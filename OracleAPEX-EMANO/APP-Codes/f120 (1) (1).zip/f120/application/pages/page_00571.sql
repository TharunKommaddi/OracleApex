prompt --application/pages/page_00571
begin
--   Manifest
--     PAGE: 00571
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>571
,p_name=>'Arbeitskreise'
,p_alias=>'ARBEITSKREISE1'
,p_page_mode=>'MODAL'
,p_step_title=>'Arbeitskreise'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'400'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13052342434726056553)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(637561291400734979)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13052342483505056553)
,p_plug_name=>'Arbeitskreise'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13052342672205056553)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1006040470691081644)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(13052342672205056553)
,p_button_name=>'BACK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1006040022654081644)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(13052342672205056553)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1006039714402081643)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(13052342672205056553)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Vorschriften'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1006036454954081638)
,p_branch_name=>'Go To Page 572'
,p_branch_action=>'f?p=&APP_ID.:572:&SESSION.::&DEBUG.::P572_EIN_VORSCHRIFT:&P25_VORSCHRIFT_NUMMER.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1006039714402081643)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1006036070127081638)
,p_branch_name=>'Go toPage 570'
,p_branch_action=>'f?p=&APP_ID.:570:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1006040470691081644)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1006036824315081639)
,p_branch_name=>'Go To Page 570'
,p_branch_action=>'f?p=&APP_ID.:570:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006038646592081641)
,p_name=>'P571_AK_SEL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(13052342483505056553)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_result VARCHAR2(4000);',
'BEGIN',
'    -- If cloning, get AKs from source ticket',
'    IF :P581_IS_CLONE = 1 AND :P581_CLONE_SOURCE_TICKET IS NOT NULL THEN',
'        SELECT LISTAGG(DISTINCT teak.et_b_akid, '':'') WITHIN GROUP (ORDER BY teak.et_b_akid)',
'        INTO v_result',
'        FROM t_mfv tm',
'        JOIN t_mfv_ref_et_b_ak tmr ON (tm.mfvid = tmr.mfvid)',
'        JOIN t_et_b_ak teak ON (tmr.et_b_akid = teak.et_b_akid)',
'        WHERE tm.jira_ticket = :P581_CLONE_SOURCE_TICKET;',
'    ELSE',
'        -- Normal mode: Get AKs from topics',
'        SELECT LISTAGG(DISTINCT trak.et_b_akid, '':'') WITHIN GROUP (ORDER BY trak.et_b_akid)',
'        INTO v_result',
'        FROM t_vorschrift_ref_thema vrt',
'        JOIN t_thema_ref_et_b_ak trak ON vrt.themaid = trak.themaid',
'        WHERE vrt.vorschriftid = :P25_VORSCHRIFTID',
'        AND vrt.geloescht = 0;',
'    END IF;',
'    ',
'    RETURN v_result;',
'END;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Arbeitskreise'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_ARBEITSKREIS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' SELECT ',
'    ET_B_AKID, ',
'    kurz, ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN Bezeichnung',
'        ELSE name_eng',
'    END AS name',
'FROM T_ET_B_AK ',
'WHERE ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN Bezeichnung',
'        ELSE name_eng',
'    END NOT IN ',
'    (',
'        CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''Administratoren'' ELSE ''Administrators'' END,',
'        CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''Redaktionsteam'' ELSE ''Editorial Team'' END',
'    );',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-w\00E4hlen-')
,p_cSize=>30
,p_read_only_when=>'P581_IS_CLONE'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'height', '350',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select LISTAGG (ET_B_AKID,'':'') ',
'from t_mfv_ref_et_b_ak tr',
'where tr.mfvid = :P581_MFVS --or :P581_MFVS is null',
'',
';',
'',
'',
'-- 05.02.29026',
'',
'',
'DECLARE',
'    v_result VARCHAR2(4000);',
'BEGIN',
'    /*IF :P581_AUSWAHL = ''10'' AND :P581_MFVS IS NOT NULL THEN',
'        -- MfV-based AKs',
'        SELECT LISTAGG(ET_B_AKID,'':'') ',
'        INTO v_result',
'        FROM t_mfv_ref_et_b_ak ',
'        WHERE mfvid = :P581_MFVS;',
'    ELSE*/',
'        -- Topic-based AKs',
'        SELECT LISTAGG(DISTINCT trak.et_b_akid, '':'') WITHIN GROUP (ORDER BY trak.et_b_akid)',
'        INTO v_result',
'        FROM t_vorschrift_ref_thema vrt',
'        JOIN t_thema_ref_et_b_ak trak ON vrt.themaid = trak.themaid',
'        WHERE vrt.vorschriftid = :P25_VORSCHRIFTID',
'        AND vrt.geloescht = 0;',
'    --END IF;',
'    ',
'    RETURN v_result;',
'END;',
'',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(916342559232945405)
,p_name=>'P571_CLONE_INFO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(13052342483505056553)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT emano_util.fLang(',
unistr('    ''Diese Arbeitskreise wurden aus Ticket '' || :P581_CLONE_SOURCE_TICKET || '' \00FCbernommen.'','),
'    ''These working groups were taken from ticket '' || :P581_CLONE_SOURCE_TICKET || ''.''',
')',
'FROM dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P581_IS_CLONE'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1006038129835081640)
,p_validation_name=>'Validation for choosing'
,p_validation_sequence=>10
,p_validation=>'P571_AK_SEL'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Arbeitskreise muss einen Wert haben.'
,p_when_button_pressed=>wwv_flow_imp.id(1006039714402081643)
,p_associated_item=>wwv_flow_imp.id(1006038646592081641)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1006037817920081639)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1006040022654081644)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006037361564081639)
,p_event_id=>wwv_flow_imp.id(1006037817920081639)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp.component_end;
end;
/
