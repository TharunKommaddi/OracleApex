prompt --application/pages/page_00930
begin
--   Manifest
--     PAGE: 00930
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>930
,p_name=>'Konzern-Marken'
,p_alias=>'KONZERN-MARKEN'
,p_step_title=>'Konzern-Marken'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(402740678876233375)
,p_name=>'Konzern-Marken'
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select km.ROWID as kmrowid,',
'       KONZERN_MARKEID,',
'       NAME,',
'       nvl2(km.letzte_aenderung_benutzerid, nachname || '', '' || vorname, null) as LETZTE_AENDERUNG_BENUTZER,',
'       km.letzte_aenderung_datum',
'  from T_KONZERN_MARKE km',
'  left join t_benutzer b on b.benutzerid = km.LETZTE_AENDERUNG_BENUTZERID  ',
'order by name'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126011838647526613)
,p_query_column_id=>1
,p_column_alias=>'KMROWID'
,p_column_display_sequence=>2
,p_column_link=>'f?p=&APP_ID.:935:&SESSION.::&DEBUG.:935:P935_ROWID:#KMROWID#'
,p_column_linktext=>'<span aria-label="Eintrag bearbeiten"><span class="fa fa-edit" aria-hidden="true" title="Eintrag bearbeiten"></span></span>'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(402739860583233363)
,p_query_column_id=>2
,p_column_alias=>'KONZERN_MARKEID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(402739487031233361)
,p_query_column_id=>3
,p_column_alias=>'NAME'
,p_column_display_sequence=>3
,p_column_heading=>'Marke'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126011961104526614)
,p_query_column_id=>4
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZER'
,p_column_display_sequence=>5
,p_column_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126011981218526615)
,p_query_column_id=>5
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>4
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_column_format=>'DD.MM.YYYY HH24:MI'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(402738129600233358)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(402740678876233375)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:935:&SESSION.::&DEBUG.:935'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(402739046797233360)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(402740678876233375)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(402738604901233358)
,p_event_id=>wwv_flow_imp.id(402739046797233360)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(402740678876233375)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
