prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>15
,p_name=>unistr('L\00E4ndergruppe bearbeiten / hinzuf\00FCgen')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('L\00E4ndergruppe bearbeiten / hinzuf\00FCgen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>unistr('var htmldb_delete_message=''"M\00F6chten Sie die L\00E4ndergruppe l\00F6schen"'';')
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2641369099444049498)
,p_plug_name=>'Form on T_LAENDERGRUPPE'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2645048189454950740)
,p_plug_name=>unistr('L\00E4nder')
,p_parent_plug_id=>wwv_flow_imp.id(2641369099444049498)
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(2645048424935950742)
,p_name=>unistr('Zugeordnete L\00E4nder')
,p_parent_plug_id=>wwv_flow_imp.id(2645048189454950740)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select lrl.rowid, lrl.LAND_REF_LAENDERGRUPPEID,',
'       l.LAND || '' ('' || l.B_NUMMER || '')'' AS LAND,',
'       GUELTIG_VON,',
'       GUELTIG_BIS,',
'       lrl.LETZTE_AENDERUNG_DATUM,',
'       b.nachname || '', '' || b.vorname AS BENUTZER',
'  from T_LAND_REF_LAENDERGRUPPE lrl',
'join t_laendergruppe lg on lg.LAENDERGRUPPEID = lrl.LAENDERGRUPPEID',
'join t_land l on l.landid = lrl.landid',
'left outer join t_benutzer b on b.benutzerid = lrl.LETZTE_AENDERUNG_BENUTZERID',
'where lg.rowid = :P15_ROWID',
'order by NLSSORT(l.B_NUMMER, ''NLS_SORT=BINARY_AI'') asc, lrl.GUELTIG_VON asc, lrl.GUELTIG_BIS asc'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>unistr('Noch keine L\00E4nder zugeordnet.')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2645470774643731642)
,p_query_column_id=>1
,p_column_alias=>'ROWID'
,p_column_display_sequence=>1
,p_column_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:RP,16:P16_ROWID:#ROWID#'
,p_column_linktext=>'<span class="fa fa-pencil" aria-hidden="true"></span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2645048514032950743)
,p_query_column_id=>2
,p_column_alias=>'LAND_REF_LAENDERGRUPPEID'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2645049260845950750)
,p_query_column_id=>3
,p_column_alias=>'LAND'
,p_column_display_sequence=>3
,p_column_heading=>'Land'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2645048839803950746)
,p_query_column_id=>4
,p_column_alias=>'GUELTIG_VON'
,p_column_display_sequence=>4
,p_column_heading=>unistr('G\00FCltig von')
,p_column_format=>'DD.MM.YYYY'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2645048909996950747)
,p_query_column_id=>5
,p_column_alias=>'GUELTIG_BIS'
,p_column_display_sequence=>5
,p_column_heading=>unistr('G\00FCltig bis')
,p_column_format=>'DD.MM.YYYY'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2645048998128950748)
,p_query_column_id=>6
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>6
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_column_format=>'DD.MM.YYYY HH24:Mi'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2645049336856950751)
,p_query_column_id=>7
,p_column_alias=>'BENUTZER'
,p_column_display_sequence=>7
,p_column_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2641369834435049501)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2641370190037049502)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2641369834435049501)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2641369755475049501)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2641369834435049501)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2645048351566950741)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2645048189454950740)
,p_button_name=>'ADD_LAND'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:RP,16:P16_LAENDERGRUPPEID:&P15_LAENDERGRUPPEID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2641369617492049501)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2641369834435049501)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P15_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2641369564149049501)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2641369834435049501)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P15_ROWID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2641372644493049512)
,p_name=>'P15_ROWID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2641369099444049498)
,p_use_cache_before_default=>'NO'
,p_source=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2641373048708049527)
,p_name=>'P15_LAENDERGRUPPE'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2641369099444049498)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('L\00E4ndergruppe')
,p_source=>'LAENDERGRUPPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2641373440158049532)
,p_name=>'P15_LAENDERGRUPPE_TYP'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2641369099444049498)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Typ'
,p_source=>'LAENDERGRUPPE_TYP'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2645470961596731643)
,p_name=>'P15_LAENDERGRUPPEID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2641369099444049498)
,p_use_cache_before_default=>'NO'
,p_source=>'LAENDERGRUPPEID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2655294955070689645)
,p_name=>'P15_LAENDER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2641369099444049498)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Zugeordnete L\00E4nder')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select lrlg.LANDID',
'from T_LAENDERGRUPPE lg',
'join T_LAND_REF_LAENDERGRUPPE lrlg on lrlg.LAENDERGRUPPEID = lg.LAENDERGRUPPEID',
'join T_LAND l on l.LANDID = lrlg.LANDID',
'where lg.rowid = :P15_ROWID',
'ORDER BY NLSSORT(l.B_NUMMER, ''NLS_SORT=BINARY_AI'') ASC'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    l.B_NUMMER || '' - '' || ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.LAND',
'        ELSE l.LAND_ENG ',
'    END AS Land,',
'    l.LANDID',
'FROM ',
'    T_LAND l',
'ORDER BY ',
'    NLSSORT(l.B_NUMMER, ''NLS_SORT=BINARY_AI'') ASC',
''))
,p_cHeight=>5
,p_display_when=>'P15_ROWID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2641370304204049502)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2641370190037049502)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2641371125742049507)
,p_event_id=>wwv_flow_imp.id(2641370304204049502)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2650732159806831446)
,p_name=>'DIALOG_LAENDER_CLOSED'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2645048189454950740)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2650732261115831447)
,p_event_id=>wwv_flow_imp.id(2650732159806831446)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2645048424935950742)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2641374245660049537)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_LAENDERGRUPPE'
,p_attribute_02=>'T_LAENDERGRUPPE'
,p_attribute_03=>'P15_ROWID'
,p_attribute_04=>'ROWID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6313586561559437772
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2641374579500049537)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of T_LAENDERGRUPPE'
,p_attribute_02=>'T_LAENDERGRUPPE'
,p_attribute_03=>'P15_ROWID'
,p_attribute_04=>'ROWID'
,p_attribute_09=>'P15_ROWID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>unistr('L\00E4ndergruppe erstellt.')
,p_internal_uid=>6313586895399437772
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2655294984756689646)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LAENDER'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_laendergruppeid number;',
'begin',
'    select laendergruppeid into l_laendergruppeid',
'    from t_laendergruppe',
'    where rowid = :P15_ROWID;',
'  ',
'    merge into t_land_ref_laendergruppe dest',
'    using (select l_laendergruppeid as laendergruppeid, column_value  as landid from TABLE(APEX_STRING.split_numbers(:P15_LAENDER, '':''))) src',
'    on (dest.laendergruppeid = src.laendergruppeid',
'       and dest.landid = src.landid)',
'    when not matched then insert(dest.laendergruppeid, dest.landid)',
'       values(src.laendergruppeid, src.landid);',
'      ',
'    delete from t_land_ref_laendergruppe lrlg',
'    where lrlg.laendergruppeid = l_laendergruppeid',
'        and lrlg.landid not in (select column_value from TABLE(APEX_STRING.split_numbers(:P15_LAENDER, '':'')));',
'',
'    update t_laendergruppe',
'    set letzte_aenderung_datum = sysdate, letzte_aenderung_benutzerid = :G_BENUTZERID',
'    where laendergruppeid = l_laendergruppeid;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6327507300656077881
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2641375023905049538)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2641369755475049501)
,p_internal_uid=>6313587339804437773
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2641375438203049538)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>6313587754102437773
);
wwv_flow_imp.component_end;
end;
/
