prompt --application/pages/page_00480
begin
--   Manifest
--     PAGE: 00480
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>480
,p_name=>unistr(' \00DCbergangsbestimmung_farbe Report')
,p_alias=>unistr('\00DCBERGANGSBESTIMMUNG-FARBE-REPORT')
,p_step_title=>unistr('\00DCbergangsbestimmung_farbe Report')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1982163038347120961)
,p_name=>unistr('\00DCbergangsbestimmung_farbe Report')
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select   UEBERGANGSBESTIMMUNG_FARBEID,',
'        ',
'       VORSCHRIFT_AENDERUNGID,',
'       v.vorschrift_nummer,',
'       FARBE',
'  from T_UEBERGANGSBESTIMMUNG_FARBE uf',
'  join t_vorschrift v on  (v.vorschriftid = uf.VORSCHRIFT_AENDERUNGID)'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1073650820325865102)
,p_query_column_id=>1
,p_column_alias=>'UEBERGANGSBESTIMMUNG_FARBEID'
,p_column_display_sequence=>70
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1073650439394865099)
,p_query_column_id=>2
,p_column_alias=>'VORSCHRIFT_AENDERUNGID'
,p_column_display_sequence=>10
,p_column_heading=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:485:&SESSION.::&DEBUG.:485:P485_UEBERGANGSBESTIMMUNG_FARBEID:#UEBERGANGSBESTIMMUNG_FARBEID#'
,p_column_linktext=>'<span class="fa fa-pencil" aria-hidden="true"></span>'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1073650017172865099)
,p_query_column_id=>3
,p_column_alias=>'VORSCHRIFT_NUMMER'
,p_column_display_sequence=>60
,p_column_heading=>'Vorschrift Nummer'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1073649643494865099)
,p_query_column_id=>4
,p_column_alias=>'FARBE'
,p_column_display_sequence=>50
,p_column_heading=>'Farbe'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1073648967465865062)
,p_button_sequence=>40
,p_button_name=>'ADD'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Erstellen'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:485:&SESSION.::&DEBUG.:485::'
,p_grid_new_row=>'Y'
,p_grid_column=>11
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1073648664727865054)
,p_name=>'Dialog_edit closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1982163038347120961)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1073648201389865047)
,p_event_id=>wwv_flow_imp.id(1073648664727865054)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1982163038347120961)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1073647719318865046)
,p_name=>'dlg closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1073648967465865062)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1073647281062865045)
,p_event_id=>wwv_flow_imp.id(1073647719318865046)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1982163038347120961)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
