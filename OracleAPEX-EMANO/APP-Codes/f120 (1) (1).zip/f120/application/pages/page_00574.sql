prompt --application/pages/page_00574
begin
--   Manifest
--     PAGE: 00574
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>574
,p_name=>'Zusammenfassung'
,p_alias=>'ZUSAMMENFASSUNG1'
,p_page_mode=>'MODAL'
,p_step_title=>'Zusammenfassung'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_dialog_width=>'1000'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(916342784755945407)
,p_plug_name=>'&nbsp;'
,p_icon_css_classes=>'fa-warning'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--warning'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><strong>Klonmodus aktiviert!</strong></p>',
'<p>Dieses Ticket wird mit Daten aus dem Quellticket <strong>&P581_CLONE_SOURCE_TICKET.</strong> erstellt.</p>',
unistr('<p>Alle Arbeitsergebnisse (Background, Betroffene Bereiche, Contributors, Analyse, Request for Resolution) und Anh\00E4nge werden kopiert.</p>')))
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P574_CLONE_INFO'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13052394607093076525)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(637561291400734979)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13052394754571076525)
,p_plug_name=>'Zusammenfassung'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13052394782436076525)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1006009848649055867)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(13052394782436076525)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1006009492893055867)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(13052394782436076525)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Jira-Link vorbereiten'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1006009069326055867)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(13052394782436076525)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1006007238624055866)
,p_branch_name=>'Go To Page 576'
,p_branch_action=>'f?p=&APP_ID.:576:&SESSION.::&DEBUG.:576:P576_JIRA_POST_ID:&P574_JIRA_POST_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1006009492893055867)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1006007665675055866)
,p_branch_name=>'Go To Page 573'
,p_branch_action=>'f?p=&APP_ID.:572:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1006009069326055867)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3098112959653958313)
,p_name=>'P574_COCOA_1'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(13052394754571076525)
,p_prompt=>'Cocoa-Ticket'
,p_source=>'P582_COCOA'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006014592320055871)
,p_name=>'P574_MFV_RO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(13052394754571076525)
,p_use_cache_before_default=>'NO'
,p_prompt=>'MfV Teil'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when :P570_MFV_TYP = 1 then ''Information''',
'else ''Interpretation'' end from dual;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006014146067055870)
,p_name=>'P574_ARBEITSKREISE_RO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(13052394754571076525)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr(' Gew\00E4hlte Arbeitskreise')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(bezeichnung, '',''||chr(13)) within group (order by bezeichnung) ',
'  from t_et_b_ak',
' where et_b_akid in (',
'    select column_value from table(apex_string.split(:P571_AK_SEL, '':'')));'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006013736348055870)
,p_name=>'P574_ONE_ONLY_DISP'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(13052394754571076525)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when (:P572_FOR_ONE = 1) then',
unistr('    emano_util.fLang(''MfV f\00FCr eine Vorschrift!'', ''MfV for a regulation!'')'),
'    else ',
unistr('    emano_util.fLang(''MfV f\00FCr mehrere Vorschriften!'', ''MfV for several regulations!'')'),
'    end as vor',
'from dual;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006013373833055869)
,p_name=>'P574_MASTER_VORSCHRIFT_DISP'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(13052394754571076525)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Hauptvorschrift f\00FCr MfV (Jira-Datengrundlage)')
,p_source=>'select vorschrift_nummer from T_Vorschrift where vorschriftid =:P572_MASTER_VORSCHRIFTID;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006012987115055869)
,p_name=>'P574_VORSCHRIFT_OLD'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(13052394754571076525)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
' with cte1 as (Select vorschrift_nummer',
'    from t_vorschrift_ref_vorschrift tvrv',
'    join t_vorschrift tv on (tvrv.VORGAENGER_VORSCHRIFTID = tv.vorschriftid)',
'    where  beziehung_art = 10 and nachfolger_vorschriftid =:P572_MASTER_VORSCHRIFTID',
'    )',
'    Select nvl(listagg(vorschrift_nummer, '', '') ,',
unistr('    emano_util.fLang(''Es wurde keine Vorschrift in RegIndex als Vorg\00E4nger hinterlegt'', ''No rule has been registered in RegIndex as a predecessor'')) as mesage'),
'    from cte1'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>unistr('Vorg\00E4nger Vorschriftennummer')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P570_MFV_TYP'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006012579414055869)
,p_name=>'P574_VORSCHRIFTEN_RO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(13052394754571076525)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Zus\00E4tzliche Vorschrift(en) f\00FCr MfV')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(vorschrift_nummer,'', ''||chr(13)) within group (order by vorschrift_nummer)  from T_Vorschrift where vorschriftid in (',
'select column_value from table(apex_string.split_numbers(:P572_VORSCHRIFTEN_SEL,'':'')));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P572_FOR_ONE'
,p_display_when2=>'0'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006012155226055869)
,p_name=>'P574_STICHWWOERTER_RO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(13052394754571076525)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Verkn\00FCpfte Themengebiete')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*select listagg(stext, '', '') within group (order by stext) ',
'  from t_Schlagwort where schlagwortid in (',
'            select column_value ',
'              from table(apex_string.split_numbers(:P573_STICHWORT_SEL,'':'')));',
'              */',
'--    Select replace(:P573_STICHWORT_SEL,'':'','', '') from dual',
'',
'Select listagg( replace(Bezeichnung,'':'','' ''),''; '') ',
' from t_vorschrift_ref_thema tvrt',
' join t_thema tt on (tvrt.themaid = tt.themaid)',
' where tvrt.geloescht =0 and (tvrt.vorschriftid =  :P572_MASTER_VORSCHRIFTID or tvrt.vorschriftid IN (',
'         SELECT',
'             column_value',
'         FROM',
'             TABLE ( apex_string.split_numbers(:P572_VORSCHRIFTEN_SEL, '':'') )))'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006011776049055868)
,p_name=>'P574_P574_MFVS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(13052394754571076525)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Vorg\00E4nger MfV-ID')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Check if clone mode is active',
'SELECT ',
'    CASE ',
'        -- If cloning, show the source ticket',
'        WHEN :P581_IS_CLONE = 1 THEN ',
'            :P581_CLONE_SOURCE_TICKET',
'        ',
'        -- If normal mode and MfV selected, show MfV name',
'        WHEN :P581_MFVS IS NOT NULL THEN ',
'            (',
'                SELECT MFV_NAME',
'                FROM t_mfv tm ',
'                LEFT OUTER JOIN t_mfv_ref_mfv_teil tmrt ON (tm.mfvid = tmrt.mfvid)',
'                LEFT OUTER JOIN t_mfv_teil tmt ON (tmrt.MFV_TEILID = tmt.MFV_TEILID)',
'                WHERE tm.mfvid = :P581_MFVS',
'                GROUP BY tm.mfvid, MFV_NAME',
'                FETCH FIRST 1 ROWS ONLY',
'            )',
'        ',
'        -- If normal mode and no MfV selected',
'        ELSE ',
unistr('            ''Keine Vorg\00E4nger-MFV ausgew\00E4hlt / in Regindex hinterlegt'''),
'    END AS vorgaenger_mfv_id',
'FROM dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 12.02.2026 14:26 pm - backup without cloned info',
'',
'with cte1 as (Select  MFV_NAME',
'from t_mfv tm ',
'left outer join t_mfv_ref_mfv_teil tmrt on (tm.mfvid = tmrt.mfvid )',
'left outer join t_mfv_teil tmt on (tmrt.MFV_TEILID = tmt.MFV_TEILID)',
'where tm.mfvid = :P581_MFVS',
'group by tm.mfvid,MFV_NAME',
')',
'Select mfv_name ',
'from cte1',
'union all',
unistr('Select ''Keine Vorg\00E4nger-MFV ausgew\00E4hlt / in Regindex hinterlegt'''),
'from dual where :P581_MFVS is null'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006011365722055868)
,p_name=>'P574_MFVID'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(13052394754571076525)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Neue MfV-ID'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select case when (:P570_MFV_TYP = 1) then ''INF_''',
' when (:P570_MFV_TYP = 2)  then ''INT_'' else ''Fehler'' end ',
'|| (Select listagg(kurz,''_'') within group(order by kurz) as d from t_et_b_ak where et_b_akid in (Select column_value from table (apex_string.split_numbers(:P571_AK_SEL,'':''))))',
' ||''_TVRB-XXXXX'' ||''_V'' || case when :P581_MFVS is null then ''01'' else ',
' (Select case  when substr(substr(mfv_name,-4),0,2) =''_V'' then lpad(to_number(substr(mfv_name,-2))+1,2,''0'') else ''YY'' end',
' from t_mfv tm where tm.mfvid = :P581_MFVS)',
'',
' ',
' end',
'',
'as d ',
'',
'from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006010973190055868)
,p_name=>'P574_SUMIS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(13052394754571076525)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Potentiell SUMS-relevant'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--select rxswin from T_Vorschrift where vorschriftid =:P572_MASTER_VORSCHRIFTID;',
'',
'',
'with cte1 as (',
'Select distinct vorschriftid, 1 as sums_land from t_vorschrift_ref_land tvrl',
'join t_land tl on (tvrl.landid = tl.landid)',
'where sums_relevant = 10',
')',
'Select  case when rxswin = 10 and tv.homologationsrelevant = 10 and (nvl(sums_land,0) = 1 or substr(vorschrift_nummer,0,4) =''UN-R'')then  10   ',
'when rxswin = 0  and tv.homologationsrelevant = 10  then 0 ',
'when rxswin = 20 and tv.homologationsrelevant = 10 and (nvl(sums_land,0) = 1 or substr(vorschrift_nummer,0,4) =''UN-R'') then 20 else 0 end r',
'from t_vorschrift tv',
'left join cte1 t1 on (tv.vorschriftid = t1.vorschriftid)',
'where tv.vorschriftid =:P572_MASTER_VORSCHRIFTID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Nicht gepr\00FCft'', ''Not checked'') AS display_value,'),
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_display_when=>'P570_MFV_TYP'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006010520848055867)
,p_name=>'P574_COCOA'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(13052394754571076525)
,p_prompt=>'Cocoa-Ticket'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ''<a href="https://devstack.vwgroup.com/jira/browse/'' || :P582_COCOA || ''" target="_blank" class="t-Button t-Button--hot t-Button--small">',
'<span class="t-Icon t-Icon--left fa fa-external-link"></span>',
unistr(''' || :P582_COCOA || '' \00F6ffnen'),
'</a>'' AS Cocoa_ticket',
'FROM dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P582_COCOA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988066452934880387)
,p_name=>'P574_JIRA_POST_ID'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(13052394754571076525)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(967677233943291034)
,p_name=>'P574_COCOA_LINK'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(13052394754571076525)
,p_prompt=>'COCOA Ticket Link'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :P582_COCOA IS NOT NULL THEN',
'            ''<a href="https://cicd.cloud.audi/jira/browse/'' || :P582_COCOA || ''" target="_blank" class="t-Button t-Button--small">'' ||',
'            ''<span class="t-Icon t-Icon--left fa fa-external-link"></span>'' ||',
unistr('            :P582_COCOA || '' \00F6ffnen'' ||'),
'            ''</a>''',
'        ELSE',
'            NULL',
'    END AS cocoa_link',
'FROM dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(916342876533945408)
,p_name=>'P574_CLONE_INFO'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(13052394754571076525)
,p_prompt=>'Ticket-Modus'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CASE ',
'    WHEN :P581_IS_CLONE = 1 THEN ',
'        emano_util.fLang(',
'            ''Geklont von: '' || :P581_CLONE_SOURCE_TICKET,',
'            ''Cloned from: '' || :P581_CLONE_SOURCE_TICKET',
'        )',
'    ELSE ',
'        emano_util.fLang(''Neues Ticket'', ''New Ticket'')',
'END AS clone_status',
'FROM dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1006008650082055866)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1006009848649055867)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006008210157055866)
,p_event_id=>wwv_flow_imp.id(1006008650082055866)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(988066358444880386)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create_Jira_POST'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_jira_post_id NUMBER;',
'    l_is_clone NUMBER;',
'    l_source_ticket VARCHAR2(100);',
'BEGIN',
'    -- Log all parameters',
'    debug(''Ticket Assistant'', ''========== CREATE JIRA POST START =========='');',
'    debug(''Assi :P572_MASTER_VORSCHRIFTID'', :P572_MASTER_VORSCHRIFTID);',
'    debug(''Assi :P571_AK_SEL'', :P571_AK_SEL);',
'    debug(''Assi :P570_MFV_TYP'', :P570_MFV_TYP);',
'    debug(''Assi :P573_STICHWORT_SEL'', :P573_STICHWORT_SEL);',
'    debug(''Assi :P572_VORSCHRIFTEN_SEL'', :P572_VORSCHRIFTEN_SEL);',
'    debug(''Assi :P581_MFVS'', :P581_MFVS);',
'    debug(''Assi :P582_COCOA'', :P582_COCOA);',
'    ',
'    -- Get clone information',
'    l_is_clone := NVL(:P581_IS_CLONE, 0);',
'    l_source_ticket := :P581_CLONE_SOURCE_TICKET;',
'    ',
'    debug(''Assi :P581_IS_CLONE'', l_is_clone);',
'    debug(''Assi :P581_CLONE_SOURCE_TICKET'', NVL(l_source_ticket, ''[NULL]''));',
'    ',
'    -- Validate clone parameters',
'    IF l_is_clone = 1 THEN',
'        IF l_source_ticket IS NULL OR TRIM(l_source_ticket) = '''' THEN',
'            debug(''Ticket Assistant'', ''ERROR: Clone mode enabled but no source ticket selected'');',
unistr('            RAISE_APPLICATION_ERROR(-20001, ''Klonmodus aktiviert, aber kein Quellticket ausgew\00E4hlt'');'),
'        END IF;',
'        debug(''Ticket Assistant'', ''>>> CLONE MODE ACTIVE <<<'');',
'    ELSE',
'        debug(''Ticket Assistant'', ''>>> NORMAL MODE <<<'');',
'    END IF;',
'    ',
'    -- Call the function with clone parameters',
'    l_jira_post_id := PCK_CIP_JIRA.postNewTicketinQueue(',
'        aVorschriftId       => :P572_MASTER_VORSCHRIFTID,',
'        aMFV_TEILID         => NVL(:P570_MFV_TYP, 1),',
'        aAKIDS              => :P571_AK_SEL,',
unistr('        aSchlagw\00F6rter       => :P573_STICHWORT_SEL,'),
'        aZusVorschriften    => :P572_VORSCHRIFTEN_SEL,',
'        aMFVID              => :P574_MFVID,',
'        aprevMFVid          => :P581_MFVS,',
'        aCocoaTicket        => :P582_COCOA,',
'        aIsClone            => l_is_clone,           ',
'        aSourceTVRBTicket   => l_source_ticket       ',
'    );',
'    ',
'    debug(''Ticket Assistant'', ''JIRA_POST_ID created: '' || l_jira_post_id);',
'    ',
'    -- Store the ID for page 576',
'    :P574_JIRA_POST_ID := l_jira_post_id;',
'    ',
'    debug(''Ticket Assistant'', ''========== CREATE JIRA POST COMPLETE =========='');',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        debug(''Ticket Assistant'', ''FATAL ERROR in Create_Jira_POST: '' || SQLERRM);',
'        debug(''Ticket Assistant'', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);',
'        RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1006009492893055867)
,p_internal_uid=>2684145957454507849
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(916342945382945409)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create_Jira_POST_05.02.2026 Backup'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_jira_post_id NUMBER;',
'BEGIN',
'',
'debug(''Assi :P572_MASTER_VORSCHRIFTID'',:P572_MASTER_VORSCHRIFTID);',
'debug(''Assi :P571_AK_SEL'',:P571_AK_SEL);',
'debug(''Assi :P570_MFV_TYP'',:P570_MFV_TYP);',
'debug(''Assi :P571_AK_SEL'',:P571_AK_SEL);',
'debug(''Assi :P573_STICHWORT_SEL'',:P573_STICHWORT_SEL);',
'debug(''Assi ::P572_VORSCHRIFTEN_SEL'',:P572_VORSCHRIFTEN_SEL);',
'debug(''Assi :P581_MFVS'',:P581_MFVS);',
'    -- Call the function that returns the JIRA_POST_ID',
'    l_jira_post_id := PCK_CIP_JIRA.postNewTicketinQueue(',
'        :P572_MASTER_VORSCHRIFTID, ',
'        nvl(:P570_MFV_TYP,1),',
'        :P571_AK_SEL,',
'        :P573_STICHWORT_SEL, ',
'        :P572_VORSCHRIFTEN_SEL,',
'        :P574_MFVID, ',
'        :P581_MFVS, ',
'        :P582_COCOA',
'    );',
'    ',
'    -- Store the ID for page 576',
'    :P574_JIRA_POST_ID := l_jira_post_id;',
'    ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1006009492893055867)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2755869370516442826
);
wwv_flow_imp.component_end;
end;
/
