prompt --application/pages/page_00466
begin
--   Manifest
--     PAGE: 00466
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>466
,p_name=>'ET/FB Bewertungen bearbeiten'
,p_alias=>'ET-FB-BEWERTUNGEN-BEARBEITEN'
,p_page_mode=>'MODAL'
,p_step_title=>'ET/FB Bewertungen bearbeiten'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.regulation-selector {',
'    background: #e3f2fd;',
'    padding: 15px;',
'    border-radius: 4px;',
'    margin-bottom: 15px;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_dialog_width=>'1000'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8803481388107153450)
,p_plug_name=>'Form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15312012369168692262)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964144491633466103)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(15312012369168692262)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964144101988466103)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(15312012369168692262)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>unistr('javascript:apex.confirm(''M\00F6chten Sie den FilterProfil l\00F6schen?'',''DELETE'');')
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964143634236466103)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(15312012369168692262)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964143226439466103)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(15312012369168692262)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964153169542466111)
,p_name=>'P466_INFO_TEXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_prompt=>'INFO Text'
,p_source=>unistr('ben\00F6tigen sie eine Vorschrift aus dieser Zeile')
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964152782995466111)
,p_name=>'P466_REGULATION_SELECTOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_prompt=>'Sie sind in der Zeile..'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    CASE',
'        WHEN tv.vorschrift_nummer IS NOT NULL THEN tv.vorschrift_nummer',
'        ELSE ms.vorschriftnummer',
'    END as d, -- Display Value',
'    CASE',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END as r -- Return Value',
'FROM T_MS_SUCHERGEBNISS ms',
'LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'WHERE ms.sucheid = :P466_SEARCH_SELECTION',
'AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'ORDER BY 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    CASE ',
'        WHEN tv.vorschrift_nummer IS NOT NULL THEN tv.vorschrift_nummer',
'        ELSE ms.vorschriftnummer',
'    END || ',
'    CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NULL THEN '' (Main)''',
'        ELSE '' (Alternative)''',
'    END as d,',
'    CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END as r',
'FROM T_MS_SUCHERGEBNISS ms',
'LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'ORDER BY 1;'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964152404290466110)
,p_name=>'P466_HOMOLOGATION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_prompt=>'Homologations<br>eigenschaft(en)'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CASE',
'        WHEN LENGTH(homologation_list) > 500',
'        THEN SUBSTR(homologation_list, 1, 497) || ''...''',
'        ELSE homologation_list',
'    END AS homologation_properties',
'FROM (',
'    SELECT',
'        REPLACE(',
'            LISTAGG(DISTINCT e.EIGENSCHAFT_KENNUNG || ''-'' || et.kuerzel || ''-'' || e.eigenschaft, '', '')',
'            WITHIN GROUP (ORDER BY e.eigenschaft),',
'            '', '',',
'            ''<br>''',
'        ) AS homologation_list',
'    FROM t_vorschrift_ref_thema vrt',
'    JOIN carmah2_admin.t_eigenschaft_ref_regindexthemen err ON (vrt.themaid = err.regindex_themen_id)',
'    JOIN carmah2_admin.t_eigenschaft e ON (err.eigenschaft_id = e.eigenschaft_id)',
'    JOIN carmah2_admin.t_eigenschaft_typ et ON (e.eigenschaft_typ_id = et.eigenschaft_typ_id)',
'    WHERE vrt.geloescht = 0',
'    AND vrt.vorschriftid = :P466_REGULATION_SELECTOR',
')'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964151999605466110)
,p_name=>'P466_LRSA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_prompt=>'LRSA'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CASE',
'        WHEN LENGTH(lrsa_list) > 500',
'        THEN SUBSTR(lrsa_list, 1, 497) || ''...''',
'        ELSE lrsa_list',
'    END AS lrsa_properties',
'FROM (',
'    SELECT',
'        REPLACE(',
'            LISTAGG(DISTINCT l.lrsa_nummer || '' - '' || l.bezeichnung, '', '')',
'            WITHIN GROUP (ORDER BY l.bezeichnung ASC),',
'            '', '',',
'            ''<br>''',
'        ) AS lrsa_list',
'    FROM t_vorschrift_ref_thema vrt',
'    JOIN T_THEMA_REF_LRSA ref ON (vrt.themaid = ref.themaid)',
'    JOIN T_LRSA l ON (l.LRSA_ID = ref.LRSAID)',
'    WHERE vrt.geloescht = 0',
'    AND vrt.vorschriftid = :P466_REGULATION_SELECTOR',
')'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964151591879466110)
,p_name=>'P466_BEWERTUNG_ANSICHT'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_item_default=>'ET'
,p_prompt=>'<b>Bewertung Ansicht</b>'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'SELECT display_value as d, return_value as r',
'FROM (',
'    SELECT ''ET-B Abstimmung'' as display_value, ''ET'' as return_value, 1 as sort_order FROM dual',
'    UNION ALL',
'    SELECT ''ET-A Vorschlag'', ''FB'', 2 FROM dual',
'    UNION ALL',
'    SELECT ''ET-G Vorschlag'', ''ANDERE'', 3 FROM dual',
')',
'ORDER BY sort_order'))
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964151189198466109)
,p_name=>'P466_SELECTED_ROWS'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964150730606466109)
,p_name=>'P466_ET_KOMMENTAR'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_use_cache_before_default=>'NO'
,p_prompt=>'ET Kommentar'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ET_KOMMENTAR',
'FROM T_MS_BEWERTUNG',
'WHERE SUCHEID = :P466_SEARCH_SELECTION',
'AND MEILENSTEIN = :P466_MILESTONE_SELECTION',
'AND CARD_NUMBER = :P466_CARD_NUM',
'AND VORSCHRIFTID = :P466_REGULATION_SELECTOR',
'-- AND BENUTZERID = :G_BENUTZERID;',
'AND (BENUTZERID = :G_BENUTZERID',
'     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                WHERE brr.benutzerid = :G_BENUTZERID ',
'                AND brr.rolleid = 1001)',
'    );'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>':P466_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964150352140466109)
,p_name=>'P466_ET_VERWENDUNG'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Ben\00F6tigt ET-G eine Vorschrift aus dieser Zeile f\00FCr die Homologation?')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NVL(ET_VERWENDUNG, ''nicht bewertet'')',
'FROM T_MS_BEWERTUNG',
'WHERE SUCHEID = :P466_SEARCH_SELECTION',
'AND MEILENSTEIN = :P466_MILESTONE_SELECTION',
'AND CARD_NUMBER = :P466_CARD_NUM',
'AND VORSCHRIFTID = :P466_REGULATION_SELECTOR',
'-- AND BENUTZERID = :G_BENUTZERID;',
'AND (BENUTZERID = :G_BENUTZERID ',
'     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                WHERE brr.benutzerid = :G_BENUTZERID ',
'                AND brr.rolleid = 1001)',
'    );'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT d, r FROM (',
'    SELECT ''nicht bewertet'' as d, ''nicht bewertet'' as r FROM dual',
'    UNION ALL',
'    SELECT ''ja'' as d, ''ja'' as r FROM dual  ',
'    UNION ALL',
'    SELECT ''nein'' as d, ''nein'' as r FROM dual',
'  ) ORDER BY CASE WHEN r = ''nicht bewertet'' THEN 1 WHEN r = ''ja'' THEN 2 ELSE 3 END'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Bitte ausw\00E4hlen --')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>':P466_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964149933953466109)
,p_name=>'P466_ET_VORSCHLAG_VORSCHRIFT'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_prompt=>'ET Vorschlag Vorschrift'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH base_regulation AS (',
'    -- Main regulation',
'    SELECT ',
'        ms.vorschriftid,',
'        CASE ',
'            WHEN tp.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND tv.DOKUMENTENDATUM IS NOT NULL ',
'            THEN tv.vorschrift_nummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'            ELSE tv.vorschrift_nummer ',
'        END as display_value,',
'        1 as display_order,',
'        ''Hauptvorschrift'' as category',
'    FROM T_MS_SUCHERGEBNISS ms',
'    INNER JOIN t_vorschrift tv ON tv.vorschriftid = CASE ',
'        WHEN ms.alternative_vorschriftid IS NOT NULL ',
'        THEN ms.alternative_vorschriftid ',
'        ELSE ms.vorschriftid ',
'    END',
'    LEFT JOIN t_publisher tp ON tv.publisherid = tp.publisherid',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND (CASE ',
'        WHEN ms.alternative_vorschriftid IS NOT NULL ',
'        THEN ms.alternative_vorschriftid ',
'        ELSE ms.vorschriftid ',
'    END) = :P466_SINGLE_REG_ID',
'    AND ROWNUM = 1',
'),',
'alternative_regulations AS (',
'    -- Alternative regulations (higher series)',
'    SELECT DISTINCT',
'        ms.alternative_vorschriftid as vorschriftid,',
'        CASE ',
'            WHEN tp.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND tv.DOKUMENTENDATUM IS NOT NULL ',
'            THEN tv.vorschrift_nummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'            ELSE tv.vorschrift_nummer ',
'        END as display_value,',
'        2 as display_order,',
'        ''Alternative'' as category',
'    FROM T_MS_SUCHERGEBNISS ms',
'    INNER JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'    LEFT JOIN t_publisher tp ON tv.publisherid = tp.publisherid',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.vorschriftid = :P466_SINGLE_REG_ID',
'    AND ms.alternative_vorschriftid IS NOT NULL',
'),',
'all_successors AS (',
'    -- Get ALL recursive successors ONLY from T_MS_SUCHERGEBNISS',
'    SELECT DISTINCT',
'        vrv.nachfolger_vorschriftid as vorschriftid,',
'        CASE ',
'            WHEN tp.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND tv.DOKUMENTENDATUM IS NOT NULL ',
'            THEN tv.vorschrift_nummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'            ELSE tv.vorschrift_nummer ',
'        END as display_value,',
'        3 as display_order,',
'        ''Nachfolger (Ebene '' || LEVEL || '')'' as category,',
'        LEVEL as successor_level',
'    FROM t_vorschrift_ref_vorschrift vrv',
'    INNER JOIN t_vorschrift tv ON tv.vorschriftid = vrv.nachfolger_vorschriftid',
'    LEFT JOIN t_publisher tp ON tv.publisherid = tp.publisherid',
unistr('    -- \2705 FILTER: Only successors that exist in T_MS_SUCHERGEBNISS'),
'    INNER JOIN t_ms_suchergebniss ms ON (',
'        ms.vorschriftid = vrv.nachfolger_vorschriftid',
'        AND ms.sucheid = :P466_SEARCH_SELECTION',
'        AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    )',
'    WHERE vrv.beziehung_art = 10',
'    START WITH vrv.vorgaenger_vorschriftid IN (',
'        SELECT vorschriftid FROM base_regulation',
'        UNION ALL',
'        SELECT vorschriftid FROM alternative_regulations',
'    )',
'    CONNECT BY NOCYCLE PRIOR vrv.nachfolger_vorschriftid = vrv.vorgaenger_vorschriftid',
'        AND vrv.beziehung_art = 10',
'        AND LEVEL <= 10',
')',
'-- Combine all results',
'SELECT ',
'    display_value as d,',
'    display_value as r',
'FROM (',
'    SELECT display_value, display_order, category FROM base_regulation',
'    UNION ALL',
'    SELECT display_value, display_order, category FROM alternative_regulations',
'    UNION ALL',
'    SELECT display_value, display_order, category FROM all_successors',
')',
'-- ORDER BY display_order, display_value;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Vorschrift ausw\00E4hlen --')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P466_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')',
'',
'',
'SELECT DISTINCT regulation_option as d, regulation_option as r',
'  FROM (',
'      SELECT ms.vorschriftnummer as regulation_option',
'      FROM T_MS_SUCHERGEBNISS ms',
'      WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'      AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'      UNION',
'      SELECT tv.vorschrift_nummer as regulation_option  ',
'      FROM T_MS_SUCHERGEBNISS ms',
'      LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'      WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'      AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'      AND tv.vorschrift_nummer IS NOT NULL',
'  ) ORDER BY regulation_option',
'',
'',
'  sourece ',
'',
'  SELECT DISTINCT ms.vorschriftnummer',
'FROM T_MS_SUCHERGEBNISS ms',
'WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'AND ROWNUM = 1',
'',
'-- lov 13 aug',
'SELECT DISTINCT regulation_option as d, regulation_option as r',
'FROM (',
'    -- Get the main regulation number',
'    SELECT DISTINCT ms.vorschriftnummer as regulation_option, 1 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'    AND ms.vorschriftnummer IS NOT NULL',
'    ',
'    UNION',
'    ',
'    -- Get all alternative regulation numbers for this main regulation',
'    SELECT DISTINCT tv.vorschrift_nummer as regulation_option, 2 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'    AND tv.vorschrift_nummer IS NOT NULL',
'    AND ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL',
')',
'ORDER BY regulation_option'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964149566423466108)
,p_name=>'P466_ET_VORSCHLAG_VORSCHRIFT_2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_use_cache_before_default=>'NO'
,p_prompt=>'ET Vorschlag Vorschrift'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN tv.vorschrift_nummer IS NOT NULL THEN ',
'            ms.vorschriftnummer || '', '' || tv.vorschrift_nummer',
'        ELSE ',
'            ms.vorschriftnummer',
'    END as regulation_numbers',
'FROM T_MS_SUCHERGEBNISS ms',
'LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'AND (',
'    CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END',
') = :P466_SINGLE_REG_ID',
'AND ROWNUM = 1'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>':P466_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964149144553466107)
,p_name=>'P466_FB_KOMMENTAR'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_use_cache_before_default=>'NO'
,p_prompt=>'FB Kommentar'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT FB_KOMMENTAR',
'FROM T_MS_BEWERTUNG',
'WHERE SUCHEID = :P466_SEARCH_SELECTION',
'AND MEILENSTEIN = :P466_MILESTONE_SELECTION',
'AND CARD_NUMBER = :P466_CARD_NUM',
'AND VORSCHRIFTID = :P466_REGULATION_SELECTOR',
'-- AND BENUTZERID = :G_BENUTZERID;',
'AND (BENUTZERID = :G_BENUTZERID ',
'     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                WHERE brr.benutzerid = :G_BENUTZERID ',
'                AND brr.rolleid = 1001)',
'    );'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>':P466_BEWERTUNG_ANSICHT IN (''ET'', ''FB'')'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964148765403466107)
,p_name=>'P466_FB_VERWENDUNG'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_use_cache_before_default=>'NO'
,p_prompt=>'FB Verwendung'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NVL(FB_VERWENDUNG, ''nicht bewertet'')',
'FROM T_MS_BEWERTUNG',
'WHERE SUCHEID = :P466_SEARCH_SELECTION',
'AND MEILENSTEIN = :P466_MILESTONE_SELECTION',
'AND CARD_NUMBER = :P466_CARD_NUM',
'AND VORSCHRIFTID = :P466_REGULATION_SELECTOR',
'-- AND BENUTZERID = :G_BENUTZERID;',
'AND (BENUTZERID = :G_BENUTZERID ',
'     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                WHERE brr.benutzerid = :G_BENUTZERID ',
'                AND brr.rolleid = 1001)',
'    );'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT d, r FROM (',
'    SELECT ''nicht bewertet'' as d, ''nicht bewertet'' as r FROM dual',
'    UNION ALL',
'    SELECT ''ja'' as d, ''ja'' as r FROM dual  ',
'    UNION ALL',
'    SELECT ''nein'' as d, ''nein'' as r FROM dual',
'  ) ORDER BY CASE WHEN r = ''nicht bewertet'' THEN 1 WHEN r = ''ja'' THEN 2 ELSE 3 END'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Bitte ausw\00E4hlen --')
,p_cHeight=>1
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>':P466_BEWERTUNG_ANSICHT IN (''ET'', ''FB'')'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964148317254466107)
,p_name=>'P466_FB_VORSCHLAG_VORSCHRIFT'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_prompt=>'FB Vorschlag Vorschrift'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT regulation_option as d, regulation_option as r',
'FROM (',
'    -- Get the main regulation number',
'    SELECT DISTINCT ',
'        CASE ',
'            WHEN tp_main.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND tv_main.DOKUMENTENDATUM IS NOT NULL ',
'            THEN ms.vorschriftnummer || ''_'' || TO_CHAR(tv_main.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'            ELSE ms.vorschriftnummer ',
'        END as regulation_option, ',
'        1 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN t_vorschrift tv_main ON tv_main.vorschriftid = ms.vorschriftid',
'    LEFT JOIN t_publisher tp_main ON tv_main.publisherid = tp_main.publisherid',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'    AND ms.vorschriftnummer IS NOT NULL',
'    ',
'    UNION',
'    ',
'    -- Get all alternative regulation numbers for this main regulation group',
'    SELECT DISTINCT ',
'        CASE ',
'            WHEN tp_alt.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND tv.DOKUMENTENDATUM IS NOT NULL ',
'            THEN tv.vorschrift_nummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'            ELSE tv.vorschrift_nummer ',
'        END as regulation_option, ',
'        2 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'    LEFT JOIN t_publisher tp_alt ON tv.publisherid = tp_alt.publisherid',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'    AND tv.vorschrift_nummer IS NOT NULL',
'    AND ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL',
')',
'ORDER BY regulation_option;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Vorschrift ausw\00E4hlen --')
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P466_BEWERTUNG_ANSICHT IN (''ET'', ''FB'')',
'',
'',
'',
'SELECT DISTINCT regulation_option as d, regulation_option as r',
'  FROM (',
'      SELECT ms.vorschriftnummer as regulation_option',
'      FROM T_MS_SUCHERGEBNISS ms',
'      WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'      AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'      UNION',
'      SELECT tv.vorschrift_nummer as regulation_option  ',
'      FROM T_MS_SUCHERGEBNISS ms',
'      LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'      WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'      AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'      AND tv.vorschrift_nummer IS NOT NULL',
'  ) ORDER BY regulation_option',
'',
'',
'  soruce ',
'',
'  SELECT FB_VORSCHLAG_VORSCHRIFT',
'FROM T_MS_BEWERTUNG',
'WHERE SUCHEID = :P466_SEARCH_SELECTION',
'AND MEILENSTEIN = :P466_MILESTONE_SELECTION',
'AND CARD_NUMBER = :P466_CARD_NUM',
'AND VORSCHRIFTID = :P466_REGULATION_SELECTOR',
'AND BENUTZERID = :G_BENUTZERID;',
'',
'',
' --- 13 aug     ',
'',
'',
' SELECT DISTINCT regulation_option as d, regulation_option as r',
'FROM (',
'    -- Get the main regulation number',
'    SELECT DISTINCT ms.vorschriftnummer as regulation_option, 1 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'    AND ms.vorschriftnummer IS NOT NULL',
'    ',
'    UNION',
'    ',
'    -- Get all alternative regulation numbers for this main regulation',
'    SELECT DISTINCT tv.vorschrift_nummer as regulation_option, 2 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'    AND tv.vorschrift_nummer IS NOT NULL',
'    AND ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL',
')',
'ORDER BY regulation_option'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964147956639466106)
,p_name=>'P466_FB_VORSCHLAG_VORSCHRIFT_2'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_use_cache_before_default=>'NO'
,p_prompt=>'FB Vorschlag Vorschrift'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN tv.vorschrift_nummer IS NOT NULL THEN ',
'            ms.vorschriftnummer || '', '' || tv.vorschrift_nummer',
'        ELSE ',
'            ms.vorschriftnummer',
'    END as regulation_numbers',
'FROM T_MS_SUCHERGEBNISS ms',
'LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'AND (',
'    CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END',
') = :P466_SINGLE_REG_ID',
'AND ROWNUM = 1'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>':P466_BEWERTUNG_ANSICHT IN (''ET'', ''FB'')'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964147606989466106)
,p_name=>'P466_SEARCH_SELECTION'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964147203928466106)
,p_name=>'P466_MILESTONE_SELECTION'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964146733120466105)
,p_name=>'P466_CARD_NUM'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964146381087466105)
,p_name=>'P466_LOAD_FROM'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964145939606466105)
,p_name=>'P466_RECORD_COUNT'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CASE ',
'    WHEN :P466_SELECTED_ROWS IS NULL THEN ''No records selected''',
'    ELSE ''Selected '' || COUNT(*) || '' record(s): '' || :P466_SELECTED_ROWS',
'END',
'FROM TABLE(apex_string.split(:P466_SELECTED_ROWS, '':''))',
'WHERE TRIM(column_value) IS NOT NULL'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964145522206466104)
,p_name=>'P466_SINGLE_REG_ID'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964145206501466104)
,p_name=>'P466_SELECTED_ROWS_1'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_use_cache_before_default=>'NO'
,p_source=>':&P466_LOAD_FROM.'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(951939588128316320)
,p_name=>'P466_ET_VORSCHLAG_VORSCHRIFT_MULTIPLE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_prompt=>'ET Vorschlag Vorschrift'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT regulation_option as d, regulation_option as r',
'FROM (',
'    -- Get the main regulation number',
'    SELECT DISTINCT ',
'        CASE ',
'            WHEN tp_main.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND tv_main.DOKUMENTENDATUM IS NOT NULL ',
'            THEN ms.vorschriftnummer || ''_'' || TO_CHAR(tv_main.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'            ELSE ms.vorschriftnummer ',
'        END as regulation_option, ',
'        1 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN t_vorschrift tv_main ON tv_main.vorschriftid = ms.vorschriftid',
'    LEFT JOIN t_publisher tp_main ON tv_main.publisherid = tp_main.publisherid',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'    AND ms.vorschriftnummer IS NOT NULL',
'    ',
'    UNION',
'    ',
'    -- Get all alternative regulation numbers for this main regulation group',
'    SELECT DISTINCT ',
'        CASE ',
'            WHEN tp_alt.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND tv.DOKUMENTENDATUM IS NOT NULL ',
'            THEN tv.vorschrift_nummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'            ELSE tv.vorschrift_nummer ',
'        END as regulation_option, ',
'        2 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'    LEFT JOIN t_publisher tp_alt ON tv.publisherid = tp_alt.publisherid',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'    AND tv.vorschrift_nummer IS NOT NULL',
'    AND ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL',
')',
'ORDER BY regulation_option;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Vorschrift ausw\00E4hlen --')
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P466_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')',
'',
'',
'SELECT DISTINCT regulation_option as d, regulation_option as r',
'  FROM (',
'      SELECT ms.vorschriftnummer as regulation_option',
'      FROM T_MS_SUCHERGEBNISS ms',
'      WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'      AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'      UNION',
'      SELECT tv.vorschrift_nummer as regulation_option  ',
'      FROM T_MS_SUCHERGEBNISS ms',
'      LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'      WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'      AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'      AND tv.vorschrift_nummer IS NOT NULL',
'  ) ORDER BY regulation_option',
'',
'',
'  sourece ',
'',
'  SELECT DISTINCT ms.vorschriftnummer',
'FROM T_MS_SUCHERGEBNISS ms',
'WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'AND ROWNUM = 1',
'',
'-- lov 13 aug',
'SELECT DISTINCT regulation_option as d, regulation_option as r',
'FROM (',
'    -- Get the main regulation number',
'    SELECT DISTINCT ms.vorschriftnummer as regulation_option, 1 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'    AND ms.vorschriftnummer IS NOT NULL',
'    ',
'    UNION',
'    ',
'    -- Get all alternative regulation numbers for this main regulation',
'    SELECT DISTINCT tv.vorschrift_nummer as regulation_option, 2 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'    AND tv.vorschrift_nummer IS NOT NULL',
'    AND ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL',
')',
'ORDER BY regulation_option'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(923435993424643730)
,p_name=>'P466_ET_VORSCHLAG_VORSCHRIFT_15JANWITHOTUSUCCS'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_prompt=>'ET Vorschlag Vorschrift'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT regulation_option as d, regulation_option as r',
'FROM (',
'    -- Get the main regulation number',
'    SELECT DISTINCT ',
'        CASE ',
'            WHEN tp_main.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND tv_main.DOKUMENTENDATUM IS NOT NULL ',
'            THEN ms.vorschriftnummer || ''_'' || TO_CHAR(tv_main.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'            ELSE ms.vorschriftnummer ',
'        END as regulation_option, ',
'        1 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN t_vorschrift tv_main ON tv_main.vorschriftid = ms.vorschriftid',
'    LEFT JOIN t_publisher tp_main ON tv_main.publisherid = tp_main.publisherid',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'    AND ms.vorschriftnummer IS NOT NULL',
'    ',
'    UNION',
'    ',
'    -- Get all alternative regulation numbers',
'    SELECT DISTINCT ',
'        CASE ',
'            WHEN tp_alt.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND tv.DOKUMENTENDATUM IS NOT NULL ',
'            THEN tv.vorschrift_nummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'            ELSE tv.vorschrift_nummer ',
'        END as regulation_option, ',
'        2 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'    LEFT JOIN t_publisher tp_alt ON tv.publisherid = tp_alt.publisherid',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'    AND tv.vorschrift_nummer IS NOT NULL',
'    AND ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL',
')',
'ORDER BY regulation_option;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Vorschrift ausw\00E4hlen --')
,p_cHeight=>1
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P466_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')',
'',
'',
'SELECT DISTINCT regulation_option as d, regulation_option as r',
'  FROM (',
'      SELECT ms.vorschriftnummer as regulation_option',
'      FROM T_MS_SUCHERGEBNISS ms',
'      WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'      AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'      UNION',
'      SELECT tv.vorschrift_nummer as regulation_option  ',
'      FROM T_MS_SUCHERGEBNISS ms',
'      LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'      WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'      AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'      AND tv.vorschrift_nummer IS NOT NULL',
'  ) ORDER BY regulation_option',
'',
'',
'  sourece ',
'',
'  SELECT DISTINCT ms.vorschriftnummer',
'FROM T_MS_SUCHERGEBNISS ms',
'WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'AND ROWNUM = 1',
'',
'-- lov 13 aug',
'SELECT DISTINCT regulation_option as d, regulation_option as r',
'FROM (',
'    -- Get the main regulation number',
'    SELECT DISTINCT ms.vorschriftnummer as regulation_option, 1 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'    AND ms.vorschriftnummer IS NOT NULL',
'    ',
'    UNION',
'    ',
'    -- Get all alternative regulation numbers for this main regulation',
'    SELECT DISTINCT tv.vorschrift_nummer as regulation_option, 2 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'    AND tv.vorschrift_nummer IS NOT NULL',
'    AND ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL',
')',
'ORDER BY regulation_option'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(923435729248643728)
,p_name=>'P466_ET_VORSCHLAG_VORSCHRIFT_WERNERNOTWANT'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(8803481388107153450)
,p_prompt=>'ET Vorschlag Vorschrift'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT regulation_option as d, regulation_option as r',
'FROM (',
'    -- ============================================',
'    -- 1. Get the MAIN regulation number',
'    -- ============================================',
'    SELECT DISTINCT ',
'        CASE ',
'            WHEN tp_main.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND tv_main.DOKUMENTENDATUM IS NOT NULL ',
'            THEN ms.vorschriftnummer || ''_'' || TO_CHAR(tv_main.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'            ELSE ms.vorschriftnummer ',
'        END as regulation_option',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN t_vorschrift tv_main ON tv_main.vorschriftid = ms.vorschriftid',
'    LEFT JOIN t_publisher tp_main ON tv_main.publisherid = tp_main.publisherid',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'    AND ms.vorschriftnummer IS NOT NULL',
'    ',
'    UNION',
'    ',
'    -- ============================================',
'    -- 2. Get all ALTERNATIVE regulation numbers',
'    -- ============================================',
'    SELECT DISTINCT ',
'        CASE ',
'            WHEN tp_alt.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND tv.DOKUMENTENDATUM IS NOT NULL ',
'            THEN tv.vorschrift_nummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'            ELSE tv.vorschrift_nummer ',
'        END as regulation_option',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'    LEFT JOIN t_publisher tp_alt ON tv.publisherid = tp_alt.publisherid',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'    AND tv.vorschrift_nummer IS NOT NULL',
'    AND ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL',
'    ',
'    UNION',
'    ',
'    -- ============================================',
'    -- 3. Get ALL SUCCESSORS of ALL regulations (RECURSIVE)',
'    -- ============================================',
'    SELECT DISTINCT',
'        CASE ',
'            WHEN tp_succ.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND tv_succ.DOKUMENTENDATUM IS NOT NULL ',
'            THEN tv_succ.vorschrift_nummer || ''_'' || TO_CHAR(tv_succ.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'            ELSE tv_succ.vorschrift_nummer ',
'        END as regulation_option',
'    FROM t_vorschrift_ref_vorschrift vrv',
'    INNER JOIN t_vorschrift tv_succ ON tv_succ.vorschriftid = vrv.nachfolger_vorschriftid',
'    LEFT JOIN t_publisher tp_succ ON tv_succ.publisherid = tp_succ.publisherid',
'    WHERE vrv.beziehung_art = 10',
'    START WITH vrv.vorgaenger_vorschriftid IN (',
'        -- Get main regulation ID',
'        SELECT ms.vorschriftid',
'        FROM T_MS_SUCHERGEBNISS ms',
'        WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'        AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'        AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'        ',
'        UNION',
'        ',
'        -- Get all alternative regulation IDs',
'        SELECT ms.alternative_vorschriftid',
'        FROM T_MS_SUCHERGEBNISS ms',
'        WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'        AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'        AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'        AND ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL',
'    )',
'    CONNECT BY NOCYCLE PRIOR vrv.nachfolger_vorschriftid = vrv.vorgaenger_vorschriftid',
'        AND vrv.beziehung_art = 10',
'        AND LEVEL <= 10',
');'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Vorschrift ausw\00E4hlen --')
,p_cHeight=>1
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P466_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')',
'',
'',
'SELECT DISTINCT regulation_option as d, regulation_option as r',
'  FROM (',
'      SELECT ms.vorschriftnummer as regulation_option',
'      FROM T_MS_SUCHERGEBNISS ms',
'      WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'      AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'      UNION',
'      SELECT tv.vorschrift_nummer as regulation_option  ',
'      FROM T_MS_SUCHERGEBNISS ms',
'      LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'      WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'      AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'      AND tv.vorschrift_nummer IS NOT NULL',
'  ) ORDER BY regulation_option',
'',
'',
'  sourece ',
'',
'  SELECT DISTINCT ms.vorschriftnummer',
'FROM T_MS_SUCHERGEBNISS ms',
'WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'AND ROWNUM = 1',
'',
'-- lov 13 aug',
'SELECT DISTINCT regulation_option as d, regulation_option as r',
'FROM (',
'    -- Get the main regulation number',
'    SELECT DISTINCT ms.vorschriftnummer as regulation_option, 1 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'    AND ms.vorschriftnummer IS NOT NULL',
'    ',
'    UNION',
'    ',
'    -- Get all alternative regulation numbers for this main regulation',
'    SELECT DISTINCT tv.vorschrift_nummer as regulation_option, 2 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'    WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID',
'    AND tv.vorschrift_nummer IS NOT NULL',
'    AND ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL',
')',
'ORDER BY regulation_option'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964140026407466098)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(964144491633466103)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964139563148466097)
,p_event_id=>wwv_flow_imp.id(964140026407466098)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964139196701466097)
,p_name=>'Show / Hide Columns'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P466_BEWERTUNG_ANSICHT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964138626100466097)
,p_event_id=>wwv_flow_imp.id(964139196701466097)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P466_BEWERTUNG_ANSICHT'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964138156956466096)
,p_event_id=>wwv_flow_imp.id(964139196701466097)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Store switch value before refresh',
'var switchValue = $v(''P461_BEWERTUNG_ANSICHT'');',
'sessionStorage.setItem(''P461_SWITCH_VALUE'', switchValue);'))
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964137624235466096)
,p_event_id=>wwv_flow_imp.id(964139196701466097)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8803481388107153450)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964137291131466096)
,p_name=>'New'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P466_REGULATION_SELECTOR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964136811602466095)
,p_event_id=>wwv_flow_imp.id(964137291131466096)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964136378619466095)
,p_name=>'Handle ET Verwendung Logic'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P466_ET_VERWENDUNG'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.triggeringElement.value === ''nein'''
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964135838775466095)
,p_event_id=>wwv_flow_imp.id(964136378619466095)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P466_ET_VORSCHLAG_VORSCHRIFT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964135318585466095)
,p_event_id=>wwv_flow_imp.id(964136378619466095)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P466_ET_VORSCHLAG_VORSCHRIFT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964142910167466102)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Single Update Bewertungen speichern'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Use the selected regulation ID instead of P466_SINGLE_REG_ID',
'    MERGE INTO T_MS_BEWERTUNG bew',
'    USING (',
'        SELECT ',
'            :P466_SEARCH_SELECTION as sucheid,',
'            :P466_MILESTONE_SELECTION as meilenstein, ',
'            :P466_CARD_NUM as card_number,',
'            :P466_REGULATION_SELECTOR as vorschriftid,  -- Changed to use selector',
'            :G_BENUTZERID as benutzerid',
'        FROM dual',
'    ) src ON (',
'        bew.SUCHEID = src.sucheid ',
'        AND bew.MEILENSTEIN = src.meilenstein',
'        AND bew.CARD_NUMBER = src.card_number',
'        AND bew.VORSCHRIFTID = src.vorschriftid',
'        AND bew.BENUTZERID = src.benutzerid',
'    )',
'    WHEN MATCHED THEN',
'        UPDATE SET ',
'            ET_VERWENDUNG = NVL(:P466_ET_VERWENDUNG, ''nicht bewertet''),',
'            ET_VORSCHLAG_VORSCHRIFT = :P466_ET_VORSCHLAG_VORSCHRIFT,',
'            ET_KOMMENTAR = :P466_ET_KOMMENTAR,',
'            -- FB_VERWENDUNG = NVL(:P466_FB_VERWENDUNG, ''nicht bewertet''),',
'            -- FB_VORSCHLAG_VORSCHRIFT = :P466_FB_VORSCHLAG_VORSCHRIFT,',
'            -- FB_KOMMENTAR = :P466_FB_KOMMENTAR,',
'            LETZTE_AENDERUNG_DATUM = SYSDATE,',
'            LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'    WHEN NOT MATCHED THEN',
'        INSERT (',
'            SUCHEID, MEILENSTEIN, CARD_NUMBER, VORSCHRIFTID, BENUTZERID,',
'            ET_VERWENDUNG, ET_VORSCHLAG_VORSCHRIFT, ET_KOMMENTAR,',
'            -- FB_VERWENDUNG, FB_VORSCHLAG_VORSCHRIFT, FB_KOMMENTAR,',
'            -- ERSTELLUNG_DATUM, ',
'            LETZTE_AENDERUNG_DATUM, LETZTE_AENDERUNG_BENUTZERID',
'        ) VALUES (',
'            src.sucheid, src.meilenstein, src.card_number, src.vorschriftid, src.benutzerid,',
'            NVL(:P466_ET_VERWENDUNG, ''nicht bewertet''),',
'            :P466_ET_VORSCHLAG_VORSCHRIFT,',
'            :P466_ET_KOMMENTAR,',
'            -- NVL(:P466_FB_VERWENDUNG, ''nicht bewertet''),',
'            -- :P466_FB_VORSCHLAG_VORSCHRIFT,',
'            -- :P466_FB_KOMMENTAR,',
'            -- SYSDATE,',
'             SYSDATE, :G_BENUTZERID',
'        );',
'    ',
'    COMMIT;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(964143634236466103)
,p_internal_uid=>2708069405731922133
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964141625278466101)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Bulk Update Bewertungen speichern_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_selected_rows VARCHAR2(4000) := :P466_SELECTED_ROWS;',
'    l_search_id NUMBER := :P466_SEARCH_SELECTION;',
'    l_milestone NUMBER := :P466_MILESTONE_SELECTION;',
'    l_card_number NUMBER := :P466_CARD_NUM;',
'    l_count NUMBER := 0;',
'BEGIN',
'    -- Process each selected row (SPECIFIC_REG_ID values)',
'    FOR rec IN (',
'        SELECT TO_NUMBER(TRIM(column_value)) as specific_reg_id',
'        FROM TABLE(apex_string.split(l_selected_rows, '':''))',
'        WHERE TRIM(column_value) IS NOT NULL',
'    ) LOOP',
'        ',
'        -- Update or insert evaluation for each regulation',
'        MERGE INTO T_MS_BEWERTUNG bew',
'        USING (',
'            SELECT ',
'                l_search_id as sucheid,',
'                l_milestone as meilenstein, ',
'                l_card_number as card_number,',
'                rec.specific_reg_id as vorschriftid,',
'                :G_BENUTZERID as benutzerid',
'            FROM dual',
'        ) src ON (',
'            bew.SUCHEID = src.sucheid ',
'            AND bew.MEILENSTEIN = src.meilenstein',
'            AND bew.CARD_NUMBER = src.card_number',
'            AND bew.VORSCHRIFTID = src.vorschriftid',
'            AND bew.BENUTZERID = src.benutzerid',
'        )',
'        WHEN MATCHED THEN',
'            UPDATE SET ',
'                ET_VERWENDUNG = CASE WHEN :P466_ET_VERWENDUNG IS NOT NULL THEN :P466_ET_VERWENDUNG ELSE bew.ET_VERWENDUNG END,',
'                ET_VORSCHLAG_VORSCHRIFT = CASE WHEN :P466_ET_VORSCHLAG_VORSCHRIFT IS NOT NULL THEN :P466_ET_VORSCHLAG_VORSCHRIFT ELSE bew.ET_VORSCHLAG_VORSCHRIFT END,',
'                ET_KOMMENTAR = CASE WHEN :P466_ET_KOMMENTAR IS NOT NULL THEN :P466_ET_KOMMENTAR ELSE bew.ET_KOMMENTAR END,',
'                FB_VERWENDUNG = CASE WHEN :P466_FB_VERWENDUNG IS NOT NULL THEN :P466_FB_VERWENDUNG ELSE bew.FB_VERWENDUNG END,',
'                FB_VORSCHLAG_VORSCHRIFT = CASE WHEN :P466_FB_VORSCHLAG_VORSCHRIFT IS NOT NULL THEN :P466_FB_VORSCHLAG_VORSCHRIFT ELSE bew.FB_VORSCHLAG_VORSCHRIFT END,',
'                FB_KOMMENTAR = CASE WHEN :P466_FB_KOMMENTAR IS NOT NULL THEN :P466_FB_KOMMENTAR ELSE bew.FB_KOMMENTAR END,',
'                LETZTE_AENDERUNG_DATUM = SYSDATE,',
'                LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'        WHEN NOT MATCHED THEN',
'            INSERT (',
'                SUCHEID, MEILENSTEIN, CARD_NUMBER, VORSCHRIFTID, BENUTZERID,',
'                ET_VERWENDUNG, ET_VORSCHLAG_VORSCHRIFT, ET_KOMMENTAR,',
'                FB_VERWENDUNG, FB_VORSCHLAG_VORSCHRIFT, FB_KOMMENTAR,',
'                ERSTELLUNG_DATUM, LETZTE_AENDERUNG_DATUM, LETZTE_AENDERUNG_BENUTZERID',
'            ) VALUES (',
'                src.sucheid, src.meilenstein, src.card_number, src.vorschriftid, src.benutzerid,',
'                NVL(:P466_ET_VERWENDUNG, ''nicht bewertet''),',
'                :P466_ET_VORSCHLAG_VORSCHRIFT,',
'                :P466_ET_KOMMENTAR,',
'                NVL(:P466_FB_VERWENDUNG, ''nicht bewertet''),',
'                :P466_FB_VORSCHLAG_VORSCHRIFT,',
'                :P466_FB_KOMMENTAR,',
'                SYSDATE, SYSDATE, :G_BENUTZERID',
'            );',
'            ',
'        l_count := l_count + 1;',
'    END LOOP;',
'    ',
'',
'    ',
'    -- Success message',
'    -- apex_application.g_print_success_message := l_count || '' Bewertungen erfolgreich aktualisiert'';',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_process_success_message=>'fdxfdgfdg'
,p_internal_uid=>2708070690620922134
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964142448330466101)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(964143634236466103)
,p_internal_uid=>2708069867568922134
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964140891572466099)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Page Data Button Link Icon'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_selected_reg_id NUMBER;',
'    l_coming_from_p461 BOOLEAN := FALSE;',
'BEGIN',
'    apex_debug.message(''=== PAGE 466 BEFORE_HEADER START ==='');',
'    apex_debug.message(''P466_REGULATION_SELECTOR: '' || :P466_REGULATION_SELECTOR);',
'    apex_debug.message(''P466_SINGLE_REG_ID: '' || :P466_SINGLE_REG_ID);',
'    apex_debug.message(''P466_SELECTED_ROWS: '' || :P466_SELECTED_ROWS);',
'    ',
'    -- Check if coming from page 461 with selected rows',
'    IF :P466_SELECTED_ROWS IS NOT NULL AND TRIM(:P466_SELECTED_ROWS) != '''' THEN',
'        l_coming_from_p461 := TRUE;',
'        apex_debug.message(''Coming from P461 with selected rows: '' || :P466_SELECTED_ROWS);',
'        ',
'        -- For multiple selections, clear form for bulk edit',
'        -- For single selection, load existing data',
'        DECLARE',
'            l_colon_count NUMBER;',
'            l_first_reg_id NUMBER;',
'        BEGIN',
'            -- Count how many regulations selected',
'            l_colon_count := LENGTH(:P466_SELECTED_ROWS) - LENGTH(REPLACE(:P466_SELECTED_ROWS, '':'', ''''));',
'            ',
'            IF l_colon_count = 0 THEN',
'                -- Single selection - load existing data',
'                l_first_reg_id := TO_NUMBER(TRIM(:P466_SELECTED_ROWS));',
'                l_selected_reg_id := l_first_reg_id;',
'                :P466_REGULATION_SELECTOR := l_selected_reg_id;',
'                ',
'                apex_debug.message(''Single selection from P461: '' || l_selected_reg_id);',
'            ELSE',
'                -- Multiple selections - clear form for bulk edit',
'                apex_debug.message(''Multiple selections from P461 - clearing form for bulk edit'');',
'                :P466_REGULATION_SELECTOR := NULL;',
'                :P466_ET_VERWENDUNG := NULL;',
'                :P466_FB_VERWENDUNG := NULL;',
'                :P466_ET_VORSCHLAG_VORSCHRIFT := NULL;',
'                :P466_ET_KOMMENTAR := NULL;',
'                :P466_FB_VORSCHLAG_VORSCHRIFT := NULL;',
'                :P466_FB_KOMMENTAR := NULL;',
'                RETURN; -- Exit early for bulk edit',
'            END IF;',
'        END;',
'    ELSE',
'        -- Not coming from P461 - handle normal page flow',
'        l_coming_from_p461 := FALSE;',
'        ',
'        -- Determine which regulation ID to use',
'        IF :P466_REGULATION_SELECTOR IS NOT NULL THEN',
'            l_selected_reg_id := :P466_REGULATION_SELECTOR;',
'            apex_debug.message(''Using existing regulation selector: '' || l_selected_reg_id);',
'        ELSE',
'            -- First time loading - set default to first regulation',
'            BEGIN',
'                SELECT MIN(',
'                    CASE ',
'                        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'                        ELSE ms.VORSCHRIFTID',
'                    END',
'                )',
'                INTO l_selected_reg_id',
'                FROM T_MS_SUCHERGEBNISS ms',
'                WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'                AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'                AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID;',
'                ',
'                -- Set the selector to this default value',
'                :P466_REGULATION_SELECTOR := l_selected_reg_id;',
'                apex_debug.message(''Set default regulation: '' || l_selected_reg_id);',
'                ',
'            EXCEPTION',
'                WHEN NO_DATA_FOUND THEN',
'                    l_selected_reg_id := :P466_SINGLE_REG_ID;',
'                    :P466_REGULATION_SELECTOR := l_selected_reg_id;',
'                    apex_debug.message(''No regulations found, using single reg ID: '' || l_selected_reg_id);',
'            END;',
'        END IF;',
'    END IF;',
'    ',
'    -- Load evaluation data for the selected regulation',
'    IF l_selected_reg_id IS NOT NULL THEN',
'        BEGIN',
'            SELECT ',
'                NVL(ET_VERWENDUNG, ''nicht bewertet''),',
'                ET_VORSCHLAG_VORSCHRIFT,',
'                ET_KOMMENTAR,',
'                NVL(FB_VERWENDUNG, ''nicht bewertet''),',
'                FB_VORSCHLAG_VORSCHRIFT,',
'                FB_KOMMENTAR',
'            INTO ',
'                :P466_ET_VERWENDUNG,',
'                :P466_ET_VORSCHLAG_VORSCHRIFT,',
'                :P466_ET_KOMMENTAR,',
'                :P466_FB_VERWENDUNG,',
'                :P466_FB_VORSCHLAG_VORSCHRIFT,',
'                :P466_FB_KOMMENTAR',
'            FROM T_MS_BEWERTUNG',
'            WHERE SUCHEID = :P466_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P466_MILESTONE_SELECTION',
'            AND CARD_NUMBER = :P466_CARD_NUM',
'            AND VORSCHRIFTID = l_selected_reg_id',
'            -- AND BENUTZERID = :G_BENUTZERID;',
'            AND (BENUTZERID = :G_BENUTZERID',
'                 OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                            WHERE brr.benutzerid = :G_BENUTZERID ',
'                            AND brr.rolleid = 1001)',
'                );',
'            ',
'            apex_debug.message(''SUCCESS: Loaded data for regulation '' || l_selected_reg_id);',
'            apex_debug.message(''ET_VERWENDUNG: '' || :P466_ET_VERWENDUNG);',
'            apex_debug.message(''FB_VERWENDUNG: '' || :P466_FB_VERWENDUNG);',
'            ',
'        EXCEPTION',
'            WHEN NO_DATA_FOUND THEN',
'                -- No existing evaluation - set defaults',
'                :P466_ET_VERWENDUNG := ''nicht bewertet'';',
'                :P466_ET_VORSCHLAG_VORSCHRIFT := NULL;',
'                :P466_ET_KOMMENTAR := NULL;',
'                :P466_FB_VERWENDUNG := ''nicht bewertet'';',
'                :P466_FB_VORSCHLAG_VORSCHRIFT := NULL;',
'                :P466_FB_KOMMENTAR := NULL;',
'                ',
'                apex_debug.message(''NO_DATA_FOUND: Set defaults for regulation '' || l_selected_reg_id);',
'        END;',
'    ELSE',
'        apex_debug.message(''ERROR: No regulation ID available'');',
'        -- Set safe defaults',
'        :P466_ET_VERWENDUNG := ''nicht bewertet'';',
'        :P466_FB_VERWENDUNG := ''nicht bewertet'';',
'        :P466_ET_VORSCHLAG_VORSCHRIFT := NULL;',
'        :P466_ET_KOMMENTAR := NULL;',
'        :P466_FB_VORSCHLAG_VORSCHRIFT := NULL;',
'        :P466_FB_KOMMENTAR := NULL;',
'    END IF;',
'    ',
'    apex_debug.message(''=== END BEFORE_HEADER ==='');',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_debug.message(''ERROR in BEFORE_HEADER: '' || SQLERRM);',
'        -- Set safe defaults on error',
'        :P466_ET_VERWENDUNG := ''nicht bewertet'';',
'        :P466_FB_VERWENDUNG := ''nicht bewertet'';',
'        :P466_ET_VORSCHLAG_VORSCHRIFT := NULL;',
'        :P466_ET_KOMMENTAR := NULL;',
'        :P466_FB_VORSCHLAG_VORSCHRIFT := NULL;',
'        :P466_FB_KOMMENTAR := NULL;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2708071424326922136
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964140496093466098)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Page Data Button Link Icon_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'DECLARE',
'    l_selected_reg_id NUMBER;',
'BEGIN',
'    apex_debug.message(''=== PAGE 466 BEFORE_HEADER ==='');',
'    apex_debug.message(''P466_REGULATION_SELECTOR: '' || :P466_REGULATION_SELECTOR);',
'    apex_debug.message(''P466_SINGLE_REG_ID: '' || :P466_SINGLE_REG_ID);',
'    apex_debug.message(''P466_SEARCH_SELECTION: '' || :P466_SEARCH_SELECTION);',
'    apex_debug.message(''P466_MILESTONE_SELECTION: '' || :P466_MILESTONE_SELECTION);',
'    apex_debug.message(''P466_CARD_NUM: '' || :P466_CARD_NUM);',
'    ',
'    -- Determine which regulation ID to use',
'    IF :P466_REGULATION_SELECTOR IS NOT NULL THEN',
'        l_selected_reg_id := :P466_REGULATION_SELECTOR;',
'        apex_debug.message(''Using regulation selector: '' || l_selected_reg_id);',
'    ELSE',
'        -- First time loading - set default to first regulation',
'        BEGIN',
'            SELECT MIN(',
'                CASE ',
'                    WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'                    ELSE ms.VORSCHRIFTID',
'                END',
'            )',
'            INTO l_selected_reg_id',
'            FROM T_MS_SUCHERGEBNISS ms',
'            WHERE ms.sucheid = :P466_SEARCH_SELECTION ',
'            AND ms.meilenstein = :P466_MILESTONE_SELECTION',
'            AND ms.VORSCHRIFTID = :P466_SINGLE_REG_ID;',
'            ',
'            -- Set the selector to this default value',
'            :P466_REGULATION_SELECTOR := l_selected_reg_id;',
'            apex_debug.message(''Set default regulation: '' || l_selected_reg_id);',
'            ',
'        EXCEPTION',
'            WHEN NO_DATA_FOUND THEN',
'                l_selected_reg_id := :P466_SINGLE_REG_ID;',
'                :P466_REGULATION_SELECTOR := l_selected_reg_id;',
'                apex_debug.message(''No regulations found, using single reg ID: '' || l_selected_reg_id);',
'        END;',
'    END IF;',
'    ',
'    -- Load evaluation data for the selected regulation',
'    IF l_selected_reg_id IS NOT NULL THEN',
'        BEGIN',
'            SELECT ',
'                NVL(ET_VERWENDUNG, ''nicht bewertet''),',
'                ET_VORSCHLAG_VORSCHRIFT,',
'                ET_KOMMENTAR,',
'                NVL(FB_VERWENDUNG, ''nicht bewertet''),',
'                FB_VORSCHLAG_VORSCHRIFT,',
'                FB_KOMMENTAR',
'            INTO ',
'                :P466_ET_VERWENDUNG,',
'                :P466_ET_VORSCHLAG_VORSCHRIFT,',
'                :P466_ET_KOMMENTAR,',
'                :P466_FB_VERWENDUNG,',
'                :P466_FB_VORSCHLAG_VORSCHRIFT,',
'                :P466_FB_KOMMENTAR',
'            FROM T_MS_BEWERTUNG',
'            WHERE SUCHEID = :P466_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P466_MILESTONE_SELECTION',
'            AND CARD_NUMBER = :P466_CARD_NUM',
'            AND VORSCHRIFTID = l_selected_reg_id',
'            AND BENUTZERID = :G_BENUTZERID;',
'            ',
'            apex_debug.message(''SUCCESS: Loaded data for regulation '' || l_selected_reg_id);',
'            apex_debug.message(''ET_VERWENDUNG: '' || :P466_ET_VERWENDUNG);',
'            apex_debug.message(''FB_VERWENDUNG: '' || :P466_FB_VERWENDUNG);',
'            ',
'        EXCEPTION',
'            WHEN NO_DATA_FOUND THEN',
'                -- No existing evaluation - set defaults',
'                :P466_ET_VERWENDUNG := ''nicht bewertet'';',
'                :P466_ET_VORSCHLAG_VORSCHRIFT := NULL;',
'                :P466_ET_KOMMENTAR := NULL;',
'                :P466_FB_VERWENDUNG := ''nicht bewertet'';',
'                :P466_FB_VORSCHLAG_VORSCHRIFT := NULL;',
'                :P466_FB_KOMMENTAR := NULL;',
'                ',
'                apex_debug.message(''NO_DATA_FOUND: Set defaults for regulation '' || l_selected_reg_id);',
'        END;',
'    ELSE',
'        apex_debug.message(''ERROR: No regulation ID available'');',
'        -- Set safe defaults',
'        :P466_ET_VERWENDUNG := ''nicht bewertet'';',
'        :P466_FB_VERWENDUNG := ''nicht bewertet'';',
'        :P466_ET_VORSCHLAG_VORSCHRIFT := NULL;',
'        :P466_ET_KOMMENTAR := NULL;',
'        :P466_FB_VORSCHLAG_VORSCHRIFT := NULL;',
'        :P466_FB_KOMMENTAR := NULL;',
'    END IF;',
'    ',
'    apex_debug.message(''=== END BEFORE_HEADER ==='');',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_debug.message(''ERROR in BEFORE_HEADER: '' || SQLERRM);',
'        -- Set safe defaults on error',
'        :P466_ET_VERWENDUNG := ''nicht bewertet'';',
'        :P466_FB_VERWENDUNG := ''nicht bewertet'';',
'        :P466_ET_VORSCHLAG_VORSCHRIFT := NULL;',
'        :P466_ET_KOMMENTAR := NULL;',
'        :P466_FB_VORSCHLAG_VORSCHRIFT := NULL;',
'        :P466_FB_KOMMENTAR := NULL;',
'END;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2708071819805922137
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964142060630466101)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Page Data MehrfachBearbeitung Button'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Set the page items from URL parameters',
'    :P466_CARD_NUM := :P466_CARD_NUM;',
'    :P466_SEARCH_SELECTION := :P466_SEARCH_SELECTION;',
'    :P466_MILESTONE_SELECTION := :P466_MILESTONE_SELECTION;',
'    :P466_SELECTED_ROWS := :P466_SELECTED_ROWS;',
'   ',
'    -- Debug',
'    -- apex_debug.message(''P466_SELECTED_ROWS: '' || :P466_SELECTED_ROWS);',
'    -- apex_debug.message(''P466_SEARCH_SELECTION: '' || :P466_SEARCH_SELECTION);',
'    -- apex_debug.message(''P466_MILESTONE_SELECTION: '' || :P466_MILESTONE_SELECTION);',
'    -- apex_debug.message(''P466_CARD_NUM: '' || :P466_CARD_NUM);',
'    ',
'',
'    ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2708070255268922134
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964141293236466100)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Page Data_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    debug(''P466_LOAD_FROM value'', :P466_LOAD_FROM);',
'    ',
'    -- Manually resolve the selected rows since automatic resolution failed',
'    IF :P466_LOAD_FROM = ''P461_SELECTED_ROWS'' THEN',
'        :P466_SELECTED_ROWS := apex_util.get_session_state(''P461_SELECTED_ROWS'');',
'        debug(''Manually set P466_SELECTED_ROWS'', :P466_SELECTED_ROWS);',
'    END IF;',
'    ',
'    debug(''P466_SEARCH_SELECTION'', :P466_SEARCH_SELECTION);',
'    debug(''P466_MILESTONE_SELECTION'', :P466_MILESTONE_SELECTION);',
'    debug(''P466_CARD_NUM'', :P466_CARD_NUM);',
'    debug(''G_BENUTZERID'', :G_BENUTZERID);',
'    ',
'    -- Check if we have selected rows',
'    IF :P466_SELECTED_ROWS IS NOT NULL AND TRIM(:P466_SELECTED_ROWS) != '''' THEN',
'        debug(''Selected rows found'', :P466_SELECTED_ROWS);',
'        ',
'        -- Count selected records using simple approach',
'        DECLARE',
'            l_selected_count NUMBER;',
'            l_first_reg_id NUMBER;',
'            l_selected_string VARCHAR2(4000) := :P466_SELECTED_ROWS;',
'        BEGIN',
'            -- Simple count - if no colon, then 1 record, otherwise count colons + 1',
'            IF INSTR(l_selected_string, '':'') = 0 THEN',
'                l_selected_count := 1;',
'                l_first_reg_id := TO_NUMBER(TRIM(l_selected_string));',
'            ELSE',
'                -- Count colons and add 1',
'                l_selected_count := LENGTH(l_selected_string) - LENGTH(REPLACE(l_selected_string, '':'', '''')) + 1;',
'                -- Get first ID (before first colon)',
'                l_first_reg_id := TO_NUMBER(TRIM(SUBSTR(l_selected_string, 1, INSTR(l_selected_string, '':'') - 1)));',
'            END IF;',
'            ',
'            debug(''Selected count'', l_selected_count);',
'            debug(''First regulation ID'', l_first_reg_id);',
'            ',
'            -- If only one record, load its existing evaluation data',
'            IF l_selected_count = 1 THEN',
'                debug(''Loading data for single record'', l_first_reg_id);',
'                ',
'                -- Load existing evaluation data',
'                BEGIN',
'                    SELECT ',
'                        ET_VERWENDUNG,',
'                        NVL(ET_VORSCHLAG_VORSCHRIFT, ''-'') as ET_VORSCHLAG_VORSCHRIFT,',
'                        ET_KOMMENTAR,',
'                        FB_VERWENDUNG,',
'                        NVL(FB_VORSCHLAG_VORSCHRIFT, ''-'') as FB_VORSCHLAG_VORSCHRIFT,',
'                        FB_KOMMENTAR',
'                    INTO ',
'                        :P466_ET_VERWENDUNG,',
'                        :P466_ET_VORSCHLAG_VORSCHRIFT,',
'                        :P466_ET_KOMMENTAR,',
'                        :P466_FB_VERWENDUNG,',
'                        :P466_FB_VORSCHLAG_VORSCHRIFT,',
'                        :P466_FB_KOMMENTAR',
'                    FROM T_MS_BEWERTUNG',
'                    WHERE SUCHEID = :P466_SEARCH_SELECTION',
'                    AND MEILENSTEIN = :P466_MILESTONE_SELECTION',
'                    AND CARD_NUMBER = :P466_CARD_NUM',
'                    AND VORSCHRIFTID = l_first_reg_id',
'                    AND BENUTZERID = :G_BENUTZERID;',
'                    ',
'                    debug(''SUCCESS - ET_VERWENDUNG'', :P466_ET_VERWENDUNG);',
'                    debug(''SUCCESS - ET_KOMMENTAR'', :P466_ET_KOMMENTAR);',
'                    debug(''SUCCESS - FB_VERWENDUNG'', :P466_FB_VERWENDUNG);',
'                    debug(''SUCCESS - FB_KOMMENTAR'', :P466_FB_KOMMENTAR);',
'                    ',
'                EXCEPTION',
'                    WHEN NO_DATA_FOUND THEN',
'                        debug(''Data loading'', ''NO_DATA_FOUND'');',
'                    WHEN OTHERS THEN',
'                        debug(''Data loading ERROR'', SQLERRM);',
'                END;',
'            ELSE',
'                debug(''Multiple records selected'', ''Form will be empty for bulk entry'');',
'            END IF;',
'        END;',
'    ELSE',
'        debug(''No selected rows'', ''P466_SELECTED_ROWS is still null or empty'');',
'    END IF;',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        debug(''Before Header Process ERROR'', SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2708071022662922135
);
wwv_flow_imp.component_end;
end;
/
