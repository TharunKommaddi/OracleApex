prompt --application/pages/page_00365
begin
--   Manifest
--     PAGE: 00365
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>365
,p_name=>unistr('Datumsangaben aus FALKO \00FCbernehmen (veraltet)')
,p_alias=>unistr('DATUMSANGABEN-AUS-FALKO-\00DCBERNEHMEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Datumsangaben aus FALKO \00FCbernehmen')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1009280143200613589)
,p_plug_name=>'Suche'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1009279769639613585)
,p_plug_name=>'Daten'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1016219208335619187)
,p_name=>'Suchergebnisse'
,p_region_name=>'search-results'
,p_parent_plug_id=>wwv_flow_imp.id(1009279769639613585)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    select fp_kpb, fp_bezeichnung, SM_NOMENKLATUR, ltue_sop, ltue_eop, tpl_name, ltue_deleted, ltue_von',
'    from v_x_falko@carmah_e',
'),',
'cte2 as (',
'    select distinct fp_kpb, ltue_sop, ltue_eop, tpl_name, ltue_deleted',
'    from cte1',
'),',
'cte3 as (',
'    select distinct fp_kpb, ltue_sop, ltue_eop, SM_NOMENKLATUR, ltue_deleted',
'    from cte1',
'),',
'cte4 as (',
'    select fp_kpb, ltue_sop, ltue_eop, listagg(SM_NOMENKLATUR, ''<br />'') as SM_NOMENKLATUR, ltue_deleted',
'    from cte3 ',
'    group by fp_kpb, ltue_sop, ltue_eop, ltue_deleted',
')',
'select n.SM_NOMENKLATUR as SM_NOMENKLATUR, ',
'        cte2.ltue_sop, cte2.ltue_eop, case when cte2.ltue_deleted = 0 then ''nein'' else ''ja'' end as ltue_deleted,',
'        listagg(cte2.tpl_name || '' - '' || l.land, '', '') within group (order by tpl_name) as b_nummern,',
'        listagg(l.landid, '':'') within group (order by tpl_name) as laender',
'from cte2',
'left outer join t_land l on l.b_nummer = cte2.tpl_name',
'left outer join cte4 n on (n.ltue_sop = cte2.ltue_sop and n.ltue_eop = cte2.ltue_eop ',
'                           and n.fp_kpb = cte2.fp_kpb and n.ltue_deleted = cte2.ltue_deleted)',
'where cte2.fp_kpb = :P365_KPB',
'group by n.SM_NOMENKLATUR, cte2.ltue_sop, cte2.ltue_eop, cte2.ltue_deleted',
'order by cte2.ltue_deleted asc'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P365_KPB'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1016216019461619155)
,p_query_column_id=>1
,p_column_alias=>'SM_NOMENKLATUR'
,p_column_display_sequence=>2
,p_column_heading=>'Nomenklatur'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1016219090312619186)
,p_query_column_id=>2
,p_column_alias=>'LTUE_SOP'
,p_column_display_sequence=>3
,p_column_heading=>'SOP'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1016218953837619185)
,p_query_column_id=>3
,p_column_alias=>'LTUE_EOP'
,p_column_display_sequence=>4
,p_column_heading=>'EOP'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1016215867404619154)
,p_query_column_id=>4
,p_column_alias=>'LTUE_DELETED'
,p_column_display_sequence=>6
,p_column_heading=>unistr('gel\00F6scht')
,p_column_alignment=>'CENTER'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1016218269288619178)
,p_query_column_id=>5
,p_column_alias=>'B_NUMMERN'
,p_column_display_sequence=>5
,p_column_heading=>'B-Nummern'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1016218187756619177)
,p_query_column_id=>6
,p_column_alias=>'LAENDER'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1016218344257619179)
,p_query_column_id=>7
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>1
,p_column_heading=>'&nbsp;'
,p_column_link=>'javascript:void(null);'
,p_column_linktext=>unistr('<span class="fa fa-box-arrow-out-east" aria-hidden="true" title="SOP/EOP und L\00E4nder \00FCbernehmen"></span>')
,p_column_link_attr=>'sop=#LTUE_SOP# eop=#LTUE_EOP# landids=#LAENDER#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1016219462716619190)
,p_name=>'P365_KPB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1009280143200613589)
,p_prompt=>'KPB'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct fp_kpb as display, fp_kpb as value',
'from v_x_falko@carmah_e'))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1016218081710619176)
,p_name=>'P365_SOP'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1009280143200613589)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1016218007569619175)
,p_name=>'P365_EOP'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1009280143200613589)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1016217842106619174)
,p_name=>'P365_LANDIDS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1009280143200613589)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1016218769718619183)
,p_name=>'KPB changed'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P365_KPB'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1016218640918619182)
,p_event_id=>wwv_flow_imp.id(1016218769718619183)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1016219208335619187)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1016217595131619171)
,p_name=>'row selected'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#search-results tr td:first-child a'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1016217456814619170)
,p_event_id=>wwv_flow_imp.id(1016217595131619171)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P365_SOP'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).attr(''sop'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1016217015906619165)
,p_event_id=>wwv_flow_imp.id(1016217595131619171)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P365_EOP'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).attr(''eop'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1016217121937619166)
,p_event_id=>wwv_flow_imp.id(1016217595131619171)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P365_LANDIDS'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).attr(''landids'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1016217382569619169)
,p_event_id=>wwv_flow_imp.id(1016217595131619171)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
,p_attribute_01=>'P365_SOP,P365_EOP,P365_LANDIDS'
);
wwv_flow_imp.component_end;
end;
/
