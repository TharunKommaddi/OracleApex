prompt --application/pages/page_00054
begin
--   Manifest
--     PAGE: 00054
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>54
,p_name=>'Regel bearbeiten'
,p_alias=>'REGEL-BEARBEITEN'
,p_page_mode=>'MODAL'
,p_step_title=>'Regel bearbeiten'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(910483753460828018)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5424799019436810188)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(910463827548688300)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5424799019436810188)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(910463434434688299)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(5424799019436810188)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(910463105900688298)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(5424799019436810188)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_condition=>'P54_REGELID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(910462623559688298)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(5424799019436810188)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_condition=>'P54_REGELID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(910483679352828017)
,p_name=>'P54_REGELID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(910483753460828018)
,p_prompt=>'Regelid'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(910483519477828016)
,p_name=>'P54_BEZEICHNUNG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(910483753460828018)
,p_prompt=>'Regelname'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(910483467267828015)
,p_name=>'P54_BESCHREIBUNG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(910483753460828018)
,p_prompt=>'Beschreibung'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(910483332761828014)
,p_name=>'P54_AKTIV_FLAG'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(910483753460828018)
,p_prompt=>'Aktiv'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Ja;1,Nein;0'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(910483247142828013)
,p_name=>'P54_THEMEN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(910483753460828018)
,p_prompt=>unistr('Themen (AND - genau diese m\00FCssen zutreffen)')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NUMMER || '' - '' || BEZEICHNUNG AS D, THEMAID AS R',
'FROM T_THEMA',
'WHERE GUELTIG = 1',
'ORDER BY NUMMER;'))
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_help_text=>'Die Vorschrift muss GENAU diese Themen haben - kein einziges mehr oder weniger.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(910483121199828012)
,p_name=>'P54_AUSGESCHLOSSENE_FZG'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(910483753460828018)
,p_item_default=>'Pkw (1024)'
,p_prompt=>'Ausgeschlossene Fahrzeugklassen'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT BEZEICHNUNG AS D, FAHRZEUGKLASSEID AS R',
'FROM T_FAHRZEUGKLASSE',
'ORDER BY BEZEICHNUNG;'))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_help_text=>'Wenn die Vorschrift eine dieser Fahrzeugklassen hat, greift die Regel NICHT.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(910462247952686839)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(910463827548688300)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(910461901726686832)
,p_event_id=>wwv_flow_imp.id(910462247952686839)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(910483079205828011)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save Rule (Insert / Update T_REGEL)'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P54_REGELID IS NULL THEN',
'        -- INSERT new rule',
'        INSERT INTO T_REGEL (',
'            BEZEICHNUNG, BESCHREIBUNG, AKTIV_FLAG,',
'            LETZTE_AENDERUNG_DATUM, LETZTE_AENDERUNG_BENUTZERID',
'        ) VALUES (',
'            :P54_BEZEICHNUNG, :P54_BESCHREIBUNG, :P54_AKTIV_FLAG,',
'            SYSDATE, PCK_RI.fGetUserId',
'        ) RETURNING REGELID INTO :P54_REGELID;',
'    ELSE',
'        -- UPDATE existing rule',
'        UPDATE T_REGEL SET',
'            BEZEICHNUNG                 = :P54_BEZEICHNUNG,',
'            BESCHREIBUNG                = :P54_BESCHREIBUNG,',
'            AKTIV_FLAG                  = :P54_AKTIV_FLAG,',
'            LETZTE_AENDERUNG_DATUM      = SYSDATE,',
'            LETZTE_AENDERUNG_BENUTZERID = PCK_RI.fGetUserId',
'        WHERE REGELID = :P54_REGELID;',
'    END IF;',
'',
'    -- Commit parent row first so FK constraints are satisfied',
'    COMMIT;',
'',
'    -- Delete existing topic links and re-insert',
'    DELETE FROM T_REGEL_REF_THEMA WHERE REGELID = :P54_REGELID;',
'    FOR t IN (',
'        SELECT COLUMN_VALUE AS THEMAID',
'        FROM TABLE(APEX_STRING.SPLIT_NUMBERS(:P54_THEMEN, '':''))',
'        WHERE COLUMN_VALUE IS NOT NULL',
'    ) LOOP',
'        INSERT INTO T_REGEL_REF_THEMA (',
'            REGELID, THEMAID, LETZTE_AENDERUNG_DATUM, LETZTE_AENDERUNG_BENUTZERID',
'        ) VALUES (',
'            :P54_REGELID, t.THEMAID, SYSDATE, PCK_RI.fGetUserId',
'        );',
'    END LOOP;',
'',
'    -- Delete existing FZG exclusions and re-insert',
'    DELETE FROM T_REGEL_REF_FZG_KLASSE WHERE REGELID = :P54_REGELID;',
'    FOR f IN (',
'        SELECT COLUMN_VALUE AS FAHRZEUGKLASSEID',
'        FROM TABLE(APEX_STRING.SPLIT_NUMBERS(:P54_AUSGESCHLOSSENE_FZG, '':''))',
'        WHERE COLUMN_VALUE IS NOT NULL',
'    ) LOOP',
'        INSERT INTO T_REGEL_REF_FZG_KLASSE (',
'            REGELID, FAHRZEUGKLASSEID, LETZTE_AENDERUNG_DATUM, LETZTE_AENDERUNG_BENUTZERID',
'        ) VALUES (',
'            :P54_REGELID, f.FAHRZEUGKLASSEID, SYSDATE, PCK_RI.fGetUserId',
'        );',
'    END LOOP;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2761729236693560224
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(910482984928828010)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete Rule (ON DELETE CASCADE handles child rows)'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    DELETE FROM T_REGEL WHERE REGELID = :P54_REGELID;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(910463434434688299)
,p_internal_uid=>2761729330970560225
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(910147211950323079)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2762065103949065156
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(910177390968695934)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LoadData'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P54_REGELID IS NOT NULL THEN',
'',
'        SELECT BEZEICHNUNG, BESCHREIBUNG, AKTIV_FLAG',
'        INTO :P54_BEZEICHNUNG, :P54_BESCHREIBUNG, :P54_AKTIV_FLAG',
'        FROM T_REGEL',
'        WHERE REGELID = :P54_REGELID;',
'',
'        -- Load topics as colon-separated list',
'        SELECT LISTAGG(THEMAID, '':'') WITHIN GROUP (ORDER BY THEMAID)',
'        INTO :P54_THEMEN',
'        FROM T_REGEL_REF_THEMA',
'        WHERE REGELID = :P54_REGELID;',
'',
'        -- Load excluded FZG classes as colon-separated list',
'        SELECT LISTAGG(FAHRZEUGKLASSEID, '':'') WITHIN GROUP (ORDER BY FAHRZEUGKLASSEID)',
'        INTO :P54_AUSGESCHLOSSENE_FZG',
'        FROM T_REGEL_REF_FZG_KLASSE',
'        WHERE REGELID = :P54_REGELID;',
'',
'    END IF;',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        NULL; -- Row not found, just leave items empty',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2762034924930692301
);
wwv_flow_imp.component_end;
end;
/
