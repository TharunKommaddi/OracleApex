prompt --application/pages/page_00320
begin
--   Manifest
--     PAGE: 00320
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>320
,p_name=>'Suche'
,p_alias=>'SUCHE'
,p_step_title=>'Suche'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Hilfe-Buztton',
'//$(''#rSuche .t-Region-title'').append('' <span onclick="redirect(161)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'//$(''#rSuche_heading'').append('' <span onclick="redirect(161)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rSuche .t-Region-title:first'').append('' <span onclick="redirect(161)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3636639305132187813)
,p_plug_name=>'Suche'
,p_region_name=>'rSuche'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3636639589255187816)
,p_name=>'CARD_SUCHLISTE'
,p_parent_plug_id=>wwv_flow_imp.id(3636639305132187813)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_component_template_options=>'#DEFAULT#:t-Cards--animColorFill:t-Cards--3cols:t-Cards--basic'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select column_value, ',
'''<a href="'' ||',
'apex_page.get_url(p_page => 325, p_items => ''P325_SUCHE_TEMPID'', p_values => column_value, p_clear_cache => 325) ||',
'''"><span aria-hidden="true" class="fa fa-pencil-square"></span> '' || emano_util.fLang(''Eingabe Suchparameter'', ''Input Search Parameters'') || ''</a>''',
'as CARD_SUBTEXT, ',
'emano_util.fLang(''Meilenstein'', ''Milestone'') || '' '' || row_number() over (ORDER BY column_value ASC) as CARD_TITLE,',
'',
'(select ''<table>'' ||',
' nvl2(JSON_VALUE(SUCHDATEN,''$.DATUM_MEILENSTEIN''), ''<tr><td>'' || emano_util.fLang(''Datum Meilenstein'', ''Milestone Date'') || '':</td><td>'' || TO_CHAR(JSON_VALUE(SUCHDATEN,''$.DATUM_MEILENSTEIN'')) || ''</td></tr>'', null)',
' || nvl2(JSON_VALUE(SUCHDATEN,''$.DATUM_SOP''), ''<tr><td>'' || emano_util.fLang(''Datum SOP'', ''SOP Date'') || '':</td><td>'' || TO_CHAR(JSON_VALUE(SUCHDATEN,''$.DATUM_SOP'')) || ''</td></tr>'', null)',
' || nvl2(JSON_VALUE(SUCHDATEN,''$.DATUM_EOP'' ), ''<tr><td>'' || emano_util.fLang(''Datum EOP'', ''EOP Date'') || '':</td><td>'' || TO_CHAR(JSON_VALUE(SUCHDATEN,''$.DATUM_EOP'' ))  || ''</td></tr>'', null)',
unistr(' || nvl2(JSON_VALUE(SUCHDATEN,''$.LAENDER''), ''<tr><td>'' || emano_util.fLang(''Relevante L\00E4nder'', ''Relevant Countries'') || '':</td><td>'' || to_char(regexp_count(JSON_VALUE(SUCHDATEN,''$.LAENDER''), '':'')+1) || ''</td></tr>'', null)'),
' || nvl2(JSON_VALUE(SUCHDATEN,''$.THEMEN'' ), ''<tr><td>'' || emano_util.fLang(''Relevante Themen'', ''Relevant Topics'') || '':</td><td>'' || to_char(regexp_count(JSON_VALUE(SUCHDATEN,''$.THEMEN'' ), '':'')+1) || ''</td></tr>'', null)',
' || case when JSON_VALUE(SUCHDATEN,''$.LAENDER'') is null or JSON_VALUE(SUCHDATEN,''$.THEMEN'' ) is null then ''<tr><td>'' || emano_util.fLang(''Noch keine Suchparameter eingestellt'', ''No search parameters set yet'') || ''</td></tr>'' else null end',
' || ''</table>''',
'from t_suche_JSON_temp st',
'where suche_tempid = column_value) AS CARD_TEXT',
'',
'from table(apex_string.split_numbers(:P320_SUCHE_TEMPIDS,'':''))',
'',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414129911996820551)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(869082265936331750)
,p_query_column_id=>1
,p_column_alias=>'COLUMN_VALUE'
,p_column_display_sequence=>1
,p_column_heading=>'Column Value'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(869081934488331749)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>2
,p_column_heading=>'Card Subtext'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(869081535131331749)
,p_query_column_id=>3
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>3
,p_column_heading=>'Card Title'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(869081094953331749)
,p_query_column_id=>4
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>4
,p_column_heading=>'Card Text'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3651178878131759533)
,p_plug_name=>'Ergebnis 1'
,p_parent_plug_id=>wwv_flow_imp.id(3636639305132187813)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3636878203903701532)
,p_name=>'ergebnis1'
,p_parent_plug_id=>wwv_flow_imp.id(3651178878131759533)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select Vorschrift_nummer,vorschriftid ,  t.regelnummer as Regel, t.Risiko',
'from',
'                      table(',
'                                (Select pck_ri_suche.fSearchResultsBase(JSON_VALUE(SUCHDATEN,''$.THEMEN'' ), JSON_VALUE(SUCHDATEN,''$.LAENDER''),JSON_VALUE(SUCHDATEN,''$.DATUM_SOP''),',
'                                       JSON_VALUE(SUCHDATEN,''$.DATUM_MEILENSTEIN''),  JSON_VALUE(SUCHDATEN,''$.SUCHTYP'' ), JSON_VALUE(SUCHDATEN,''$.DATUM_EOP'' ),',
'                                       JSON_VALUE(SUCHDATEN,''$.CKD_FBU_MODE'' ),JSON_VALUE(SUCHDATEN,''$.LOW_RISK'' ),JSON_VALUE(SUCHDATEN,''$.HIGH_RISK'' )) ',
'                                      from t_suche_JSON_temp tst',
'                                    where SUCHE_TEMPID = pck_ri_suche.fSplitIndex(:P320_SUCHE_TEMPIDS,1))',
'                                    ) t',
'                       join  t_vorschrift tv on (t.vorschriftid=tv.vorschriftid)',
'                      ',
'     ',
'                      ',
'                      ',
'                         '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(869080087130331748)
,p_query_column_id=>1
,p_column_alias=>'VORSCHRIFT_NUMMER'
,p_column_display_sequence=>1
,p_column_heading=>'Vorschriftennummer'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_column_linktext=>'#VORSCHRIFT_NUMMER#'
,p_column_link_attr=>'target="_blank"'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(869079660494331747)
,p_query_column_id=>2
,p_column_alias=>'VORSCHRIFTID'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(869079257039331747)
,p_query_column_id=>3
,p_column_alias=>'REGEL'
,p_column_display_sequence=>3
,p_column_heading=>'Regel'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'STATIC:Verpflichtend neue Typen;1,Verpflichtend alle Fahrzeuge;2,Optional;0'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(852077171204380103)
,p_query_column_id=>4
,p_column_alias=>'RISIKO'
,p_column_display_sequence=>4
,p_column_heading=>'Risiko'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(958143412491459185)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3651179171630759536)
,p_plug_name=>'head1'
,p_parent_plug_id=>wwv_flow_imp.id(3651178878131759533)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3651179216859759537)
,p_plug_name=>'footer1'
,p_parent_plug_id=>wwv_flow_imp.id(3651178878131759533)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3651179009586759534)
,p_plug_name=>'Ergebnis 2'
,p_parent_plug_id=>wwv_flow_imp.id(3636639305132187813)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3636878739461701538)
,p_name=>'Ergebnis 2'
,p_parent_plug_id=>wwv_flow_imp.id(3651179009586759534)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (Select Vorschrift_nummer,vorschriftid , regelnummer as regel, t.Risiko',
'from',
'                      table(',
'                                (Select pck_ri_suche.fSearchResultsBase(JSON_VALUE(SUCHDATEN,''$.THEMEN'' ), JSON_VALUE(SUCHDATEN,''$.LAENDER''),JSON_VALUE(SUCHDATEN,''$.DATUM_SOP''),',
'                                       JSON_VALUE(SUCHDATEN,''$.DATUM_MEILENSTEIN''),  JSON_VALUE(SUCHDATEN,''$.SUCHTYP'' ), JSON_VALUE(SUCHDATEN,''$.DATUM_EOP'' ),',
'                                       JSON_VALUE(SUCHDATEN,''$.CKD_FBU_MODE'' ),JSON_VALUE(SUCHDATEN,''$.LOW_RISK'' ),JSON_VALUE(SUCHDATEN,''$.HIGH_RISK'' )) ',
'                                      from t_suche_JSON_temp tst',
'                                    where SUCHE_TEMPID = pck_ri_suche.fSplitIndex(:P320_SUCHE_TEMPIDS,1))',
'                                    ) t',
'                       join  t_vorschrift tv on (t.vorschriftid=tv.vorschriftid)',
'                       where :P320_VIEW_DELTA2 = 1 ',
'',
'',
'',
'), Cte2 as (Select tv.Vorschrift_nummer, tv.vorschriftid, regelnummer as regel, t.Risiko from',
'table(',
'                                (Select pck_ri_suche.fSearchResultsBase(JSON_VALUE(SUCHDATEN,''$.THEMEN'' ), JSON_VALUE(SUCHDATEN,''$.LAENDER''),JSON_VALUE(SUCHDATEN,''$.DATUM_SOP''),',
'                                       JSON_VALUE(SUCHDATEN,''$.DATUM_MEILENSTEIN''),  JSON_VALUE(SUCHDATEN,''$.SUCHTYP'' ), JSON_VALUE(SUCHDATEN,''$.DATUM_EOP'' ),',
'                                       JSON_VALUE(SUCHDATEN,''$.CKD_FBU_MODE'' ),JSON_VALUE(SUCHDATEN,''$.LOW_RISK'' ),JSON_VALUE(SUCHDATEN,''$.HIGH_RISK'' )) ',
'                                      from t_suche_JSON_temp tst',
'                                    where SUCHE_TEMPID = pck_ri_suche.fSplitIndex(:P320_SUCHE_TEMPIDS,2))',
'                                    ) t',
'                       join  t_vorschrift tv on (t.vorschriftid=tv.vorschriftid)',
'',
'',
'',
'',
')',
'Select case when t1.vorschrift_nummer is null and :P320_VIEW_DELTA2 = 1then ''<span style="color:green">'' || tv.Vorschrift_nummer ||''</span> ''  ',
'when tv.Vorschrift_nummer is null and :P320_VIEW_DELTA2 = 1 then ''<span style="color:orange">'' || t1.Vorschrift_nummer ||''</span> '' ',
'else nvl(t1.vorschrift_nummer,tv.Vorschrift_nummer) end as vorschrift_nummer, ',
'    case when t1.vorschrift_nummer is null then ''Neu'' when tv.Vorschrift_nummer is null then ''entfallen'' else ''wegen Projektverschiebung'' end  as Delta,',
'    nvl(tv.vorschriftid, t1.vorschriftid) as vorschriftid, case when tv.regel = 0 then ''Optional'' when tv.regel = 1 then ''Verpflichtend neue Typen''',
'                                                                      else'' Verpflichtend alle Fahrzeuge''',
'                                                                      end as regel , nvl(tv.Risiko,t1.Risiko) Risiko',
'from cte2 tv',
'full outer join cte1 t1 on (tv.vorschrift_nummer = t1.vorschrift_nummer)',
'where :P320_VIEW_DELTA2 = 0 or (:P320_VIEW_DELTA2 = 1 and (( t1.vorschrift_nummer is null or tv.Vorschrift_nummer is null)',
'                                                           or (t1.regel is null or tv.regel is null or tv.regel != t1.regel))',
'                                )',
'',
'',
'',
'                         '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'Es wurden keine Daten gefunden'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(869076076260331744)
,p_query_column_id=>1
,p_column_alias=>'VORSCHRIFT_NUMMER'
,p_column_display_sequence=>1
,p_column_heading=>'Vorschriftennummer'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_column_linktext=>'#VORSCHRIFT_NUMMER#'
,p_column_link_attr=>'target="_blank"'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(869075661111331743)
,p_query_column_id=>2
,p_column_alias=>'DELTA'
,p_column_display_sequence=>2
,p_column_heading=>'Delta'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P320_VIEW_DELTA2'
,p_display_when_condition2=>'1'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(869075326808331743)
,p_query_column_id=>3
,p_column_alias=>'VORSCHRIFTID'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(869074920322331743)
,p_query_column_id=>4
,p_column_alias=>'REGEL'
,p_column_display_sequence=>4
,p_column_heading=>'Regel'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(840699293949540398)
,p_query_column_id=>5
,p_column_alias=>'RISIKO'
,p_column_display_sequence=>5
,p_column_heading=>'Risiko'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(958143412491459185)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3651179408813759538)
,p_plug_name=>'head2'
,p_parent_plug_id=>wwv_flow_imp.id(3651179009586759534)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3651179551664759540)
,p_plug_name=>'footer2'
,p_parent_plug_id=>wwv_flow_imp.id(3651179009586759534)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3651179038054759535)
,p_plug_name=>'Ergebnis 3'
,p_parent_plug_id=>wwv_flow_imp.id(3636639305132187813)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3636879389618701544)
,p_name=>'Ergebnis 3'
,p_parent_plug_id=>wwv_flow_imp.id(3651179038054759535)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (Select Vorschrift_nummer,vorschriftid , regelnummer as regel, Risiko',
'from',
'                      table(',
'                                (Select pck_ri_suche.fSearchResultsBase(JSON_VALUE(SUCHDATEN,''$.THEMEN'' ), JSON_VALUE(SUCHDATEN,''$.LAENDER''),JSON_VALUE(SUCHDATEN,''$.DATUM_SOP''),',
'                                       JSON_VALUE(SUCHDATEN,''$.DATUM_MEILENSTEIN''),  JSON_VALUE(SUCHDATEN,''$.SUCHTYP'' ), JSON_VALUE(SUCHDATEN,''$.DATUM_EOP'' ),',
'                                       JSON_VALUE(SUCHDATEN,''$.CKD_FBU_MODE'' ),JSON_VALUE(SUCHDATEN,''$.LOW_RISK'' ),JSON_VALUE(SUCHDATEN,''$.HIGH_RISK'' )) ',
'                                      from t_suche_JSON_temp tst',
'                                    where SUCHE_TEMPID = pck_ri_suche.fSplitIndex(:P320_SUCHE_TEMPIDS,2))',
'                                    ) t',
'                       join  t_vorschrift tv on  (t.vorschriftid=tv.vorschriftid)',
'                       where :P320_VIEW_DELTA3 = 1 ',
'',
'',
'',
'), Cte2 as (Select tv.Vorschrift_nummer, tv.vorschriftid, regelnummer as regel, risiko from',
'table(',
'                                (Select pck_ri_suche.fSearchResultsBase(JSON_VALUE(SUCHDATEN,''$.THEMEN'' ), JSON_VALUE(SUCHDATEN,''$.LAENDER''),JSON_VALUE(SUCHDATEN,''$.DATUM_SOP''),',
'                                       JSON_VALUE(SUCHDATEN,''$.DATUM_MEILENSTEIN''),  JSON_VALUE(SUCHDATEN,''$.SUCHTYP'' ), JSON_VALUE(SUCHDATEN,''$.DATUM_EOP'' ),',
'                                       JSON_VALUE(SUCHDATEN,''$.CKD_FBU_MODE'' ),JSON_VALUE(SUCHDATEN,''$.LOW_RISK'' ),JSON_VALUE(SUCHDATEN,''$.HIGH_RISK'' )) ',
'                                      from t_suche_JSON_temp tst',
'                                    where SUCHE_TEMPID = pck_ri_suche.fSplitIndex(:P320_SUCHE_TEMPIDS,3))',
'                                    ) t',
'                       join  t_vorschrift tv on (t.vorschriftid=tv.vorschriftid)',
'',
'',
'',
'',
')',
'Select case when t1.vorschrift_nummer is null and :P320_VIEW_DELTA2 = 1then ''<span style="color:green">'' || tv.Vorschrift_nummer ||''</span> ''  ',
'when tv.Vorschrift_nummer is null and :P320_VIEW_DELTA2 = 1 then ''<span style="color:orange">'' || t1.Vorschrift_nummer ||''</span> '' ',
'else nvl(t1.vorschrift_nummer,tv.Vorschrift_nummer) end as vorschrift_nummer, ',
'    case when t1.vorschrift_nummer is null then ''Neu'' when tv.Vorschrift_nummer is null then ''entfallen''  else ''wegen Projektverschiebung'' end  as Delta,',
'    nvl(tv.vorschriftid, t1.vorschriftid) as vorschriftid, case when tv.regel = 0 then ''Optional'' when tv.regel = 1 then ''Verpflichtend neue Typen''',
'                                                                      else'' Verpflichtend alle Fahrzeuge''',
'                                                                      end as regel,nvl(tv.Risiko,t1.Risiko) Risiko',
'from cte2 tv',
'full outer join cte1 t1 on (tv.vorschrift_nummer = t1.vorschrift_nummer)',
'where :P320_VIEW_DELTA2 = 0 or (:P320_VIEW_DELTA2 = 1 and (( t1.vorschrift_nummer is null or tv.Vorschrift_nummer is null)',
'                                                           or (t1.regel is null or tv.regel is null or tv.regel != t1.regel))',
'                                )',
'',
'',
'',
'                         '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'Es wurden keine Daten gefunden'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(869071734321331740)
,p_query_column_id=>1
,p_column_alias=>'VORSCHRIFT_NUMMER'
,p_column_display_sequence=>1
,p_column_heading=>'Vorschriftennummer'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_column_linktext=>'#VORSCHRIFT_NUMMER#'
,p_column_link_attr=>'target="_blank"'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(869071307398331740)
,p_query_column_id=>2
,p_column_alias=>'DELTA'
,p_column_display_sequence=>2
,p_column_heading=>'Delta'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P320_VIEW_DELTA3'
,p_display_when_condition2=>'1'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(869070901642331739)
,p_query_column_id=>3
,p_column_alias=>'VORSCHRIFTID'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(869070506080331739)
,p_query_column_id=>4
,p_column_alias=>'REGEL'
,p_column_display_sequence=>4
,p_column_heading=>'Regel'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(840699184953540397)
,p_query_column_id=>5
,p_column_alias=>'RISIKO'
,p_column_display_sequence=>5
,p_column_heading=>'Risiko'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(958143412491459185)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3651179432667759539)
,p_plug_name=>'head3'
,p_parent_plug_id=>wwv_flow_imp.id(3651179038054759535)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3651179807148759542)
,p_plug_name=>'footer3'
,p_parent_plug_id=>wwv_flow_imp.id(3651179038054759535)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(869078619941331747)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3651179171630759536)
,p_button_name=>'BTN_SUCHE1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Suchen'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
,p_grid_column_span=>3
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(869074168287331742)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3651179408813759538)
,p_button_name=>'BTN_SUCHE2'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Suchen'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
,p_grid_column_span=>3
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(869069772251331738)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3651179432667759539)
,p_button_name=>'BTN_SUCHE3'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Suchen'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
,p_grid_column_span=>3
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(869085372938331754)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3636639305132187813)
,p_button_name=>'BTN_PARAM_UEBERNEHMEN2'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Suchparameter \00FCbernehmen')
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
,p_grid_column=>5
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(869068676765331737)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3651179807148759542)
,p_button_name=>'CSV3'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Download'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-download'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(869073056276331741)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(3651179551664759540)
,p_button_name=>'CSV2'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Download'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-download'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(869077449012331746)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(3651179216859759537)
,p_button_name=>'CSV1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Download'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-download'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(869084991204331754)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(3636639305132187813)
,p_button_name=>'BTN_PARAM_UEBERNEHMEN3'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Suchparameter \00FCbernehmen')
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(634294151353589898)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3636639305132187813)
,p_button_name=>'SUCHMASKEN_LEEREN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Parameter leeren'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:320:&SESSION.::&DEBUG.:320::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(869084541224331754)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(3636639305132187813)
,p_button_name=>'COPY_SUCHE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Suche an anderen Anwender weitergeben'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:327:&SESSION.::&DEBUG.:RP,327:P327_SUCHE_TEMPIDS,P327_REASSIGN_USER:\&P320_SUCHE_TEMPIDS.\,true'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(677276224115185497)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(3636639305132187813)
,p_button_name=>'MERGE_SUCHE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Suche zusammenf\00FChren')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:322:&SESSION.::&DEBUG.:RP,327::'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(869084184874331754)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(3636639305132187813)
,p_button_name=>'LOAD_SUCHE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Historische Suchen laden/verwalten'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:326:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(869083829480331754)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(3636639305132187813)
,p_button_name=>'SAVE_SUCHE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Suche speichern'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:327:&SESSION.::&DEBUG.:RP,327:P327_SUCHE_TEMPIDS:\&P320_SUCHE_TEMPIDS.\'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(569231218597407187)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3651179216859759537)
,p_button_name=>'SUCHE_ANZEIGEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Suche Anzeigen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:600:&SESSION.::&DEBUG.:600:P600_SUCHE_TEMPID,P600_SUCHE_INDEX:\&P320_SUCHE_TEMPIDS.\,1'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(569230450199407180)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3651179551664759540)
,p_button_name=>'SUCHE_ANZEIGEN_2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Suche Anzeigen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:600:&SESSION.::&DEBUG.:600:P600_SUCHE_TEMPID,P600_SUCHE_INDEX:\&P320_SUCHE_TEMPIDS.\,2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(569230362915407179)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3651179807148759542)
,p_button_name=>'SUCHE_ANZEIGEN_3'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Suche Anzeigen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:600:&SESSION.::&DEBUG.:600:P600_SUCHE_TEMPID,P600_SUCHE_INDEX:\&P320_SUCHE_TEMPIDS.\,3'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(869058622232331731)
,p_branch_name=>'Branch_DOWNLOAD1'
,p_branch_action=>'f?p=&APP_ID.:0:&SESSION.:APPLICATION_PROCESS=downloadCSV:&DEBUG.:RP:G_CSV_EXPORTTYPE,G_CSV_INDEX,G_CSV_SUCHEIDS,G_CSV_DELTAMODE:&P320_EXPORT_FORMAT1.,1,&P320_SUCHE_TEMPIDS.,0&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(869077449012331746)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(869058197727331731)
,p_branch_name=>'Branch_DOWNLOAD2'
,p_branch_action=>'f?p=&APP_ID.:0:&SESSION.:APPLICATION_PROCESS=downloadCSV:&DEBUG.:RP,:G_CSV_EXPORTTYPE,G_CSV_INDEX,G_CSV_SUCHEIDS,G_CSV_DELTAMODE:&P320_EXPORT_FORMAT2.,2,&P320_SUCHE_TEMPIDS.,&P320_VIEW_DELTA2.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
,p_branch_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(869057780543331731)
,p_branch_name=>'Branch_DOWNLOAD3'
,p_branch_action=>'f?p=&APP_ID.:0:&SESSION.:APPLICATION_PROCESS=downloadCSV:&DEBUG.:RP,:G_CSV_EXPORTTYPE,G_CSV_INDEX,G_CSV_SUCHEIDS,G_CSV_DELTAMODE:&P320_EXPORT_FORMAT3.,3,&P320_SUCHE_TEMPIDS.,&P320_VIEW_DELTA3.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>30
,p_branch_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(869059428648331732)
,p_branch_name=>'Branch_Download2_new'
,p_branch_action=>'f?p=&APP_ID.:0:&SESSION.:APPLICATION_PROCESS=downloadCSV:&DEBUG.::G_CSV_DELTAMODE,G_CSV_EXPORTTYPE,G_CSV_INDEX,G_CSV_SUCHEIDS:&P320_VIEW_DELTA2.,&P320_EXPORT_FORMAT2.,2,&P320_SUCHE_TEMPIDS.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(869073056276331741)
,p_branch_sequence=>40
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(869059034098331732)
,p_branch_name=>'Branch_Download3_new'
,p_branch_action=>'f?p=&APP_ID.:0:&SESSION.:APPLICATION_PROCESS=downloadCSV:&DEBUG.::G_CSV_DELTAMODE,G_CSV_EXPORTTYPE,G_CSV_INDEX,G_CSV_SUCHEIDS:&P320_VIEW_DELTA3.,&P320_EXPORT_FORMAT3.,3,&P320_SUCHE_TEMPIDS.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(869068676765331737)
,p_branch_sequence=>50
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869083346182331753)
,p_name=>'P320_SUCHEID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(3636639305132187813)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869083017602331753)
,p_name=>'P320_SUCHE_TEMPIDS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(3636639305132187813)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869078227588331747)
,p_name=>'P320_PLACEHOLDER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3651179171630759536)
,p_prompt=>'&nbsp;'
,p_source=>'&nbsp;'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="visibility:hidden;"'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869077082579331746)
,p_name=>'P320_EXPORT_FORMAT1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3651179216859759537)
,p_prompt=>'Export Format'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
unistr('        emano_util.fLang(''Export f\00FCr Baureihe'', ''Export for Series'') AS display_value, '),
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Export f\00FCr Themengebiete'', ''Export for Topic Areas'') AS display_value,'),
'        2 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Export f\00FCr Vorschriften'', ''Export for Regulations'') AS display_value,'),
'        3 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869073831556331742)
,p_name=>'P320_VIEW_DELTA2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3651179408813759538)
,p_item_default=>'0'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Delta',
  'off_value', '1',
  'on_label', 'Alle Ergebnisse',
  'on_value', '0',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869072669951331741)
,p_name=>'P320_EXPORT_FORMAT2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3651179551664759540)
,p_prompt=>'Export Format'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
unistr('        emano_util.fLang(''Export f\00FCr Baureihe'', ''Export for Series'') AS display_value, '),
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Export f\00FCr Themengebiete'', ''Export for Topic Areas'') AS display_value,'),
'        2 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Export f\00FCr Vorschriften'', ''Export for Regulations'') AS display_value,'),
'        3 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869069412568331738)
,p_name=>'P320_VIEW_DELTA3'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3651179432667759539)
,p_item_default=>'true'
,p_source=>'0'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Delta',
  'off_value', '1',
  'on_label', 'Alle Ergebnisse',
  'on_value', '0',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869068319234331737)
,p_name=>'P320_EXPORT_FORMAT3'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3651179807148759542)
,p_prompt=>'Export Format'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
unistr('        emano_util.fLang(''Export f\00FCr Baureihe'', ''Export for Series'') AS display_value, '),
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Export f\00FCr Themengebiete'', ''Export for Topic Areas'') AS display_value,'),
'        2 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Export f\00FCr Vorschriften'', ''Export for Regulations'') AS display_value,'),
'        3 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(769853883011276102)
,p_name=>'P320_DETAILS_1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(3651179216859759537)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(869067793986331736)
,p_validation_name=>'VALIDATE_SOP_1'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    lMeilenstein number := 1;',
'    lResult date;',
'begin',
'',
'    Select JSON_VALUE(SUCHDATEN,''$.DATUM_MEILENSTEIN'') into lResult',
'    from t_suche_json_temp tst',
'    where SUCHE_TEMPID = pck_ri_suche.fSplitIndex(:P320_SUCHE_TEMPIDS, lMeilenstein);',
'',
'    return lResult is not null;',
'    ',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('Bitte setzen Sie zun\00E4chst das Datum SOP/ME in Meilenstein 1.')
,p_when_button_pressed=>wwv_flow_imp.id(869078619941331747)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(869067382859331736)
,p_validation_name=>'VALIDATE_SOP_2'
,p_validation_sequence=>40
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    lMeilenstein number := 2;',
'    lResult date;',
'begin',
'',
'    Select JSON_VALUE(SUCHDATEN,''$.DATUM_MEILENSTEIN'') into lResult',
'    from t_suche_json_temp tst',
'    where SUCHE_TEMPID = pck_ri_suche.fSplitIndex(:P320_SUCHE_TEMPIDS, lMeilenstein);',
'',
'    return lResult is not null;',
'    ',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('Bitte setzen Sie zun\00E4chst das Datum SOP/ME in Meilenstein 2.')
,p_when_button_pressed=>wwv_flow_imp.id(869074168287331742)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(869066950079331736)
,p_validation_name=>'VALIDATE_SOP_3'
,p_validation_sequence=>50
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    lMeilenstein number := 3;',
'    lResult date;',
'begin',
'',
'    Select JSON_VALUE(SUCHDATEN,''$.DATUM_MEILENSTEIN'') into lResult',
'    from t_suche_json_temp tst',
'    where SUCHE_TEMPID = pck_ri_suche.fSplitIndex(:P320_SUCHE_TEMPIDS, lMeilenstein);',
'',
'    return lResult is not null;',
'    ',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('Bitte setzen Sie zun\00E4chst das Datum SOP/ME in Meilenstein 3.')
,p_when_button_pressed=>wwv_flow_imp.id(869069772251331738)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(869065880165331735)
,p_name=>'Parameter Bearbeiten - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(3636639589255187816)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869065400043331734)
,p_event_id=>wwv_flow_imp.id(869065880165331735)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3636639589255187816)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(869064952109331734)
,p_name=>'Suche Speichern - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(3636639589255187816)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869064497261331734)
,p_event_id=>wwv_flow_imp.id(869064952109331734)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P320_SUCHEID'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(869064097307331734)
,p_name=>'ACTION_UEBERNEHMEN2'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(869085372938331754)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869063623339331734)
,p_event_id=>wwv_flow_imp.id(869064097307331734)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_tempids wwv_flow_t_varchar2;',
'begin',
'    l_tempids := apex_string.split(:P320_SUCHE_TEMPIDS, '':'');',
'    pck_ri_suche.pCopySuchparameter(l_tempids(1), l_tempids(2));',
'end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869063077546331733)
,p_event_id=>wwv_flow_imp.id(869064097307331734)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3636639589255187816)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(869062676158331733)
,p_name=>'ACTION_UEBERNEHMEN3'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(869084991204331754)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869062184680331733)
,p_event_id=>wwv_flow_imp.id(869062676158331733)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_tempids wwv_flow_t_varchar2;',
'begin',
'    l_tempids := apex_string.split(:P320_SUCHE_TEMPIDS, '':'');',
'    pck_ri_suche.pCopySuchparameter(l_tempids(2), l_tempids(3));',
'end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869061674328331733)
,p_event_id=>wwv_flow_imp.id(869062676158331733)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3636639589255187816)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(869061282153331733)
,p_name=>'Change Switch Delta2'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P320_VIEW_DELTA2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869060789193331733)
,p_event_id=>wwv_flow_imp.id(869061282153331733)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(869060385342331732)
,p_name=>'Change switch delta 3'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P320_VIEW_DELTA3'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869059893188331732)
,p_event_id=>wwv_flow_imp.id(869060385342331732)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(769853386749276097)
,p_name=>'Change_Delta_Detail2'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P320_VIEW_DELTA2'
,p_condition_element=>'P320_VIEW_DELTA2'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(769853597545276099)
,p_event_id=>wwv_flow_imp.id(769853386749276097)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P320_DETAILS_2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(769853451519276098)
,p_event_id=>wwv_flow_imp.id(769853386749276097)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P320_DETAILS_2'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(769853140678276095)
,p_name=>'Change_Delta_Detail3'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P320_VIEW_DELTA3'
,p_condition_element=>'P320_VIEW_DELTA3'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(769853090804276094)
,p_event_id=>wwv_flow_imp.id(769853140678276095)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P320_DETAILS_2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(769852942409276093)
,p_event_id=>wwv_flow_imp.id(769853140678276095)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P320_DETAILS_2'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(869066284280331735)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Historische Suche laden'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
unistr('    -- Wenn der Anwender eine Suche ausgew\00E4hlt hat, dann setze die TempIds dieser Suche'),
'    if (:P320_SUCHEID is not null) then',
'        :P320_SUCHE_TEMPIDS := PCK_RI_SUCHE.fLoadSuche(:P320_SUCHEID);',
'        :P320_SUCHEID := null;',
'    end if;',
'    ',
'    ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2803146031619056500
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(869066639573331736)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Tempor\00E4re Suche erstellen')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
unistr('    -- Wenn Anwender eine frische Session hat, dann tempor\00E4re Speicher f\00FCr die Suchdaten erstellen'),
'    if (:P320_SUCHE_TEMPIDS is null) then',
'        :P320_SUCHE_TEMPIDS := pck_ri_suche.fGetNewTempJSONSuche(1) || '':'' || pck_ri_suche.fGetNewTempJSONSuche(2) || '':'' || pck_ri_suche.fGetNewTempJSONSuche(3);',
'    end if;',
'    ',
'    ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2803145676326056499
);
wwv_flow_imp.component_end;
end;
/
