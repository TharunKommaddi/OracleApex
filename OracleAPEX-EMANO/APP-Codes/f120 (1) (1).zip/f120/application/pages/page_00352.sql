prompt --application/pages/page_00352
begin
--   Manifest
--     PAGE: 00352
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>352
,p_name=>unistr('\00C4nderungshistorie Vorschrift Verkn\00FCpfungen')
,p_alias=>unistr('\00C4NDERUNGSHISTORIE-VORSCHRIFT-VERKN\00DCPFUNGEN1')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('\00C4nderungshistorie Vorschrift Verkn\00FCpfungen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function regiontitle(){',
'var type; ',
'type = apex.item( "P352_AMENDMENTID" ).getValue();',
'if (type == ''20'' ){',
unistr('apex.util.getTopApex().jQuery(".ui-dialog-content").dialog("option", "title", "\00C4nderungshistorie Vorschrift Amendment")'),
'}else{',
unistr('apex.util.getTopApex().jQuery(".ui-dialog-content").dialog("option", "title", "\00C4nderungshistorie Vorschrift Verkn\00FCpfungen")'),
'} ',
'}'))
,p_javascript_code_onload=>'regiontitle();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IR_HIST .t-fht-tbody {max-height: calc(100vh - 200px)}',
'.t-Body-topButton {display: none !important}',
'.t-Body-content {padding-bottom: 3px !important}',
'.t-Body {margin-bottom: 3px !important}',
'.t-Body-contentInner {padding-bottom: 0px !important}'))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(756554385094965945)
,p_plug_name=>unistr('Historie Vorschrift Verkn\00FCpfungen und Amendment')
,p_region_name=>'IR_HIST'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH cte AS (',
'    SELECT vrv.VORSCHRIFT_REF_VORSCHRIFTID,',
'        vrv.beziehung_art artid,',
'        vrv.AKTION,',
'        pck_ri_history.fdiff(vv.vorschrift_nummer, LAG(vv.vorschrift_nummer) OVER (PARTITION BY vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID ORDER BY vrv.letzte_aenderung_datum ASC), vrv.aktion) AS VORGAENGER_VORSCHRIFT,',
'        pck_ri_history.fdiff(nv.vorschrift_nummer, LAG(nv.vorschrift_nummer) OVER (PARTITION BY vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID ORDER BY vrv.letzte_aenderung_datum ASC), vrv.aktion) AS NACHFOLGER_VORSCHRIFT,',
'        pck_ri_history.fdiff(ba.beziehung_art, LAG(ba.beziehung_art) OVER (PARTITION BY vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID ORDER BY vrv.letzte_aenderung_datum ASC)) AS BEZIEHUNG_ART,',
'        pck_ri_history.fdiff(TO_CHAR(vrv.DATUM_IN_KRAFT, ''DD.MM.YYYY''), LAG(TO_CHAR(vrv.DATUM_IN_KRAFT, ''DD.MM.YYYY'')) OVER (PARTITION BY vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID ORDER BY vrv.letzte_aenderung_datum ASC)) AS DATUM_'
||'IN_KRAFT,',
'        pck_ri_history.fdiff(TO_CHAR(vrv.DATUM_NEUE_TYPEN, ''DD.MM.YYYY''), LAG(TO_CHAR(vrv.DATUM_NEUE_TYPEN, ''DD.MM.YYYY'')) OVER (PARTITION BY vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID ORDER BY vrv.letzte_aenderung_datum ASC)) AS DA'
||'TUM_NEUE_TYPEN,',
'        pck_ri_history.fdiff(TO_CHAR(vrv.DATUM_ALLE_TYPEN, ''DD.MM.YYYY''), LAG(TO_CHAR(vrv.DATUM_ALLE_TYPEN, ''DD.MM.YYYY'')) OVER (PARTITION BY vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID ORDER BY vrv.letzte_aenderung_datum ASC)) AS DA'
||'TUM_ALLE_TYPEN,',
'        pck_ri_history.fdiff(vrv.KOMMENTAR, LAG(vrv.KOMMENTAR) OVER (PARTITION BY vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID ORDER BY vrv.letzte_aenderung_datum ASC)) AS KOMMENTAR,',
'        pck_ri_history.fdiff(CASE vrv.HOMOLOGATION_SERIE WHEN 0 THEN ''nein'' WHEN 10 THEN ''ja'' ELSE TO_CHAR(vrv.HOMOLOGATION_SERIE) END, LAG(CASE vrv.HOMOLOGATION_SERIE WHEN 0 THEN ''nein'' WHEN 10 THEN ''ja'' ELSE TO_CHAR(vrv.HOMOLOGATION_SERIE) END) OVE'
||'R (PARTITION BY vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID ORDER BY vrv.letzte_aenderung_datum ASC), vrv.aktion) AS HOMOLOGATION_SERIE,',
'        pck_ri_history.fdiff(hv.vorschrift_nummer, LAG(hv.vorschrift_nummer) OVER (PARTITION BY vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID ORDER BY vrv.letzte_aenderung_datum ASC)) AS MAX_HOMOLOGATION_VORSCHRIFT,',
'        NVL2(vrv.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, NULL) AS LETZTE_AENDERUNG_BENUTZER,',
'        vrv.LETZTE_AENDERUNG_DATUM,',
'        b.EMAIL,',
'        pck_ri.fCreatePermalinkUrl(vv.vorschriftid) AS PERMALINK',
'    FROM T_H_VORSCHRIFT_REF_VORSCHRIFT vrv',
'    LEFT JOIN t_benutzer b ON b.benutzerid = vrv.letzte_aenderung_benutzerid',
'    LEFT JOIN t_vorschrift vv ON vv.vorschriftid = vrv.vorgaenger_vorschriftid',
'    LEFT JOIN t_vorschrift nv ON nv.vorschriftid = vrv.nachfolger_vorschriftid',
'    LEFT JOIN t_beziehung_art ba ON ba.beziehung_artid = vrv.beziehung_art',
'    LEFT JOIN t_vorschrift hv ON hv.vorschriftid = vrv.max_homologation_vorschriftid',
'    WHERE vrv.VORGAENGER_VORSCHRIFTID = :P352_VORSCHRIFTID OR vrv.NACHFOLGER_VORSCHRIFTID = :P352_VORSCHRIFTID',
'    ORDER BY vrv.LETZTE_AENDERUNG_DATUM DESC',
')',
'SELECT VORSCHRIFT_REF_VORSCHRIFTID,',
'    AKTION, VORGAENGER_VORSCHRIFT, NACHFOLGER_VORSCHRIFT, BEZIEHUNG_ART, DATUM_IN_KRAFT, DATUM_NEUE_TYPEN,',
'    DATUM_ALLE_TYPEN, KOMMENTAR, HOMOLOGATION_SERIE, MAX_HOMOLOGATION_VORSCHRIFT, LETZTE_AENDERUNG_BENUTZER, LETZTE_AENDERUNG_DATUM, EMAIL, PERMALINK',
'FROM cte',
'WHERE artid = NVL(:P352_AMENDMENTID, artid) ',
'   OR VORSCHRIFT_REF_VORSCHRIFTID IN (',
'       SELECT VORSCHRIFT_REF_VORSCHRIFTID',
'       FROM T_H_VORSCHRIFT_REF_VORSCHRIFT',
'       WHERE beziehung_art = NVL(:P352_AMENDMENTID, beziehung_art)',
'         AND (VORGAENGER_VORSCHRIFTID = :P352_VORSCHRIFTID OR NACHFOLGER_VORSCHRIFTID = :P352_VORSCHRIFTID)',
'   );'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P352_VORSCHRIFTID,P352_AMENDMENTID'
,p_plug_display_condition_type=>'NEVER'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Historie Vorschrift Verkn\00FCpfungen und Amendment')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select H_VORSCHRIFT_REF_VORSCHRIFTID,',
'    VORSCHRIFT_REF_VORSCHRIFTID,',
'    AKTION,',
'    pck_ri_history.fdiff(vv.vorschrift_nummer, LAG(vv.vorschrift_nummer) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc), aktion) as VORGAENGER_VORSCHRIFT,',
'    pck_ri_history.fdiff(nv.vorschrift_nummer, LAG(nv.vorschrift_nummer) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc), aktion) as NACHFOLGER_VORSCHRIFT,',
'    pck_ri_history.fdiff(ba.beziehung_art, LAG(ba.beziehung_art) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as BEZIEHUNG_ART,',
'    pck_ri_history.fdiff(to_char(vrv.DATUM_IN_KRAFT, ''DD.MM.YYYY''), LAG(to_char(vrv.DATUM_IN_KRAFT, ''DD.MM.YYYY'')) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as DATUM_IN_KR'
||'AFT,',
'    pck_ri_history.fdiff(to_char(vrv.DATUM_NEUE_TYPEN, ''DD.MM.YYYY''), LAG(to_char(vrv.DATUM_NEUE_TYPEN, ''DD.MM.YYYY'')) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as DATUM_N'
||'EUE_TYPEN,',
'    pck_ri_history.fdiff(to_char(vrv.DATUM_ALLE_TYPEN, ''DD.MM.YYYY''), LAG(to_char(vrv.DATUM_ALLE_TYPEN, ''DD.MM.YYYY'')) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as DATUM_A'
||'LLE_TYPEN,',
'    pck_ri_history.fdiff(vrv.KOMMENTAR, LAG(vrv.KOMMENTAR) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as KOMMENTAR,',
'    pck_ri_history.fdiff(case vrv.HOMOLOGATION_SERIE when 0 then ''nein'' when 10 then ''ja'' else to_char(vrv.HOMOLOGATION_SERIE) end , LAG(case vrv.HOMOLOGATION_SERIE when 0 then ''nein'' when 10 then ''ja'' else to_char(vrv.HOMOLOGATION_SERIE) end) over(p'
||'artition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc), aktion) as HOMOLOGATION_SERIE,    ',
'    pck_ri_history.fdiff(hv.vorschrift_nummer, LAG(hv.vorschrift_nummer) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as MAX_HOMOLOGATION_VORSCHRIFT,',
'    ',
'    nvl2(vrv.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) AS LETZTE_AENDERUNG_BENUTZER,',
'    vrv.LETZTE_AENDERUNG_DATUM as LETZTE_AENDERUNG_DATUM,',
'    b.EMAIL AS EMAIL,',
'    pck_ri.fCreatePermalinkUrl(vv.vorschriftid) as PERMALINK',
'',
'from T_H_VORSCHRIFT_REF_VORSCHRIFT vrv',
'left outer join t_benutzer b on (b.benutzerid = vrv.letzte_aenderung_benutzerid)',
'left outer join t_vorschrift vv on (vv.vorschriftid = vrv.vorgaenger_vorschriftid)',
'left outer join t_vorschrift nv on (nv.vorschriftid = vrv.nachfolger_vorschriftid)',
'left outer join t_beziehung_art ba on (ba.beziehung_artid = nvl(:P352_AMENDMENTID,vrv.beziehung_art))',
'left outer join t_vorschrift hv on (hv.vorschriftid = vrv.max_homologation_vorschriftid)',
'',
'where vrv.VORGAENGER_VORSCHRIFTID = :P352_VORSCHRIFTID or vrv.NACHFOLGER_VORSCHRIFTID = :P352_VORSCHRIFTID',
'order by vrv.LETZTE_AENDERUNG_DATUM desc',
'',
'',
''))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(756554308557965945)
,p_name=>'Historie Vorschrift Kerndaten'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>unistr('Es gibt keine historischen Verkn\00FCpfungen f\00FCr diese Vorschrift.')
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'mailto:#EMAIL#?body=#PERMALINK#'
,p_detail_link_text=>'<span class="fa fa-envelope-o" aria-hidden="true"></span></a>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>356138628537168459
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016287602154100404)
,p_db_column_name=>'VORSCHRIFT_REF_VORSCHRIFTID'
,p_display_order=>20
,p_column_identifier=>'AX'
,p_column_label=>'Vorschrift Ref Vorschriftid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016286352148100403)
,p_db_column_name=>'VORGAENGER_VORSCHRIFT'
,p_display_order=>50
,p_column_identifier=>'BA'
,p_column_label=>'Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016286008476100402)
,p_db_column_name=>'NACHFOLGER_VORSCHRIFT'
,p_display_order=>60
,p_column_identifier=>'BB'
,p_column_label=>'Verlinkte Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016285592438100402)
,p_db_column_name=>'BEZIEHUNG_ART'
,p_display_order=>70
,p_column_identifier=>'BC'
,p_column_label=>'Art der Beziehung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016285159069100401)
,p_db_column_name=>'DATUM_IN_KRAFT'
,p_display_order=>90
,p_column_identifier=>'BD'
,p_column_label=>'In Kraftsetzung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016284782598100401)
,p_db_column_name=>'DATUM_NEUE_TYPEN'
,p_display_order=>100
,p_column_identifier=>'BE'
,p_column_label=>'Einsatztermin neue Typen'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016284363070100401)
,p_db_column_name=>'DATUM_ALLE_TYPEN'
,p_display_order=>110
,p_column_identifier=>'BF'
,p_column_label=>'Einsatztermin alle Fahrzeuge'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016283963214100400)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>120
,p_column_identifier=>'BG'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016283546188100400)
,p_db_column_name=>'HOMOLOGATION_SERIE'
,p_display_order=>130
,p_column_identifier=>'BH'
,p_column_label=>unistr('Homologation mit h\00F6herer Serie m\00F6glich')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016283147634100400)
,p_db_column_name=>'MAX_HOMOLOGATION_VORSCHRIFT'
,p_display_order=>140
,p_column_identifier=>'BI'
,p_column_label=>'Maximale Homologationsvorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016287143751100404)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>150
,p_column_identifier=>'AY'
,p_column_label=>unistr('\00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016286778296100403)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>160
,p_column_identifier=>'AZ'
,p_column_label=>unistr('\00C4nderung Datum')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(804986549346965101)
,p_db_column_name=>'AKTION'
,p_display_order=>170
,p_column_identifier=>'BL'
,p_column_label=>'Aktion'
,p_column_html_expression=>'<span class="fa #AKTION#" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(958145941627486314)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1003882514065808388)
,p_db_column_name=>'EMAIL'
,p_display_order=>180
,p_column_identifier=>'BJ'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1003882381801808387)
,p_db_column_name=>'PERMALINK'
,p_display_order=>190
,p_column_identifier=>'BK'
,p_column_label=>'Permalink'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(756536134203952772)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'964101'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LETZTE_AENDERUNG_BENUTZER:LETZTE_AENDERUNG_DATUM:AKTION:VORGAENGER_VORSCHRIFT:NACHFOLGER_VORSCHRIFT:BEZIEHUNG_ART:DATUM_IN_KRAFT:DATUM_NEUE_TYPEN:DATUM_ALLE_TYPEN:KOMMENTAR:HOMOLOGATION_SERIE:MAX_HOMOLOGATION_VORSCHRIFT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(683385780937621982)
,p_plug_name=>unistr('Historie Vorschrift Verkn\00FCpfungen')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select H_VORSCHRIFT_REF_VORSCHRIFTID,',
'    VORSCHRIFT_REF_VORSCHRIFTID,',
'    AKTION,',
'    pck_ri_history.fdiff(vv.vorschrift_nummer, LAG(vv.vorschrift_nummer) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc), aktion) as VORGAENGER_VORSCHRIFT,',
'    pck_ri_history.fdiff(nv.vorschrift_nummer, LAG(nv.vorschrift_nummer) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc), aktion) as NACHFOLGER_VORSCHRIFT,',
'    pck_ri_history.fdiff(ba.beziehung_art, LAG(ba.beziehung_art) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as BEZIEHUNG_ART,',
'    pck_ri_history.fdiff(to_char(vrv.DATUM_IN_KRAFT, ''DD.MM.YYYY''), LAG(to_char(vrv.DATUM_IN_KRAFT, ''DD.MM.YYYY'')) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as DATUM_IN_KR'
||'AFT,',
'    pck_ri_history.fdiff(to_char(vrv.DATUM_NEUE_TYPEN, ''DD.MM.YYYY''), LAG(to_char(vrv.DATUM_NEUE_TYPEN, ''DD.MM.YYYY'')) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as DATUM_N'
||'EUE_TYPEN,',
'    pck_ri_history.fdiff(to_char(vrv.DATUM_ALLE_TYPEN, ''DD.MM.YYYY''), LAG(to_char(vrv.DATUM_ALLE_TYPEN, ''DD.MM.YYYY'')) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as DATUM_A'
||'LLE_TYPEN,',
'    pck_ri_history.fdiff(vrv.KOMMENTAR, LAG(vrv.KOMMENTAR) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as KOMMENTAR,',
'    pck_ri_history.fdiff(case vrv.HOMOLOGATION_SERIE when 0 then ''nein'' when 10 then ''ja'' else to_char(vrv.HOMOLOGATION_SERIE) end , LAG(case vrv.HOMOLOGATION_SERIE when 0 then ''nein'' when 10 then ''ja'' else to_char(vrv.HOMOLOGATION_SERIE) end) over(p'
||'artition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc), aktion) as HOMOLOGATION_SERIE,    ',
'    pck_ri_history.fdiff(hv.vorschrift_nummer, LAG(hv.vorschrift_nummer) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as MAX_HOMOLOGATION_VORSCHRIFT,',
'    ',
'    nvl2(vrv.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) AS LETZTE_AENDERUNG_BENUTZER,',
'    vrv.LETZTE_AENDERUNG_DATUM as LETZTE_AENDERUNG_DATUM,',
'    b.EMAIL AS EMAIL,',
'    pck_ri.fCreatePermalinkUrl(vv.vorschriftid) as PERMALINK',
'',
'from T_H_VORSCHRIFT_REF_VORSCHRIFT vrv',
'left outer join t_benutzer b on (b.benutzerid = vrv.letzte_aenderung_benutzerid)',
'left outer join t_vorschrift vv on (vv.vorschriftid = vrv.vorgaenger_vorschriftid)',
'left outer join t_vorschrift nv on (nv.vorschriftid = vrv.nachfolger_vorschriftid)',
'left outer join t_beziehung_art ba on (ba.beziehung_artid = vrv.beziehung_art)',
'left outer join t_vorschrift hv on (hv.vorschriftid = vrv.max_homologation_vorschriftid)',
'',
'where vrv.VORGAENGER_VORSCHRIFTID = :P352_VORSCHRIFTID or vrv.NACHFOLGER_VORSCHRIFTID = :P352_VORSCHRIFTID',
'order by vrv.LETZTE_AENDERUNG_DATUM desc',
'',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P352_VORSCHRIFTID'
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P352_AMENDMENTID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Historie Vorschrift Verkn\00FCpfungen')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select H_VORSCHRIFT_REF_VORSCHRIFTID,',
'    VORSCHRIFT_REF_VORSCHRIFTID,',
'    AKTION,',
'    pck_ri_history.fdiff(vv.vorschrift_nummer, LAG(vv.vorschrift_nummer) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc), aktion) as VORGAENGER_VORSCHRIFT,',
'    pck_ri_history.fdiff(nv.vorschrift_nummer, LAG(nv.vorschrift_nummer) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc), aktion) as NACHFOLGER_VORSCHRIFT,',
'    pck_ri_history.fdiff(ba.beziehung_art, LAG(ba.beziehung_art) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as BEZIEHUNG_ART,',
'    pck_ri_history.fdiff(to_char(vrv.DATUM_IN_KRAFT, ''DD.MM.YYYY''), LAG(to_char(vrv.DATUM_IN_KRAFT, ''DD.MM.YYYY'')) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as DATUM_IN_KR'
||'AFT,',
'    pck_ri_history.fdiff(to_char(vrv.DATUM_NEUE_TYPEN, ''DD.MM.YYYY''), LAG(to_char(vrv.DATUM_NEUE_TYPEN, ''DD.MM.YYYY'')) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as DATUM_N'
||'EUE_TYPEN,',
'    pck_ri_history.fdiff(to_char(vrv.DATUM_ALLE_TYPEN, ''DD.MM.YYYY''), LAG(to_char(vrv.DATUM_ALLE_TYPEN, ''DD.MM.YYYY'')) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as DATUM_A'
||'LLE_TYPEN,',
'    pck_ri_history.fdiff(vrv.KOMMENTAR, LAG(vrv.KOMMENTAR) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as KOMMENTAR,',
'    pck_ri_history.fdiff(case vrv.HOMOLOGATION_SERIE when 0 then ''nein'' when 10 then ''ja'' else to_char(vrv.HOMOLOGATION_SERIE) end , LAG(case vrv.HOMOLOGATION_SERIE when 0 then ''nein'' when 10 then ''ja'' else to_char(vrv.HOMOLOGATION_SERIE) end) over(p'
||'artition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc), aktion) as HOMOLOGATION_SERIE,    ',
'    pck_ri_history.fdiff(hv.vorschrift_nummer, LAG(hv.vorschrift_nummer) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as MAX_HOMOLOGATION_VORSCHRIFT,',
'    ',
'    nvl2(vrv.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) AS LETZTE_AENDERUNG_BENUTZER,',
'    vrv.LETZTE_AENDERUNG_DATUM as LETZTE_AENDERUNG_DATUM,',
'    b.EMAIL AS EMAIL,',
'    pck_ri.fCreatePermalinkUrl(vv.vorschriftid) as PERMALINK',
'',
'from T_H_VORSCHRIFT_REF_VORSCHRIFT vrv',
'left outer join t_benutzer b on (b.benutzerid = vrv.letzte_aenderung_benutzerid)',
'left outer join t_vorschrift vv on (vv.vorschriftid = vrv.vorgaenger_vorschriftid)',
'left outer join t_vorschrift nv on (nv.vorschriftid = vrv.nachfolger_vorschriftid)',
'left outer join t_beziehung_art ba on (ba.beziehung_artid = nvl(:P352_AMENDMENTID,vrv.beziehung_art))',
'left outer join t_vorschrift hv on (hv.vorschriftid = vrv.max_homologation_vorschriftid)',
'',
'where vrv.VORGAENGER_VORSCHRIFTID = :P352_VORSCHRIFTID or vrv.NACHFOLGER_VORSCHRIFTID = :P352_VORSCHRIFTID',
'order by vrv.LETZTE_AENDERUNG_DATUM desc',
'',
'',
''))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(683385646584621981)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>unistr('Es gibt keine historischen Verkn\00FCpfungen f\00FCr diese Vorschrift.')
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'mailto:#EMAIL#?body=#PERMALINK#'
,p_detail_link_text=>'<span class="fa fa-envelope-o" aria-hidden="true"></span></a>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>429307290510512423
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683385626532621980)
,p_db_column_name=>'VORSCHRIFT_REF_VORSCHRIFTID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Vorschrift Ref Vorschriftid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683385479872621979)
,p_db_column_name=>'VORGAENGER_VORSCHRIFT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683385415535621978)
,p_db_column_name=>'NACHFOLGER_VORSCHRIFT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Verlinkte Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683385273848621977)
,p_db_column_name=>'BEZIEHUNG_ART'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Art der Beziehung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683385147843621976)
,p_db_column_name=>'DATUM_IN_KRAFT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'In Kraftsetzung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683385074731621975)
,p_db_column_name=>'DATUM_NEUE_TYPEN'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Einsatztermin neue Typen'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683384992711621974)
,p_db_column_name=>'DATUM_ALLE_TYPEN'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Einsatztermin alle Fahrzeuge'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683384900414621973)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683384801947621972)
,p_db_column_name=>'HOMOLOGATION_SERIE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('Homologation mit h\00F6herer Serie m\00F6glich')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683384664182621971)
,p_db_column_name=>'MAX_HOMOLOGATION_VORSCHRIFT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Maximale Homologationsvorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683384595894621970)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>unistr('\00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683384519359621969)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>unistr('\00C4nderung Datum')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683384414761621968)
,p_db_column_name=>'AKTION'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Aktion'
,p_column_html_expression=>'<span class="fa #AKTION#" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(958145941627486314)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683384252328621967)
,p_db_column_name=>'EMAIL'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683384223017621966)
,p_db_column_name=>'PERMALINK'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Permalink'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682710424683316196)
,p_db_column_name=>'H_VORSCHRIFT_REF_VORSCHRIFTID'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'H Vorschrift Ref Vorschriftid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(682697611823291481)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4299954'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LETZTE_AENDERUNG_BENUTZER:LETZTE_AENDERUNG_DATUM:AKTION:VORGAENGER_VORSCHRIFT:NACHFOLGER_VORSCHRIFT:BEZIEHUNG_ART:DATUM_IN_KRAFT:DATUM_NEUE_TYPEN:DATUM_ALLE_TYPEN:KOMMENTAR:HOMOLOGATION_SERIE:MAX_HOMOLOGATION_VORSCHRIFT:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(683384118457621965)
,p_plug_name=>'Historie Vorschrift Amendment'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH cte AS (',
'    SELECT vrv.VORSCHRIFT_REF_VORSCHRIFTID,',
'        vrv.beziehung_art artid,',
'        vrv.AKTION,',
'        pck_ri_history.fdiff(vv.vorschrift_nummer, LAG(vv.vorschrift_nummer) OVER (PARTITION BY vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID ORDER BY vrv.letzte_aenderung_datum ASC), vrv.aktion) AS VORGAENGER_VORSCHRIFT,',
'        pck_ri_history.fdiff(nv.vorschrift_nummer, LAG(nv.vorschrift_nummer) OVER (PARTITION BY vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID ORDER BY vrv.letzte_aenderung_datum ASC), vrv.aktion) AS NACHFOLGER_VORSCHRIFT,',
'        pck_ri_history.fdiff(ba.beziehung_art, LAG(ba.beziehung_art) OVER (PARTITION BY vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID ORDER BY vrv.letzte_aenderung_datum ASC)) AS BEZIEHUNG_ART,',
'        pck_ri_history.fdiff(TO_CHAR(vrv.DATUM_IN_KRAFT, ''DD.MM.YYYY''), LAG(TO_CHAR(vrv.DATUM_IN_KRAFT, ''DD.MM.YYYY'')) OVER (PARTITION BY vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID ORDER BY vrv.letzte_aenderung_datum ASC)) AS DATUM_'
||'IN_KRAFT,',
'        pck_ri_history.fdiff(TO_CHAR(vrv.DATUM_NEUE_TYPEN, ''DD.MM.YYYY''), LAG(TO_CHAR(vrv.DATUM_NEUE_TYPEN, ''DD.MM.YYYY'')) OVER (PARTITION BY vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID ORDER BY vrv.letzte_aenderung_datum ASC)) AS DA'
||'TUM_NEUE_TYPEN,',
'        pck_ri_history.fdiff(TO_CHAR(vrv.DATUM_ALLE_TYPEN, ''DD.MM.YYYY''), LAG(TO_CHAR(vrv.DATUM_ALLE_TYPEN, ''DD.MM.YYYY'')) OVER (PARTITION BY vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID ORDER BY vrv.letzte_aenderung_datum ASC)) AS DA'
||'TUM_ALLE_TYPEN,',
'        pck_ri_history.fdiff(vrv.KOMMENTAR, LAG(vrv.KOMMENTAR) OVER (PARTITION BY vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID ORDER BY vrv.letzte_aenderung_datum ASC)) AS KOMMENTAR,',
'        pck_ri_history.fdiff(CASE vrv.HOMOLOGATION_SERIE WHEN 0 THEN ''nein'' WHEN 10 THEN ''ja'' ELSE TO_CHAR(vrv.HOMOLOGATION_SERIE) END, LAG(CASE vrv.HOMOLOGATION_SERIE WHEN 0 THEN ''nein'' WHEN 10 THEN ''ja'' ELSE TO_CHAR(vrv.HOMOLOGATION_SERIE) END) OVE'
||'R (PARTITION BY vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID ORDER BY vrv.letzte_aenderung_datum ASC), vrv.aktion) AS HOMOLOGATION_SERIE,',
'        pck_ri_history.fdiff(hv.vorschrift_nummer, LAG(hv.vorschrift_nummer) OVER (PARTITION BY vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID ORDER BY vrv.letzte_aenderung_datum ASC)) AS MAX_HOMOLOGATION_VORSCHRIFT,',
'        NVL2(vrv.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, NULL) AS LETZTE_AENDERUNG_BENUTZER,',
'        vrv.LETZTE_AENDERUNG_DATUM,',
'        b.EMAIL,',
'        pck_ri.fCreatePermalinkUrl(vv.vorschriftid) AS PERMALINK',
'    FROM T_H_VORSCHRIFT_REF_VORSCHRIFT vrv',
'    LEFT JOIN t_benutzer b ON b.benutzerid = vrv.letzte_aenderung_benutzerid',
'    LEFT JOIN t_vorschrift vv ON vv.vorschriftid = vrv.vorgaenger_vorschriftid',
'    LEFT JOIN t_vorschrift nv ON nv.vorschriftid = vrv.nachfolger_vorschriftid',
'    LEFT JOIN t_beziehung_art ba ON ba.beziehung_artid = vrv.beziehung_art',
'    LEFT JOIN t_vorschrift hv ON hv.vorschriftid = vrv.max_homologation_vorschriftid',
'    WHERE vrv.VORGAENGER_VORSCHRIFTID = :P352_VORSCHRIFTID OR vrv.NACHFOLGER_VORSCHRIFTID = :P352_VORSCHRIFTID',
'    ORDER BY vrv.LETZTE_AENDERUNG_DATUM DESC',
')',
'SELECT VORSCHRIFT_REF_VORSCHRIFTID,',
'    AKTION, VORGAENGER_VORSCHRIFT, NACHFOLGER_VORSCHRIFT, BEZIEHUNG_ART, DATUM_IN_KRAFT, DATUM_NEUE_TYPEN,',
'    DATUM_ALLE_TYPEN, KOMMENTAR, HOMOLOGATION_SERIE, MAX_HOMOLOGATION_VORSCHRIFT, LETZTE_AENDERUNG_BENUTZER, LETZTE_AENDERUNG_DATUM, EMAIL, PERMALINK',
'FROM cte',
'WHERE artid = :P352_AMENDMENTID',
'   OR VORSCHRIFT_REF_VORSCHRIFTID IN (',
'       SELECT VORSCHRIFT_REF_VORSCHRIFTID',
'       FROM T_H_VORSCHRIFT_REF_VORSCHRIFT',
'       WHERE beziehung_art = :P352_AMENDMENTID',
'         AND (VORGAENGER_VORSCHRIFTID = :P352_VORSCHRIFTID OR NACHFOLGER_VORSCHRIFTID = :P352_VORSCHRIFTID)',
'   );'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P352_VORSCHRIFTID,P352_AMENDMENTID'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P352_AMENDMENTID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Historie Vorschrift Amendment'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select H_VORSCHRIFT_REF_VORSCHRIFTID,',
'    VORSCHRIFT_REF_VORSCHRIFTID,',
'    AKTION,',
'    pck_ri_history.fdiff(vv.vorschrift_nummer, LAG(vv.vorschrift_nummer) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc), aktion) as VORGAENGER_VORSCHRIFT,',
'    pck_ri_history.fdiff(nv.vorschrift_nummer, LAG(nv.vorschrift_nummer) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc), aktion) as NACHFOLGER_VORSCHRIFT,',
'    pck_ri_history.fdiff(ba.beziehung_art, LAG(ba.beziehung_art) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as BEZIEHUNG_ART,',
'    pck_ri_history.fdiff(to_char(vrv.DATUM_IN_KRAFT, ''DD.MM.YYYY''), LAG(to_char(vrv.DATUM_IN_KRAFT, ''DD.MM.YYYY'')) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as DATUM_IN_KR'
||'AFT,',
'    pck_ri_history.fdiff(to_char(vrv.DATUM_NEUE_TYPEN, ''DD.MM.YYYY''), LAG(to_char(vrv.DATUM_NEUE_TYPEN, ''DD.MM.YYYY'')) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as DATUM_N'
||'EUE_TYPEN,',
'    pck_ri_history.fdiff(to_char(vrv.DATUM_ALLE_TYPEN, ''DD.MM.YYYY''), LAG(to_char(vrv.DATUM_ALLE_TYPEN, ''DD.MM.YYYY'')) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as DATUM_A'
||'LLE_TYPEN,',
'    pck_ri_history.fdiff(vrv.KOMMENTAR, LAG(vrv.KOMMENTAR) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as KOMMENTAR,',
'    pck_ri_history.fdiff(case vrv.HOMOLOGATION_SERIE when 0 then ''nein'' when 10 then ''ja'' else to_char(vrv.HOMOLOGATION_SERIE) end , LAG(case vrv.HOMOLOGATION_SERIE when 0 then ''nein'' when 10 then ''ja'' else to_char(vrv.HOMOLOGATION_SERIE) end) over(p'
||'artition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc), aktion) as HOMOLOGATION_SERIE,    ',
'    pck_ri_history.fdiff(hv.vorschrift_nummer, LAG(hv.vorschrift_nummer) over(partition by vrv.VORGAENGER_VORSCHRIFTID, vrv.VORSCHRIFT_REF_VORSCHRIFTID order by vrv.letzte_aenderung_datum asc)) as MAX_HOMOLOGATION_VORSCHRIFT,',
'    ',
'    nvl2(vrv.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) AS LETZTE_AENDERUNG_BENUTZER,',
'    vrv.LETZTE_AENDERUNG_DATUM as LETZTE_AENDERUNG_DATUM,',
'    b.EMAIL AS EMAIL,',
'    pck_ri.fCreatePermalinkUrl(vv.vorschriftid) as PERMALINK',
'',
'from T_H_VORSCHRIFT_REF_VORSCHRIFT vrv',
'left outer join t_benutzer b on (b.benutzerid = vrv.letzte_aenderung_benutzerid)',
'left outer join t_vorschrift vv on (vv.vorschriftid = vrv.vorgaenger_vorschriftid)',
'left outer join t_vorschrift nv on (nv.vorschriftid = vrv.nachfolger_vorschriftid)',
'left outer join t_beziehung_art ba on (ba.beziehung_artid = nvl(:P352_AMENDMENTID,vrv.beziehung_art))',
'left outer join t_vorschrift hv on (hv.vorschriftid = vrv.max_homologation_vorschriftid)',
'',
'where vrv.VORGAENGER_VORSCHRIFTID = :P352_VORSCHRIFTID or vrv.NACHFOLGER_VORSCHRIFTID = :P352_VORSCHRIFTID',
'order by vrv.LETZTE_AENDERUNG_DATUM desc',
'',
'',
''))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(683383959949621964)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>unistr('Es gibt keine historischen Verkn\00FCpfungen f\00FCr diese Vorschrift.')
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'mailto:#EMAIL#?body=#PERMALINK#'
,p_detail_link_text=>'<span class="fa fa-envelope-o" aria-hidden="true"></span></a>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>429308977145512440
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683383868071621963)
,p_db_column_name=>'VORSCHRIFT_REF_VORSCHRIFTID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Vorschrift Ref Vorschriftid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683383795997621962)
,p_db_column_name=>'VORGAENGER_VORSCHRIFT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683383703445621961)
,p_db_column_name=>'NACHFOLGER_VORSCHRIFT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Verlinkte Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683383542398621960)
,p_db_column_name=>'BEZIEHUNG_ART'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Art der Beziehung'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683383525470621959)
,p_db_column_name=>'DATUM_IN_KRAFT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'In Kraftsetzung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'NEVER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683383394926621958)
,p_db_column_name=>'DATUM_NEUE_TYPEN'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Einsatztermin neue Typen'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'NEVER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683383321737621957)
,p_db_column_name=>'DATUM_ALLE_TYPEN'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Einsatztermin alle Fahrzeuge'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'NEVER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683383165618621956)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683383055054621955)
,p_db_column_name=>'HOMOLOGATION_SERIE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('Homologation mit h\00F6herer Serie m\00F6glich')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'NEVER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683382945915621954)
,p_db_column_name=>'MAX_HOMOLOGATION_VORSCHRIFT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Maximale Homologationsvorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'NEVER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682711116832316203)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>unistr('\00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682710973103316202)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>unistr('\00C4nderung Datum')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682710881522316201)
,p_db_column_name=>'AKTION'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Aktion'
,p_column_html_expression=>'<span class="fa #AKTION#" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(958145941627486314)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682710787270316200)
,p_db_column_name=>'EMAIL'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(682710714733316199)
,p_db_column_name=>'PERMALINK'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Permalink'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(682696941023291449)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4299960'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LETZTE_AENDERUNG_BENUTZER:LETZTE_AENDERUNG_DATUM:AKTION:VORGAENGER_VORSCHRIFT:NACHFOLGER_VORSCHRIFT:DATUM_IN_KRAFT:DATUM_NEUE_TYPEN:DATUM_ALLE_TYPEN:KOMMENTAR:HOMOLOGATION_SERIE:MAX_HOMOLOGATION_VORSCHRIFT:'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1016282399250100398)
,p_name=>'P352_VORSCHRIFTID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(684045643619613892)
,p_name=>'P352_AMENDMENTID'
,p_item_sequence=>20
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(682710291569316195)
,p_name=>'Show / Hide Reports'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P352_AMENDMENTID'
,p_condition_element=>'P352_AMENDMENTID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(682710222294316194)
,p_event_id=>wwv_flow_imp.id(682710291569316195)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(683384118457621965)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(682709753591316190)
,p_event_id=>wwv_flow_imp.id(682710291569316195)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(683385780937621982)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(682709951978316192)
,p_event_id=>wwv_flow_imp.id(682710291569316195)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(683385780937621982)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(682709863881316191)
,p_event_id=>wwv_flow_imp.id(682710291569316195)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(683384118457621965)
);
wwv_flow_imp.component_end;
end;
/
