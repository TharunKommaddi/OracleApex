prompt --application/pages/page_00355
begin
--   Manifest
--     PAGE: 00355
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>355
,p_name=>unistr('\00C4nderungshistorie Vorschrift L\00E4nder und Themen')
,p_alias=>unistr('\00C4NDERUNGSHISTORIE-VORSCHRIFT-L\00C4NDER-UND-THEMEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('\00C4nderungshistorie Vorschrift L\00E4nder und Themen')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IR_HIST .t-fht-tbody {max-height: calc(100vh - 200px)}',
'.t-Body-topButton {display: none !important}',
'.t-Body-content {padding-bottom: 3px !important}',
'.t-Body {margin-bottom: 3px !important}',
'.t-Body-contentInner {padding-bottom: 0px !important}'))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(747565855788905605)
,p_plug_name=>unistr('Historie Vorschrift L\00E4nder und Themen')
,p_region_name=>'IR_HIST'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with hist_records as (',
'    select vtl.h_vorschrift_ref_thema_ref_landid, ',
'    vtl.VORSCHRIFT_REF_THEMA_REF_LANDID,',
'    ',
'    case vtl.geloescht when 0 then v.VORSCHRIFT_NUMMER else null end as VORSCHRIFT, case vtl.geloescht when 1 then LAG(v.VORSCHRIFT_NUMMER) over(partition by vtl.vorschriftid , vtl.themaid, vtl.landid order by vtl.letzte_aenderung_datum asc) else nul'
||'l end as VORSCHRIFT_H,',
'    case vtl.geloescht when 0 then t.bezeichnung else null end as THEMA, case vtl.geloescht when 1 then LAG(t.bezeichnung) over(partition by vtl.vorschriftid , vtl.themaid, vtl.landid order by vtl.letzte_aenderung_datum asc) else null end as THEMA_H,',
'    case vtl.geloescht when 0 then l.B_NUMMER || '' - '' || CASE ',
'          WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.land',
'               ELSE l.land_eng',
'            END',
'        else null end as LAND, ',
'    case vtl.geloescht when 1 then LAG(l.B_NUMMER || '' - '' || CASE ',
'       WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.land',
'       ELSE l.land_eng',
'        END) over(partition by vtl.vorschriftid , vtl.themaid, vtl.landid order by vtl.letzte_aenderung_datum asc) else null end as LAND_H,',
'    case vtl.geloescht when 0 then vtl.BEMERKUNG else null end as BEMERKUNG, case vtl.geloescht when 1 then LAG(vtl.BEMERKUNG) over(partition by vtl.vorschriftid , vtl.themaid, vtl.landid order by vtl.letzte_aenderung_datum asc) else null end as BEME'
||'RKUNG_H,',
'    case vtl.geloescht when 0 then ''nein'' when 1 then ''ja'' end as GELOESCHT, lag(case vtl.GELOESCHT when 0 then ''nein'' when 1 then ''ja'' end) over(partition by vtl.vorschriftid , vtl.themaid, vtl.landid order by vtl.letzte_aenderung_datum asc) as GELO'
||'ESCHT_H,',
'    ',
'    vtl.letzte_aenderung_datum as letzte_aenderung_datum,',
'    pck_ri.fCreatePermalinkUrl(vtl.vorschriftid) as PERMALINK,',
'    b.email as EMAIL,',
'    nvl2(vtl.letzte_aenderung_benutzerid, b.nachname || '', '' || b.vorname, null) AS LETZTE_AENDERUNG_BENUTZER',
'    from T_H_VORSCHRIFT_REF_THEMA_REF_LAND vtl',
'    left outer join t_benutzer b on (b.benutzerid = vtl.letzte_aenderung_benutzerid)',
'    left outer join t_vorschrift v on (v.vorschriftid = vtl.vorschriftid)',
'    left outer join t_thema t on (t.themaid = vtl.themaid)',
'    left outer join t_land l on (l.landid = vtl.landid)',
'    where vtl.VORSCHRIFTID = :P355_VORSCHRIFTID',
'), changed_hist_records as (',
'    select c.* from hist_records c where c.geloescht_h is null or c.geloescht <> c.geloescht_h',
'), highlight_changes as (',
'    select hist_data.H_VORSCHRIFT_REF_THEMA_REF_LANDID,',
'       hist_data.VORSCHRIFT_REF_THEMA_REF_LANDID,',
'       pck_ri_history.fdiff(hist_data.VORSCHRIFT, hist_data.VORSCHRIFT_H) as VORSCHRIFT,',
'       pck_ri_history.fdiff(hist_data.THEMA, hist_data.THEMA_H) as THEMA,',
'       pck_ri_history.fdiff(hist_data.LAND, hist_data.LAND_H) as LAND,',
'       pck_ri_history.fdiff(hist_data.BEMERKUNG, hist_data.BEMERKUNG_H) as BEMERKUNG,',
'       pck_ri_history.fdiff(hist_data.GELOESCHT, hist_data.GELOESCHT_H) as GELOESCHT,',
'',
'       hist_data.letzte_aenderung_datum as letzte_aenderung_datum,',
'       hist_data.permalink as PERMALINK,',
'       hist_data.email as EMAIL,',
'       hist_data.LETZTE_AENDERUNG_BENUTZER AS LETZTE_AENDERUNG_BENUTZER',
'',
'    from changed_hist_records hist_data ',
')    ',
'',
'select min(H_VORSCHRIFT_REF_THEMA_REF_LANDID) as H_VORSCHRIFT_REF_THEMA_REF_LANDID,',
'       min(VORSCHRIFT_REF_THEMA_REF_LANDID) as VORSCHRIFT_REF_THEMA_REF_LANDID,',
'       VORSCHRIFT,',
'       listagg(THEMA, '', '' ON OVERFLOW TRUNCATE) AS THEMA,',
'       --listagg(LAND, '', '') AS LAND,',
'       LAND AS LAND,',
'       BEMERKUNG,',
'       GELOESCHT,',
'',
'       letzte_aenderung_datum,',
'       PERMALINK,',
'       EMAIL,',
'       LETZTE_AENDERUNG_BENUTZER',
'',
'from highlight_changes',
'group by LETZTE_AENDERUNG_BENUTZER, letzte_aenderung_datum, VORSCHRIFT, LAND, BEMERKUNG, GELOESCHT, PERMALINK, EMAIL',
'order by LETZTE_AENDERUNG_DATUM desc',
'',
'   '))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Historie Vorschrift L\00E4nder und Themen')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(747565779251905605)
,p_name=>'Historie Vorschrift Kerndaten'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>unistr('Es wurden noch keine L\00E4nder oder Themen zugeordnet.')
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>600
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'mailto:#EMAIL#?body=#PERMALINK#'
,p_detail_link_text=>'<span class="fa fa-envelope-o" aria-hidden="true"></span>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>365127157843228799
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1018766971175826420)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>352
,p_column_identifier=>'AJ'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1018764592516826417)
,p_db_column_name=>'EMAIL'
,p_display_order=>432
,p_column_identifier=>'AQ'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1018764139760826417)
,p_db_column_name=>'PERMALINK'
,p_display_order=>442
,p_column_identifier=>'AR'
,p_column_label=>'Permalink'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1018763765336826415)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>452
,p_column_identifier=>'AS'
,p_column_label=>unistr('\00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1018763405180826415)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>462
,p_column_identifier=>'AT'
,p_column_label=>unistr('\00C4nderung Datum')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1020289752716660167)
,p_db_column_name=>'H_VORSCHRIFT_REF_THEMA_REF_LANDID'
,p_display_order=>472
,p_column_identifier=>'AU'
,p_column_label=>'H Vorschrift Ref Thema Ref Landid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1020289683548660166)
,p_db_column_name=>'VORSCHRIFT_REF_THEMA_REF_LANDID'
,p_display_order=>482
,p_column_identifier=>'AV'
,p_column_label=>'Vorschrift Ref Thema Ref Landid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1020289566424660165)
,p_db_column_name=>'VORSCHRIFT'
,p_display_order=>492
,p_column_identifier=>'AW'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1020289506774660164)
,p_db_column_name=>'THEMA'
,p_display_order=>502
,p_column_identifier=>'AX'
,p_column_label=>'Themen'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1020289359497660163)
,p_db_column_name=>'LAND'
,p_display_order=>512
,p_column_identifier=>'AY'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1020289309710660162)
,p_db_column_name=>'GELOESCHT'
,p_display_order=>522
,p_column_identifier=>'AZ'
,p_column_label=>unistr('Gel\00F6scht')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(747547604897892432)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'939307'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LETZTE_AENDERUNG_BENUTZER:LETZTE_AENDERUNG_DATUM:VORSCHRIFT:THEMA:LAND:BEMERKUNG:GELOESCHT:'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1018761807484826396)
,p_name=>'P355_VORSCHRIFTID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(747565855788905605)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
