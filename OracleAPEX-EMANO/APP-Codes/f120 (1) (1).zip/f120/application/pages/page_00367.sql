prompt --application/pages/page_00367
begin
--   Manifest
--     PAGE: 00367
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>367
,p_name=>unistr('Motor Getriebe Varianten w\00E4hlen')
,p_alias=>unistr('MOTOR-GETRIEBE-VARIANTEN-W\00C4HLEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Motor Getriebe Varianten w\00E4hlen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function fAddButtons() {',
unistr('    $(''#VSIG tr td:nth-child(4).t-Report-cell'').append(''<nobr> <span class="fa fa-share-square-o" aria-hidden="true" title="Datum SOP/ME \00FCbernehmen"></span></nobr>'');'),
'',
unistr('    $(''#VSIG tr td:nth-child(5).t-Report-cell'').append(''<nobr> <span class="fa fa-share-square-o" aria-hidden="true" title="Datum EOP/ME \00FCbernehmen"></span></nobr>'');'),
'',
'    /*$(''#VSIG tr td:nth-child(1).t-Report-cell input[type="checkbox"]'').change(function() {',
'',
'        if($(this).is('':checked'')) {',
'            if ($(this).closest(''tr'').find(''td:nth-child(5).t-Report-cell nobr'').length == 0) {',
unistr('                $(this).closest(''tr'').find(''td:nth-child(5).t-Report-cell'').append(''<nobr> <span class="fa fa-share-square-o" aria-hidden="true" title="Datum EOP \00FCbernehmen"></span></nobr>'');    '),
'            }',
'        } ',
'',
'    });*/',
'',
'    $(''#VSIG tr th:nth-child(1).t-Report-colHead input[type="checkbox"]'').change(function() {',
'        console.log(''Header Checkbox geklicke!'');',
'        if($(this).is('':checked'')) {',
'            console.log(''true'');',
'            $(''td.t-Report-cell input[type="checkbox"]:not(:checked)'').click();',
unistr('            //$(''#VSIG tr td:nth-child(5).t-Report-cell:not(:has(>nobr))'').append(''<nobr> <span class="fa fa-share-square-o" aria-hidden="true" title="Datum EOP \00FCbernehmen"></span></nobr>'');    '),
'        } else {',
'            $(''td.t-Report-cell input[type="checkbox"]:checked'').click();  ',
'            console.log(''false'');          ',
'        }',
'        /*else {',
'            $(''#VSIG tr td:nth-child(5).t-Report-cell nobr'').remove();    ',
'        }*/',
'    });',
'',
'}',
'',
'',
'function fMinMax() {',
'    /* minimales SOP datum */',
'    let min_date = '''';',
'    $(''tr td:nth-child(4).t-Report-cell'').each(function() {',
'        var this_date;',
'        if ($(this).text().trim().length > 0) {',
'            this_date = $.datepicker.parseDate(''dd.mm.yy'', $(this).text());    ',
'        } else {',
'            this_date = null;',
'        }',
'',
'        if ((!min_date && this_date) || (this_date && this_date < min_date)) {',
'            min_date = this_date;',
'        }',
'    });',
'',
'    let min_date_string = $.datepicker.formatDate(''dd.mm.yy'', min_date);',
'    $(''tr td:nth-child(4)'').each(function() {',
'    if ($(this).text() == min_date_string) {',
'        $(this).css(''background-color'', ''lightblue'');',
'        $(this).css(''font-weight'', ''bold'');',
'    }',
'        ',
'    });',
'',
'    /* maximales EOP Datum */',
'    let max_date = '''';',
'    $(''tr td:nth-child(5).t-Report-cell'').each(function() {',
'        var this_date;',
'        if ($(this).text().trim().length > 0) {',
'            this_date = $.datepicker.parseDate(''dd.mm.yy'', $(this).text());    ',
'        } else {',
'            this_date = null;',
'        }',
'        if ((!max_date && this_date) || (this_date && this_date > max_date)) {',
'            max_date = this_date;',
'        }',
'    });',
'',
'    let max_date_string = $.datepicker.formatDate(''dd.mm.yy'', max_date);',
'    $(''tr td:nth-child(5)'').each(function() {',
'    if ($(this).text() == max_date_string) {',
'        //alert(min_date_string);',
'        $(this).css(''background-color'', ''lightblue'');',
'        $(this).css(''font-weight'', ''bold'');',
'    }',
'        ',
'    });',
'}',
'',
'',
'function fSetLaender() {',
'    var any_checked = $("#VSIG").find("td input:checked").length > 0;',
'',
'    if (any_checked) {',
'        $("#b_next").removeClass("apex_disabled");',
'    } else {',
'        $("#b_next").addClass("apex_disabled");',
'    }',
'',
'    $("#b_next").prop(''disabled'', !any_checked);',
'',
'    var sel_laender = apex.item(''P367_BNUMMERN'');',
'    let available_eop = apex.item(''P367_AVAILABLE_EOPS'');',
'',
'    var set_eops = new Set();',
'    var set_selected_laender = new Set();',
'    $("#VSIG").find("td input:checked").each(function() {',
'        let jsonObject = JSON.parse(this.value);    ',
'',
'        let bnummern = jsonObject.bnummern.split('':'');',
'        bnummern.forEach(item => set_selected_laender.add(item));',
'',
'        if (jsonObject.eop != ''&nbsp;'') {',
'        set_eops.add(jsonObject.eop);',
'        }       ',
'',
'    });',
'',
'    sel_laender.setValue(Array.from(set_selected_laender).join('':''));',
'',
'    let str_eops = Array.from(set_eops).join('':'');',
'    available_eop.setValue(str_eops);',
'',
'    apex.server.process(''DUMMY_PROCESS'', {',
'        pageItems: ''#P367_BNUMMERN''',
'    },{dataType: "text"});',
'',
'}'))
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_dialog_height=>'400'
,p_dialog_chained=>'N'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(262357774798012559)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(902112785903569023)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(262357886626012559)
,p_plug_name=>'Step 2'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(233282128489417707)
,p_name=>'Motor Getriebe Varianten'
,p_region_name=>'VSIG'
,p_parent_plug_id=>wwv_flow_imp.id(262357886626012559)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    select  /*+ driving_site(bp) */ fp_kpb, fp_bezeichnung, SM_NOMENKLATUR, ltue_sop, ltue_eop,b_nummer tpl_name, ltue_deleted, ltue_von',
'   /*  from mv_x_falko2 mv2--for Dev Env*/',
'     -- for T and P Env',
'     from carmah_admin.t_falko_basis_projekt bp',
'    join carmah_admin.t_falko_ltue l on (l.falko_basis_projekt_id = bp.falko_basis_projekt_id)',
'    join carmah_admin.t_typpruefland tpl on (l.typpruefland_id = tpl.typpruefland_id)',
'    join apex_string.split_numbers(:P366_SELECTED_KPB, '':'') x on (bp.kpb_id = x.column_value)',
'    where kpb_id in (select column_value from table(apex_string.split_numbers(:P366_SELECTED_KPB, '':'')))',
'),',
'cte2 as (',
'    select distinct fp_kpb, ltue_sop, ltue_eop, tpl_name, ltue_deleted',
'    from cte1',
'),',
'cte3 as (',
'    select distinct fp_kpb, ltue_sop, ltue_eop, SM_NOMENKLATUR, ltue_deleted',
'    from cte1',
'),',
'cte4 as (',
'    select fp_kpb, ltue_sop, ltue_eop, listagg(SM_NOMENKLATUR, ''<br />'') as SM_NOMENKLATUR, ltue_deleted',
'    from cte3 ',
'    group by fp_kpb, ltue_sop, ltue_eop, ltue_deleted',
')',
'select n.fp_kpb as fp_kpb, n.SM_NOMENKLATUR as SM_NOMENKLATUR, ',
'        cte2.ltue_sop, cte2.ltue_eop, case when cte2.ltue_deleted = 0 then ''nein'' else ''ja'' end as ltue_deleted,',
'        listagg(cte2.tpl_name || '' - '' || l.land, '', '') within group (order by tpl_name) as b_nummern,',
'        listagg(l.landid, '':'') within group (order by tpl_name) as laender',
'from cte2',
'left outer join t_land l on l.b_nummer = cte2.tpl_name --and l.STARTDATUM_TYP =:P367_SOPEOPID',
'-- left outer join cte4 n on (((n.ltue_sop  = cte2.ltue_sop) or (n.ltue_sop is null and cte2.ltue_sop is null)) ',
'--                            and ((n.ltue_eop = cte2.ltue_eop)or (n.ltue_eop is null and cte2.ltue_eop is null)) ',
'--                            and n.fp_kpb = cte2.fp_kpb and n.ltue_deleted = cte2.ltue_deleted)',
'-- left outer join cte4 n on (((nvl(n.ltue_sop, ''-1'') = nvl(cte2.ltue_sop, ''-1'')) /*or (n.ltue_sop is null and cte2.ltue_sop is null)*/) ',
'--                            and ((nvl(n.ltue_eop, ''-1'') = nvl(cte2.ltue_eop, ''-1'')) /*or (n.ltue_eop is null and cte2.ltue_eop is null)*/) ',
'--                            and n.fp_kpb = cte2.fp_kpb and n.ltue_deleted = cte2.ltue_deleted)',
'',
'left outer join cte4 n on (((n.ltue_sop = cte2.ltue_sop) or (n.ltue_sop is null and cte2.ltue_sop is null)) ',
'                           and ((n.ltue_eop = cte2.ltue_eop) or (n.ltue_eop is null and cte2.ltue_eop is null)) ',
'                           and n.fp_kpb = cte2.fp_kpb and n.ltue_deleted = cte2.ltue_deleted)',
'',
'where  l.STARTDATUM_TYP =:P367_SOPEOPID',
'group by n.fp_kpb, n.SM_NOMENKLATUR, cte2.ltue_sop, cte2.ltue_eop, cte2.ltue_deleted',
'order by cte2.ltue_deleted asc'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P367_SOPEOPID'
,p_lazy_loading=>true
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>1000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(857991222910950646)
,p_query_column_id=>1
,p_column_alias=>'FP_KPB'
,p_column_display_sequence=>2
,p_column_heading=>'KPB'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(857990760298950645)
,p_query_column_id=>2
,p_column_alias=>'SM_NOMENKLATUR'
,p_column_display_sequence=>3
,p_column_heading=>'Nomenklatur'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(857990395202950645)
,p_query_column_id=>3
,p_column_alias=>'LTUE_SOP'
,p_column_display_sequence=>4
,p_column_heading=>'SOP'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(857989951267950645)
,p_query_column_id=>4
,p_column_alias=>'LTUE_EOP'
,p_column_display_sequence=>5
,p_column_heading=>'EOP'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(857989566176950644)
,p_query_column_id=>5
,p_column_alias=>'LTUE_DELETED'
,p_column_display_sequence=>6
,p_column_heading=>unistr('Gel\00F6scht')
,p_column_alignment=>'CENTER'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(857989233565950643)
,p_query_column_id=>6
,p_column_alias=>'B_NUMMERN'
,p_column_display_sequence=>7
,p_column_heading=>'B-Nummern'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(857988821598950643)
,p_query_column_id=>7
,p_column_alias=>'LAENDER'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(857988417521950643)
,p_query_column_id=>8
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>1
,p_column_heading=>'<input type="checkbox" />'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<input type="checkbox" value=''{',
'"sop": "#LTUE_SOP#", ',
'"eop": "#LTUE_EOP#", ',
'"bnummern": "#LAENDER#"',
'}'' />',
'<!--<input type="checkbox" value="#LAENDER#" />-->'))
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(262358033002012559)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(857987696029950641)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(262358033002012559)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(857987333014950641)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(262358033002012559)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Daten \00FCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(857986875861950641)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(262358033002012559)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(857977934670950632)
,p_branch_action=>'f?p=&APP_ID.:366:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(857986875861950641)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(857995501946950654)
,p_name=>'P367_SELECTED_KPB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(262357886626012559)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Ausgew\00E4hlte KPBs')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(distinct bp.fp_kpb, '', '')',
'from table (apex_string.split(:P366_SELECTED_KPB, '':'')) x',
'join carmah_admin.t_falko_basis_projekt bp on (x.column_value = bp.kpb_id)',
'--join mv_x_falko2 bp on (x.column_value = bp.kpb_id)'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(857995073155950654)
,p_name=>'P367_SOPEOPID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(262357886626012559)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(857994669998950654)
,p_name=>'P367_SOP'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(262357886626012559)
,p_prompt=>'SOP/ME'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(857994243144950653)
,p_name=>'P367_EOP'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(262357886626012559)
,p_prompt=>'EOP/ME'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(857993875370950653)
,p_name=>'P367_HINWEIS1'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(262357886626012559)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Hinweis'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'CASE ',
'    WHEN :P367_SOPEOPID= 10 THEN ',
'        emano_util.fLang(',
unistr('            ''Sie haben die L\00E4nder ausgew\00E4hlt, die zu SOP geh\00F6ren.'', '),
'            ''You have selected the countries associated with SOP.''',
'        )',
'    WHEN :P367_SOPEOPID = 20 THEN ',
'        emano_util.fLang(',
unistr('            ''Sie haben die L\00E4nder ausgew\00E4hlt, die zu Markteinf\00FChrung(ME) geh\00F6ren.'', '),
'            ''You have selected the countries associated with MarketLaunch(ME).''',
'        )',
'END as message ',
'FROM dual;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(857993453684950653)
,p_name=>'P367_EOP_BACKUP'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(262357886626012559)
,p_prompt=>'EOP/ME'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>unistr('Bitte w\00E4hlen Sie mindestens eine Zeile aus der Tabelle, um ein EOP-Datum w\00E4hlen zu k\00F6nnen.')
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'lov values ',
'',
'select distinct column_value from table(apex_string.split(:P367_AVAILABLE_EOPS, '':''))',
'order by to_date(column_value, ''DD.MM.YYYY'') asc'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(857993051941950652)
,p_name=>'P367_AVAILABLE_EOPS'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(262357886626012559)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(857992713325950651)
,p_name=>'P367_BNUMMERN'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(262357886626012559)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(857992328440950651)
,p_name=>'P367_LAENDER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(262357886626012559)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('L\00E4nder')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(B_NUMMER || '' '' || LAND, '', '')',
'from T_LAND',
'where landid in (select distinct column_value from table (apex_string.split_numbers(:P367_BNUMMERN, '':'')))'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(857991881504950650)
,p_name=>'P367_KPBS_UEBERGABE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(262357886626012559)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(857986095527950639)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(857987696029950641)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(857985542250950638)
,p_event_id=>wwv_flow_imp.id(857986095527950639)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(857985322711950638)
,p_name=>'Row Selector'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'td input:checkbox'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#VSIG'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(857984826748950637)
,p_event_id=>wwv_flow_imp.id(857985322711950638)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var any_checked = $("#VSIG").find("td input:checked").length > 0;',
'',
'if (any_checked) {',
'    $("#b_next").removeClass("apex_disabled");',
'} else {',
'    $("#b_next").addClass("apex_disabled");',
'}',
'',
'$("#b_next").prop(''disabled'', !any_checked);',
'',
'var sel_laender = apex.item(''P367_BNUMMERN'');',
'let available_eop = apex.item(''P367_AVAILABLE_EOPS'');',
'',
'var set_eops = new Set();',
'var set_selected_laender = new Set();',
'$("#VSIG").find("td input:checked").each(function() {',
'    let jsonObject = JSON.parse(this.value);    ',
'',
'    let bnummern = jsonObject.bnummern.split('':'');',
'    bnummern.forEach(item => set_selected_laender.add(item));',
'',
'    if (jsonObject.eop != ''&nbsp;'') {',
'      set_eops.add(jsonObject.eop);',
'    }       ',
'',
'});',
'',
'sel_laender.setValue(Array.from(set_selected_laender).join('':''));',
'',
'let str_eops = Array.from(set_eops).join('':'');',
'available_eop.setValue(str_eops);',
'',
'apex.server.process(''DUMMY_PROCESS'', {',
'    pageItems: ''#P367_BNUMMERN''',
'},{dataType: "text"});',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(857984271038950637)
,p_event_id=>wwv_flow_imp.id(857985322711950638)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P367_LAENDER'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(b_nummer || '' '' || land, '', '')',
'from t_land',
'where landid in (select distinct column_value from Table(apex_string.split_numbers(:P367_BNUMMERN, '':'')))',
'order by b_nummer'))
,p_attribute_07=>'P367_BNUMMERN'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(857983882306950637)
,p_name=>'All Selector'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'th input:checkbox'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(857983376506950637)
,p_event_id=>wwv_flow_imp.id(857983882306950637)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' var check_all = $("#VSIG").find("th input:checked").is(":checked");',
'',
unistr('    // alle Zeilen ausw\00E4hlen/abw\00E4hlen'),
'    $("#VSIG").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'    // Button aktivieren/deaktivieren',
'    if (check_all) {',
'        $("#b_next").removeClass("apex_disabled");',
'    } else {',
'        $("#b_next").addClass("apex_disabled");',
'    }',
'',
'    $("#b_next").prop(''disabled'', !check_all);',
'    ',
unistr('    // alle ausgew\00E4hlten Zeilen-IDs in das Item P367_LAENDER'),
'    var sel_laender = apex.item(''P367_BNUMMERN'');',
'    let available_eop = apex.item(''P367_AVAILABLE_EOPS'');',
'        ',
'    var set_eops = new Set();',
'    var set_selected_laender = new Set();',
'    $("#VSIG").find("td input:checked").each(function() {',
'        let jsonObject = JSON.parse(this.value);    ',
'        ',
'        let bnummern = jsonObject.bnummern.split('':'');',
'        bnummern.forEach(item => set_selected_laender.add(item));',
'        ',
'        if (jsonObject.eop != ''&nbsp;'') {',
'          set_eops.add(jsonObject.eop);',
'        }       ',
'        ',
'    });',
'',
'    sel_laender.setValue(Array.from(set_selected_laender).join('':''));',
'',
'    let str_eops = Array.from(set_eops).join('':'');',
'    available_eop.setValue(str_eops);',
'    apex.server.process(''DUMMY_PROCESS'', {',
'        pageItems: ''#P367_BNUMMERN''',
'    },{dataType: ''text''});',
'',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(857982851749950636)
,p_event_id=>wwv_flow_imp.id(857983882306950637)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P367_LAENDER'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(b_nummer || '' '' || land, '', '')',
'from t_land',
'where landid in (select distinct column_value from Table(apex_string.split_numbers(:P367_BNUMMERN, '':'')))',
'order by b_nummer'))
,p_attribute_07=>'P367_BNUMMERN'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(857982493761950636)
,p_name=>'after table refresh'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(857981997037950636)
,p_event_id=>wwv_flow_imp.id(857982493761950636)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* minimales datum */',
'let min_date = '''';',
'$(''tr td:nth-child(4).t-Report-cell'').each(function() {',
'    var this_date;',
'    if ($(this).text().trim().length > 0) {',
'        this_date = $.datepicker.parseDate(''dd.mm.yy'', $(this).text());    ',
'    } else {',
'        this_date = null;',
'    }',
'',
'    if ((!min_date && this_date) || (this_date && this_date < min_date)) {',
'        min_date = this_date;',
'    }',
'});',
'',
'let min_date_string = $.datepicker.formatDate(''dd.mm.yy'', min_date);',
'$(''tr td:nth-child(4)'').each(function() {',
'   if ($(this).text() == min_date_string) {',
'       $(this).css(''background-color'', ''lightblue'');',
'       $(this).css(''font-weight'', ''bold'');',
'   }',
'    ',
'});',
'',
'/* maximales Datum */',
'let max_date = '''';',
'$(''tr td:nth-child(5).t-Report-cell'').each(function() {',
'    var this_date;',
'    if ($(this).text().trim().length > 0) {',
'        this_date = $.datepicker.parseDate(''dd.mm.yy'', $(this).text());    ',
'    } else {',
'        this_date = null;',
'    }',
'    if ((!max_date && this_date) || (this_date && this_date > max_date)) {',
'        max_date = this_date;',
'    }',
'});',
'',
'let max_date_string = $.datepicker.formatDate(''dd.mm.yy'', max_date);',
'$(''tr td:nth-child(5)'').each(function() {',
'   if ($(this).text() == max_date_string) {',
'       //alert(min_date_string);',
'       $(this).css(''background-color'', ''lightblue'');',
'       $(this).css(''font-weight'', ''bold'');',
'   }',
'    ',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(857981589854950635)
,p_name=>'Set EOP'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'tr td:nth-child(5).t-Report-cell nobr span'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#VSIG'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(857981072917950635)
,p_event_id=>wwv_flow_imp.id(857981589854950635)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P367_EOP'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).closest(''td'').text()'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(857980705972950635)
,p_name=>'Set SOP'
,p_event_sequence=>60
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'tr td:nth-child(4).t-Report-cell nobr span'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#VSIG'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(857980193308950635)
,p_event_id=>wwv_flow_imp.id(857980705972950635)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P367_SOP'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).closest(''td'').text()'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(857979758154950635)
,p_name=>'New'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P367_BNUMMERN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(857979309870950634)
,p_event_id=>wwv_flow_imp.id(857979758154950635)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P367_SOP_EOP_ID'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DISTINCT(lg.laendergruppeid )',
'from t_laendergruppe lg where lg.laendergruppeid!=1220 and lg.laendergruppeid in (select LAENDERGRUPPEID from t_land_ref_laendergruppe ',
'where landid in (select column_value from table(apex_string.split_numbers(:P367_BNUMMERN,'':'')))) ',
'order by 1;'))
,p_attribute_07=>'P367_BNUMMERN'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(857978923995950633)
,p_name=>'After Refresh'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(233282128489417707)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(857978404461950633)
,p_event_id=>wwv_flow_imp.id(857978923995950633)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'fMinMax();',
'fAddButtons();'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(857986491619950640)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_01=>'P367_SOP,P367_EOP,P367_BNUMMERN,P367_KPBS_UEBERGABE,P367_SELECTED_KPB'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2814225824279437595
);
wwv_flow_imp.component_end;
end;
/
