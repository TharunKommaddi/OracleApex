prompt --application/pages/page_00455
begin
--   Manifest
--     PAGE: 00455
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>455
,p_name=>'MS Suchparameter'
,p_alias=>'MS-SUCHPARAMETER'
,p_page_mode=>'MODAL'
,p_step_title=>'MS Suchparameter'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function loadLaenderShuttle() {',
'    var shuttleName = ''P455_FILTER_LAND'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadLaenderShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P455_FILTER_LAENDERGRUPPE''),',
'          x03: $v(''P455_STARTDATUM_TYP''),',
'          x04: $v(''P455_FILTER_LAENDER'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                console.log(pData);',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'     //alert(x04);',
'}',
'',
'function loadThemenShuttle() {',
'    var shuttleName = ''P455_FILTER_THEMEN'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lAntriebsart = $v(''P455_ANTRIEBSART'');',
'    var lArbeitskreis = $v(''P455_ARBEITSKREISE'');',
'    var lDatumMeilenstein  = $v(''P455_DATUM_MEILENSTEIN'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadThemenShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P455_FILTER_THEMEN_PRE''),',
'          x03: lAntriebsart,',
'          x04: lArbeitskreis,',
'          x05: lDatumMeilenstein',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'function updateLabelDatumSop() {',
'    var lItem = apex.item("P455_STARTDATUM_TYP");',
'    var lValue = lItem.getValue();',
'',
'    if (lValue == 20) {',
'    $("label[for=P455_DATUM_SOP]").text("Datum ME");',
'    } else {',
'    $("label[for=P455_DATUM_SOP]").text("Datum SOP");',
'    } ',
'}',
'',
'$(document).ready(function() {',
'   updateLabelDatumSop(); ',
'});',
'',
'$(''.shuttleSort2'').css(''display'', ''none'');',
'$(''.apex-item-wrapper--shuttle'').css(''padding-top'', ''0rem'');',
'',
'function addItemToShuttle(aShuttle, aID, aDisplay) {',
'    var lLeft = $(''#'' + aShuttle + ''_LEFT'');',
'    var lRight = $(''#'' + aShuttle + ''_RIGHT'');',
'    lLeft.find(''option[value='' + aID + '']'').remove();',
'    lRight.append(''<option value="'' + aID + ''">'' + aDisplay + ''</option>'');',
'}',
'',
'',
'function opennextpage(){',
'',
'// alert(''test'');',
'apex.submit(''OPENWINDOW'');',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1200'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3354631542471080434)
,p_plug_name=>'Suchparameter'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(160517045982450017)
,p_plug_name=>'Trennlinie'
,p_parent_plug_id=>wwv_flow_imp.id(3354631542471080434)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>90
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<hr>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(160516889720450016)
,p_plug_name=>'Risikobewertung'
,p_parent_plug_id=>wwv_flow_imp.id(3354631542471080434)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>100
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(904806885053436904)
,p_plug_name=>unistr('Box Vorfilter L\00E4nder')
,p_parent_plug_id=>wwv_flow_imp.id(3354631542471080434)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>70
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(904807016650436905)
,p_plug_name=>unistr('Box Filter L\00E4nder')
,p_parent_plug_id=>wwv_flow_imp.id(3354631542471080434)
,p_region_template_options=>'#DEFAULT#:margin-left-md'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(904807081506436906)
,p_plug_name=>'Trennlinie'
,p_parent_plug_id=>wwv_flow_imp.id(3354631542471080434)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<hr>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(904807187375436907)
,p_plug_name=>'Box Vorfilter Themen'
,p_parent_plug_id=>wwv_flow_imp.id(3354631542471080434)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(904807294333436908)
,p_plug_name=>'Box Filter Themen'
,p_parent_plug_id=>wwv_flow_imp.id(3354631542471080434)
,p_region_template_options=>'#DEFAULT#:margin-left-md'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(904807405508436909)
,p_plug_name=>'Trennlinie'
,p_parent_plug_id=>wwv_flow_imp.id(3354631542471080434)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<hr>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(904807543296436910)
,p_plug_name=>'Haupteinstellungen'
,p_parent_plug_id=>wwv_flow_imp.id(3354631542471080434)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3355432588221703922)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noBorder'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(421128307975204272)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(904807016650436905)
,p_button_name=>'B_KOMMENTARE_PRUEFEN'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('Kommentar bez. ausgew\00E4hlten L\00E4ndern pr\00FCfen')
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-info-square-o'
,p_button_cattributes=>'style="margin: 0px; padding: 0px; "'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(421122768875204265)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_imp.id(904807543296436910)
,p_button_name=>'B_FALKO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--iconRight:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'SOP/EOP (FALKO)'
,p_button_redirect_url=>'f?p=&APP_ID.:366:&SESSION.::&DEBUG.:366,367::'
,p_icon_css_classes=>'fa-search'
,p_grid_column_css_classes=>'t-Form-inputContainer'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(421119713293204263)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3355432588221703922)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(413241976380746989)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(3355432588221703922)
,p_button_name=>'SAVE_AND_SEARCH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern und Suchen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(421119240835204263)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3355432588221703922)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(421094337989204231)
,p_branch_name=>'Go To Page 450'
,p_branch_action=>'f?p=&APP_ID.:450:&SESSION.::&DEBUG.:RP,::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
,p_branch_condition_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_branch_condition=>'B_KOMMENTARE_PRUEFEN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1005254100756844672)
,p_name=>'P455_LAENDER_CONTAINED_MJ'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(904807016650436905)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1005122151052864234)
,p_name=>'P455_FILTER_LAENDER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(904806885053436904)
,p_prompt=>unistr('Vorfilter L\00E4nder')
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" onclick="loadLaenderShuttle()"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1005121851176864231)
,p_name=>'P455_ANTRIEBSART'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(904807187375436907)
,p_item_default=>'-1'
,p_prompt=>'Vorfilter Antriebsart'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END AS d,',
'    antriebsartid AS r ',
'FROM ',
'    t_antriebsart',
'ORDER BY ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END;',
''))
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(994911968914239299)
,p_name=>'P455_MJ_ANFANG'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(904807543296436910)
,p_prompt=>'Mj Anfang'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select   to_char(sysdate,   ''yyyy'') + x.column_value d , to_char(sysdate, ''yyyy'') + x.column_value r',
'   from table (apex_string.split_numbers(''-10:-9:-8:-7:-6:-5:-4:-3:-2:-1:0:1:2:3:4:5:6:7:8:9:10:11:12:13:14:15:16:17:18:19:20'','':'')) x;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(994911888337239298)
,p_name=>'P455_MJ_ENDE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(904807543296436910)
,p_prompt=>'MJ Ende'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  to_char(sysdate, ''yyyy'') + x.column_value d , to_char(sysdate, ''yyyy'') + x.column_value r',
'   from table (apex_string.split_numbers(''-10:-9:-8:-7:-6:-5:-4:-3:-2:-1:0:1:2:3:4:5:6:7:8:9:10:11:12:13:14:15:16:17:18:19:20'','':'')) x;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(994911792444239297)
,p_name=>'P455_INFO'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(904807543296436910)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('return emano_util.fLang(''Sie m\00FCssen mindestens ein Land ausgew\00E4hlt haben welches das Datumsmodell Modeljahr besitzt. (USA, KANADA, AGCC-Staaten)'', ''You must have selected at least one country that has the date model model year. (USA, CANADA, AGCC cou')
||'ntries)'');',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Info'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(994911673611239296)
,p_name=>'P455_INFO_MODUS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(904807543296436910)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('return emano_util.fLang(''Nicht relevant f\00FCr Datumsmodell Modeljahr (USA, KANADA, AGCC-Staaten)'', ''Not relevant for date model model year (USA, CANADA, AGCC states)'');'),
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Info Modus'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(981276068340373734)
,p_name=>'P455_KPB'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(904807543296436910)
,p_prompt=>'KPBs (AU-Nummern)'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT LISTAGG(DISTINCT bp.fp_kpb, '', '') WITHIN GROUP (ORDER BY bp.fp_kpb)',
'FROM TABLE(APEX_STRING.SPLIT_NUMBERS(:P455_KPB_IDS, '':'')) x',
'JOIN carmah_admin.t_falko_basis_projekt bp ON (x.column_value = bp.kpb_id)'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(distinct bp.fp_kpb, '', '') ',
'from table (apex_string.split(:P455_KPB, '':'')) x',
'--join mv_x_falko2 bp on (x.column_value = bp.kpb_id)',
'join carmah_admin.t_falko_basis_projekt bp on (x.column_value = bp.kpb_id)'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(981275971263373733)
,p_name=>'P455_KPB_IDS'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(904807543296436910)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(941832344532351401)
,p_name=>'P455_NEW'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(904807543296436910)
,p_item_default=>'select count(*) from t_benutzer_ref_rolle where rolleid in(1010,1050) and benutzerid = :G_BENUTZERID;'
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(883687470610223168)
,p_name=>'P455_NEW_1'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(904807543296436910)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(883686140549223155)
,p_name=>'P455_NEW_2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(904807543296436910)
,p_prompt=>'New'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_STARTDATUM_TYP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''SOP'', ''SOP'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Markteinf\00FChrung (ME)'', ''Market Introduction (MI)'') AS display_value,'),
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869423835228066748)
,p_name=>'P455_QUERSCHNITT_THEMEN_CB'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(904807294333436908)
,p_prompt=>'<b>Querschnittsthemengebiete</b>'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.nummer || '' - '' ||v.bezeichnung d, tra.Themaid r ',
'  from T_thema_ref_et_b_AK tra ',
'  join V_THEMA_BAUM v on (v.themaid = tra.themaid)   ',
' where tra.et_b_AKid = 1036 -- querschnitt Themen',
' order by v.thema_sortorder'))
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '5')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(494694170579206757)
,p_name=>'P455_SUCHEID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(3354631542471080434)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(494694102931206756)
,p_name=>'P455_MEILENSTEIN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3354631542471080434)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421132271721204283)
,p_name=>'P455_STATUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3354631542471080434)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421131898939204280)
,p_name=>'P455_SUCHE_TEMPID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(3354631542471080434)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421131452138204280)
,p_name=>'P455_SUCHE_JSON_DATEN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(3354631542471080434)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421130806484204275)
,p_name=>'P455_HILFE_RISIKO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(160516889720450016)
,p_prompt=>'Risikobewertung'
,p_source=>'return emano_util.fLang(''Risikobewertung'', ''Risk Assessment'') || '' <span onclick="redirect(241)" class="fa fa-question-square-o"></span>'';'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(3414144103148820565)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421130398780204274)
,p_name=>'P455_LOW_RISK'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(160516889720450016)
,p_prompt=>'Mittleres Risko in Monaten'
,p_source=>'24'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_cMaxlength=>2
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421129980203204274)
,p_name=>'P455_HIGH_RISK'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(160516889720450016)
,p_prompt=>'Hohes Risiko in Monaten'
,p_source=>'12'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_cMaxlength=>2
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421128989032204273)
,p_name=>'P455_FILTER_LAENDERGRUPPE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(904806885053436904)
,p_prompt=>unistr('Vorfilter L\00E4nder&shy;gruppen')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select lg.laendergruppe, lg.laendergruppeid ',
'from t_laendergruppe lg where lg.laendergruppeid!=1220',
'--and landid in (select column_value from table(apex_string.split_numbers(:P455_NEW_1,'':'')))',
'',
'/*and lg.laendergruppeid in (select LAENDERGRUPPEID from t_land_ref_laendergruppe */',
'--where landid in (select column_value from table(apex_string.split_numbers(:P455_NEW_1,'':'')))',
'order by 1;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- alle -'
,p_cHeight=>5
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421127870344204271)
,p_name=>'P455_FILTER_LAND'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(904807016650436905)
,p_prompt=>unistr('L\00E4nder')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select l.b_nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.land',
'        ELSE l.land_eng',
'    END as land, l.landid',
'from t_land l',
'where (:P455_STARTDATUM_TYP is null or startdatum_typ = :P455_STARTDATUM_TYP)',
'/*8where (:P455_FILTER_LAENDERGRUPPE is null or landid in (select landid from t_land_ref_laendergruppe where laendergruppeid = :P455_FILTER_LAENDERGRUPPE))',
' and (:P455_STARTDATUM_TYP is null or startdatum_typ = :P455_STARTDATUM_TYP)*/',
'ORDER BY NLSSORT(l.B_NUMMER, ''NLS_SORT=BINARY_AI'') ASC'))
,p_lov_cascade_parent_items=>'P455_STARTDATUM_TYP'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>4
,p_tag_css_classes=>'margin-bottom-none'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421127535731204270)
,p_name=>'P455_LAND_STATUS_DATENSTAND'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(904807016650436905)
,p_prompt=>unistr('Die folgenden L\00E4nder sind derzeit im Regulation Index nicht abgebildet:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="font-size: 12px; font-weight: 100; line-height: 16px; margin:0px; padding:0px;"'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#:margin-top-none:margin-bottom-none'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421127098844204269)
,p_name=>'P455_BESONDERHEITEN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(904807016650436905)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421126677995204269)
,p_name=>'P455_URL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(904807016650436905)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421125637249204268)
,p_name=>'P455_THEMEN_CHILDREN_TO_ADD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(904807187375436907)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421125300118204268)
,p_name=>'P455_FILTER_THEMEN_PRE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(904807187375436907)
,p_prompt=>'Vorfilter Themen'
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" onclick="loadThemenShuttle()"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421124869264204267)
,p_name=>'P455_ARBEITSKREISE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(904807187375436907)
,p_item_default=>'-1'
,p_prompt=>'Vorfilter Arbeitskreise'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select kurz||'' ''|| CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END as d, ',
'    et_b_akid as r',
'from t_et_b_ak',
'where et_b_akid not in (1200)  -- !AB QS-Themen mitnehmen     ), 1036)  -- Querschnitts Themen',
'and et_b_akid in (select et_b_akid from t_thema_ref_et_b_ak)',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- alle -'
,p_lov_null_value=>'-1'
,p_cHeight=>5
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421124516799204267)
,p_name=>'P455_ANTRIEBSART_ALT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(904807187375436907)
,p_item_default=>'-1'
,p_prompt=>'Vorfilter Antriebsart'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END AS d,',
'    antriebsartid AS r ',
'FROM ',
'    t_antriebsart',
'ORDER BY ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END;',
''))
,p_cHeight=>5
,p_grid_label_column_span=>3
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421123771589204267)
,p_name=>'P455_FILTER_THEMEN'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(904807294333436908)
,p_prompt=>'Themengebiete'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    nummer || '' - '' || ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END as description,',
'    themaid as r ',
'FROM v_thema_baum',
unistr('-- nur die Themen anzeigen, bei denen das G\00FCltigkeits-Endedatum nach dem Meilensteindatum liegt oder leer ist. Wenn davor, dann nicht in der Auswahl'),
'where :P455_DATUM_MEILENSTEIN >= nvl(GUELTIGKEIT_STARTDATUM, to_date(''01011960'',''DDMMYYYY'')) and (:P455_DATUM_MEILENSTEIN <= GUELTIGKEIT_ENDEDATUM) ',
'or (:P455_DATUM_MEILENSTEIN >= nvl(GUELTIGKEIT_STARTDATUM, to_date(''01011960'',''DDMMYYYY'')) and GUELTIGKEIT_ENDEDATUM is null)',
'',
'',
'--nvl(gueltig, 0) =1 ',
'--!AB QS-Themen mitnehmen',
'--and themaid not in  (select themaid  from t_thema_ref_et_b_ak where et_b_akid =1036);  '))
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421122401674204265)
,p_name=>'P455_SUCHE_MODUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(904807543296436910)
,p_item_default=>'0'
,p_prompt=>'Suche Modus'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_value clob;',
'l_count number;',
'v_cnt number;',
'begin ',
'begin ',
'select count(*) into l_count from t_benutzer_ref_rolle where rolleid in(1005,1010,1050) and benutzerid = :G_BENUTZERID;  -- 1005, 1010, 1050 not be able to see exiting type ',
'exception when no_data_found then l_count :=0;',
'end;',
'',
'if l_count >0 then ',
'begin ',
'select count(*) into v_cnt from t_benutzer_ref_rolle where rolleid in(1000,1001,1002,1003,1004,1006,1040,1060) and benutzerid = :G_BENUTZERID;  -- rest not be able to see exiting type ',
'exception when no_data_found then l_count :=0;',
'end;',
'',
'if v_cnt > 0 then',
'l_value :=''SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''''Neue Typen'''', ''''New Types'''') AS display_value,',
'        0 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'    UNION ALL',
'    SELECT ',
'        emano_util.fLang(''''Bestehender Typ'''', ''''Existing Type'''') AS display_value,',
'        10 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
')'';',
'else',
'',
'l_value :=''SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''''Neue Typen'''', ''''New Types'''') AS display_value,',
'        0 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'    ',
')'';',
'end if;',
'else',
'l_value :=''SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''''Neue Typen'''', ''''New Types'''') AS display_value,',
'        0 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'    ',
')'';',
'end if;',
'return (l_value);',
'',
'end;',
'',
'',
'-- ROLLEID ROLLE               ',
'-- ---------- --------------------',
'--       1006 FbEx                ',
'--       1004 Suche               ',
'--       1010 Basisrechte         ',
'--       1005 User Admin          ',
'--       1040 KFEx                ',
'--       1050 RRE                 ',
'--       1060 KVKO                ',
'--       1000 VKO                 ',
'--       1001 ZVEX                ',
'--       1002 VEX                 ',
'--       1003 Fachadmin ',
'',
'',
'-- 1000,1001,1002,1003,1004,1005,1006,1010,1040,1050,1060,'))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421121978196204265)
,p_name=>'P455_DATUM_MEILENSTEIN'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(904807543296436910)
,p_item_default=>'Sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Datum Meilenstein'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421121541351204264)
,p_name=>'P455_STARTDATUM_TYP'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(904807543296436910)
,p_use_cache_before_default=>'NO'
,p_item_default=>'10'
,p_prompt=>'Art des Startdatums'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lResult number;',
'begin',
'    select l.startdatum_typ into lResult',
'    from t_land l',
'    where l.landid in (select column_value from TABLE(APEX_STRING.split_numbers(:P455_FILTER_LAND, '':'')))',
'    OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY;',
'    ',
'    return lResult;',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'    lResult := null;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_STARTDATUM_TYP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''SOP'', ''SOP'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Markteinf\00FChrung (ME)'', ''Market Introduction (MI)'') AS display_value,'),
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:margin-bottom-none'
,p_is_persistent=>'U'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421121231952204264)
,p_name=>'P455_DATUM_SOP'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(904807543296436910)
,p_prompt=>'Datum SOP'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421120779236204263)
,p_name=>'P455_DATUM_EOP'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(904807543296436910)
,p_prompt=>'Datum EOP'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(421120400604204263)
,p_name=>'P455_CKD_FBU_MODE'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(904807543296436910)
,p_item_default=>'0'
,p_prompt=>'FBU/CKD'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'CKD',
  'off_value', '1',
  'on_label', 'FBU',
  'on_value', '0',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(421116053780204245)
,p_validation_name=>'Validation_EOP'
,p_validation_sequence=>10
,p_validation=>'to_date(:P455_DATUM_EOP) > to_date(:P455_DATUM_SOP)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Der EOP muss nach dem SOP liegen'
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(421120779236204263)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(421118806930204247)
,p_validation_name=>'Validation_EOP_not_null'
,p_validation_sequence=>20
,p_validation=>'(:P455_DATUM_EOP is not null)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Es muss ein Datum EOP festgelegt werden.'
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(421120779236204263)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(421118501612204247)
,p_validation_name=>'Validation_SOP_not_null'
,p_validation_sequence=>30
,p_validation=>'(:P455_DATUM_SOP is not null)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Es muss ein Datum SOP festgelegt werden.'
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(421121231952204264)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(421117281641204246)
,p_validation_name=>'Validation_Datum_Meilenstei_not_null'
,p_validation_sequence=>40
,p_validation=>'(:P455_DATUM_MEILENSTEIN is not null)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Es muss ein Datum Meilenstein festgelegt werden.'
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(421121978196204265)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(421118070483204246)
,p_validation_name=>'Validation Thema gewaehlt'
,p_validation_sequence=>50
,p_validation=>'(:P455_FILTER_THEMEN is not null or :P455_QUERSCHNITT_THEMEN_CB is not null )'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Es muss mindestens ein Thema ausgew\00E4hlt werden.')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(421123771589204267)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(421117684407204246)
,p_validation_name=>'Validation Land gewaehlt'
,p_validation_sequence=>60
,p_validation=>'(:P455_FILTER_LAND is not null)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Es muss mindestens ein Land ausgew\00E4hlt werden.')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(421127870344204271)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(421116854219204246)
,p_validation_name=>'Validation Risiko Low Reihenvolge'
,p_validation_sequence=>70
,p_validation=>'(:P455_low_risk> :P455_HIGH_RISK)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Das Mittlere Risiko muss gr\00F6\00DFer als das Hohe Risiko sein.')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(421130398780204274)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(421116531209204246)
,p_validation_name=>'Validation Risiko High Reihenvolge'
,p_validation_sequence=>80
,p_validation=>'(:P455_low_risk> :P455_HIGH_RISK)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Das Mittlere Risiko muss gr\00F6\00DFer als das Hohe Risiko sein.')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(421129980203204274)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(3141433127487707433)
,p_validation_name=>'Validation_MODELLJAHR_ANFANG'
,p_validation_sequence=>90
,p_validation=>'(:P455_MJ_ANFANG is not null )'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Bitte bef\00FCllen sie das Feld MJ Anfang. <br>'),
unistr('Bitte geben sie die Jahreszahlen f\00FCr Modeljahr ein!'),
'In welchen Modeljahren wird das Produkt ausgeliefert  '))
,p_always_execute=>'Y'
,p_validation_condition=>'P455_LAENDER_CONTAINED_MJ'
,p_validation_condition_type=>'ITEM_IS_NOT_ZERO'
,p_associated_item=>wwv_flow_imp.id(994911968914239299)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(3141432750375707429)
,p_validation_name=>'Validation_MODELLJAHR_ENDE'
,p_validation_sequence=>100
,p_validation=>'(:P455_MJ_ENDE is not null )'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Bitte bef\00FCllen sie das Feld MJ Ende.<br>'),
unistr('Bitte geben sie die Jahreszahlen f\00FCr Modeljahr ein!'),
'In welchen Modeljahren wird das Produkt ausgeliefert  '))
,p_always_execute=>'Y'
,p_validation_condition=>'P455_LAENDER_CONTAINED_MJ'
,p_validation_condition_type=>'ITEM_IS_NOT_ZERO'
,p_associated_item=>wwv_flow_imp.id(994911888337239298)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(421101292700204234)
,p_name=>'FILTER_LAENDERGRUPPE_CHANGED'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P455_FILTER_LAENDERGRUPPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421100818426204234)
,p_event_id=>wwv_flow_imp.id(421101292700204234)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1005122060740864233)
,p_name=>'FILTER_LAENDER_PRE_CHANGED'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P455_FILTER_LAENDER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1005121945984864232)
,p_event_id=>wwv_flow_imp.id(1005122060740864233)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(421100436372204234)
,p_name=>'FILTER_THEMEN_PRE_CHANGED'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P455_FILTER_THEMEN_PRE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421099923959204234)
,p_event_id=>wwv_flow_imp.id(421100436372204234)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadThemenShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(421099491959204234)
,p_name=>'CANCEL'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(421119240835204263)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421098984313204233)
,p_event_id=>wwv_flow_imp.id(421099491959204234)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(421098600195204233)
,p_name=>'FILTER_LAND_CHANGED'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P455_FILTER_LAND'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421098078973204233)
,p_event_id=>wwv_flow_imp.id(421098600195204233)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    select l.startdatum_typ into :P455_STARTDATUM_TYP',
'    from t_land l',
'    where l.landid in (select column_value from TABLE(APEX_STRING.split_numbers(:P455_FILTER_LAND, '':'')))',
'    OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY;',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'    :P455_STARTDATUM_TYP := null;',
'end;'))
,p_attribute_02=>'P455_FILTER_LAND'
,p_attribute_03=>'P455_STARTDATUM_TYP'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(421097692014204233)
,p_name=>'STARTDATUM_TYP_CHANGE'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P455_STARTDATUM_TYP'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421097191762204233)
,p_event_id=>wwv_flow_imp.id(421097692014204233)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P455_FILTER_LAND'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(883687374257223167)
,p_event_id=>wwv_flow_imp.id(421097692014204233)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P455_NEW_1'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>':P455_STARTDATUM_TYP'
,p_attribute_07=>'P455_STARTDATUM_TYP'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(883686290612223156)
,p_event_id=>wwv_flow_imp.id(421097692014204233)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P455_STARTDATUM_TYP,P455_NEW_1'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421096713288204233)
,p_event_id=>wwv_flow_imp.id(421097692014204233)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'loadLaenderShuttle();',
'updateLabelDatumSop();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(421096283685204233)
,p_name=>'Antriebart changed alt'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P455_ANTRIEBSART_ALT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421095834244204232)
,p_event_id=>wwv_flow_imp.id(421096283685204233)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadThemenShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1005121775125864230)
,p_name=>'Antriebart changed'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P455_ANTRIEBSART'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1005121677132864229)
,p_event_id=>wwv_flow_imp.id(1005121775125864230)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadThemenShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(421095419042204232)
,p_name=>'Disable mode switch when limited User'
,p_event_sequence=>90
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>'pck_ri.fIsLimitedUser = 1 '
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421094922122204232)
,p_event_id=>wwv_flow_imp.id(421095419042204232)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P455_SUCHE_MODUS'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(883688222228223175)
,p_name=>'set value for 366 item'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(421122768875204265)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(877411745589999903)
,p_event_id=>wwv_flow_imp.id(883688222228223175)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P366_SOP_EOP_ID :=:P455_STARTDATUM_TYP;'
,p_attribute_02=>'P455_STARTDATUM_TYP'
,p_attribute_03=>'P366_SOP_EOP_ID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(883688103772223174)
,p_event_id=>wwv_flow_imp.id(883688222228223175)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P455_FILTER_LAENDERGRUPPE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(869476409748647898)
,p_name=>'set value for 366 item_page load'
,p_event_sequence=>110
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869476329758647897)
,p_event_id=>wwv_flow_imp.id(869476409748647898)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P366_SOP_EOP_ID :=:P455_STARTDATUM_TYP;'
,p_attribute_02=>'P455_STARTDATUM_TYP'
,p_attribute_03=>'P366_SOP_EOP_ID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(883689120124223184)
,p_name=>'Dialog Falko closed'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(421122768875204265)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(883689023994223183)
,p_event_id=>wwv_flow_imp.id(883689120124223184)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P455_DATUM_SOP'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P367_SOP'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(883688892835223182)
,p_event_id=>wwv_flow_imp.id(883689120124223184)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P455_DATUM_EOP'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P367_EOP'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(883688673864223180)
,p_event_id=>wwv_flow_imp.id(883689120124223184)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P455_FILTER_LAND'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P367_BNUMMERN'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(981275818315373732)
,p_event_id=>wwv_flow_imp.id(883689120124223184)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P455_KPB'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P367_SELECTED_KPB'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(981275754329373731)
,p_event_id=>wwv_flow_imp.id(883689120124223184)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P455_KPB_IDS'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P367_KPBS_UEBERGABE'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(951937694565316301)
,p_event_id=>wwv_flow_imp.id(883689120124223184)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Force update the text field based on the IDs returned',
'    -- This prevents the "ID instead of Name" bug',
'    SELECT listagg(fp_kpb, '', '') WITHIN GROUP (ORDER BY fp_kpb)',
'       INTO :P455_KPB',
'       FROM (',
'           SELECT DISTINCT fp_kpb',
'           FROM carmah_admin.t_falko_basis_projekt',
'           WHERE kpb_id IN (',
'               SELECT column_value ',
'               FROM apex_string.split(:P455_KPB_IDS, '':'')',
'           )',
'       );',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Fallback if lookup fails (keeps whatever was passed)',
'        NULL;',
'END;'))
,p_attribute_02=>'P455_KPB_IDS'
,p_attribute_03=>'P455_KPB'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(421111068087204239)
,p_name=>'FILTER_LAND_CHANGED_BESNDERHEITEN'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P455_FILTER_LAND'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421110631683204239)
,p_event_id=>wwv_flow_imp.id(421111068087204239)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(landid, '':'') into :P455_BESONDERHEITEN',
'from t_land',
'where landid in (select column_value from table(apex_string.split_numbers(:P455_FILTER_LAND, '':'')))',
'and besonderheiten is not null;',
'--APEX_UTIL.SET_SESSION_STATE(''P455_BESONDERHEITEN'', ''SOME VALUE'');'))
,p_attribute_02=>'P455_FILTER_LAND'
,p_attribute_03=>'P455_BESONDERHEITEN'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(421110227254204239)
,p_name=>'LAENDER_MIT_BESONDERHEIT_CHANGED'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P455_BESONDERHEITEN'
,p_condition_element=>'P455_BESONDERHEITEN'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421109660334204238)
,p_event_id=>wwv_flow_imp.id(421110227254204239)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(421128307975204272)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421108722686204237)
,p_event_id=>wwv_flow_imp.id(421110227254204239)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(421128307975204272)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421109138114204238)
,p_event_id=>wwv_flow_imp.id(421110227254204239)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apeX_page.get_url (',
'    p_page => 136,',
'    p_items => ''P136_LAENDER'',',
'    p_values => ''\'' || :P455_BESONDERHEITEN || ''\'',',
'    p_clear_cache => 136',
') into :P455_URL FROM DUAL;'))
,p_attribute_02=>'P455_BESONDERHEITEN'
,p_attribute_03=>'P455_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(421106368297204237)
,p_name=>'open_modal'
,p_event_sequence=>150
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(421128307975204272)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_da_event_comment=>'B_KOMMENTARE_PRUEFEN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421105927525204236)
,p_event_id=>wwv_flow_imp.id(421106368297204237)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.navigation.redirect($v("P455_URL"));',
'//window.location=$("#P455_URL").val();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(421105484996204236)
,p_name=>'FILTER_LAND_CHANGED_UMSETZUNGSSTAND'
,p_event_sequence=>160
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P455_FILTER_LAND'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421105028386204236)
,p_event_id=>wwv_flow_imp.id(421105484996204236)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('select nvl2(listagg(landid), --''Die Folgenden L\00E4nder sind derzeit im Regulation Index nicht abgebildet:<br />'' '),
'            '''' || listagg(b_nummer || '' - '' || land, '', ''), null) into :P455_LAND_STATUS_DATENSTAND',
'from t_land',
'where landid in (select column_value from table(apex_string.split_numbers(:P455_FILTER_LAND, '':'')))',
'    and STATUS_DATENSTAND = 0',
'',
';'))
,p_attribute_02=>'P455_FILTER_LAND'
,p_attribute_03=>'P455_LAND_STATUS_DATENSTAND'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(421104636756204236)
,p_name=>'UMSETZUNGSTATUS_DATENSTAND_CHANGED'
,p_event_sequence=>170
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P455_LAND_STATUS_DATENSTAND'
,p_condition_element=>'P455_LAND_STATUS_DATENSTAND'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421104134506204236)
,p_event_id=>wwv_flow_imp.id(421104636756204236)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P455_LAND_STATUS_DATENSTAND'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421103571599204236)
,p_event_id=>wwv_flow_imp.id(421104636756204236)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P455_LAND_STATUS_DATENSTAND'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(421112911868204240)
,p_name=>'Arbeitskreis_changed'
,p_event_sequence=>180
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P455_ARBEITSKREISE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421112347328204240)
,p_event_id=>wwv_flow_imp.id(421112911868204240)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadThemenShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(421103191374204235)
,p_name=>'add childThemen'
,p_event_sequence=>190
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P455_FILTER_THEMEN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421101702957204234)
,p_event_id=>wwv_flow_imp.id(421103191374204235)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lThemenliste apex_t_number := apex_string.split_numbers(:P455_FILTER_THEMEN,'':'');',
'     l_lst_allQSThemen varchar2(2000);',
'  --  l_inQuerschnittsthemen apex_t_number ;',
'begin    ',
'',
'    apex_json.initialize_clob_output;',
'    apex_json.open_array;    ',
'',
'  -- select listagg(themaid, '':'') into l_lst_allQSThemen from t_thema_ref_et_b_ak where et_b_akid = 1036;',
'   -- l_inQuerschnittsthemen  := apex_string.split_numbers(l_lst_allQSThemen,'':'');',
unistr('    -- Jedes bereits ausgew\00E4hlte Thema durchgehen und dessen Kinder selektieren'),
'    for i in 1 .. lThemenliste.count loop',
'        for childthemen in (',
'            select themaid, nummer || '' - '' || bezeichnung as d',
'            from t_thema',
'            where gueltig =1',
'            connect by parentid = prior themaid',
'            start with parentid = lThemenliste(i)',
'        ) loop',
'            -- Wenn das entsprechende Kind noch nicht im Shuttle ist, dann ',
unistr('            -- zu einer Hinzuf\00FCgungs-Liste addieren'),
'            if (childthemen.themaid not member of lThemenliste -- !AB QS-Themen mitnehmen  and  childthemen.themaid  not member of l_inQuerschnittsthemen',
'             ) then',
'                apex_json.open_object;',
'                apex_json.write(''id'',childthemen.themaid);',
'                apex_json.write(''display'',childthemen.d);',
'                apex_json.close_object;',
'            end if;',
'        end loop;',
'    ',
'    end loop;',
unistr('    -- Hinzuf\00FCgungs-Liste ist hidden item'),
unistr('    -- Direktes Hinzuf\00FCgen w\00FCrde zu einem Refresh der Scrollbalken des Items f\00FChren'),
'    apex_json.close_array;',
'    :P455_THEMEN_CHILDREN_TO_ADD := apex_json.get_clob_output;',
'    apex_json.free_output;',
'end;    '))
,p_attribute_02=>'P455_FILTER_THEMEN'
,p_attribute_03=>'P455_THEMEN_CHILDREN_TO_ADD'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421102169348204235)
,p_event_id=>wwv_flow_imp.id(421103191374204235)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var items = JSON.parse($v(''P455_THEMEN_CHILDREN_TO_ADD''));',
'',
unistr('// alle Items im Shuttle hinzuf\00FCgen'),
'for (item of items) {',
'    if (item) addItemToShuttle(''P455_FILTER_THEMEN'',item.id,item.display);',
'} ',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421102673409204235)
,p_event_id=>wwv_flow_imp.id(421103191374204235)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var obj = new Object();',
'obj.LAENDER = $v(''P455_FILTER_LAND'');',
'/*if( typeof $v(''P455_QUERSCHNITT_THEMEN_CB'') ==="string"  && $v(''P455_QUERSCHNITT_THEMEN_CB'').trim().length != 0){',
'    obj.THEMEN = $v(''P455_QUERSCHNITT_THEMEN_CB'');',
'    if(typeof $v(''P455_FILTER_THEMEN'') === "string" && $v(''P455_FILTER_LAND'').trim().length != 0){',
'        obj.THEMEN = $v(''P455_QUERSCHNITT_THEMEN_CB'').concat('':'',$v(''P455_FILTER_THEMEN''));',
'    }',
'}',
'else */',
'{',
'    obj.THEMEN = $v(''P455_FILTER_THEMEN'');',
'}',
'//obj.THEMEN = $v(''P455_FILTER_THEMEN'');',
'obj.LOW_RISK =  $v(''P455_LOW_RISK'');',
'obj.HIGH_RISK =  $v(''P455_HIGH_RISK'');',
'obj.CKD_FBU_MODE = $v(''P455_CKD_FBU_MODE'');',
'obj.DATUM_SOP = $v(''P455_DATUM_SOP'');',
'obj.DATUM_EOP = $v(''P455_DATUM_EOP'');',
'obj.DATUM_MEILENSTEIN = $v(''P455_DATUM_MEILENSTEIN'');',
'obj.SUCHTYP = $v(''P455_SUCHE_MODUS'');',
'obj.MEILENSTEIN = $v(''P455_MEILENSTEIN'');',
'obj.MJ_ANFANG = $v(''P455_MJ_ANFANG'');',
'obj.MJ_ENDE = $v(''P455_MJ_ENDE'');',
'obj.ANTRIEBSART = $v(''P455_ANTRIEBSART'');',
'obj.KPB = $v(''P455_KPB_IDS'');',
'obj.LOCKED = 0;',
'',
'$s(''P455_SUCHE_JSON_DATEN'', JSON.stringify(obj));',
'',
'apex.server.process(''DUMMY_PROCESS'', {',
'    pageItems: ''#P455_SUCHE_JSON_DATEN''',
'}, {',
'    dataType: "text"',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(421113795803204243)
,p_name=>'FILTER_CHANGE'
,p_event_sequence=>200
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P455_FILTER_LAND,P455_FILTER_THEMEN,P455_SUCHE_MODUS,P455_LOW_RISK,P455_HIGH_RISK,P455_DATUM_MEILENSTEIN,P455_DATUM_SOP,P455_DATUM_EOP,P455_CKD_FBU_MODE,P455_MJ_ANFANG,P455_MJ_ENDE,P455_QUERSCHNITT_THEMEN_CB,P455_ANTRIEBSART_ALT,P455_KPB,P455_KPB_IDS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(980817971674066834)
,p_event_id=>wwv_flow_imp.id(421113795803204243)
,p_event_result=>'TRUE'
,p_action_sequence=>140
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P455_KPB'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421113294934204241)
,p_event_id=>wwv_flow_imp.id(421113795803204243)
,p_event_result=>'TRUE'
,p_action_sequence=>150
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var obj = new Object();',
'obj.LAENDER = $v(''P455_FILTER_LAND'');',
'//obj.THEMEN = $v(''P455_FILTER_THEMEN'');',
'if( typeof $v(''P455_QUERSCHNITT_THEMEN_CB'') ==="string"  && $v(''P455_QUERSCHNITT_THEMEN_CB'').trim().length != 0){',
'    obj.THEMEN = $v(''P455_QUERSCHNITT_THEMEN_CB'');',
'    if(typeof $v(''P455_FILTER_THEMEN'') === "string" && $v(''P455_FILTER_LAND'').trim().length != 0){',
'        obj.THEMEN = $v(''P455_QUERSCHNITT_THEMEN_CB'').concat('':'',$v(''P455_FILTER_THEMEN''));',
'    }',
'}',
'else {',
'    obj.THEMEN = $v(''P455_FILTER_THEMEN'');',
'}',
'obj.LOW_RISK =  $v(''P455_LOW_RISK'');',
'obj.HIGH_RISK =  $v(''P455_HIGH_RISK'');',
'obj.CKD_FBU_MODE = $v(''P455_CKD_FBU_MODE'');',
'obj.DATUM_SOP = $v(''P455_DATUM_SOP'');',
'obj.DATUM_EOP = $v(''P455_DATUM_EOP'');',
'obj.DATUM_MEILENSTEIN = $v(''P455_DATUM_MEILENSTEIN'');',
'obj.SUCHTYP = $v(''P455_SUCHE_MODUS'');',
'obj.MEILENSTEIN = $v(''P455_MEILENSTEIN'');',
'obj.MJ_ANFANG = $v(''P455_MJ_ANFANG'');',
'obj.MJ_ENDE = $v(''P455_MJ_ENDE'');',
'obj.ANTRIEBSART = $v(''P455_ANTRIEBSART'');',
'obj.KPB = $v(''P455_KPB'');',
'obj.KPB_ID = $v(''P455_KPB_IDS'');',
'obj.LOCKED = 0;',
'',
'$s(''P455_SUCHE_JSON_DATEN'', JSON.stringify(obj));',
'',
'apex.server.process(''DUMMY_PROCESS'', {',
'    pageItems: ''#P455_SUCHE_JSON_DATEN''',
'}, {',
'    dataType: "text"',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(421112008860204240)
,p_name=>'FILTER_CHANGE_1'
,p_event_sequence=>210
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(421111499438204239)
,p_event_id=>wwv_flow_imp.id(421112008860204240)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var obj = new Object();',
'obj.LAENDER = $v(''P455_FILTER_LAND'');',
'//obj.THEMEN = $v(''P455_FILTER_THEMEN'');',
'if( typeof $v(''P455_QUERSCHNITT_THEMEN_CB'') ==="string"  && $v(''P455_QUERSCHNITT_THEMEN_CB'').trim().length != 0){',
'    obj.THEMEN = $v(''P455_QUERSCHNITT_THEMEN_CB'');',
'    if(typeof $v(''P455_FILTER_THEMEN'') === "string" && $v(''P455_FILTER_LAND'').trim().length != 0){',
'        obj.THEMEN = $v(''P455_QUERSCHNITT_THEMEN_CB'').concat('':'',$v(''P455_FILTER_THEMEN''));',
'    }',
'}',
'else {',
'    obj.THEMEN = $v(''P455_FILTER_THEMEN'');',
'}',
'obj.LOW_RISK =  $v(''P455_LOW_RISK'');',
'obj.HIGH_RISK =  $v(''P455_HIGH_RISK'');',
'obj.CKD_FBU_MODE = $v(''P455_CKD_FBU_MODE'');',
'obj.DATUM_SOP = $v(''P455_DATUM_SOP'');',
'obj.DATUM_EOP = $v(''P455_DATUM_EOP'');',
'obj.DATUM_MEILENSTEIN = $v(''P455_DATUM_MEILENSTEIN'');',
'obj.SUCHTYP = $v(''P455_SUCHE_MODUS'');',
'obj.MEILENSTEIN = $v(''P455_MEILENSTEIN'');',
'obj.MJ_ANFANG = $v(''P455_MJ_ANFANG'');',
'obj.MJ_ENDE = $v(''P455_MJ_ENDE'');',
'obj.ANTRIEBSART = $v(''P455_ANTRIEBSART'');',
'obj.KPB = $v(''P455_KPB_IDS'');',
'obj.LOCKED = 0;',
'',
'$s(''P455_SUCHE_JSON_DATEN'', JSON.stringify(obj));',
'',
'apex.server.process(''DUMMY_PROCESS'', {',
'    pageItems: ''#P455_SUCHE_JSON_DATEN''',
'}, {',
'    dataType: "text"',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1005254010671844671)
,p_name=>'SET_MJ_LAND_COUNT'
,p_event_sequence=>220
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P455_FILTER_LAND'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1005253859147844670)
,p_event_id=>wwv_flow_imp.id(1005254010671844671)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'l_co number  :=0;',
'BEGIN ',
'    select count(*) into :P455_LAENDER_CONTAINED_MJ  ',
'      from t_land where landid in ( select column_value from table(apex_string.split_numbers(:P455_FILTER_LAND,'':'')) )',
'       and einsatzdatum_modellid =30;',
'end;'))
,p_attribute_02=>'P455_FILTER_LAND'
,p_attribute_03=>'P455_LAENDER_CONTAINED_MJ'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(877410152282999887)
,p_name=>'SET_MJ_LAND_COUNT_1'
,p_event_sequence=>230
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(877410049422999886)
,p_event_id=>wwv_flow_imp.id(877410152282999887)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'l_co number  :=0;',
'BEGIN ',
'    select count(*) into :P455_LAENDER_CONTAINED_MJ  ',
'      from t_land where landid in ( select column_value from table(apex_string.split_numbers(:P455_FILTER_LAND,'':'')) )',
'       and einsatzdatum_modellid =30;',
'end;'))
,p_attribute_02=>'P455_FILTER_LAND'
,p_attribute_03=>'P455_LAENDER_CONTAINED_MJ'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1005253265195844664)
,p_name=>'LAENDER_CONTAINED_MJ_CHANGED'
,p_event_sequence=>240
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P455_LAENDER_CONTAINED_MJ'
,p_condition_element=>'P455_LAENDER_CONTAINED_MJ'
,p_triggering_condition_type=>'LESS_THAN_OR_EQUAL'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1005253230048844663)
,p_event_id=>wwv_flow_imp.id(1005253265195844664)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P455_MJ_ANFANG,P455_MJ_ENDE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1005253136989844662)
,p_event_id=>wwv_flow_imp.id(1005253265195844664)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P455_MJ_ANFANG,P455_MJ_ENDE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(877409973059999885)
,p_event_id=>wwv_flow_imp.id(1005253265195844664)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P455_MJ_ANFANG,P455_MJ_ENDE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(875245401741362301)
,p_name=>'QS Themen Filter Changed'
,p_event_sequence=>250
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P455_QUERSCHNITT_THEMEN_CB'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(875245280834362300)
,p_event_id=>wwv_flow_imp.id(875245401741362301)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var obj = new Object();',
'obj.LAENDER = $v(''P455_FILTER_LAND'');',
'//obj.THEMEN = $v(''P455_FILTER_THEMEN'');',
'if( typeof $v(''P455_QUERSCHNITT_THEMEN_CB'') ==="string"  && $v(''P455_QUERSCHNITT_THEMEN_CB'').trim().length != 0){',
'    obj.THEMEN = $v(''P455_QUERSCHNITT_THEMEN_CB'');',
'    if(typeof $v(''P455_FILTER_THEMEN'') === "string" && $v(''P455_FILTER_LAND'').trim().length != 0){',
'        obj.THEMEN = $v(''P455_QUERSCHNITT_THEMEN_CB'').concat('':'',$v(''P455_FILTER_THEMEN''));',
'    }',
'}',
'else {',
'    obj.THEMEN = $v(''P455_FILTER_THEMEN'');',
'}',
'obj.LOW_RISK =  $v(''P455_LOW_RISK'');',
'obj.HIGH_RISK =  $v(''P455_HIGH_RISK'');',
'obj.CKD_FBU_MODE = $v(''P455_CKD_FBU_MODE'');',
'obj.DATUM_SOP = $v(''P455_DATUM_SOP'');',
'obj.DATUM_EOP = $v(''P455_DATUM_EOP'');',
'obj.DATUM_MEILENSTEIN = $v(''P455_DATUM_MEILENSTEIN'');',
'obj.SUCHTYP = $v(''P455_SUCHE_MODUS'');',
'obj.MEILENSTEIN = $v(''P455_MEILENSTEIN'');',
'obj.MJ_ANFANG = $v(''P455_MJ_ANFANG'');',
'obj.MJ_ENDE = $v(''P455_MJ_ENDE'');',
'obj.ANTRIEBSART = $v(''P455_ANTRIEBSART'');',
'obj.KPB = $v(''P455_KPB_IDS'');',
'obj.LOCKED = 0;',
'',
'$s(''P455_SUCHE_JSON_DATEN'', JSON.stringify(obj));',
'',
'apex.server.process(''DUMMY_PROCESS'', {',
'    pageItems: ''#P455_SUCHE_JSON_DATEN''',
'}, {',
'    dataType: "text"',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3138184792027267803)
,p_name=>'Meilenstein Datum changed'
,p_event_sequence=>260
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P455_DATUM_MEILENSTEIN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3138184694276267802)
,p_event_id=>wwv_flow_imp.id(3138184792027267803)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadThemenShuttle();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(421115382683204245)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_SUCHPARAMETER'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'update t_suche_temp t',
'set t.suchdaten.datum_meilenstein = :P455_DATUM_MEILENSTEIN,',
' t.suchdaten.datum_sop = :P455_DATUM_SOP,',
' t.suchdaten.datum_eop = :P455_DATUM_EOP,',
' t.suchdaten.liste_laender = :P455_FILTER_LAND,',
' t.suchdaten.liste_themen = :P455_FILTER_THEMEN,',
' t.suchdaten.suchtyp = :P455_SUCHE_MODUS,',
' t.suchdaten.ckd_fbu_mode = :P455_ckd_fbu_mode',
'where suche_tempid = :P455_SUCHE_TEMPID;',
'*/',
'-- todo Use cases',
'--     start  suche job ',
'',
'',
'declare ',
'  l_daten clob;',
'  l_daten2 clob;',
'  l_daten3 clob;',
'  l_changed number;     -- 0 - not changed ,  1 - changed ,  2- war nicht vorhanden',
'  l_arr clob :=''['';',
'  co number :=0;',
'  l_user varchar2(200);',
'   l_cou number :=0;',
'',
'begin',
'   select count(*) into l_cou',
'    from ( select sucheid,  t.daten daten, t.meils meils',
'             from t_suche_json t, json_table ( t.suchdaten, ''$[*]'' columns (daten clob format json path ''$'',',
'                      nested path ''$[*]'' COLUMNS(  meils number path ''$.MEILENSTEIN''))',
'                    ) t where sucheid = :P455_SUCHEID',
'    ) where meils = :P455_MEILENSTEIN;',
'   ',
'  if(l_cou >0) then',
'      select daten into l_daten',
'        from (',
'           select sucheid, row_number() over( order by t.meils) rn, t.daten daten, t.meils meils',
'            from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (daten clob format json path ''$'',',
'                     nested path ''$[*]'' COLUMNS(',
'                         meils number path ''$.MEILENSTEIN''))',
'          ) t where sucheid = :P455_SUCHEID',
'       ) where meils = :P455_MEILENSTEIN;',
'        --  neue Meilenstein vergl mit altem - ',
'     select case when JSON_EQUAL(l_daten, :P455_SUCHE_JSON_DATEN) then 0 else 1 end as equ into l_changed from dual;',
'   else ',
'     l_changed :=2;',
'   end if;',
'',
'  ',
'  if (l_changed != 0 ) then',
'  ',
'     l_daten := :P455_SUCHE_JSON_DATEN;',
'     ',
'     for cur in ( select  daten   from (',
'                       select sucheid, row_number() over( order by t.meils) rn, ',
'                          t.meils meils , t.daten daten ',
'                        from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (daten clob format json path ''$'',',
'                             nested path ''$[*]'' COLUMNS( meils number path ''$.MEILENSTEIN'')',
'                         ) ',
'                      ) t where sucheid = :P455_SUCHEID',
'                   ) where meils  != :P455_MEILENSTEIN',
'     )',
'     loop',
'     ',
'      co := co+1;',
'       if (co=1) then',
'         l_daten2 := cur.daten;',
'       elsif (co=2) then',
'         l_daten3 := cur.daten;',
'       end if;',
'       ',
'     end loop;',
'     ',
'      if(l_daten is not null) then',
'         dbms_lob.append(l_arr, l_daten);',
'      ',
'          if(l_daten2 is not null) then',
'             dbms_lob.append(l_arr,'','');',
'             dbms_lob.append(l_arr, l_daten2);',
'           end if;',
'           if(l_daten3 is not null) then',
'             dbms_lob.append(l_arr,'','');',
'             dbms_lob.append(l_arr, l_daten3);',
'           end if;',
'          dbms_lob.append(l_arr,'']'');',
'',
'           select nachname ||'', ''|| vorname into l_user from t_benutzer where benutzerid = pck_ri.fgetuserid;',
'',
'           if(l_changed =1 or :P455_SUCHEID < 2 ) then',
'              insert into  t_suche_JSON (bezeichnung, beschreibung, benutzerid, zeitpunkt, suchdaten, manuelle_speicherung, ERGEBNIS_STATUS)',
'                    values(''user_''|| nvl(l_user,''_'')|| '' ''||to_char(sysdate,''DD.MM.YYYY HH24:MI:SS''), ',
'                           ''Automatisch gespeichert am ''|| to_char(sysdate,''DD.MM.YYYY HH24:MI:SS''), pck_ri.fgetuserid, sysdate , l_arr, 0, 0)',
'               RETURNING sucheid INTO :P455_SUCHEID;',
'               select :P455_SUCHEID into :P450_SUCHEID from dual;',
'            else',
'             update  t_suche_JSON set zeitpunkt = sysdate, suchdaten = l_arr where sucheid = :P455_SUCHEID;',
'            end if;',
'             --debug(''P450_SUCHEID=''|| :P450_SUCHEID);',
'      end if;',
'   end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(421119713293204263)
,p_internal_uid=>3251096933216183990
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(413241893115746988)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_PARAMETER_UND_START_SUCHE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'declare ',
'  l_daten clob;',
'  l_daten2 clob;',
'  l_daten3 clob;',
'  l_changed number;     -- 0 - not changed ,  1 - changed ,  2- war nicht vorhanden',
'  l_arr clob :=''['';',
'  co number :=0;',
'  l_user varchar2(200);',
'   l_cou number :=0;',
'',
'begin',
'   select count(*) into l_cou',
'    from ( select sucheid,  t.daten daten, t.meils meils',
'             from t_suche_json t, json_table ( t.suchdaten, ''$[*]'' columns (daten clob format json path ''$'',',
'                      nested path ''$[*]'' COLUMNS(  meils number path ''$.MEILENSTEIN''))',
'                    ) t where sucheid = :P455_SUCHEID',
'    ) where meils = :P455_MEILENSTEIN;',
'   ',
'  if(l_cou >0) then',
'      select daten into l_daten',
'        from (',
'           select sucheid, row_number() over( order by t.meils) rn, t.daten daten, t.meils meils',
'            from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (daten clob format json path ''$'',',
'                     nested path ''$[*]'' COLUMNS(',
'                         meils number path ''$.MEILENSTEIN''))',
'          ) t where sucheid = :P455_SUCHEID',
'       ) where meils = :P455_MEILENSTEIN;',
'        --  neue Meilenstein vergl mit altem - ',
'     select case when JSON_EQUAL(l_daten, :P455_SUCHE_JSON_DATEN) then 0 else 1 end as equ into l_changed from dual;',
'   else ',
'     l_changed :=2;',
'   end if;',
'',
'  ',
'  if (l_changed != 0 ) then',
'  ',
'     l_daten := :P455_SUCHE_JSON_DATEN;',
'     ',
'     for cur in ( select  daten   from (',
'                       select sucheid, row_number() over( order by t.meils) rn, ',
'                          t.meils meils , t.daten daten ',
'                        from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (daten clob format json path ''$'',',
'                             nested path ''$[*]'' COLUMNS( meils number path ''$.MEILENSTEIN'')',
'                         ) ',
'                      ) t where sucheid = :P455_SUCHEID',
'                   ) where meils  != :P455_MEILENSTEIN',
'     )',
'     loop',
'     ',
'      co := co+1;',
'       if (co=1) then',
'         l_daten2 := cur.daten;',
'       elsif (co=2) then',
'         l_daten3 := cur.daten;',
'       end if;',
'       ',
'     end loop;',
'     ',
'      if(l_daten is not null) then',
'         dbms_lob.append(l_arr, l_daten);',
'      ',
'          if(l_daten2 is not null) then',
'             dbms_lob.append(l_arr,'','');',
'             dbms_lob.append(l_arr, l_daten2);',
'           end if;',
'           if(l_daten3 is not null) then',
'             dbms_lob.append(l_arr,'','');',
'             dbms_lob.append(l_arr, l_daten3);',
'           end if;',
'          dbms_lob.append(l_arr,'']'');',
'',
'           select nachname ||'', ''|| vorname into l_user from t_benutzer where benutzerid = pck_ri.fgetuserid;',
'',
'           if(l_changed =1 or :P455_SUCHEID < 2) then',
'              insert into  t_suche_JSON (bezeichnung, beschreibung, benutzerid, zeitpunkt, suchdaten, manuelle_speicherung, ERGEBNIS_STATUS)',
'                    values(''user_''|| nvl(l_user,''_'')|| '' ''||to_char(sysdate,''DD.MM.YYYY HH24:MI:SS''), ',
'                           ''Automatisch gespeichert am ''|| to_char(sysdate,''DD.MM.YYYY HH24:MI:SS''), pck_ri.fgetuserid, sysdate , l_arr, 0, 0)',
'               RETURNING sucheid INTO :P455_SUCHEID;',
'               select :P455_SUCHEID into :P450_SUCHEID from dual;',
'            else',
'               update  t_suche_JSON set zeitpunkt = sysdate, suchdaten = l_arr, ERGEBNIS_STATUS = 0 where sucheid = :P455_SUCHEID;',
'            end if;',
'            commit;',
'      --  else   -- nothing changed',
'      end if;',
'   end if;',
'       update t_suche_JSON set ERGEBNIS_STATUS = 1 where sucheid = :P455_SUCHEID;',
'       dbms_scheduler.run_job(job_name=>''J_SUCHE_AUSFUEREN'', use_current_session =>false);',
'   ',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(413241976380746989)
,p_internal_uid=>3258970422783641247
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(421115745720204245)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LOAD_SUCHPARAMETER'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  l_rown  number :=0;',
'   l_co number :=0;',
'begin',
'if (:P455_STATUS is null) then',
'',
'    -- Daten der Suche aus T_SUCHE_JSON laden',
'    select count(*)   into l_co',
'    from (',
'        select  row_number() over(order by t.meilenstein) rn, t.ms,  t.meilenstein meilenstein',
'          from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS(',
'                ms varchar2(20) path ''$.DATUM_MEILENSTEIN'',',
'                meilenstein number path''$.MEILENSTEIN''',
'                ))) t where sucheid = :P455_SUCHEID',
'      )  where meilenstein = :P455_MEILENSTEIN;',
'      ',
'      if(l_co >0) then',
'          select *  ',
'            into l_rown, :P455_DATUM_MEILENSTEIN, :P455_DATUM_SOP, :P455_DATUM_EOP, :P455_MJ_ANFANG, :P455_MJ_ENDE,',
'                    :P455_FILTER_LAND, :P455_FILTER_THEMEN, ',
'                    -- :P455_QUERSCHNITT_THEMEN_CB,',
'                    :P455_SUCHE_MODUS, :P455_ckd_fbu_mode,',
'                    :P455_LOW_RISK, :P455_HIGH_RISK, :P455_MEILENSTEIN, :P455_ANTRIEBSART, ',
'                    :P455_KPB',
'          from (',
'                select  row_number() over(order by t.meilenstein) rn, t.ms,  t.sop, t.eop, t.mj_anfang, t.mj_ende, ',
'                    t.laender , --t.themen,  ',
'                    ( select listagg(x.column_value, '':'') within group (order by x.column_value) ',
'                      from table (apex_string.split_numbers( t.themen, '':'') ) x ',
'                      ) as THEMEN,   -- !AB alle QS-Themen mitnehmen',
'                    -- where x.column_value not in (select themaid from T_thema_ref_et_b_AK  where et_b_AKid =1036)',
'                    --  ( select listagg(x.column_value, '':'') within group (order by x.column_value) ',
'                    --    from table (apex_string.split_numbers( t.themen, '':'') ) x ',
'                    --    where x.column_value  in (select themaid from T_thema_ref_et_b_AK  where et_b_AKid =1036) ) as THEMEN_QS,',
'                    t.smode, t.ckd_fbu_mode,',
'                    t.l_risk, t.h_risk,  t.meilenstein meilenstein, antriebsart, ',
'                   nvl(kpb, (select listagg(distinct bp.fp_kpb, '', '')',
'                                from table (apex_string.split(t.kpb_ID, '':'')) x',
'                                join carmah_admin.t_falko_basis_projekt bp on (x.column_value = bp.kpb_id)',
'                                --join mv_x_falko2 bp on (x.column_value = bp.kpb_id)',
'                    )) as KPB',
'                    from t_suche_json t, json_table ',
'                    (',
'                        t.suchdaten, ''$[*]'' columns ',
'                        (',
'                            nested path ''$[*]'' COLUMNS',
'                            (',
'                                laender varchar2(4000) PATH ''$.LAENDER'',',
'                                themen varchar2(2000) path ''$.THEMEN'',',
'                                --themen_qs varchar2(2000) path ''$.THEMEN'',',
'                                l_risk number path ''$.LOW_RISK'',',
'                                h_risk number path ''$.HIGH_RISK'',',
'                                ms varchar2(20) path ''$.DATUM_MEILENSTEIN'',',
'                                sop varchar2 path ''$.DATUM_SOP'',',
'                                eop varchar2(20) path ''$.DATUM_EOP'',',
'                                mj_anfang varchar2(20)  path ''$.MJ_ANFANG'',',
'                                mj_ende varchar2(20)  path ''$.MJ_ENDE'',',
'                                smode varchar2(20) path ''$.SUCHTYP'',',
'                                ckd_fbu_mode number path''$.CKD_FBU_MODE'',',
'                                meilenstein number path''$.MEILENSTEIN'',',
'                                antriebsart number path ''$.ANTRIEBSART'',',
'                                kpb varchar2(2000) path ''$.KPB'',',
'                                kpb_ID varchar2(2000) path ''$.KPB_ID''',
'                            )',
'                        )',
'                    ) t where sucheid =:P455_SUCHEID',
'              )  where meilenstein = :P455_MEILENSTEIN;',
'              ',
'        :P455_STATUS := 10;',
'      end if;',
'        ',
'end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>3251096570179183990
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(421114998515204245)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLaenderShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'	DECLARE',
'		lSelected varchar2(2000) := apex_application.g_x01;',
'		lLaendergruppe varchar2(2000) := apex_application.g_x02;',
'		lStartdatumTyp number := apex_application.g_x03;',
'        lTextLand varchar2(2000) := apex_application.g_x04;',
'		 ',
'	BEGIN',
'		',
'		--debug(lLaendergruppei',
'      ',
'		apex_json.open_array;',
'',
'       --   if :P455_NEW_1 is null and :P455_FILTER_LAENDERGRUPPE is null then ',
'		for l in (',
'			select b_nummer || '' - '' || CASE ',
'		WHEN nvl(:FSP_LANGUAGE_PREFERENCE,''de'') = ''de'' THEN land',
'		ELSE land_eng',
'	END as d, landid',
'			from t_land',
'            where upper(land) like ''%'' || upper(lTextLand) || ''%''',
'			and landid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))        ',
'	and (',
'				lLaendergruppe is null',
'				or landid in (',
'					select landid from t_land_ref_laendergruppe ',
'					  where laendergruppeid in (',
'						select column_value from table(apex_string.split_numbers(lLaendergruppe,'':''))',
'',
'				   )',
'			    ',
'				)',
'               ',
'			) ',
'',
'         --Original (commented out):   ',
'		 and (',
'				lStartdatumTyp is null',
'				or startdatum_typ = lStartdatumTyp',
'			)',
'			order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'')        ',
'		-- end	',
'		) loop',
'			apex_json.open_object;',
'			apex_json.write(''d'',l.d);',
'			apex_json.write(''r'',l.landid);',
'			apex_json.close_object;',
'END LOOP;',
'',
'		apex_json.close_array;',
'		',
'		',
'',
'	END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>3251097317384183990
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(421114597887204244)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadThemenShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lText varchar2(2000) := apex_application.g_x02;',
'    lAntriebsart varchar2(2000) := apex_application.g_x03;',
'    lArbeitskreise varchar2(2000) := apex_application.g_x04;',
'    lDatumMeilenstein varchar2(2000) := apex_application.g_x05;',
'BEGIN',
'    apex_json.open_array;',
'    for l in (',
'        select nummer || '' - '' || bezeichnung as d, t.themaid as r',
'        from v_thema_baum t',
'        left outer join t_thema_ref_antriebsart tra on (tra.themaid = t.themaid)',
'        where upper(nummer || '' - '' || bezeichnung) like ''%'' || upper(lText) || ''%''',
'        and t.themaid not in (select column_value from table(apex_string.split_numbers(lSelected,'':''))) ',
'        --!AB alle QS-Themen auch mitnehmen',
'        --and t.themaid not in (select themaid from t_thema_ref_et_b_ak where et_b_akid =1036 )   ',
'        and',
'         (',
'            lArbeitskreise = ''-1'' or t.themaid  in (Select themaid from t_thema_ref_et_b_ak tre where et_b_akid in (',
'                select column_value from table(apex_string.split(lArbeitskreise,'':''))',
'            )',
'            )',
'        )',
'        and (',
'            ',
'            ',
'            ',
'            -- tra.antriebsartid in (select column_value from table(apex_string.split(lantriebsart,'':'')))',
'            --  or lantriebsart is null',
'',
'',
'            lAntriebsart IS NULL -- Always show if no filter is set',
'                OR tra.antriebsartid IS NULL -- OR always show if topic has no drive type',
'                OR tra.antriebsartid IN ( -- OR show if the drive type matches the filter',
'                    SELECT',
'                        column_value',
'                    FROM',
'                        TABLE ( apex_string.split(lAntriebsart, '':'') )',
'                )',
'',
'',
'',
'',
'',
'',
'',
'            )',
'            --and t.gueltig =1 -- das muss raus, weil man sonst die Themen mit Ende-Datum nicht bekommt',
unistr('            -- nur die Themen anzeigen, bei denen das G\00FCltigkeits-Endedatum nach dem Meilensteindatum liegt oder leer ist. Wenn davor, dann nicht in der Auswahl'),
'            and ((to_date(lDatumMeilenstein, ''dd.mm.yyyy'') >= nvl(t.gueltigkeit_startdatum, to_date(''01011960'',''DDMMYYYY'')) and (to_date(lDatumMeilenstein, ''dd.mm.yyyy'') <= t.gueltigkeit_endedatum))',
'            or (to_date(lDatumMeilenstein, ''dd.mm.yyyy'') >= nvl(t.gueltigkeit_startdatum, to_date(''01011960'',''DDMMYYYY'')) and t.gueltigkeit_endedatum is null)',
'            )',
'        group by nummer, bezeichnung, t.themaid, thema_sortorder',
'        order by thema_sortorder',
'        ',
'       ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.r);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>3251097718012183991
);
wwv_flow_imp.component_end;
end;
/
