prompt --application/pages/page_00470
begin
--   Manifest
--     PAGE: 00470
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>470
,p_name=>'Select FUKA Quellvorschrift'
,p_alias=>'SELECT-FUKA-QUELLVORSCHRIFT'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Auswahl Vorg\00E4nger Vorschrift')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_dialog_height=>'400'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(988450678649471100)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(988451613722471139)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(988450524911471100)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(588486118822221526)
,p_plug_name=>'Zielvorschrift '
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(507924692465728216)
,p_plug_name=>'Quellvorschrift'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>6
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(988449013665471091)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(988450524911471100)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(988448682340471091)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(988450524911471100)
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Funktionen Ausw\00E4hlen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:472:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(988447096909471083)
,p_branch_action=>'f?p=&APP_ID.:472:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(988448682340471091)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(990120577708731695)
,p_name=>'P470_ZIEL_WITHOUT_NORM_VALIDATION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_prompt=>'Notation nicht validieren'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  (case WHEN (:P470_ZIEL_VORSCHRIFT_NOTATION is not null and :P470_ZIEL_VORSCHRIFT_NOTATION != 1016)  then 0 ',
'else 1 end) as cb from dual;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC(,):&nbsp;1'
,p_grid_label_column_span=>4
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('W\00E4hle die Checkbox, wenn die ausgew\00E4hlte Notation nicht validiert werden soll.'),
unistr('In diesem Fall wird automatisch eine Benachrichtigung f\00FCr die Fachadministratoren erstellt.')))
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988419065515377946)
,p_name=>'P470_ZIEL_VORSCHRIFT_NUMMER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Zielvorschrift Nummer'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vorschrift_nummer',
'from t_vorschrift',
'where vorschriftid = :P470_ZIEL_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988418699563377943)
,p_name=>'P470_ZIEL_VORSCHRIFTID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988418345050377943)
,p_name=>'P470_VORSCHRIFT_NOTATION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Vorschrift Notation'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select n.bezeichnung ',
'from t_vorschrift v',
'join t_norm n on (n.normid = v.normid)',
'where v.vorschriftid = :P470_ZIEL_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung, normid',
'from t_norm n where n.normid not in (1016)',
'order by 1'))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_inline_help_text=>unistr('Bitte w\00E4hlen Sie eine Notation')
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988417542246377942)
,p_name=>'P470_VORSCHRIFT_TYPID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Vorschrift Typ'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vt.bezeichnung  --vorschrift_typid ',
'from t_vorschrift v',
'join t_vorschrift_typ vt on (vt.vorschrift_typid = v.vorschrift_typid)',
'where v.vorschriftid = :P470_ZIEL_VORSCHRIFTID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_VORSCHRIFT_TYP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung ',
'        ELSE name_eng',
'    END AS d,',
'    vorschrift_typid AS r',
'FROM t_vorschrift_typ',
'ORDER BY 2;',
''))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988417201639377941)
,p_name=>'P470_EINSATZDATUM_MODELLID'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Einsatz DATUM Modell'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct m.modell ',
'from t_vorschrift v',
'join t_vorschrift_ref_einsatzdatum_typ vrt on (vrt.vorschriftid = v.vorschriftid)',
'join t_einsatzdatum_typ t on (t.einsatzdatum_typid = vrt.einsatzdatum_typid)',
'join t_einsatzdatum_modell m on (m.einsatzdatum_modellid = t.einsatzdatum_modellid)',
'where v.vorschriftid = :P470_ZIEL_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988416751242377941)
,p_name=>'P470_VORSCHRIFT_BEZEICHNUNG'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Titel (\00DCberschrift)')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select VORSCHRIFT_BEZEICHNUNG ',
'from t_vorschrift',
'where vorschriftid = :P470_ZIEL_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988416342332377941)
,p_name=>'P470_FREIGABESTATUS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Interner DB Freigabestatus'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select   case v.VORSCHRIFT_FREIGABESTATUSID  ',
'    WHEN 10 THEN emano_util.fLang(''in Bearbeitung'', ''in Progress'')',
'        WHEN 20 THEN emano_util.fLang(''sichtbar in Regulation index DB'', ''visible in Regulation index DB'')',
'        WHEN 30 THEN emano_util.fLang(''nicht Relevant'', ''not Relevant'')',
'        ELSE emano_util.fLang(''undefined'', ''undefined'')  end "status"',
'from t_vorschrift v where v.vorschriftid = :P470_ZIEL_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988416007811377941)
,p_name=>'P470_RXSWIN'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_use_cache_before_default=>'NO'
,p_prompt=>'potentiell SW-Relevant'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case nvl(rxswin,0) when 10 then  emano_util.fLang(''Ja'', ''Yes'')',
unistr('      when 20 then emano_util.fLang(''nicht gepr\00FCft'', ''Not checked'')'),
'             else emano_util.fLang(''Nein'', ''No'') end translated_value',
'from t_vorschrift',
'where vorschriftid = :P470_ZIEL_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988415614216377940)
,p_name=>'P470_HOMOLOGATIONSRELEVANT'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_use_cache_before_default=>'NO'
,p_prompt=>' Homologationsrelevant'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case nvl(homologationsrelevant,0) when 10 then emano_util.fLang(''Ja'', ''Yes'')',
unistr('when 20 then emano_util.fLang(''nicht gepr\00FCft'', ''Not checked'')'),
'     else emano_util.fLang(''Nein'', ''No'') end translated_value',
'from t_vorschrift',
'where vorschriftid = :P470_ZIEL_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988415186157377940)
,p_name=>'P470_FAHRZEUGKLASSE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fahrzeugklasse'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(fk.bezeichnung,  '', '') within group (order by fk.bezeichnung) ',
'from t_vorschrift_ref_fahrzeugklasse vrf',
'join t_fahrzeugklasse fk on (fk.fahrzeugklasseid = vrf.fahrzeugklasseid)',
'where vrf.vorschriftid = :P470_ZIEL_VORSCHRIFTID;'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988414791878377940)
,p_name=>'P470_BEMERKUNG'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_prompt=>'Bemerkung zur Vorschrift'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.bemerkung  ',
'from t_vorschrift v',
'where v.vorschriftid = :P470_ZIEL_VORSCHRIFTID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988414403415377939)
,p_name=>'P470_LINK_ZUR_VORSCHRIFT_DMS_RO'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu DMS'
,p_format_mask=>'<span style="text-decoration-line: underline"></span>'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PCK_RI.fCreateLinkIfUrl(v.link_zur_vorschrift_dms, 80)',
'from t_vorschrift v',
'where v.vorschriftid = :P470_ZIEL_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="text-decoration: underline; text-decoration-style: dashed"'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988413947411377939)
,p_name=>'P470_LINK_REQMAN_RO'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu REQMAN'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PCK_RI.fCreateLinkIfUrl(v.link_reqman, 80)',
'from t_vorschrift v',
'where v.vorschriftid = :P470_ZIEL_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="text-decoration: underline; text-decoration-style: dashed"'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988413554387377938)
,p_name=>'P470_LINK_ZUR_VORSCHRIFT_GETEX'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_prompt=>'Getex 1.0 ID'
,p_post_element_text=>unistr('<a style="margin-left: 5px; margin-top: 5px" href="https://getex.wob.vw.vwg/web/guest/dokumente_suche" target="_blank"><button class="t-Button" type="button">Getex 1.0 \00F6ffnen</button></a>')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select LINK_ZUR_VORSCHRIFT_GETEX',
'from t_vorschrift',
' where vorschriftid = :P470_ZIEL_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988413191796377938)
,p_name=>'P470_WEBSITEID'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Webseite'
,p_source=>'WEBSITEID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT w.WEBSITE_NAME, w.WEBSITEID',
'FROM T_WEBSITE w',
'ORDER BY 1',
''))
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988412818541377937)
,p_name=>'P470_WEBSITELINK_RO'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu Web Site'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  pck_ri.fcreateLinkIfUrl(websitelink)',
'from t_vorschrift v',
'where v.vorschriftid = :P470_ZIEL_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="text-decoration: underline; text-decoration-style: dashed"'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988412401702377937)
,p_name=>'P470_KSU'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_item_default=>'1020'
,p_prompt=>'KSU'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select k.bezeichnung ',
'from t_ksu k where k.ksuid = (select ksuid from t_Vorschrift where vorschriftid=:P470_ZIEL_VORSCHRIFTID);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select k.bezeichnung, k.ksuid',
'from t_ksu k',
'order by k.bezeichnung'))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988411938111377937)
,p_name=>'P470_TECHNOLOGIE'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Technologie'
,p_source=>'TECHNOLOGIE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988411613409377937)
,p_name=>'P470_VERANTWORTLICHE'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Regulierungsverantwortliche'
,p_post_element_text=>'&nbsp;<span onclick="redirect(322)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(nachname || '', '' || vorname || '' ('' || abteilung || '')'', '', '') within group (order by nachname)',
'    from t_vorschrift_ref_verantwortlicher vrv',
'    left outer join t_verantwortlicher v on (vrv.verantwortlicherid = v.verantwortlicherid)',
'    where vrv.vorschriftid = :P470_ZIEL_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988411153676377937)
,p_name=>'P470_STICHWOERTER'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(588486118822221526)
,p_prompt=>'Stichwoerter'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(sw.stext,  '', '') within group (order by sw.stext)',
'    from t_vorschrift_ref_schlagwort vrs',
'    join t_schlagwort sw on (sw.schlagwortid = vrs.schlagwortid)',
'   where vrs.vorschriftid = :P470_ZIEL_VORSCHRIFTID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988407222770316431)
,p_name=>'P470_SRC_VORSCHRIFTID_S'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_prompt=>'Vorschriftennummer'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
' l_co number :=0;',
'  l_fuid  number :=0;',
' begin ',
'    select  count( v.vorschriftid) into l_co   ',
'        from t_vorschrift_ref_vorschrift vrv',
'        join t_vorschrift v on (v.vorschriftid = vrv.vorgaenger_vorschriftid and vrv.nachfolger_vorschriftid = :P470_ZIEL_VORSCHRIFTID)',
'        where   v.vorschriftid != :P470_ZIEL_VORSCHRIFTID',
'        order by v.vorschrift_nummer;',
'    if(l_co = 1) then',
'      ',
'       select   v.vorschriftid  into l_fuid',
'        from t_vorschrift_ref_vorschrift vrv',
'        join t_vorschrift v on (v.vorschriftid = vrv.vorgaenger_vorschriftid and vrv.nachfolger_vorschriftid = :P470_ZIEL_VORSCHRIFTID)',
'        where   v.vorschriftid != :P470_ZIEL_VORSCHRIFTID;',
'        return l_fuid;',
'    elsif(l_co > 1) then',
'       select  vorschriftid into l_fuid from',
'        ( select  row_number() over(order by rownum) rn,  v.vorschriftid  vorschriftid',
'           from t_vorschrift_ref_vorschrift vrv',
'        join t_vorschrift v on (v.vorschriftid = vrv.vorgaenger_vorschriftid and vrv.nachfolger_vorschriftid = :P470_ZIEL_VORSCHRIFTID)',
'        where   v.vorschriftid != :P470_ZIEL_VORSCHRIFTID',
'        ) where rn =1;',
'        --debug(''P470_SRC_VORSCHRIFTID_S found='' || :P470_SRC_VORSCHRIFTID_S);',
'        return l_fuid;',
'    else   ',
'        return null;',
'    end if;',
' end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select  v.vorschrift_nummer d, v.vorschriftid r   ',
'        from t_vorschrift v ',
'        where  v.vorschriftid != :P470_ZIEL_VORSCHRIFTID',
'        order by v.vorschrift_nummer'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988406820482316430)
,p_name=>'P470_SRC_VORSCHRIFT_NOTATION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Vorschrift Notation'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select n.normid --n.bezeichnung , n.normid',
'from t_vorschrift v',
'join t_norm n on (n.normid = v.normid)',
'where v.vorschriftid = :P470_SRC_VORSCHRIFTID_S'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung d, normid r',
'from t_norm n where n.normid not in (1016)',
'order by 1'))
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_inline_help_text=>unistr('Bitte w\00E4hlen Sie eine Notation')
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988406354912316429)
,p_name=>'P470_SRC_WITHOUT_NORM_VALIDATION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_prompt=>'Notation nicht validieren'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  (case WHEN (:P470_SRC_VORSCHRIFT_NOTATION is not null and :P470_SRC_VORSCHRIFT_NOTATION != 1016)  then 0 ',
'else 1 end) as cb from dual;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC(,):&nbsp;1'
,p_grid_label_column_span=>4
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('W\00E4hle die Checkbox, wenn die ausgew\00E4hlte Notation nicht validiert werden soll.'),
unistr('In diesem Fall wird automatisch eine Benachrichtigung f\00FCr die Fachadministratoren erstellt.')))
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988405444209316426)
,p_name=>'P470_NOTATION_BEISPIEL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988405069096316425)
,p_name=>'P470_SRC_VORSCHRIFT_TYPID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Vorschrift Typ'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*select  decode( vorschrift_typid, 10, emano_util.fLang(''Vorschrift'', ''Regulation''),',
'  20, emano_util.fLang(''Supplement UN-R'', ''Supplement UN-R''),',
'  30, emano_util.fLang(''Rahmenverordnung, GSR, Rahmenrichtlinie'', ''Framework regulation, GSR, Framework directive''),',
unistr('  40, emano_util.fLang(''Norm zwingend f\00FCr Homologation notwendig'', ''Mandatory standard for homologation''),'),
'  50, emano_util.fLang(''Amendment'', ''Amendment''), emano_util.fLang(''Vorschrift'', ''Regulation'')',
'  ) as display_value',
'from t_vorschrift',
'where vorschriftid = :P470_SRC_VORSCHRIFTID_S;*/',
'select vt.vorschrift_typid --vt.bezeichnung  --',
'from t_vorschrift v',
'join t_vorschrift_typ vt on (vt.vorschrift_typid = v.vorschrift_typid)',
'where v.vorschriftid = :P470_SRC_VORSCHRIFTID_S;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_VORSCHRIFT_TYP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung ',
'        ELSE name_eng',
'    END AS d,',
'    vorschrift_typid AS r',
'FROM t_vorschrift_typ',
'ORDER BY 2;',
''))
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988404719791316425)
,p_name=>'P470_SRC_EINSATZDATUM_MODELLID'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Einsatz DATUM Modell'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.einsatzdatum_modellid ',
'from t_vorschrift v',
'join t_einsatzdatum_modell m on (m.einsatzdatum_modellid = v.einsatzdatum_modellid )',
'where vorschriftid = :P470_SRC_VORSCHRIFTID_S'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_EINSATZDATUM_MODELL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT EINSATZDATUM_MODELLID, CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN MODELL ELSE MODELL_ENG END FROM T_EINSATZDATUM_MODELL;',
''))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988404251549316425)
,p_name=>'P470_SRC_VORSCHRIFT_BEZEICHNUNG'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Titel (\00DCberschrift)')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vorschrift_bezeichnung ',
'from t_vorschrift',
'where vorschriftid = :P470_SRC_VORSCHRIFTID_S'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988403852654316425)
,p_name=>'P470_SRC_FREIGABE_STATUS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Interner Freigabe Status'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   decode(v.vorschrift_freigabestatusid, 1, emano_util.fLang(''Import'', ''Import''), 10, emano_util.fLang(''VKO-/VEX Prozess-Bearbeitung'', ''VKO-/VEX Process Editing''), ',
'                                                    20, emano_util.fLang(''Sichtbar in Regulation Index DB'', ''Visible in Regulation Index DB''), ',
'                                                    30, emano_util.fLang(''nicht relevant'', ''Not Relevant''), emano_util.fLang(''nicht relevant'', ''Not Relevant'')) status_desc',
'        FROM t_vorschrift v  --t_vorschrift_ref_vorschrift vrv',
'        --join t_vorschrift v on (v.vorschriftid = vrv.vorgaenger_vorschriftid)',
'        where --vrv.nachfolger_vorschriftid = :P470_ZIEL_VORSCHRIFTID and ',
'        v.vorschriftid = :P470_SRC_VORSCHRIFTID_S;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>5
,p_grid_column=>1
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988403494137316425)
,p_name=>'P470_SRC_RXSWIN'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_prompt=>'potentiell SW-Relevant'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
unistr('   decode(v.rxswin, 10, emano_util.fLang(''Ja'', ''Yes''), 0, emano_util.fLang(''Nein'', ''No''), 20, emano_util.fLang(''nicht gepr\00FCft'', ''Not checked'')'),
unistr('   , emano_util.fLang(''nicht gepr\00FCft'', ''Not checked'')  ) as display_value'),
'from t_vorschrift v',
'where v.vorschriftid = :P470_SRC_VORSCHRIFTID_S'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_protection_level=>'B'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988403038291316424)
,p_name=>'P470_SRC_HOMOLOGATIONSRELEVANT'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Homologationsrelevant'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select decode(homologationsrelevant,  10 , emano_util.fLang(''Ja'', ''Yes''),',
unistr('   20 , emano_util.fLang(''nicht gepr\00FCft'', ''Not checked''),'),
unistr('    0 , emano_util.fLang(''Nein'', ''No''), emano_util.fLang(''nicht gepr\00FCft'', ''Not checked'')  ) as  display_value'),
'from t_vorschrift',
'where vorschriftid = :P470_SRC_VORSCHRIFTID_S'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_protection_level=>'B'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988402673678316424)
,p_name=>'P470_SRC_FAHRZEUGKLASSE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fahrzeugklasse'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(fahrzeugklasseid, '':'')',
'from t_vorschrift_ref_fahrzeugklasse',
'where vorschriftid = :P470_SRC_VORSCHRIFTID_S;'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung d, fahrzeugklasseid r',
'from t_fahrzeugklasse',
'order by bezeichnung asc'))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988402269005316423)
,p_name=>'P470_SRC_VORSCHRIFTID'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988401924867316423)
,p_name=>'P470_SRC_BEMERKUNG'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_item_default=>'P470_SRC_BEMERKUNG'
,p_item_default_type=>'ITEM'
,p_prompt=>'Bemerkung zur Vorschrift'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bemerkung ',
'from t_vorschrift',
'where vorschriftid = :P470_SRC_VORSCHRIFTID_S'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988401528248316422)
,p_name=>'P470_SRC_LINK_ZUR_VORSCHRIFT_DMS'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu DMS (Ein Link pro Zeile)'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select LINK_ZUR_VORSCHRIFT_DMS ',
'from t_vorschrift',
'where vorschriftid = :P470_SRC_VORSCHRIFTID_S'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>'&nbsp;'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988401058952316421)
,p_name=>'P470_SRC_LINK_REQMAN'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu ReqMan (Ein Link pro  Zeile)'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select LINK_REQMAN',
'from t_vorschrift',
'where vorschriftid = :P470_SRC_VORSCHRIFTID_S'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>'&nbsp;'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988400721793316421)
,p_name=>'P470_SRC_LINK_ZUR_VORSCHRIFT_GETEX'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Getex 1.0 ID'
,p_post_element_text=>unistr('<a style="margin-left: 5px; margin-top: 5px" href="https://getex.wob.vw.vwg/web/guest/dokumente_suche" target="_blank"><button class="t-Button" type="button">Getex 1.0 \00F6ffnen</button></a>')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select LINK_ZUR_VORSCHRIFT_GETEX ',
'from t_vorschrift',
'where vorschriftid = :P470_SRC_VORSCHRIFTID_S'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988400264835316419)
,p_name=>'P470_SRC_WEBSITEID'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Webseite'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select websiTeid ',
'from t_vorschrift',
'where vorschriftid = :P470_SRC_VORSCHRIFTID_S'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT w.WEBSITE_NAME, w.WEBSITEID',
'FROM T_WEBSITE w',
'ORDER BY 1',
''))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988399864287316419)
,p_name=>'P470_SRC_WEBSITELINK'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu Web Site'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select WEBSITELINK',
'from t_vorschrift',
'where vorschriftid = :P470_SRC_VORSCHRIFTID_S'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_css_classes=>'style="text-decoration: underline; text-decoration-style: dashed"'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988399520770316418)
,p_name=>'P470_SRC_KSU'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1020'
,p_prompt=>'KSU'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ksuid',
'from t_vorschrift',
'where vorschriftid = :P470_SRC_VORSCHRIFTID_S'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select k.bezeichnung, k.ksuid',
'from t_ksu k',
'order by k.bezeichnung'))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988399054725316418)
,p_name=>'P470_SRC_TECHNOLOGIE'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Technologie'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select technologie',
'from t_vorschrift',
'where vorschriftid = :P470_SRC_VORSCHRIFTID_S'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988398681726316418)
,p_name=>'P470_SRC_VERANTWORTLICHE'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(nachname || '', '' || vorname || '' ('' || abteilung || '')'', '', '') within group (order by nachname)',
'    from t_vorschrift_ref_verantwortlicher vrv',
'    left outer join t_verantwortlicher v on (vrv.verantwortlicherid = v.verantwortlicherid)',
'    where vrv.vorschriftid = :P470_SRC_VORSCHRIFTID_S'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988398285880316418)
,p_name=>'P470_SRC_STICHWOERTER'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(507924692465728216)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(sw.stext,  '', '') within group (order by sw.stext)',
'    from t_vorschrift_ref_schlagwort vrs',
'    join t_schlagwort sw on (sw.schlagwortid = vrs.schlagwortid)',
'   where vrs.vorschriftid = :P470_SRC_VORSCHRIFTID_S;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(988448591632471090)
,p_name=>'Cancel Dialog'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(988449013665471091)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(988447751392471085)
,p_event_id=>wwv_flow_imp.id(988448591632471090)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(990120513941731694)
,p_name=>'Change'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P470_SRC_VORSCHRIFTID_S'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(990120307997731692)
,p_event_id=>wwv_flow_imp.id(990120513941731694)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' begin ',
'   --debug(''p470, :P470_SRC_VORSCHRIFTID_S='' || :P470_SRC_VORSCHRIFTID_S);',
'    if(:P470_SRC_VORSCHRIFTID_S is not null)  then   ',
'',
'         with fzg as ( select listagg(fahrzeugklasseid, '':'') fzg_klasseids, vorschriftid from t_vorschrift_ref_fahrzeugklasse',
'                        group by vorschriftid',
'         ) --, cte_norm as ( select bezeichnung, normid from t_norm where  normid =(select normid from t_vorschrift where vorschriftid = :P470_SRC_VORSCHRIFTID_S)',
'         --)',
'         ',
'          select n.bezeichnung, --n.normid,      ',
'            without_norm_validation, decode( v.vorschrift_typid, 10, emano_util.fLang(''Vorschrift'', ''Regulation''),',
'  20, emano_util.fLang(''Supplement UN-R'', ''Supplement UN-R''),',
'  30, emano_util.fLang(''Rahmenverordnung, GSR, Rahmenrichtlinie'', ''Framework regulation, GSR, Framework directive''),',
unistr('  40, emano_util.fLang(''Norm zwingend f\00FCr Homologation notwendig'', ''Mandatory standard for homologation''),'),
'  50, emano_util.fLang(''Amendment'', ''Amendment''), emano_util.fLang(''Vorschrift'', ''Regulation'')  ),',
'          decode (v.einsatzdatum_modellid, 10, emano_util.fLang(''Einsatzdatum Neuer Typ, Alle Fahrzeuge'',''Date of use New type, All vehicles'' ),',
'       20, emano_util.fLang(''Einsatzdatum Neuer Typ CKD/FBU, Alle Fahrzeuge CKD/FBU'',''Date of use New type CKD/FBU, All vehicles CKD/FBU'' ),',
'            30, emano_util.fLang(''Modelljahr'',''Model yea'' ),',
'            emano_util.fLang(''Einsatzdatum Neuer Typ, Alle Fahrzeuge'',''Date of use New type, All vehicles'' )), ',
'          vorschrift_bezeichnung,',
'          decode(v.vorschrift_freigabestatusid  , 1, emano_util.fLang(''Import'', ''Import''), 10, emano_util.fLang(''VKO-/VEX Prozess-Bearbeitung'', ''VKO-/VEX Process Editing''), ',
'          20, emano_util.fLang(''Sichtbar in Regulation Index DB'', ''Visible in Regulation Index DB''), ',
'          30, emano_util.fLang(''nicht relevant'', ''Not Relevant''), emano_util.fLang(''nicht relevant'', ''Not Relevant'')),',
unistr('         decode(v.rxswin, 10, emano_util.fLang(''Ja'', ''Yes''), 0, emano_util.fLang(''Nein'', ''No''), 20, emano_util.fLang(''nicht gepr\00FCft'', ''Not checked''),'),
unistr('                 emano_util.fLang(''nicht gepr\00FCft'', ''Not checked'')  ), '),
unistr('         decode(homologationsrelevant,  10 , emano_util.fLang(''Ja'', ''Yes''),   20 , emano_util.fLang(''nicht gepr\00FCft'', ''Not checked''),'),
unistr('                0 , emano_util.fLang(''Nein'', ''No''), emano_util.fLang(''nicht gepr\00FCft'', ''Not checked'')  ), '),
'          fzg.fzg_klasseids, bemerkung, LINK_ZUR_VORSCHRIFT_DMS, LINK_REQMAN,',
'          LINK_ZUR_VORSCHRIFT_GETEX, websitelink, websiteid, ',
unistr('          decode (KSUID, 1041, ''Test'', 1040, ''Test'', 1042, ''KSU 2.2.'', 1080, emano_util.fLang( ''KSU Test (l\00F6schen)'', ''KSU Test (delete)''),'),
'          1000, emano_util.fLang( ''KSU 8.3 - kfm. Kommunikation'', ''KSU 8.3 - commercial communication''),',
'          1020, emano_util.fLang( ''4.2 Produktbezogene  QM-Vorgaben'', ''Product-related QM specifications''),',
'          1060, emano_util.fLang( ''QM WSTR (1) KSU Test'', ''QM WSTR (1) KSU Test''), ''Test'' ), technologie',
'                ',
'          into  :P470_SRC_VORSCHRIFT_NOTATION, ',
'          :P470_SRC_WITHOUT_NORM_VALIDATION, :P470_SRC_VORSCHRIFT_TYPID, :P470_SRC_EINSATZDATUM_MODELLID,',
'          :P470_SRC_VORSCHRIFT_BEZEICHNUNG,',
'          :P470_SRC_FREIGABE_STATUS, ',
'          :P470_SRC_RXSWIN, :P470_SRC_HOMOLOGATIONSRELEVANT, ',
'          :P470_SRC_FAHRZEUGKLASSE, :P470_SRC_BEMERKUNG, :P470_SRC_LINK_ZUR_VORSCHRIFT_DMS, :P470_SRC_LINK_REQMAN, ',
'          :P470_SRC_LINK_ZUR_VORSCHRIFT_GETEX,  :P470_SRC_WEBSITELINK, :P470_SRC_WEBSITEID, :P470_SRC_KSU, :P470_SRC_TECHNOLOGIE',
'        from t_vorschrift v ',
'        left outer join fzg  on (fzg.vorschriftid = v.vorschriftid)',
'        join t_norm n on (n.normid = v.normid)',
'        where v.vorschriftid = :P470_SRC_VORSCHRIFTID_S;',
'       -- debug(''p470, :P470_SRC_BEMERKUNG='' || :P470_SRC_BEMERKUNG);',
'    end if;',
'end;'))
,p_attribute_02=>'P470_SRC_VORSCHRIFTID_S'
,p_attribute_03=>'P470_SRC_WITHOUT_NORM_VALIDATION,P470_SRC_VORSCHRIFT_NOTATION,P470_SRC_VORSCHRIFT_BEZEICHNUNG,P470_SRC_VORSCHRIFT_TYPID,P470_SRC_EINSATZDATUM_MODELLID,P470_SRC_FREIGABE_STATUS,P470_SRC_RXSWIN,P470_SRC_HOMOLOGATIONSRELEVANT,P470_SRC_FAHRZEUGKLASSE,P47'
||'0_SRC_LINK_ZUR_VORSCHRIFT_DMS,P470_SRC_LINK_ZUR_VORSCHRIFT_GETEX,P470_SRC_WEBSITEID,P470_SRC_WEBSITELINK,P470_SRC_KSU,P470_SRC_TECHNOLOGIE,P470_SRC_VORSCHRIFTID,P470_SRC_BEMERKUNG'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
