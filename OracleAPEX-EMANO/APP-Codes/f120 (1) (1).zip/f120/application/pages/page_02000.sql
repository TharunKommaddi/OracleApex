prompt --application/pages/page_02000
begin
--   Manifest
--     PAGE: 02000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>2000
,p_name=>unistr('Analyse letzt g\00FCltige Fassung')
,p_alias=>'GETEX-MIGRATION'
,p_step_title=>unistr('Analyse letzt g\00FCltige Fassung')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#P20_SHORT'').detach().prependTo(''#VSIG div.a-IRR-buttons'').css(''margin-right'',''10px'').css(''margin-top'',''5px'');',
'$(''#P20_SUPPLEMENTS'').detach().prependTo(''#VSIG div.a-IRR-buttons'').css(''margin-right'',''10px'').css(''margin-top'',''5px'');',
'$(''#VSIG div.a-IRR-buttons'').css(''display'',''flex'').css(''justify-content'',''flex-end'');',
'$(''#P20_SHORT_CONTAINER'').closest(''div.row'').remove();',
'',
'/* Click auf Checkbox in Tabellenheader: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'$(''#VSIG'').on(''click'', ''th input'', function() {',
'    var check_all = $("#VSIG").find("th input:checked").is(":checked");',
'',
unistr('    // alle Zeilen ausw\00E4hlen/abw\00E4hlen'),
'    $("#VSIG").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'    // Button aktivieren/deaktivieren',
'    if (check_all) {',
'        $("#b_MB").removeClass("apex_disabled");',
'    } else {',
'        $("#b_MB").addClass("apex_disabled");',
'    }',
'',
'    $("#b_MB").prop(''disabled'', !check_all);',
'    ',
unistr('    // alle ausgew\00E4hlten Zeilen-IDs in das Item P20_SELECTED_ROWS'),
'    var sel_rows = apex.item(''P2000_SELECTED_ROWS'');',
'    sel_rows.setValue("");',
'    $("#VSIG").find("td input:checked").each(function() {',
'      if(sel_rows.getValue().length > 0) {',
'        sel_rows.setValue(sel_rows.getValue() + ":");    ',
'      }',
'      sel_rows.setValue(sel_rows.getValue() + this.value);',
'    });',
'    apex.server.process(''MY_PROCESS'', {',
'        pageItems: ''#P2000_SELECTED_ROWS''',
'    },{dataType: ''text''});',
'    //alert (sel_rows.getValue());',
'});',
'',
'// Hilfe Button',
'$(''#VSIG_toolbar_controls'').append('' <span onclick="redirect(4)" style="font-size:2.7em" class="fa fa-question-square-o"></span>'');',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#VSIG .t-fht-tbody {max-height: calc(100vh - 260px)}',
'.t-Body-topButton {display: none !important}',
'.t-Body-content {padding-bottom: 3px !important}',
'.t-Body {margin-bottom: 3px !important}',
'.t-Body-contentInner {padding-bottom: 0px !important}',
'',
'#VSIG_filter_type > .a-IRR-radioIconList-item:nth-child(3) {',
'    display: none;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2820122537988676451)
,p_plug_name=>'Vorschriften <span onclick="redirect(4)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'
,p_region_name=>'VSIG'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with r as (',
'  select  v.vorschriftid vorschriftid,',
'          v.DOCUMENT_TYPEID, ',
'          v.PUBLISHER,',
'          (select listagg(distinct l.LAND,'', '' on overflow truncate) ',
'           within group (order by l.LAND)',
'           from t_land l, t_vorschrift_ref_land vrl',
'           where vrl.LANDID = l.LANDID ',
'           and vrl.VORSCHRIFTID = v.VORSCHRIFTID) liste_land,',
'          ',
'          (select listagg(distinct lg.LAENDERGRUPPE, '', '' on overflow truncate) ',
'           within group (order by lg.LAENDERGRUPPE)',
'           from t_laendergruppe lg, T_LAND_REF_LAENDERGRUPPE lrl, t_vorschrift_ref_land vrl',
'           where vrl.LANDID = lrl.LANDID ',
'           and lrl.LAENDERGRUPPEID = lg.LAENDERGRUPPEID ',
'           and vrl.VORSCHRIFTID = v.VORSCHRIFTID) liste_laendergruppe,',
'           ',
'           listagg(tb.BEZIEHUNG_ART, '', '' on overflow truncate) ',
'           within group (order by tv2.vorschrift_nummer) liste_BEZIEHUNG_ART,',
'           ',
'           (SELECT CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' ',
'                       THEN bezeichnung ',
'                       ELSE name_eng ',
'                  END d ',
'            FROM t_vorschrift_typ',
'            where vorschrift_typid = v.VORSCHRIFT_TYPID) VORSCHRIFT_TYPID,',
'            ',
'            listagg(tv2.vorschrift_nummer, '', '' on overflow truncate) ',
'            within group (order by tv2.vorschrift_nummer) liste_Vernetzte_Vorschrift,',
'            ',
'            listagg((SELECT emano_util.fLang(text_deutsch, text_englisch) ',
'                    FROM t_document_type ',
'                    WHERE document_typeid = tv2.DOCUMENT_TYPEID), ',
'                   '', '' on overflow truncate) ',
'            within group (order by tv2.vorschrift_nummer) liste_Vernetzte_DOCUMENT_TYPE,',
'',
'          -- Themengebiete for main regulation - with number and name',
'            (select listagg(distinct t.NUMMER || '' - '' || ',
'                   CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' ',
'                        THEN t.BEZEICHNUNG ',
'                        ELSE t.NAME_ENG END, ',
'                   '', '' on overflow truncate) ',
'             within group (order by t.NUMMER)',
'             from t_vorschrift_ref_thema vrt',
'             join t_thema t on (t.THEMAID = vrt.THEMAID)',
'             where vrt.VORSCHRIFTID = v.VORSCHRIFTID ',
'             and nvl(vrt.GELOESCHT, 0) = 0) liste_themengebiete,',
'',
'            -- Linked regulations - Status der Vorschrift (TEXT)',
'            listagg(',
'                DECODE(tv2.VORSCHRIFT_STATUSID, ',
'                       20, ''Draft'', ',
'                       21, ''Announcement'', ',
'                       30, ''Final document'', ',
'                       40, ''Enacted'', ',
'                       100, ''Expired'', ',
'                       ''-''), ',
'                '', '' on overflow truncate) ',
'            within group (order by tv2.vorschrift_nummer) liste_Vernetzte_Status,',
'            ',
'            -- Linked regulations - Internal DB Status (TEXT)',
'            listagg(',
'                DECODE(tv2.VORSCHRIFT_FREIGABESTATUSID, ',
'                       -1, ''Neue Vorschrift aus GETEX'', ',
unistr('                       1, ''Grundbef\00FCllung (sichtbar f\00FCr VKO)'', '),
unistr('                       10, ''in Bearbeitung (sichtbar f\00FCr VKO und VEX)'', '),
unistr('                       20, ''Freigegeben (sichtbar f\00FCr alle User)'', '),
unistr('                       30, ''nicht relevant f\00FCr diesen PS/Workflow (sichtbar f\00FCr VKO und VEX)'', '),
'                       ''-''), ',
'                '', '' on overflow truncate) ',
'            within group (order by tv2.vorschrift_nummer) liste_Vernetzte_Freigabestatus',
'',
'',
'',
'',
'',
'',
'            ',
'',
'',
'           ',
'',
'',
'',
'',
'',
'            ',
'  from t_vorschrift v',
'          left join t_vorschrift_ref_vorschrift vrv ',
'                on (v.vorschriftid = vrv.vorgaenger_vorschriftid ',
'                    and vrv.beziehung_art not in (10,102,40,200,20,30,60) ',
'                    or (v.vorschriftid = vrv.nachfolger_vorschriftid ',
'                        and vrv.beziehung_art in (10,102,40,200,20,30,60)))',
'                        ',
'          left outer join t_vorschrift tv2 ',
'                on (tv2.vorschriftid = vrv.vorgaenger_vorschriftid ',
'                    and vrv.beziehung_art in (10,102,40,200,20,30,60) ',
'                    or (tv2.vorschriftid = vrv.nachfolger_vorschriftid ',
'                        and vrv.beziehung_art not in (10,102,40,200,20,30,60)))',
'                        ',
'          left outer join t_beziehung_art tb ',
'                on (vrv.BEZIEHUNG_ART = tb.BEZIEHUNG_ARTid)',
'          ',
'     group by v.vorschriftid, v.DOCUMENT_TYPEID, v.PUBLISHER, ',
'            --   v.VORSCHRIFT_FREIGABESTATUSID,',
'               v.VORSCHRIFT_TYPID ',
'              ',
')',
'',
'select vs."ROWID" as xrowid,',
'       1 as checkbox,',
'       vs.vorschriftid,',
'       vs.vorschriftid as link_netz,',
'       "VORSCHRIFT_NUMMER",',
'       apex_util.host_url(''SCRIPT'') || apex_page.get_url(',
'           p_application => :APP_ALIAS,',
'           p_page => ''VORSCHRIFT'',',
'           p_items => ''P25_VORSCHRIFTID'',',
'           p_values => vs.vorschriftid,',
'           p_session => null,',
'           p_clear_cache => ''25''',
'       ) as permalink,',
'       (SELECT emano_util.fLang(text_deutsch, text_englisch) ',
'        FROM t_document_type ',
'        WHERE document_typeid = vs.DOCUMENT_TYPEID) as DOCUMENT_TYPE,',
'       vs.PUBLISHER,',
'       r.liste_land,',
'       r.liste_laendergruppe, ',
'       liste_BEZIEHUNG_ART,',
'       r.VORSCHRIFT_TYPID,',
'',
'',
'',
'               ',
'',
'',
'       liste_Vernetzte_Vorschrift,',
'       liste_Vernetzte_DOCUMENT_TYPE,',
'',
'       ',
'',
'       DECODE(vs.FLAG_KONSOLIDIERTE_FASSUNGEN, ',
'              0, emano_util.fLang(''Nein'', ''No''), ',
'              1, emano_util.fLang(''Ja'', ''Yes'')) as FLAG_KONSOLIDIERTE_FASSUNGEN,',
'',
'',
'       -- Main Regulation - THEMENGEBIETE',
'       r.liste_themengebiete as THEMENGEBIETE,',
'       ',
'       -- Main Regulation - Internal DB Status',
unistr('       DECODE(vs.VORSCHRIFT_FREIGABESTATUSID, -1, ''Neue Vorschrift aus GETEX'', 1, ''Grundbef\00FCllung (sichtbar f\00FCr VKO)'', 10, ''in Bearbeitung (sichtbar f\00FCr VKO und VEX)'', 20, ''Freigegeben (sichtbar f\00FCr alle User)'', 30, ''nicht relevant f\00FCr diesen PS/Work')
||unistr('flow (sichtbar f\00FCr VKO und VEX)'', ''-'') as INTERNER_DB_STATUS,'),
'       ',
'       -- Main Regulation - Status der Vorschrift',
'       DECODE(vs.VORSCHRIFT_STATUSID, 20, ''Draft'', 21, ''Announcement'', 30, ''Final document'', 40, ''Enacted'', 100, ''Expired'', ''-'') as STATUS_VORSCHRIFT,',
'',
'       -- Linked Regulations - Status (TEXT)',
'       r.liste_Vernetzte_Status as VERNETZTE_STATUS,',
'       ',
'       -- Linked Regulations - Internal DB Status (TEXT)',
'       r.liste_Vernetzte_Freigabestatus as VERNETZTE_DB_STATUS',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'from "#OWNER#"."T_VORSCHRIFT" vs',
'left join r on (r.vorschriftid = vs.vorschriftid)',
'where (vs.vorschrift_typid in (10, 30, 40, 20)',
'      )',
'-- and (vs.vorschrift_freigabestatusid = 20 ',
'--      or (pck_ri.fIsLimitedUser = 0 ',
'--          and vs.vorschrift_freigabestatusid != 1))',
'ORDER BY "VORSCHRIFT_NUMMER";'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P2000_SHORT,P2000_SUPPLEMENTS'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with r as (',
'  select  v.vorschriftid vorschriftid, --listagg(vv.nachname || '', '' || vv.vorname, ''; '') within group (order by vv.nachname) as verantwortlicher,',
'          v.DOCUMENT_TYPE, ',
'          v.PUBLISHER,',
'          (select listagg(distinct l.LAND,'', '' on overflow truncate) within group (order by l.LAND )from t_land l, t_vorschrift_ref_land vrl',
'            where vrl.LANDID = l.LANDID and vrl.VORSCHRIFTID = v.VORSCHRIFTID) liste_land,',
'          (select listagg(distinct lg.LAENDERGRUPPE, '', '' on overflow truncate) within group (order by lg.LAENDERGRUPPE)',
'            from t_laendergruppe lg, T_LAND_REF_LAENDERGRUPPE lrl, t_vorschrift_ref_land vrl',
'            where vrl.LANDID = lrl.LANDID and lrl.LAENDERGRUPPEID = lg.LAENDERGRUPPEID and vrl.VORSCHRIFTID = v.VORSCHRIFTID) liste_laendergruppe,',
'           listagg( tb.BEZIEHUNG_ART, '', '' on overflow truncate) within group (order by tv2.vorschrift_nummer) liste_BEZIEHUNG_ART,',
'        --   (select emano_util.fLang(name_deutsch,name_englisch) from t_vorschrift_freigabestatus',
'           -- where vorschrift_freigabestatusid = v.VORSCHRIFT_FREIGABESTATUSID) VORSCHRIFT_FREIGABESTATUSID,',
'           (SELECT CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung ELSE name_eng END d FROM t_vorschrift_typ',
'            where vorschrift_typid = v.VORSCHRIFT_TYPID) VORSCHRIFT_TYPID,',
'            listagg( tv2.vorschrift_nummer, '', '' on overflow truncate) within group (order by tv2.vorschrift_nummer) liste_Vernetzte_Vorschrift,',
'             listagg( tv2.DOCUMENT_TYPE, '', '' on overflow truncate) within group (order by tv2.vorschrift_nummer) liste_Vernetzte_DOCUMENT_TYPE',
'              -- vre.einsatzdatum in_kraft',
'  from t_vorschrift v',
'          left join t_vorschrift_ref_vorschrift vrv on (v.vorschriftid = vrv.vorgaenger_vorschriftid and vrv.beziehung_art not in (10,102,40) or',
'                                                    (v.vorschriftid = vrv.nachfolger_vorschriftid and vrv.beziehung_art  in (10,102,40)))',
'          left outer join t_vorschrift tv2 on (tv2.vorschriftid = vrv.vorgaenger_vorschriftid and vrv.beziehung_art in (10,102,40) or',
'                                                       ( tv2.vorschriftid = vrv.nachfolger_vorschriftid and vrv.beziehung_art not  in (10,102,40)))',
'          left outer join t_beziehung_art tb on (vrv.BEZIEHUNG_ART = tb.BEZIEHUNG_ARTid)',
'          ',
'     group by v.vorschriftid, v.DOCUMENT_TYPE, v.PUBLISHER, v.VORSCHRIFT_FREIGABESTATUSID, v.VORSCHRIFT_TYPID',
')',
'',
' select vs."ROWID" as xrowid,',
' 1 as checkbox,',
' vs.vorschriftid,',
' vs.vorschriftid as link_netz,',
' "VORSCHRIFT_NUMMER",',
'apex_util.host_url(''SCRIPT'') || apex_page.get_url(',
'    p_application => :APP_ALIAS',
'    , p_page => ''VORSCHRIFT''',
'    , p_items => ''P25_VORSCHRIFTID''',
'    , p_values => vs.vorschriftid',
'    , p_session => null',
'    , p_clear_cache => ''25''',
') as permalink,',
'-- r.liste_aa antriebsart',
' vs.DOCUMENT_TYPE,',
'  vs.PUBLISHER,',
'  r.liste_land,',
'  r.liste_laendergruppe, ',
'  liste_BEZIEHUNG_ART,',
' -- r.VORSCHRIFT_FREIGABESTATUSID,',
'  r.VORSCHRIFT_TYPID,',
'  liste_Vernetzte_Vorschrift,',
'  liste_Vernetzte_DOCUMENT_TYPE,',
'  DECODE(vs.FLAG_KONSOLIDIERTE_FASSUNGEN, ',
'         0, emano_util.fLang(''Nein'', ''No''), ',
'         1, emano_util.fLang(''Ja'', ''Yes'')) as FLAG_KONSOLIDIERTE_FASSUNGEN',
'from "#OWNER#"."T_VORSCHRIFT" vs   -- "#OWNER#"."T_VORSCHRIFT" vs',
'left join r on (r.vorschriftid = vs.vorschriftid)',
'where (vs.vorschrift_typid in (10, 30, 40) -- Supplements nicht anzeigen',
'       or vs.vorschrift_typid in (select case when (:P20_SUPPLEMENTS = 20) then 20 else 0 end from dual)  --:P20_SUPPLEMENTS ',
'      )',
'and (vs.vorschrift_freigabestatusid = 20 or (pck_ri.fIsLimitedUser = 0 and vs.vorschrift_freigabestatusid != 1)) -- Import nicht anzeigen',
'ORDER BY  "VORSCHRIFT_NUMMER";'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2820122884336676451)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'Keine Vorschriften gefunden.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>1000
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV'
,p_enable_mail_download=>'N'
,p_detail_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:RP,25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_detail_link_text=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_description=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 25,',
'                      accessMode => 100))'))
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>3932815821431810855
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(932776626868148575)
,p_db_column_name=>'XROWID'
,p_display_order=>10
,p_column_identifier=>'CQ'
,p_column_label=>'Xrowid'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(932776526752148574)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>20
,p_column_identifier=>'CR'
,p_column_label=>'<input type="checkbox" value="all" />'
,p_column_html_expression=>'<input type="checkbox" value="#VORSCHRIFTID#" />'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(932774457246148554)
,p_db_column_name=>'LINK_NETZ'
,p_display_order=>30
,p_column_identifier=>'DL'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:300:P300_VORSCHRIFTID:#LINK_NETZ#'
,p_column_linktext=>unistr('<span class="fa fa-network-hub" title="Vernetzungsansicht \00F6ffnen" alt="Vernetzungsansicht \00F6ffnen"></span>')
,p_column_link_attr=>'target="_blank"'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(932775119560148560)
,p_db_column_name=>'PERMALINK'
,p_display_order=>40
,p_column_identifier=>'DF'
,p_column_label=>'<span title="Permalink">&nbsp;</span>'
,p_column_html_expression=>'<span class="fa fa-link" title="Permalink in Zwischenablage kopieren" alt="Permalink in Zwischenablage kopieren" onClick="javascript:navigator.clipboard.writeText(''#PERMALINK#'');alert(''Der Permalink wurde in die Zwischenablage kopiert:\n\n#PERMALINK#'
||''');"></span>'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(932774537385148555)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>50
,p_column_identifier=>'DK'
,p_column_label=>'Vorschriftid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(931968863256582203)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>60
,p_column_identifier=>'DM'
,p_column_label=>'Vorschrift Nummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(932774871383148558)
,p_db_column_name=>'DOCUMENT_TYPE'
,p_display_order=>70
,p_column_identifier=>'DH'
,p_column_label=>'Document Type'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(932774807442148557)
,p_db_column_name=>'PUBLISHER'
,p_display_order=>80
,p_column_identifier=>'DI'
,p_column_label=>'Publisher'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(931967467456582189)
,p_db_column_name=>'LISTE_LAND'
,p_display_order=>90
,p_column_identifier=>'DP'
,p_column_label=>'Liste Land'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(931967387240582188)
,p_db_column_name=>'LISTE_LAENDERGRUPPE'
,p_display_order=>100
,p_column_identifier=>'DQ'
,p_column_label=>unistr('Liste L\00E4ndergruppe')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(931967079063582185)
,p_db_column_name=>'LISTE_BEZIEHUNG_ART'
,p_display_order=>110
,p_column_identifier=>'DS'
,p_column_label=>'Liste Beziehung Art'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(931966697111582181)
,p_db_column_name=>'VORSCHRIFT_TYPID'
,p_display_order=>130
,p_column_identifier=>'DW'
,p_column_label=>'Vorschrift Typ'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(930024504907842903)
,p_db_column_name=>'LISTE_VERNETZTE_VORSCHRIFT'
,p_display_order=>140
,p_column_identifier=>'DX'
,p_column_label=>'Liste Vernetzte Vorschrift'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(930024344125842902)
,p_db_column_name=>'LISTE_VERNETZTE_DOCUMENT_TYPE'
,p_display_order=>150
,p_column_identifier=>'DY'
,p_column_label=>'Liste Vernetzte Document Type'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3182770226444391812)
,p_db_column_name=>'FLAG_KONSOLIDIERTE_FASSUNGEN'
,p_display_order=>160
,p_column_identifier=>'DZ'
,p_column_label=>'Flag konsolidierte Fassung vorhanden'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(916344804279945427)
,p_db_column_name=>'THEMENGEBIETE'
,p_display_order=>170
,p_column_identifier=>'EB'
,p_column_label=>'Themengebiete'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(916344430330945424)
,p_db_column_name=>'VERNETZTE_STATUS'
,p_display_order=>200
,p_column_identifier=>'EE'
,p_column_label=>'Vernetzte Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(916344408635945423)
,p_db_column_name=>'VERNETZTE_DB_STATUS'
,p_display_order=>210
,p_column_identifier=>'EF'
,p_column_label=>'Vernetzte DB Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(916344222287945422)
,p_db_column_name=>'INTERNER_DB_STATUS'
,p_display_order=>220
,p_column_identifier=>'EG'
,p_column_label=>'Interner DB Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(916344166452945421)
,p_db_column_name=>'STATUS_VORSCHRIFT'
,p_display_order=>230
,p_column_identifier=>'EH'
,p_column_label=>'Status Vorschrift'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2820130587415681803)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1522075'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LINK_NETZ:CHECKBOX:PERMALINK:VORSCHRIFT_NUMMER:THEMENGEBIETE:INTERNER_DB_STATUS:STATUS_VORSCHRIFT:DOCUMENT_TYPE:PUBLISHER:VORSCHRIFT_TYPID:LISTE_LAND:LISTE_LAENDERGRUPPE:LISTE_BEZIEHUNG_ART:LISTE_VERNETZTE_VORSCHRIFT:VERNETZTE_DB_STATUS:VERNETZTE_STA'
||'TUS:LISTE_VERNETZTE_DOCUMENT_TYPE:FLAG_KONSOLIDIERTE_FASSUNGEN:'
,p_sort_column_1=>'VORSCHRIFT_NUMMER'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2857397400422965328)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2707059584407204267)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(934107500217724969)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2820122537988676451)
,p_button_name=>'LAENDER_INFO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('L\00E4nder')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-info-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(934106319563724963)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(2820122537988676451)
,p_button_name=>'CREATE_JIRA_TICKET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Jira Ticket Assistent'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:570:&SESSION.::&DEBUG.:570, 571, 572,,573, 574:P25_VORSCHRIFTID:'
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(934107062077724965)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(2820122537988676451)
,p_button_name=>'MEHRFACHBEARBEITUNG'
,p_button_static_id=>'b_MB'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Mehrfachbearbeitung'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:2005:&SESSION.::&DEBUG.:RP,2005:P2005_LOAD_FROM:"P2000_SELECTED_ROWS"'
,p_button_comment=>'(pck_ri.fIsAuthorized(pageId => 140, accessMode => 200))'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(934106657016724963)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(2820122537988676451)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_COP_RELEVANT,P25_VORSCHRIFT_FREIGABESTATUSID:0,1'
,p_button_condition_type=>'NEVER'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(userId => PCK_RI.fGetUserId, ',
'                      pageId => :APP_PAGE_ID,',
'                      accessMode => 200))'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(934115725122725025)
,p_name=>'P2000_SUPPLEMENTS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2820122537988676451)
,p_item_default=>'10'
,p_prompt=>'Supplenments'
,p_display_as=>'NATIVE_YES_NO'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144103148820565)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'ohne Supplements',
  'off_value', '10',
  'on_label', ' mit Supplements',
  'on_value', '20',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(934115249347725020)
,p_name=>'P2000_SHORT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2820122537988676451)
,p_item_default=>'10'
,p_prompt=>'Anzeige'
,p_display_as=>'NATIVE_YES_NO'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144103148820565)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Langversion',
  'off_value', '20',
  'on_label', 'Kurzversion',
  'on_value', '10',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(934105863315724962)
,p_name=>'P2000_URL_MEHRFACHBEARBEITUNG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2820122537988676451)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(934105520980724962)
,p_name=>'P2000_SELECTED_ROWS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2820122537988676451)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(934097959228724909)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2820122537988676451)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(934097438495724908)
,p_event_id=>wwv_flow_imp.id(934097959228724909)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2820122537988676451)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(934097090264724908)
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(934106657016724963)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(934096597058724907)
,p_event_id=>wwv_flow_imp.id(934097090264724908)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2820122537988676451)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(934096180444724906)
,p_name=>'Backup OPEN_MEHRFACHBEARBEITUNG_DIALOG'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(934107062077724965)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'NEVER'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(934094696252724904)
,p_event_id=>wwv_flow_imp.id(934096180444724906)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var sel_rows = apex.item(''P2000_SELECTED_ROWS'');',
'sel_rows.setValue("");',
'$("#VSIG").find("td input:checked").each(function() {',
'  if(sel_rows.getValue().length > 0) {',
'    sel_rows.setValue(sel_rows.getValue() + ":");    ',
'  }',
'  sel_rows.setValue(sel_rows.getValue() + this.value);',
'});',
'            '))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(934095153550724904)
,p_event_id=>wwv_flow_imp.id(934096180444724906)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :P2000_URL_MEHRFACHBEARBEITUNG := APEX_UTIL.PREPARE_URL (',
'        APEX_PAGE.GET_URL (',
'            p_page => 140,',
'            --p_triggering_element => ''#b_MB'',',
'            p_items => ''P140_SELECTED_VORSCHRIFTEN'',',
'            p_values => ''\'' || :P2000_SELECTED_ROWS || ''\'',',
'            p_clear_cache => 140),',
'        p_triggering_element => ''$(''''body'''')'');',
'            ',
'END;',
'',
'',
''))
,p_attribute_02=>'P2000_SELECTED_ROWS'
,p_attribute_03=>'P2000_URL_MEHRFACHBEARBEITUNG'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(934095650075724905)
,p_event_id=>wwv_flow_imp.id(934096180444724906)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'eval($(''#P2000_URL_MEHRFACHBEARBEITUNG'').val())',
' '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(934094266521724904)
,p_name=>'Mehrfachbearbeitung - Dialog Closed'
,p_event_sequence=>70
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'body'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(934093117083724902)
,p_event_id=>wwv_flow_imp.id(934094266521724904)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'//alert(''TEST'');'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(934093787672724903)
,p_event_id=>wwv_flow_imp.id(934094266521724904)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2820122537988676451)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(933492672591724902)
,p_name=>'Change Variante'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2000_SHORT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(933492147558724901)
,p_event_id=>wwv_flow_imp.id(933492672591724902)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.util.showSpinner();',
'window.location=''f?p=&APP_ID.:21:&APP_SESSION.'''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(934103845211724920)
,p_name=>'Zeilenselektor'
,p_event_sequence=>90
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'td input'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#VSIG'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(934103431936724916)
,p_event_id=>wwv_flow_imp.id(934103845211724920)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var any_checked = $("#VSIG").find("td input:checked").length > 0;',
'',
'if (any_checked) {',
'    $("#b_MB").removeClass("apex_disabled");',
'} else {',
'    $("#b_MB").addClass("apex_disabled");',
'}',
'',
'$("#b_MB").prop(''disabled'', !any_checked);',
'',
'var sel_rows = apex.item(''P2000_SELECTED_ROWS'');',
'sel_rows.setValue("");',
'$("#VSIG").find("td input:checked").each(function() {',
'  if(sel_rows.getValue().length > 0) {',
'    sel_rows.setValue(sel_rows.getValue() + ":");    ',
'  }',
'  sel_rows.setValue(sel_rows.getValue() + this.value);',
'});',
'            '))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(934102926709724915)
,p_event_id=>wwv_flow_imp.id(934103845211724920)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P2000_SELECTED_ROWS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(934099830086724910)
,p_name=>unistr('L\00E4nderinfo')
,p_event_sequence=>100
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'button#b_laender_info'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(934099271728724910)
,p_event_id=>wwv_flow_imp.id(934099830086724910)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'apex.server.process(',
'    ''prepare_laender'',                           ',
'    {',
'        x01: ''Mehrfachbearbeitung'',',
'        x02: $v(''P10_SELECTED_IDS'').replace(/:/g, "|")',
'    }, ',
'    {',
'        success: function (pData)',
'        {           ',
'            apex.navigation.redirect(pData);',
'        },',
'        dataType: "text"                     ',
'    }',
');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(934098837718724909)
,p_name=>unistr('Klick Button L\00E4nder Info')
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(934107500217724969)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(934098354051724909)
,p_event_id=>wwv_flow_imp.id(934098837718724909)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'javascript:window.open(''f?p=&APP_ID.:130:&SESSION.'',''_blank'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(934102530004724915)
,p_name=>'switch supplements'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2000_SUPPLEMENTS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(934101996792724913)
,p_event_id=>wwv_flow_imp.id(934102530004724915)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2820122537988676451)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(934100735619724911)
,p_name=>'hide create Jira ticket button'
,p_event_sequence=>130
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NOT_EXISTS'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from t_benutzer_ref_rolle where benutzerid=:G_BENUTZERID',
'AND rolleid in (1003,1000 )'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(934100209524724910)
,p_event_id=>wwv_flow_imp.id(934100735619724911)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(934106319563724963)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(934101540800724913)
,p_name=>'hide Mehrfachbearbeitung button'
,p_event_sequence=>140
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NOT_EXISTS'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from t_benutzer_ref_rolle where benutzerid=:G_BENUTZERID',
'AND rolleid in (1003,1000 )'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(934101130534724911)
,p_event_id=>wwv_flow_imp.id(934101540800724913)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(934107062077724965)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(934104292750724923)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'prepare_laender'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_url varchar2(2000);',
'    l_app number := v(''APP_ID'');',
'    l_session number := v(''APP_SESSION'');',
'',
'    --l_page_item VARCHAR2(2000) := case when apex_application.g_x01 = ''Einzelbearbeitung'' then ''P15_BEWERTUNG_ID'' when apex_application.g_x01 = ''Mehrfachbearbeitung'' then ''P15_SELECTED_IDS'' end;',
'BEGIN',
'    l_url := APEX_UTIL.PREPARE_URL(',
'        p_url => ''f?p='' || l_app || '':300:'' || l_session || ''::NO:300::'' || apex_application.g_x02,',
'        p_checksum_type => ''SESSION'');',
'    htp.p(l_url);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2738108023148663312
);
wwv_flow_imp.component_end;
end;
/
