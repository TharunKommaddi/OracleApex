prompt --application/pages/page_00104
begin
--   Manifest
--     PAGE: 00104
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>104
,p_name=>unistr('Vorschriften Themen Verkn\00FCpfung')
,p_alias=>unistr('VORSCHRIFTEN-THEMEN-VERKN\00DCPFUNG')
,p_page_mode=>'MODAL'
,p_step_title=>'Vorschriften Themen Zuordnung'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function loadThemenShuttle() {',
'    var shuttleName = ''P104_THEMENIDS'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadThemenShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P104_PRE_THEMENIDS''),',
'          //x03: $v(''P104_QUERSCHNITT_THEMEN_CB'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'function addItemToShuttle(aShuttle, aID, aDisplay) {',
'    var lLeft = $(''#'' + aShuttle + ''_LEFT'');',
'    var lRight = $(''#'' + aShuttle + ''_RIGHT'');',
'    lLeft.find(''option[value='' + aID + '']'').remove();',
'    lRight.append(''<option value="'' + aID + ''">'' + aDisplay + ''</option>'');',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Text-Item muss da sein, da sonst Submit bei Enter im Vorfilter-Feld',
'$(''#P104_TEXTFIELD'').closest(''div.row'').hide();',
'if(apex.item("P104_THEMAID").isEmpty())',
'{',
'    $x_Hide(''P104_BEMERKUNG'');',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_dialog_width=>'1200'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2707171913025953509)
,p_plug_name=>'THEMEN_ITEMS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2707172956081953519)
,p_plug_name=>'Button_Footer'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1048561271826979279)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2707172956081953519)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1048561725121979281)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2707172956081953519)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P104_OPEN_TO_DELETE'
,p_button_condition_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1048560857264979279)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2707172956081953519)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P104_OPEN_TO_DELETE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1048550724895979260)
,p_branch_name=>'parent_page_submit'
,p_branch_action=>'javascript:parent.apex.submit()'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'REQUEST_IN_CONDITION'
,p_branch_condition=>'SAVE,DELETE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1048568814757979290)
,p_name=>'P104_VORSCHRIFTID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2707171913025953509)
,p_prompt=>'Vorschrift'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select Vorschrift_nummer ||'' - ''||VORSCHRIFT_BEZEICHNUNG, vorschriftid',
'from T_vorschrift'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1048568368601979288)
,p_name=>'P104_THEMAID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2707171913025953509)
,p_prompt=>'Thema'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_THEMA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    NUMMER || '' - '' || ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN BEZEICHNUNG',
'        ELSE name_eng',
'    END as d,',
'    THEMAID as r',
'FROM V_THEMA_BAUM vtb',
'-- It excludes topics linked to et_b_akid = 1036 in t_thema_ref_et_b_ak, ensuring results are relevant to users without access to these excluded topics.',
'-- WHERE vtb.themaid not in (select themaid from t_thema_ref_et_b_ak where et_b_akid =1036 )',
'ORDER BY vtb.thema_sortorder;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P104_NEW_CREATE = 1 and :P104_EDIT_THEMEN is null and :P104_THEMA_READ_ONLY = 1)',
'or',
' (:P104_THEMAID is not null',
'  and (:P104_NEW_CREATE is null or :P104_NEW_CREATE= 0)',
'    )'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P104_THEMA_READ_ONLY = 1',
'or (:P104_NEW_CREATE is null or :P104_NEW_CREATE = 0)',
'or :P104_OPEN_TO_DELETE is not null',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1048566781316979287)
,p_name=>'P104_BEMERKUNG'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2707171913025953509)
,p_prompt=>'Bemerkung'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>3
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 1000 = VKO role, 1003 = Fachadmin role',
'(pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') = 0) ',
'OR ',
'(:P104_OPEN_TO_DELETE IS NOT NULL)'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'red only ',
'item is not null ',
'P104_OPEN_TO_DELETE'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1048565607124979286)
,p_name=>'P104_PRE_THEMENIDS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2707171913025953509)
,p_prompt=>'Vorfilter Themen'
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 48px; padding: 8px; border-radius: 0 2px 2px 0;" onclick="loadThemenShuttle()"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'((:P104_THEMAID is null and (:P104_NEW_CREATE is null or :P104_NEW_CREATE= 0)',
')',
'or',
'(:P104_NEW_CREATE = 1 and :P104_EDIT_THEMEN = 1)',
')',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1048565211893979286)
,p_name=>'P104_THEMENIDS'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(2707171913025953509)
,p_prompt=>'Themen'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUMMER || '' - '' || BEZEICHNUNG as d,',
'       THEMAID as r',
'  from V_THEMA_BAUM vtb ',
' where gueltig =1',
' and THEMAID not in ( select themaid from t_thema_ref_et_b_ak where et_b_akid = 1036 ) -- diese nicht in shuttle verwalten, sondern als querschnittsthemen',
' order by vtb.thema_sortorder;'))
,p_cHeight=>9
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P104_THEMAID is null and (:P104_NEW_CREATE is null or :P104_NEW_CREATE= 0)',
')',
'or',
'(:P104_NEW_CREATE = 1 and :P104_EDIT_THEMEN = 1)'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_read_only_when=>'P104_THEMA_READ_ONLY'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1048564817087979285)
,p_name=>'P104_TEXTFIELD'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(2707171913025953509)
,p_prompt=>'&nbsp;'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1048564430571979285)
,p_name=>'P104_OLD_THEMENIDS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(2707171913025953509)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1048564026020979285)
,p_name=>'P104_NEW_CREATE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(2707171913025953509)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1048563566054979285)
,p_name=>'P104_THEMA_READ_ONLY'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(2707171913025953509)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1048563229286979285)
,p_name=>'P104_EDIT_THEMEN'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(2707171913025953509)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1048562785004979285)
,p_name=>'P104_OPEN_TO_DELETE'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(2707171913025953509)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1048562384009979284)
,p_name=>'P104_THEMEN_CHILDREN_TO_ADD'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(2707171913025953509)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(894383907948630067)
,p_name=>'P104_AK_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2707171913025953509)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(894383522934630063)
,p_name=>'P104_QUERSCHNITTSTHEMEN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2707171913025953509)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(894382949195630058)
,p_name=>'P104_QUERSCHNITT_THEMEN_CB'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(2707171913025953509)
,p_prompt=>'<b>Querschnittsthemengebiete</b>'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ',
'        ( v.bezeichnung || case when nvl(v.gueltig, 0) =0 then '' (in GETEX inaktiv)''  ',
'                                                          else '' '' end ',
'        )',
'        ELSE ( v.name_eng || case when nvl(v.gueltig, 0) =0 then '' (in GETEX inactive)''  ',
'                                                          else '' '' end ',
'        )',
'    END as  d,',
' tra.Themaid r ',
'  from T_thema_ref_et_b_AK tra ',
'  join V_THEMA_BAUM v on (v.themaid = tra.themaid)   ',
' where tra.et_b_AKid = 1036 -- querschnitt Themen',
' order by v.thema_sortorder'))
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '5')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1048560015501979273)
,p_validation_name=>'THEMA_VALIDATION'
,p_validation_sequence=>20
,p_validation=>'P104_THEMENIDS'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Bitte w\00E4hlen Sie ein Thema aus')
,p_validation_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P104_THEMAID is null and (:P104_NEW_CREATE is null or :P104_NEW_CREATE= 0)',
')',
'or',
'(:P104_NEW_CREATE = 1 and :P104_EDIT_THEMEN = 1)'))
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(1048561725121979281)
,p_associated_item=>wwv_flow_imp.id(1048565211893979286)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1048559198998979273)
,p_validation_name=>'Validation_thema_einzeln'
,p_validation_sequence=>40
,p_validation=>'P104_THEMAID'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Bitte w\00E4hlen Sie ein Thema aus.')
,p_validation_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P104_NEW_CREATE = 1 and :P104_EDIT_THEMEN is null ) -- and :P104_THEMA_READ_ONLY = 0)',
'or',
' (:P104_THEMAID is not null',
'  and (:P104_NEW_CREATE is null or :P104_NEW_CREATE= 0)',
'    )'))
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(1048561725121979281)
,p_associated_item=>wwv_flow_imp.id(1048568368601979288)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1048553969242979262)
,p_name=>'Cancel'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1048561271826979279)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1048553458969979262)
,p_event_id=>wwv_flow_imp.id(1048553969242979262)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1048554913053979266)
,p_name=>unistr('change L\00E4ndergruppe')
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P104_LAENDER_GRUPPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1048554421611979263)
,p_event_id=>wwv_flow_imp.id(1048554913053979266)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1048551690582979261)
,p_name=>'enter im suchfeld'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P104_PRE_THEMENIDS'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1048551193894979261)
,p_event_id=>wwv_flow_imp.id(1048551690582979261)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'loadThemenShuttle();',
'return false;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1048553127445979262)
,p_name=>'add childThemen'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P104_THEMENIDS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1048552049722979261)
,p_event_id=>wwv_flow_imp.id(1048553127445979262)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lThemenliste apex_t_number := apex_string.split_numbers(:P104_THEMENIDS,'':'');',
'     l_lst_allQSThemen varchar2(2000);',
'    l_inQuerschnittsthemen apex_t_number ;',
'    begin    ',
'',
'    apex_json.initialize_clob_output;',
'    apex_json.open_array;    ',
'',
'    select listagg(themaid, '':'') into l_lst_allQSThemen from t_thema_ref_et_b_ak where et_b_akid = 1036;',
'    l_inQuerschnittsthemen  := apex_string.split_numbers(l_lst_allQSThemen,'':'');',
unistr('   -- Jedes bereits ausgew\00E4hlte Thema durchgehen und dessen Kinder selektieren'),
'    for i in 1 .. lThemenliste.count loop',
'        for childthemen in (',
'            select themaid, nummer || '' - '' || bezeichnung as d',
'            from t_thema',
'            where gueltig =1',
'            connect by parentid = prior themaid',
'            start with parentid = lThemenliste(i)',
'        ) loop',
'            -- Wenn das entsprechende Kind noch nicht im Shuttle ist, dann ',
unistr('            -- zu einer Hinzuf\00FCgungs-Liste addieren'),
'            if (childthemen.themaid not member of lThemenliste ',
'             and  childthemen.themaid  not member of l_inQuerschnittsthemen) then',
'                apex_json.open_object;',
'                apex_json.write(''id'',childthemen.themaid);',
'                apex_json.write(''display'',childthemen.d);',
'                apex_json.close_object;',
'            end if;',
'        end loop;',
'    ',
'    end loop;',
unistr('    -- Hinzuf\00FCgungs-Liste ist hidden item'),
unistr('    -- Direktes Hinzuf\00FCgen w\00FCrde zu einem Refresh der Scrollbalken des Items f\00FChren'),
'    apex_json.close_array;',
'    :P104_THEMEN_CHILDREN_TO_ADD := apex_json.get_clob_output;',
'    apex_json.free_output;',
'end;    '))
,p_attribute_02=>'P104_THEMENIDS'
,p_attribute_03=>'P104_THEMEN_CHILDREN_TO_ADD'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1048552574623979262)
,p_event_id=>wwv_flow_imp.id(1048553127445979262)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var items = JSON.parse($v(''P104_THEMEN_CHILDREN_TO_ADD''));',
'',
unistr('// alle Items im Shuttle hinzuf\00FCgen'),
'for (item of items) {',
'    if (item) addItemToShuttle(''P104_THEMENIDS'',item.id,item.display);',
'} ',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(894383380598630062)
,p_name=>'on Change'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P104_AK_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(894383225047630060)
,p_event_id=>wwv_flow_imp.id(894383380598630062)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P104_THEMENIDS'
,p_attribute_01=>'loadThemenShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(894382856988630057)
,p_name=>'set Visibility of Querschnitts Themen'
,p_event_sequence=>60
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>'(:P104_THEMAID is not null)'
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(894382772668630056)
,p_event_id=>wwv_flow_imp.id(894382856988630057)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P104_QUERSCHNITT_THEMEN_CB'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1048557331889979270)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*debug(''Seite 104'',''Aufruf Save'');',
'*/',
'-- Afruf mit allem Bearbeiten',
'declare ',
'   l_num_updated number :=0;',
'   l_chng number :=0;',
'begin',
'',
'    if ( :P104_EDIT_THEMEN = 1 )  then',
'       l_chng := PCK_RI_GETEX_COMPARE.fIsThemaListChanged(:P104_VORSCHRIFTID, :P104_THEMENIDS || '':''||: P104_QUERSCHNITT_THEMEN_CB);',
'    --debug('':P104_QUERSCHNITT_THEMEN_CB =''|| :P104_QUERSCHNITT_THEMEN_CB,''Aufruf Massenbearbeitung'');',
'',
'',
'',
unistr('        -- wenn es Gleichwertig-Verkn\00FCpfungen gibt, dann m\00FCssen neu hinzugef\00FCgte Themen mit dem Status Pr\00FCfung = 0 dort ebenfalls hinzugef\00FCgt werden'),
'        for x in (',
'            select vorschrift_ref_vorschriftid',
'            from t_vorschrift_ref_vorschrift vrv',
'            where vrv.beziehung_art = 102',
'            and vrv.vorgaenger_vorschriftid = :P104_VORSCHRIFTID',
'        ) loop',
'',
'            merge into t_vorschrift_ref_vorschrift_ref_thema t',
'            using (',
'                -- Nur die Themen, die neu hinzukommen',
'                select column_value as themaid',
'                from apex_string.split_numbers(:P104_THEMENIDS,'':'')',
'                where column_value not in (',
'                    select distinct themaid',
'                    from t_vorschrift_ref_thema vrt',
'                    where vorschriftid = :P104_VORSCHRIFTID',
'                    --and themaid IN (SELECT DISTINCT PARENTID FROM T_THEMA WHERE PARENTID IS NOT NULL and parentid in (select column_value from table(apex_string.split_numbers(:P104_THEMENIDS, '':'')))  )',
'                    and geloescht = 0 and themaid is not null)',
'                    and column_value not IN (SELECT DISTINCT PARENTID FROM T_THEMA WHERE PARENTID IS NOT NULL /*and column_value NOT IN (SELECT DISTINCT PARENTID FROM T_THEMA WHERE PARENTID IS NOT NULL)*/',
'                )  ',
'                 --and -- themaid   is not in select parentid from T_thema',
'            ) u',
'            on (t.vorschrift_ref_vorschriftid = x.vorschrift_ref_vorschriftid and t.themaid = u.themaid)',
unistr('            -- Status Pr\00FCfung = 0 und Status Verkn\00FCpfung = 0 sorgt daf\00FCr, dass die Themen auf der linken Seite auftauchen und rot sind'),
'            when matched then update set t.status_pruefung = 0',
'            when not matched then insert (',
'                vorschrift_ref_vorschriftid, themaid, status_verknuepfung,',
'                status_pruefung',
'            ) values (',
'                x.vorschrift_ref_vorschriftid, u.themaid, 0,',
'                0',
'            );',
'',
'',
'        end loop;',
'',
'        UPDATE  t_vorschrift_ref_THEMA set geloescht=0 --, bemerkung= :P104_BEMERKUNG',
'         where vorschriftID = :P104_VORSCHRIFTID ',
'           and geloescht =1',
'           and ( themaid  in (select column_value from table(apex_string.split_numbers(:P104_THEMENIDS, '':'')))',
'                 or Themaid in ( select column_value from table(apex_string.split_numbers(:P104_QUERSCHNITT_THEMEN_CB, '':'')))',
'                 and themaid  NOT IN (SELECT DISTINCT PARENTID FROM T_THEMA WHERE PARENTID IS NOT NULL)',
'           );        ',
'',
'        ',
'        MERGE into t_vorschrift_ref_THEMA dest',
'           USING ( select :P104_VORSCHRIFTID as vorschriftID, column_value as themaid from table (apex_string.split_numbers(:P104_THEMENIDS, '':''))',
'           where column_value  NOT IN (SELECT DISTINCT PARENTID FROM T_THEMA WHERE PARENTID IS NOT NULL)',
'           ) src',
'           on (src.vorschriftID = dest.vorschriftID ',
'               and src.themaid = dest.themaid)',
'          WHEN NOT MATCHED THEN',
'           insert (vorschriftID, themaid, geloescht) --, bemerkung)',
'           values (src.vorschriftID, src.themaid, 0); --, :P104_BEMERKUNG);',
'',
'        -- merge Querschnitts Themen',
'        if (:P104_QUERSCHNITT_THEMEN_CB is not null) then',
'          MERGE into t_vorschrift_ref_THEMA dest',
'           USING ( select :P104_VORSCHRIFTID as vorschriftID, column_value as themaid from table(apex_string.split_numbers(:P104_QUERSCHNITT_THEMEN_CB, '':''))) src',
'           on (src.vorschriftID = dest.vorschriftID ',
'               and src.themaid = dest.themaid)',
'          WHEN NOT MATCHED THEN',
'           insert (vorschriftID, themaid, geloescht) --, bemerkung)',
'           values (src.vorschriftID, src.themaid, 0); ',
'        end if;',
unistr('         -- nicht l\00F6schen  nur flag setzen'),
'          --debug (''P104_THEMENIDS= ''|| :P104_THEMENIDS);',
'         UPDATE  t_vorschrift_ref_THEMA set geloescht=1',
'          where vorschriftID = :P104_VORSCHRIFTID',
'            and ( themaid not in (select column_value from table(apex_string.split_numbers(:P104_THEMENIDS, '':'')))',
'                  and Themaid not in ( select column_value from table(apex_string.split_numbers(:P104_QUERSCHNITT_THEMEN_CB, '':'')))',
'                  --tharun',
'                --   or  apex_string.split_numbers(:P104_THEMENIDS, '':'') IN (SELECT DISTINCT PARENTID FROM v_thema_baum WHERE PARENTID IS NOT NULL)',
'                  or themaid IN (SELECT DISTINCT PARENTID FROM T_THEMA WHERE PARENTID IS NOT NULL ',
'                                 and parentid in (select column_value from table(apex_string.split_numbers(:P104_THEMENIDS, '':''))) )',
'                 ',
'                ) ',
'',
'            and geloescht=0 returning count(vorschrift_ref_themaid) into l_num_updated; ',
'          --debug (''l_num_updated: '' || l_num_updated);',
'      ',
'        PCK_RI_BENACHRICHTIGUNG.pBenachricht_Mfv_Arbeitskreise( :P104_VORSCHRIFTID, ''Themen'', :G_BENUTZERID );',
'  ',
'        if  (l_chng >0) then   ',
'            update T_VORSCHRIFT set letzte_aenderung_getex_attr = sysdate  where VORSCHRIFTID = :P104_VORSCHRIFTID;',
'        end if;',
'    elsif ((:P104_THEMA_READ_ONLY = 0) and :P104_THEMAID is not null --and :P104_NEW_CREATE = 1',
'       and :P104_EDIT_THEMEN is null)',
'    then',
unistr('   -- ein Thema hinzuf\00FCgen'),
'     UPDATE t_vorschrift_ref_THEMA set bemerkung = :P104_BEMERKUNG',
'      where vorschriftID = :P104_VORSCHRIFTID',
'        and themaid = :P104_THEMAID;',
'      --pck_ri_history.pInsertVorschriftThemaRelationkeinLand(:P104_VORSCHRIFTID,:P104_THEMAID,:P104_BEMERKUNG); ',
'      PCK_RI_BENACHRICHTIGUNG.pBenachricht_Mfv_Arbeitskreise( :P104_VORSCHRIFTID, ''Themen'', :G_BENUTZERID );',
'',
'    /*elsif (:P104_THEMAID is null and (:P104_NEW_CREATE is null or :P104_NEW_CREATE= 0) )',
'       then',
'      -- Mehrere Themen Speichern',
'        ',
'      -- debug(''Seite 100'',''Aufruf Themen++ bearbeiten'');',
'      --PCK_RI_BENACHRICHTIGUNG.pBenachricht_Mfv_Arbeitskreise( :P104_VORSCHRIFTID, ''Themen'', :G_BENUTZERID );',
'      null;',
'    */',
'    end if;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1048561725121979281)
,p_internal_uid=>2623654984009408965
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1048558132650979270)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Benachricht_Fremdzuweis_Thema'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  lThemenIdliste apex_t_number; -- := apex_string.split_numbers(:P104_THEMENIDS,'':'');',
'   sDiffListe varchar2(800);',
'begin',
'',
'  if (  ( (:P104_EDIT_THEMEN = 1 OR :P104_THEMA_READ_ONLY = 0)  ',
'          or :P104_THEMAID is null and (:P104_NEW_CREATE is null or :P104_NEW_CREATE= 0)',
'        )',
'     ) then',
'      select listagg(themaid,'':'') within group (order by themaid)  into sDiffListe from',
'        (select column_value as themaid from table( APEX_STRING.split_numbers(:P104_THEMENIDS, '':''))',
'          MINUS                                                     -- :P104_OLD_THEMENIDS',
'          select column_value as themaid from table( APEX_STRING.split_numbers(:P104_OLD_THEMENIDS, '':''))',
'         )',
'      where themaid is not null;',
'      if length(sDiffListe) >1 then',
'         --debug(''sDiffListe= '', sDiffListe);',
'',
'          lThemenIdliste := apex_string.split_numbers(sDiffListe,'':'');',
'          PCK_RI_BENACHRICHTIGUNG.pBenachrichtigung_fremdzuweisung(:P104_VORSCHRIFTID, lThemenIdliste, :G_BENUTZERID);',
'      end if;',
'  end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1048561725121979281)
,p_internal_uid=>2623654183248408965
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1048556066855979267)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DELETE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*debug(''Seite 104'',''Aufruf DELETE'');',
'*/',
'--debug(''Seite 104 :P104_THEMAID '',:P104_THEMAID );',
'--debug(''Seite 104 :P104_THEMA_READ_ONLY '',:P104_THEMA_READ_ONLY );',
'',
'     ',
'',
'     Update t_vorschrift_ref_thema set geloescht =1 where  vorschriftid = :P104_VORSCHRIFTID AND themaid = :P104_THEMAID; ',
'     --  ',
'     update T_VORSCHRIFT set letzte_aenderung_getex_attr = sysdate  where VORSCHRIFTID = :P104_VORSCHRIFTID;  ',
'      -- pck_ri_history.pInsertVorschriftThemaRelationkeinLand(:P104_VORSCHRIFTID,:P104_THEMAID,:P104_BEMERKUNG,1);',
'',
'',
unistr('      -- Bei Gleichwertig-Verkn\00FCpfungen entfernen, wenn vorhanden'),
'      update t_vorschrift_ref_vorschrift_ref_thema',
'      set status_verknuepfung = 0',
'      where themaid = :P104_THEMAID',
'      and vorschrift_ref_vorschriftid in (',
'          select vorschrift_ref_vorschriftid',
'          from t_vorschrift_ref_vorschrift vrv',
'          where vrv.beziehung_art = 102',
'          and vrv.vorgaenger_vorschriftid = :P104_VORSCHRIFTID',
'      );',
'     '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1048560857264979279)
,p_internal_uid=>2623656249043408968
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1048558863458979273)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Letzte Aenderung Datum setzen, Reset VI'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_vorschrift',
'set letzte_aenderung_datum = sysdate',
'where vorschriftid = :P104_VORSCHRIFTID;',
'-- UserID wird durch Trigger automatisch gesetzt',
'',
'pck_ri.pResetVI(:P104_VORSCHRIFTID);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DELETE, SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2623653452440408962
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1016890341018243331)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Recalculate Cockpit and GETEX Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P104_VORSCHRIFTID IS NOT NULL THEN',
'        PCK_RI_GETEX_CTRL.pRecalculateGetexAndCockpitData(:P104_VORSCHRIFTID);',
'    END IF;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_debug.error(''Recalculation error: '' || SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE, DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2655321974881144904
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1048556867144979269)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1048561725121979281)
,p_internal_uid=>2623655448754408966
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1048556444648979269)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load_Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  LcountThemen number;',
'begin',
'     --debug('' load_Data :P104_EDIT_THEMEN:'', :P104_EDIT_THEMEN);',
'    -- debug('':P104_NEW_CREATE:'', :P104_NEW_CREATE);',
'',
'if (:P104_THEMAID is not null)',
'    then ',
'',
'           with cte1 as(Select distinct bemerkung',
'                             from t_vorschrift_ref_thema',
'                             where vorschriftid = :P104_VORSCHRIFTID and nvl(themaid,-1) = nvl(:P104_THEMAID,-1) and geloescht = 0',
'                             )',
'                select listagg(bemerkung, '', '' on overflow truncate) into :P104_BEMERKUNG',
'                from cte1;',
'                ',
'',
'elsif (:P104_EDIT_THEMEN = 1 and :P104_NEW_CREATE = 1)',
'    then',
'        Select count( distinct Themaid) into LcountThemen',
'          from t_vorschrift_ref_thema',
'         where vorschriftid = :P104_VORSCHRIFTID and geloescht = 0',
'           and Themaid not in (select distinct themaid from t_thema_ref_et_b_ak where et_b_akid =1036);',
'            ',
'            :P104_OLD_THEMENIDS :='''';',
'        if (lcountThemen> 0)',
'        then ',
'            select listagg(Themaid, '':'') into :P104_THEMENIDS',
'              from (Select distinct themaid ',
'                      from t_vorschrift_ref_thema',
'                     where vorschriftid = :P104_VORSCHRIFTID  and geloescht = 0',
'                       and Themaid not in (select distinct themaid from t_thema_ref_et_b_ak where et_b_akid =1036)',
'                 );',
'            ',
'        end if;',
'             ',
'        select :P104_THEMENIDS into :P104_OLD_THEMENIDS from dual;',
'            --debug('':P104_OLD_THEMENIDS:'', :P104_OLD_THEMENIDS);',
'',
'        select  listagg(tra.Themaid, '':'') into :P104_QUERSCHNITT_THEMEN_CB ',
'          from T_thema_ref_et_b_AK tra ',
'          join T_THEMA t on (t.themaid = tra.themaid)',
'          join t_vorschrift_ref_thema vrt on (vrt.themaid = tra.themaid )',
'         where tra.et_b_AKid =1036 and vrt.vorschriftid =:P104_VORSCHRIFTID and vrt.geloescht=0;',
'',
'end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2623655871250408966
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1048555710306979267)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLaenderShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lLaendergruppe number := apex_application.g_x02;',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    for l in (',
'        select b_nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'        ELSE land_eng',
'    END as d, landid',
'        from t_land',
'        where landid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))        ',
'        and (',
'            lLaendergruppe is null',
'            or landid in (select landid from t_land_ref_laendergruppe where laendergruppeid = lLaendergruppe)',
'        )',
'        order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'')        ',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.landid);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'    ',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2623656605592408968
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1048555262534979267)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadThemenShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lText varchar2(2000) := apex_application.g_x02;',
'    --lQuerschnitt_Themen varchar2(2000) := apex_application.g_x03;',
'BEGIN',
'    ',
'    ',
'    apex_json.open_array;',
'    for l in (',
'        select nummer || '' - '' || bezeichnung as d, themaid as r',
'        from v_thema_baum',
'        where upper(nummer || '' - '' || bezeichnung) like ''%'' || upper(lText) || ''%''',
'        and themaid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))',
'        and themaid not in (select themaid from t_vorschrift_ref_thema where vorschriftid = :P104_VORSCHRIFTID and geloescht !=1 ) ',
'        and  THEMAID not in ( select themaid from t_thema_ref_et_b_ak where et_b_akid = 1036 )  ',
'        and nvl(gueltig, 0)=1      ',
'        order by thema_sortorder',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.r);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'    ',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2623657053364408968
);
wwv_flow_imp.component_end;
end;
/
