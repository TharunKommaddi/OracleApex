prompt --application/pages/page_02010
begin
--   Manifest
--     PAGE: 02010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>2010
,p_name=>'ImagePopUp'
,p_alias=>'IMAGEPOPUP'
,p_page_mode=>'MODAL'
,p_step_title=>'ImagePopUp'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_dialog_width=>'1200'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(748440357814058143)
,p_plug_name=>'Image PopUp'
,p_region_name=>'IMGP'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(929166483821610319)
,p_name=>'P2010_BILD_NUMMER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(748440357814058143)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(929165677230610310)
,p_name=>'P2010_IMAGE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(748440357814058143)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_grid_column=>2
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'SQL',
  'sql_statement', 'select BILD_1 from t_MS_bild where BILD_NUMMER=:P2010_BILD_NUMMER')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(928840321901396993)
,p_name=>'P2010_BILD_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(748440357814058143)
,p_prompt=>'Bild Name'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(931964440467582159)
,p_name=>'setimage'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2010_BILD_NUMMER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(931964413616582158)
,p_event_id=>wwv_flow_imp.id(931964440467582159)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2010_IMAGE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select dbms_lob.getLength(BILD_1) from t_MS_bild where BILD_NUMMER=:P2010_BILD_NUMMER'
,p_attribute_07=>'P2010_BILD_NUMMER'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(928839996999396990)
,p_event_id=>wwv_flow_imp.id(931964440467582159)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2010_BILD_NAME'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when :FSP_LANGUAGE_PREFERENCE = ''de'' and bezeichnung is not null then bezeichnung',
'when :FSP_LANGUAGE_PREFERENCE = ''en'' and name_eng is not null then name_eng',
'else to_char(BILD_NUMMER) end bild_name ',
'from t_MS_bild where bild_nummer=:P2010_BILD_NUMMER;',
''))
,p_attribute_07=>'P2010_BILD_NUMMER'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
