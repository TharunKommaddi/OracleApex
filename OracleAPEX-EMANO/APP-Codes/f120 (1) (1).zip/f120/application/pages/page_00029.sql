prompt --application/pages/page_00029
begin
--   Manifest
--     PAGE: 00029
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>29
,p_name=>'Getex'
,p_alias=>'GETEX'
,p_page_mode=>'MODAL'
,p_step_title=>'Getex'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function checkAusserKraftConditions() {',
'//   console.log("Starting checkAusserKraftConditions");',
' ',
'  return new Promise(function(resolve, reject) {',
'    // console.log("Inside Promise - making server call to CHECK_CONDITIONS");',
'    apex.server.process(',
'      "CHECK_CONDITIONS",',
'      {',
'        pageItems: "#P29_VORSCHRIFTID" ',
'      },',
'      {',
'        dataType: "json",',
'        success: function(data) {',
'        //   console.log("CHECK_CONDITIONS response:", data);',
'          if (data.showPopup) {',
'            // console.log("Dialog needs to be shown");',
'           ',
'            if ($("#kraft-confirm-dialog").length > 0) {',
'            //   console.log("Removing existing dialog");',
'              $("#kraft-confirm-dialog").dialog("destroy").remove();',
'            }',
'            ',
'            // Custom dialog with checkbox',
'            var html = ''<div id="kraft-confirm-dialog" style="background-color: #FFFFFF; color: #404040; padding: 20px 20px 10px 20px; font-family: \''Audi Type\'', \''Helvetica Neue\'', Helvetica, Arial, sans-serif;">'' +',
'                       ''<p style="font-size: 14px; line-height: 1.5; margin-bottom: 0; text-align: justify;">'' + ',
unistr('                       ''Da ein Einsatztermin f\00FCr Alle Fahrzeuge Datum <strong>'' + data.deploymentDate + ''</strong> in der aktuellen '' +'),
unistr('                       ''Vorschrift \00FCbernommen wurde, w\00FCrde nun RegIndex die Vorg\00E4nger Vorschrift '' +'),
'                       ''<strong>'' + data.predecessorName + ''</strong> '' +',
unistr('                       ''mit dem Datum <strong>'' + data.deploymentDate + ''</strong> Au\00DFer Kraft setzen.'' +'),
'                       ''</p>'' +',
'                       ''<div style="margin: 15px 0;">'' +',
'                       ''<label style="display: flex; align-items: center;">'' +',
'                       ''<input type="checkbox" id="chk_confirm_kraft" style="margin-right: 10px;"> '' +',
unistr('                       ''<span style="font-size: 14px;">Ich best\00E4tige, dass ich die Mitteilung verstanden habe</span>'' +'),
'                       ''</label>'' +',
'                       ''</div>'' +',
'                       ''<div style="display: flex; justify-content: space-between; margin-top: 10px; margin-bottom: 0;">'' +',
'                       ''<button id="btn_nicht_kraft" class="t-Button t-Button--hot" '' +',
unistr('                       ''style="background-color: #2b2f33; color: #FFFFFF; border: 2px solid white; font-size: 1.2rem; padding: 8px 16px; font-weight: normal;">NICHT Au\00DFer Kraft setzen</button>'' +'),
'                       ''<button id="btn_kraft" class="t-Button t-Button--hot" disabled '' +',
unistr('                       ''style="background-color: #bb0a31; color: #FFFFFF; border: 2px solid white; font-size: 1.2rem; padding: 8px 16px; font-weight: normal;">Au\00DFer Kraft setzen</button>'' +'),
'                       ''</div></div>'';',
'            ',
'         ',
'            // console.log("Adding dialog to the body");',
'            $("body").append(html);',
'            ',
'          ',
'            // console.log("Initializing dialog");',
'            $("#kraft-confirm-dialog").dialog({',
unistr('              title: "Au\00DFer Kraft setzen best\00E4tigen",'),
'              modal: true,',
'              resizable: false,',
'              width: 525,',
'              height: 280,',
'              autoOpen: true,',
'              closeOnEscape: false,',
'              dialogClass: "no-close",',
'              close: function() {',
'                // console.log("Dialog close event triggered");',
'               ',
'                $(this).dialog("destroy");',
'                $(this).remove();',
'              }',
'            });',
'            ',
unistr('            // Enable/disable the "Au\00DFer Kraft setzen" button based on checkbox'),
'            $("#chk_confirm_kraft").on("change", function() {',
'            //   console.log("Checkbox changed:", this.checked);',
'              $("#btn_kraft").prop("disabled", !this.checked);',
'            });',
'            ',
'          ',
'            $("#btn_nicht_kraft").on("click", function() {',
unistr('            //   console.log("NICHT Au\00DFer Kraft setzen clicked");'),
'              ',
'              $("#kraft-confirm-dialog").dialog("close");',
'             ',
'            //   console.log("Resolving Promise with false");',
'              resolve(false);',
'            });',
'            ',
'            $("#btn_kraft").on("click", function() {',
unistr('            //   console.log("Au\00DFer Kraft setzen clicked");'),
'             ',
'              if ($("#chk_confirm_kraft").prop("checked")) {',
'                // console.log("Checkbox is checked, proceeding with UPDATE_PREDECESSOR");',
'                apex.server.process(',
'                  "UPDATE_PREDECESSOR",',
'                  {',
'                    x01: data.predecessorId,',
'                    x02: data.deploymentDate,',
'                    x03: data.modelId,',
'                    x04: data.ausserkraftTypId',
'                  },',
'                  {',
'                    dataType: "json",',
'                    success: function(result) {',
'                    //   console.log("UPDATE_PREDECESSOR success:", result);',
'                   ',
unistr('                      apex.message.showPageSuccess("Vorg\00E4nger wurde erfolgreich aktualisiert.");'),
'                      $("#kraft-confirm-dialog").dialog("close");',
'                      ',
'                    ',
'                    //   console.log("Resolving Promise with true");',
'                      resolve(true);',
'                    },',
'                    error: function(xhr, status, error) {',
'                      console.error("UPDATE_PREDECESSOR error:", error);',
'                      apex.message.alert("Fehler beim Aktualisieren: " + error);',
'                      $("#kraft-confirm-dialog").dialog("close");',
'                      reject(error);',
'                    }',
'                  }',
'                );',
'              }',
'            });',
'            ',
'        ',
'          } else {',
'            // console.log("No dialog needed, resolving with true");',
'          ',
'            resolve(true);',
'          }',
'        },',
'        error: function(xhr, status, error) {',
'          console.error("CHECK_CONDITIONS error:", error);',
unistr('          apex.message.alert("Fehler bei der \00DCberpr\00FCfung: " + error);'),
'          reject(error);',
'        }',
'      }',
'    );',
'  });',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'// Common function used by all reports to toggle switch states',
'function setRadioValue(baseId, value) {',
'    if (value === ''Y'') {',
'        apex.jQuery(`#${baseId}_Y`).prop(''checked'', true);',
'        apex.jQuery(`#${baseId}_N`).prop(''checked'', false);',
'    } else {',
'        apex.jQuery(`#${baseId}_Y`).prop(''checked'', false);',
'        apex.jQuery(`#${baseId}_N`).prop(''checked'', true);',
'    }',
'}',
'',
'// Function to handle switch changes',
'function handleSwitchChange(section, start, end, isYes) {',
'    // Update header buttons',
'    apex.jQuery(`#${section}-${isYes ? ''ja'' : ''nein''}`).addClass(''active'');',
'    apex.jQuery(`#${section}-${isYes ? ''nein'' : ''ja''}`).removeClass(''active'');',
'    ',
'    // Update all switches',
'    for(let i = start; i <= end; i++) {',
'        setRadioValue(`SWITCH_${section.toUpperCase()}_${i}`, isYes ? ''Y'' : ''N'');',
'    }',
'    setRadioValue(`SWITCH_ALL_${section.toUpperCase()}`, isYes ? ''Y'' : ''N'');',
'}',
'',
'// Function to check child switches and update header',
'function checkChildSwitches(section, start, end) {',
'    let allYes = true;',
'    for(let i = start; i <= end; i++) {',
'        if (!apex.jQuery(`#SWITCH_${section.toUpperCase()}_${i}_Y`).prop(''checked'')) {',
'            allYes = false;',
'            break;',
'        }',
'    }',
'    // Update header based on child states',
'    apex.jQuery(`#${section}-ja`).toggleClass(''active'', allYes);',
'    apex.jQuery(`#${section}-nein`).toggleClass(''active'', !allYes);',
'    setRadioValue(`SWITCH_ALL_${section.toUpperCase()}`, allYes ? ''Y'' : ''N'');',
'}',
'',
'// Initialize switches when page loads',
'apex.jQuery(function($){',
'    // Configuration object for each section',
'    const sections = {',
'        kerndaten: { start: 1, end: 8 },',
'        einsatzdaten: { start: 9, end: 10 },',
'        listen: { start: 17, end: 19 },',
'        relations: { start: 12, end: 16 }',
'    };',
'',
'    // Set up handlers for each section',
'    Object.entries(sections).forEach(([section, range]) => {',
'        // Header switch handlers',
'        $(`#${section}-ja`).on(''click'', function(e) {',
'            e.preventDefault();',
'            handleSwitchChange(section, range.start, range.end, true);',
'        });',
'',
'        $(`#${section}-nein`).on(''click'', function(e) {',
'            e.preventDefault();',
'            handleSwitchChange(section, range.start, range.end, false);',
'        });',
'',
'        // Individual switch handlers',
'        for(let i = range.start; i <= range.end; i++) {',
'            $(`#SWITCH_${section.toUpperCase()}_${i}_Y, #SWITCH_${section.toUpperCase()}_${i}_N`).on(''change'', function() {',
'                checkChildSwitches(section, range.start, range.end);',
'            });',
'        }',
'    });',
'});',
'',
'',
'',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.hl {',
'  background-color: yellow;',
'  color: black;',
'}',
'',
'',
'',
'',
'.switch-buttons {',
'    display: inline-flex;',
'    border-radius: 50px;',
'    overflow: hidden;',
'    border: 1px solid #e0e0e0;',
'    font-family: "Audi Type", "Helvetica Neue", Helvetica, Arial, sans-serif;',
'}',
'',
'.ja-button, .nein-button {',
'    padding: 4px 12px;',
'    border: none;',
'    font-size: 12px;',
'    font-weight: normal;',
'    cursor: pointer;',
'    background-color: #D3D3D3;',
'    color: #A9A9A9;',
'    font-family: "Audi Type", "Helvetica Neue", Helvetica, Arial, sans-serif;',
'}',
'',
'.ja-button.active, .nein-button.active {',
'    background-color: #bb0a31;',
'    color: #F9F9F9;',
'    font-weight: normal;',
'    font-family: "Audi Type", "Helvetica Neue", Helvetica, Arial, sans-serif;',
'}',
'',
'',
'',
'/***********************',
' * Alert Confirmation Styles',
' ***********************/',
'/* .a-AlertMessage {',
'    padding-left: 20px;',
'    padding-right: 20px;',
'    padding-bottom: 20px;',
'    padding-top: 20px;',
'}',
'',
'/* .delete_confirm {',
'    cursor: pointer;',
'}',
' */',
'',
'',
'',
'.a-AlertMessage {',
'    display: flex;',
'    padding-left: 20px!important;',
'    padding-right: 20px!important;',
'    padding-bottom: 20px!important;',
'    padding-top: 20px!important;',
'',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1300'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'l.switch-buttons {',
'    display: inline-flex;',
'    border-radius: 2px;',
'    overflow: hidden;',
'}',
'',
'.ja-button, .nein-button {',
'    padding: 4px 12px;',
'    border: none;',
'    font-size: 14px;',
'    cursor: pointer;',
'}',
'',
'/* Normal state - grey background */',
'.ja-button, .nein-button {',
'    background-color: #f0f0f0;  /* Light grey background */',
'    color: #666;               /* Grey text */',
'}',
'',
'/* Active state for Ja */',
'.ja-button.active {',
'    background-color: #bb0a31;  /* Red background */',
'    color: white;              /* White text */',
'}',
'',
'/* Active state for Nein */',
'.nein-button.active {',
'    background-color: #bb0a31;  /* Red background */',
'    color: white;              /* White text */',
'}',
'',
'/* Button border */',
'.switch-buttons {',
'    border: 1px solid #e0e0e0;  /* Light grey border */',
'}',
'',
'',
'',
'// Common function used by all reports to toggle switch states',
'function setRadioValue(baseId, value) {',
'    if (value === ''Y'') {',
'        apex.jQuery(`#${baseId}_Y`).prop(''checked'', true);',
'        apex.jQuery(`#${baseId}_N`).prop(''checked'', false);',
'    } else {',
'        apex.jQuery(`#${baseId}_Y`).prop(''checked'', false);',
'        apex.jQuery(`#${baseId}_N`).prop(''checked'', true);',
'    }',
'}',
'',
'// Function to handle switch changes',
'function handleSwitchChange(section, start, end, isYes) {',
'    // Update header buttons',
'    apex.jQuery(`#${section}-${isYes ? ''ja'' : ''nein''}`).addClass(''active'');',
'    apex.jQuery(`#${section}-${isYes ? ''nein'' : ''ja''}`).removeClass(''active'');',
'    ',
'    // Update all switches',
'    for(let i = start; i <= end; i++) {',
'        setRadioValue(`SWITCH_${section.toUpperCase()}_${i}`, isYes ? ''Y'' : ''N'');',
'    }',
'    setRadioValue(`SWITCH_ALL_${section.toUpperCase()}`, isYes ? ''Y'' : ''N'');',
'}',
'',
'// Function to check child switches and update header',
'function checkChildSwitches(section, start, end) {',
'    let allYes = true;',
'    for(let i = start; i <= end; i++) {',
'        if (!apex.jQuery(`#SWITCH_${section.toUpperCase()}_${i}_Y`).prop(''checked'')) {',
'            allYes = false;',
'            break;',
'        }',
'    }',
'    // Update header based on child states',
'    apex.jQuery(`#${section}-ja`).toggleClass(''active'', allYes);',
'    apex.jQuery(`#${section}-nein`).toggleClass(''active'', !allYes);',
'    setRadioValue(`SWITCH_ALL_${section.toUpperCase()}`, allYes ? ''Y'' : ''N'');',
'}',
'',
'// Initialize switches when page loads',
'apex.jQuery(function($){',
'    // Configuration object for each section',
'    const sections = {',
'        kerndaten: { start: 1, end: 8 },',
'        einsatzdaten: { start: 9, end: 10 },',
'        listen: { start: 12, end: 19 }',
'    };',
'',
'    // Set up handlers for each section',
'    Object.entries(sections).forEach(([section, range]) => {',
'        // Header switch handlers',
'        $(`#${section}-ja`).on(''click'', function(e) {',
'            e.preventDefault();',
'            handleSwitchChange(section, range.start, range.end, true);',
'        });',
'',
'        $(`#${section}-nein`).on(''click'', function(e) {',
'            e.preventDefault();',
'            handleSwitchChange(section, range.start, range.end, false);',
'        });',
'',
'        // Individual switch handlers',
'        for(let i = range.start; i <= range.end; i++) {',
'            $(`#SWITCH_${section.toUpperCase()}_${i}_Y, #SWITCH_${section.toUpperCase()}_${i}_N`).on(''change'', function() {',
'                checkChildSwitches(section, range.start, range.end);',
'            });',
'        }',
'    });',
'});'))
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1505791667159169964)
,p_plug_name=>'Attributen Gruppen'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'(pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0)'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>':G_BENUTZERID = 15643'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1505792300213178570)
,p_plug_name=>'Auswahl'
,p_parent_plug_id=>wwv_flow_imp.id(1505791667159169964)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1081793399536635418)
,p_name=>'Einsatzdaten Attribute  - heading'
,p_parent_plug_id=>wwv_flow_imp.id(1505792300213178570)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_grid_column_span=>3
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    edat_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 2,',
'        p_value => CASE ',
'                    WHEN INSTR('':''||:P29_SELECTED_EINSATZDATEN||'':'','':''||edat_id||'':'') > 0 ',
'                    THEN ''Y'' ',
'                    ELSE ''Y''',
'                  END,',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_EINSATZDATEN_''||edat_id,',
'        p_item_label => Einsatzdaten||'': Switch'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    Einsatzdaten',
'from (',
'    select 9 as edat_id, ''Inkraftsetzungsdatum'' as Einsatzdaten from dual',
'    union',
'    select 10 as edat_id, ''Einsatzdatum Daten'' as Einsatzdaten from dual',
'    -- union',
unistr('    -- select 11 as edat_id, ''Au\00DFerkraftsetzungsdatum'' as Einsatzdaten from dual'),
') cte;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    to_number(''999999'') as edat_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 5,',
'        p_value => ''Y'',',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_ALL_EINSATZDATEN'',',
'        p_item_label => ''Einsatzdaten: All'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    ''Einsatzdaten'' as Einsatzdaten',
'from dual',
'',
'union all',
'',
'select ',
'    edat_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 2,',
'        p_value => CASE ',
'                    WHEN INSTR('':''||:P29_SELECTED_EINSATZDATEN||'':'','':''||edat_id||'':'') > 0 ',
'                    THEN ''Y'' ',
'                    ELSE ''Y''',
'                  END,',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_EINSATZDATEN_''||edat_id,',
'        p_item_label => Einsatzdaten||'': Switch'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    Einsatzdaten',
'from (',
'    select 9 as edat_id, ''Inkraftsetzungsdatum'' as Einsatzdaten from dual',
'    union',
'    select 10 as edat_id, ''Einsatzdatum Daten'' as Einsatzdaten from dual',
'    -- union',
unistr('    -- select 11 as edat_id, ''Au\00DFerkraftsetzungsdatum'' as Einsatzdaten from dual'),
') cte;'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1081793232496635417)
,p_query_column_id=>1
,p_column_alias=>'EDAT_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1081793124522635416)
,p_query_column_id=>2
,p_column_alias=>'SWITCH_ITEM'
,p_column_display_sequence=>20
,p_column_heading=>'<div class="switch-buttons">          <button type="button" class="ja-button active" id="einsatzdaten-ja">Ja</button>          <button type="button" class="nein-button" id="einsatzdaten-nein">Nein</button>  </div>'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_column_comment=>'Switch Item'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1081793114124635415)
,p_query_column_id=>3
,p_column_alias=>'EINSATZDATEN'
,p_column_display_sequence=>30
,p_column_heading=>'Einsatzdaten'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1081792935453635414)
,p_name=>'Attribute zur Aktualisierung - heading'
,p_parent_plug_id=>wwv_flow_imp.id(1505792300213178570)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:margin-left-lg'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_grid_column_span=>3
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    attr_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 1,',
'        p_value => CASE ',
'                    WHEN INSTR('':''||:P29_SELECTED_KERNDATEN||'':'','':''||attr_id||'':'') > 0 ',
'                    THEN ''Y'' ',
'                    ELSE ''Y''',
'                  END,',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_KERNDATEN_''||attr_id,',
'        p_item_label => kerndaten||'': Switch'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    kerndaten',
'from (',
'    select 1 as attr_id, ''Vorschriftennummer'' as kerndaten from dual',
'    union',
'    select 2 as attr_id, ''Dokumentendatum'' as kerndaten from dual',
'    union',
'    select 3 as attr_id, ''Dokumententyp'' as kerndaten from dual',
'    union',
'    select 4 as attr_id, ''Titel Kurz'' as kerndaten from dual',
'    union',
'    select 5 as attr_id, ''Titel Lang'' as kerndaten from dual',
'    union',
'    select 6 as attr_id, ''Status der Vorschrift'' as kerndaten from dual',
'    union',
'    select 7 as attr_id, ''Einsatzdatum Modell'' as kerndaten from dual',
'    union',
'    select 8 as attr_id, ''Vorschriftentyp'' as kerndaten from dual',
') cte;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    to_number(''999999'') as attr_id,  -- Using a number for consistent data type',
'    APEX_ITEM.SWITCH(',
'        p_idx => 4,',
'        p_value => ''Y'',',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_ALL_KERNDATEN'',',
'        p_item_label => ''Kerndaten: All'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    ''Kerndaten'' as kerndaten',
'from dual',
'',
'union all',
'',
'select ',
'    attr_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 1,',
'        p_value => CASE ',
'                    WHEN INSTR('':''||:P29_SELECTED_KERNDATEN||'':'','':''||attr_id||'':'') > 0 ',
'                    THEN ''Y'' ',
'                    ELSE ''Y''',
'                  END,',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_KERNDATEN_''||attr_id,',
'        p_item_label => kerndaten||'': Switch'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    kerndaten',
'from (',
'    select 1 as attr_id, ''Vorschriftennummer'' as kerndaten from dual',
'    union',
'    select 2 as attr_id, ''Dokumentendatum'' as kerndaten from dual',
'    union',
'    select 3 as attr_id, ''Dokumententyp'' as kerndaten from dual',
'    union',
'    select 4 as attr_id, ''Titel Kurz'' as kerndaten from dual',
'    union',
'    select 5 as attr_id, ''Titel Lang'' as kerndaten from dual',
'    union',
'    select 6 as attr_id, ''Status der Vorschrift'' as kerndaten from dual',
'    union',
'    select 7 as attr_id, ''Einsatzdatum Modell'' as kerndaten from dual',
'    union',
'    select 8 as attr_id, ''Vorschriftentyp'' as kerndaten from dual',
') cte;'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1081792863380635413)
,p_query_column_id=>1
,p_column_alias=>'ATTR_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1081792757199635412)
,p_query_column_id=>2
,p_column_alias=>'SWITCH_ITEM'
,p_column_display_sequence=>20
,p_column_heading=>'<div class="switch-buttons">          <button type="button" class="ja-button active" id="kerndaten-ja">Ja</button>          <button type="button" class="nein-button" id="kerndaten-nein">Nein</button>  </div>'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1081792635299635411)
,p_query_column_id=>3
,p_column_alias=>'KERNDATEN'
,p_column_display_sequence=>30
,p_column_heading=>'Kerndaten'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1081792596046635410)
,p_name=>'Listen Attribute - heading'
,p_parent_plug_id=>wwv_flow_imp.id(1505792300213178570)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_grid_column_span=>3
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    liAtt_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 3,',
'        p_value => CASE ',
'                    WHEN INSTR('':''||:P29_SELECTED_LISTEN||'':'','':''||liAtt_id||'':'') > 0 ',
'                    THEN ''Y'' ',
'                    ELSE ''Y''',
'                  END,',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_LISTEN_''||liAtt_id,',
'        p_item_label => Listen_Attribute||'': Switch'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    Listen_Attribute',
'from (',
unistr('    select 17 as liAtt_id, ''L\00E4nder'' as Listen_Attribute from dual'),
'    union',
'    select 18 as liAtt_id, ''Themen'' as Listen_Attribute from dual',
'    union',
'    select 19 as liAtt_id, ''Fahrzeugklassen'' as Listen_Attribute from dual',
') cte;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    to_number(''999999'') as liAtt_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 6,',
'        p_value => ''Y'',',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_ALL_LISTEN'',',
'        p_item_label => ''Listen Attribute: All'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    ''Listen Attribute'' as Listen_Attribute',
'from dual',
'',
'union all',
'',
'select ',
'    liAtt_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 3,',
'        p_value => CASE ',
'                    WHEN INSTR('':''||:P29_SELECTED_LISTEN||'':'','':''||liAtt_id||'':'') > 0 ',
'                    THEN ''Y'' ',
'                    ELSE ''Y''',
'                  END,',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_LISTEN_''||liAtt_id,',
'        p_item_label => Listen_Attribute||'': Switch'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    Listen_Attribute',
'from (',
'    select 12 as liAtt_id, ''Sucessor / Predecessor'' as Listen_Attribute from dual',
'    union',
'    select 13 as liAtt_id, ''Linked'' as Listen_Attribute from dual',
'    union',
'    select 14 as liAtt_id, ''Changes'' as Listen_Attribute from dual',
'    union',
'    select 15 as liAtt_id, ''Demands'' as Listen_Attribute from dual',
'    union',
'    select 16 as liAtt_id, ''Equivalent'' as Listen_Attribute from dual',
'    union',
unistr('    select 17 as liAtt_id, ''L\00E4nder'' as Listen_Attribute from dual'),
'    union',
'    select 18 as liAtt_id, ''Themen'' as Listen_Attribute from dual',
'    union',
'    select 19 as liAtt_id, ''Fahrzeugklassen'' as Listen_Attribute from dual',
') cte;'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1081792428463635409)
,p_query_column_id=>1
,p_column_alias=>'LIATT_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1081792407779635408)
,p_query_column_id=>2
,p_column_alias=>'SWITCH_ITEM'
,p_column_display_sequence=>20
,p_column_heading=>'<div class="switch-buttons">          <button type="button" class="ja-button active" id="listen-ja">Ja</button>          <button type="button" class="nein-button" id="listen-nein">Nein</button>  </div>'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1081792302988635407)
,p_query_column_id=>3
,p_column_alias=>'LISTEN_ATTRIBUTE'
,p_column_display_sequence=>30
,p_column_heading=>'Listen Attribute'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1057070915357661187)
,p_name=>'Relation Attribute - heading'
,p_parent_plug_id=>wwv_flow_imp.id(1505792300213178570)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>70
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_grid_column_span=>3
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    relType_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 4,',
'        p_value => CASE ',
'                    WHEN INSTR('':''||:P29_SELECTED_RELATIONS||'':'','':''||relType_id||'':'') > 0 ',
'                    THEN ''Y'' ',
'                    ELSE ''Y''',
'                  END,',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_RELATIONS_''||relType_id,',
'        p_item_label => Relations_Type||'': Switch'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    Relations_Type',
'from (',
'    select 12 as relType_id, ''Sucessor / Predecessor'' as Relations_Type from dual',
'    union',
'    select 13 as relType_id, ''Linked To'' as Relations_Type from dual',
'    union',
'    select 14 as relType_id, ''Changes'' as Relations_Type from dual',
'    union',
'    select 15 as relType_id, ''Demands'' as Relations_Type from dual',
'    union',
'    select 16 as relType_id, ''Equivalent'' as Relations_Type from dual',
') cte;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    to_number(''999999'') as liAtt_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 6,',
'        p_value => ''Y'',',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_ALL_LISTEN'',',
'        p_item_label => ''Listen Attribute: All'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    ''Listen Attribute'' as Listen_Attribute',
'from dual',
'',
'union all',
'',
'select ',
'    liAtt_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 3,',
'        p_value => CASE ',
'                    WHEN INSTR('':''||:P29_SELECTED_LISTEN||'':'','':''||liAtt_id||'':'') > 0 ',
'                    THEN ''Y'' ',
'                    ELSE ''Y''',
'                  END,',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_LISTEN_''||liAtt_id,',
'        p_item_label => Listen_Attribute||'': Switch'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    Listen_Attribute',
'from (',
'    select 12 as liAtt_id, ''Sucessor / Predecessor'' as Listen_Attribute from dual',
'    union',
'    select 13 as liAtt_id, ''Linked'' as Listen_Attribute from dual',
'    union',
'    select 14 as liAtt_id, ''Changes'' as Listen_Attribute from dual',
'    union',
'    select 15 as liAtt_id, ''Demands'' as Listen_Attribute from dual',
'    union',
'    select 16 as liAtt_id, ''Equivalent'' as Listen_Attribute from dual',
'    union',
unistr('    select 17 as liAtt_id, ''L\00E4nder'' as Listen_Attribute from dual'),
'    union',
'    select 18 as liAtt_id, ''Themen'' as Listen_Attribute from dual',
'    union',
'    select 19 as liAtt_id, ''Fahrzeugklassen'' as Listen_Attribute from dual',
') cte;'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1055144046901317533)
,p_query_column_id=>1
,p_column_alias=>'RELTYPE_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1057070686503661185)
,p_query_column_id=>2
,p_column_alias=>'SWITCH_ITEM'
,p_column_display_sequence=>20
,p_column_heading=>'<div class="switch-buttons">     <button type="button" class="ja-button active" id="relations-ja">Ja</button>     <button type="button" class="nein-button" id="relations-nein">Nein</button> </div>'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1055143973844317532)
,p_query_column_id=>3
,p_column_alias=>'RELATIONS_TYPE'
,p_column_display_sequence=>40
,p_column_heading=>'Relations Type'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4838059380679153640)
,p_plug_name=>'Main Region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3148578635267251393)
,p_plug_name=>'</>'
,p_parent_plug_id=>wwv_flow_imp.id(4838059380679153640)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>80
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3136214537876152424)
,p_plug_name=>unistr('Au\00DFerkraftsetzung von Vorg\00E4nger-Vorschriften')
,p_parent_plug_id=>wwv_flow_imp.id(4838059380679153640)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>90
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Durch die Daten\00FCbernahme ist die Setzung bzw. Ver\00E4nderung des Au\00DFerkraftsetzungs-Datum bei mindestens einer Vorg\00E4nger-Vorschrift vorgesehen:<br />'),
'&P29_VALIDATION_AUSSER_KRAFT!RAW.'))
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P29_VALIDATION_AUSSER_KRAFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1069009479583571925)
,p_plug_name=>unistr('Verkn\00FCpfung nach Art')
,p_parent_plug_id=>wwv_flow_imp.id(4838059380679153640)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>160
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1069009323926571924)
,p_name=>'Predecessor->Successor'
,p_parent_plug_id=>wwv_flow_imp.id(1069009479583571925)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' with cte_mv as ( ',
'                select  vr.V_ID, vr.vorschriftid, vr.reg_number, vr.relationtype relationtype, vr.target_reg_number target_reg_number,',
'                  vr.multigroupid, vr.successorsincluded, ',
'                    vr.sc_type, vr.targetid, min(vr.sc_date) as sc_date',
'                from MV_GETEX_VORSCHRIFT_RELATION vr ',
'                where vr.vorschriftid = :P29_VORSCHRIFTID  --5682 --436  ',
'                GROUP BY vr.V_ID, vr.vorschriftid, vr.reg_number, vr.relationtype, vr.target_reg_number, vr.sc_type, vr.targetid, ',
'                vr.multigroupid, vr.successorsincluded',
'                order by relationtype, targetid',
' ), cte_mv_t as ( ',
'                 select  t.vorschriftid targ_vorschriftid, mv.V_ID, mv.vorschriftid, mv.reg_number, mv.multigroupid, mv.successorsincluded,',
'                    mv.relationtype , mv.target_reg_number ,  mv.sc_type, mv.targetid, mv.sc_date, gv.rev_doc_datum target_doc_datum',
'                 from cte_mv mv',
'                 join t_vorschrift t on (t.regindexid = mv.targetid) ',
'                  -- 1384  geloeschte vorsch',
'                 join MV_GETEX_VORSCHRIFT gv on (gv.reg_id =  mv.targetid)',
'                  where (nvl(gv.loesch_datum, sysdate +200) > sysdate)',
' ),  cte_mv_r as (',
'                select Distinct t.vorschriftid targ_vorschriftid, vr.V_ID, vr.vorschriftid, vr.reg_number, vr.relationtype, vr.target_reg_number',
'                    , vr.multigroupid, vr.successorsincluded ',
'                from MV_GETEX_VORSCHRIFT_RELATION vr ',
'                join t_vorschrift t on (t.regindexid = vr.targetid) ',
'                  -- 1384  geloeschte vorsch',
'                 join MV_GETEX_VORSCHRIFT gv on (gv.reg_id = vr.V_ID)',
'                  where (nvl(gv.loesch_datum, sysdate +200) > sysdate)',
'                  -- \\\\',
'                and t.vorschriftid =  :P29_VORSCHRIFTID  --5682 --436',
' ),',
unistr('  cte_lnd_flag_g as (  -- f\00FCr l\00E4nder, die doppelte Vorschriften_namen haben k\00F6nnen'),
'        select distinct gvl.v_id, v.vorschriftid',
'        from mv_getex_vorschrift_land gvl',
'        join T_land la on (la.iso_code_3 = gvl.iso_code3)',
'        join t_vorschrift v on (v.regindexid is not null and v.regindexid =gvl.v_id)',
'        where la.cockpit_erw_anzeige >0',
'         --and v.vorschriftid = :P29_VORSCHRIFTID',
' )',
'',
' --/////',
' SELECT  --- nur in Regindex als Vorgaenger oder nachfolger, nicht in  GETEX        --nachf 25701',
'  ''<span class="hl">nicht vorhanden</span>'' AS Getex_Predecessor --Vorschrift_nummer,',
'    ,  ''<span class="hl">nicht vorhanden</span>'' AS Getex_Successor --TargetVorschrift_nummer   -- mv.sc_type, mv.sc_date ,',
'    , nvl2(t.vorschrift_nummer, concat(t.vorschrift_nummer ,  ',
'                           case when :P29_LAND_ERW_ANZEIGE =''Ja'' then  nvl2(t.dokumentendatum, ''_''|| to_char(t.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end), ',
'                    ''<span class="hl">nicht vorhanden</span>'') as Regindex_Predecessor --vorgaenger_vorschrift',
'    , nvl2(t_n.Vorschrift_nummer, concat(t_n.vorschrift_nummer ,  ',
'                           case when :P29_LAND_ERW_ANZEIGE =''Ja'' then  nvl2(t_n.dokumentendatum,''_''|| to_char(t_n.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end), ',
'                     ''<span class="hl">nicht vorhanden</span>'') AS Regindex_Successor --nachfolger_vorschrift ',
'',
' FROM t_vorschrift_ref_vorschrift tvrv ',
'  left outer join T_VORSCHRIFT t on ( t.VORSCHRIFTID = tvrv.Vorgaenger_Vorschriftid )    --and t.REGINDEXID is not null  )',
'    left outer join T_VORSCHRIFT t_n on (t_n.VORSCHRIFTID = tvrv.NACHFOLGER_VORSCHRIFTID )  -- and t_n.REGINDEXID is not null  )',
'    where  (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 OR  tvrv.beziehung_art not in (40,102))  --AB2!',
'     and tvrv.beziehung_art = 10 -- ( story 1364)',
'     and',
'    (',
'        ( tvrv.vorgaenger_vorschriftid = :P29_VORSCHRIFTID ',
'           and tvrv.nachfolger_vorschriftid not in ( select targ_vorschriftid from cte_mv_t mv where -- vorschriftid =436',
'                                ( mv.relationtype = ''IS_CHANGED_BY'' and (( instr(upper(mv.target_reg_number),''UN-R'')=1 and tvrv.beziehung_art =30) or  tvrv.beziehung_art =20 ) ',
'                                   OR tvrv.beziehung_art = decode(mv.relationtype, ''PREDECESSOR'' , 10,      ''LINKED_FROM'', 60, ''IS_CONSOLIDATED_IN'', 200, 0 )',
'                                    OR  (tvrv.beziehung_art = decode(mv.relationtype, ''IS_DEMANDED_BY'', 40,  ',
'                                             ''SEEN_AS_EQUIVALENT_BY'', 102,   0  ) ',
'                                           and  (mv.multigroupid is null or (mv.multigroupid is not null and (nvl(mv.successorsincluded, ''false'') = ''true'')))',
'                                    )',
'                                )  ',
'                            )',
'        ) ',
'',
'        OR     ',
'        ( tvrv.nachfolger_vorschriftid = :P29_VORSCHRIFTID',
'            and tvrv.vorgaenger_vorschriftid not in ( select vorschriftid  from cte_mv_r mr   where ',
'                            (  mr.relationtype = ''IS_CHANGED_BY'' and ( instr(upper(mr.reg_number),''UN-R'')=1 and tvrv.beziehung_art =30 or  tvrv.beziehung_art =20 ) ',
'                                OR tvrv.beziehung_art = decode(mr.relationtype, ''PREDECESSOR'' , 10,      ''LINKED_FROM'', 60, ''IS_CONSOLIDATED_IN'', 200, 0 )',
'                                OR  (  tvrv.beziehung_art = decode(mr.relationtype, ''IS_DEMANDED_BY'', 40,   ',
'                                             ''SEEN_AS_EQUIVALENT_BY'', 102,    0  )',
'                                      and  (mr.multigroupid is null or (mr.multigroupid is not null and (nvl(mr.successorsincluded, ''false'') = ''true'')))',
'                                )',
'                            ) ',
'                        )',
'        )',
'    )                  ',
'                 ',
'',
' UNION',
'',
'  --///// nur in GETEX als Nachfolger von , nicht in Regindex',
' SELECT ',
'                                       -- so rum wenn mv.relationtype in ''PREDECESSOR''',
'    nvl(mv.reg_number, ''<span class="hl">nicht vorhanden</span>'') --|| ''-''|| mv.vorschriftid ',
'        AS Getex_Predecessor    --Vorschrift_nummer,',
'   , nvl2(mv.target_reg_number,  concat( mv.target_reg_number  , ',
'                           case when :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl2( mv.target_doc_datum , ''_''|| to_char(mv.target_doc_datum ,''dd.mm.yyyy'' ), '''')  else '''' end ),',
'                          ''<span class="hl">nicht vorhanden</span>'') -- ||''-''|| mv.targ_vorschriftid ',
'        AS Getex_Successor  --TargetVorschrift_nummer',
'    ,  ''<span class="hl">nicht vorhanden</span>'' as Regindex_Predecessor --_vorgaenger_vorschrift',
'    ,  ''<span class="hl">nicht vorhanden</span>'' AS Regindex_Successor --_nachfolger_vorschrift ',
' ',
'          --  nvl2(mv.target_reg_number,  concat( mv.target_reg_number || '' '' , ',
'          --                         case when :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(mv.rev_doc_datum ,''dd.mm.yyyy'' ), '''')  else '''' end ),',
'          --                        ''<span class="hl">nicht vorhanden</span>'') AS Getex_Predecessor --TargetVorschrift_nummer',
'         -- ,  nvl(mv.reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Successor --Vorschrift_nummer,',
'         --   ,  ''<span class="hl">nicht vorhanden</span>'' as Regindex_Predecessor --_vorgaenger_vorschrift',
'         --   ,  ''<span class="hl">nicht vorhanden</span>'' AS Regindex_Successor --_nachfolger_vorschrift ',
' ',
'  from  cte_mv_t mv',
' where  mv.relationtype in (''SUCCESSOR'', ''PREDECESSOR'') -- story 1364',
' ',
'   and mv.Vorschriftid not in ( select tvrv.nachfolger_vorschriftid from t_vorschrift_ref_vorschrift tvrv',
'                                where tvrv.vorgaenger_vorschriftid = mv.targ_vorschriftid ',
'                                  and  ( mv.relationtype= ''CHANGES'' and ( instr(upper(mv.target_reg_number),''UN-R'')=1 and tvrv.beziehung_art =30 or  tvrv.beziehung_art =20 )',
'                                          OR  tvrv.beziehung_art = decode(mv.relationtype,  ''SUCCESSOR'', 10,  ''LINKED_TO'', 60, ''CONSOLIDATES'', 200, 0  )',
'',
'                                          OR  ( tvrv.beziehung_art = decode(mv.relationtype, ''DEMANDS'', 40,  ''EQUIVALENT_TO'', 102,   0  )',
'                                              and (nvl(mv.successorsincluded, ''false'') = ''false''  and mv.multigroupid is Not null)',
'                                          )',
'                                          OR  (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 and tvrv.beziehung_art = decode(mv.relationtype, ''IS_DEMANDED_BY'', 40,   ',
'                                             ''SEEN_AS_EQUIVALENT_BY'', 102,    0  )',
'                                          )',
'                                   ) ',
'                               )',
'    --//---- andere verkn. in regindex, wo P29_VORSCHRIFTID als Nachfolger,  nicht mitnehmen',
'  and mv.Vorschriftid not in (select tvrv.nachfolger_vorschriftid from t_vorschrift_ref_vorschrift tvrv',
'                                where tvrv.vorgaenger_vorschriftid = mv.targ_vorschriftid',
'                                and ( mv.relationtype= ''IS_CHANGED_BY'' and ( instr(upper(mv.target_reg_number),''UN-R'')=1 and tvrv.beziehung_art =30 or  tvrv.beziehung_art =20 )',
'                                        OR tvrv.beziehung_art = decode(mv.relationtype, ''PREDECESSOR'' , 10,   ''LINKED_FROM'', 60, ''IS_CONSOLIDATED_IN'', 200, 0 )',
'                                    ',
'                                        OR  (tvrv.beziehung_art = decode(mv.relationtype, ''IS_DEMANDED_BY'', 40, ''SEEN_AS_EQUIVALENT_BY'', 102,   0  )',
'                                        )',
'                                        OR  (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 and  tvrv.beziehung_art = decode(mv.relationtype, ''DEMANDS'', 40, ',
'                                             ''EQUIVALENT_TO'', 102,    0  )',
'                                        )',
'                                    ) ',
'                                )',
'     --\\\\',
'  -- andere verkn. in regindex, wo P29_VORSCHRIFTID als Vorgaenger  nicht mitnehmen',
'  and mv.Vorschriftid not in (select tvrv.vorgaenger_vorschriftid from t_vorschrift_ref_vorschrift tvrv',
'                                where tvrv.nachfolger_vorschriftid = mv.targ_vorschriftid ',
'                                and (mv.relationtype= ''IS_CHANGED_BY'' and ( instr(upper(mv.reg_number),''UN-R'')=1 and tvrv.beziehung_art =30 or  tvrv.beziehung_art =20 )',
'                                    OR tvrv.beziehung_art = decode(mv.relationtype, ''PREDECESSOR'' , 10,    ''LINKED_FROM'', 60, ''IS_CONSOLIDATED_IN'', 200, 0 )',
'                                    OR  (tvrv.beziehung_art = decode(mv.relationtype, ''IS_DEMANDED_BY'', 40,  ''SEEN_AS_EQUIVALENT_BY'', 102,    0  )',
'                                    )',
'                                    OR  ( PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 and tvrv.beziehung_art = decode(mv.relationtype, ''DEMANDS'', 40,  ',
'                                             ''EQUIVALENT_TO'', 102,   0  )',
'                                    )',
'                                ) ',
'                            )  -- for 436',
' ',
'  UNION',
'  ',
' ',
' -- -- vorschr as nachfolger  exact passend',
'  -- keine DEMANDS',
'   SELECT DISTINCT  ',
'     nvl(mv.target_reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Predecessor --TargetVorschrift_nummer   -- mv.sc_type, mv.sc_date ,',
'  , nvl(mv.reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Successor --Vorschrift_nummer',
'  , nvl2(t.vorschrift_nummer, concat(t.vorschrift_nummer ,  ',
'                       case when :P29_LAND_ERW_ANZEIGE =''Ja'' then nvl2(t.dokumentendatum,''_''|| to_char(t.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end),',
'                         ''<span class="hl">nicht vorhanden</span>'')  as Regindex_Predecessor ',
'    --, nvl(t.vorschrift_nummer, ''<span class="hl">nicht vorhanden</span>'') as Regindex_Predecessor --_vorgaenger_vorschrift',
'    , nvl2(t_n.Vorschrift_nummer, concat(t_n.Vorschrift_nummer,  ',
'                       case when :P29_LAND_ERW_ANZEIGE =''Ja'' then nvl2(t_n.dokumentendatum, ''_''|| to_char(t_n.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end),',
'                    ''<span class="hl">nicht vorhanden</span>'') AS Regindex_Successor --_nachfolger_vorschrift',
'',
' FROM  T_VORSCHRIFT_REF_VORSCHRIFT tvrv',
' full outer JOIN cte_mv_t mv on ( mv.vorschriftid = tvrv.Nachfolger_Vorschriftid and tvrv.Vorgaenger_vorschriftid = mv.targ_vorschriftid )',
' left outer join T_VORSCHRIFT t on ( t.VORSCHRIFTID = tvrv.Vorgaenger_Vorschriftid and t.REGINDEXID is not null  ) ',
' left outer join T_VORSCHRIFT t_n on (t_n.VORSCHRIFTID = tvrv.NACHFOLGER_VORSCHRIFTID and t_n.REGINDEXID is not null  )',
'-- full outer JOIN cte_daten_getex3 g3 on ( g3.sc_type in ( ''All Vehicles'', ''New Types'') )',
'',
' WHERE mv.vorschriftid = :P29_VORSCHRIFTID ',
' and mv.relationtype  in ( ''SUCCESSOR'')  -- story 1364',
' ',
' --  order by nachfolger_vorschriftID, Getex_TargetVorschrift_nummer',
'  and  ( tvrv.beziehung_art = 10  )  ',
'        ----****',
'  UNION',
' -- vorschrift as vorgaenger passend',
' SELECT     nvl(mv.reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Predescessor ----Vorschrift_nummer',
'   , nvl(mv.target_reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Successor --TargetVorschrift_nummer   -- mv.sc_type, mv.sc_date ,',
'   , nvl2(t.vorschrift_nummer, concat(t.vorschrift_nummer ,  ',
'                      case when:P29_LAND_ERW_ANZEIGE =''Ja''  then nvl2(t.dokumentendatum, ''_''|| to_char(t.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end),',
'                       ''<span class="hl">nicht vorhanden</span>'') as Regindex_Predescessor --_vorgaenger_vorschrift',
'   ,  nvl2(t_n.Vorschrift_nummer, concat(t_n.vorschrift_nummer ,  ',
'                       case when :P29_LAND_ERW_ANZEIGE =''Ja'' then nvl2(t_n.dokumentendatum, ''_''|| to_char(t_n.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end),',
'   ''<span class="hl">nicht vorhanden</span>'') AS Regindex_Successor --_Nachfolger_vorschrift  --    ',
' ',
' FROM T_VORSCHRIFT_REF_VORSCHRIFT tvrv',
'  --full outer ',
'  JOIN cte_mv_t mv  on (  mv.vorschriftid = tvrv.Vorgaenger_Vorschriftid and mv.targ_vorschriftid = tvrv.Nachfolger_Vorschriftid) ',
'  left outer join T_VORSCHRIFT t on ( t.VORSCHRIFTID = tvrv.Vorgaenger_Vorschriftid and t.REGINDEXID is not null ) ',
'  left outer join T_VORSCHRIFT t_n on (t_n.VORSCHRIFTID = tvrv.NACHFOLGER_VORSCHRIFTID and t_n.REGINDEXID is not null  )',
'  --full outer JOIN cte_daten_getex3 g3 on ( g3.sc_type in ( ''All Vehicles'', ''New Types'') )',
' WHERE mv.vorschriftid = :P29_VORSCHRIFTID --5682 --436 --:P29_VORSCHRIFTID ',
' and mv.relationtype  in ( ''PREDECESSOR'')  -- story 1364',
'  ',
'   and  ( tvrv.beziehung_art = 10)',
'',
'order by  4'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT 1 from MV_GETEX_VORSCHRIFT_RELATION ',
'   where v_id = (select regindexid from t_vorschrift where vorschriftid= :P29_VORSCHRIFTID and regindexid is not null)',
'   and relationtype in (''SUCCESSOR'', ''PREDECESSOR'')',
'   ',
' UNION',
'  SELECT  1 from t_vorschrift_ref_vorschrift ',
'   where  (vorgaenger_vorschriftid = :P29_VORSCHRIFTID or nachfolger_vorschriftid = :P29_VORSCHRIFTID)',
'   and beziehung_art in (10)'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069009244568571923)
,p_query_column_id=>1
,p_column_alias=>'GETEX_PREDECESSOR'
,p_column_display_sequence=>10
,p_column_heading=>'Getex Predecessor'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069009197529571922)
,p_query_column_id=>2
,p_column_alias=>'GETEX_SUCCESSOR'
,p_column_display_sequence=>20
,p_column_heading=>'Getex Successor'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069009048093571921)
,p_query_column_id=>3
,p_column_alias=>'REGINDEX_PREDECESSOR'
,p_column_display_sequence=>30
,p_column_heading=>'Regindex Predecessor'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069008997381571920)
,p_query_column_id=>4
,p_column_alias=>'REGINDEX_SUCCESSOR'
,p_column_display_sequence=>40
,p_column_heading=>'Regindex Successor'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1069008907358571919)
,p_name=>'Linked to'
,p_parent_plug_id=>wwv_flow_imp.id(1069009479583571925)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' with cte_mv as ( ',
'                select  vr.V_ID, vr.vorschriftid, vr.reg_number, vr.relationtype relationtype, vr.target_reg_number target_reg_number,',
'                  vr.multigroupid, vr.successorsincluded, ',
'                    vr.sc_type, vr.targetid, min(vr.sc_date) as sc_date',
'                from MV_GETEX_VORSCHRIFT_RELATION vr ',
'                where vr.vorschriftid = :P29_VORSCHRIFTID  --5682 --436  ',
'                GROUP BY vr.V_ID, vr.vorschriftid, vr.reg_number, vr.relationtype, vr.target_reg_number, vr.sc_type, vr.targetid, ',
'                vr.multigroupid, vr.successorsincluded',
'                order by relationtype, targetid',
' ), cte_mv_t as ( ',
'                 select  t.vorschriftid targ_vorschriftid, mv.V_ID, mv.vorschriftid, mv.reg_number, mv.multigroupid, mv.successorsincluded,',
'                    mv.relationtype , mv.target_reg_number ,  mv.sc_type, mv.targetid, mv.sc_date, gv.rev_doc_datum',
'                 from cte_mv mv',
'                 join t_vorschrift t on (t.regindexid = mv.targetid) ',
'                 -- 1436  geloeschte vorsch',
'                 join MV_GETEX_VORSCHRIFT gv on (gv.reg_id = t.regindexid)',
'                  where (nvl(gv.loesch_datum, sysdate +200) > sysdate)',
' ),  cte_mv_r as (',
'                select Distinct t.vorschriftid targ_vorschriftid, vr.V_ID, vr.vorschriftid, vr.reg_number, vr.relationtype, vr.target_reg_number',
'                    , vr.multigroupid, vr.successorsincluded ',
'                from MV_GETEX_VORSCHRIFT_RELATION vr ',
'                join t_vorschrift t on (t.regindexid = vr.targetid)',
'                 -- 1436  geloeschte vorsch',
'                 join MV_GETEX_VORSCHRIFT gv on (gv.reg_id = vr.V_ID)',
'                  where (nvl(gv.loesch_datum, sysdate +200) > sysdate)',
'                  -- \\\\',
'                and  t.vorschriftid =  :P29_VORSCHRIFTID  --5682 --436',
' )',
'  ',
' --/////',
' SELECT  --- nur in Regindex als Vorgaenger oder nachfolger, nicht in  GETEX        --nachf 25701',
'     ''<span class="hl">nicht vorhanden</span>'' AS Getex_Hauptvorschrift --_TargetVorschrift_nummer   -- mv.sc_type, mv.sc_date ,',
'   --, ''<span class="hl">nicht vorhanden</span>'' as relationtype   -- nvl(vr.vorschriftid, 0) AS GetexVorschriftID, vr.V_ID Getex_ID,',
'   , ''<span class="hl">nicht vorhanden</span>'' AS Getex_Verlinkte_Vorschrift --Vorschrift_nummer,',
'   , nvl2(t.vorschrift_nummer, concat(t.vorschrift_nummer ,  ',
'                           case when :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl2(t.dokumentendatum, ''_''|| to_char(t.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end), ',
'                    ''<span class="hl">nicht vorhanden</span>'') as Regindex_Hauptvorschrift --_vorgaenger_vorschrift',
'   -- , decode(tvrv.beziehung_art, 10, ''predeccessor >>successor'', 20, ''Amendment'',  30, ''Supplement'',  40, ''Demands'', 102,''Equivalent'',  60, ''Linked'', ''unbekannt'') beziehung_art',
'    , nvl2(t_n.Vorschrift_nummer, concat(t_n.vorschrift_nummer ,  ',
'                           case when :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl2(t_n.dokumentendatum,''_''|| to_char(t_n.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end), ',
'                    ''<span class="hl">nicht vorhanden</span>'') AS Regindex_Verlinkte_Vorschrift --_nachfolger_vorschrift ',
'',
' FROM t_vorschrift_ref_vorschrift tvrv ',
'  left outer join T_VORSCHRIFT t on ( t.VORSCHRIFTID = tvrv.Vorgaenger_Vorschriftid )    --and t.REGINDEXID is not null  )',
'    left outer join T_VORSCHRIFT t_n on (t_n.VORSCHRIFTID = tvrv.NACHFOLGER_VORSCHRIFTID )  -- and t_n.REGINDEXID is not null  )',
'    where  (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 OR  tvrv.beziehung_art not in (40,102))  --AB2!',
'     and tvrv.beziehung_art = 60 -- ( story 1364)',
'     and',
'    (',
'        ( tvrv.vorgaenger_vorschriftid = :P29_VORSCHRIFTID ',
'           and tvrv.nachfolger_vorschriftid not in ( select targ_vorschriftid from cte_mv_t mv where -- vorschriftid =436',
'                                ( mv.relationtype = ''IS_CHANGED_BY'' and (( instr(upper(mv.target_reg_number),''UN-R'')=1 and tvrv.beziehung_art =30) or  tvrv.beziehung_art =20 ) ',
'                                   OR tvrv.beziehung_art = decode(mv.relationtype, ''PREDECESSOR'' , 10,      ''LINKED_FROM'', 60, ''IS_CONSOLIDATED_IN'', 200, 0 )',
'                                    OR  (tvrv.beziehung_art = decode(mv.relationtype, ''IS_DEMANDED_BY'', 40,  ',
'                                             ''SEEN_AS_EQUIVALENT_BY'', 102,   0  ) ',
'                                           and  (mv.multigroupid is null or (mv.multigroupid is not null and (nvl(mv.successorsincluded, ''false'') = ''true'')))',
'                                    )',
'                                )  ',
'                            )',
'        ) ',
'',
'        OR     ',
'        ( tvrv.nachfolger_vorschriftid = :P29_VORSCHRIFTID',
'            and tvrv.vorgaenger_vorschriftid not in ( select vorschriftid  from cte_mv_r mr   where ',
'                            (  mr.relationtype = ''IS_CHANGED_BY'' and ( instr(upper(mr.reg_number),''UN-R'')=1 and tvrv.beziehung_art =30 or  tvrv.beziehung_art =20 ) ',
'                                OR tvrv.beziehung_art = decode(mr.relationtype, ''PREDECESSOR'' , 10,      ''LINKED_FROM'', 60, ''IS_CONSOLIDATED_IN'', 200, 0 )',
'                                OR  (  tvrv.beziehung_art = decode(mr.relationtype, ''IS_DEMANDED_BY'', 40,   ',
'                                             ''SEEN_AS_EQUIVALENT_BY'', 102,    0  )',
'                                      and  (mr.multigroupid is null or (mr.multigroupid is not null and (nvl(mr.successorsincluded, ''false'') = ''true'')))',
'                                )',
'                            ) ',
'                        )',
'        )',
'    )                  ',
'                 ',
'',
' UNION',
'',
'  --///// nur in GETEX als Nachfolger von , nicht in Regindex',
' SELECT ',
'    nvl2( mv.target_reg_number, concat( mv.target_reg_number  , ',
'                           case when :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl2(mv.rev_doc_datum, ''_''|| to_char( mv.rev_doc_datum ,''dd.mm.yyyy'' ), '''')  else '''' end ),',
'                           ''<span class="hl">nicht vorhanden</span>'') AS Getex_Hauptvorschrift',
'    --nvl(mv.target_reg_number,  ''<span class="hl">nicht vorhanden</span>'') AS Getex_Hauptvorschrift --_TargetVorschrift_nummer',
'  -- , mv.relationtype   -- nvl(vr.vorschriftid, 0) AS GetexVorschriftID, vr.V_ID Getex_ID,',
'   , nvl(mv.reg_number,  ',
'                       ''<span class="hl">nicht vorhanden</span>'') AS Getex_Verlinkte_Vorschrift --Vorschrift_nummer,',
'    ,  ''<span class="hl">nicht vorhanden</span>'' as Regindex_Hauptvorschrift --_vorgaenger_vorschrift',
'  --  , '''' beziehung_art',
'    ,  ''<span class="hl">nicht vorhanden</span>'' AS Regindex_Verlinkte_Vorschrift --_nachfolger_vorschrift ',
' ',
' from  cte_mv_t mv',
' where  mv.relationtype in (''LINKED_TO'', ''LINKED_FROM'') -- story 1364',
'  ',
'  and (nvl(mv.successorsincluded, ''false'') = ''true'' or mv.multigroupid is  null)',
'   and mv.Vorschriftid not in ( select tvrv.nachfolger_vorschriftid from t_vorschrift_ref_vorschrift tvrv',
'                                where tvrv.vorgaenger_vorschriftid = mv.targ_vorschriftid ',
'                                  and  ( mv.relationtype= ''CHANGES'' and ( instr(upper(mv.target_reg_number),''UN-R'')=1 and tvrv.beziehung_art =30 or  tvrv.beziehung_art =20 )',
'                                          OR  tvrv.beziehung_art = decode(mv.relationtype,  ''SUCCESSOR'', 10,  ''LINKED_TO'', 60, ''CONSOLIDATES'', 200, 0  )',
'',
'                                          OR  ( tvrv.beziehung_art = decode(mv.relationtype, ''DEMANDS'', 40,  ''EQUIVALENT_TO'', 102,   0  )',
'                                              and (nvl(mv.successorsincluded, ''false'') = ''false''  and mv.multigroupid is Not null)',
'                                          )',
'                                          OR  (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 and tvrv.beziehung_art = decode(mv.relationtype, ''IS_DEMANDED_BY'', 40,   ',
'                                             ''SEEN_AS_EQUIVALENT_BY'', 102,    0  )',
'                                          )',
'                                   ) ',
'                               )',
'    --//---- andere verkn. in regindex, wo P29_VORSCHRIFTID als Nachfolger,  nicht mitnehmen',
'  and mv.Vorschriftid not in (select tvrv.nachfolger_vorschriftid from t_vorschrift_ref_vorschrift tvrv',
'                                where tvrv.vorgaenger_vorschriftid = mv.targ_vorschriftid',
'                                and ( mv.relationtype= ''IS_CHANGED_BY'' and ( instr(upper(mv.target_reg_number),''UN-R'')=1 and tvrv.beziehung_art =30 or  tvrv.beziehung_art =20 )',
'                                        OR tvrv.beziehung_art = decode(mv.relationtype, ''PREDECESSOR'' , 10,   ''LINKED_FROM'', 60, ''IS_CONSOLIDATED_IN'', 200, 0 )',
'                                    ',
'                                        OR  (tvrv.beziehung_art = decode(mv.relationtype, ''IS_DEMANDED_BY'', 40, ''SEEN_AS_EQUIVALENT_BY'', 102,   0  )',
'                                        )',
'                                        OR  (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 and  tvrv.beziehung_art = decode(mv.relationtype, ''DEMANDS'', 40, ',
'                                             ''EQUIVALENT_TO'', 102,    0  )',
'                                        )',
'                                    ) ',
'                                )',
'     --\\\\',
'  -- andere verkn. in regindex, wo P29_VORSCHRIFTID als Vorgaenger  nicht mitnehmen',
'  and mv.Vorschriftid not in (select tvrv.vorgaenger_vorschriftid from t_vorschrift_ref_vorschrift tvrv',
'                                where tvrv.nachfolger_vorschriftid = mv.targ_vorschriftid ',
'                                and (mv.relationtype= ''IS_CHANGED_BY'' and ( instr(upper(mv.reg_number),''UN-R'')=1 and tvrv.beziehung_art =30 or  tvrv.beziehung_art =20 )',
'                                    OR tvrv.beziehung_art = decode(mv.relationtype, ''PREDECESSOR'' , 10,    ''LINKED_FROM'', 60, ''IS_CONSOLIDATED_IN'', 200, 0 )',
'                                    OR  (tvrv.beziehung_art = decode(mv.relationtype, ''IS_DEMANDED_BY'', 40,  ''SEEN_AS_EQUIVALENT_BY'', 102,    0  )',
'                                    )',
'                                    OR  ( PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 and tvrv.beziehung_art = decode(mv.relationtype, ''DEMANDS'', 40,  ',
'                                             ''EQUIVALENT_TO'', 102,   0  )',
'                                    )',
'                                ) ',
'                            )  -- for 436',
' ',
'  UNION',
'  ',
'--\\\',
' ',
' -- -- vorschr as nachfolger  exact passend',
'  -- keine DEMANDS',
'   SELECT DISTINCT     nvl(mv.target_reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Hauptvorschrift   -- mv.sc_type, mv.sc_date ,',
'   -- , mv.relationtype   -- nvl(vr.vorschriftid, 0) AS GetexVorschriftID, vr.V_ID Getex_ID,',
'  , nvl(mv.reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Verlinkte_Vorschrift --_nummer',
'   ,  nvl2(t.vorschrift_nummer, concat(t.vorschrift_nummer ,  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl2(t.dokumentendatum,''_''|| to_char(t.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end),',
'                           ''<span class="hl">nicht vorhanden</span>'')',
'    as Regindex_Hauptvorschrift --vorgaenger_vorschrift',
'  --  , decode(tvrv.beziehung_art, 10, ''predeccessor >>successor'', 20, ''Amendment'', 30, ''Supplement'', 40, ''Demands'', 102,''Equivalent'',  60, ''Linked'', ''unbekannt'') beziehung_art',
'    , nvl2(t_n.vorschrift_nummer, concat(t_n.vorschrift_nummer ,',
'                     case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl2(t_n.dokumentendatum, ''_''|| to_char(t_n.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end), ',
'                     ''<span class="hl">nicht vorhanden</span>'') AS Regindex_Verlinkte_Vorschrift --_nachfolger_vorschrift',
'   -- , tvrv.datum_alle_typen, tvrv.datum_neue_typen ',
'',
' FROM  T_VORSCHRIFT_REF_VORSCHRIFT tvrv',
' full outer JOIN cte_mv_t mv on ( mv.vorschriftid = tvrv.Nachfolger_Vorschriftid and tvrv.Vorgaenger_vorschriftid = mv.targ_vorschriftid )',
' left outer join T_VORSCHRIFT t on ( t.VORSCHRIFTID = tvrv.Vorgaenger_Vorschriftid and t.REGINDEXID is not null  ) ',
' left outer join T_VORSCHRIFT t_n on (t_n.VORSCHRIFTID = tvrv.NACHFOLGER_VORSCHRIFTID and t_n.REGINDEXID is not null  )',
'-- full outer JOIN cte_daten_getex3 g3 on ( g3.sc_type in ( ''All Vehicles'', ''New Types'') )',
'',
' WHERE mv.vorschriftid = :P29_VORSCHRIFTID ',
' and mv.relationtype  in ( ''LINKED_TO'')  -- story 1364',
'  --and (mv.relationtype  in ( ''SUCCESSOR'', ''LINKED_TO'', ''CHANGES'' )-- ''IS_CONSOLIDATED_IN'' --, ''CONSOLIDATES'', ',
'    --    or ( PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 and mv.relationtype  in ( ''EQUIVALENT_TO'', ''DEMANDS''))',
'   --   ) --!AB3',
' --  order by nachfolger_vorschriftID, Getex_TargetVorschrift_nummer',
'  and  (     tvrv.beziehung_art = 60)  ',
'        ----****',
'  UNION',
' -- vorschrift as vorgaenger passend',
' SELECT    ',
'     nvl(mv.reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Hauptvorschrift --Vorschrift_nummer',
'    -- , mv.relationtype                            ',
'   , nvl(mv.target_reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Verlinkte_Vorschrift --_TargetVorschrift_nummer   -- mv.sc_type, mv.sc_date ,',
'   , nvl2(t.vorschrift_nummer, concat(t.vorschrift_nummer ,  ',
'         case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl2(t.dokumentendatum, ''_''|| to_char( t.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '' '' end),',
'          ''<span class="hl">nicht vorhanden</span>'') as Regindex_Hauptvorschrift --_vorgaenger_vorschrift',
'--   , decode(tvrv.beziehung_art, 10, ''predeccessor >>successor'', 20,''Amendment'', 30, ''Supplement'', 40, ''Demands'', 102,''Equivalent'',  60, ''Linked'', ''unbekannt'') beziehung_art',
'   ,  nvl2(t_n.vorschrift_nummer, concat(t_n.vorschrift_nummer || '' '', ',
'                        case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl2(t_n.dokumentendatum, ''_''|| to_char(t_n.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '' '' end),',
'    ''<span class="hl">nicht vorhanden</span>'') AS Regindex_Verlinkte_Vorschrift --_Nachfolger_vorschrift  --    ',
'',
' FROM T_VORSCHRIFT_REF_VORSCHRIFT tvrv',
'  --full outer ',
'  JOIN cte_mv_t mv  on (  mv.vorschriftid = tvrv.Vorgaenger_Vorschriftid and mv.targ_vorschriftid = tvrv.Nachfolger_Vorschriftid) ',
'  left outer join T_VORSCHRIFT t on ( t.VORSCHRIFTID = tvrv.Vorgaenger_Vorschriftid and t.REGINDEXID is not null ) ',
'  left outer join T_VORSCHRIFT t_n on (t_n.VORSCHRIFTID = tvrv.NACHFOLGER_VORSCHRIFTID and t_n.REGINDEXID is not null  )',
'  --full outer JOIN cte_daten_getex3 g3 on ( g3.sc_type in ( ''All Vehicles'', ''New Types'') )',
' WHERE mv.vorschriftid = :P29_VORSCHRIFTID --5682 --436 --:P29_VORSCHRIFTID ',
' and mv.relationtype  in ( ''LINKED_FROM'')  -- story 1364',
'  --and mv.relationtype not in (''CONSOLIDATES'', ''IS_CONSOLIDATED_IN'', ''SUCCESSOR'',  ''EQUIVALENT_TO'',  ''CHANGES'', ''DEMANDS'', ''LINKED_TO'')',
'   and  (  tvrv.beziehung_art = 60 )',
'',
'order by  4'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1 from MV_GETEX_VORSCHRIFT_RELATION ',
'   where v_id = (select regindexid from t_vorschrift where vorschriftid= :P29_VORSCHRIFTID and regindexid is not null)',
'   and relationtype in (''LINKED_TO'', ''LINKED_FROM'')',
'   ',
' UNION',
'  SELECT  1 from t_vorschrift_ref_vorschrift ',
'   where  (vorgaenger_vorschriftid = :P29_VORSCHRIFTID or nachfolger_vorschriftid = :P29_VORSCHRIFTID)',
'   and beziehung_art in (60)'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069008717858571918)
,p_query_column_id=>1
,p_column_alias=>'GETEX_HAUPTVORSCHRIFT'
,p_column_display_sequence=>10
,p_column_heading=>'Getex Hauptvorschrift'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069008652540571917)
,p_query_column_id=>2
,p_column_alias=>'GETEX_VERLINKTE_VORSCHRIFT'
,p_column_display_sequence=>20
,p_column_heading=>'Getex Verlinkte Vorschrift'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069008553665571916)
,p_query_column_id=>3
,p_column_alias=>'REGINDEX_HAUPTVORSCHRIFT'
,p_column_display_sequence=>30
,p_column_heading=>'Regindex Hauptvorschrift'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069008432669571915)
,p_query_column_id=>4
,p_column_alias=>'REGINDEX_VERLINKTE_VORSCHRIFT'
,p_column_display_sequence=>40
,p_column_heading=>'Regindex Verlinkte Vorschrift'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1069008352589571914)
,p_name=>'Consolidates'
,p_parent_plug_id=>wwv_flow_imp.id(1069009479583571925)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  with cte_mv as ( ',
'                select  vr.V_ID, vr.vorschriftid, vr.reg_number, vr.relationtype relationtype, vr.target_reg_number target_reg_number,',
'                  vr.multigroupid, vr.successorsincluded, ',
'                    vr.sc_type, vr.targetid, min(vr.sc_date) as sc_date',
'                from MV_GETEX_VORSCHRIFT_RELATION vr ',
'                where vr.vorschriftid = :P29_VORSCHRIFTID  --5682 --436  ',
'                GROUP BY vr.V_ID, vr.vorschriftid, vr.reg_number, vr.relationtype, vr.target_reg_number, vr.sc_type, vr.targetid, ',
'                vr.multigroupid, vr.successorsincluded',
'                order by relationtype, targetid',
' ), cte_mv_t as ( ',
'                 select  t.vorschriftid targ_vorschriftid, mv.V_ID, mv.vorschriftid, mv.reg_number, mv.multigroupid, mv.successorsincluded,',
'                    mv.relationtype , mv.target_reg_number ,  mv.sc_type, mv.targetid, mv.sc_date, gv.rev_doc_datum',
'                 from cte_mv mv',
'                 join t_vorschrift t on (t.regindexid = mv.targetid)',
'                  -- 1436  geloeschte vorsch',
'                 join MV_GETEX_VORSCHRIFT gv on (gv.reg_id = t.regindexid)',
'                  where (nvl(gv.loesch_datum, sysdate +200) > sysdate) ',
' ),  cte_mv_r as (',
'                select Distinct t.vorschriftid targ_vorschriftid, vr.V_ID, vr.vorschriftid, vr.reg_number, vr.relationtype, vr.target_reg_number',
'                    , vr.multigroupid, vr.successorsincluded ',
'                from MV_GETEX_VORSCHRIFT_RELATION vr ',
'                join t_vorschrift t on (t.regindexid = vr.targetid)',
'                 -- 1436  geloeschte vorsch',
'                 join MV_GETEX_VORSCHRIFT gv on (gv.reg_id = vr.V_ID)',
'                  where (nvl(gv.loesch_datum, sysdate +200) > sysdate)',
'                  -- \\\\',
'                and t.vorschriftid =  :P29_VORSCHRIFTID  --5682 --436',
' )',
' --/////',
' SELECT  --- nur in Regindex als Vorgaenger oder nachfolger, nicht in  GETEX        --nachf 25701',
'     ''<span class="hl">nicht vorhanden</span>'' AS Getex_Konsolidierte_Vorschrift --_TargetVorschrift_nummer   -- mv.sc_type, mv.sc_date ,',
'   --, ''<span class="hl">nicht vorhanden</span>'' as relationtype   -- nvl(vr.vorschriftid, 0) AS GetexVorschriftID, vr.V_ID Getex_ID,',
'   , ''<span class="hl">nicht vorhanden</span>'' AS Getex_Konsolidierende_Vorschrift --Vorschrift_nummer,',
'   , nvl2(t.vorschrift_nummer, concat(t.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja'' then nvl(to_char(t.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end), ',
'                    ''<span class="hl">nicht vorhanden</span>'') as Regindex_Konsolidierte_Vorschrift --_vorgaenger_vorschrift',
'   -- , decode(tvrv.beziehung_art, 10, ''predeccessor >>successor'', 20, ''Amendment'',  30, ''Supplement'',  40, ''Demands'', 102,''Equivalent'',  60, ''Linked'', ''unbekannt'') beziehung_art',
'    , nvl2(t_n.Vorschrift_nummer, concat(t_n.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t_n.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end), ',
'                    ''<span class="hl">nicht vorhanden</span>'') AS Regindex_Konsolidierende_Vorschrift --_nachfolger_vorschrift ',
'',
' FROM t_vorschrift_ref_vorschrift tvrv ',
'  left outer join T_VORSCHRIFT t on ( t.VORSCHRIFTID = tvrv.Vorgaenger_Vorschriftid )    --and t.REGINDEXID is not null  )',
'    left outer join T_VORSCHRIFT t_n on (t_n.VORSCHRIFTID = tvrv.NACHFOLGER_VORSCHRIFTID )  -- and t_n.REGINDEXID is not null  )',
'    where  (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 OR  tvrv.beziehung_art not in (40,102))  --AB2!',
'     and tvrv.beziehung_art = 200 -- ( story 1364)',
'     and',
'    (',
'        ( tvrv.vorgaenger_vorschriftid = :P29_VORSCHRIFTID ',
'           and tvrv.nachfolger_vorschriftid not in ( select targ_vorschriftid from cte_mv_t mv where -- vorschriftid =436',
'                                ( mv.relationtype = ''IS_CHANGED_BY'' and (( instr(upper(mv.target_reg_number),''UN-R'')=1 and tvrv.beziehung_art =30) or  tvrv.beziehung_art =20 ) ',
'                                   OR tvrv.beziehung_art = decode(mv.relationtype, ''PREDECESSOR'', 10,  ''LINKED_FROM'', 60, ''IS_CONSOLIDATED_IN'', 200, 0 )',
'                                    OR  (tvrv.beziehung_art = decode(mv.relationtype, ''IS_DEMANDED_BY'', 40,  ',
'                                             ''SEEN_AS_EQUIVALENT_BY'', 102,  0 ) ',
'                                           and  (mv.multigroupid is null or (mv.multigroupid is not null and (nvl(mv.successorsincluded, ''false'') = ''true'')))',
'                                    )',
'                                )  ',
'                            )',
'        ) ',
'',
'        OR     ',
'        ( tvrv.nachfolger_vorschriftid = :P29_VORSCHRIFTID',
'            and tvrv.vorgaenger_vorschriftid not in ( select vorschriftid  from cte_mv_r mr   where ',
'                            (  mr.relationtype = ''IS_CHANGED_BY'' and ( instr(upper(mr.reg_number),''UN-R'')=1 and tvrv.beziehung_art =30 or  tvrv.beziehung_art =20 ) ',
'                                OR tvrv.beziehung_art = decode(mr.relationtype, ''PREDECESSOR'' , 10,  ''LINKED_FROM'', 60, ''IS_CONSOLIDATED_IN'', 200, 0 )',
'                                OR  (  tvrv.beziehung_art = decode(mr.relationtype, ''IS_DEMANDED_BY'', 40,   ',
'                                             ''SEEN_AS_EQUIVALENT_BY'', 102,    0  )',
'                                      and  (mr.multigroupid is null or (mr.multigroupid is not null and (nvl(mr.successorsincluded, ''false'') = ''true'')))',
'                                )',
'                            ) ',
'                        )',
'        )',
'    )                  ',
'                 ',
'',
' UNION',
'',
'  --///// nur in GETEX als Nachfolger von , nicht in Regindex',
' SELECT ',
'    nvl2(mv.target_reg_number,  concat( mv.target_reg_number || '' '' , ',
'                           case when :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(mv.rev_doc_datum ,''dd.mm.yyyy'' ), '''')  else '''' end ),',
'                          ''<span class="hl">nicht vorhanden</span>'') AS Getex_Konsolidierte_Vorschrift --_TargetVorschrift_nummer',
'  -- , mv.relationtype   -- nvl(vr.vorschriftid, 0) AS GetexVorschriftID, vr.V_ID Getex_ID,',
'   , nvl(mv.reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Konsolidierende_Vorschrift --Vorschrift_nummer,',
'    ,  ''<span class="hl">nicht vorhanden</span>'' as Regindex_Konsolidierte_Vorschrift --_vorgaenger_vorschrift',
'  --  , '''' beziehung_art',
'    ,  ''<span class="hl">nicht vorhanden</span>'' AS Regindex_Konsolidierende_Vorschrift --_nachfolger_vorschrift ',
' ',
' from  cte_mv_t mv',
' where  mv.relationtype in (''CONSOLIDATES'', ''IS_CONSOLIDATED_IN'') -- story 1364',
'  and (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 OR mv.relationtype  not in ( ',
'            ''IS_DEMANDED_BY'', ''SEEN_AS_EQUIVALENT_BY'',   ''DEMANDS'', ''EQUIVALENT_TO''))  --// AB! hide',
'   and (nvl(mv.successorsincluded, ''false'') = ''true'' or mv.multigroupid is  null)',
'   and mv.Vorschriftid not in ( select tvrv.nachfolger_vorschriftid from t_vorschrift_ref_vorschrift tvrv',
'                                where tvrv.vorgaenger_vorschriftid = mv.targ_vorschriftid ',
'                                  and  ( mv.relationtype= ''CHANGES'' and ( instr(upper(mv.target_reg_number),''UN-R'')=1 and tvrv.beziehung_art =30 or  tvrv.beziehung_art =20 )',
'                                          OR  tvrv.beziehung_art = decode(mv.relationtype,  ''SUCCESSOR'', 10,  ''LINKED_TO'', 60, ''CONSOLIDATES'', 200, 0  )',
'',
'                                          OR  ( tvrv.beziehung_art = decode(mv.relationtype, ''DEMANDS'', 40,  ''EQUIVALENT_TO'', 102,   0  )',
'                                              and (nvl(mv.successorsincluded, ''false'') = ''false''  and mv.multigroupid is Not null)',
'                                          )',
'                                          OR  (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 and tvrv.beziehung_art = decode(mv.relationtype, ''IS_DEMANDED_BY'', 40,   ',
'                                             ''SEEN_AS_EQUIVALENT_BY'', 102,    0  )',
'                                          )',
'                                   ) ',
'                               )',
'    --//---- andere verkn. in regindex, wo P29_VORSCHRIFTID als Nachfolger,  nicht mitnehmen',
'  and mv.Vorschriftid not in (select tvrv.nachfolger_vorschriftid from t_vorschrift_ref_vorschrift tvrv',
'                                where tvrv.vorgaenger_vorschriftid = mv.targ_vorschriftid',
'                                and ( mv.relationtype= ''IS_CHANGED_BY'' and ( instr(upper(mv.target_reg_number),''UN-R'')=1 and tvrv.beziehung_art =30 or  tvrv.beziehung_art =20 )',
'                                        OR tvrv.beziehung_art = decode(mv.relationtype, ''PREDECESSOR'' , 10, ''LINKED_FROM'', 60, ''IS_CONSOLIDATED_IN'', 200, 0 )',
'                                    ',
'                                        OR  (tvrv.beziehung_art = decode(mv.relationtype, ''IS_DEMANDED_BY'', 40, ''SEEN_AS_EQUIVALENT_BY'', 102,   0  )',
'                                        )',
'                                        OR  (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 and  tvrv.beziehung_art = decode(mv.relationtype, ''DEMANDS'', 40, ',
'                                             ''EQUIVALENT_TO'', 102,    0  )',
'                                        )',
'                                    ) ',
'                                )',
'     --\\\\',
'  -- andere verkn. in regindex, wo P29_VORSCHRIFTID als Vorgaenger  nicht mitnehmen',
'  and mv.Vorschriftid not in (select tvrv.vorgaenger_vorschriftid from t_vorschrift_ref_vorschrift tvrv',
'                                where tvrv.nachfolger_vorschriftid = mv.targ_vorschriftid ',
'                                and (mv.relationtype= ''IS_CHANGED_BY'' and ( instr(upper(mv.reg_number),''UN-R'')=1 and tvrv.beziehung_art =30 or  tvrv.beziehung_art =20 )',
'                                    OR tvrv.beziehung_art = decode(mv.relationtype, ''PREDECESSOR'' , 10,    ''LINKED_FROM'', 60, ''IS_CONSOLIDATED_IN'', 200, 0 )',
'                                    OR  (tvrv.beziehung_art = decode(mv.relationtype, ''IS_DEMANDED_BY'', 40,  ''SEEN_AS_EQUIVALENT_BY'', 102,  0 )',
'                                    )',
'                                    OR  ( PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 and tvrv.beziehung_art = decode(mv.relationtype, ''DEMANDS'', 40,  ',
'                                             ''EQUIVALENT_TO'', 102,   0  )',
'                                    )',
'                                ) ',
'                            )  -- for 436',
' ',
'  UNION',
'  ',
'--\\\',
' ',
' -- -- vorschr as nachfolger  exact passend',
'  -- keine DEMANDS',
'   SELECT DISTINCT     nvl(mv.target_reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Konsolidierte_Vorschrift   -- mv.sc_type, mv.sc_date ,',
'   -- , mv.relationtype   -- nvl(vr.vorschriftid, 0) AS GetexVorschriftID, vr.V_ID Getex_ID,',
'  , nvl(mv.reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Konsolidierende_Vorschrift --_nummer',
'   , nvl2(t.vorschrift_nummer,  concat(t.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end),',
'                      ''<span class="hl">nicht vorhanden</span>'') as Regindex_Konsolidierte_Vorschrift --vorgaenger_vorschrift',
'  --  , decode(tvrv.beziehung_art, 10, ''predeccessor >>successor'', 20, ''Amendment'', 30, ''Supplement'', 40, ''Demands'', 102,''Equivalent'',  60, ''Linked'', ''unbekannt'') beziehung_art',
'    , nvl2(t_n.Vorschrift_nummer,  concat(t_n.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t_n.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end),',
'                       ''<span class="hl">nicht vorhanden</span>'') AS Regindex_Konsolidierende_Vorschrift --_nachfolger_vorschrift',
'   -- , tvrv.datum_alle_typen, tvrv.datum_neue_typen ',
'',
' FROM  T_VORSCHRIFT_REF_VORSCHRIFT tvrv',
' full outer JOIN cte_mv_t mv on ( mv.vorschriftid = tvrv.Nachfolger_Vorschriftid and tvrv.Vorgaenger_vorschriftid = mv.targ_vorschriftid )',
' left outer join T_VORSCHRIFT t on ( t.VORSCHRIFTID = tvrv.Vorgaenger_Vorschriftid and t.REGINDEXID is not null  ) ',
' left outer join T_VORSCHRIFT t_n on (t_n.VORSCHRIFTID = tvrv.NACHFOLGER_VORSCHRIFTID and t_n.REGINDEXID is not null  )',
'-- full outer JOIN cte_daten_getex3 g3 on ( g3.sc_type in ( ''All Vehicles'', ''New Types'') )',
'',
' WHERE mv.vorschriftid = :P29_VORSCHRIFTID ',
' and mv.relationtype  in ( ''CONSOLIDATES'')  ',
'  and  (  tvrv.beziehung_art =  200  )  ',
'        ----****',
'  UNION',
' -- vorschrift as vorgaenger passend',
' SELECT    ',
'     nvl(mv.reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Konsolidierte_Vorschrift --Vorschrift_nummer',
'    -- , mv.relationtype                            ',
'   , nvl(mv.target_reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Konsolidierende_Vorschrift --_TargetVorschrift_nummer   -- mv.sc_type, mv.sc_date ,',
'   , nvl2(t.vorschrift_nummer,  concat(t.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end), ',
'                            ''<span class="hl">nicht vorhanden</span>'') as Regindex_Konsolidierte_Vorschrift --_vorgaenger_vorschrift',
'--   , decode(tvrv.beziehung_art, 10, ''predeccessor >>successor'', 20,''Amendment'', 30, ''Supplement'', 40, ''Demands'', 102,''Equivalent'',  60, ''Linked'', ''unbekannt'') beziehung_art',
'   ,  nvl2(t_n.Vorschrift_nummer,  concat(t_n.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t_n.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end),',
'                               ''<span class="hl">nicht vorhanden</span>'') AS Regindex_Konsolidierende_Vorschrift --_Nachfolger_vorschrift  --    ',
'',
' FROM T_VORSCHRIFT_REF_VORSCHRIFT tvrv',
'  --full outer ',
'  JOIN cte_mv_t mv  on (  mv.vorschriftid = tvrv.Vorgaenger_Vorschriftid and mv.targ_vorschriftid = tvrv.Nachfolger_Vorschriftid) ',
'  left outer join T_VORSCHRIFT t on ( t.VORSCHRIFTID = tvrv.Vorgaenger_Vorschriftid and t.REGINDEXID is not null ) ',
'  left outer join T_VORSCHRIFT t_n on (t_n.VORSCHRIFTID = tvrv.NACHFOLGER_VORSCHRIFTID and t_n.REGINDEXID is not null  )',
'  --full outer JOIN cte_daten_getex3 g3 on ( g3.sc_type in ( ''All Vehicles'', ''New Types'') )',
' WHERE mv.vorschriftid = :P29_VORSCHRIFTID --5682 --436 --:P29_VORSCHRIFTID ',
' and mv.relationtype  in ( ''IS_CONSOLIDATED_IN'')  -- story 1364',
'   and  (  tvrv.beziehung_art =  200   )',
'',
'order by  4'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1 from MV_GETEX_VORSCHRIFT_RELATION ',
'   where v_id = (select regindexid from t_vorschrift where vorschriftid= :P29_VORSCHRIFTID and regindexid is not null)',
'   and relationtype in (''IS_CONSOLIDATED_IN'', ''CONSOLIDATES'')',
'   ',
' UNION',
'  SELECT  1 from t_vorschrift_ref_vorschrift ',
'   where  (vorgaenger_vorschriftid = :P29_VORSCHRIFTID or nachfolger_vorschriftid = :P29_VORSCHRIFTID)',
'   and beziehung_art in (200)'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069008290632571913)
,p_query_column_id=>1
,p_column_alias=>'GETEX_KONSOLIDIERTE_VORSCHRIFT'
,p_column_display_sequence=>10
,p_column_heading=>'Getex Konsolidierte Vorschrift'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069008150444571912)
,p_query_column_id=>2
,p_column_alias=>'GETEX_KONSOLIDIERENDE_VORSCHRIFT'
,p_column_display_sequence=>20
,p_column_heading=>'Getex Konsolidierende Vorschrift'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069008030088571911)
,p_query_column_id=>3
,p_column_alias=>'REGINDEX_KONSOLIDIERTE_VORSCHRIFT'
,p_column_display_sequence=>30
,p_column_heading=>'Regindex Konsolidierte Vorschrift'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069007959813571910)
,p_query_column_id=>4
,p_column_alias=>'REGINDEX_KONSOLIDIERENDE_VORSCHRIFT'
,p_column_display_sequence=>40
,p_column_heading=>'Regindex Konsolidierende Vorschrift'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1069007867244571909)
,p_name=>'Amendment/Supplement'
,p_parent_plug_id=>wwv_flow_imp.id(1069009479583571925)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with   cte_mv as ( ',
'                select  vr.V_ID, vr.vorschriftid, vr.reg_number, vr.relationtype relationtype, vr.target_reg_number target_reg_number,',
'                  vr.multigroupid, vr.successorsincluded, ',
'                    vr.sc_type, vr.targetid, min(vr.sc_date) as sc_date',
'                from MV_GETEX_VORSCHRIFT_RELATION vr ',
'                where vr.vorschriftid = :P29_VORSCHRIFTID  --5682 --436  ',
'                GROUP BY vr.V_ID, vr.vorschriftid, vr.reg_number, vr.relationtype, vr.target_reg_number, vr.sc_type, vr.targetid, ',
'                vr.multigroupid, vr.successorsincluded',
'                order by relationtype, targetid',
' ), cte_mv_t as ( ',
'                 select  t.vorschriftid targ_vorschriftid, mv.V_ID, mv.vorschriftid, mv.reg_number, mv.multigroupid, mv.successorsincluded,',
'                    mv.relationtype , mv.target_reg_number ,  mv.sc_type, mv.targetid, mv.sc_date, gv.rev_doc_datum',
'                 from cte_mv mv',
'                 join t_vorschrift t on (t.regindexid = mv.targetid)',
'                 -- 1436  geloeschte vorsch',
'                 join MV_GETEX_VORSCHRIFT gv on (gv.reg_id = t.regindexid)',
'                  where (nvl(gv.loesch_datum, sysdate +200) > sysdate) ',
' ),  cte_mv_r as (',
'                select Distinct t.vorschriftid targ_vorschriftid, vr.V_ID, vr.vorschriftid, vr.reg_number, vr.relationtype, vr.target_reg_number',
'                    , vr.multigroupid, vr.successorsincluded ',
'                from MV_GETEX_VORSCHRIFT_RELATION vr ',
'                join t_vorschrift t on (t.regindexid = vr.targetid) ',
'                -- 1436  geloeschte vorsch',
'                 join MV_GETEX_VORSCHRIFT gv on (gv.reg_id = vr.V_ID)',
'                  where (nvl(gv.loesch_datum, sysdate +200) > sysdate)',
'                  -- \\\\',
'                and t.vorschriftid =  :P29_VORSCHRIFTID  --5682 --436',
' )',
' --/////',
' SELECT  --- nur in Regindex als Vorgaenger oder nachfolger, nicht in  GETEX        --nachf 25701',
'     ''<span class="hl">nicht vorhanden</span>'' AS Getex_Hauptvorschrift --_TargetVorschrift_nummer   -- mv.sc_type, mv.sc_date ,',
'   --, ''<span class="hl">nicht vorhanden</span>'' as relationtype   -- nvl(vr.vorschriftid, 0) AS GetexVorschriftID, vr.V_ID Getex_ID,',
'   , ''<span class="hl">nicht vorhanden</span>'' AS Getex_Nachfolger_Vorschrift --Vorschrift_nummer,',
'   , nvl2(t.vorschrift_nummer, concat(t.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end), ',
'                    ''<span class="hl">nicht vorhanden</span>'') as Regindex_Hauptvorschrift --_vorgaenger_vorschrift',
'   -- , decode(tvrv.beziehung_art, 10, ''predeccessor >>successor'', 20, ''Amendment'',  30, ''Supplement'',  40, ''Demands'', 102,''Equivalent'',  60, ''Linked'', ''unbekannt'') beziehung_art',
'    , nvl2(t_n.Vorschrift_nummer, concat(t_n.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t_n.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end), ',
'                    ''<span class="hl">nicht vorhanden</span>'') AS Regindex_Nachfolger_Vorschrift --_nachfolger_vorschrift ',
'   , case --when (mv.target_reg_number is null ) then ''''',
'           when (tvrv.beziehung_art =30) then ''Supplement'' else ''Amendment'' END as Beziehung_art',
' FROM t_vorschrift_ref_vorschrift tvrv ',
'  left outer join T_VORSCHRIFT t on ( t.VORSCHRIFTID = tvrv.Vorgaenger_Vorschriftid )    --and t.REGINDEXID is not null  )',
'    left outer join T_VORSCHRIFT t_n on (t_n.VORSCHRIFTID = tvrv.NACHFOLGER_VORSCHRIFTID )  -- and t_n.REGINDEXID is not null  )',
'    where  (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 OR  tvrv.beziehung_art not in (40,102))  --AB2!',
'     and ',
'        tvrv.beziehung_art in (20, 30) -- ( story 1364)',
'     and',
'    (',
'        ( tvrv.vorgaenger_vorschriftid = :P29_VORSCHRIFTID ',
'           and tvrv.nachfolger_vorschriftid not in ( select targ_vorschriftid from cte_mv_t mv where -- vorschriftid =436',
'                                ( mv.relationtype = ''IS_CHANGED_BY'' and (( instr(upper(mv.target_reg_number),''UN-R'')=1 and tvrv.beziehung_art =30) or  tvrv.beziehung_art =20 ) ',
'                                   --OR tvrv.beziehung_art = decode(mv.relationtype, ''PREDECESSOR'' , 10,      ''LINKED_FROM'', 60, ''IS_CONSOLIDATED_IN'', 200, 0 )',
'                                   -- OR  (tvrv.beziehung_art = decode(mv.relationtype, ''IS_DEMANDED_BY'', 40,  ',
'                                   --          ''SEEN_AS_EQUIVALENT_BY'', 102,   0  ) ',
'                                   --        and  (mv.multigroupid is null or (mv.multigroupid is not null and (nvl(mv.successorsincluded, ''false'') = ''true'')))',
'                                   -- )',
'                                )  ',
'                            )',
'        ) ',
'',
'        OR     ',
'        ( tvrv.nachfolger_vorschriftid = :P29_VORSCHRIFTID',
'            and tvrv.vorgaenger_vorschriftid not in ( select vorschriftid  from cte_mv_r mr   where ',
'                            (  mr.relationtype = ''IS_CHANGED_BY'' and ( instr(upper(mr.reg_number),''UN-R'')=1 and tvrv.beziehung_art =30 or  tvrv.beziehung_art =20 ) ',
'                                OR tvrv.beziehung_art = decode(mr.relationtype, ''PREDECESSOR'' , 10,   ''LINKED_FROM'', 60, ''IS_CONSOLIDATED_IN'', 200, 0 )',
'                                OR  (  tvrv.beziehung_art = decode(mr.relationtype, ''IS_DEMANDED_BY'', 40,   ',
'                                             ''SEEN_AS_EQUIVALENT_BY'', 102,    0  )',
'                                      and  (mr.multigroupid is null or (mr.multigroupid is not null and (nvl(mr.successorsincluded, ''false'') = ''true'')))',
'                                )',
'                            ) ',
'                        )',
'        )',
'    )                  ',
'                 ',
'',
' UNION',
'',
'  --///// nur in GETEX als Nachfolger von , nicht in Regindex',
' SELECT ',
'    nvl2(mv.target_reg_number,  concat( mv.target_reg_number || '' '' , ',
'                           case when :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(mv.rev_doc_datum ,''dd.mm.yyyy'' ), '''')  else '''' end ),',
'                          ''<span class="hl">nicht vorhanden</span>'') AS Getex_Hauptvorschrift --_TargetVorschrift_nummer',
'   --, mv.relationtype   -- nvl(vr.vorschriftid, 0) AS GetexVorschriftID, vr.V_ID Getex_ID,',
'   , nvl(mv.reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Nachfolger_Vorschrift --Vorschrift_nummer,',
'    ,  ''<span class="hl">nicht vorhanden</span>'' as Regindex_Hauptvorschrift --_vorgaenger_vorschrift',
'  --  , '''' beziehung_art',
'    ,  ''<span class="hl">nicht vorhanden</span>'' AS Regindex_Nachfolger_Vorschrift --_nachfolger_vorschrift ',
'   , case when (mv.target_reg_number is null ) then ''''',
'           when (instr(upper(mv.target_reg_number),''UN-R'')=1 ) then ''Supplement'' else ''Amendment'' END as Beziehung_art',
' from  cte_mv_t mv',
' where  mv.relationtype in (''CHANGES'', ''IS_CHANGED_BY'') -- story 1364',
' -- and (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 OR mv.relationtype  not in ( ',
'  --          ''IS_DEMANDED_BY'', ''SEEN_AS_EQUIVALENT_BY'',   ''DEMANDS'', ''EQUIVALENT_TO''))  --// AB! hide',
'  --and (nvl(mv.successorsincluded, ''false'') = ''true'' or mv.multigroupid is  null)',
'   and mv.Vorschriftid not in ( select tvrv.nachfolger_vorschriftid from t_vorschrift_ref_vorschrift tvrv',
'                                where tvrv.vorgaenger_vorschriftid = mv.targ_vorschriftid ',
'                                  and  ( mv.relationtype= ''CHANGES'' and ( instr(upper(mv.target_reg_number),''UN-R'')=1 and tvrv.beziehung_art =30 or  tvrv.beziehung_art =20 )',
'',
'                                   ) ',
'                               )',
'    --//---- andere verkn. in regindex, wo P29_VORSCHRIFTID als Nachfolger,  nicht mitnehmen',
'  and mv.Vorschriftid not in (select tvrv.nachfolger_vorschriftid from t_vorschrift_ref_vorschrift tvrv',
'                                where tvrv.vorgaenger_vorschriftid = mv.targ_vorschriftid',
'                                and ( mv.relationtype= ''IS_CHANGED_BY'' and ( instr(upper(mv.target_reg_number),''UN-R'')=1 and tvrv.beziehung_art =30 or  tvrv.beziehung_art =20 )',
'',
'                                    ) ',
'                                )',
'     --\\\\',
'  -- andere verkn. in regindex, wo P29_VORSCHRIFTID als Vorgaenger  nicht mitnehmen',
'  and mv.Vorschriftid not in ( select tvrv.vorgaenger_vorschriftid from t_vorschrift_ref_vorschrift tvrv',
'                                where tvrv.nachfolger_vorschriftid = mv.targ_vorschriftid ',
'                                and (mv.relationtype= ''IS_CHANGED_BY'' and ( instr(upper(mv.reg_number),''UN-R'')=1 and tvrv.beziehung_art =30 or  tvrv.beziehung_art =20 )',
'',
'                                ) ',
'                            )  -- for 436',
' ',
'  UNION',
'  ',
'--\\\',
' ',
' -- -- vorschr as nachfolger  exact passend',
'  -- keine DEMANDS',
'   SELECT DISTINCT     nvl(mv.target_reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Hauptvorschrift   -- mv.sc_type, mv.sc_date ,',
'   -- , mv.relationtype   -- nvl(vr.vorschriftid, 0) AS GetexVorschriftID, vr.V_ID Getex_ID,',
'  , nvl(mv.reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Nachfolger_Vorschrift --_nummer',
'   , nvl2(t.vorschrift_nummer,  concat(t.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end), ',
'                                  ''<span class="hl">nicht vorhanden</span>'') as Regindex_Hauptvorschrift --vorgaenger_vorschrift',
'  --  , decode(tvrv.beziehung_art, 10, ''predeccessor >>successor'', 20, ''Amendment'', 30, ''Supplement'', 40, ''Demands'', 102,''Equivalent'',  60, ''Linked'', ''unbekannt'') beziehung_art',
'    , nvl2(t_n.Vorschrift_nummer,  concat(t_n.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t_n.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end),',
'                                  ''<span class="hl">nicht vorhanden</span>'') AS Regindex_Nachfolger_Vorschrift --_nachfolger_vorschrift',
'    , case when (mv.target_reg_number is null ) then ''''',
'          when (instr(upper(mv.target_reg_number),''UN-R'')=1 and tvrv.beziehung_art =30) then ''Supplement'' else ''Amendment'' END as Beziehung_art',
'   ',
'',
' FROM  T_VORSCHRIFT_REF_VORSCHRIFT tvrv',
' full outer JOIN cte_mv_t mv on ( mv.vorschriftid = tvrv.Nachfolger_Vorschriftid and tvrv.Vorgaenger_vorschriftid = mv.targ_vorschriftid )',
' left outer join T_VORSCHRIFT t on ( t.VORSCHRIFTID = tvrv.Vorgaenger_Vorschriftid and t.REGINDEXID is not null  ) ',
' left outer join T_VORSCHRIFT t_n on (t_n.VORSCHRIFTID = tvrv.NACHFOLGER_VORSCHRIFTID and t_n.REGINDEXID is not null  )',
'',
'',
' WHERE mv.vorschriftid = :P29_VORSCHRIFTID ',
' and mv.relationtype  in ( ''CHANGES'') ',
' --  order by nachfolger_vorschriftID, Getex_TargetVorschrift_nummer',
'  and  ( mv.relationtype= ''CHANGES'' and ( (instr(upper(mv.target_reg_number),''UN-R'')=1 and tvrv.beziehung_art =30) or  tvrv.beziehung_art =20 ) ',
'       )  ',
'        ----****',
'  UNION',
' -- vorschrift as vorgaenger passend',
' SELECT    ',
'     nvl(mv.reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Hauptvorschrift --Vorschrift_nummer',
'    -- , mv.relationtype                            ',
'   , nvl(mv.target_reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Nachfolger_Vorschrift --_TargetVorschrift_nummer   -- mv.sc_type, mv.sc_date ,',
'   , nvl2(t.vorschrift_nummer,  concat(t.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end),',
'                          ''<span class="hl">nicht vorhanden</span>'') as Regindex_Hauptvorschrift --_vorgaenger_vorschrift',
'--   , decode(tvrv.beziehung_art, 10, ''predeccessor >>successor'', 20,''Amendment'', 30, ''Supplement'', 40, ''Demands'', 102,''Equivalent'',  60, ''Linked'', ''unbekannt'') beziehung_art',
'   ,  nvl2(t_n.Vorschrift_nummer,  concat(t_n.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t_n.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end),',
'                           ''<span class="hl">nicht vorhanden</span>'') AS Regindex_Nachfolger_Vorschrift --_Nachfolger_vorschrift  --    ',
'    , case when (mv.target_reg_number is null ) then ''''',
'          when (instr(upper(mv.target_reg_number),''UN-R'')=1 and tvrv.beziehung_art =30) then ''Supplement'' else ''Amendment'' END as Beziehung_art',
' ',
' FROM T_VORSCHRIFT_REF_VORSCHRIFT tvrv',
'  --full outer ',
'  JOIN cte_mv_t mv  on (  mv.vorschriftid = tvrv.Vorgaenger_Vorschriftid and mv.targ_vorschriftid = tvrv.Nachfolger_Vorschriftid) ',
'  left outer join T_VORSCHRIFT t on ( t.VORSCHRIFTID = tvrv.Vorgaenger_Vorschriftid and t.REGINDEXID is not null ) ',
'  left outer join T_VORSCHRIFT t_n on (t_n.VORSCHRIFTID = tvrv.NACHFOLGER_VORSCHRIFTID and t_n.REGINDEXID is not null  )',
'  ',
' WHERE mv.vorschriftid = :P29_VORSCHRIFTID --5682 --436 --:P29_VORSCHRIFTID ',
' and mv.relationtype  in ( ''IS_CHANGED_BY'')  -- story 1364',
'  --and mv.relationtype not in (''CONSOLIDATES'', ''IS_CONSOLIDATED_IN'', ''SUCCESSOR'',  ''EQUIVALENT_TO'',  ''CHANGES'', ''DEMANDS'', ''LINKED_TO'')',
'   and ( (instr(upper(mv.reg_number),''UN-R'')=1 and tvrv.beziehung_art =30) or  tvrv.beziehung_art =20 )  ',
'        ',
'',
'order by  4'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
' SELECT 1 from MV_GETEX_VORSCHRIFT_RELATION ',
'   where v_id = (select regindexid from t_vorschrift where vorschriftid= :P29_VORSCHRIFTID and regindexid is not null)',
'   and relationtype in (''CHANGES'', ''IS_CHANGED_BY'')',
'   ',
' UNION',
'  SELECT  1 from t_vorschrift_ref_vorschrift ',
'   where  (vorgaenger_vorschriftid = :P29_VORSCHRIFTID or nachfolger_vorschriftid = :P29_VORSCHRIFTID)',
'   and beziehung_art in (20,30)'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069007717715571908)
,p_query_column_id=>1
,p_column_alias=>'GETEX_HAUPTVORSCHRIFT'
,p_column_display_sequence=>10
,p_column_heading=>'Getex Hauptvorschrift'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069007652572571907)
,p_query_column_id=>2
,p_column_alias=>'GETEX_NACHFOLGER_VORSCHRIFT'
,p_column_display_sequence=>20
,p_column_heading=>'Getex Nachfolger Vorschrift'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069007562611571906)
,p_query_column_id=>3
,p_column_alias=>'REGINDEX_HAUPTVORSCHRIFT'
,p_column_display_sequence=>30
,p_column_heading=>'Regindex Hauptvorschrift'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069007484282571905)
,p_query_column_id=>4
,p_column_alias=>'REGINDEX_NACHFOLGER_VORSCHRIFT'
,p_column_display_sequence=>40
,p_column_heading=>'Regindex Nachfolger Vorschrift'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069007395100571904)
,p_query_column_id=>5
,p_column_alias=>'BEZIEHUNG_ART'
,p_column_display_sequence=>50
,p_column_heading=>'Beziehung Art'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1069007293628571903)
,p_name=>'Equivalent'
,p_parent_plug_id=>wwv_flow_imp.id(1069009479583571925)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- equivalent',
'-- equivalent',
'with ',
' cte_mv as ( ',
'                select  vr.V_ID, vr.vorschriftid, vr.reg_number, vr.relationtype relationtype, vr.target_reg_number target_reg_number,',
'                  vr.multigroupid, vr.successorsincluded, ',
'                    vr.sc_type, vr.targetid, min(vr.sc_date) as sc_date',
'                from MV_GETEX_VORSCHRIFT_RELATION vr ',
'                where vr.vorschriftid = :P29_VORSCHRIFTID  --5682 --436  ',
'                GROUP BY vr.V_ID, vr.vorschriftid, vr.reg_number, vr.relationtype, vr.target_reg_number, vr.sc_type, vr.targetid, ',
'                vr.multigroupid, vr.successorsincluded',
'                order by relationtype, targetid',
' ), cte_mv_t as ( ',
'                 select  t.vorschriftid targ_vorschriftid, mv.V_ID, mv.vorschriftid, mv.reg_number, mv.multigroupid, mv.successorsincluded,',
'                    mv.relationtype , mv.target_reg_number ,  mv.sc_type, mv.targetid, mv.sc_date, gv.rev_doc_datum',
'                 from cte_mv mv',
'                 join t_vorschrift t on (t.regindexid = mv.targetid)',
'                 -- 1436  geloeschte vorsch',
'                 join MV_GETEX_VORSCHRIFT gv on (gv.reg_id = t.regindexid)',
'                  where (nvl(gv.loesch_datum, sysdate +200) > sysdate) ',
' ),  cte_mv_r as (',
'                select Distinct t.vorschriftid targ_vorschriftid, vr.V_ID, vr.vorschriftid, vr.reg_number, vr.relationtype, vr.target_reg_number',
'                    , vr.multigroupid, vr.successorsincluded ',
'                from MV_GETEX_VORSCHRIFT_RELATION vr ',
'                join t_vorschrift t on (t.regindexid = vr.targetid) ',
'                -- 1436  geloeschte vorsch',
'                 join MV_GETEX_VORSCHRIFT gv on (gv.reg_id = vr.V_ID)',
'                  where (nvl(gv.loesch_datum, sysdate +200) > sysdate)',
'                  -- \\\\',
'                and  t.vorschriftid =  :P29_VORSCHRIFTID  --5682 --436',
' )',
'',
' --/////',
' SELECT  --- nur in Regindex als Vorgaenger oder nachfolger, nicht in  GETEX        --nachf 25701',
'  ''<span class="hl">nicht vorhanden</span>'' AS Getex_Hauptvorschrift --Vorschrift_nummer,',
'   ',
'   ,  ''<span class="hl">nicht vorhanden</span>'' AS Getex_Equivalant_Vorschrift --TargetVorschrift_nummer   -- mv.sc_type, mv.sc_date ,',
'    , nvl2(t.vorschrift_nummer, concat(t.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end), ',
'                    ''<span class="hl">nicht vorhanden</span>'') as Regindex_Hauptvorschrift --vorgaenger_vorschrift',
'   ',
'    , nvl2(t_n.Vorschrift_nummer, concat(t_n.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t_n.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end), ',
'                    ''<span class="hl">nicht vorhanden</span>'') AS Regindex_Equivalant_Vorschrift --nachfolger_vorschrift ',
'    , '''' as Getex_homologation_mit_hohere_serie',
'    , case when nvl(tvrv.homologation_serie, 0) = 10 then ''Ja'' ',
'          -- when tvrv.beziehung_art not in (120, 40) then  '''' ',
'           else ''Nein'' end as Regindex_homologation_mit_hohere_serie ',
'',
' FROM t_vorschrift_ref_vorschrift tvrv ',
'  left outer join T_VORSCHRIFT t on ( t.VORSCHRIFTID = tvrv.Vorgaenger_Vorschriftid )    --and t.REGINDEXID is not null  )',
'    left outer join T_VORSCHRIFT t_n on (t_n.VORSCHRIFTID = tvrv.NACHFOLGER_VORSCHRIFTID )  -- and t_n.REGINDEXID is not null  )',
'    where  (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 OR  tvrv.beziehung_art not in (40,102))  --AB2!',
'     and tvrv.beziehung_art = 102 -- ( story 1364)',
'     and',
'    (',
'        ( tvrv.vorgaenger_vorschriftid = :P29_VORSCHRIFTID ',
'           and tvrv.nachfolger_vorschriftid not in ( select targ_vorschriftid from cte_mv_t mv where -- vorschriftid =436',
'                                (  (tvrv.beziehung_art = decode(mv.relationtype, ''IS_DEMANDED_BY'', 40, ''SEEN_AS_EQUIVALENT_BY'', 102, 0 ) ',
'                                           and  (mv.multigroupid is null or (mv.multigroupid is not null and (nvl(mv.successorsincluded, ''false'') = ''true'')))',
'                                    )',
'                                )  ',
'                            )',
'        ) ',
'',
'        OR     ',
'        ( tvrv.nachfolger_vorschriftid = :P29_VORSCHRIFTID',
'            and tvrv.vorgaenger_vorschriftid not in ( select vorschriftid  from cte_mv_r mr   where ',
'                            (  (  tvrv.beziehung_art = decode(mr.relationtype, ''IS_DEMANDED_BY'', 40, ''SEEN_AS_EQUIVALENT_BY'', 102, 0 )',
'                                      and  (mr.multigroupid is null or (mr.multigroupid is not null and (nvl(mr.successorsincluded, ''false'') = ''true'')))',
'                                )',
'                            ) ',
'                        )',
'        )',
'    )                  ',
'                 ',
'',
' UNION',
'',
'  --///// nur in GETEX als Nachfolger von , nicht in Regindex',
' SELECT ',
'    nvl2(mv.target_reg_number,  concat( mv.target_reg_number || '' '' , ',
'                           case when :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(mv.rev_doc_datum ,''dd.mm.yyyy'' ), '''')  else '''' end ),',
'                          ''<span class="hl">nicht vorhanden</span>'') AS Getex_Hauptvorschrift --TargetVorschrift_nummer',
'   ,  nvl(mv.reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Equivalant_Vorschrift --Vorschrift_nummer,',
'   ,  ''<span class="hl">nicht vorhanden</span>'' as Regindex_Hauptvorschrift --_vorgaenger_vorschrift',
'   ,  ''<span class="hl">nicht vorhanden</span>'' AS Regindex_Equivalant_Vorschrift --_nachfolger_vorschrift ',
'   , case when (mv.multigroupid  is null or nvl(mv.successorsincluded, ''false'') =''false'' ) then ''Nein'' else ''Ja'' end as Getex_homologation_mit_hohere_serie',
'   , '''' as Regindex_homologation_mit_hohere_serie',
'',
'  from  cte_mv_t mv',
'  where  mv.relationtype in (''EQUIVALENT_TO'', ''SEEN_AS_EQUIVALENT_BY'') -- story 1364',
'  and (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 )  --// AB! hide',
'  and (nvl(mv.successorsincluded, ''false'') = ''true'' or mv.multigroupid is  null)',
'   and mv.Vorschriftid not in ( select tvrv.nachfolger_vorschriftid from t_vorschrift_ref_vorschrift tvrv',
'                                where tvrv.vorgaenger_vorschriftid = mv.targ_vorschriftid ',
'                                  and  (   (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 and tvrv.beziehung_art = 102   )    ) ',
'                               )',
'    --//---- andere verkn. in regindex, wo P29_VORSCHRIFTID als Nachfolger,  nicht mitnehmen',
' -- and mv.Vorschriftid not in ( select tvrv.nachfolger_vorschriftid from t_vorschrift_ref_vorschrift tvrv',
' --                               where tvrv.vorgaenger_vorschriftid = mv.targ_vorschriftid',
' --                               and (  (tvrv.beziehung_art = 102  )      )',
' --                             ) ',
'                                ',
'     --\\\\',
'  -- andere verkn. in regindex, wo P29_VORSCHRIFTID als Vorgaenger  nicht mitnehmen',
'  and mv.Vorschriftid not in ( select tvrv.vorgaenger_vorschriftid from t_vorschrift_ref_vorschrift tvrv',
'                                where tvrv.nachfolger_vorschriftid = mv.targ_vorschriftid ',
'                                and (   (tvrv.beziehung_art = decode(mv.relationtype,   ''SEEN_AS_EQUIVALENT_BY'', 102,    0  )',
'                                    )',
'                                    OR  ( PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 and tvrv.beziehung_art = decode(mv.relationtype, ''EQUIVALENT_TO'', 102,   0  )',
'                                    )',
'                                ) ',
'                            )  -- for 436',
' ',
'  UNION',
' ',
' -- -- vorschr as nachfolger  exact passend',
'  -- keine DEMANDS',
'   SELECT DISTINCT  ',
'     nvl(mv.target_reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Hauptvorschrift --TargetVorschrift_nummer   -- mv.sc_type, mv.sc_date ,',
'    , nvl(mv.reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Equivalant_Vorschrift --Vorschrift_nummer',
'    , nvl2(t.vorschrift_nummer,  concat(t.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end),',
'                          ''<span class="hl">nicht vorhanden</span>'') as Regindex_Hauptvorschrift --_vorgaenger_vorschrift',
'    , nvl2(t_n.Vorschrift_nummer,  concat(t_n.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t_n.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end),',
'                             ''<span class="hl">nicht vorhanden</span>'') AS Regindex_Equivalant_Vorschrift --_nachfolger_vorschrift',
'    , case when (mv.multigroupid  is null or nvl(mv.successorsincluded, ''false'') =''false'' ) then ''Nein'' else ''Ja'' end as Getex_homologation_mit_hohere_serie',
'',
'    , case when nvl(tvrv.homologation_serie, 0) = 10 then ',
'         case when (mv.multigroupid  is null or nvl(mv.successorsincluded, ''false'') =''false'' ) then',
'         ''<span class="hl">Ja</span>''',
'         else',
'          ''Ja''  end',
'      else ',
'        case when (mv.multigroupid  is null or nvl(mv.successorsincluded, ''false'') =''false'' ) and (tvrv.beziehung_art in (102, 40)) then',
'           ''Nein''',
'            when (mv.multigroupid  is null or nvl(mv.successorsincluded, ''false'') =''false'' ) then ''''',
'            else  ''<span class="hl">Nein</span>'' end',
'      end as Regindex_homologation_mit_hohere_serie',
'',
' FROM  T_VORSCHRIFT_REF_VORSCHRIFT tvrv',
' full outer JOIN cte_mv_t mv on ( mv.vorschriftid = tvrv.Nachfolger_Vorschriftid and tvrv.Vorgaenger_vorschriftid = mv.targ_vorschriftid )',
' left outer join T_VORSCHRIFT t on ( t.VORSCHRIFTID = tvrv.Vorgaenger_Vorschriftid and t.REGINDEXID is not null  ) ',
' left outer join T_VORSCHRIFT t_n on (t_n.VORSCHRIFTID = tvrv.NACHFOLGER_VORSCHRIFTID and t_n.REGINDEXID is not null  )',
'',
'',
' WHERE mv.vorschriftid = :P29_VORSCHRIFTID ',
'  and mv.relationtype  in ( ''EQUIVALENT_TO'')  -- story 1364',
'  --and (mv.relationtype  in ( ''SUCCESSOR'', ''LINKED_TO'', ''CHANGES'' )-- ''IS_CONSOLIDATED_IN'' --, ''CONSOLIDATES'', ',
'    --    or ( PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 and mv.relationtype  in ( ''EQUIVALENT_TO'', ''DEMANDS''))',
'    --  ) --!AB3',
' --  order by nachfolger_vorschriftID, Getex_TargetVorschrift_nummer',
'  and  (  ( tvrv.beziehung_art = decode(mv.relationtype,  ''EQUIVALENT_TO'', 102,   0  )',
'                and (mv.multigroupid is  null or (nvl(mv.successorsincluded, ''false'') = ''true''))',
'            ) ',
'       )  ',
'        ',
'  UNION',
'',
' -- vorschrift as vorgaenger passend',
' SELECT     nvl(mv.reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Hauptvorschrift ----Vorschrift_nummer',
'     , nvl(mv.target_reg_number, ''<span class="hl">nicht vorhanden</span>'') AS Getex_Equivalant_Vorschrift --TargetVorschrift_nummer   -- mv.sc_type, mv.sc_date ,',
'    , nvl2(t.vorschrift_nummer,  concat(t.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end),',
'                              ''<span class="hl">nicht vorhanden</span>'') as Regindex_Hauptvorschrift --_vorgaenger_vorschrift',
'    ,  nvl2(t_n.Vorschrift_nummer,  concat(t_n.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t_n.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end),',
'                                  ''<span class="hl">nicht vorhanden</span>'') AS Regindex_Equivalant_Vorschrift --_Nachfolger_vorschrift  --    ',
'    , case when (mv.multigroupid  is null or nvl(mv.successorsincluded, ''false'') =''false'' ) and  (tvrv.beziehung_art in (120, 40) ) then  ''Nein'' ',
'         when (mv.multigroupid  is null or nvl(mv.successorsincluded, ''false'') =''false'' ) then ''''',
'        else ''Ja'' end as Getex_homologation_mit_hohere_serie',
'    , case when nvl(tvrv.homologation_serie, 0) = 10 then ',
'         case when (mv.multigroupid  is null or nvl(mv.successorsincluded, ''false'') =''false'' ) then',
'         ''<span class="hl">Ja</span>''',
'         else',
'        ''Ja''  end',
'      else ',
'        case when (mv.multigroupid  is null or nvl(mv.successorsincluded, ''false'') =''false'' ) and (tvrv.beziehung_art in (120, 40)) then',
'         ''Nein''',
'          when (mv.multigroupid  is null or nvl(mv.successorsincluded, ''false'') =''false'' )  then ''''',
'          else  ''<span class="hl">Nein</span>'' end',
'       end as Regindex_homologation_mit_hohere_serie ',
'       ',
' FROM T_VORSCHRIFT_REF_VORSCHRIFT tvrv',
'  --full outer ',
'  JOIN cte_mv_t mv  on (  mv.vorschriftid = tvrv.Vorgaenger_Vorschriftid and mv.targ_vorschriftid = tvrv.Nachfolger_Vorschriftid) ',
'  left outer join T_VORSCHRIFT t on ( t.VORSCHRIFTID = tvrv.Vorgaenger_Vorschriftid and t.REGINDEXID is not null ) ',
'  left outer join T_VORSCHRIFT t_n on (t_n.VORSCHRIFTID = tvrv.NACHFOLGER_VORSCHRIFTID and t_n.REGINDEXID is not null  )',
' WHERE mv.vorschriftid = :P29_VORSCHRIFTID --5682 --436 --:P29_VORSCHRIFTID ',
' and mv.relationtype  in ( ''SEEN_AS_EQUIVALENT_BY'')  -- story 1364',
'  and  (   (  PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 and tvrv.beziehung_art = decode(mv.relationtype,   ''SEEN_AS_EQUIVALENT_BY'', 102,   0  )  --!AB4',
'                and  (mv.multigroupid is null or  (nvl(mv.successorsincluded, ''false'') = ''true'') )',
'            )',
'        )',
'',
'order by  4'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1 from MV_GETEX_VORSCHRIFT_RELATION ',
'   where v_id = (select regindexid from t_vorschrift where vorschriftid= :P29_VORSCHRIFTID and regindexid is not null)',
'   and relationtype in (''EQUIVALENT_TO'', ''SEEN_AS_EQUIVALENT_BY'')',
'   ',
' UNION',
'  SELECT  1 from t_vorschrift_ref_vorschrift ',
'   where  (vorgaenger_vorschriftid = :P29_VORSCHRIFTID or nachfolger_vorschriftid = :P29_VORSCHRIFTID)',
'   and beziehung_art in (102)'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069007166629571902)
,p_query_column_id=>1
,p_column_alias=>'GETEX_HAUPTVORSCHRIFT'
,p_column_display_sequence=>10
,p_column_heading=>'Getex Hauptvorschrift'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069007038883571901)
,p_query_column_id=>2
,p_column_alias=>'GETEX_EQUIVALANT_VORSCHRIFT'
,p_column_display_sequence=>20
,p_column_heading=>'Getex Equivalant Vorschrift'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069006917383571900)
,p_query_column_id=>3
,p_column_alias=>'REGINDEX_HAUPTVORSCHRIFT'
,p_column_display_sequence=>30
,p_column_heading=>'Regindex Hauptvorschrift'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069006816727571899)
,p_query_column_id=>4
,p_column_alias=>'REGINDEX_EQUIVALANT_VORSCHRIFT'
,p_column_display_sequence=>40
,p_column_heading=>'Regindex Equivalant Vorschrift'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069006733540571898)
,p_query_column_id=>5
,p_column_alias=>'GETEX_HOMOLOGATION_MIT_HOHERE_SERIE'
,p_column_display_sequence=>50
,p_column_heading=>'Getex Homologation Mit Hohere Serie'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069006707326571897)
,p_query_column_id=>6
,p_column_alias=>'REGINDEX_HOMOLOGATION_MIT_HOHERE_SERIE'
,p_column_display_sequence=>60
,p_column_heading=>'Regindex Homologation Mit Hohere Serie'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1069006533060571896)
,p_name=>'Demand'
,p_parent_plug_id=>wwv_flow_imp.id(1069009479583571925)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('with cte_daten_getex as (-- Einsatzdatumsangaben aus GETEX - Schritt 1: Minimum \00FCber alle Themen holen '),
'           select ',
'            v.vorschriftid, sc_type, trunc(min(sc_date)) as sc_date, sc_vehicletype, g.targetid',
'            from MV_GETEX_VORSCHRIFT_RELATION g',
'            join t_vorschrift v on (g.v_id = v.regindexid)',
'            where relationtype in (''DEMANDS'', ''IS_DEMANDED_BY'') --sc_date is not null and',
'                and (multigroupid is null or nvl(successorsincluded, ''false'') = ''true'')',
'               and   v.vorschriftid = :P29_VORSCHRIFTID           --and sc_type is not null',
'            group by v.vorschriftid, g.targetid, sc_type, sc_vehicletype',
unistr(' ) , cte_daten_getex2 as ( -- Einsatzdatumsangaben aus GETEX - Schritt 2: Sortorder \00FCber Fahrzeugarten definieren '),
'            select c.*, case sc_vehicletype when ''PCV'' then 1 when ''INDEPENDENT'' then 2 else 3 end as sortorder',
'            from cte_daten_getex c order by targetid',
unistr(' ), cte_daten_getex3 as ( -- Einsatzdatumsangaben aus GETEX - Schritt 3: Auf Fahrzeugart mit h\00F6chster Priorit\00E4t limitieren '),
'            select distinct vorschriftid, sc_type,  -- to_char(sc_date, ''dd.mm.yyyy''), sc_type',
'            targetid,',
'            to_char(sc_date, ''dd.mm.yyyy'') getex_einsatzdatum,',
'            sc_vehicletype as fahrzeugtyp',
'            from cte_daten_getex2 order by targetid, sc_vehicletype',
' ),  cte_mv as ( ',
'                select  vr.V_ID, vr.vorschriftid, vr.reg_number, vr.relationtype relationtype, vr.target_reg_number target_reg_number,',
'                  vr.multigroupid, vr.successorsincluded, ',
'                    vr.sc_type, vr.targetid, min(vr.sc_date) as sc_date',
'                from MV_GETEX_VORSCHRIFT_RELATION vr ',
'                where vr.vorschriftid = :P29_VORSCHRIFTID  --5682 --436  ',
'                GROUP BY vr.V_ID, vr.vorschriftid, vr.reg_number, vr.relationtype, vr.target_reg_number, vr.sc_type, vr.targetid, ',
'                vr.multigroupid, vr.successorsincluded',
'                order by relationtype, targetid',
' ), cte_mv_t as ( ',
'                 select  t.vorschriftid targ_vorschriftid, mv.V_ID, mv.vorschriftid, mv.reg_number, mv.multigroupid, mv.successorsincluded,',
'                    mv.relationtype , mv.target_reg_number ,  mv.sc_type, mv.targetid, mv.sc_date, gv.rev_doc_datum',
'                 from cte_mv mv',
'                 join t_vorschrift t on (t.regindexid = mv.targetid)',
'                 -- 1436  geloeschte vorsch',
'                 join MV_GETEX_VORSCHRIFT gv on (gv.reg_id = t.regindexid)',
'                  where (nvl(gv.loesch_datum, sysdate +200) > sysdate)',
' ),  cte_mv_r as (',
'                select Distinct t.vorschriftid targ_vorschriftid, vr.V_ID, vr.vorschriftid, vr.reg_number, vr.relationtype, vr.target_reg_number',
'                    , vr.multigroupid, vr.successorsincluded ',
'                from MV_GETEX_VORSCHRIFT_RELATION vr ',
'                join t_vorschrift t on (t.regindexid = vr.targetid)',
'                -- 1436  geloeschte vorsch',
'                 join MV_GETEX_VORSCHRIFT gv on (gv.reg_id = vr.V_ID)',
'                  where (nvl(gv.loesch_datum, sysdate +200) > sysdate)',
'                  -- \\\\',
'                and  t.vorschriftid =  :P29_VORSCHRIFTID  --5682 --436',
' )',
'',
' --/////',
' SELECT distinct  --- nur in Regindex als Vorgaenger oder nachfolger, nicht in  GETEX        --nachf 25701',
'  ''<span class="hl">nicht vorhanden</span>'' AS GETEX_Rahmenrichtlinie --Vorschrift_nummer,',
'   ',
'   ,  ''<span class="hl">nicht vorhanden</span>'' AS GETEX_Demands_Vorschrift --TargetVorschrift_nummer   -- mv.sc_type, mv.sc_date ,',
'    , nvl2(t.vorschrift_nummer, concat(t.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end), ',
'                      ''<span class="hl">nicht vorhanden</span>'') as RegindexDB_Rahmenrichtlinie --vorgaenger_vorschrift',
'    , nvl2(t_n.Vorschrift_nummer, concat(t_n.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t_n.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end), ',
'                               ''<span class="hl">nicht vorhanden</span>'') AS RegindexDB_Demands_Vorschrift  --nachfolger_vorschrift ',
'   ',
'    , '''' as Getex_homologation_mit_hohere_serie',
'    , case when nvl(tvrv.homologation_serie, 0) = 10 then ''Ja'' ',
'          -- when tvrv.beziehung_art not in (120, 40) then  '''' ',
'           else ''Nein'' end as Regindex_homologation_mit_hohere_serie ',
'    , ''''   as diff_dat   ',
'    , vorschrift_ref_vorschriftid as virt_id ',
'    ,  '''' as RR_getex_key',
'     , '''' as DEM_getex_key',
'',
' FROM t_vorschrift_ref_vorschrift tvrv ',
'  left outer join T_VORSCHRIFT t on ( t.VORSCHRIFTID = tvrv.Vorgaenger_Vorschriftid )    --and t.REGINDEXID is not null  )',
'    left outer join T_VORSCHRIFT t_n on (t_n.VORSCHRIFTID = tvrv.NACHFOLGER_VORSCHRIFTID )  -- and t_n.REGINDEXID is not null  )',
'    where  (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 OR  tvrv.beziehung_art not in (40,102))  --AB2!',
'     and tvrv.beziehung_art = 40 -- ( story 1364)',
'   ',
'     and',
'    (',
'        ( tvrv.vorgaenger_vorschriftid = :P29_VORSCHRIFTID ',
'           and tvrv.nachfolger_vorschriftid not in ( select targ_vorschriftid from cte_mv_t mv where -- vorschriftid =436',
'                                (  --(tvrv.beziehung_art = decode(mv.relationtype, ''IS_DEMANDED_BY'', 40, ''SEEN_AS_EQUIVALENT_BY'', 102, 0 ) ',
'                                   (tvrv.beziehung_art = decode(mv.relationtype, ''IS_DEMANDED_BY'', 40, ''SEEN_AS_EQUIVALENT_BY'', 102, 0 )',
'                                           and  (mv.multigroupid is null or (mv.multigroupid is not null and (nvl(mv.successorsincluded, ''false'') = ''true'')))',
'                                    )',
'                                )  ',
'                            )',
'        ) ',
'',
'       OR     ',
'        ( tvrv.nachfolger_vorschriftid = :P29_VORSCHRIFTID',
'            and tvrv.vorgaenger_vorschriftid not in ( select vorschriftid  from cte_mv_r mr   where ',
'                            (  (  tvrv.beziehung_art = decode(mr.relationtype, ''IS_DEMANDED_BY'', 40, ''SEEN_AS_EQUIVALENT_BY'', 102, 0 )',
'                                      and  (mr.multigroupid is null or (mr.multigroupid is not null and (nvl(mr.successorsincluded, ''false'') = ''true'')))',
'                                )',
'                            ) ',
'                        )',
'        )',
'    )                  ',
'             ',
' UNION',
'',
'  --///// nur in GETEX als Nachfolger von , nicht in Regindex',
' SELECT distinct',
'    nvl2(mv.target_reg_number,  concat( mv.target_reg_number || '' '' , ',
'                           case when :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(mv.rev_doc_datum ,''dd.mm.yyyy'' ), '''')  else '''' end ),',
'                          ''<span class="hl">nicht vorhanden</span>'') AS GETEX_Rahmenrichtlinie --TargetVorschrift_nummer',
'   ,  nvl(mv.reg_number, ''<span class="hl">nicht vorhanden</span>'') AS GETEX_Demands_Vorschrift --Vorschrift_nummer,',
'   ,  ''<span class="hl">nicht vorhanden</span>'' as RegindexDB_Rahmenrichtlinie --_vorgaenger_vorschrift',
'   ,  ''<span class="hl">nicht vorhanden</span>'' AS RegindexDB_Demands_Vorschrift --_nachfolger_vorschrift ',
'   , case when (mv.multigroupid  is null or nvl(mv.successorsincluded, ''false'') =''false'' ) then ''Nein'' else ''Ja'' end as Getex_homologation_mit_hohere_serie',
'   , '''' as Regindex_homologation_mit_hohere_serie ',
'   ,  ''''  as diff_dat ',
'  , 0 as virt_id',
'   --,  mv.v_id as getex_key',
'   , mv.targetid as RR_getex_key',
'   , mv.v_id as DEM_getex_key',
'',
'  from  cte_mv_t mv',
'  where  mv.relationtype in (''DEMANDS'', ''IS_DEMANDED_BY'') -- story 1364',
'  and (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 )  --// AB! hide',
'  and (nvl(mv.successorsincluded, ''false'') = ''true'' or mv.multigroupid is  null)',
'   and mv.Vorschriftid not in ( select tvrv.nachfolger_vorschriftid from t_vorschrift_ref_vorschrift tvrv',
'                                where tvrv.vorgaenger_vorschriftid = mv.targ_vorschriftid ',
'                                  and  (   (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 and tvrv.beziehung_art = 40   )    ) ',
'                               )',
'    --//---- andere verkn. in regindex, wo P29_VORSCHRIFTID als Nachfolger,  nicht mitnehmen',
' -- and mv.Vorschriftid not in ( select tvrv.nachfolger_vorschriftid from t_vorschrift_ref_vorschrift tvrv',
' --                               where tvrv.vorgaenger_vorschriftid = mv.targ_vorschriftid',
' --                               and (  (tvrv.beziehung_art = 40  )      )',
' --                             ) ',
'                                ',
'     --\\\\',
'  -- andere verkn. in regindex, wo P29_VORSCHRIFTID als Vorgaenger  nicht mitnehmen',
'  and mv.Vorschriftid not in ( select tvrv.vorgaenger_vorschriftid from t_vorschrift_ref_vorschrift tvrv',
'                                where tvrv.nachfolger_vorschriftid = mv.targ_vorschriftid ',
'                                and (   (tvrv.beziehung_art = decode(mv.relationtype,   ''IS_DEMANDED_BY'', 40,    0  )',
'                                    )',
'                                    OR  ( PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 and tvrv.beziehung_art = decode(mv.relationtype, ''DEMANDS'', 40,   0  )',
'                                    )',
'                                ) ',
'                            )  -- for 436',
' ',
'  UNION',
'   --- nur DEMANDS  ****************',
'    SELECT DISTINCT   nvl(mv.target_reg_number, ''<span class="hl">nicht vorhanden</span>'') AS GETEX_Rahmenrichtlinie   -- mv.sc_type, mv.sc_date ,',
'    , nvl(mv.reg_number, ''<span class="hl">nicht vorhanden</span>'') AS GETEX_Demands_vorschrift',
'    -- , mv.relationtype   -- nvl(vr.vorschriftid, 0) AS GetexVorschriftID, vr.V_ID Getex_ID,',
'    , nvl2(t.vorschrift_nummer,  concat(t.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja'' then nvl(to_char(t.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end),',
'                        ''<span class="hl">nicht vorhanden</span>'') as RegindexDB_Rahmenrichtlinie',
'    -- , decode(tvrv.beziehung_art, 10, ''predeccessor >>successor'', 20, ''Amendment'', 30, ''Supplement'', 40, ''Demands'', 102,''Equivalent'',  60, ''Linked'', ''unbekannt'') beziehung_art',
'    , nvl2(t_n.Vorschrift_nummer,  concat(t_n.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t_n.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end),',
'                         ''<span class="hl">nicht vorhanden</span>'') AS RegindexDB_Demands_vorschrift',
'    --  , tvrv.datum_alle_typen, tvrv.datum_neue_typen',
'    , case when nvl(tvrv.homologation_serie, 0) = 10 then ',
'           case when (mv.multigroupid  is null or nvl(mv.successorsincluded, ''false'') =''false'' ) then',
'              ''<span class="hl">Ja</span>''',
'               else',
'              ''Ja''  end',
'      else ',
'            case when (mv.multigroupid  is null or nvl(mv.successorsincluded, ''false'') =''false'' ) then',
'              ''Nein''',
'            else',
'              ''<span class="hl">Nein</span>'' end',
'      end as Regindex_homologation_mit_hohere_serie ',
'    , case when (mv.multigroupid  is null or nvl(mv.successorsincluded, ''false'') =''false'' ) then ''Nein'' ',
'           else ''Ja'' end as getex_homologation_mit_hohere_serie',
' -- vret.einsatzdatum as Inkraftsetzung_verkn_Vorschrift',
'    , case when ( nvl(tvrv.datum_alle_typen, null) is not null and  g3.sc_type = ''All Vehicles'' and g3.getex_einsatzdatum is null',
'               or nvl(tvrv.datum_alle_typen, null) is  null and  g3.sc_type = ''All Vehicles'' and g3.getex_einsatzdatum is not null',
'            )',
'            then ''<span class="hl">Ja, All/ New types</span>''',
'            when ( nvl(tvrv.datum_neue_typen, null) is not null and  g3.sc_type = ''New Types'' and g3.getex_einsatzdatum is null',
'               or nvl(tvrv.datum_neue_typen, null) is  null and  g3.sc_type = ''New Types'' and g3.getex_einsatzdatum is not null',
'            )',
'            then ''<span class="hl">Ja, All/ New types</span>''',
'            when ( nvl(tvrv.datum_alle_typen, null) is  null and  g3.sc_type = ''All Vehicles''  and g3.getex_einsatzdatum is null)',
'            then  ''Nein, All/ New types''',
'',
'            when ( nvl(tvrv.datum_neue_typen, null) is null and  g3.sc_type = ''New Types'' and g3.getex_einsatzdatum is null)',
'            then ''Nein, All/ New types''',
'            when ( nvl(tvrv.datum_neue_typen, null) is null and  g3.sc_type  is null )',
'            then ''Nein, All/ New types''',
'',
'            when ( nvl(tvrv.datum_alle_typen, null) is not null and  g3.sc_type = ''All Vehicles'' and g3.getex_einsatzdatum is not null )',
'            then (',
'                case when (to_char(tvrv.datum_alle_typen, ''dd.mm.yyyy'') = g3.getex_einsatzdatum )',
'                     then ''Nein, All/ New types''',
'                else ''<span class="hl">Ja, All/ New types</span>'' end',
'            )',
'            when ( nvl(tvrv.datum_neue_typen, null) is not null and  g3.sc_type = ''New Types'' and g3.getex_einsatzdatum is not null )',
'            then (',
'                case when (to_char(tvrv.datum_neue_typen, ''dd.mm.yyyy'') = g3.getex_einsatzdatum )',
'                then ''Nein, All/ New types''',
'                else ''<span class="hl">Ja, All/ New types</span>'' end',
'           )',
'           else ''<span class="hl">Ja, All/ New types</span>'' end as diff_dat ',
'          --||''<button type="button" data-t-id="#virt_id#"  class="t-Button t-Button--small  t-Button--padleft t-Button--padRight t-Button--padTop t-Button--padBottom  cc_data_btn">Daten</button >'' ',
'   , tvrv.vorschrift_ref_vorschriftid as virt_id',
'   , mv.targetid as RR_getex_key',
'   , mv.v_id as DEM_getex_key',
'         -- g3.getex_einsatzdatum getex_einsatzdatum',
'',
' FROM  T_VORSCHRIFT_REF_VORSCHRIFT tvrv',
' full outer JOIN cte_mv_t mv on ( mv.vorschriftid = tvrv.Nachfolger_Vorschriftid and tvrv.Vorgaenger_vorschriftid = mv.targ_vorschriftid )',
' left outer join T_VORSCHRIFT t on ( t.VORSCHRIFTID = tvrv.Vorgaenger_Vorschriftid and t.REGINDEXID is not null  ) ',
' left outer join T_VORSCHRIFT t_n on (t_n.VORSCHRIFTID = tvrv.NACHFOLGER_VORSCHRIFTID and t_n.REGINDEXID is not null  )',
' full outer JOIN cte_daten_getex3 g3 on ( g3.sc_type is null or g3.sc_type in ( ''All Vehicles'', ''New Types'') )',
'',
' WHERE mv.vorschriftid = :P29_VORSCHRIFTID ',
'   and g3.targetid = mv.targetid',
'  ',
'  and  ( (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 and mv.relationtype  in (  ''DEMANDS'' )) ',
'        ) --!AB3',
'  and  (   ( tvrv.beziehung_art = decode(mv.relationtype, ''DEMANDS'', 40, 0  )',
'            ) ',
'       )',
'',
'  UNION',
'-- DEMANDS as Vorgaenger',
'     SELECT DISTINCT  nvl(mv.reg_number, ''<span class="hl">nicht vorhanden</span>'') AS GETEX_Rahmenrichtlinie   -- mv.sc_type, mv.sc_date ,',
'    , nvl(mv.target_reg_number, ''<span class="hl">nicht vorhanden</span>'') AS GETEX_Demands_vorschrift',
'   -- , mv.relationtype   -- nvl(vr.vorschriftid, 0) AS GetexVorschriftID, vr.V_ID Getex_ID,',
'    , nvl2(t.vorschrift_nummer,  concat(t.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end), ',
'                           ''<span class="hl">nicht vorhanden</span>'') as RegindexDB_Rahmenrichtlinie',
'   -- , decode(tvrv.beziehung_art, 10, ''predeccessor >>successor'', 20, ''Amendment'', 30, ''Supplement'', 40, ''Demands'', 102,''Equivalent'',  60, ''Linked'', ''unbekannt'') beziehung_art',
'    , nvl2(t_n.Vorschrift_nummer,  concat(t_n.vorschrift_nummer || '' '',  ',
'                           case when  :P29_LAND_ERW_ANZEIGE =''Ja''  then nvl(to_char(t_n.dokumentendatum, ''dd.mm.yyyy'' ), '''') else '''' end),',
'                                ''<span class="hl">nicht vorhanden</span>'') AS RegindexDB_Demands_vorschrift',
'  --  , tvrv.datum_alle_typen, tvrv.datum_neue_typen',
'    , case when nvl(tvrv.homologation_serie, 0) = 10 then ',
'            case when (mv.multigroupid  is null or nvl(mv.successorsincluded, ''false'') =''false'' ) then',
'                  ''<span class="hl">Ja</span>''',
'                else',
'                ''Ja''  end',
'      else ',
'            case when (mv.multigroupid  is null or nvl(mv.successorsincluded, ''false'') =''false'' ) then',
'              ''Nein''',
'            else',
'              ''<span class="hl">Nein</span>'' end',
'       end as Regindex_homologation_mit_hohere_serie ',
'    , case when (mv.multigroupid  is null or nvl(mv.successorsincluded, ''false'') =''false'' ) then ''Nein'' ',
'      else ''Ja'' end as getex_homologation_mit_hohere_serie',
' -- vret.einsatzdatum as Inkraftsetzung_verkn_Vorschrift',
'   ,  case when ( nvl(tvrv.datum_alle_typen, null) is not null and  g3.sc_type = ''All Vehicles'' and g3.getex_einsatzdatum is null',
'               or nvl(tvrv.datum_alle_typen, null) is  null and  g3.sc_type = ''All Vehicles'' and g3.getex_einsatzdatum is not null',
'            )',
'            then ''<span class="hl">Ja, All/ New types</span>''',
'            when ( nvl(tvrv.datum_neue_typen, null) is not null and  g3.sc_type = ''New Types'' and g3.getex_einsatzdatum is null',
'               or nvl(tvrv.datum_neue_typen, null) is  null and  g3.sc_type = ''New Types'' and g3.getex_einsatzdatum is not null',
'            )',
'            then ''<span class="hl">Ja, All/ New types</span>''',
'            when ( nvl(tvrv.datum_alle_typen, null) is  null and  g3.sc_type = ''All Vehicles''  and g3.getex_einsatzdatum is null)',
'            then  ''Nein, All/ New types''',
'',
'            when ( nvl(tvrv.datum_neue_typen, null) is null and  g3.sc_type = ''New Types'' and g3.getex_einsatzdatum is null)',
'            then ''Nein, All/ New types''',
'            when ( nvl(tvrv.datum_neue_typen, null) is null and  g3.sc_type  is null )',
'            then ''Nein, All/ New types''',
'',
'            when ( nvl(tvrv.datum_alle_typen, null) is not null and  g3.sc_type = ''All Vehicles'' and g3.getex_einsatzdatum is not null )',
'            then (',
'                case when (to_char(tvrv.datum_alle_typen, ''dd.mm.yyyy'') = g3.getex_einsatzdatum )',
'                     then ''Nein, All/ New types''',
'                     else ''<span class="hl">Ja, All/ New types</span>'' end',
'           )',
'           when ( nvl(tvrv.datum_neue_typen, null) is not null and  g3.sc_type = ''New Types'' and g3.getex_einsatzdatum is not null )',
'           then (',
'                case when (to_char(tvrv.datum_neue_typen, ''dd.mm.yyyy'') = g3.getex_einsatzdatum )',
'                then ''Nein, All/ New types''',
'                else ''<span class="hl">Ja, All/ New types</span>'' end',
'           )',
'           else ''<span class="hl">Ja, All/ New types</span>'' end as diff_dat ',
'          --||''<button type="button" data-t-id="#virt_id#"  class="t-Button t-Button--small  t-Button--padleft t-Button--padRight t-Button--padTop t-Button--padBottom  cc_data_btn">Daten</button >'' ',
'   , tvrv.vorschrift_ref_vorschriftid as virt_id',
'   , mv.v_id as RR_getex_key  -- RahmenRichtlin',
'   , mv.targetid as DEM_getex_key  -- Demands',
'',
' FROM  T_VORSCHRIFT_REF_VORSCHRIFT tvrv',
' full outer JOIN cte_mv_t mv on ( mv.vorschriftid = tvrv.Vorgaenger_vorschriftid  and tvrv.Nachfolger_Vorschriftid = mv.targ_vorschriftid )',
' left outer join T_VORSCHRIFT t on ( t.VORSCHRIFTID = tvrv.Vorgaenger_Vorschriftid and t.REGINDEXID is not null  ) ',
' left outer join T_VORSCHRIFT t_n on (t_n.VORSCHRIFTID = tvrv.NACHFOLGER_VORSCHRIFTID and t_n.REGINDEXID is not null  )',
' full outer JOIN cte_daten_getex3 g3 on ( g3.sc_type is null or g3.sc_type in ( ''All Vehicles'', ''New Types'') )',
'',
' WHERE mv.vorschriftid = :P29_VORSCHRIFTID ',
'   and g3.targetid = mv.targetid',
'  ',
'   and  ( (PCK_RI_GETEX_CTRL.fEquiDemandsCheck =1 and mv.relationtype  in (  ''IS_DEMANDED_BY'' )) ',
'        ) --!AB3',
'   and  (   ( tvrv.beziehung_art = decode(mv.relationtype, ''IS_DEMANDED_BY'', 40, 0  )   ',
'            ) ',
'        )',
'  order by 4'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1 from MV_GETEX_VORSCHRIFT_RELATION ',
'   where v_id = (select regindexid from t_vorschrift where vorschriftid= :P29_VORSCHRIFTID and regindexid is not null)',
'   and relationtype in (''DEMANDS'', ''IS_DEMANDED_BY'')',
'   and (multigroupid is null or nvl(successorsincluded, ''false'')=''true'')',
' UNION',
'  SELECT  1 from t_vorschrift_ref_vorschrift ',
'   where  (vorgaenger_vorschriftid = :P29_VORSCHRIFTID or nachfolger_vorschriftid = :P29_VORSCHRIFTID)',
'   and beziehung_art in (40)'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069006420343571895)
,p_query_column_id=>1
,p_column_alias=>'GETEX_RAHMENRICHTLINIE'
,p_column_display_sequence=>10
,p_column_heading=>'Getex Rahmenrichtlinie'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069006383922571894)
,p_query_column_id=>2
,p_column_alias=>'GETEX_DEMANDS_VORSCHRIFT'
,p_column_display_sequence=>20
,p_column_heading=>'Getex Demands Vorschrift'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069006283027571893)
,p_query_column_id=>3
,p_column_alias=>'REGINDEXDB_RAHMENRICHTLINIE'
,p_column_display_sequence=>30
,p_column_heading=>'Regindexdb Rahmenrichtlinie'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069006119901571892)
,p_query_column_id=>4
,p_column_alias=>'REGINDEXDB_DEMANDS_VORSCHRIFT'
,p_column_display_sequence=>40
,p_column_heading=>'Regindexdb Demands Vorschrift'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069006111938571891)
,p_query_column_id=>5
,p_column_alias=>'GETEX_HOMOLOGATION_MIT_HOHERE_SERIE'
,p_column_display_sequence=>50
,p_column_heading=>'Getex Homologation Mit Hohere Serie'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069005964674571890)
,p_query_column_id=>6
,p_column_alias=>'REGINDEX_HOMOLOGATION_MIT_HOHERE_SERIE'
,p_column_display_sequence=>60
,p_column_heading=>'Regindex Homologation Mit Hohere Serie'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069005886006571889)
,p_query_column_id=>7
,p_column_alias=>'DIFF_DAT'
,p_column_display_sequence=>70
,p_column_heading=>'Diff Dat'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069005806243571888)
,p_query_column_id=>8
,p_column_alias=>'VIRT_ID'
,p_column_display_sequence=>80
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069005705083571887)
,p_query_column_id=>9
,p_column_alias=>'RR_GETEX_KEY'
,p_column_display_sequence=>100
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1069005533642571886)
,p_query_column_id=>10
,p_column_alias=>'DEM_GETEX_KEY'
,p_column_display_sequence=>110
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1068909096600951432)
,p_query_column_id=>11
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>90
,p_column_heading=>unistr('Eigenschaften der Verkn\00FCpfung (Datum, etc)')
,p_column_link=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.::P46_VORSCHRIFT_REF_VORSCHRIFTID,P46_DEM_GETEX_KEY,P46_RR_GETEX_KEY:#VIRT_ID#,#DEM_GETEX_KEY#,#RR_GETEX_KEY#'
,p_column_linktext=>'<span style="font-size:1.5em" class="fa fa-question-square-o"></span>'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(4839304466129842179)
,p_name=>'Thema'
,p_parent_plug_id=>wwv_flow_imp.id(4838059380679153640)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>110
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'with cte_l as (',
'    select t.nummer, t.bezeichnung, t.themaid',
'    from t_vorschrift_ref_thema vrt',
'    join t_thema t on (vrt.themaid = t.themaid)',
'    where vrt.geloescht = 0 and vrt.vorschriftid = :P29_VORSCHRIFTID',
'), cte_r as (',
'    select gvt.thema_name, gvt.regindex_themaid',
'    from t_vorschrift v',
'    join mv_getex_vorschrift_thema gvt on (v.regindexid = gvt.v_id)',
'    where v.vorschriftid = :P29_VORSCHRIFTID and gvt.regindex_themaid is not null',
')',
'select nvl2(cte_l.themaid,cte_l.nummer || '' '' || cte_l.BEZEICHNUNG, ''<span class="hl">nicht vorhanden</span>'') AS RegindexThemaName, nvl(cte_r.THEMA_NAME, ''<span class="hl">nicht vorhanden</span>'') as getexthemaname',
'from cte_l',
'full outer join cte_r on (cte_l.themaid = cte_r.regindex_themaid)'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P29_VORSCHRIFTID,P29_LIST'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    tv.REGINDEXID AS LocalRegindexID,',
'    vgt.V_ID AS GetexVID,',
'    tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'    tvrt.THEMAID AS LocalThemaID,',
'    vgt.REGINDEX_THEMAID AS GetexThemaID,',
'    tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON tv.VORSCHRIFTID = tvrt.VORSCHRIFTID',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'    AND (',
'        (:P29_LIST = ''Alle'' AND (tvrt.THEMAID != vgt.REGINDEX_THEMAID OR tvrt.THEMAID IS NULL OR vgt.REGINDEX_THEMAID IS NULL))',
'        OR (:P29_LIST = ''Getex'' AND vgt.REGINDEX_THEMAID IS NOT NULL AND tvrt.THEMAID IS NULL)',
'        OR (:P29_LIST = ''Vorschrift'' AND tvrt.THEMAID IS NOT NULL AND vgt.REGINDEX_THEMAID IS NULL)',
'    );',
'',
'',
'',
'',
'',
'',
'',
'declare',
'l_value clob;',
'begin',
'if :P29_LIST =''Alle'' then',
'',
'l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
'full outer JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE tv.REGINDEXID IS NOT NULL',
'and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'',
'elsif :P29_LIST =''Vorschrift'' then',
'',
'l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
' left outer JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE tv.REGINDEXID IS NOT NULL',
'and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'   else',
'   l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
' V_GETEX_VORSCHRIFT_THEMA vgt',
' INNER JOIN',
'    T_VORSCHRIFT tv ON tv.REGINDEXID = vgt.V_ID',
'left outer join ',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID    ',
'WHERE tv.REGINDEXID IS NOT NULL',
' and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'end if;',
'return(l_value);',
'end;'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(672849439266442502)
,p_query_column_id=>1
,p_column_alias=>'REGINDEXTHEMANAME'
,p_column_display_sequence=>70
,p_column_heading=>'Regindex Themaname'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(672849102904442501)
,p_query_column_id=>2
,p_column_alias=>'GETEXTHEMANAME'
,p_column_display_sequence=>50
,p_column_heading=>'Getex Themaname'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(4839407889688060654)
,p_name=>'Land'
,p_parent_plug_id=>wwv_flow_imp.id(4838059380679153640)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>120
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('with cte_l as ( -- dem Vorschrift zugeordnete l\00E4nder in Regindex'),
'    select distinct l.land, l.iso_code_3, l.landid, vrl.bemerkung, l.b_nummer',
'    from t_vorschrift_ref_land vrl',
'    join t_land l on (vrl.landid = l.landid)',
'    where vrl.vorschriftid = :P29_VORSCHRIFTID and vrl.geloescht = 0',
'),',
unistr('cte_rm as ( -- dem Vorschrift zugeordnete l\00E4nder in Getex , au\00DFer ARE-l\00E4nder (regindex_landid = null)'),
'    select distinct gvl.regindex_landid as regindex_landid, gvl.land_name, gvl.iso_code3 as getexisocode',
'    from t_vorschrift v',
'    join mv_getex_vorschrift_land gvl on (v.regindexid = gvl.v_id)',
'    where  v.vorschriftid = :P29_VORSCHRIFTID   and gvl.regindex_landid is not null ',
'              ',
unistr('     UNION  -- l\00E4nder die in Getex vorhanden und subl\00E4nder sind ,  au\00DFer  Typ 3'),
'     select distinct mg.landid as regindex_landid, gvl.land_name, mg.mapping_text as getexisocode',
'    from t_vorschrift v',
'    join mv_getex_vorschrift_land gvl on (v.regindexid = gvl.v_id)',
'    join t_land_mapping_getex mg on (mg.mapping_typ =1 and mg.mapping_text = gvl.isocode5 ',
'                                     or mg.mapping_typ =2 and mg.mapping_text = gvl.iso_code3)',
'    where mg.landid is not null and v.vorschriftid = :P29_VORSCHRIFTID',
'    ',
unistr('    UNION  -- l\00E4nder aus Getex mit iso_code3, die nicht in  mapping tabelle sind und nicht ''ARE'''),
'    select distinct gvl.regindex_landid as regindex_landid, gvl.land_name, gvl.iso_code3 as getexisocode',
'    from t_vorschrift v',
'    join mv_getex_vorschrift_land gvl on (v.regindexid = gvl.v_id)',
'    where  v.vorschriftid = :P29_VORSCHRIFTID   and gvl.regindex_landid is null ',
'    and gvl.iso_code3 not in (select mapping_text from t_land_mapping_getex)',
'    and gvl.iso_code3 not in (''ARE'')',
unistr('), cte_are as ( -- Typ 3  ARE l\00E4nder'),
'    select distinct gvl.regindex_landid as regindex_landid, gvl.land_name, gvl.iso_code3 as getexisocode, gvl.b_number',
'    from t_vorschrift v',
'    join mv_getex_vorschrift_land gvl on (v.regindexid = gvl.v_id)',
'    join t_land l on (l.b_nummer = gvl.B_NUMBER)',
'    where  v.vorschriftid = :P29_VORSCHRIFTID   --and gvl.regindex_landid is null ',
'    and gvl.iso_code3  in (''ARE'') ',
'    )',
'select ',
'  case when cte_l.b_nummer = ''B93'' then ''nicht vorhanden''',
'        else    nvl(cte_rm.land_name,''<span class="hl">nicht vorhanden</span>'') end as getexlandname, ',
'  case when cte_l.b_nummer = ''B93'' then ''nicht vorhanden''',
'        else  nvl(cte_rm.getexisocode,''<span class="hl">nicht vorhanden</span>'') end as getexisocode,',
'    nvl(cte_l.land,''<span class="hl">nicht vorhanden</span>'') as regidnexlandname, nvl(cte_l.iso_code_3,''<span class="hl">nicht vorhanden</span>'') as regindexisocode3,',
'    cte_l.bemerkung',
'from cte_l',
'full outer join cte_rm on (cte_l.landid = cte_rm.regindex_landid)  --where cte_l.iso_code_3 is not  null',
'where (cte_rm.getexisocode  is not null or cte_l.iso_code_3 is not null) or cte_l.b_nummer =''B93''  --! AB Korrektur',
'UNION',
unistr('select  --  ARE l\00E4nder'),
'      nvl(cte_are.land_name,''<span class="hl">nicht vorhanden</span>'') as getexlandname, ',
'    nvl(cte_are.getexisocode,''nicht vorhanden'') as getexisocode,',
'    nvl(cte_l.land,''<span class="hl">nicht vorhanden</span>'') as regidnexlandname, nvl(cte_l.iso_code_3,''nicht vorhanden'') as regindexisocode3,',
'    cte_l.bemerkung',
'from cte_l',
'full outer join cte_are on (cte_l.b_nummer = cte_are.b_number) ',
'where cte_l.iso_code_3 is null and cte_are.getexisocode in (''ARE'')'))
,p_display_when_condition=>':P29_VORSCHRIFTTYPID_CALC != 20'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P29_VORSCHRIFTID,P29_LIST'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>200
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    tv.REGINDEXID AS LocalRegindexID,',
'    vgt.V_ID AS GetexVID,',
'    tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'    tvrt.THEMAID AS LocalThemaID,',
'    vgt.REGINDEX_THEMAID AS GetexThemaID,',
'    tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON tv.VORSCHRIFTID = tvrt.VORSCHRIFTID',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'    AND (',
'        (:P29_LIST = ''Alle'' AND (tvrt.THEMAID != vgt.REGINDEX_THEMAID OR tvrt.THEMAID IS NULL OR vgt.REGINDEX_THEMAID IS NULL))',
'        OR (:P29_LIST = ''Getex'' AND vgt.REGINDEX_THEMAID IS NOT NULL AND tvrt.THEMAID IS NULL)',
'        OR (:P29_LIST = ''Vorschrift'' AND tvrt.THEMAID IS NOT NULL AND vgt.REGINDEX_THEMAID IS NULL)',
'    );',
'',
'',
'',
'',
'',
'',
'',
'declare',
'l_value clob;',
'begin',
'if :P29_LIST =''Alle'' then',
'',
'l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
'full outer JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE tv.REGINDEXID IS NOT NULL',
'and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'',
'elsif :P29_LIST =''Vorschrift'' then',
'',
'l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
' left outer JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE tv.REGINDEXID IS NOT NULL',
'and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'   else',
'   l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
' V_GETEX_VORSCHRIFT_THEMA vgt',
' INNER JOIN',
'    T_VORSCHRIFT tv ON tv.REGINDEXID = vgt.V_ID',
'left outer join ',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID    ',
'WHERE tv.REGINDEXID IS NOT NULL',
' and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'end if;',
'return(l_value);',
'end;'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(672848432569442500)
,p_query_column_id=>1
,p_column_alias=>'GETEXLANDNAME'
,p_column_display_sequence=>60
,p_column_heading=>'Getex Land Name'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1019017781792583108)
,p_query_column_id=>2
,p_column_alias=>'GETEXISOCODE'
,p_column_display_sequence=>70
,p_column_heading=>'Getex ISO Code'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(672847543159442499)
,p_query_column_id=>3
,p_column_alias=>'REGIDNEXLANDNAME'
,p_column_display_sequence=>90
,p_column_heading=>'RegIndex Land Name'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(672847186887442499)
,p_query_column_id=>4
,p_column_alias=>'REGINDEXISOCODE3'
,p_column_display_sequence=>80
,p_column_heading=>'Regindex ISO Code3'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(653887055542692664)
,p_query_column_id=>5
,p_column_alias=>'BEMERKUNG'
,p_column_display_sequence=>100
,p_column_heading=>'Bemerkung'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(4840296975143663646)
,p_name=>'Fahrzeugart'
,p_parent_plug_id=>wwv_flow_imp.id(4838059380679153640)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>140
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_l as (',
'    select v.vorschriftid, v.regindexid, tvrf.fahrzeugklasseid, fk.bezeichnung as fzgklasse',
'    from t_vorschrift v',
'    join t_vorschrift_ref_fahrzeugklasse tvrf on (v.vorschriftid = tvrf.vorschriftid)',
'    join t_fahrzeugklasse fk on (tvrf.fahrzeugklasseid = fk.fahrzeugklasseid)',
'    where v.vorschriftid = :P29_VORSCHRIFTID',
'), cte_r as (',
'    select vgfz.fahrzeugklasseid, vgfz.fahrzeug_typ',
'    from t_vorschrift v',
'    join mv_getex_vorschrift_fz_typ vgfz on (v.regindexid = vgfz.v_id)',
'    where v.vorschriftid = :P29_VORSCHRIFTID',
')',
'select nvl(cte_l.fzgklasse, ''<span class="hl">nicht vorhanden</span>'') AS RegindexFahrzeugklasse, nvl(cte_r.FAHRZEUG_TYP, ''<span class="hl">nicht vorhanden</span>'') AS GetexFahrzeugklasseTyp',
'from cte_l',
'full outer join cte_r on (cte_l.fahrzeugklasseid = cte_r.fahrzeugklasseid)',
' --where cte_l.fahrzeugklasseid not in (1051, 1071, 1073)',
''))
,p_display_when_condition=>':P29_VORSCHRIFTTYPID_CALC != 20'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P29_VORSCHRIFTID,P29_LIST'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    tv.REGINDEXID AS LocalRegindexID,',
'    vgt.V_ID AS GetexVID,',
'    tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'    tvrt.THEMAID AS LocalThemaID,',
'    vgt.REGINDEX_THEMAID AS GetexThemaID,',
'    tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON tv.VORSCHRIFTID = tvrt.VORSCHRIFTID',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'    AND (',
'        (:P29_LIST = ''Alle'' AND (tvrt.THEMAID != vgt.REGINDEX_THEMAID OR tvrt.THEMAID IS NULL OR vgt.REGINDEX_THEMAID IS NULL))',
'        OR (:P29_LIST = ''Getex'' AND vgt.REGINDEX_THEMAID IS NOT NULL AND tvrt.THEMAID IS NULL)',
'        OR (:P29_LIST = ''Vorschrift'' AND tvrt.THEMAID IS NOT NULL AND vgt.REGINDEX_THEMAID IS NULL)',
'    );',
'',
'',
'',
'',
'',
'',
'',
'declare',
'l_value clob;',
'begin',
'if :P29_LIST =''Alle'' then',
'',
'l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
'full outer JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE tv.REGINDEXID IS NOT NULL',
'and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'',
'elsif :P29_LIST =''Vorschrift'' then',
'',
'l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
' left outer JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE tv.REGINDEXID IS NOT NULL',
'and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'   else',
'   l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
' V_GETEX_VORSCHRIFT_THEMA vgt',
' INNER JOIN',
'    T_VORSCHRIFT tv ON tv.REGINDEXID = vgt.V_ID',
'left outer join ',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID    ',
'WHERE tv.REGINDEXID IS NOT NULL',
' and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'end if;',
'return(l_value);',
'end;   d d'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(672842618278442469)
,p_query_column_id=>1
,p_column_alias=>'REGINDEXFAHRZEUGKLASSE'
,p_column_display_sequence=>80
,p_column_heading=>'Regindex Fahrzeugart'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(672842204988442469)
,p_query_column_id=>2
,p_column_alias=>'GETEXFAHRZEUGKLASSETYP'
,p_column_display_sequence=>50
,p_column_heading=>'Getex Fahrzeugart'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(4862444444657234436)
,p_name=>'Einsatzdaten'
,p_parent_plug_id=>wwv_flow_imp.id(4838059380679153640)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>150
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_daten_regindex as (',
'            -- Einsatzdatumsangaben aus RegIndex ',
'            select vorschriftid, vret.einsatzdatum_typid, einsatzdatum,  modeljahr, et.mapping_getex, et.einsatzdatum_typ',
'            from t_vorschrift_ref_einsatzdatum_typ vret',
'            join t_einsatzdatum_typ et on (vret.einsatzdatum_typid = et.einsatzdatum_typid)',
'            where vret.vorschriftid = :P29_VORSCHRIFTID --in (182, 199,331,17,356,1440,1443) --aVorschriftID ',
'            and et.mapping_getex is not null',
'            and vret.einsatzdatum_typid not in (1051, 1071, 1073)',
'        ), cte_daten_getex as (',
unistr('            -- Einsatzdatumsangaben aus GETEX - Schritt 1: Minimum \00FCber alle Themen holen '),
'            select v.vorschriftid, sc_type, trunc(min(sc_datum)) as sc_datum, sc_fahrzeug_typ',
'            from MV_GETEX_THEMA_SCENARIO g',
'            join t_vorschrift v on (g.v_id = v.regindexid)',
'            where sc_datum is not null and v.vorschriftid = :P29_VORSCHRIFTID  --in (182, 199,331,17,356,1440,1443) -- aVorschriftID ',
'            group by v.vorschriftid, sc_type, sc_fahrzeug_typ',
'        ), cte_daten_getex_mj as (',
unistr('            /* Einsatzdatumsangaben aus GETEX - Schritt 1: Minimum \00FCber alle Themen holen */'),
'            select v.vorschriftid, sc_type,  --sc_datum , --trunc(min(sc_datum)) as sc_datum,',
'            min(sc_year) as sc_year,     sc_fahrzeug_typ',
'            from MV_GETEX_THEMA_SCENARIO g',
'             join t_vorschrift v on (g.v_id = v.regindexid)',
'            where ( sc_year is not null) and v.vorschriftid =  :P29_VORSCHRIFTID ',
'            group by v.vorschriftid, sc_type, sc_fahrzeug_typ',
'        ), cte_daten_getex2 as (',
unistr('            -- Einsatzdatumsangaben aus GETEX - Schritt 2: Sortorder \00FCber Fahrzeugarten definieren '),
'            select c.*, case sc_fahrzeug_typ when ''PCV'' then 1 when ''INDEPENDENT'' then 2 else 3 end as sortorder',
'            from cte_daten_getex c',
'        ),',
'         cte_daten_getex2_mj as (',
unistr('            -- Einsatzdatumsangaben aus GETEX - Schritt 2: Sortorder \00FCber Fahrzeugarten definieren '),
'            select c_mj.*, case sc_fahrzeug_typ when ''PCV'' then 1 when ''INDEPENDENT'' then 2 else 3 end as sortorder',
'            from cte_daten_getex_mj c_mj',
'        ),',
'        cte_daten_getex3 as (',
unistr('            -- Einsatzdatumsangaben aus GETEX - Schritt 3: Auf Fahrzeugart mit h\00F6chster Priorit\00E4t limitieren '),
'            select distinct vorschriftid, sc_type, ',
'               first_value(to_char(sc_datum, ''dd.mm.yyyy'')) over (partition by sc_type order by sortorder) getex_einsatzdatum, ',
'               first_value(sc_fahrzeug_typ) over (partition by sc_type order by sortorder) as fahrzeugtyp',
'            from cte_daten_getex2',
'            UNION ',
'            select distinct vorschriftid, sc_type, ',
'               first_value(sc_year) over (partition by sc_type order by sortorder) getex_einsatzdatum, ',
'               first_value(sc_fahrzeug_typ) over (partition by sc_type order by sortorder) as fahrzeugtyp',
'            from cte_daten_getex2_mj',
'            ',
'        )            --, cte_vergleich as (    ',
'        select  ',
'            g.fahrzeugtyp as getex_fahrzeugtyp,',
'            g.getex_einsatzdatum  as getex_einsatzdatum,',
'            g.sc_type as getex_einsatzdatum_typ, ',
'            case when :P29_IS_GETEX_MJ =1 then',
'               to_char(r.modeljahr, ''yyyy'') ',
'            else',
'              to_char(r.einsatzdatum, ''dd.mm.yyyy'') end as regindex_einsatzdatum ,',
'            r.einsatzdatum_typ regindex_einsatzdatum_typ,',
'             case when ( g.getex_einsatzdatum != ',
'                         ( case when :P29_IS_GETEX_MJ = 1 then to_char(r.modeljahr, ''yyyy'') ',
'                                        else to_char(r.einsatzdatum, ''dd.mm.yyyy'') end )',
'                    or',
'                   ( g.getex_einsatzdatum is null and ( case when :P29_IS_GETEX_MJ =1 then r.modeljahr else  r.einsatzdatum end is not null )) or --',
'                     ( (g.getex_einsatzdatum is not null) and ( ',
'                     case when :P29_IS_GETEX_MJ =1 then r.modeljahr else r.einsatzdatum  end is null))',
'                ) then ''<span class="hl">''|| ''Ja'' || ''</span>'' else ''Nein'' end as diff',
'        from cte_daten_regindex r',
'        full outer join cte_daten_getex3 g on (r.mapping_getex = g.sc_type)',
'     ',
'/*',
'with cte_l as (',
'    SELECT distinct tve.einsatzdatum_typID, ',
'        ted.Einsatzdatum_typ, ',
'        to_char(tve.einsatzdatum, ''dd.mm.yyyy'') as Regindex_Einsatzdatum            ',
'    FROM T_VORSCHRIFT_REF_EINSATZDATUM_TYP tve',
'    join T_EINSATZDATUM_TYP ted on (ted.Einsatzdatum_TypID = tve.Einsatzdatum_TypID and ted.MAPPING_GETEX  is not null)',
'    join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tve.VORSCHRIFTid and tv.REGINDEXID is not null )',
'    WHERE     tv.VORSCHRIFTID  =:P29_VORSCHRIFTID',
'    and tve.einsatzdatum is not null  ',
'    and ted.Einsatzdatum_TYPID not in (1000, 1041, 1060, 1063)',
'), cte_r as (    ',
'    SELECT distinct ',
'        vgsc.SC_TYPE AS Getex_EinsatzdatumTyp,',
'        to_char(vgsc.sc_datum,''dd.mm.yyyy'') as Getex_Einsatzdatum,',
'        vgsc.sc_fahrzeug_typ as Getex_fahrzeug_typ,',
'        ted.einsatzdatum_typid',
'    FROM MV_GETEX_THEMA_SCENARIO vgsc',
'    join T_EINSATZDATUM_TYP ted on (ted.MAPPING_GETEX is not null and vgsc.sc_type is not null and ted.MAPPING_GETEX  = vgsc.sc_type)',
'    join T_VORSCHRIFT tv on ( tv.REGINDEXID is not null and tv.REGINDEXID = vgsc.v_id)',
'    WHERE     tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'    AND vgsc.sc_datum IS NOT NULL',
'    and vgsc.sc_fahrzeug_typ in (''INDEPENDENT'', ''PCV'')',
')',
'select distinct  --tv.VORSCHRIFT_NUMMER,',
'    nvl(cte_l.regindex_einsatzdatum, ''<span class="hl">nicht vorhanden</span>'') as Regindex_Einsatzdatum, ',
'    nvl(cte_l.Einsatzdatum_typ, ''<span class="hl">nicht vorhanden</span>'')  AS Regindex_Einsatzdatum_Typ, ',
'    nvl(cte_r.Getex_Einsatzdatum, ''<span class="hl">nicht vorhanden</span>'') as Getex_Einsatzdatum, ',
'    nvl(cte_r.Getex_EinsatzdatumTyp, ''<span class="hl">nicht vorhanden</span>'')  AS Getex_Einsatzdatum_Typ, ',
'    nvl(cte_r.getex_fahrzeug_typ, ''<span class="hl">nicht vorhanden</span>'') as Getex_fahrzeug_typ',
'from cte_l',
'full outer join cte_r on (cte_l.einsatzdatum_typid = cte_r.einsatzdatum_typid)',
'*/'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P29_VORSCHRIFTID,P29_LIST'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(672841515433442467)
,p_query_column_id=>1
,p_column_alias=>'GETEX_FAHRZEUGTYP'
,p_column_display_sequence=>10
,p_column_heading=>'Getex Fahrzeugtyp'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(672841038847442466)
,p_query_column_id=>2
,p_column_alias=>'GETEX_EINSATZDATUM'
,p_column_display_sequence=>40
,p_column_heading=>'Getex Einsatzdatum'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(672840649607442464)
,p_query_column_id=>3
,p_column_alias=>'GETEX_EINSATZDATUM_TYP'
,p_column_display_sequence=>20
,p_column_heading=>'Getex Einsatzdatum Typ'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(672840266430442461)
,p_query_column_id=>4
,p_column_alias=>'REGINDEX_EINSATZDATUM'
,p_column_display_sequence=>60
,p_column_heading=>'Regindex Einsatzdatum'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(672839932269442458)
,p_query_column_id=>5
,p_column_alias=>'REGINDEX_EINSATZDATUM_TYP'
,p_column_display_sequence=>50
,p_column_heading=>'Regindex Einsatzdatum Typ'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(672839461813442456)
,p_query_column_id=>6
,p_column_alias=>'DIFF'
,p_column_display_sequence=>70
,p_column_heading=>'Diff'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(658639285331621091)
,p_name=>'Inkraftsetzungsdatum'
,p_parent_plug_id=>wwv_flow_imp.id(4862444444657234436)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trunc(nvl(gv.REV_INFORCE_DATUM , null)) Getex_Inkraftsetzungsdatum, ',
'     trunc(nvl(vre.einsatzdatum, null)) Regindex_Inkraftsetzungsdatum ,',
'    case  when    gv.REV_INFORCE_DATUM  is null and vre.einsatzdatum is not null',
'            or gv.REV_INFORCE_DATUM  is not null and vre.einsatzdatum is null',
'            OR to_char(trunc(nvl(gv.REV_INFORCE_DATUM, null)),''dd.mm.yyyy'') !=  to_char(trunc(nvl(vre.einsatzdatum, null) ) ,''dd.mm.yyyy'') ',
'     then ''<span class="hl">''|| ''Ja'' || ''</span>'' else ''Nein'' end as diff',
'from T_VORSCHRIFT_REF_EINSATZDATUM_TYP  vre',
'full outer join T_Vorschrift v on (v.Vorschriftid = vre.Vorschriftid and vre.EINSATZDATUM_TYPID =1000)',
'join mV_GETEX_VORSCHRIFT gv on (gv.reg_id = v.regindexid)',
'where vre.vorschriftid = :P29_VORSCHRIFTID and rownum<2;',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(658638909108621087)
,p_query_column_id=>1
,p_column_alias=>'GETEX_INKRAFTSETZUNGSDATUM'
,p_column_display_sequence=>10
,p_column_heading=>'Getex Inkraftsetzungsdatum'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(658639097786621089)
,p_query_column_id=>2
,p_column_alias=>'REGINDEX_INKRAFTSETZUNGSDATUM'
,p_column_display_sequence=>20
,p_column_heading=>'Regindex Inkraftsetzungsdatum'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(658638983254621088)
,p_query_column_id=>3
,p_column_alias=>'DIFF'
,p_column_display_sequence=>40
,p_column_heading=>'Diff'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(653890863505692702)
,p_name=>'PhaseIn Enthalten'
,p_parent_plug_id=>wwv_flow_imp.id(4862444444657234436)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct case when nvl(gt.sc_PhaseInsIncluded,''false'') =''false'' then ''Nein'' else ''Ja'' end   as PhaseIn_Included_Getex,',
'',
'        case when nvl(v.phasein_enthalten, 0) = 0  then ',
'            (case when (nvl(gt.sc_PhaseInsIncluded,''false'') =''false''  ) then',
'                 ''Nein'' ',
'             else',
'                ''<span class="hl"> Nein </<span >''',
'             end )',
'        else ',
'            ( case when (nvl(gt.sc_PhaseInsIncluded,''false'') =''false''  ) then',
'                ''<span class="hl"> Ja </<span >''',
'             else',
'               ''Ja'' ',
'             end',
'            )',
'',
'        end   as PhaseIn_Included_Regindex',
'                ',
'from T_Vorschrift v',
' left outer join MV_GETEX_THEMA_SCENARIO gt on (v.regindexid = gt.v_id)',
'where v.vorschriftid = :P29_VORSCHRIFTID',
'order by 1, 2 asc  fetch first 1 rows only'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
' --not exists (select 1 from dual)',
' exists ( select 1 from t_Vorschrift v',
'                    join Mv_getex_vorschrift gt on (v.regindexid = gt.reg_id)',
'                    where v.vorschriftid = :P29_VORSCHRIFTID ',
'                    and (v.einsatzdatum_modellid =30 or gt.timelinedatetype=''MODELYEAR'' ))'))
,p_display_when_cond2=>'SQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(653890759786692701)
,p_query_column_id=>1
,p_column_alias=>'PHASEIN_INCLUDED_GETEX'
,p_column_display_sequence=>10
,p_column_heading=>'Phasein Included Getex'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(653890694134692700)
,p_query_column_id=>2
,p_column_alias=>'PHASEIN_INCLUDED_REGINDEX'
,p_column_display_sequence=>20
,p_column_heading=>'Phasein Included Regindex'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(4908071389219810554)
,p_name=>'Antriebsart'
,p_parent_plug_id=>wwv_flow_imp.id(4838059380679153640)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>130
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'with cte_l as (',
'    select a.bezeichnung, a.antriebsartid',
'    from t_vorschrift_ref_antriebsart vra',
'    join t_antriebsart a on (vra.antriebsartid = a.antriebsartid)',
'    where vra.vorschriftid = :P29_VORSCHRIFTID and vra.geloescht = 0',
'), cte_r as (',
'    select gva.antriebsart, gva.regindex_antriebsartid',
'    from t_vorschrift v',
'    join mv_getex_vorschrift_antriebsart gva on (v.regindexid = gva.v_id)',
'    where v.vorschriftid = :P29_VORSCHRIFTID',
')',
'select nvl(cte_l.bezeichnung,''<span class="hl">nicht vorhanden</span>'') as regindexantriebsartname, nvl(cte_r.antriebsart, ''<span class="hl">nicht vorhanden</span>'') as getexantriebsartname',
'from cte_l',
'full outer join cte_r on (cte_l.antriebsartid = cte_r.regindex_antriebsartid)'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- (:P29_VORSCHRIFTTYPID_CALC != 20);',
'(false)'))
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P29_VORSCHRIFTID,P29_LIST'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    tv.REGINDEXID AS LocalRegindexID,',
'    vgt.V_ID AS GetexVID,',
'    tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'    tvrt.THEMAID AS LocalThemaID,',
'    vgt.REGINDEX_THEMAID AS GetexThemaID,',
'    tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON tv.VORSCHRIFTID = tvrt.VORSCHRIFTID',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'    AND (',
'        (:P29_LIST = ''Alle'' AND (tvrt.THEMAID != vgt.REGINDEX_THEMAID OR tvrt.THEMAID IS NULL OR vgt.REGINDEX_THEMAID IS NULL))',
'        OR (:P29_LIST = ''Getex'' AND vgt.REGINDEX_THEMAID IS NOT NULL AND tvrt.THEMAID IS NULL)',
'        OR (:P29_LIST = ''Vorschrift'' AND tvrt.THEMAID IS NOT NULL AND vgt.REGINDEX_THEMAID IS NULL)',
'    );',
'',
'',
'',
'',
'',
'',
'',
'declare',
'l_value clob;',
'begin',
'if :P29_LIST =''Alle'' then',
'',
'l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
'full outer JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE tv.REGINDEXID IS NOT NULL',
'and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'',
'elsif :P29_LIST =''Vorschrift'' then',
'',
'l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
' left outer JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE tv.REGINDEXID IS NOT NULL',
'and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'   else',
'   l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
' V_GETEX_VORSCHRIFT_THEMA vgt',
' INNER JOIN',
'    T_VORSCHRIFT tv ON tv.REGINDEXID = vgt.V_ID',
'left outer join ',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID    ',
'WHERE tv.REGINDEXID IS NOT NULL',
' and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'end if;',
'return(l_value);',
'end;'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(672837974218442453)
,p_query_column_id=>1
,p_column_alias=>'REGINDEXANTRIEBSARTNAME'
,p_column_display_sequence=>50
,p_column_heading=>'Regindex Antriebsartname'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(672837547282442453)
,p_query_column_id=>2
,p_column_alias=>'GETEXANTRIEBSARTNAME'
,p_column_display_sequence=>30
,p_column_heading=>'Getex Antriebsartname'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(5556371643076413078)
,p_name=>'Kerndaten'
,p_parent_plug_id=>wwv_flow_imp.id(4838059380679153640)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>100
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'',
'    select 0 as sortorder, ''Vorschriftennummer'' as attribut, v.vorschrift_nummer as wert_regindex, gv.reg_num as wert_getex,',
'        emano_util.fIsUnequal(v.vorschrift_nummer, gv.reg_num) delta',
'    from t_vorschrift v',
'    join mv_getex_vorschrift gv on (v.regindexid = gv.reg_id)',
'    where v.vorschriftid = :P29_VORSCHRIFTID',
'',
'    union',
'',
'    select 1 as sortorder, ''Dokumentendatum'', to_char(v.dokumentendatum,''dd.mm.yyyy hh24:mi''), to_char(trunc(gv.rev_doc_datum),''dd.mm.yyyy hh24:mi''),',
'        emano_util.fIsUnequal(v.dokumentendatum, trunc(gv.rev_doc_datum)) delta',
'    from t_vorschrift v',
'    join mv_getex_vorschrift gv on (v.regindexid = gv.reg_id)',
'    where v.vorschriftid = :P29_VORSCHRIFTID',
'',
'    union',
'',
'    select 2 as sortorder, ''Document Type'', emano_util.flang(dt.text_deutsch, dt.text_englisch), gdt.document_type ,',
'        emano_util.fIsUnequal(dt.document_type, gdt.document_type) delta',
'    from t_vorschrift v',
'    left outer join t_document_type dt on (v.document_typeid = dt.document_typeid)',
'    join mv_getex_vorschrift gv on (v.regindexid = gv.reg_id)',
'    join mv_getex_vorschrift_document_type gdt on (gdt.reg_id = gv.reg_id)',
'    where v.vorschriftid = :P29_VORSCHRIFTID',
'',
'   /* select 2 as sortorder, ''Document Type'', emano_util.flang(dt.text_deutsch, dt.text_englisch), gv.rev_documenttype,',
'        emano_util.fIsUnequal(dt.document_type,gv.rev_documenttype) delta',
'    from t_vorschrift v',
'    left outer join t_document_type dt on (v.document_typeid = dt.document_typeid)',
'    join mv_getex_vorschrift gv on (v.regindexid = gv.reg_id)',
'    where v.vorschriftid = :P29_VORSCHRIFTID',
'    */',
'    union',
'',
'    select 3 as sortorder, ''Titel (Kurz)'', v.titel_kurz, gv.rev_shorttitle,',
'        emano_util.fIsUnequal(trim(v.titel_kurz), trim(gv.rev_shorttitle)) delta',
'    from t_vorschrift v',
'    join mv_getex_vorschrift gv on (v.regindexid = gv.reg_id)',
'    where v.vorschriftid = :P29_VORSCHRIFTID',
'',
'    union',
'',
'    select 4 as sortorder, ''Titel (lang)'', v.vorschrift_bezeichnung, gv.rev_title,',
'        emano_util.fIsUnequal(trim(v.vorschrift_bezeichnung), trim(gv.rev_title)) delta',
'    from t_vorschrift v',
'    join mv_getex_vorschrift gv on (v.regindexid = gv.reg_id)',
'    where v.vorschriftid = :P29_VORSCHRIFTID    ',
'',
'    union',
'',
'    select 5 as sortorder, ''Status der Vorschrift'', vs.status, gv.rev_v_status,',
'        emano_util.fIsUnequal(vs.mapping_getex, gv.rev_v_status) delta',
'    from t_vorschrift v',
'    join t_vorschrift_status vs on (v.vorschrift_statusid = vs.vorschrift_statusid)',
'    join mv_getex_vorschrift gv on (v.regindexid = gv.reg_id)',
'    where v.vorschriftid = :P29_VORSCHRIFTID     ',
'',
'    union',
'',
'    select 6 as sortorder, ''Einsatzdatum Modell'', em.modell , --nvl(gv.timelinedatetype,''EU''), ',
'          case  PCK_RI_GETEX_CTRL.fEinsatzDatumModellID(:P29_VORSCHRIFTID) when 30  then ''MODELYEAR'' when 20  then  ''CHINA'' else ''EU'' end modelid,',
'        emano_util.fIsUnequal(em.einsatzdatum_modellid, PCK_RI_GETEX_CTRL.fEinsatzDatumModellID(:P29_VORSCHRIFTID)) delta',
'        --emano_util.fIsUnequal(em.mapping_getex,nvl(gv.timelinedatetype,''EU''))',
'    from t_vorschrift v',
'    join t_einsatzdatum_modell em on (v.einsatzdatum_modellid = em.einsatzdatum_modellid)',
'    join mv_getex_vorschrift gv on (v.regindexid = gv.reg_id)',
'    where v.vorschriftid = :P29_VORSCHRIFTID',
'',
'  /*  select 6 as sortorder, ''Einsatzdatum Modell'', em.modell, nvl(gv.timelinedatetype,''EU''),',
'        emano_util.fIsUnequal(em.mapping_getex,nvl(gv.timelinedatetype,''EU''))',
'    from t_vorschrift v',
'    join t_einsatzdatum_modell em on (v.einsatzdatum_modellid = em.einsatzdatum_modellid)',
'    join mv_getex_vorschrift gv on (v.regindexid = gv.reg_id)',
'    where v.vorschriftid = :P29_VORSCHRIFTID ',
'`*/',
'    union',
'',
'    select 7 as sortorder, ''Vorschriftentyp<br /><i>Der Wert wird in Getex nicht erarbeitet;<br />dieser Wert wird in Regindex berechnet.</i>'', ',
'            emano_util.flang(vt_r.bezeichnung, vt_r.name_eng), emano_util.flang(vt_g.bezeichnung, vt_g.name_eng),',
'        emano_util.fIsUnequal(v.vorschrift_typid, pck_ri_getex_ctrl.fCalcVorTypID(v.regindexid)) delta',
'    from t_vorschrift v',
'    join t_vorschrift_typ vt_r on (v.vorschrift_typid = vt_r.vorschrift_typid)',
'    join t_vorschrift_typ vt_g on (vt_g.vorschrift_typid = pck_ri_getex_ctrl.fCalcVorTypID(v.regindexid))',
'    where v.vorschriftid = :P29_VORSCHRIFTID',
'    ',
'',
')',
'select attribut,',
'    case when delta = 1 then ''<span class="hl">'' end || wert_regindex || case when delta = 1 then ''</span>'' end as wert_regindex,',
'    case when delta = 1 then ''<span class="hl">'' end || wert_getex || case when delta = 1 then ''</span>'' end as wert_getex',
'from cte1',
'order by sortorder    '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(672836934438442450)
,p_query_column_id=>1
,p_column_alias=>'ATTRIBUT'
,p_column_display_sequence=>10
,p_column_heading=>'Attribut'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(672836498549442449)
,p_query_column_id=>2
,p_column_alias=>'WERT_REGINDEX'
,p_column_display_sequence=>30
,p_column_heading=>'Wert Regindex'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(672836124693442448)
,p_query_column_id=>3
,p_column_alias=>'WERT_GETEX'
,p_column_display_sequence=>20
,p_column_heading=>'Wert Getex'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4848118939814254839)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3148578499582251391)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3148578635267251393)
,p_button_name=>'Save_Comment'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Kommentar speichern'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--REGINDEXE-1376 extended by Id 21105,15643 -- 1021 was meant to be id 1000',
'-- or :G_BENUTZERID in (1021,21105,15643)',
'(pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1200'') > 0  )'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(672852873636442518)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4848118939814254839)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(672852508150442516)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4848118939814254839)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1200'') > 0  and :P29_MASTER in ( 20, 30) ) ',
'--REGINDEXE-1376 extended by Id 21105,15643 -- 1021 was meant to be id 1000',
'or :G_BENUTZERID in (1021,21105,15643)'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_comment=>'pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0 and pck_ri.fIsUserInRolle(listRolleId => ''1100'') = 0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3148579407463251400)
,p_name=>'P29_LAND_ERW_ANZEIGE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4838059380679153640)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_lnd_erweit as (',
'    select distinct gvl.v_id, v.vorschriftid ',
'    from mv_getex_vorschrift_land gvl  ',
'    join t_vorschrift v on (v.regindexid is not null and v.regindexid = gvl.v_id)',
'    join t_publisher p on (v.publisherid = p.publisherid)',
'    where nvl(p.ANZEIGE_MIT_DOKUMENTENDATUM, 10) = 20',
'    and v.vorschriftid = :P29_VORSCHRIFTID',
') ',
'select case when (select count(vorschriftid) from cte_lnd_erweit) > 0 then ''Ja'' else ''nein'' end as co from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 14 Jul 2025',
'',
'with  cte_lnd_erweit as (',
'      select  distinct gvl.v_id, v.vorschriftid ',
'      from mv_getex_vorschrift_land gvl  ',
'        join T_land la on (la.iso_code_3 = gvl.iso_code3 and la.cockpit_erw_anzeige >0)',
'        join t_vorschrift v on (v.regindexid is not null and v.regindexid = gvl.v_id)',
'        where nvl(la.cockpit_erw_anzeige, 0) > 0',
'        and v.vorschriftid = :P29_VORSCHRIFTID',
'',
' ) ',
' select case when (select count( vorschriftid) from cte_lnd_erweit) >0 then ''Ja'' else ''nein'' end as co from dual',
'',
'',
' 18jul',
' with cte_lnd_erweit as (',
'    select distinct gvl.v_id, v.vorschriftid ',
'    from mv_getex_vorschrift_land gvl  ',
'    join t_vorschrift v on (v.regindexid is not null and v.regindexid = gvl.v_id)',
'    join t_publisher p on (v.publisherid = p.publisherid)',
'    where nvl(p.ANZEIGE_MIT_DOKUMENTENDATUM, 10) = 20',
'    and v.vorschriftid = :P29_VORSCHRIFTID',
') ',
'select case when (select count(vorschriftid) from cte_lnd_erweit) > 0 then ''Ja'' else ''nein'' end as co from dual'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3148578560483251392)
,p_name=>'P29_KOMMENTAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3148578635267251393)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Kommentar'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  kommentar',
'from t_vorschrift v',
' join t_getex_kommentar gk on (gk.getex_key = v.regindexid)',
' where v.vorschriftid =:P29_VORSCHRIFTID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>130
,p_cHeight=>1
,p_colspan=>10
,p_read_only_when=>'(pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') = 0  ) '
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3136214478445152423)
,p_name=>'P29_AUSSER_KRAFT_APPLY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3136214537876152424)
,p_prompt=>unistr('Au\00DFerkraftsetzungsdatum')
,p_source=>'10'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', unistr('Nicht \00FCbernehmen'),
  'off_value', '20',
  'on_label', unistr('\00DCbernehmen'),
  'on_value', '10',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1539906870420101105)
,p_name=>'P29_VALIDATION_AUSSER_KRAFT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4838059380679153640)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lValidation varchar2(2000);',
'    lStatus number;',
'begin',
'    pDatumAusserKraft(:P29_VORSCHRIFTID, 10, lStatus, lValidation);',
'    return lValidation;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1088842719090580734)
,p_name=>'P29_CAMEFROM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(4838059380679153640)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_item_comment=>'REGINDEXE-1376'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1069005506727571885)
,p_name=>'P29_DIFF_ROWID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1069006533060571896)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(690612167913665775)
,p_name=>'P29_IS_GETEX_MJ'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(4838059380679153640)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'lret number :=0;',
'begin',
'    select count(*) --v.vorschriftid, sc_type,  --sc_datum , --trunc(min(sc_datum)) as sc_datum,',
'           -- min(sc_year) as sc_year,     sc_fahrzeug_typ',
'    into lret',
'    from MV_GETEX_THEMA_SCENARIO g',
'    join t_vorschrift v on (g.v_id = v.regindexid)',
'     where ( sc_year is not null) and v.vorschriftid =  :P29_VORSCHRIFTID ;',
'    ',
'    if (lret>0) then',
'        return 1;',
'    end if;',
'    return lret;',
'',
' end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(672851811100442515)
,p_name=>'P29_VORSCHRIFTID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(4838059380679153640)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(672851406961442513)
,p_name=>'P29_MASTER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(4838059380679153640)
,p_use_cache_before_default=>'NO'
,p_source=>'select master from t_vorschrift where vorschriftid = :P29_VORSCHRIFTID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(672850949541442513)
,p_name=>'P29_VORSCHRIFTNUMMER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(4838059380679153640)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Vorschriftnummer'
,p_source=>'select VORSCHRIFT_NUMMER from t_vorschrift where VORSCHRIFTID=:P29_VORSCHRIFTID;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(672850556785442513)
,p_name=>'P29_LIST'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(4838059380679153640)
,p_use_cache_before_default=>'NO'
,p_item_default=>'Alle'
,p_prompt=>'Liste'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>'STATIC2:Getex;Getex,Vorschrift;Vorschrift,Alle;Alle'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(672850224541442513)
,p_name=>'P29_VORSCHRIFTTYPID_CALC'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(4838059380679153640)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_getex_key varchar2(64);',
'begin',
'   select regindexid into l_getex_key from t_vorschrift where vorschriftid = :P29_VORSCHRIFTID;',
'   return  PCK_RI_GETEX_CTRL.fCalcVorTypID(l_getex_key);',
' end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(672839116721442455)
,p_name=>'P29_GETEX_IN_KRAFT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4862444444657234436)
,p_use_cache_before_default=>'NO'
,p_prompt=>'GETEX Inkraftsetzungsdatum'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select REV_INFORCE_DATUM from mV_GETEX_VORSCHRIFT',
'where reg_id = (select regindexid from t_vorschrift where vorschriftid = :P29_VORSCHRIFTID) ;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(672838702903442454)
,p_name=>'P29_REGINDEX_IN_KRAFT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(4862444444657234436)
,p_use_cache_before_default=>'NO'
,p_prompt=>'RegIndex Inkraftsetzungsdatum'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select einsatzdatum from T_VORSCHRIFT_REF_EINSATZDATUM_TYP ',
'where vorschriftid = :P29_VORSCHRIFTID  and EINSATZDATUM_TYPID =1000 and rownum<2;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(672832850928442444)
,p_name=>'Cancel Dialog'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(672852873636442518)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(672832387675442443)
,p_event_id=>wwv_flow_imp.id(672832850928442444)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1068909306602951434)
,p_name=>'sshow diff data'
,p_event_sequence=>150
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.cc_data_btn'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1068909125341951433)
,p_event_id=>wwv_flow_imp.id(1068909306602951434)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var virtualId = $(this.triggeringElement).data(''tId'');',
'//var courseNum = document.getElementById(virtualId);',
'console.log(virtualId);',
'//console.log($v(''virtualId'') );',
'//console.log(courseNum);',
'',
'$s(''P29_DIFF_ROWID'', virtualId);',
'',
'alert($v(''P29_DIFF_ROWID''));'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3148578351069251390)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Speichern kommentar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' merge into t_getex_kommentar gk',
'        using (',
'            select regindexid as getex_key , :P29_KOMMENTAR as kommentar ,  --:STATUS_DIFF as status_diff, ',
'                   0  as EINTRAG_FEHLERHAFT , pck_ri.fGetuserid as Bearbeiterid ',
'            from t_vorschrift',
'            where vorschriftid = :P29_VORSCHRIFTID and regindexid is not null',
'        ) u',
'        on (gk.getex_key = u.getex_key)',
'        when matched then update set kommentar = u.kommentar, kommentar_zeitpunkt = sysdate ,  --status_diff = :STATUS_DIFF , ',
'                                   bearbeiterid = u.Bearbeiterid',
'',
'        when not matched then insert (getex_key, kommentar, kommentar_zeitpunkt, ',
'                                 status_diff, EINTRAG_FEHLERHAFT,  BEARBEITERID )',
'                            values (u.getex_key, u.kommentar, sysdate,  ',
'                                      0,  0, u.Bearbeiterid);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(3148578499582251391)
,p_internal_uid=>523633964830136845
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(672834533282442445)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Fahrzeugklasse_Insert'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_count number;',
'begin',
'FOR I in (select tv.VORSCHRIFTID,',
'                 vgfz.FAHRZEUGKLASSEID',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    V_GETEX_VORSCHRIFT_FZ_TYP vgfz ON tv.REGINDEXID = vgfz.V_ID',
'WHERE tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   and vgfz.FAHRZEUGKLASSEID not in (select tvrfzz.FAHRZEUGKLASSEID from T_VORSCHRIFT_REF_FAHRZEUGKLASSE tvrfzz where tvrfzz.VORSCHRIFTID = tv.VORSCHRIFTID ',
'                                        and tvrfzz.VORSCHRIFTID = :P29_VORSCHRIFTID) ',
')',
'LOOP ',
'begin',
'select count(*) into l_count ',
'from T_VORSCHRIFT_REF_FAHRZEUGKLASSE where VORSCHRIFTID =:P29_VORSCHRIFTID and FAHRZEUGKLASSEID=i.FAHRZEUGKLASSEID;',
'exception when no_data_found then l_count:=0;',
'end;',
'',
'if l_count =0 then ',
'insert into T_VORSCHRIFT_REF_FAHRZEUGKLASSE',
'(',
'    VORSCHRIFTID,',
'    FAHRZEUGKLASSEID,',
'    LETZTE_AENDERUNG_DATUM,',
'    LETZTE_AENDERUNG_BENUTZERID',
'',
')',
'values( ',
'    :P29_VORSCHRIFTID,',
'    i.FAHRZEUGKLASSEID,',
'    sysdate,',
'    PCK_RI.fGetUserId',
'',
'',
');',
'end if;',
'end loop;',
'DELETE from T_VORSCHRIFT_REF_FAHRZEUGKLASSE where VORSCHRIFT_REF_FAHRZEUGKLASSEID  in (select VORSCHRIFT_REF_FAHRZEUGKLASSEID ',
'FROM',
'   T_VORSCHRIFT_REF_FAHRZEUGKLASSE tvrfz',
'INNER JOIN',
'    T_VORSCHRIFT tv  ON (tv.VORSCHRIFTID = tvrfz.VORSCHRIFTID)',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_FZ_TYP vgfz ON tv.REGINDEXID = vgfz.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'  AND tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'  AND (tvrfz.FAHRZEUGKLASSEID, tv.VORSCHRIFTID) NOT IN (SELECT FAHRZEUGKLASSEID, tva.VORSCHRIFTID FROM V_GETEX_VORSCHRIFT_FZ_TYP vgfzz INNER JOIN T_VORSCHRIFT tva ON tva.REGINDEXID = vgfzz.V_ID)',
');',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(672852508150442516)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2999377782616945790
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(672834843731442446)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Antriebsart_Insert'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_count number;',
'begin',
'FOR I in (select tv.VORSCHRIFTID,',
'                 vga.REGINDEX_ANTRIEBSARTID',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    V_GETEX_VORSCHRIFT_ANTRIEBSART vga ON tv.REGINDEXID = vga.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'   AND tv.VORSCHRIFTID =:P29_VORSCHRIFTID',
'   and vga.REGINDEX_ANTRIEBSARTID not in (select tvraa.ANTRIEBSARTID from T_VORSCHRIFT_REF_ANTRIEBSART tvraa where tvraa.VORSCHRIFTID = tv.VORSCHRIFTID ',
'                                            and tvraa.geloescht = 0 and tvraa.VORSCHRIFTID=:P29_VORSCHRIFTID)',
')',
'LOOP ',
'begin',
'select count(*) into l_count ',
'from T_VORSCHRIFT_REF_ANTRIEBSART where VORSCHRIFTID =:P29_VORSCHRIFTID and ANTRIEBSARTID=i.REGINDEX_ANTRIEBSARTID;',
'exception when no_data_found then l_count:=0;',
'end;',
'',
'if l_count =0 then ',
'insert into T_VORSCHRIFT_REF_ANTRIEBSART',
'(',
'    VORSCHRIFTID,',
'    ANTRIEBSARTID,',
'    GELOESCHT,',
'    LETZTE_AENDERUNG_DATUM,',
'    LETZTE_AENDERUNG_BENUTZERID',
'',
')',
'values( ',
'    :P29_VORSCHRIFTID,',
'    i.REGINDEX_ANTRIEBSARTID,',
'    0,',
'    sysdate,',
'    PCK_RI.fGetUserId',
'',
'',
');',
'else',
'UPDATE T_VORSCHRIFT_REF_ANTRIEBSART SET geloescht = 0  where VORSCHRIFTID =:P29_VORSCHRIFTID and ANTRIEBSARTID=i.REGINDEX_ANTRIEBSARTID;',
'end if;',
'end loop;',
'UPDATE T_VORSCHRIFT_REF_ANTRIEBSART SET geloescht = 1 WHERE VORSCHRIFT_REF_ANTRIEBSARTID IN (SELECT VORSCHRIFT_REF_ANTRIEBSARTID ',
'FROM',
'    T_VORSCHRIFT_REF_ANTRIEBSART tvra',
'INNER JOIN',
'    T_VORSCHRIFT tv ON (tv.VORSCHRIFTID = tvra.VORSCHRIFTID and tvra.geloescht = 0)',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'    AND (tvra.ANTRIEBSARTID, tv.VORSCHRIFTID) NOT IN (SELECT REGINDEX_ANTRIEBSARTID, tva.VORSCHRIFTID FROM V_GETEX_VORSCHRIFT_ANTRIEBSART vgaa ',
'                                                       INNER JOIN T_VORSCHRIFT tva ON tva.REGINDEXID = vgaa.V_ID ',
'                                                       AND tva.VORSCHRIFTID = :P29_VORSCHRIFTID)',
');',
'end;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(672852508150442516)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2999377472167945789
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(672835266549442446)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Land_Insert'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_count number;',
'begin',
'FOR I in (select tv.VORSCHRIFTID,',
'                 vgl.REGINDEX_LANDID',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    V_GETEX_VORSCHRIFT_LAND vgl ON tv.REGINDEXID = vgl.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   and vgl.REGINDEX_LANDID not in (select tvrll.LANDID from T_VORSCHRIFT_REF_LAND tvrll where tvrll.VORSCHRIFTID = tv.VORSCHRIFTID',
'                                    and tvrll.geloescht = 0 and tvrll.VORSCHRIFTID=:P29_VORSCHRIFTID )',
')',
'LOOP ',
'begin',
'select count(*) into l_count ',
'from T_VORSCHRIFT_REF_LAND where VORSCHRIFTID =:P29_VORSCHRIFTID and LANDID =i.REGINDEX_LANDID;',
'exception when no_data_found then l_count:=0;',
'end;',
'',
'if l_count =0 then ',
'insert into T_VORSCHRIFT_REF_LAND',
'(',
'    VORSCHRIFTID,',
'    LANDID,',
'    GELOESCHT,',
'    LETZTE_AENDERUNG_DATUM,',
'    LETZTE_AENDERUNG_BENUTZERID',
'',
')',
'values( ',
'    :P29_VORSCHRIFTID,',
'    i.REGINDEX_LANDID,',
'    0,',
'    sysdate,',
'    PCK_RI.fGetUserId',
'',
'',
');',
'else',
'UPDATE T_VORSCHRIFT_REF_LAND SET geloescht = 0  where VORSCHRIFTID =:P29_VORSCHRIFTID and LANDID=i.REGINDEX_LANDID;',
'end if;',
'end loop;',
'UPDATE T_VORSCHRIFT_REF_LAND SET geloescht = 1 WHERE VORSCHRIFT_REF_LANDID IN (SELECT VORSCHRIFT_REF_LANDID ',
'FROM',
'    T_VORSCHRIFT_REF_LAND tvrl',
'INNER JOIN',
'    T_VORSCHRIFT tv ON (tv.VORSCHRIFTID = tvrl.VORSCHRIFTID and tvrl.geloescht = 0)',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'    AND (tvrl.LANDID, tv.VORSCHRIFTID) NOT IN (SELECT REGINDEX_LANDID, tva.VORSCHRIFTID FROM V_GETEX_VORSCHRIFT_LAND vgll ',
'                                               INNER JOIN T_VORSCHRIFT tva ON tva.REGINDEXID = vgll.V_ID AND tva.VORSCHRIFTID = :P29_VORSCHRIFTID)',
');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(672852508150442516)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2999377049349945789
,p_process_comment=>'PCK_RI.fGetUserId'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(672834129402442445)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update GETEX_IMPORT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_count number;',
'begin',
'   UPDATE T_X_GETEX_IMPORT tgxi',
'      SET tgxi.STATUS = 2',
'    WHERE tgxi.GETEX_SCHLUESSEL = (',
'        SELECT tv.REGINDEXID',
'        FROM t_vorschrift tv',
'        WHERE tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'    );',
unistr('    -- set status:  \00DCbereinsimmung mit GETEX'),
'  update T_VORSCHRIFT set status_update_getex =10 , letzte_aenderung_getex_attr = sysdate',
'  WHERE  VORSCHRIFTID = :P29_VORSCHRIFTID;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(672852508150442516)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2999378186496945790
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(672833279605442444)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Abgleich vom Getex Process'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lStatus number;',
'    lValidation varchar2(2000);',
'begin',
'    if (:P29_VALIDATION_AUSSER_KRAFT is not null and nvl(:P29_AUSSER_KRAFT_APPLY,20) = 10) then',
'        pDatumAusserKraft(:P29_VORSCHRIFTID,20,lStatus,lValidation);',
'    end if;',
'end;',
'',
'',
'PCK_RI_GETEX_APPLY.pAbgleichRegIndexVomGetex(:P29_VORSCHRIFTID);',
'',
'PCK_RI_GETEX_COMPARE.pCompareVorschrift(:P29_VORSCHRIFTID);',
'Pck_ri.pResetVI(:P29_VORSCHRIFTID);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(672852508150442516)
,p_internal_uid=>2999379036293945791
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3182769305543391802)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>489443010355996433
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'REGINDEXE-1376',
'set server-side Condition on Never'))
);
wwv_flow_imp.component_end;
end;
/
