prompt --application/pages/page_00960
begin
--   Manifest
--     PAGE: 00960
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>960
,p_name=>'Matrixansicht Importeure / Cluster'
,p_alias=>'MATRIXANSICHT-IMPORTEURE-CLUSTER'
,p_step_title=>'Matrixansicht Importeure / Cluster'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--https://cdn.sheetjs.com/xlsx-0.20.0/package/dist/xlsx.full.min.js',
'#APP_FILES#xlsx.bundle.js'))
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var daten;',
'',
'',
'function test() {',
'    apex.server.process(',
'        ''getjson'',                           ',
'        { x01: 3 }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                ',
'                daten = pData;',
'',
'                gen();',
'                ',
'            },',
'            dataType: "json"                     ',
'        }',
'    );        ',
'}',
'',
'function textToWidth(text) {',
'    var ret = {};',
'',
'    try {',
unistr('        // H\00F6he = Anzahl der Line Breaks * 20'),
'        ret.h = (text.match(/\n/g) || []).length * 20;',
'',
unistr('        // Breite = L\00E4ngste Zeile '),
'        var arr = text.split("\n");',
'        var maxlength = 0;',
'        for (x in arr) {',
'            if (arr[x].length > maxlength) maxlength = arr[x].length;',
'        }',
'        ret.w = maxlength;',
'    } catch (error) {',
'        console.log(text);',
'        console.log(error);',
'    }',
'',
'',
'    return ret.w;',
'}',
'',
'',
'function colFit(sheet, rowStart, rowEnd, colStart, colEnd) {',
'',
'    let colLengths = [];',
'',
'    for (var col = colStart; col <= colEnd; col++) {',
'        var maxColLength = 0;',
'        for (var row = rowStart; row <= rowEnd; row++) {',
'            var address = XLSX.utils.encode_cell({c:col,r:row});            ',
'            var cell = sheet[address];',
'            try {',
'                //if (cell && cell.v && cell.v.length > maxColLength) maxColLength = cell.v.length;',
'                if (cell && cell.v) {',
'                    var length = textToWidth(cell.v);',
'                    if (length > maxColLength) maxColLength = length;',
'                }',
'            } catch (error) {',
'                console.log(''address not found: '' + address);',
'                console.log(error);',
'            }',
'        }',
'        colLengths[col] = {width:maxColLength};',
'    }',
'',
'    sheet[''!cols''] = colLengths;',
'',
'}',
'',
'function applyStyleToRange(sheet,style,range) {',
'',
'    for (var col = range.s.c; col <= range.e.c; col++) {',
'        for (var row = range.s.r; row <= range.e.r; row++) {',
'            var address = XLSX.utils.encode_cell({c:col,r:row});',
'            var cell = sheet[address];',
'            if (cell) {',
'                cell.s = style;',
'            } else {',
'                cell = {t:"s", v:"", s: style};',
'            }',
'            sheet[address] = cell;',
'            if (cell.t == "z") {',
'                cell.t = "s";',
'                cell.v = "";',
'            }',
'        }',
'    }    ',
'',
'}',
'',
'',
'function gen() {',
'',
'    const workbook = XLSX.utils.book_new();',
'    const thinBorder = { style:"thin", color: {rgb:"000000"}};',
'	const borderFull = { top: thinBorder, bottom: thinBorder, left: thinBorder, right: thinBorder};',
'',
'    for (land in daten) {',
'',
unistr('        // \00DCberschriftenzeile   '),
'        let sheet = XLSX.utils.aoa_to_sheet([["Export Importeure Matrixansicht - Land " + daten[land].land + " (" + daten[land].b_nummer + ")"]]);',
'        sheet["A1"].s = {',
'            font: {',
'                sz: 24,',
'                bold: true',
'            }',
'        };',
'',
'        sheet["!merges"] = [];        ',
'',
unistr('        // Die statischen ersten 3 \00DCberschriften'),
'        XLSX.utils.sheet_add_aoa(sheet,[["Konzern Cluster", "KVKO Namen", "KVKO Mails"]],{origin:"A3"});',
'        sheet["!merges"].push({s:{r:2,c:0},e:{r:3,c:0}});',
'        sheet["!merges"].push({s:{r:2,c:1},e:{r:3,c:1}});',
'        sheet["!merges"].push({s:{r:2,c:2},e:{r:3,c:2}});   ',
'',
'',
'        sheet["!rows"] = [];',
unistr('        sheet["!rows"][2] = {''hpt'' : 40}; // Ungef\00E4hr doppelte Standardzeilenh\00F6he'),
'',
'        for (imp in JSON.parse(daten[land].metadaten)) {',
'',
'            let importeur = JSON.parse(daten[land].metadaten)[imp];',
'            ',
'            // Zelle mit dem Namen des Importeurs',
'            let cell = { v: importeur.bezeichnung + "\n" + importeur.typ, t: "s", s: { alignment: { horizontal: "center", wrapText: true } } };',
'            XLSX.utils.sheet_add_aoa(sheet,[[cell]],{origin:{r:2,c:3+(2*imp)}});',
'            sheet["!merges"].push({s:{r:2,c:3+(2*imp)},e:{r:2,c:4+(2*imp)}});',
'',
'            // Zellen darunter',
'            XLSX.utils.sheet_add_aoa(sheet,[["R-VKO","E-Mail-Adressen"]],{origin:{r:3,c:3+(2*imp)}});',
'            ',
'        }',
'',
'        XLSX.utils.sheet_add_json(sheet,JSON.parse(daten[land].daten),{origin:"A5",skipHeader:true});',
'',
'        // in sheet[''!ref''] ist gespeichert, wie weit nach unten und nach rechts die Daten gehen',
'        var dim = XLSX.utils.decode_range(sheet[''!ref'']);',
'',
unistr('        // Grauer Hintergrund und fetter Text f\00FCr die beiden \00DCberschriftenzeilen'),
'        var s = { border: borderFull, alignment: { vertical: "center", wrapText: true }, fill: { fgColor: {rgb: "C0C0C0"}}, font: { bold: true}};',
'        applyStyleToRange(sheet,s,{s:{r:2,c:0},e:{r:3,c:dim.e.c}});',
'',
unistr('        // Formattierung f\00FCr die Inhaltszellen'),
'        s = { border: borderFull, alignment: { wrapText: true}};',
'        applyStyleToRange(sheet,s,{s:{r:4,c:0},e:{r:dim.e.r,c:dim.e.c}});',
'',
unistr('        // wir nutzen die Angaben, um geeignete Zellen f\00FCr die Berechnung der Spaltenbreiten auszuw\00E4hlen'),
'        colFit(sheet,3,dim.e.r,0,dim.e.c); ',
'',
'        var sheetName = (daten[land].b_nummer + ''-'' + daten[land].land).replace(''/'',''_'').substring(0,30);',
'        XLSX.utils.book_append_sheet(workbook,sheet,sheetName);',
'    }',
'    ',
'    XLSX.writeFile(workbook,''Test.xlsx'', {compression: true});',
'',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var arr;',
'try {',
'    arr = JSON.parse($v(''P960_SPOC''));',
'} catch (e) {',
'    arr = JSON.parse(''[]'');',
'}    ',
'',
'$(''spoc'').each(function() {',
'    var lImporteurid = $(this).text();',
'    var lSpocs = arr.find(element => element.importeurid == lImporteurid);',
'    if (typeof lSpocs === ''undefined'') {',
'        $(this).replaceWith();',
'    } else {',
'        $(this).replaceWith(''SPOCs: '' + lSpocs.spocs);',
'    }',
'});',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.linkimporteur { cursor: pointer }',
'',
'#importeure_matrix .t-Report-report td.t-Report-cell:not(:nth-child(2)) {',
'    border-left: 2px solid black;',
'}',
'',
'#importeure_matrix .t-Report-report th.t-Report-colHead:not(:nth-child(2)) {',
'    border-left: 2px solid black;',
'}',
'',
'#importeure_matrix .t-Report-report td.t-Report-cell:last-child {',
'    border-right: 2px solid black;',
'}',
'',
'#importeure_matrix .t-Report-report th.t-Report-colHead:last-child {',
'    border-right: 2px solid black;',
'}',
'',
'#importeure_matrix table.t-Report-report {',
'    border-top: 2px solid black;',
'    border-bottom: 2px solid black;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(373357789912312298)
,p_plug_name=>'Matrixansicht Importeure / Cluster'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(373357501211312295)
,p_name=>'New'
,p_region_name=>'importeure_matrix'
,p_parent_plug_id=>wwv_flow_imp.id(373357789912312298)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lLandid number := v(''P960_FILTER_LAND'');',
'begin    ',
'    return PCK_RI_IMPORTEUR.fGenMatrixSQL(:P960_FILTER_LAND);',
'end;'))
,p_display_when_condition=>'P960_FILTER_LAND'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_plug_query_max_columns=>20
,p_query_headings=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lReturn varchar2(2000) := ''Konzern Cluster:K-VKO'';',
'',
'begin',
'',
'',
'    for i in (',
'        select lpad(row_number() over (order by i.bezeichnung),2,''0'') as idx, irl.importeurid, i.bezeichnung, i.verantwortung_importeur',
'        from t_importeur_ref_land irl',
'        join t_importeur i on (irl.importeurid = i.importeurid)',
'        where landid = :P960_FILTER_LAND and i.is_deleted = 0',
'        order by i.bezeichnung',
'    ) loop',
'        lReturn := lReturn || '':'' || i.bezeichnung',
'        || '' <span title="Erweiterte Informationen zum Importeur" importeurid="'' || i.importeurid || ''" class="linkimporteur fa fa-info-square-o"></span>''',
'        || case i.verantwortung_importeur when 10 then ''<br />Lead-Importeur'' when 20 then ''<br />Support-Importeur'' end',
'        || ''<br /><spoc>'' || i.importeurid || ''</spoc>'';',
'    end loop;',
'    ',
'    return lReturn;',
'    ',
'        ',
'    ',
'end;    '))
,p_query_headings_type=>'FUNCTION_BODY_RETURNING_COLON_DELIMITED_LIST'
,p_query_num_rows=>100
,p_query_options=>'GENERIC_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337809421569290286)
,p_query_column_id=>1
,p_column_alias=>'COL01'
,p_column_display_sequence=>1
,p_column_heading=>'Konzern Cluster'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337809239429290285)
,p_query_column_id=>2
,p_column_alias=>'COL02'
,p_column_display_sequence=>2
,p_column_heading=>'K-VKO'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337809205451290284)
,p_query_column_id=>3
,p_column_alias=>'COL03'
,p_column_display_sequence=>3
,p_column_heading=>'Mail K-VKO'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337809104676290283)
,p_query_column_id=>4
,p_column_alias=>'COL04'
,p_column_display_sequence=>4
,p_column_heading=>'Col04'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337808970354290282)
,p_query_column_id=>5
,p_column_alias=>'COL05'
,p_column_display_sequence=>5
,p_column_heading=>'Col05'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337808854391290281)
,p_query_column_id=>6
,p_column_alias=>'COL06'
,p_column_display_sequence=>6
,p_column_heading=>'Col06'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337808809504290280)
,p_query_column_id=>7
,p_column_alias=>'COL07'
,p_column_display_sequence=>7
,p_column_heading=>'Col07'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337808734207290279)
,p_query_column_id=>8
,p_column_alias=>'COL08'
,p_column_display_sequence=>8
,p_column_heading=>'Col08'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337808610914290278)
,p_query_column_id=>9
,p_column_alias=>'COL09'
,p_column_display_sequence=>9
,p_column_heading=>'Col09'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337808493086290277)
,p_query_column_id=>10
,p_column_alias=>'COL10'
,p_column_display_sequence=>10
,p_column_heading=>'Col10'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337808356876290276)
,p_query_column_id=>11
,p_column_alias=>'COL11'
,p_column_display_sequence=>11
,p_column_heading=>'Col11'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337808321470290275)
,p_query_column_id=>12
,p_column_alias=>'COL12'
,p_column_display_sequence=>12
,p_column_heading=>'Col12'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337808185784290274)
,p_query_column_id=>13
,p_column_alias=>'COL13'
,p_column_display_sequence=>13
,p_column_heading=>'Col13'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337808075666290273)
,p_query_column_id=>14
,p_column_alias=>'COL14'
,p_column_display_sequence=>14
,p_column_heading=>'Col14'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337807969082290272)
,p_query_column_id=>15
,p_column_alias=>'COL15'
,p_column_display_sequence=>15
,p_column_heading=>'Col15'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337807891833290271)
,p_query_column_id=>16
,p_column_alias=>'COL16'
,p_column_display_sequence=>16
,p_column_heading=>'Col16'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337807800462290270)
,p_query_column_id=>17
,p_column_alias=>'COL17'
,p_column_display_sequence=>17
,p_column_heading=>'Col17'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337807729643290269)
,p_query_column_id=>18
,p_column_alias=>'COL18'
,p_column_display_sequence=>18
,p_column_heading=>'Col18'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337807543270290268)
,p_query_column_id=>19
,p_column_alias=>'COL19'
,p_column_display_sequence=>19
,p_column_heading=>'Col19'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337807522834290267)
,p_query_column_id=>20
,p_column_alias=>'COL20'
,p_column_display_sequence=>20
,p_column_heading=>'Col20'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(337806529269290257)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(373357789912312298)
,p_button_name=>'BUTTON_IMPORTEUR'
,p_button_static_id=>'button_importeur'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Button Importeur'
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:925:&SESSION.::&DEBUG.:925:P925_CAME_FROM:960'
,p_button_cattributes=>'style="display:none"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1065519449248676085)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(373357789912312298)
,p_button_name=>'EXPORT_DOWNLOAD'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Export Download'
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:0:&SESSION.:APPLICATION_PROCESS=downloadImporteureZip:&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(829555129670399355)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(373357789912312298)
,p_button_name=>'EXPORT_NEW'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Export (neu)'
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(373357638984312297)
,p_name=>'P960_FILTER_LAND'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(373357789912312298)
,p_prompt=>'Auswahl Land'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_LAENDER'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH cte1 AS (',
'    SELECT ',
'        l.b_nummer || '' - '' || ',
'        emano_util.fLang(land,land_eng) || '' ('' || count(irl.importeurid) || '')'' AS d, ',
'        l.b_nummer, ',
'        CASE ',
'            WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.land',
'            ELSE l.land_eng ',
'        END AS LandName, ',
'        l.landid',
'    FROM ',
'        t_land l',
'        JOIN t_importeur_ref_land irl ON (l.landid = irl.landid)',
'        JOIN t_importeur i ON (irl.importeurid = i.importeurid AND i.is_deleted = 0)',
'    WHERE ',
'        l.status_datenstand = 10',
'    GROUP BY ',
'        l.landid, l.b_nummer, ',
'        land, land_eng',
')',
'',
'SELECT cte1.*, flagge',
'FROM cte1',
'JOIN t_land l ON (l.landid = cte1.landid)',
'ORDER BY NLSSORT(cte1.B_NUMMER, ''NLS_SORT=BINARY_AI'') ASC',
''))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(337807416754290266)
,p_name=>'P960_IMPORTEURE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(373357789912312298)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select i.bezeichnung',
'        from t_importeur_ref_land irl',
'        join t_importeur i on (irl.importeurid = i.importeurid)',
'        where landid = :P960_FILTER_LAND',
'        order by i.bezeichnung'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(337806166653290254)
,p_name=>'P960_CLICKED_IMPORTEUR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(373357789912312298)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327614234743252397)
,p_name=>'P960_D_LAND'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(373357789912312298)
,p_use_cache_before_default=>'NO'
,p_prompt=>'D Land'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lBNummer varchar2(250);',
'    lLand varchar2(250);',
'    ',
'    ',
'begin',
'',
'    select b_nummer, land into lBNummer, lLand',
'    from t_land',
'    where landid = :P960_FILTER_LAND;',
'',
'    return ''<table><tr>',
'    <td>',
'    <img height=60 src="'' || apex_page.get_url(p_page => 0, p_items => ''G_LANDID'', p_values => :P960_FILTER_LAND, p_request => ''APPLICATION_PROCESS=getFlag'') || ''" />',
'    </td><td><h2>&nbsp;&nbsp;'' || lBNummer || '' - '' || lLand || ''</h2></td></tr></table>'';',
'',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>0
,p_display_when=>'P960_FILTER_LAND'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(3414144103148820565)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327613869141252394)
,p_name=>'P960_SPOC'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(373357789912312298)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    select importeurid, nachname, vorname, email_adresse',
'    from t_ansprechpartner ap',
'    where spoc = 10 and importeurid in (select importeurid from t_importeur_ref_land where landid = :P960_FILTER_LAND)',
'), cte2 as (',
'    select importeurid, listagg(vorname || '' '' || nachname || '' <a href="mailto:'' || email_adresse || ''"><span class="fa fa-envelope-o"></span></a>'','', '') within group (order by nachname) as spocs',
'    from cte1',
'    group by importeurid',
')',
'select json_arrayagg(json_object(importeurid,spocs))',
'from cte2'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P960_FILTER_LAND'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(327614811848252403)
,p_name=>'Open Importeur'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.linkimporteur'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(327614719398252402)
,p_event_id=>wwv_flow_imp.id(327614811848252403)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P960_CLICKED_IMPORTEUR'',$(this.triggeringElement).attr(''importeurid''));'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(327614556441252401)
,p_event_id=>wwv_flow_imp.id(327614811848252403)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P960_CLICKED_IMPORTEUR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(327614511942252400)
,p_event_id=>wwv_flow_imp.id(327614811848252403)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#button_importeur'').click();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(377366533160978241)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P960_FILTER_LAND'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(377366646999978242)
,p_event_id=>wwv_flow_imp.id(377366533160978241)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(829554937976399354)
,p_name=>'New_1'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(829555129670399355)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(929098929297280203)
,p_event_id=>wwv_flow_imp.id(829554937976399354)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'test()'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(781400114959132178)
,p_name=>unistr('Daten \00FCber Dialog ver\00E4ndert')
,p_event_sequence=>40
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(781400020746132177)
,p_event_id=>wwv_flow_imp.id(781400114959132178)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(373357501211312295)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(829555150440399356)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'getjson'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lDaten clob;',
'begin',
'    with cte1 as (',
'        select',
'            json_object(',
'                landid, b_nummer, land,',
'                ''daten'' value pck_ri_importeur.fGetMatrixData(landid),',
'                ''metadaten'' value pck_ri_importeur.fGetImporteurMetaData(landid) returning clob',
'            ) daten',
'        from t_land l',
'        --where landid in (1022,2141)',
'    )',
'    select json_arrayagg(daten returning clob) into lDaten',
'    from cte1;',
' ',
'    pck_ri_importeur.htpprn(lDaten);',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2842657165458988879
);
wwv_flow_imp.component_end;
end;
/
