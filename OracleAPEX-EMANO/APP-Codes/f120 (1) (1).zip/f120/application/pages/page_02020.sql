prompt --application/pages/page_02020
begin
--   Manifest
--     PAGE: 02020
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>2020
,p_name=>'Free VKO Report'
,p_alias=>'FREE-VKO-REPORT'
,p_step_title=>'Free VKO Report'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// $(''#ir_region_toolbar'').append($(''#P2020_SUPPLEMENTS_CONTAINER'')); // to set position',
'// $(''#P2020_SUPPLEMENTS_LABEL'').css(''display'', ''block''); // make item label as block',
'// $(''#P2020_SUPPLEMENTS_LABEL'').css(''white-space'', ''nowrap''); // disable wrapping',
'// $(''#ir_region_toolbar'').append($(''#refresh''));',
'// $(''#P20_SHORT'').detach().prependTo(''#VSIG div.a-IRR-buttons'').css(''margin-right'',''10px'').css(''margin-top'',''5px'');',
'// $(''#P2020_SUPPLEMENTS'').detach().prependTo(''#ir_region div.a-IRR-buttons'').css(''margin-right'',''10px'').css(''margin-top'',''5px'');',
'// $(''#refresh div.a-IRR-buttons'').css(''display'',''flex'').css(''justify-content'',''flex-end'');',
'// $(''#P20_SHORT_CONTAINER'').closest(''div.row'').remove();',
'// Move the refresh button to the end of the toolbar',
'',
'// .css(''margin-top'',''1px'').css(''margin-bottom'',''1px''));',
'// Optional: Add some margin to separate the elements',
'// .css(''margin-right'',''1px'')',
'$(''#P2020_FLAG_KF'').detach().prependTo(''#ir_region div.a-IRR-buttons'')',
'  .css(''margin-right'', ''10px'')',
'  .css(''margin-top'', ''-1px'');',
'',
'$(''#P2020_FLAG_KF_LABEL'').hide();',
'',
'$(''#P2020_STATUS_BEZ_CONTAINER'').detach()',
'  .insertBefore(''#P2020_FLAG_KF'')',
'  .css({',
'    ''display'': ''inline-block'', ',
'    ''visibility'': ''visible'', ',
'    ''margin-right'': ''10px'', ',
'    ''margin-top'': ''-1px'', ',
'    ''text-align'': ''right''',
'  });',
'',
'$(''#refresh'').detach().appendTo(''#ir_region div.a-IRR-buttons'');',
'',
unistr('$("label[for=''P2020_FLAG_KF_Y'']").attr(''title'', ''Blendet Vorschriften, die durch letztg\00FCltige Fassungen ersetzt worden sind, ein'');'),
unistr('$("label[for=''P2020_FLAG_KF_N'']").attr(''title'', ''Blendet Vorschriften, die durch letztg\00FCltige Fassungen ersetzt worden sind, aus'');'),
'',
'$(''#ir_region div.a-IRR-buttons'').css(''display'', ''flex'').css(''justify-content'', ''flex-end'');',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Form-itemWrapper .a-Button, .t-Form-itemWrapper .apex-item-display-only, .t-Form-itemWrapper .apex-item-multi, .t-Form-itemWrapper input, .t-Form-itemWrapper select, .t-Form-itemWrapper textarea {',
'    order: 3;',
'    border: none !important;',
'    /* --a-base-link-text-color: red; */',
'}',
'',
'.apex-item-display-only, ',
'.t-Form-itemWrapper ',
'.t-Form-itemWrapper input {',
'    order: 3;',
'    color: red !important;',
'    width: 225px !important;',
'}',
'',
'/* #P2020_STATUS_BEZ_CONTAINER{ position: absolute; right: 20px;} */'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(669647943043337967)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2707059584407204267)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3046604869386324778)
,p_plug_name=>'Free VKO Report : Letzte Aktualisierung - <b><u> &P2020_REFRESH_DATE_TIME.</u></b>'
,p_region_name=>'ir_region'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'  VORSCHRIFTID,',
'  VORSCHRIFT_NUMMER,',
'  VORSCHRIFT_BEZEICHNUNG,',
'  VORSCHRIFT_TYPID,',
'  PROGNOSE_QUALITAET,',
'  JIRA_TICKET,',
'  VORSCHRIFT_FREIGABESTATUSID,',
'  LINK_ZUR_VORSCHRIFT_DMS,',
'  MFV_ID,',
'  TYPSCHILD,',
'  WEBSITLINK,',
'  WEBSITE_HILFETEXT,',
'  KSU,',
'  LETZTE_AENDERUNG_DATUM,',
'  LETZTE_AENDERUNG_BENUTZER,',
'  LIST_LAND,',
'  ETB_AK,',
'  THEMENGEBIETE,',
'  VORSCHRIFT_STATUSID,',
'  RXSWIN_RELEVANT,',
'  KEINE_NORM_VALIDIERUNG,',
'  -- VERANTWORTLICHER,  -- ticket 1751',
'  MJ_PHASEIN_START,',
' -- MJ_PHASEIN_END,',
'  ALLE_FAHRZEUGE_FBU,',
'  ALLE_FAHRZEUGE_CKD,',
'  NEUE_TYPEN_FBU,',
'  NEUE_TYPEN_CKD,',
'  NEUE_TYPEN,',
'  ALLE_FAHRZEUGE,',
'  EINSATZDATUM_MODELLID,',
'  ANTRIEBSART,',
'  COP_RELEVANT,',
'  TECHNOLOGIE,',
'  SWR_HAUPTUMSETZENDE_OE,',
'  TICKETS,',
'  NOTATION,',
'  LISTE,',
'  HOMOLOGATIONSRELEVANT,',
'  REV_NOTWENDIG,',
'  AUSSERKRAFTSETZUNGSDATUM,',
'  DATUM_AUSSER_KRAFT_FBU,',
'  DATUM_AUSSER_KRAFT_CKD,',
'  INKRAFTSETZUNGSDATUM,',
'  VORGAENGER_VORSCHRIFT,',
'  EQUIVALENT_VORSCHRIFT,',
'  LEAD_VKO,',
'  MFV_THEMA,',
'  PCK_RI.fJiraTicketsToLinks(MFV_JIRA_TICKET_LINK) AS MFV_JIRA_TICKET_LINK,',
'  MFV_TEIL_BEZEICHNUNG,',
'  Nachfolgervorschrift,',
'  dokumentendatum,',
'  GROUP_CLUSTER_ID as GROUP_CLUSTER_ID, ',
'  GROUP_CLUSTER as GROUP_CLUSTER,',
'  PERMALINK,',
'  LIST_LANDID as LIST_LANDIDs,',
'    --   GETEX_STATUS,  ',
'    CASE ',
unistr('        WHEN GETEX_STATUS = 10 THEN ''Daten stimmen \00FCberein'''),
unistr('        WHEN GETEX_STATUS = 20 THEN ''Daten stimmen NICHT \00FCberein'''),
'        WHEN GETEX_STATUS = 30 THEN ''Es liegt keine GeTex Vorschrift vor''',
'    END AS GETEX_STATUS,',
'--   GETEX_URL,',
'  pck_ri.fcreateLinkIfUrl(GETEX_URL, 512) as GETEX_URL,',
'  CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN mv.BEMERKUNG_DE ELSE mv.BEMERKUNG_EN END BEMERKUNG,',
'nvl2("LINK_ZUR_VORSCHRIFT_GETEX", "LINK_ZUR_VORSCHRIFT_GETEX" || '' <a href="https://getex.wob.vw.vwg/web/guest/dokumente_suche" target="_blank">Getex 1.0 &ouml;ffnen</a>'', null) AS LINK_ZUR_VORSCHRIFT_GETEX,',
'case flag_konsolidierte_fassungen when 1 then ',
unistr('      ''<span title="Es existiert eine letztg\00FCltige Fassung, in welche diese \00C4nderungsvorschrift enthalten ist" class="fa fa-flag"></span>'' '),
'      else null end as flag_konsolidierte_fassungen,',
'',
'       ATVW_DOK,',
'    CODEBEAMER_DOK,',
'',
'',
'',
'      NOT_APPLICABLE_PCV,',
'  NOT_APPLICABLE_CKD_PCV,',
'  NOT_APPLICABLE_FBU_PCV,',
'  lrsa,',
'  KOMMENTAR_INHALTLICH_SACHLICH_GEPRUEFT',
'',
' from MV_FREE_VKO_REPORT mv',
'',
'where /*(vorschrift_typid in (10, 30, 40) -- Supplements nicht anzeigen',
'       or vorschrift_typid in (select case when (:P2020_SUPPLEMENTS = 20) then 20 else 0 end from dual)',
'       )',
'and*/ (',
unistr('    (vorschrift_freigabestatusid = 10 and pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002:1040:1006'') > 0) -- Wenn Status "in Bearbeitung" dann sichtbar f\00FCr Fachadmin, VKO, VEX, ZVEX, KFEX, GBEX'),
unistr('    or vorschrift_freigabestatusid = 20 -- Wenn Status "freigegeben", dann sichtbar f\00FCr alle'),
unistr('    or (vorschrift_freigabestatusid = 30 and pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0) -- Wenn Status "nicht relevant", dann sichtbar f\00FCr Fachadmin, VKO, VEX, ZVEX'),
')',
'AND (flag_konsolidierte_fassungen = 0 OR :P2020_FLAG_KF = 1)',
'ORDER BY  VORSCHRIFT_NUMMER',
'',
'',
'-- P20_SUPPLEMENTS',
'',
'/*',
'where (vs.vorschrift_typid in (10, 30, 40) -- Supplements nicht anzeigen',
'       or vs.vorschrift_typid in (select case when (:P20_SUPPLEMENTS = 20) then 20 else 0 end from dual)  --:P20_SUPPLEMENTS ',
'      )',
'and (',
unistr('    (vs.vorschrift_freigabestatusid = 10 and pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002:1040:1006'') > 0) -- Wenn Status "in Bearbeitung" dann sichtbar f\00FCr Fachadmin, VKO, VEX, ZVEX, KFEX, GBEX'),
unistr('    or vs.vorschrift_freigabestatusid = 20 -- Wenn Status "freigegeben", dann sichtbar f\00FCr alle'),
unistr('    or (vs.vorschrift_freigabestatusid = 30 and pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0) -- Wenn Status "nicht relevant", dann sichtbar f\00FCr Fachadmin, VKO, VEX, ZVEX'),
')',
'',
'ORDER BY  "VORSCHRIFT_NUMMER";',
'*/',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P2020_FLAG_KF'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(3046605215734324778)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'Keine Vorschriften gefunden.'
,p_oracle_text_index_column=>'VORSCHRIFT_NUMMER'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>910
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV'
,p_enable_mail_download=>'N'
,p_detail_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_detail_link_text=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_detail_link_condition_type=>'EXPRESSION'
,p_detail_link_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 25,',
'                      accessMode => 100))'))
,p_detail_link_cond2=>'PLSQL'
,p_description=>'<img src="#APEX_FILES#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>4159298152829459182
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1055139450581317487)
,p_db_column_name=>'PERMALINK'
,p_display_order=>10
,p_column_identifier=>'EN'
,p_column_label=>'Permalink'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781933444809819654)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>20
,p_column_identifier=>'BV'
,p_column_label=>'Vorschriften&shy;Nummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781882028494739703)
,p_db_column_name=>'VORSCHRIFT_BEZEICHNUNG'
,p_display_order=>30
,p_column_identifier=>'BW'
,p_column_label=>'Vorschriftentitel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781881846514739702)
,p_db_column_name=>'VORSCHRIFT_TYPID'
,p_display_order=>40
,p_column_identifier=>'BX'
,p_column_label=>'Vorschrift Typ'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(2656545044559578040)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781881784335739701)
,p_db_column_name=>'PROGNOSE_QUALITAET'
,p_display_order=>50
,p_column_identifier=>'BY'
,p_column_label=>'Prognose Qualitaet'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(958121403566083634)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781880404785739687)
,p_db_column_name=>'VORSCHRIFT_STATUSID'
,p_display_order=>60
,p_column_identifier=>'CM'
,p_column_label=>'Status der Vorschrift'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(2490458092659806028)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781881545362739699)
,p_db_column_name=>'VORSCHRIFT_FREIGABESTATUSID'
,p_display_order=>70
,p_column_identifier=>'CA'
,p_column_label=>'Interner Freigabe&shy;status'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(958129793570194302)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(905822622125296562)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Bemerkung zur Vorschrift Deutsch'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781880572709739689)
,p_db_column_name=>'ETB_AK'
,p_display_order=>90
,p_column_identifier=>'CK'
,p_column_label=>'ET-B AK'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781880656162739690)
,p_db_column_name=>'LIST_LAND'
,p_display_order=>100
,p_column_identifier=>'CJ'
,p_column_label=>unistr('L\00E4nder ')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781109816825218303)
,p_db_column_name=>'LINK_ZUR_VORSCHRIFT_GETEX'
,p_display_order=>110
,p_column_identifier=>'DP'
,p_column_label=>'Getex 1.0 ID'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781881159445739695)
,p_db_column_name=>'WEBSITLINK'
,p_display_order=>120
,p_column_identifier=>'CE'
,p_column_label=>'Link zu Web Site'
,p_column_html_expression=>'<span title="#WEBSITE_HILFETEXT#">#WEBSITLINK#</span>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781881530392739698)
,p_db_column_name=>'LINK_ZUR_VORSCHRIFT_DMS'
,p_display_order=>130
,p_column_identifier=>'CB'
,p_column_label=>'Link zu DMS'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781880903846739692)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>140
,p_column_identifier=>'CH'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781881262293739696)
,p_db_column_name=>'TYPSCHILD'
,p_display_order=>150
,p_column_identifier=>'CD'
,p_column_label=>'Typschild'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781881033644739693)
,p_db_column_name=>'KSU'
,p_display_order=>160
,p_column_identifier=>'CG'
,p_column_label=>'KSU'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781880817083739691)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>170
,p_column_identifier=>'CI'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781933729738819656)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>180
,p_column_identifier=>'BT'
,p_column_label=>'Vorschriftid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781881061112739694)
,p_db_column_name=>'WEBSITE_HILFETEXT'
,p_display_order=>190
,p_column_identifier=>'CF'
,p_column_label=>'Website Hilfetext'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781880476616739688)
,p_db_column_name=>'THEMENGEBIETE'
,p_display_order=>200
,p_column_identifier=>'CL'
,p_column_label=>'Themengebiete'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781880333860739686)
,p_db_column_name=>'RXSWIN_RELEVANT'
,p_display_order=>210
,p_column_identifier=>'CN'
,p_column_label=>'potentiell SW-Relevant'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(958135905312245351)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781878665599739670)
,p_db_column_name=>'SWR_HAUPTUMSETZENDE_OE'
,p_display_order=>220
,p_column_identifier=>'DD'
,p_column_label=>'Hauptumsetzende OE2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781879981375739683)
,p_db_column_name=>'MJ_PHASEIN_START'
,p_display_order=>230
,p_column_identifier=>'CQ'
,p_column_label=>'Einsatzzeitpunkt'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781879820439739681)
,p_db_column_name=>'ALLE_FAHRZEUGE_FBU'
,p_display_order=>250
,p_column_identifier=>'CS'
,p_column_label=>'Alle Fahrzeuge FBU'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781879709007739680)
,p_db_column_name=>'ALLE_FAHRZEUGE_CKD'
,p_display_order=>260
,p_column_identifier=>'CT'
,p_column_label=>'Alle Fahrzeuge CKD'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781879587773739679)
,p_db_column_name=>'NEUE_TYPEN_FBU'
,p_display_order=>270
,p_column_identifier=>'CU'
,p_column_label=>'Neue Typen FBU'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781879528937739678)
,p_db_column_name=>'NEUE_TYPEN_CKD'
,p_display_order=>280
,p_column_identifier=>'CV'
,p_column_label=>'Neue Typen CKD'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781879371259739677)
,p_db_column_name=>'NEUE_TYPEN'
,p_display_order=>290
,p_column_identifier=>'CW'
,p_column_label=>'Neue Typen'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781879260913739676)
,p_db_column_name=>'ALLE_FAHRZEUGE'
,p_display_order=>300
,p_column_identifier=>'CX'
,p_column_label=>'Alle Fahrzeuge'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781879190420739675)
,p_db_column_name=>'EINSATZDATUM_MODELLID'
,p_display_order=>310
,p_column_identifier=>'CY'
,p_column_label=>'Einsatzdatum Modellid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(1076773784946225404)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781879095551739674)
,p_db_column_name=>'ANTRIEBSART'
,p_display_order=>320
,p_column_identifier=>'CZ'
,p_column_label=>'Antriebsart'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781878947158739673)
,p_db_column_name=>'COP_RELEVANT'
,p_display_order=>330
,p_column_identifier=>'DA'
,p_column_label=>'Cop Relevant'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(958149357559525013)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781878863958739672)
,p_db_column_name=>'TECHNOLOGIE'
,p_display_order=>340
,p_column_identifier=>'DB'
,p_column_label=>'Technologie'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781878606219739669)
,p_db_column_name=>'TICKETS'
,p_display_order=>360
,p_column_identifier=>'DE'
,p_column_label=>'Konzerntickets'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781878457795739668)
,p_db_column_name=>'NOTATION'
,p_display_order=>370
,p_column_identifier=>'DF'
,p_column_label=>'Notation'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781878431449739667)
,p_db_column_name=>'LISTE'
,p_display_order=>380
,p_column_identifier=>'DG'
,p_column_label=>'Fahrzeugarten'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781877650296739660)
,p_db_column_name=>'EQUIVALENT_VORSCHRIFT'
,p_display_order=>390
,p_column_identifier=>'DN'
,p_column_label=>'Equivalent Vorschrift'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781881705099739700)
,p_db_column_name=>'JIRA_TICKET'
,p_display_order=>400
,p_column_identifier=>'BZ'
,p_column_label=>'Jira Ticket'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781877933399739662)
,p_db_column_name=>'INKRAFTSETZUNGSDATUM'
,p_display_order=>410
,p_column_identifier=>'DL'
,p_column_label=>'Inkraftsetzungsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781878278564739666)
,p_db_column_name=>'HOMOLOGATIONSRELEVANT'
,p_display_order=>420
,p_column_identifier=>'DH'
,p_column_label=>'Homologationsrelevant'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(767269734186787801)
,p_db_column_name=>'MFV_ID'
,p_display_order=>430
,p_column_identifier=>'DQ'
,p_column_label=>'Mfv Id'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(767269542873787800)
,p_db_column_name=>'KEINE_NORM_VALIDIERUNG'
,p_display_order=>440
,p_column_identifier=>'DR'
,p_column_label=>'Keine Norm Validierung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(767269493721787799)
,p_db_column_name=>'AUSSERKRAFTSETZUNGSDATUM'
,p_display_order=>450
,p_column_identifier=>'DS'
,p_column_label=>'Ausserkraftsetzungsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(767269421152787798)
,p_db_column_name=>'DATUM_AUSSER_KRAFT_FBU'
,p_display_order=>460
,p_column_identifier=>'DT'
,p_column_label=>'Datum Ausser Kraft Fbu'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(767269317551787797)
,p_db_column_name=>'DATUM_AUSSER_KRAFT_CKD'
,p_display_order=>470
,p_column_identifier=>'DU'
,p_column_label=>'Datum Ausser Kraft Ckd'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(767269213275787796)
,p_db_column_name=>'VORGAENGER_VORSCHRIFT'
,p_display_order=>480
,p_column_identifier=>'DV'
,p_column_label=>'Vorgaenger Vorschrift'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(684046256055613898)
,p_db_column_name=>'LEAD_VKO'
,p_display_order=>490
,p_column_identifier=>'DW'
,p_column_label=>'Lead VKO'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(669648386730337971)
,p_db_column_name=>'MFV_THEMA'
,p_display_order=>500
,p_column_identifier=>'DX'
,p_column_label=>'Thema MfV'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(669648306471337970)
,p_db_column_name=>'MFV_JIRA_TICKET_LINK'
,p_display_order=>510
,p_column_identifier=>'DY'
,p_column_label=>'MfV-Link'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(669648223089337969)
,p_db_column_name=>'MFV_TEIL_BEZEICHNUNG'
,p_display_order=>520
,p_column_identifier=>'DZ'
,p_column_label=>'MfV Teil'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(669648093463337968)
,p_db_column_name=>'NACHFOLGERVORSCHRIFT'
,p_display_order=>530
,p_column_identifier=>'EA'
,p_column_label=>'Nachfolgervorschrift'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(664860141791819601)
,p_db_column_name=>'GETEX_STATUS'
,p_display_order=>540
,p_column_identifier=>'ED'
,p_column_label=>'Getex Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(664860032891819599)
,p_db_column_name=>'GETEX_URL'
,p_display_order=>550
,p_column_identifier=>'EF'
,p_column_label=>'Getex Url'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(645329429850071802)
,p_db_column_name=>'REV_NOTWENDIG'
,p_display_order=>560
,p_column_identifier=>'EG'
,p_column_label=>'REV Notwendig'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(646432047862271176)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3182769431382391804)
,p_db_column_name=>'DOKUMENTENDATUM'
,p_display_order=>570
,p_column_identifier=>'EH'
,p_column_label=>'Dokumentendatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3146688430380981689)
,p_db_column_name=>'GROUP_CLUSTER_ID'
,p_display_order=>580
,p_column_identifier=>'EO'
,p_column_label=>'Group Cluster Id'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3146688343285981688)
,p_db_column_name=>'GROUP_CLUSTER'
,p_display_order=>590
,p_column_identifier=>'EP'
,p_column_label=>'Group Cluster'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1051430116326859595)
,p_db_column_name=>'LIST_LANDIDS'
,p_display_order=>600
,p_column_identifier=>'EQ'
,p_column_label=>unistr('Liste L\00E4nderIDs')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1043565227092189810)
,p_db_column_name=>'FLAG_KONSOLIDIERTE_FASSUNGEN'
,p_display_order=>610
,p_column_identifier=>'ER'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P2020_FLAG_KF'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(988041486457483329)
,p_db_column_name=>'ATVW_DOK'
,p_display_order=>620
,p_column_identifier=>'EV'
,p_column_label=>'ATVW Dok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(988041351062483328)
,p_db_column_name=>'CODEBEAMER_DOK'
,p_display_order=>630
,p_column_identifier=>'EW'
,p_column_label=>'Codebeamer Dok'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(988041224942483327)
,p_db_column_name=>'NOT_APPLICABLE_PCV'
,p_display_order=>640
,p_column_identifier=>'EX'
,p_column_label=>'Not Applicable Pcv'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(988041179094483326)
,p_db_column_name=>'NOT_APPLICABLE_CKD_PCV'
,p_display_order=>650
,p_column_identifier=>'EY'
,p_column_label=>'Not Applicable Ckd Pcv'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(988041050664483325)
,p_db_column_name=>'NOT_APPLICABLE_FBU_PCV'
,p_display_order=>660
,p_column_identifier=>'EZ'
,p_column_label=>'Not Applicable Fbu Pcv'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(992544645943674324)
,p_db_column_name=>'LRSA'
,p_display_order=>670
,p_column_identifier=>'FA'
,p_column_label=>'LRSA'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(988067035850880393)
,p_db_column_name=>'KOMMENTAR_INHALTLICH_SACHLICH_GEPRUEFT'
,p_display_order=>680
,p_column_identifier=>'FB'
,p_column_label=>unistr('Kommentar Inhaltlich Sachlich Gepr\00FCft')
,p_column_html_expression=>'<span style="display:block; width:200px"> #KOMMENTAR_INHALTLICH_SACHLICH_GEPRUEFT#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(3046612918813330130)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1982149'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PERMALINK:FLAG_KONSOLIDIERTE_FASSUNGEN:ATVW_DOK:CODEBEAMER_DOK:VORSCHRIFT_NUMMER:DOKUMENTENDATUM:VORSCHRIFT_BEZEICHNUNG:VORSCHRIFT_STATUSID:HOMOLOGATIONSRELEVANT:TICKETS:JIRA_TICKET:LINK_ZUR_VORSCHRIFT_DMS:LINK_ZUR_VORSCHRIFT_GETEX:WEBSITLINK:INKRAFT'
||'SETZUNGSDATUM:NEUE_TYPEN:ALLE_FAHRZEUGE:NEUE_TYPEN_FBU:ALLE_FAHRZEUGE_FBU:NEUE_TYPEN_CKD:ALLE_FAHRZEUGE_CKD:AUSSERKRAFTSETZUNGSDATUM:DATUM_AUSSER_KRAFT_FBU:DATUM_AUSSER_KRAFT_CKD:MJ_PHASEIN_START:BEMERKUNG:VORSCHRIFT_TYPID:PROGNOSE_QUALITAET:VORSCHRI'
||'FT_FREIGABESTATUSID:ETB_AK:LIST_LAND:LETZTE_AENDERUNG_DATUM:TYPSCHILD:KSU:LETZTE_AENDERUNG_BENUTZER:THEMENGEBIETE:RXSWIN_RELEVANT:SWR_HAUPTUMSETZENDE_OE:EINSATZDATUM_MODELLID:ANTRIEBSART:COP_RELEVANT:TECHNOLOGIE:NOTATION:LISTE:EQUIVALENT_VORSCHRIFT:K'
||'EINE_NORM_VALIDIERUNG:MFV_ID:MFV_TEIL_BEZEICHNUNG:MFV_JIRA_TICKET_LINK:MFV_THEMA:VORGAENGER_VORSCHRIFT:NACHFOLGERVORSCHRIFT:GETEX_STATUS:GETEX_URL:LEAD_VKO:GROUP_CLUSTER_ID:GROUP_CLUSTER:LIST_LANDIDS:NOT_APPLICABLE_CKD_PCV:NOT_APPLICABLE_FBU_PCV:NOT_'
||'APPLICABLE_PCV:LRSA:REV_NOTWENDIG:KOMMENTAR_INHALTLICH_SACHLICH_GEPRUEFT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(834277844302992771)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3046604869386324778)
,p_button_name=>'Refresh'
,p_button_static_id=>'refresh'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Auffrischen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1043266093001389494)
,p_name=>'P2020_FLAG_KF'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(669647943043337967)
,p_prompt=>'Flag konsolidierte Fassung vorhanden'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Wenn Benutzer VKO oder VEX ist, soll Schalter default auf einblenden',
'-- stehen, sonst auf ausblenden',
'if (pck_ri.fIsUserInRolle(listRolleId => ''1000:1002'') > 0) then',
'    return 1;',
'else',
'    return 0;',
'end if;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Normalansicht',
  'off_value', '0',
  'on_label', 'Detailansicht',
  'on_value', '1',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(767268786802787792)
,p_name=>'P2020_REFRESH_DATE_TIME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3046604869386324778)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'  TO_CHAR(LAST_REFRESH_DATE, ''DD.MM.YYYY HH24:MI'') AS REFRESH_DATE_TIME ',
'FROM USER_MVIEWS',
'WHERE MVIEW_NAME = ''MV_FREE_VKO_REPORT'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(765765352860497420)
,p_name=>'P2020_STATUS_BEZ'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(3046604869386324778)
,p_use_cache_before_default=>'NO'
,p_prompt=>'&nbsp;'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(765764516108489423)
,p_name=>'P2020_HIDDEN_REFRESH_ITEM'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(3046604869386324778)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(669647686220337964)
,p_name=>'P2020_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(669647943043337967)
,p_item_default=>':G_BENUTZERID'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(767265020608787754)
,p_name=>'change refresh item'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(762789143812349003)
,p_event_id=>wwv_flow_imp.id(767265020608787754)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'setInterval( ()=> { $s(''P2020_HIDDEN_REFRESH_ITEM'', ''refresh'') }, 4000 );',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(762788843008349000)
,p_name=>'NEW VERSION'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2020_HIDDEN_REFRESH_ITEM'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(762788798266348999)
,p_event_id=>wwv_flow_imp.id(762788843008349000)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_count number;',
'l_value varchar2(100);',
'begin',
'begin',
'SELECT count(*) into l_count',
'FROM USER_MVIEWS',
'WHERE MVIEW_NAME = ''MV_FREE_VKO_REPORT''',
'--and LAST_REFRESH_DATE> :P2020_REFRESH_DATE_TIME;',
'and TO_char(LAST_REFRESH_DATE, ''DD.MM.YYYY HH24:MI'') >:P2020_REFRESH_DATE_TIME;',
'exception when no_data_found then l_count :=0;',
'end;',
'if l_count >0 then ',
unistr('l_value:=''Neue Version Verf\00FCgbar!'';'),
'',
'else',
'l_value :=null;',
'end if;',
':P2020_STATUS_BEZ := l_value;',
'--:P2020_STATUS_BEZ :=null;',
'--end if;',
'end;'))
,p_attribute_02=>'P2020_REFRESH_DATE_TIME'
,p_attribute_03=>'P2020_STATUS_BEZ'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(762788445669348996)
,p_name=>'change item position'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(762788397038348995)
,p_event_id=>wwv_flow_imp.id(762788445669348996)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#ir_region_toolbar'').append($(''#P2020_STATUS_BEZ_CONTAINER'')); // to set position',
'$(''#P2020_STATUS_BEZ_LABEL'').css(''display'', ''block''); // make item label as block',
'$(''#P2020_STATUS_BEZ_LABEL'').css(''white-space'', ''nowrap''); // disable wrapping'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(669647909270337966)
,p_name=>'switch supplements'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2020_SUPPLEMENTS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(669647815707337965)
,p_event_id=>wwv_flow_imp.id(669647909270337966)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3046604869386324778)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1043265880812387465)
,p_name=>'Switch Filter'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2020_FLAG_KF'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1043265505851387435)
,p_event_id=>wwv_flow_imp.id(1043265880812387465)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3046604869386324778)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(765746327468359313)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Refresh_Materialized_View'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  --  pck_ri.P_REFRESH_MV_FREE_VKO_REPORT_AND_MV_VORSCHRIFTEN_LANG_VERSION_REPORT;',
'   DBMS_MVIEW.REFRESH(''MV_FREE_VKO_REPORT'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(834277844302992771)
,p_internal_uid=>2906465988431028922
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3095362920116678206)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Aktualisiere ORA Text Suche Indexe'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    CTX_DDL.SYNC_INDEX(''MV_FREE_VKO_EXTENDED_IDX'');',
'    CTX_DDL.SYNC_INDEX(''MV_FREE_VKO_BEZEICHNUNG_IDX'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(834277844302992771)
,p_internal_uid=>576849395782710029
);
wwv_flow_imp.component_end;
end;
/
