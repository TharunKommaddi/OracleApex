prompt --application/pages/page_00630
begin
--   Manifest
--     PAGE: 00630
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>630
,p_name=>'GETEX_VORSCHRIFTEN'
,p_alias=>'GETEX-VORSCHRIFTEN'
,p_step_title=>'GETEX_VORSCHRIFTEN'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(894397435956846278)
,p_plug_name=>'GETEX_VORSCHRIFTEN'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select V_id as Vorschrift_ident, ',
'V_nummer as Vorschrift_nummer, ',
'v_status as Vorschrift_status, ',
'--v_publ_id as Vorschrift_publ_id, ',
'--v_publ_typ as Vorschrift_publ_typ, ',
'--v_publ_name as Vorschrift_publ_name, ',
'--v_timelineDateType as Vorschrift_timeline_Datentyp,',
'rev_id as revision_id, --correctionCounter as Korrektur_zaehler, ',
'--rev_Datum as revision_datum,  ',
'rev_v_nummer as revision_vorschrift_nummer, ',
'rev_v_status as revision_vorschrift_status, ',
'rev_title as revision_vorschrift_titel, ',
'rev_current as revision_current,',
'rev_doc_datum as revision_document_datum, ',
'rev_inForce_datum as revision_inForce_datum, ',
'rev_inForce_estimated as revision_inForce_estimated, ',
'rev_documentType as revision_document_Typ,',
'--rev_fahrzeug_typ as revision_fahrzeug_typ,',
'--rev_antriebsart as revision_antriebsart, ',
'rev_sourceType as revision_sourceType, ',
'rev_importDatum as revision_importDatum, ',
'rev_regIndexId as revision_regIndexId',
'from V_GETEX_VORSCHRIFT'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'GETEX_VORSCHRIFTEN'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(894397280818846278)
,p_name=>'GETEX_VORSCHRIFTEN'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>218295656276288126
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(894387451679630103)
,p_db_column_name=>'VORSCHRIFT_IDENT'
,p_display_order=>10
,p_column_identifier=>'H'
,p_column_label=>'Vorschrift Ident'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(894387398490630102)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>20
,p_column_identifier=>'I'
,p_column_label=>'Vorschrift Nummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(894387318969630101)
,p_db_column_name=>'VORSCHRIFT_STATUS'
,p_display_order=>30
,p_column_identifier=>'J'
,p_column_label=>'Vorschrift Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(894386794587630096)
,p_db_column_name=>'REVISION_ID'
,p_display_order=>80
,p_column_identifier=>'O'
,p_column_label=>'Revision Id'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(894386474846630093)
,p_db_column_name=>'REVISION_VORSCHRIFT_NUMMER'
,p_display_order=>110
,p_column_identifier=>'Q'
,p_column_label=>'Revision Vorschrift Nummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(894386358547630092)
,p_db_column_name=>'REVISION_VORSCHRIFT_STATUS'
,p_display_order=>120
,p_column_identifier=>'R'
,p_column_label=>'Revision Vorschrift Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(894386294919630091)
,p_db_column_name=>'REVISION_VORSCHRIFT_TITEL'
,p_display_order=>130
,p_column_identifier=>'S'
,p_column_label=>'Revision Vorschrift Titel'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(894386201779630090)
,p_db_column_name=>'REVISION_CURRENT'
,p_display_order=>140
,p_column_identifier=>'T'
,p_column_label=>'Revision Aktuell'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(894386077709630089)
,p_db_column_name=>'REVISION_DOCUMENT_DATUM'
,p_display_order=>150
,p_column_identifier=>'U'
,p_column_label=>'Revision Document Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(894385985196630088)
,p_db_column_name=>'REVISION_INFORCE_DATUM'
,p_display_order=>160
,p_column_identifier=>'V'
,p_column_label=>'Revision In_Kraft Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(894385914667630087)
,p_db_column_name=>'REVISION_INFORCE_ESTIMATED'
,p_display_order=>170
,p_column_identifier=>'W'
,p_column_label=>unistr('Revision In_Kraft Gesch\00E4tzt')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(894385785586630086)
,p_db_column_name=>'REVISION_DOCUMENT_TYP'
,p_display_order=>180
,p_column_identifier=>'X'
,p_column_label=>'Revision Document Typ'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(894385525354630083)
,p_db_column_name=>'REVISION_SOURCETYPE'
,p_display_order=>210
,p_column_identifier=>'AA'
,p_column_label=>'Revision Sourcetype'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(894385345807630082)
,p_db_column_name=>'REVISION_IMPORTDATUM'
,p_display_order=>220
,p_column_identifier=>'AB'
,p_column_label=>'Revision Importdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(894385336406630081)
,p_db_column_name=>'REVISION_REGINDEXID'
,p_display_order=>230
,p_column_identifier=>'AC'
,p_column_label=>'Revision Regindexid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(894388615898716227)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2183044'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'VORSCHRIFT_STATUS:VORSCHRIFT_NUMMER:REVISION_REGINDEXID:REVISION_VORSCHRIFT_NUMMER:REVISION_VORSCHRIFT_STATUS:REVISION_VORSCHRIFT_TITEL:REVISION_CURRENT:REVISION_DOCUMENT_TYP:REVISION_DOCUMENT_DATUM:REVISION_IMPORTDATUM:REVISION_INFORCE_DATUM:REVISIO'
||'N_INFORCE_ESTIMATED:REVISION_SOURCETYPE'
);
wwv_flow_imp.component_end;
end;
/
