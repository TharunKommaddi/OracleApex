prompt --application/pages/page_00820
begin
--   Manifest
--     PAGE: 00820
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>820
,p_name=>'Vorschriften Report equal'
,p_alias=>'VORSCHRIFTEN-REPORT-EQUAL'
,p_step_title=>'Vorschriften Report equal'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1805308394386488573)
,p_plug_name=>'Vorschriften Report equal'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select LOCAL_VORSCHRIFT, PERMALINK, VORSCHRIFTID,  EQUAL_VORSCHRIFT, PERMALINK_EQUAL, VORSCHRIFTID_EQUAL,',
'CASE ',
'    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN "LAND"',
'    ELSE "LAND_ENG" ',
'END AS Land,',
'B_NUMMER,  AK_KURZ, tgliste',
'from v_vorschrift_equal'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_page_header=>'Vorschriften Report equal'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1805308504113488573)
,p_name=>'Vorschriften Report equal'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>2918001441208622977
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571950446806216766)
,p_db_column_name=>'LOCAL_VORSCHRIFT'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Local Vorschrift'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571950108356216765)
,p_db_column_name=>'PERMALINK'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Permalink'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571949714155216765)
,p_db_column_name=>'EQUAL_VORSCHRIFT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Equal Vorschrift'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571949260098216765)
,p_db_column_name=>'PERMALINK_EQUAL'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Permalink Equal'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571951328437216766)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>14
,p_column_identifier=>'E'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_column_linktext=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571950924188216766)
,p_db_column_name=>'VORSCHRIFTID_EQUAL'
,p_display_order=>24
,p_column_identifier=>'F'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID_EQUAL#'
,p_column_linktext=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(337573139476263202)
,p_db_column_name=>'B_NUMMER'
,p_display_order=>44
,p_column_identifier=>'H'
,p_column_label=>unistr('L\00E4nder (B-Nummern)')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(337573133267263201)
,p_db_column_name=>'AK_KURZ'
,p_display_order=>54
,p_column_identifier=>'I'
,p_column_label=>'AK'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(962880170644665169)
,p_db_column_name=>'LAND'
,p_display_order=>64
,p_column_identifier=>'L'
,p_column_label=>unistr('L\00E4nder (Klarname)')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(802046310095551781)
,p_db_column_name=>'TGLISTE'
,p_display_order=>74
,p_column_identifier=>'M'
,p_column_label=>unistr('Zu pr\00FCfende Themengebiete')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1805325972214517573)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5407440'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'VORSCHRIFTID:B_NUMMER:LAND:LOCAL_VORSCHRIFT:PERMALINK:VORSCHRIFTID_EQUAL:EQUAL_VORSCHRIFT:PERMALINK_EQUAL:AK_KURZ:TGLISTE:'
);
wwv_flow_imp.component_end;
end;
/
