prompt --application/pages/page_00060
begin
--   Manifest
--     PAGE: 00060
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>60
,p_name=>'SRA-Group_VKO_Delta'
,p_alias=>'SRA-GROUP-VKO-DELTA'
,p_step_title=>'SRA-Group_VKO_Delta'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function initializeDateTooltips() {',
'    apex.jQuery(".date-tooltip").tooltip({',
'        show: { effect: "fade", delay: 100 },',
'        hide: { effect: "fade", delay: 100 },',
'        track: true,',
'        position: { ',
'            my: "left+10 top+25",',
'            at: "right bottom",',
'            collision: "flipfit"',
'        }',
'    });',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'initializeDateTooltips()',
'',
'$(''#rSRA_gruppen_heading '').append('' <span onclick="redirect(1700)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(988069274167880415)
,p_plug_name=>'SRA Gruppen Abgleich'
,p_region_name=>'rSRA_gruppen'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11657932018089327711)
,p_plug_name=>'VKO'
,p_parent_plug_id=>wwv_flow_imp.id(988069274167880415)
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3521973109136027635)
,p_name=>'VKO in SRA-Gruppe(n), die nicht im VKO-VEX-Register eingetragen sind'
,p_parent_plug_id=>wwv_flow_imp.id(11657932018089327711)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'with cte_VKO_reg as ( select  distinct akrb.benutzerid,  b.nachname nachname, b.vorname vorname, b.abteilung abteilung, b.gid gid',
'                   from T_ET_B_AK_REF_BENUTZER akrb',
'                   join T_BENUTZER b on (b.benutzerid = akrb.benutzerid)  --  order by b.nachname',
')',
'',
' select  nachname,  vorname, abteilung, gid, sra_liste from T_SRA_BENUTZER where  SRA_GROUP =''VKO''',
' and gid not in (select gid from cte_vko_reg where gid is not null)'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024139767024991911)
,p_query_column_id=>1
,p_column_alias=>'NACHNAME'
,p_column_display_sequence=>10
,p_column_heading=>'Nachname'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024139332430991910)
,p_query_column_id=>2
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>20
,p_column_heading=>'Vorname'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024138976858991910)
,p_query_column_id=>3
,p_column_alias=>'ABTEILUNG'
,p_column_display_sequence=>30
,p_column_heading=>'Abteilung'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024138524121991910)
,p_query_column_id=>4
,p_column_alias=>'GID'
,p_column_display_sequence=>40
,p_column_heading=>'Gid'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024138191213991909)
,p_query_column_id=>5
,p_column_alias=>'SRA_LISTE'
,p_column_display_sequence=>50
,p_column_heading=>'Gruppe(n)'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(11657663168693792523)
,p_name=>'VKO von SRA Gruppe, die keine VKO Rechte in Regindex haben '
,p_parent_plug_id=>wwv_flow_imp.id(11657932018089327711)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--with cte1 as (    select /*+ materialize */ column_value as dn from koala_util.fGetGroupmembers(''AUDI_SRA_41384'')  --  VKO ',
'--              UNION',
'--               select /*+ materialize */ column_value as dn from koala_util.fGetGroupmembers(''AUDI_SRA_42067'')',
'--),  ',
'--cte2 as (  select *  from cte1  where dn != ''cn=dummy''  ',
'--),',
'',
'with cte_ri as( select b.nachname nachname, b.vorname vorname , b.abteilung abteilung, b.GID GID',
'            from T_Benutzer b ',
'            join T_benutzer_ref_rolle brr on (brr.benutzerid =b.benutzerid and brr.rolleid=1000 ) --and b.status=10)',
')',
' --select k.surname nachname, k.givenname vorname, k.subdepartment abteilung, k.gid gid ',
' --  from cte2, koala_util.fSearchDN(cte2.dn) k     ',
'select  nachname,  vorname, abteilung, gid from T_SRA_BENUTZER where  SRA_GROUP =''VKO''',
'minus',
'(select  nachname,  vorname, abteilung,  GID  from cte_ri  )',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('keine Eintr\00E4ge vorhanden')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024137503063991908)
,p_query_column_id=>1
,p_column_alias=>'NACHNAME'
,p_column_display_sequence=>1
,p_column_heading=>'Nachname'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024137061368991907)
,p_query_column_id=>2
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>2
,p_column_heading=>'Vorname'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024136678608991907)
,p_query_column_id=>3
,p_column_alias=>'ABTEILUNG'
,p_column_display_sequence=>4
,p_column_heading=>'Abteilung'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024136230050991907)
,p_query_column_id=>4
,p_column_alias=>'GID'
,p_column_display_sequence=>3
,p_column_heading=>'Gid'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(11657931499137327706)
,p_name=>'VKO von Regindex, die keine VKO Rechte in SRA Gruppe haben '
,p_parent_plug_id=>wwv_flow_imp.id(11657932018089327711)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--with cte1 as ( select /*+ materialize */ column_value as dn from koala_util.fGetGroupmembers(''AUDI_SRA_41384'') ',
'--                UNION',
'--               select /*+ materialize */ column_value as dn from koala_util.fGetGroupmembers(''AUDI_SRA_42067'')),  ',
'--cte2 as (  select *  from cte1  where dn != ''cn=dummy''  ',
'--),',
'with cte_ri as(  select b.nachname nachname, b.vorname vorname , b.abteilung abteilung, b.GID GID',
'              from T_Benutzer b ',
'            join T_benutzer_ref_rolle brr on (brr.benutzerid =b.benutzerid and brr.rolleid=1000 and b.status=10)',
')',
'select nachname,  vorname,  GID from cte_ri',
' minus',
'(select  nachname,  vorname,  gid  from T_SRA_BENUTZER where  SRA_GROUP =''VKO'' )    ',
' order by 1 ',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('keine Eintr\00E4ge vorhanden')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024135605113991906)
,p_query_column_id=>1
,p_column_alias=>'NACHNAME'
,p_column_display_sequence=>1
,p_column_heading=>'Nachname'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024135189650991906)
,p_query_column_id=>2
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>2
,p_column_heading=>'Vorname'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024134776844991906)
,p_query_column_id=>3
,p_column_alias=>'GID'
,p_column_display_sequence=>3
,p_column_heading=>'Gid'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(11657933738127327728)
,p_name=>'VKO von Regindex VKO-Register, die nicht VKO Rechte in SRA Gruppe haben '
,p_parent_plug_id=>wwv_flow_imp.id(11657932018089327711)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--with cte1 as ( select /*+ materialize */ column_value as dn from koala_util.fGetGroupmembers(''AUDI_SRA_41384'') ',
'--                UNION',
'--               select /*+ materialize */ column_value as dn from koala_util.fGetGroupmembers(''AUDI_SRA_42067'')),  ',
'--cte2 as (  select *  from cte1  where dn != ''cn=dummy''  ',
'--),',
'with cte_VKO_reg as ( select  distinct akrb.benutzerid,  b.nachname nachname, b.vorname vorname, b.abteilung abteilung, b.gid gid',
'                   from T_ET_B_AK_REF_BENUTZER akrb',
'                   join T_BENUTZER b on (b.benutzerid = akrb.benutzerid)  --  order by b.nachname',
')',
'select nachname,  vorname, abteilung, GID from cte_VKO_reg',
' minus',
'--(select  k.surname nachname, k.givenname vorname, k.subdepartment abteilung,  k.gid gid ',
' --from cte2, koala_util.fSearchDN(cte2.dn) k)   ',
' select  nachname,  vorname, abteilung, gid  from T_SRA_BENUTZER where  SRA_GROUP =''VKO''',
' order by 1 ',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('keine Eintr\00E4ge vorhanden')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024134020043991905)
,p_query_column_id=>1
,p_column_alias=>'NACHNAME'
,p_column_display_sequence=>1
,p_column_heading=>'Nachname'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024133712163991905)
,p_query_column_id=>2
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>2
,p_column_heading=>'Vorname'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024133292777991904)
,p_query_column_id=>3
,p_column_alias=>'ABTEILUNG'
,p_column_display_sequence=>3
,p_column_heading=>'Abteilung'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024132903020991904)
,p_query_column_id=>4
,p_column_alias=>'GID'
,p_column_display_sequence=>4
,p_column_heading=>'Gid'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11657932084267327712)
,p_plug_name=>'VEX'
,p_parent_plug_id=>wwv_flow_imp.id(988069274167880415)
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3521973687597027641)
,p_name=>'VEX in SRA-Gruppe(n), die nicht im VKO/VEX-Register eingetragen sind'
,p_parent_plug_id=>wwv_flow_imp.id(11657932084267327712)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_verantwortliche as (',
'    select distinct    b.nachname nachname, b.vorname vorname, b.abteilung abteilung,  b.gid gid',
'    from t_et_b_ak_ref_thema_benutzer aktb',
'    left outer join t_rolle r on r.rolleid = aktb.rolleid',
'    left outer join t_benutzer_ref_rolle brf on brf.benutzer_ref_rolleid = aktb.benutzer_ref_rolleid',
'    left outer join t_benutzer b on b.benutzerid = brf.benutzerid',
'    --left outer join t_benutzer leb on leb.benutzerid = aktb.letzte_aenderung_benutzerid',
'    where r.rolleid = 1002 and b.nachname is not null',
')',
' select  nachname,  vorname, abteilung, gid, sra_liste from T_SRA_BENUTZER where  SRA_GROUP =''VEX''',
'and gid not in (select gid from cte_verantwortliche where gid is not null)',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024156325431991925)
,p_query_column_id=>1
,p_column_alias=>'NACHNAME'
,p_column_display_sequence=>10
,p_column_heading=>'Nachname'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024155934951991924)
,p_query_column_id=>2
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>20
,p_column_heading=>'Vorname'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024155556132991924)
,p_query_column_id=>3
,p_column_alias=>'ABTEILUNG'
,p_column_display_sequence=>30
,p_column_heading=>'Abteilung'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024155134744991924)
,p_query_column_id=>4
,p_column_alias=>'GID'
,p_column_display_sequence=>40
,p_column_heading=>'Gid'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024154780830991924)
,p_query_column_id=>5
,p_column_alias=>'SRA_LISTE'
,p_column_display_sequence=>50
,p_column_heading=>'Gruppe(n)'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(11657930489511327696)
,p_name=>'VEX von SRA Gruppe, die keine VEX Rechte in Regindex haben '
,p_parent_plug_id=>wwv_flow_imp.id(11657932084267327712)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--with cte1 as (  select /*+ materialize */ column_value as dn from koala_util.fGetGroupmembers(''AUDI_SRA_44360'')  -- VEX',
'--              UNION',
'--               select /*+ materialize */ column_value as dn from koala_util.fGetGroupmembers(''AUDI_SRA_45063'')',
'--),  ',
'--cte2 as ( select distinct * from cte1  where dn != ''cn=dummy''  ',
'--) ,',
'with cte_ri as( select b.nachname nachname, b.vorname vorname, b.abteilung abteilung, b.GID GID',
'          from T_Benutzer b ',
'         join T_benutzer_ref_rolle brr on (brr.benutzerid =b.benutzerid and brr.rolleid= 1002) ',
')',
'--select  k.surname nachname, k.givenname vorname, k.subdepartment abteilung, k.gid gid ',
'--from cte2, koala_util.fSearchDN(cte2.dn) k      ',
' select  nachname,  vorname, abteilung, gid  from T_SRA_BENUTZER where  SRA_GROUP =''VEX''',
'minus',
'select   nachname,   vorname,     abteilung,   gid from cte_ri',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('keine Eintr\00E4ge vorhanden')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024154062422991923)
,p_query_column_id=>1
,p_column_alias=>'NACHNAME'
,p_column_display_sequence=>1
,p_column_heading=>'Nachname'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024153652400991923)
,p_query_column_id=>2
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>2
,p_column_heading=>'Vorname'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024153230382991922)
,p_query_column_id=>3
,p_column_alias=>'ABTEILUNG'
,p_column_display_sequence=>3
,p_column_heading=>'Abteilung'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024152848718991922)
,p_query_column_id=>4
,p_column_alias=>'GID'
,p_column_display_sequence=>4
,p_column_heading=>'Gid'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(11657932258735327713)
,p_name=>'VEX von Regindex, die keine VEX Rechte in SRA Gruppe haben '
,p_parent_plug_id=>wwv_flow_imp.id(11657932084267327712)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--with cte1 as (  select /*+ materialize */ column_value as dn from koala_util.fGetGroupmembers(''AUDI_SRA_44360'')  -- VEX',
'--              UNION',
'--               select /*+ materialize */ column_value as dn from koala_util.fGetGroupmembers(''AUDI_SRA_45063'')',
'--),  ',
'--cte2 as ( select distinct * from cte1  where dn != ''cn=dummy''  ',
'--),',
'with cte_ri as( select b.nachname nachname, b.vorname vorname , b.abteilung abteilung, b.GID GID',
'          from T_Benutzer b ',
'         join T_benutzer_ref_rolle brr on (brr.benutzerid =b.benutzerid and brr.rolleid=1002)',
')',
'select nachname,  vorname , abteilung,  GID  from cte_ri',
' minus',
'--select  k.surname nachname, k.givenname vorname, k.subdepartment abteilung,  k.gid gid ',
'--  from cte2, koala_util.fSearchDN(cte2.dn) k      ',
' select  nachname,  vorname, abteilung, gid  from T_SRA_BENUTZER where  SRA_GROUP =''VEX''',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('keine Eintr\00E4ge vorhanden')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024152159260991921)
,p_query_column_id=>1
,p_column_alias=>'NACHNAME'
,p_column_display_sequence=>1
,p_column_heading=>'Nachname'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024151799068991921)
,p_query_column_id=>2
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>2
,p_column_heading=>'Vorname'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024151316763991921)
,p_query_column_id=>3
,p_column_alias=>'ABTEILUNG'
,p_column_display_sequence=>3
,p_column_heading=>'Abteilung'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024150933514991920)
,p_query_column_id=>4
,p_column_alias=>'GID'
,p_column_display_sequence=>4
,p_column_heading=>'Gid'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(11657934195322327733)
,p_name=>'VEX von Regindex VEX Register, die keine VEX Rechte in SRA Gruppe haben '
,p_parent_plug_id=>wwv_flow_imp.id(11657932084267327712)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_verantwortliche as (',
'    select distinct    b.nachname nachname, b.vorname vorname, b.abteilung abteilung,  b.gid gid',
'    from t_et_b_ak_ref_thema_benutzer aktb',
'    left outer join t_rolle r on r.rolleid = aktb.rolleid',
'    left outer join t_benutzer_ref_rolle brf on brf.benutzer_ref_rolleid = aktb.benutzer_ref_rolleid',
'    left outer join t_benutzer b on b.benutzerid = brf.benutzerid',
'    --left outer join t_benutzer leb on leb.benutzerid = aktb.letzte_aenderung_benutzerid',
'    where r.rolleid = 1002 and b.nachname is not null',
')',
'select nachname, vorname, abteilung, gid from cte_verantwortliche',
' minus',
'--select  k.surname nachname, k.givenname vorname, k.subdepartment abteilung,  k.gid gid ',
'--  from cte2, koala_util.fSearchDN(cte2.dn) k      ',
' select  nachname,  vorname, abteilung, gid  from T_SRA_BENUTZER where  SRA_GROUP =''VEX''',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('keine Eintr\00E4ge vorhanden')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024150260507991919)
,p_query_column_id=>1
,p_column_alias=>'NACHNAME'
,p_column_display_sequence=>1
,p_column_heading=>'Nachname'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024149851192991919)
,p_query_column_id=>2
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>2
,p_column_heading=>'Vorname'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024149506523991919)
,p_query_column_id=>3
,p_column_alias=>'ABTEILUNG'
,p_column_display_sequence=>3
,p_column_heading=>'Abteilung'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024149098107991919)
,p_query_column_id=>4
,p_column_alias=>'GID'
,p_column_display_sequence=>4
,p_column_heading=>'Gid'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11657932715373327718)
,p_plug_name=>'FbEx'
,p_parent_plug_id=>wwv_flow_imp.id(988069274167880415)
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3521974270644027647)
,p_name=>'FBEX in SRA-Gruppe(n), die nicht im VKO/VEX-Register eingetragen sind'
,p_parent_plug_id=>wwv_flow_imp.id(11657932715373327718)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--WITH cte1 AS ( select /*+ materialize */ column_value as dn from koala_util.fGetGroupmembers(''AUDI_SRA_44030'') ',
'--), ',
'--cte2 as (  select *  from cte1   where dn != ''cn=dummy''   ',
'--),',
'with cte_verantwortliche as (',
'    select distinct    b.nachname nachname, b.vorname vorname, b.abteilung abteilung,  b.gid gid',
'    from t_et_b_ak_ref_thema_benutzer aktb',
'    left outer join t_rolle r on r.rolleid = aktb.rolleid',
'    left outer join t_benutzer_ref_rolle brf on brf.benutzer_ref_rolleid = aktb.benutzer_ref_rolleid',
'    left outer join t_benutzer b on b.benutzerid = brf.benutzerid',
'    --left outer join t_benutzer leb on leb.benutzerid = aktb.letzte_aenderung_benutzerid',
'    where r.rolleid = 1006 and b.nachname is not null',
')',
'select  nachname,  vorname, abteilung, gid , sra_liste from T_SRA_BENUTZER',
'where  SRA_GROUP =''FBEX''',
'and gid not in (select gid from cte_verantwortliche where gid is not null)',
'order by 1  '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024148038491991918)
,p_query_column_id=>1
,p_column_alias=>'NACHNAME'
,p_column_display_sequence=>10
,p_column_heading=>'Nachname'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024147630624991917)
,p_query_column_id=>2
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>20
,p_column_heading=>'Vorname'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024147292993991917)
,p_query_column_id=>3
,p_column_alias=>'ABTEILUNG'
,p_column_display_sequence=>30
,p_column_heading=>'Abteilung'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024146909151991917)
,p_query_column_id=>4
,p_column_alias=>'GID'
,p_column_display_sequence=>40
,p_column_heading=>'Gid'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024146445300991917)
,p_query_column_id=>5
,p_column_alias=>'SRA_LISTE'
,p_column_display_sequence=>50
,p_column_heading=>'Gruppe(n)'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(11657931014819327701)
,p_name=>'FbEx von SRA Gruppe, die keine FbEx Rechte in Regindex haben '
,p_parent_plug_id=>wwv_flow_imp.id(11657932715373327718)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--WITH cte1 AS ( select /*+ materialize */ column_value as dn from koala_util.fGetGroupmembers(''AUDI_SRA_44030'') ',
'--), ',
'--cte2 as (  select *  from cte1  where dn != ''cn=dummy''   ',
'--),',
'with cte_ri as( select b.nachname nachname, b.vorname vorname , b.abteilung abteilung, b.GID GID',
'                from T_Benutzer b ',
'            join T_benutzer_ref_rolle brr on (brr.benutzerid =b.benutzerid and brr.rolleid = 1006)',
')   ',
'--SELECT   k.surname nachname, k.givenname vorname, k.subdepartment abteilung, k.gid gid ',
' -- from cte2, koala_util.fSearchDN(cte2.dn) k    ',
'  select  nachname,  vorname, abteilung, gid  from T_SRA_BENUTZER where  SRA_GROUP =''FBEX''',
' minus',
'( SELECT nachname,  vorname , abteilung, GID from cte_ri ) -- FbEx   ',
'order by 1   '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('keine Eintr\00E4ge vorhanden')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024145759683991916)
,p_query_column_id=>1
,p_column_alias=>'NACHNAME'
,p_column_display_sequence=>1
,p_column_heading=>'Nachname'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024145411105991916)
,p_query_column_id=>2
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>2
,p_column_heading=>'Vorname'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024144987502991915)
,p_query_column_id=>3
,p_column_alias=>'ABTEILUNG'
,p_column_display_sequence=>3
,p_column_heading=>'Abteilung'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024144575752991915)
,p_query_column_id=>4
,p_column_alias=>'GID'
,p_column_display_sequence=>4
,p_column_heading=>'Gid'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(11657932817464327719)
,p_name=>'FbEx von Regindex, die keine FbEx Rechte in SRA Gruppe haben '
,p_parent_plug_id=>wwv_flow_imp.id(11657932715373327718)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--WITH cte1 AS ( select /*+ materialize */ column_value as dn from koala_util.fGetGroupmembers(''AUDI_SRA_44030'') ',
'--), ',
'--cte2 as (  select *  from cte1   where dn != ''cn=dummy''   ',
'--),',
'with cte_ri as( select b.nachname nachname, b.vorname vorname , b.abteilung abteilung, b.GID GID',
'        from T_Benutzer b ',
'        join T_benutzer_ref_rolle brr on (brr.benutzerid =b.benutzerid and brr.rolleid = 1006)',
')',
'SELECT nachname,  vorname , abteilung, GID from cte_ri       -- FbEx ',
' minus  ',
'--SELECT   k.surname nachname, k.givenname vorname, k.subdepartment abteilung, k.gid gid ',
'--  from cte2, koala_util.fSearchDN(cte2.dn) k  ',
'select  nachname,  vorname, abteilung, gid  from T_SRA_BENUTZER where  SRA_GROUP =''FBEX''',
'order by 1   '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('keine Eintr\00E4ge vorhanden')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024143827233991914)
,p_query_column_id=>1
,p_column_alias=>'NACHNAME'
,p_column_display_sequence=>1
,p_column_heading=>'Nachname'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024143491094991914)
,p_query_column_id=>2
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>2
,p_column_heading=>'Vorname'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024143066344991914)
,p_query_column_id=>3
,p_column_alias=>'ABTEILUNG'
,p_column_display_sequence=>3
,p_column_heading=>'Abteilung'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024142666739991913)
,p_query_column_id=>4
,p_column_alias=>'GID'
,p_column_display_sequence=>4
,p_column_heading=>'Gid'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(11657934763119327738)
,p_name=>'FbEx von Regindex FbEx-Register, die keine FbEx Rechte in SRA Gruppe haben '
,p_parent_plug_id=>wwv_flow_imp.id(11657932715373327718)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--WITH cte1 AS ( select /*+ materialize */ column_value as dn from koala_util.fGetGroupmembers(''AUDI_SRA_44030'') ',
'--), ',
'--cte2 as (  select *  from cte1   where dn != ''cn=dummy''   ',
'--),',
'with cte_verantwortliche as (',
'    select distinct    b.nachname nachname, b.vorname vorname, b.abteilung abteilung,  b.gid gid',
'    from t_et_b_ak_ref_thema_benutzer aktb',
'    left outer join t_rolle r on r.rolleid = aktb.rolleid',
'    left outer join t_benutzer_ref_rolle brf on brf.benutzer_ref_rolleid = aktb.benutzer_ref_rolleid',
'    left outer join t_benutzer b on b.benutzerid = brf.benutzerid',
'    --left outer join t_benutzer leb on leb.benutzerid = aktb.letzte_aenderung_benutzerid',
'    where r.rolleid = 1006 and b.nachname is not null',
')',
'select nachname, vorname, abteilung, gid from cte_verantwortliche',
'  --SELECT nachname,  vorname , abteilung, GID from cte_ri  -- FbEx ',
' minus  ',
'  --SELECT   k.surname nachname, k.givenname vorname, k.subdepartment abteilung, k.gid gid ',
'  --  from cte2, koala_util.fSearchDN(cte2.dn) k  ',
'select  nachname,  vorname, abteilung, gid  from T_SRA_BENUTZER where  SRA_GROUP =''FBEX''',
'order by 1   '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('keine Eintr\00E4ge vorhanden')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024141958231991913)
,p_query_column_id=>1
,p_column_alias=>'NACHNAME'
,p_column_display_sequence=>1
,p_column_heading=>'Nachname'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024141572997991912)
,p_query_column_id=>2
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>2
,p_column_heading=>'Vorname'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024141126938991912)
,p_query_column_id=>3
,p_column_alias=>'ABTEILUNG'
,p_column_display_sequence=>3
,p_column_heading=>'Abteilung'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024140765461991912)
,p_query_column_id=>4
,p_column_alias=>'GID'
,p_column_display_sequence=>4
,p_column_heading=>'Gid'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp.component_end;
end;
/
