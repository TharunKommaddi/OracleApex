prompt --application/pages/page_00120
begin
--   Manifest
--     PAGE: 00120
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>120
,p_name=>'Normierte Eingaben'
,p_step_title=>'Normierte Eingaben'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2662243764234647417)
,p_plug_name=>'Normierte Eingabe <span onclick="redirect(12)" class="fa fa-question-square-o"></span>'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_la as (',
'    select normid, listagg(trim(la.b_nummer), '', '') within group (order by la.b_nummer) as laender',
'    from t_norm_ref_land nrl',
'    left outer join t_land la on (nrl.landid = la.landid)',
'    group by normid    ',
')',
'select n."ROWID", ',
' n.normid "NORMID",',
' n.bezeichnung "BEZEICHNUNG",',
' regexp_replace(apex_escape.html("REGEX"), '''' || chr(10) || ''?'' || chr(13), ''<br />'') as "REGEX",',
' regexp_replace(apex_escape.html("BEISPIEL"), '''' || chr(10) || ''?'' || chr(13), ''<br />'') as "BEISPIEL",',
' n.beschreibung "BESCHREIBUNG",',
' cte_la.laender,',
' n."LETZTE_AENDERUNG_DATUM",',
' b.NACHNAME || '', '' || b.VORNAME as "LETZTE_AENDERUNG_BENUTZER"',
' from "#OWNER#"."T_NORM" n',
' left outer join cte_la  on cte_la.normid = n.normid',
' left outer join T_BENUTZER b on b.benutzerid = n.LETZTE_AENDERUNG_BENUTZERID',
' order by n.BEZEICHNUNG asc',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2662244110652647418)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_oracle_text_index_column=>'BEZEICHNUNG'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:125:&SESSION.::&DEBUG.:125:P125_ROWID,P125_NORMID:#ROWID#,#NORMID#'
,p_detail_link_text=>'<span class="fa fa-pencil" aria-hidden="true"></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>172897544694375182
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2662244187738647423)
,p_db_column_name=>'ROWID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ROWID'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2662244584649647426)
,p_db_column_name=>'NORMID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Normid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2662244975527647427)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2662245402649647427)
,p_db_column_name=>'REGEX'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Regex'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2662245784551647427)
,p_db_column_name=>'BEISPIEL'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Beispiel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2662246198794647427)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Beschreibung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2659996319335113560)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>16
,p_column_identifier=>'G'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY HH24:Mi'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2659996480486113562)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>26
,p_column_identifier=>'I'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(370185835609936096)
,p_db_column_name=>'LAENDER'
,p_display_order=>36
,p_column_identifier=>'J'
,p_column_label=>unistr('L\00E4nder')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2662250241082710423)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1729037'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BEZEICHNUNG:REGEX:BEISPIEL:BESCHREIBUNG:LAENDER:LETZTE_AENDERUNG_DATUM:LETZTE_AENDERUNG_BENUTZER:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2662247452785647429)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2662243764234647417)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:125:&SESSION.::&DEBUG.:125'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2662246653177647427)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2662243764234647417)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2662247118832647429)
,p_event_id=>wwv_flow_imp.id(2662246653177647427)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2662243764234647417)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2662247793679647430)
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2662247452785647429)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2662248296250647430)
,p_event_id=>wwv_flow_imp.id(2662247793679647430)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2662243764234647417)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
