prompt --application/pages/page_00645
begin
--   Manifest
--     PAGE: 00645
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>645
,p_name=>'IMPORT GETEX VORSCHRIFT FORM'
,p_alias=>'IMPORT-GETEX-VORSCHRIFT-FORM'
,p_page_mode=>'MODAL'
,p_step_title=>'IMPORT GETEX VORSCHRIFT FORM'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(868157070520009821)
,p_plug_name=>'IMPORT GETEX VORSCHRIFT FORM'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  GETEX_IMPORTID, ',
'      decode(Status, 1, ''hochgeladen'', 2, ''importiert'', 3, ''Fehler'', 3) as IMPORT_STATUS, ',
'       GETEX_SCHLUESSEL, VORSCHRIFTID, ZEITPUNKT_UPLOAD, BDATEN',
'  from T_X_GETEX_IMPORT;'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(875243701461362284)
,p_name=>unistr('Verkn\00FCpfungen')
,p_parent_plug_id=>wwv_flow_imp.id(868157070520009821)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vr.v_id relation_id, ',
'vr.publisher publisher, ',
'vr.targetid targetid, ',
'vv2.v_nummer relation_Vorschrift_nummer,',
' vr.relationtype typ, ',
' vv.v_nummer vorschrift_nummer',
'   from V_GETEX_VORSCHRIFT_RELATION vr ',
'   join V_GETEX_VORSCHRIFT vv on (vv.v_id = vr.targetid )',
'   join V_GETEX_VORSCHRIFT vv2 on (vv2.v_id = vr.v_id )',
'   where vv.v_id= :P645_GETEX_SCHLUESSEL',
'order by  vr.RELATIONTYPE;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(875243539531362283)
,p_query_column_id=>1
,p_column_alias=>'RELATION_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(875243496261362282)
,p_query_column_id=>2
,p_column_alias=>'PUBLISHER'
,p_column_display_sequence=>70
,p_column_heading=>'Publisher'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(875243430252362281)
,p_query_column_id=>3
,p_column_alias=>'TARGETID'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(875243254202362280)
,p_query_column_id=>4
,p_column_alias=>'RELATION_VORSCHRIFT_NUMMER'
,p_column_display_sequence=>40
,p_column_heading=>'Relation Vorschrift Nummer'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(875243184575362279)
,p_query_column_id=>5
,p_column_alias=>'TYP'
,p_column_display_sequence=>50
,p_column_heading=>'Typ'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(875243113276362278)
,p_query_column_id=>6
,p_column_alias=>'VORSCHRIFT_NUMMER'
,p_column_display_sequence=>60
,p_column_heading=>'Vorschrift Nummer'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(875242994233362277)
,p_name=>'Themen'
,p_parent_plug_id=>wwv_flow_imp.id(868157070520009821)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v_id, v_nummer vorschrift_nummer, v_status, thema_id, thema_name, thema_name_en ',
'  from V_GETEX_VORSCHRIFT_THEMA vvt',
' --join V_GETEX_VORSCHRIFT vv on (vv.v_id =vvt.v_id',
' where v_id = :P645_GETEX_SCHLUESSEL',
' order by thema_name'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(875242936623362276)
,p_query_column_id=>1
,p_column_alias=>'V_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(875242257608362270)
,p_query_column_id=>2
,p_column_alias=>'VORSCHRIFT_NUMMER'
,p_column_display_sequence=>70
,p_column_heading=>'Vorschrift Nummer'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(875242707761362274)
,p_query_column_id=>3
,p_column_alias=>'V_STATUS'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(875242592950362273)
,p_query_column_id=>4
,p_column_alias=>'THEMA_ID'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(875242451792362272)
,p_query_column_id=>5
,p_column_alias=>'THEMA_NAME'
,p_column_display_sequence=>50
,p_column_heading=>'Thema Name'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(875242377764362271)
,p_query_column_id=>6
,p_column_alias=>'THEMA_NAME_EN'
,p_column_display_sequence=>60
,p_column_heading=>'Thema Name Englisch'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(868153225922009805)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(868152747491009805)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(868153225922009805)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(868151358516009799)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(868153225922009805)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(868150941324009798)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(868153225922009805)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(868150613271009798)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(868153225922009805)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P645_GETEX_IMPORTID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(875245149713362299)
,p_name=>'P645_BDATEN'
,p_source_data_type=>'BLOB'
,p_is_query_only=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(868157070520009821)
,p_item_source_plug_id=>wwv_flow_imp.id(868157070520009821)
,p_prompt=>unistr('Bin\00E4re Daten')
,p_source=>'BDATEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'content_disposition', 'attachment',
  'display_as', 'INLINE',
  'display_download_link', 'Y',
  'storage_type', 'DB_COLUMN')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(875244476209362292)
,p_name=>'P645_IMPORT_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(868157070520009821)
,p_item_source_plug_id=>wwv_flow_imp.id(868157070520009821)
,p_prompt=>'Status des Imports'
,p_source=>'IMPORT_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(868156665469009819)
,p_name=>'P645_GETEX_IMPORTID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(868157070520009821)
,p_item_source_plug_id=>wwv_flow_imp.id(868157070520009821)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Getex Importid'
,p_source=>'GETEX_IMPORTID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(868155923997009809)
,p_name=>'P645_GETEX_SCHLUESSEL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(868157070520009821)
,p_item_source_plug_id=>wwv_flow_imp.id(868157070520009821)
,p_prompt=>unistr('Getex Schl\00FCssel')
,p_source=>'GETEX_SCHLUESSEL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>64
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(868155530647009809)
,p_name=>'P645_VORSCHRIFTID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(868157070520009821)
,p_item_source_plug_id=>wwv_flow_imp.id(868157070520009821)
,p_prompt=>'Getex Vorschriftid'
,p_source=>'VORSCHRIFTID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>64
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(868155105636009809)
,p_name=>'P645_ZEITPUNKT_UPLOAD'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(868157070520009821)
,p_item_source_plug_id=>wwv_flow_imp.id(868157070520009821)
,p_prompt=>'Zeitpunkt von Hochladung'
,p_source=>'ZEITPUNKT_UPLOAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>64
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(868152698251009805)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(868152747491009805)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(868151929806009800)
,p_event_id=>wwv_flow_imp.id(868152698251009805)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(868149769829009797)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(868157070520009821)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form IMPORT GETEX VORSCHRIFT FORM'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2804062546070378438
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(868149412366009796)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2804062903533378439
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(868150226108009797)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(868157070520009821)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form IMPORT GETEX VORSCHRIFT FORM'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2804062089791378438
);
wwv_flow_imp.component_end;
end;
/
