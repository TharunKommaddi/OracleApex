prompt --application/pages/page_00388
begin
--   Manifest
--     PAGE: 00388
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>388
,p_name=>unistr('ET-B AK bearbeiten / hinzuf\00FCgen')
,p_alias=>'TEMPORARY'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('ET-B AK bearbeiten / hinzuf\00FCgen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('var htmldb_delete_message=''"M\00F6chten Sie die Zuordnung des Benutzers als Experte zum Thema entfernen?"'';'),
'function diolguehead() {',
'    ',
'    if ($(''#P388_JS_LANG'').val() === ''en'') {',
'        apex.util.getTopApex().jQuery(" .myDialog .ui-dialog-title").html(''Assign user to Working group <span onclick="redirect(305)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'    }',
'    if ($(''#P388_JS_LANG'').val() === ''de'') {',
'        apex.util.getTopApex().jQuery(" .myDialog .ui-dialog-title").html(''Anwender einem Arbeitskreis zuordnen <span onclick="redirect(305)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'    }',
'    ',
'}'))
,p_javascript_code_onload=>'diolguehead();'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_css_classes=>'myDialog'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_comment=>'j'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(640870885195899797)
,p_plug_name=>'Anwender einem Arbeitskreis zuordnen'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_ET_B_AK_REF_THEMA_BENUTZER'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_read_only_when_type=>'EXISTS'
,p_plug_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual where ',
'(pck_ri.fIsUserInRolle(listRolleId => ''1040'') > 0 and ',
'pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1002:1006'') = 0)'))
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 19.02.2024',
'-- test',
'select 1 from dual where pck_ri.fIsUserInRolle(listRolleId => ''1001:1040'')> 0 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1002'')= 0',
'',
'',
'',
'-- 28.02.2024 10:19 pm',
'',
'select 1 from dual where ',
'(pck_ri.fIsUserInRolle(listRolleId => ''1001:1040'') > 0 and ',
'pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1002:1006'') = 0)'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(640237832700185911)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(898574768810732141)
,p_button_sequence=>160
,p_button_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_button_name=>'SEARCH_LDAP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'In LDAP suchen'
,p_button_redirect_url=>'f?p=&APP_ID.:65:&SESSION.::&DEBUG.:65:P65_CAMEFROM:388'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(userId => PCK_RI.fGetUserId, ',
'                      pageId => :APP_PAGE_ID,',
'                      accessMode => 200))',
'   --and (:P388_HIDE_SEARCH_LDAP  =0  or :P388_HIDE_SEARCH_LDAP  is null)',
'   and (  pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'')>0  -- vko , fach admin',
'       or  (pck_ri.fIsUserInRolle(listRolleId => ''1002'')> 0   -- vex',
'         and (:P388_ET_B_AK_REF_THEMA_BENUTZERID is  null))--or :P388_HIDE_SEARCH_LDAP  =0) )  -- VEX',
'   )'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_cattributes=>'style ="margin-top: 9px !important;"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(userId => PCK_RI.fGetUserId, ',
'                      pageId => :APP_PAGE_ID,',
'                      accessMode => 200))      pl sql exp ',
'',
'',
'',
'',
'',
'    (PCK_RI.fIsAuthorized(userId => PCK_RI.fGetUserId, ',
'    pageId => :APP_PAGE_ID,',
'    accessMode => 200))',
'',
'    select 1 from dual where :P388_LOGIN_USER_ROLE = 0 and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null ',
'--  and :P388_ROLLE not in(1006',
'-- and pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') = 0 ',
'and :P388_LOGIN_USER_REC=0; j'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(897947950900018332)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(640237832700185911)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(897948431081018338)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(640237832700185911)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Entfernen'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P388_ET_B_AK_REF_THEMA_BENUTZERID is not null',
'and (',
'    pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0 --Anzeige wenn Admin    -- 1000 - VKO, 1003 - Fachadmin',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(897947596611018331)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(640237832700185911)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1002:1006'')>0  -- vko , fach admin',
'AND :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null)'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'UPDATE'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--:P388_ET_B_AK_REF_THEMA_BENUTZERID is not null AND (:P388_HIDE_SEARCH_LDAP = 0 OR :P388_HIDE_SEARCH_LDAP is null)',
'',
'',
'',
'((PCK_RI.fIsAuthorized(userId => PCK_RI.fGetUserId, ',
'                      pageId => :APP_PAGE_ID,',
'                      accessMode => 100))',
'   --and (:P388_HIDE_SEARCH_LDAP  =0  or :P388_HIDE_SEARCH_LDAP  is null)',
'   and (  pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1002:1006'')>0  -- vko , fach admin',
'     ',
'       AND :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null',
'        ',
'   )',
')'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(897947215234018330)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(640237832700185911)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P388_ET_B_AK_REF_THEMA_BENUTZERID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(907588198698692574)
,p_name=>'P388_LOGIN_USER_ROLE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_source=>'select count(*) from t_benutzer_ref_rolle where BENUTZERID = :G_BENUTZERID and ROLLEID in (1000,1003)  -- vko, fachadmin'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(907588072222692573)
,p_name=>'P388_LOGIN_USER_REC'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select count(*) from t_benutzer ',
'where BENUTZERID = :G_BENUTZERID and nachname = :P388_NACHNAME ',
'and vorname = :P388_VORNAME or LETZTE_AENDERUNG_BENUTZERID= :G_BENUTZERID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(907587967016692572)
,p_name=>'P388_LDAP_DIRECTEINGABE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_item_default=>'1'
,p_prompt=>'&nbsp;'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:LDAP;1,Direkteingabe Name;0'
,p_read_only_when=>'P388_VEX_FBEX'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual where pck_ri.fIsUserInRolle(listRolleId => ''1002:1006'')> 0',
'         and (:P388_HIDE_SEARCH_LDAP is not null )'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(898574428707732119)
,p_name=>'P388_ROLLE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_item_source_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_prompt=>'Rolle'
,p_source=>'ROLLEID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_val clob;',
'begin ',
'if :P388_LOGIN_USER_ROLE >=1 and  (:P388_ET_B_AK_REF_THEMA_BENUTZERID is null or :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null) then ',
'l_val :=''select rolle as d, rolleid as r ',
'from t_rolle ',
'   where rolleid in (',
'',
'    1002',
'    , 1006',
'    , 1040',
'    )'';',
'elsif :P388_LOGIN_USER_ROLE =0 and  :P388_ET_B_AK_REF_THEMA_BENUTZERID is null then ',
'l_val :=''select rolle as d, rolleid as r ',
'from t_rolle ',
'   where rolleid in (1006',
'    )'';   ',
'else',
'l_val :=''select rolle as d, rolleid as r ',
'from t_rolle ',
'   where rolleid = (select ROLLEID  from T_ET_B_AK_REF_THEMA_BENUTZER',
' WHERE ET_B_AK_REF_THEMA_BENUTZERID = :P388_ET_B_AK_REF_THEMA_BENUTZERID)'';',
'',
'end if;',
'return l_val;',
'end;',
''))
,p_lov_cascade_parent_items=>'P388_LOGIN_USER_ROLE,P388_ET_B_AK_REF_THEMA_BENUTZERID'
,p_ajax_items_to_submit=>'P388_LOGIN_USER_ROLE,P388_ET_B_AK_REF_THEMA_BENUTZERID'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'    pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') = 0 --ReadOnly, wenn kein Admin',
')'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(898574017248732113)
,p_name=>'P388_ET_B_AK_REF_THEMA_BENUTZERID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_item_source_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_source=>'ET_B_AK_REF_THEMA_BENUTZERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(898573631850732110)
,p_name=>'P388_ET_B_AKID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_item_source_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_source=>'ET_B_AKID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(898572789338732108)
,p_name=>'P388_BENUTZER_GID'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(898572415786732107)
,p_name=>'P388_R_BENUTZERID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_item_source_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_source=>'BENUTZERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(898571981720732107)
,p_name=>'P388_NACHNAME'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_prompt=>'Nachname'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(898571581383732106)
,p_name=>'P388_VORNAME'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_prompt=>'Vorname'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(898571151140732106)
,p_name=>'P388_EMAIL'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(898570759694732106)
,p_name=>'P388_ABTEILUNG'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(898570393593732105)
,p_name=>'P388_BENUTZERNAME_FREITEXT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_item_source_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_prompt=>'ODER Direkteingabe Benutzername'
,p_source=>'BENUTZERNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct benutzername from t_et_b_ak_ref_thema_benutzer',
'order by benutzername'))
,p_cSize=>30
,p_cMaxlength=>248
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'fetch_on_type', 'N',
  'match_type', 'CONTAINS_IGNORE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(898570012738732105)
,p_name=>'P388_BETREUERID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_item_source_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_prompt=>'Betreuung durch VEX'
,p_source=>'BETREUERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct  d, r',
'from (',
' select distinct b.nachname||'', ''||b.vorname as d, ET_B_AK_REF_THEMA_BENUTZERID r ',
'  from t_ET_B_AK_REF_THEMA_BENUTZER artb',
'  join t_benutzer b on (b.benutzerid = artb.benutzerid )',
'  ',
' where rolleId = 1002 and artb.ET_B_AKID = :P388_ET_B_AKID',
' --artb.ET_B_AKID = 1010 --:P388_ET_B_AKID',
' and  ',
'   (select count(*) from t_Benutzer_ref_rolle where rolleid in (1000, 1003, 1002) and benutzerid = :G_BENUTZERID) >0 ',
'  union',
'  select distinct b.nachname||'', ''||b.vorname as d, ET_B_AK_REF_THEMA_BENUTZERID r ',
'  from t_ET_B_AK_REF_THEMA_BENUTZER artb',
'  join t_benutzer b on (b.benutzerid = artb.benutzerid )',
'    where rolleId = 1002 and artb.ET_B_AKID = :P388_ET_B_AKID and b.benutzerid = :G_BENUTZERID',
' order by 1',
')',
'',
' ',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('--ausw\00E4hlen--')
,p_lov_cascade_parent_items=>'P388_JS_LANG'
,p_ajax_items_to_submit=>'P388_JS_LANG'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_read_only_when=>'select 1 from dual where pck_ri.fIsUserInRolle(listRolleId => ''1002:1006'')> 0 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'')= 0 and :P388_BETREUERID is not null'
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual where pck_ri.fIsUserInRolle(listRolleId => ''1002:1006'')> 0',
'and (:P388_HIDE_SEARCH_LDAP is not null )',
'',
'',
'',
'',
'',
'select 1 from dual where pck_ri.fIsUserInRolle(listRolleId => ''1002:1006'')> 0',
'',
'',
'',
'',
'-- today fri 09.02.2024  lov  sql ',
'',
'select distinct  d, r',
'from (',
' select distinct b.nachname||'', ''||b.vorname as d, ET_B_AK_REF_THEMA_BENUTZERID r ',
'  from t_ET_B_AK_REF_THEMA_BENUTZER artb',
'  join t_benutzer b on (b.benutzerid = artb.benutzerid )',
'  ',
' where rolleId = 1002 and artb.ET_B_AKID = :P388_ET_B_AKID',
' --artb.ET_B_AKID = 1010 --:P388_ET_B_AKID',
' and  ',
'   (select count(*) from t_Benutzer_ref_rolle where rolleid in (1000, 1003) and benutzerid = :G_BENUTZERID) >0 ',
'  union',
'  select distinct b.nachname||'', ''||b.vorname as d, ET_B_AK_REF_THEMA_BENUTZERID r ',
'  from t_ET_B_AK_REF_THEMA_BENUTZER artb',
'  join t_benutzer b on (b.benutzerid = artb.benutzerid )',
'    where rolleId = 1002 and artb.ET_B_AKID = :P388_ET_B_AKID and b.benutzerid = :G_BENUTZERID',
' order by 1',
')',
'',
' ',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(898569545372732105)
,p_name=>'P388_THEMA_REF_ET_B_AKID'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_prompt=>'Thema'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(t.THEMA_REF_ET_B_AKID, '':'')',
'from T_ET_B_AK_REF_THEMA_BENUTZER_REF_ET_B_AK_REF_THEMA t',
'where t.ET_B_AK_REF_THEMA_BENUTZERID = :P388_ET_B_AK_REF_THEMA_BENUTZERID'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte as (',
'    select t.nummer || '' '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' ',
'        THEN concat(t.bezeichnung, case when (nvl(t.gueltig,0)=0) then ''(in GETEX inaktiv)'' else '' '' end )',
'        ELSE concat(t.name_eng, case when (nvl(t.gueltig,0)=0) then ''(in GETEX inactive )'' else '' '' end ) ',
'         END as d, trak.THEMA_REF_ET_B_AKID as r, vt.thema_sortorder',
'    from t_THEMA_REF_ET_B_AK trak',
'    inner join t_thema t on (t.themaid = trak.themaid)',
'    inner join v_thema_baum vt on (t.themaid = vt.themaid )',
'    where trak.ET_B_AKID = :P388_ET_B_AKID and t.gueltig =1',
'     UNION',
'      -- damit inaktive Themen  angezeigt werden wenn die vorher zugeordnet wurden',
'    select t.nummer || '' '' || CASE ',
'            WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' ',
'            THEN concat(t.bezeichnung, case when (nvl(t.gueltig,0)=0) then ''(in GETEX inaktiv)'' else '' '' end )',
'            ELSE concat(t.name_eng, case when (nvl(t.gueltig,0)=0) then ''(in GETEX inactive )'' else '' '' end ) ',
'        END as d, trak.THEMA_REF_ET_B_AKID as r,  vt.thema_sortorder',
'    from t_THEMA_REF_ET_B_AK trak',
'    inner join t_thema t on (t.themaid = trak.themaid)',
'    inner join v_thema_baum vt on (t.themaid = vt.themaid )',
'    where   trak.THEMA_REF_ET_B_AKID in ( select column_value from apex_string.split_numbers(:P388_THEMA_REF_ET_B_AKID, '':'') )',
'    ',
')',
' select d, r from cte order by  thema_sortorder ',
'',
''))
,p_lov_cascade_parent_items=>'P388_ET_B_AKID'
,p_ajax_items_to_submit=>'P388_ET_B_AKID'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>32
,p_cMaxlength=>255
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual where pck_ri.fIsUserInRolle(listRolleId => ''1006:1040'') > 0 ',
'and :P388_ROLLE in(1040,1006)  and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'')= 0'))
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 19.02.2024 ',
'',
'- test ',
'select 1 from dual where pck_ri.fIsUserInRolle(listRolleId => ''1006'')> 0 and  pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1002'')= 0'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(898569157192732102)
,p_name=>'P388_APPROVED'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_item_source_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_prompt=>unistr('Best\00E4tigt')
,p_source=>'APPROVED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Ja;20,Nein;0'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'    pck_ri.fIsUserInRolle(listRolleId => ''1002:1006'') > 0 --ReadOnly, wenn kein Admin',
'    and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') = 0 and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null--   pck_ri.fIsUserInRolle(listRolleId => ''1002:1006'') > 0',
')',
'',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'read onlky exp sql ',
'',
'(',
'    pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') = 0 --ReadOnly, wenn kein Admin',
'    and pck_ri.fIsUserInRolle(listRolleId => ''1002:1006'') > 0',
')',
'',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(898568809495732100)
,p_name=>'P388_BEMERKUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_item_source_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_prompt=>'Bemerkung'
,p_source=>'BEMERKUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>200
,p_cHeight=>5
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual where pck_ri.fIsUserInRolle(listRolleId => ''1002:1040'')>0 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1006'') = 0 ',
'and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null',
'and :P388_ROLLE in (1040)'))
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual where :P388_ROLLE = 1001  -- ZVEX',
'',
'',
'',
'select 1 from dual where pck_ri.fIsUserInRolle(listRolleId => ''1002:1001:1040'')>0 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1006'') = 0 ',
'and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null',
' and :P388_ROLLE in (1001,1040)',
'',
'',
' -- 27.02.2025 11:38 pm ',
'',
'',
' select 1 from dual where pck_ri.fIsUserInRolle(listRolleId => ''1002:1001:1040'')>0 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1006'') = 0 ',
'and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null',
' and :P388_ROLLE in (1001,1040)'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(898568372868732099)
,p_name=>'P388_BEREICH'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_item_source_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_prompt=>'Vertretener Bereich'
,p_source=>'BEREICH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>200
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual where pck_ri.fIsUserInRolle(listRolleId => ''1002:1040'')>0 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1006'') = 0 ',
'and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null',
' and :P388_ROLLE in (1040)',
'',
'',
''))
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_inline_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Beispiel Mehrere Bereiche: I/EM-X, I/EM-1 <br>',
'Beispiel ein Bereich: I/EM-X'))
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 19.02.2024',
'-- test',
'',
'(',
'    pck_ri.fIsUserInRolle(listRolleId => ''1002:1006'') > 0 --ReadOnly, wenn kein Admin',
'    and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') = 0 and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null--   pck_ri.fIsUserInRolle(listRolleId => ''1002:1006'') > 0',
')',
'',
'',
'',
'--27.02.2025 11:35 pm ',
'(',
'    pck_ri.fIsUserInRolle(listRolleId => ''1002:1006'') > 0 --ReadOnly, wenn kein Admin -- 1002',
'    and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') = 0 and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null--   pck_ri.fIsUserInRolle(listRolleId => ''1002:1006'') > 0',
')',
'',
'',
'',
'',
'',
'',
'(',
'    pck_ri.fIsUserInRolle(listRolleId => ''1002:1006:1001:1040'') > 0 ',
'    and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') = 0 ',
'    and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null',
'    and pck_ri.fGetUserId != :P388_R_BENUTZERID',
')',
'',
'',
'',
'',
'',
'',
'-- udpated 05.03.2025 10:43 ',
'',
'select 1 from dual where pck_ri.fIsUserInRolle(listRolleId => ''1002:1001:1040'')>0 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1006'') = 0 ',
'and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null',
' and :P388_ROLLE in (1001,1040)',
'',
'',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(898567986219732097)
,p_name=>'P388_BENUTZER_COLOR'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(898567550639732097)
,p_name=>'P388_JS_LANG'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_item_default=>':FSP_LANGUAGE_PREFERENCE'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869475128846647885)
,p_name=>'P388_HIDE_SEARCH_LDAP'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual where :P388_LOGIN_USER_ROLE = 0 and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null ',
'                  --  and :P388_ROLLE not in(1006',
'                 -- and pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') = 0 ',
'                    and :P388_LOGIN_USER_REC=0;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual where :P388_LOGIN_USER_ROLE = 0 and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null ',
'                  --  and :P388_ROLLE not in(1006',
'                 -- and pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') = 0 ',
'                  ---2/7/24  and :P388_LOGIN_USER_REC=0;'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(834278334917992775)
,p_name=>'P388_VEX_FBEX'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(640870885195899797)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual where pck_ri.fIsUserInRolle(listRolleId => ''1002:1006'')>0  and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') = 0 ',
'and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(897952208297062237)
,p_validation_name=>'Wert Gesetzt'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Evaluates to true if role isn''t 1006 or if role is 1006 but either a ''betreuerid'' is provided or the ''approved'' status is 0.',
'nvl(:P388_ROLLE, 0) !=1006 or',
'(nvl(:P388_ROLLE, 0)=1006 and ( :P388_BETREUERID is not null or nvl(:P388_APPROVED, 0) =0) )'))
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Betreuer muss gew\00E4hlt werden!')
,p_always_execute=>'Y'
,p_validation_condition=>'SAVE, CREATE'
,p_validation_condition_type=>'REQUEST_IN_CONDITION'
,p_associated_item=>wwv_flow_imp.id(898570012738732105)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(897951194135051403)
,p_validation_name=>'Wert Gesetzt_FBEx_Create_Update'
,p_validation_sequence=>40
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Checks if role isn''t 1006 or if role is 1006, a ''betreuerid'' must be provided.',
'nvl(:P388_ROLLE, 0) !=1006 or',
'( nvl(:P388_ROLLE, 0)=1006 and ( :P388_BETREUERID is not null ) )'))
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Betreuer muss gew\00E4hlt werden!')
,p_always_execute=>'Y'
,p_validation_condition=>'CREATE, SAVE'
,p_validation_condition_type=>'REQUEST_IN_CONDITION'
,p_associated_item=>wwv_flow_imp.id(898570012738732105)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(897950856852050304)
,p_validation_name=>'V_AK_HAS_THEMEN'
,p_validation_sequence=>50
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Fetches a constant value of 1 for records in ''t_THEMA_REF_ET_B_AK'' that match the provided ''ET_B_AKID'' and have an associated entry in ''t_thema''.',
'select 1',
'from t_THEMA_REF_ET_B_AK trak',
'inner join t_thema t on t.themaid = trak.themaid',
'where trak.ET_B_AKID = :P388_ET_B_AKID'))
,p_validation_type=>'EXISTS'
,p_error_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Der Arbeitskreis ist noch keinem Thema zugeordnet.',
unistr('Die Zuordnung erfolgt in der Maske "Thema bearbeiten / hinzuf\00FCgen" der Themenverwaltung.')))
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(898569545372732105)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(898009440651853598)
,p_name=>'Betreuer Visibility'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P388_ROLLE'
,p_condition_element=>'P388_ROLLE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1006'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(898008672426853462)
,p_event_id=>wwv_flow_imp.id(898009440651853598)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P388_BETREUERID'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(898009109172853466)
,p_event_id=>wwv_flow_imp.id(898009440651853598)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P388_BETREUERID'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(898008148757853459)
,p_event_id=>wwv_flow_imp.id(898009440651853598)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P388_BETREUERID'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'  This block of PL/SQL code is designed to automatically assign a ''Betreuer'' based on specific criteria.',
'  1. A counter ''l_co'' is initialized to check how many instances a user has a role ''VEX'' (represented by rolleid = 1002).',
'  2. If a user (obtained from the pck_ri.fGetUserid function) has at least one ''VEX'' role, ',
'    the ''Betreuer'' ID (''et_b_ak_ref_thema_benutzerid'') corresponding to that user and role is fetched.',
'    Note: If there are multiple entries for the user with the ''VEX'' role, only the first one is fetched.',
'  3. If the user is found to have the ''VEX'' role, the ''Betreuer'' ID is returned. Otherwise, null is returned.',
' */',
'declare ',
'l_co number :=0;',
'l_betreuerid number :=0;',
'begin',
'  --set Betreuer automatic to user if he has VEX role',
'    select count(*) into l_co from t_et_b_ak_ref_thema_benutzer where benutzerid = pck_ri.fGetUserid and rolleid = 1002;',
'    if (l_co > 0) then',
'        select et_b_ak_ref_thema_benutzerid ',
'          into l_betreuerid ',
'          from t_et_b_ak_ref_thema_benutzer ',
'         where  benutzerid = pck_ri.fGetUserid  --1280  --',
'           and rolleid = 1002 fetch first 1 rows only;',
'           --debug(''from Dyn Act  P388 betreuerid=''|| l_betreuerid);',
'        return l_betreuerid;',
'    end if;',
'    return null;',
' end;'))
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P388_ET_B_AK_REF_THEMA_BENUTZERID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(897981756147262762)
,p_name=>'Enter in'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P388_BENUTZERNAME_FREITEXT'
,p_condition_element=>'P388_BENUTZERNAME_FREITEXT'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseleave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(897981423630262755)
,p_event_id=>wwv_flow_imp.id(897981756147262762)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P388_BENUTZER_GID,P388_R_BENUTZERID,P388_NACHNAME,P388_VORNAME,P388_EMAIL,P388_ABTEILUNG'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*Fetches user details from ''t_benutzer'' based on varying formats of the input name: comma-separated, ',
'space-separated with two parts, and space-separated with single parts.*/',
'SELECT ',
'    distinct GID, BENUTZERID, NACHNAME, VORNAME, EMAIL, ABTEILUNG ',
'FROM ',
'    t_benutzer ',
'WHERE ',
'    ( ',
'        -- Handling comma-separated names with or without space after comma',
'        UPPER(TRIM(NACHNAME)) = TRIM(SUBSTR(UPPER(:P388_BENUTZERNAME_FREITEXT), 1, INSTR(:P388_BENUTZERNAME_FREITEXT, '','') - 1))',
'        AND ',
'        UPPER(TRIM(VORNAME)) = TRIM(SUBSTR(LTRIM(UPPER(:P388_BENUTZERNAME_FREITEXT)), INSTR(LTRIM(UPPER(:P388_BENUTZERNAME_FREITEXT)), '','') + 1))',
'    )',
'    OR',
'    (',
'        -- Handling space-separated names with two parts in both NACHNAME and VORNAME',
'        UPPER(TRIM(NACHNAME)) = TRIM(REGEXP_SUBSTR(UPPER(:P388_BENUTZERNAME_FREITEXT), ''[^ ]+'', 1, 1) || '' '' || REGEXP_SUBSTR(UPPER(:P388_BENUTZERNAME_FREITEXT), ''[^ ]+'', 1, 2))',
'        AND ',
'        UPPER(TRIM(VORNAME)) = TRIM(REGEXP_SUBSTR(UPPER(:P388_BENUTZERNAME_FREITEXT), ''[^ ]+'', 1, 3) || '' '' || REGEXP_SUBSTR(UPPER(:P388_BENUTZERNAME_FREITEXT), ''[^ ]+'', 1, 4))',
'    )',
'    OR',
'    (',
'        -- Handling space-separated names with single parts for both NACHNAME and VORNAME',
'        UPPER(TRIM(NACHNAME)) = TRIM(REGEXP_SUBSTR(UPPER(:P388_BENUTZERNAME_FREITEXT), ''[^ ]+'', 1, 1))',
'        AND ',
'        UPPER(TRIM(VORNAME)) = TRIM(REGEXP_SUBSTR(UPPER(:P388_BENUTZERNAME_FREITEXT), ''[^ ]+'', 1, 2))',
'    )and GID is not null',
'    ',
'    FETCH FIRST 1 ROW ONLY;'))
,p_attribute_07=>'P388_BENUTZERNAME_FREITEXT'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_da_action_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- select  ',
'-- GID,',
'-- BENUTZERID,',
'-- NACHNAME,',
'-- VORNAME,',
'-- EMAIL,',
'-- ABTEILUNG',
'-- from t_benutzer',
'-- where upper(trim(NACHNAME)) = REGEXP_SUBSTR(UPPER(TRIM(:P388_BENUTZERNAME_FREITEXT)),''[^,]+'',1,1)',
'-- and upper(trim(VORNAME)) = REGEXP_SUBSTR(UPPER(TRIM(:P388_BENUTZERNAME_FREITEXT)),''[^,]+'',1,2) and GID is not null;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(897977375363180910)
,p_name=>'set  approved'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P388_BENUTZERNAME_FREITEXT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(897976480038180906)
,p_event_id=>wwv_flow_imp.id(897977375363180910)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P388_APPROVED'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
' The SQL query determines the value of the ''APPROVED'' column based on the following criteria:',
' ',
' 1. If ''P388_ROLLE'' is null, and both ''P388_NACHNAME'' and ''P388_BENUTZERNAME_FREITEXT'' are null, ',
'    the value for ''APPROVED'' is set to 0.',
' 2. In all other cases, ''APPROVED'' takes the numeric value of ''P388_APPROVED''.',
' ',
' The result is derived from the Oracle DUAL table, which always returns a single row.',
' */',
'select case',
'       when :P388_ROLLE is null AND (:P388_NACHNAME is null and :P388_BENUTZERNAME_FREITEXT is null) then 0',
'       else to_number(:P388_APPROVED)',
'  end as APPROVED from dual;'))
,p_attribute_07=>'P388_ROLLE,P388_NACHNAME,P388_BENUTZERNAME_FREITEXT,P388_APPROVED'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(907588710285692579)
,p_name=>'change_color_1'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P388_BENUTZERNAME_FREITEXT,P388_APPROVED'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(907588451871692577)
,p_event_id=>wwv_flow_imp.id(907588710285692579)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P388_BENUTZER_COLOR'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'  Determines the color for a user based on multiple conditions:',
'  1. If P388_ROLLE, P388_NACHNAME, P388_BENUTZERNAME_FREITEXT, and P388_VORNAME are all null, then the color is ''pink''.',
'  2. If at least one of P388_ROLLE, P388_BENUTZERNAME_FREITEXT, P388_NACHNAME, or P388_VORNAME is not null and P388_APPROVED is 0, then the color is ''yellow''.',
'  3. If at least one of P388_ROLLE, P388_BENUTZERNAME_FREITEXT, P388_NACHNAME, or P388_VORNAME is not null and P388_APPROVED is 20, then the color is ''lightgreen''.',
'  4. For all other cases, the color is set to ''none''.',
' */',
' select case',
'       when :P388_ROLLE is null AND :P388_NACHNAME is null AND :P388_BENUTZERNAME_FREITEXT is null AND :P388_VORNAME is null then ''pink''',
'       when (:P388_ROLLE is not null OR :P388_BENUTZERNAME_FREITEXT is not null OR :P388_NACHNAME is not null OR :P388_VORNAME is not null) and :P388_APPROVED = 0 then ''yellow''',
'       when (:P388_ROLLE is not null OR :P388_BENUTZERNAME_FREITEXT is not null OR :P388_NACHNAME is not null OR :P388_VORNAME is not null) and :P388_APPROVED = 20 then ''lightgreen''',
'       else ''none''',
'end as BENUTZER_COLOR',
'from dual;',
''))
,p_attribute_07=>'P388_ROLLE,P388_NACHNAME,P388_BENUTZERNAME_FREITEXT,P388_APPROVED'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(897966265307897378)
,p_name=>'benutzer_color_changed'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P388_BENUTZER_COLOR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(897965851473897377)
,p_event_id=>wwv_flow_imp.id(897966265307897378)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'  Sets the background color of the elements with IDs ''P388_ROLLE'', ''P388_NACHNAME'', and ''P388_VORNAME'', and ''P388_BENUTZERNAME_FREITEXT''',
'  to the value stored in the ''P388_BENUTZER_COLOR'' variable.',
' */',
'$(''#P388_ROLLE_DISPLAY'').css(''background-color'', $v(''P388_BENUTZER_COLOR''));',
'$(''#P388_ROLLE'').css(''background-color'', $v(''P388_BENUTZER_COLOR''));',
'$(''#P388_NACHNAME'').css(''background-color'', $v(''P388_BENUTZER_COLOR''));',
'$(''#P388_VORNAME'').css(''background-color'', $v(''P388_BENUTZER_COLOR''));',
'// $(''#P388_BENUTZERNAME_FREITEXT'').css(''background-color'', $v(''P388_BENUTZER_COLOR''));',
'$(''#P388_BENUTZERNAME_FREITEXT input'')',
'    .css(''background-color'', $v(''P388_BENUTZER_COLOR''));',
'',
'// $(''#P388_BENUTZERNAME_FREITEXT .js-results-description'').css(''background-color'', $v(''P388_BENUTZER_COLOR''));',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(897957499166386510)
,p_name=>'Dialog Closed'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(898574768810732141)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(897957075666386502)
,p_event_id=>wwv_flow_imp.id(897957499166386510)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- test',
'declare',
' l_co number :=0;',
'begin',
' if (:P65_GID_CHOSEN is not null) then',
'   select :P65_NACHNAME_AUSGEWAEHLT, :P65_VORNAME_AUSGEWAEHLT, :P65_EMAIL_AUSGEWAEHLT, :P65_ABTEILUNG_AUSGEWAEHLT, :P65_GID_CHOSEN ',
'     into     :P388_NACHNAME,      :P388_VORNAME,         :P388_EMAIL,            :P388_ABTEILUNG,    :P388_BENUTZER_GID',
'     from dual;',
'  end if;',
'',
'																		 ',
' if (:P388_BENUTZER_GID is not null) then',
'     select count(*) into l_co   from t_benutzer where GID = :P388_BENUTZER_GID;',
'     if(l_co >0) then',
'         select  Benutzerid into  :P388_R_BENUTZERID from t_benutzer ',
'         where GID = :P388_BENUTZER_GID fetch  first 1 rows only; ',
'        -- :P388_R_BENUTZERID := PCK_RI.fCreatePlaceHolderUser(:P65_GID_CHOSEN);',
'        -- debug (''exist benutz id=''||:P388_R_BENUTZERID);',
'     else',
'       insert into t_benutzer (nachname,',
'        vorname, email, abteilung, gid)',
'       values ( :P65_NACHNAME_AUSGEWAEHLT, ',
'       :P65_VORNAME_AUSGEWAEHLT, :P65_EMAIL_AUSGEWAEHLT, :P65_ABTEILUNG_AUSGEWAEHLT, :P65_GID_CHOSEN )',
'       returning benutzerid into :P388_R_BENUTZERID;',
'       --debug (''erstellt benutz id=''||:P388_R_BENUTZERID);',
'     end if;',
'     ',
'  end if;   ',
'  if(:P388_BENUTZER_GID is not null) then',
'      :P388_BENUTZERNAME_FREITEXT := '''';',
'  end if;',
'end;'))
,p_attribute_02=>'P65_NACHNAME_AUSGEWAEHLT, P65_VORNAME_AUSGEWAEHLT, P65_EMAIL_AUSGEWAEHLT, P65_GID_CHOSEN, P388_NACHNAME, P388_VORNAME, P388_EMAIL, P388_BENUTZER_GID, P65_ABTEILUNG_AUSGEWAEHLT, P388_ABTEILUNG, P388_BENUTZERNAME_FREITEXT, P388_R_BENUTZERID'
,p_attribute_03=>'P65_NACHNAME_AUSGEWAEHLT, P65_VORNAME_AUSGEWAEHLT, P65_EMAIL_AUSGEWAEHLT, P65_GID_CHOSEN, P388_NACHNAME, P388_VORNAME, P388_EMAIL, P388_BENUTZER_GID, P65_ABTEILUNG_AUSGEWAEHLT, P388_ABTEILUNG, P388_BENUTZERNAME_FREITEXT, P388_R_BENUTZERID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(834279548748992788)
,p_event_id=>wwv_flow_imp.id(897957499166386510)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- test',
'declare',
' l_co number :=0;',
'begin',
' if (:P65_GID_CHOSEN is not null) then',
'   select :P65_NACHNAME_AUSGEWAEHLT, :P65_VORNAME_AUSGEWAEHLT, :P65_EMAIL_AUSGEWAEHLT, :P65_ABTEILUNG_AUSGEWAEHLT, :P65_GID_CHOSEN ',
'     into     :P388_NACHNAME,      :P388_VORNAME,         :P388_EMAIL,            :P388_ABTEILUNG,    :P388_BENUTZER_GID',
'     from dual;',
'  end if;',
'																	 ',
' if (:P388_BENUTZER_GID is not null) then',
'     select count(*) into l_co   from t_benutzer where GID = :P388_BENUTZER_GID;',
'     if(l_co >0) then',
'         select  Benutzerid into  :P388_R_BENUTZERID from t_benutzer ',
'         where GID = :P388_BENUTZER_GID fetch  first 1 rows only; ',
'        -- :P388_R_BENUTZERID := PCK_RI.fCreatePlaceHolderUser(:P65_GID_CHOSEN);',
'        -- debug (''exist benutz id=''||:P388_R_BENUTZERID);',
'     else',
'       insert into t_benutzer (nachname,',
'        vorname, email, abteilung, gid)',
'       values ( :P65_NACHNAME_AUSGEWAEHLT, ',
'       :P65_VORNAME_AUSGEWAEHLT, :P65_EMAIL_AUSGEWAEHLT, :P65_ABTEILUNG_AUSGEWAEHLT, :P65_GID_CHOSEN )',
'       returning benutzerid into :P388_R_BENUTZERID;',
'       --debug (''erstellt benutz id=''||:P388_R_BENUTZERID);',
'     end if;',
'     ',
'  end if;   ',
'  if(:P388_BENUTZER_GID is not null) then',
'      :P388_BENUTZERNAME_FREITEXT := '''';',
'  end if;',
'end;'))
,p_attribute_02=>'P65_NACHNAME_AUSGEWAEHLT, P65_VORNAME_AUSGEWAEHLT, P65_EMAIL_AUSGEWAEHLT, P65_GID_CHOSEN, P388_NACHNAME, P388_VORNAME, P388_EMAIL, P388_BENUTZER_GID, P65_ABTEILUNG_AUSGEWAEHLT, P388_ABTEILUNG, P388_BENUTZERNAME_FREITEXT, P388_R_BENUTZERID'
,p_attribute_03=>'P65_NACHNAME_AUSGEWAEHLT, P65_VORNAME_AUSGEWAEHLT, P65_EMAIL_AUSGEWAEHLT, P65_GID_CHOSEN, P388_NACHNAME, P388_VORNAME, P388_EMAIL, P388_BENUTZER_GID, P65_ABTEILUNG_AUSGEWAEHLT, P388_ABTEILUNG, P388_BENUTZERNAME_FREITEXT, P388_R_BENUTZERID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(907587894495692571)
,p_name=>'Switch Change'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P388_LDAP_DIRECTEINGABE'
,p_condition_element=>'P388_LDAP_DIRECTEINGABE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(907587816568692570)
,p_event_id=>wwv_flow_imp.id(907587894495692571)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P388_BENUTZERNAME_FREITEXT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(907587455657692567)
,p_event_id=>wwv_flow_imp.id(907587894495692571)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P388_BENUTZERNAME_FREITEXT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(907587625466692568)
,p_event_id=>wwv_flow_imp.id(907587894495692571)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(898574768810732141)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(907587337323692566)
,p_event_id=>wwv_flow_imp.id(907587894495692571)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(898574768810732141)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(907586860444692561)
,p_event_id=>wwv_flow_imp.id(907587894495692571)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P388_NACHNAME,P388_VORNAME'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(907587194996692564)
,p_event_id=>wwv_flow_imp.id(907587894495692571)
,p_event_result=>'FALSE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P388_NACHNAME,P388_VORNAME'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(883688622601223179)
,p_name=>'Cancel Dialog'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(897947950900018332)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(883688474222223178)
,p_event_id=>wwv_flow_imp.id(883688622601223179)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(834278142558992774)
,p_name=>'betreuid readonly'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P388_VEX_FBEX'
,p_condition_element=>'P388_VEX_FBEX'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(834278061909992773)
,p_event_id=>wwv_flow_imp.id(834278142558992774)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P388_BETREUERID'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(834277937715992772)
,p_event_id=>wwv_flow_imp.id(834278142558992774)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P388_BETREUERID'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(897946365184990102)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'erstelle Benutzer'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_co number:=0;',
'l_count number;',
'v_notification_cnt number;',
'begin',
'-- insertinf data into benutzer table ',
'     begin',
'     -- Check if user with given GID exists in ''t_benutzer'' table',
'     select count(*) into l_co from t_benutzer where gid = :P388_BENUTZER_GID;',
'     exception when no_data_found then l_co := 0;',
'     end;',
'    if (:P388_R_BENUTZERID is null and l_co =0 and :P388_NACHNAME is not null ) then',
'    -- Insert new user to ''t_benutzer'' if conditions are met',
'      insert into t_benutzer (gid,   ',
'                              nachname,       ',
'                               vorname,              ',
'                               email,  ',
'                               abteilung)',
'       values (  :P388_BENUTZER_GID, :P388_NACHNAME, :P388_VORNAME, :P388_EMAIL, :P388_ABTEILUNG )',
'       returning benutzerid into :P388_R_BENUTZERID;',
'      -- debug('' after insert :P388_R_BENUTZERID=''|| :P388_R_BENUTZERID);',
'       if (:P388_ROLLE !=1006 ) then',
'        :P388_BETREUERID := null;',
'       end if;',
'    end if;',
'   ',
'    if :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null then',
'    -- Update ''T_ET_B_AK_REF_THEMA_BENUTZER'' based on whether an ID exists or not',
'    -- debug('' bevor update T_ET_B_AK_REF_THEMA_BENUTZER, P388_BENUTZERNAME_FREITEXT=''|| :P388_BENUTZERNAME_FREITEXT);',
'        update T_ET_B_AK_REF_THEMA_BENUTZER',
'        set benutzerid = :P388_R_BENUTZERID,',
'            ET_B_AKID = :P388_ET_B_AKID,',
'            BENUTZERNAME = :P388_BENUTZERNAME_FREITEXT,',
'            BETREUERID = :P388_BETREUERID,--case when :P388_ROLLE != 1002 then null else :P388_BETREUERID end,',
'            APPROVED =  to_number(:P388_APPROVED),',
'            BEMERKUNG = :P388_BEMERKUNG,',
'            BEREICH = :P388_BEREICH,',
'            ROLLEID = :P388_ROLLE',
'        WHERE ET_B_AK_REF_THEMA_BENUTZERID = :P388_ET_B_AK_REF_THEMA_BENUTZERID;',
'    else',
'     -- first check if for et_b_AK and Benutzerid and rolleid one entry exists already ',
'        select count(*) into l_count from T_ET_B_AK_REF_THEMA_BENUTZER ',
'           where ET_B_AKID = :P388_ET_B_AKID and benutzerid = :P388_R_BENUTZERID and rolleid = :P388_ROLLE;',
'        if( l_count > 0 )   then ',
'              select ET_B_AK_REF_THEMA_BENUTZERID into :P388_ET_B_AK_REF_THEMA_BENUTZERID',
'               from T_ET_B_AK_REF_THEMA_BENUTZER ',
'               where ET_B_AKID = :P388_ET_B_AKID and benutzerid = :P388_R_BENUTZERID and rolleid = :P388_ROLLE and rownum <2;',
'           ',
'        end if;',
'        -- debug(''  insert into T_ET_B_AK_REF_THEMA_BENUTZER, P388_BENUTZERNAME_FREITEXT=''|| :P388_BENUTZERNAME_FREITEXT ||'' benutzerid='' || :P388_R_BENUTZERID);',
'        if(:P388_ET_B_AK_REF_THEMA_BENUTZERID is null) then',
'          insert into T_ET_B_AK_REF_THEMA_BENUTZER  (',
'            benutzerid,',
'            ET_B_AKID,',
'            BENUTZERNAME,',
'            BETREUERID,',
'            APPROVED,',
'            BEMERKUNG,',
'            BEREICH,',
'            ROLLEID)',
'          values (',
'            :P388_R_BENUTZERID,',
'            :P388_ET_B_AKID,',
'            :P388_BENUTZERNAME_FREITEXT,',
'            :P388_BETREUERID,--case when :P388_ROLLE != 1002 then null else :P388_BETREUERID end,',
'            to_number(:P388_APPROVED),',
'            :P388_BEMERKUNG,',
'            :P388_BEREICH,',
'            :P388_ROLLE',
'          )',
'          returning ET_B_AK_REF_THEMA_BENUTZERID into :P388_ET_B_AK_REF_THEMA_BENUTZERID;',
'        end if;  ',
'    end if;',
'-- Merge new theme references with existing ones in ''T_ET_B_AK_REF_THEMA_BENUTZER_REF_ET_B_AK_REF_THEMA''',
'merge into T_ET_B_AK_REF_THEMA_BENUTZER_REF_ET_B_AK_REF_THEMA dest',
'using (select :P388_ET_B_AK_REF_THEMA_BENUTZERID as ET_B_AK_REF_THEMA_BENUTZERID, column_value as THEMA_REF_ET_B_AKID ',
'       from table(apex_string.split_numbers(:P388_THEMA_REF_ET_B_AKID, '':''))) src',
'on (src.ET_B_AK_REF_THEMA_BENUTZERID = dest.ET_B_AK_REF_THEMA_BENUTZERID',
'   and src.THEMA_REF_ET_B_AKID = dest.THEMA_REF_ET_B_AKID)',
'when not matched then ',
'insert (ET_B_AK_REF_THEMA_BENUTZERID, THEMA_REF_ET_B_AKID)',
'values (src.ET_B_AK_REF_THEMA_BENUTZERID, src.THEMA_REF_ET_B_AKID);',
'-- Remove unmatched theme references from ''T_ET_B_AK_REF_THEMA_BENUTZER_REF_ET_B_AK_REF_THEMA''',
'delete from T_ET_B_AK_REF_THEMA_BENUTZER_REF_ET_B_AK_REF_THEMA ',
'where ET_B_AK_REF_THEMA_BENUTZERID = :P388_ET_B_AK_REF_THEMA_BENUTZERID',
'    and THEMA_REF_ET_B_AKID not in (select column_value from TABLE(APEX_STRING.split_numbers(:P388_THEMA_REF_ET_B_AKID, '':'')));   ',
'',
'',
'    --Notification ',
'    --begin',
'       -- select count(*) into v_notification_cnt from t_benachrichtigung',
'       -- where arbeitskreisid = 1500 and betroffener_anwender = nvl(:P388_R_BENUTZERID, :P388_BENUTZERNAME_FREITEXT);',
'      --  exception when no_data_found then v_notification_cnt :=0;',
'      --  end;',
'        if :P388_ROLLE in(1002,1006,1040) and :REQUEST = ''CREATE''   then  -- VEX, FBEX, KFEX ---- and v_notification_cnt <=0 and ',
'            begin',
'            PCK_RI_BENACHRICHTIGUNG.working_group_user (',
'                aarbeitskreise    => 1500,',
unistr('                atext              => ''Benutzer zur Arbeitsgruppe hinzugef\00FCgt'', --emano_util.fLang(''Benutzer zur Arbeitsgruppe hinzugef\00FCgt'',''Benutzer zur Arbeitsgruppe hinzugef\00FCgt''), -- User Added to Arbeitskreis'),
'                agrund             => 130,',
'                aloeschmarker      => 0,',
'                abenutzerid        =>:G_BENUTZERID,',
'                abetroffener_anwender =>nvl(:P388_R_BENUTZERID,:P388_BENUTZERNAME_FREITEXT)',
'        --        aGrund70_bereich IN NUMBER',
'            );',
'            end;',
'        end if;',
'',
' end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Fehler im Prozess "erstelle Benutzer"'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2774265950714398133
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(897946079956989115)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Process L\00F6sche Themen des Anwenders')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    -- Remove entries from ''T_ET_B_AK_REF_THEMA_BENUTZER_REF_ET_B_AK_REF_THEMA'' based on the provided ID',
'    delete from T_ET_B_AK_REF_THEMA_BENUTZER_REF_ET_B_AK_REF_THEMA',
'    where ET_B_AK_REF_THEMA_BENUTZERID = :P388_ET_B_AK_REF_THEMA_BENUTZERID;',
'    -- Remove entries from ''T_ET_B_AK_REF_THEMA_BENUTZER'' based on the provided ID',
'    delete from T_ET_B_AK_REF_THEMA_BENUTZER',
'    where ET_B_AK_REF_THEMA_BENUTZERID = :P388_ET_B_AK_REF_THEMA_BENUTZERID;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(897948431081018338)
,p_internal_uid=>2774266235942399120
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Remove entries from ''T_ET_B_AK_REF_THEMA_BENUTZER_REF_ET_B_AK_REF_THEMA'' based on the provided ID',
'delete from T_ET_B_AK_REF_THEMA_BENUTZER_REF_ET_B_AK_REF_THEMA',
'where ET_B_AK_REF_THEMA_BENUTZERID = :P388_ET_B_AK_REF_THEMA_BENUTZERID;',
'-- Remove entries from ''T_ET_B_AK_REF_THEMA_BENUTZER'' based on the provided ID',
'delete from T_ET_B_AK_REF_THEMA_BENUTZER',
'where ET_B_AK_REF_THEMA_BENUTZERID = :P388_ET_B_AK_REF_THEMA_BENUTZERID;',
unistr('-- wenn Vex gel\00F6scht wird setze  die von ihm betreuenden FBEX auf null und approve status auf 0'),
'-- If the role is ''Vex'', reset the ''betreuerid'' and ''approved'' status for associated records in ''T_ET_B_AK_REF_THEMA_BENUTZER''',
'/*if( :P388_ROLLE =1002) then',
'    update T_ET_B_AK_REF_THEMA_BENUTZER',
'       set betreuerid = '''', approved = 0  ',
'     where betreuerid = :P388_ET_B_AK_REF_THEMA_BENUTZERID;',
' end if;*/'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(897944316333984267)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_01=>'P388_JS_LANG'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2774267999565403968
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1055142127123317514)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 27.02.2025 12:25 pm ',
'declare',
'l_co number :=0;',
'begin',
'  if(:P388_R_BENUTZERID is  null and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null) then',
'     select benutzerid,',
'     ET_B_AKID,',
'    --  BENUTZERNAME,',
'     BETREUERID,',
'     APPROVED,',
'     BEMERKUNG,',
'     BEREICH,',
'     ROLLEID',
'     into  :P388_R_BENUTZERID,',
'     :P388_ET_B_AKID,',
'    --  :P388_BENUTZERNAME_FREITEXT,',
'     :P388_BETREUERID,',
'     :P388_APPROVED,',
'     :P388_BEMERKUNG,',
'     :P388_BEREICH,',
'     :P388_ROLLE',
'      from  T_ET_B_AK_REF_THEMA_BENUTZER  ',
'     where  ET_B_AK_REF_THEMA_BENUTZERID = :P388_ET_B_AK_REF_THEMA_BENUTZERID fetch first 1 rows only ;',
'    -- set freitext schalter',
'    if(:P388_R_BENUTZERID is  null) then',
'      :P388_LDAP_DIRECTEINGABE :=0;',
'    end if;',
'  end if;',
'   END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2617070188776070721
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(898548066558576994)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Benutzerdaten'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_co number :=0;',
'begin',
'--   DEBUG(''Starting process'', ''P388_ET_B_AK_REF_THEMA_BENUTZERID=''||:P388_ET_B_AK_REF_THEMA_BENUTZERID);',
'--   DEBUG(''Initial values'', ''P388_NACHNAME=''||:P388_NACHNAME||'', P388_VORNAME=''||:P388_VORNAME);',
'',
'  if(:P388_R_BENUTZERID is null and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null) then',
'    --  DEBUG(''Entering first condition'', ''Getting data from T_ET_B_AK_REF_THEMA_BENUTZER'');',
'   ',
'     select benutzerid,',
'     ET_B_AKID,',
'--    BENUTZERNAME,',
'    BETREUERID,',
'     APPROVED,',
'     BEMERKUNG,',
'     BEREICH,',
'     ROLLEID',
'     into  :P388_R_BENUTZERID,',
'     :P388_ET_B_AKID,',
'--    :P388_BENUTZERNAME_FREITEXT,',
'     :P388_BETREUERID,',
'     :P388_APPROVED,',
'     :P388_BEMERKUNG,',
'     :P388_BEREICH,',
'     :P388_ROLLE',
'      from  T_ET_B_AK_REF_THEMA_BENUTZER  ',
'     where  ET_B_AK_REF_THEMA_BENUTZERID = :P388_ET_B_AK_REF_THEMA_BENUTZERID fetch first 1 rows only;',
'    ',
'    -- DEBUG(''After first select'', ''P388_R_BENUTZERID=''||:P388_R_BENUTZERID);',
'    ',
'    -- set freitext schalter',
'    if(:P388_R_BENUTZERID is null) then',
'      :P388_LDAP_DIRECTEINGABE :=0;',
'    --   DEBUG(''Setting LDAP_DIRECTEINGABE'', ''0'');',
'    end if;',
'  end if;',
'',
'  if :P388_LDAP_DIRECTEINGABE=0 then ',
'   select  BENUTZERNAME',
'',
'     into    :P388_BENUTZERNAME_FREITEXT',
'   ',
'      from  T_ET_B_AK_REF_THEMA_BENUTZER  ',
'     where  ET_B_AK_REF_THEMA_BENUTZERID = :P388_ET_B_AK_REF_THEMA_BENUTZERID fetch first 1 rows only;',
'',
'end if;',
'--   DEBUG(''Before t_benutzer lookup'', ''P388_R_BENUTZERID=''||:P388_R_BENUTZERID);',
'  ',
'  if(:P388_R_BENUTZERID is not null) then',
'      begin',
'          select b.gid, b.nachname, b.vorname, b.email, b.Abteilung',
'          into :P388_BENUTZER_GID, :P388_NACHNAME, :P388_VORNAME, :P388_EMAIL, :P388_ABTEILUNG',
'          from t_benutzer b',
'          where b.benutzerid = nvl(:P388_R_BENUTZERID, -1);',
'          ',
'        --   DEBUG(''After t_benutzer lookup'', ''P388_NACHNAME=''||:P388_NACHNAME||'', P388_VORNAME=''||:P388_VORNAME);',
'      exception',
'          when no_data_found then',
'              DEBUG(''t_benutzer lookup failed'', ''No data found for P388_R_BENUTZERID=''||:P388_R_BENUTZERID);',
'      end;',
'  else',
'      DEBUG(''Skipping t_benutzer lookup'', ''P388_R_BENUTZERID is null'');',
'  end if;',
'',
'  -- Check items again before setting other values',
'--   DEBUG(''Final values before role check'', ',
'--         ''P388_NACHNAME=''||:P388_NACHNAME||',
'--         '', P388_VORNAME=''||:P388_VORNAME||',
'--         '', P388_R_BENUTZERID=''||:P388_R_BENUTZERID);',
'',
'  -- wenn benutzer is VEX und nicht gleichzeitig VKO oder Fachadmin, dann Vorbelege Rolle als FBEx',
'  select count(*) into l_co from dual ',
'     where pck_ri.fgetUserid in (select distinct benutzerid from t_benutzer_ref_Rolle where rolleid = 1002)',
'     and pck_ri.fgetUserid not in (select distinct benutzerid from t_benutzer_ref_Rolle where rolleid in (1003, 1000));',
'  ',
'  if(l_co > 0 and :P388_ET_B_AK_REF_THEMA_BENUTZERID is null) then -- lege Rolle auf FBEX fest',
'      :P388_ROLLE := 1006;',
'      :P388_APPROVED := 0;',
'    --   DEBUG(''Setting default role'', ''P388_ROLLE=1006, P388_APPROVED=0'');',
'  end if;',
'  ',
'--   DEBUG(''End of process'', ''P388_NACHNAME=''||:P388_NACHNAME||'', P388_VORNAME=''||:P388_VORNAME);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2773664249340811241
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 27.02.2025 12:25 pm ',
'declare',
'l_co number :=0;',
'begin',
'  if(:P388_R_BENUTZERID is  null and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null) then',
'     select benutzerid,',
'     ET_B_AKID,',
'     BENUTZERNAME,',
'     BETREUERID,',
'     APPROVED,',
'     BEMERKUNG,',
'     BEREICH,',
'     ROLLEID',
'     into  :P388_R_BENUTZERID,',
'     :P388_ET_B_AKID,',
'     :P388_BENUTZERNAME_FREITEXT,',
'     :P388_BETREUERID,',
'     :P388_APPROVED,',
'     :P388_BEMERKUNG,',
'     :P388_BEREICH,',
'     :P388_ROLLE',
'      from  T_ET_B_AK_REF_THEMA_BENUTZER  ',
'     where  ET_B_AK_REF_THEMA_BENUTZERID = :P388_ET_B_AK_REF_THEMA_BENUTZERID fetch first 1 rows only ;',
'    -- set freitext schalter',
'    if(:P388_R_BENUTZERID is  null) then',
'      :P388_LDAP_DIRECTEINGABE :=0;',
'    end if;',
'  end if;',
'   --debug( ''Render :P388_R_BENUTZERID=''||:P388_R_BENUTZERID);',
'  --debug( '':P388_ET_B_AKID=''||:P388_ET_B_AKID);',
'  if(:P388_R_BENUTZERID is not null ) then',
'      select b.gid,            b.nachname,           b.vorname,      b.email, b.Abteilung',
'      into :P388_BENUTZER_GID,  :P388_NACHNAME, :P388_VORNAME, :P388_EMAIL, :P388_ABTEILUNG',
'      from t_benutzer b',
'      where b.benutzerid =  nvl(:P388_R_BENUTZERID, -1);',
'   end if;',
'',
'  -- wenn  benutzer is VEX und nicht gleichzeitig VKO oder Fachadmin, dann  Vorbelege Rolle als FBEx',
'  select count(*) into l_co from dual ',
'     where --1280 not in ( select distinct benutzerid from t_et_b_ak_ref_Benutzer) and ',
'        pck_ri.fgetUserid in ( select distinct benutzerid from t_benutzer_ref_Rolle where rolleid =1002)',
'        and pck_ri.fgetUserid not in ( select distinct benutzerid from t_benutzer_ref_Rolle where rolleid in (1003, 1000) );',
'   if(l_co > 0 and :P388_ET_B_AK_REF_THEMA_BENUTZERID is null) then --   lege  Rolle auf FBEX fest',
'      :P388_ROLLE := 1006;',
'      :P388_APPROVED := 0;',
'   end if;',
'end;',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1055141936350317512)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Benutzerdaten_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_co number :=0;',
'begin',
'--   DEBUG(''Starting process'', ''P388_ET_B_AK_REF_THEMA_BENUTZERID=''||:P388_ET_B_AK_REF_THEMA_BENUTZERID);',
'--   DEBUG(''Initial values'', ''P388_NACHNAME=''||:P388_NACHNAME||'', P388_VORNAME=''||:P388_VORNAME);',
'',
'  if(:P388_R_BENUTZERID is null and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null) then',
'    --  DEBUG(''Entering first condition'', ''Getting data from T_ET_B_AK_REF_THEMA_BENUTZER'');',
'   ',
'     select benutzerid,',
'     ET_B_AKID,',
'    -- BENUTZERNAME,',
'     BETREUERID,',
'     APPROVED,',
'     BEMERKUNG,',
'     BEREICH,',
'     ROLLEID',
'     into  :P388_R_BENUTZERID,',
'     :P388_ET_B_AKID,',
'    -- :P388_BENUTZERNAME_FREITEXT,',
'     :P388_BETREUERID,',
'     :P388_APPROVED,',
'     :P388_BEMERKUNG,',
'     :P388_BEREICH,',
'     :P388_ROLLE',
'      from  T_ET_B_AK_REF_THEMA_BENUTZER  ',
'     where  ET_B_AK_REF_THEMA_BENUTZERID = :P388_ET_B_AK_REF_THEMA_BENUTZERID fetch first 1 rows only;',
'    ',
'    -- DEBUG(''After first select'', ''P388_R_BENUTZERID=''||:P388_R_BENUTZERID);',
'    ',
'    -- set freitext schalter',
'    if(:P388_R_BENUTZERID is null) then',
'      :P388_LDAP_DIRECTEINGABE :=0;',
'      DEBUG(''Setting LDAP_DIRECTEINGABE'', ''0'');',
'    end if;',
'  end if;',
'',
'--   DEBUG(''Before t_benutzer lookup'', ''P388_R_BENUTZERID=''||:P388_R_BENUTZERID);',
'  ',
'  if(:P388_R_BENUTZERID is not null) then',
'      begin',
'          select b.gid, b.nachname, b.vorname, b.email, b.Abteilung',
'          into :P388_BENUTZER_GID, :P388_NACHNAME, :P388_VORNAME, :P388_EMAIL, :P388_ABTEILUNG',
'          from t_benutzer b',
'          where b.benutzerid = nvl(:P388_R_BENUTZERID, -1);',
'          ',
'        --   DEBUG(''After t_benutzer lookup'', ''P388_NACHNAME=''||:P388_NACHNAME||'', P388_VORNAME=''||:P388_VORNAME);',
'      exception',
'          when no_data_found then',
'              DEBUG(''t_benutzer lookup failed'', ''No data found for P388_R_BENUTZERID=''||:P388_R_BENUTZERID);',
'      end;',
'  else',
'      DEBUG(''Skipping t_benutzer lookup'', ''P388_R_BENUTZERID is null'');',
'  end if;',
'',
'  -- Check items again before setting other values',
'--   DEBUG(''Final values before role check'', ',
'--         ''P388_NACHNAME=''||:P388_NACHNAME||',
'--         '', P388_VORNAME=''||:P388_VORNAME||',
'--         '', P388_R_BENUTZERID=''||:P388_R_BENUTZERID);',
'',
'  -- wenn benutzer is VEX und nicht gleichzeitig VKO oder Fachadmin, dann Vorbelege Rolle als FBEx',
'  select count(*) into l_co from dual ',
'     where pck_ri.fgetUserid in (select distinct benutzerid from t_benutzer_ref_Rolle where rolleid = 1002)',
'     and pck_ri.fgetUserid not in (select distinct benutzerid from t_benutzer_ref_Rolle where rolleid in (1003, 1000));',
'  ',
'  if(l_co > 0 and :P388_ET_B_AK_REF_THEMA_BENUTZERID is null) then -- lege Rolle auf FBEX fest',
'      :P388_ROLLE := 1006;',
'      :P388_APPROVED := 0;',
'    --   DEBUG(''Setting default role'', ''P388_ROLLE=1006, P388_APPROVED=0'');',
'  end if;',
'  ',
'--   DEBUG(''End of process'', ''P388_NACHNAME=''||:P388_NACHNAME||'', P388_VORNAME=''||:P388_VORNAME);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2617070379549070723
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 27.02.2025 12:25 pm ',
'declare',
'l_co number :=0;',
'begin',
'  if(:P388_R_BENUTZERID is  null and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null) then',
'     select benutzerid,',
'     ET_B_AKID,',
'     BENUTZERNAME,',
'     BETREUERID,',
'     APPROVED,',
'     BEMERKUNG,',
'     BEREICH,',
'     ROLLEID',
'     into  :P388_R_BENUTZERID,',
'     :P388_ET_B_AKID,',
'     :P388_BENUTZERNAME_FREITEXT,',
'     :P388_BETREUERID,',
'     :P388_APPROVED,',
'     :P388_BEMERKUNG,',
'     :P388_BEREICH,',
'     :P388_ROLLE',
'      from  T_ET_B_AK_REF_THEMA_BENUTZER  ',
'     where  ET_B_AK_REF_THEMA_BENUTZERID = :P388_ET_B_AK_REF_THEMA_BENUTZERID fetch first 1 rows only ;',
'    -- set freitext schalter',
'    if(:P388_R_BENUTZERID is  null) then',
'      :P388_LDAP_DIRECTEINGABE :=0;',
'    end if;',
'  end if;',
'   --debug( ''Render :P388_R_BENUTZERID=''||:P388_R_BENUTZERID);',
'  --debug( '':P388_ET_B_AKID=''||:P388_ET_B_AKID);',
'  if(:P388_R_BENUTZERID is not null ) then',
'      select b.gid,            b.nachname,           b.vorname,      b.email, b.Abteilung',
'      into :P388_BENUTZER_GID,  :P388_NACHNAME, :P388_VORNAME, :P388_EMAIL, :P388_ABTEILUNG',
'      from t_benutzer b',
'      where b.benutzerid =  nvl(:P388_R_BENUTZERID, -1);',
'   end if;',
'',
'  -- wenn  benutzer is VEX und nicht gleichzeitig VKO oder Fachadmin, dann  Vorbelege Rolle als FBEx',
'  select count(*) into l_co from dual ',
'     where --1280 not in ( select distinct benutzerid from t_et_b_ak_ref_Benutzer) and ',
'        pck_ri.fgetUserid in ( select distinct benutzerid from t_benutzer_ref_Rolle where rolleid =1002)',
'        and pck_ri.fgetUserid not in ( select distinct benutzerid from t_benutzer_ref_Rolle where rolleid in (1003, 1000) );',
'   if(l_co > 0 and :P388_ET_B_AK_REF_THEMA_BENUTZERID is null) then --   lege  Rolle auf FBEX fest',
'      :P388_ROLLE := 1006;',
'      :P388_APPROVED := 0;',
'   end if;',
'end;',
''))
);
wwv_flow_imp.component_end;
end;
/
