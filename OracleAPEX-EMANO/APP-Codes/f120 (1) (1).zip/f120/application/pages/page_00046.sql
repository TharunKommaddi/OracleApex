prompt --application/pages/page_00046
begin
--   Manifest
--     PAGE: 00046
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>46
,p_name=>unistr('Diff Verkn\00FCpfung Details')
,p_alias=>unistr('DIFF-VERKN\00DCPFUNG-DETAILS')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Diff Verkn\00FCpfung Details')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.hl {',
'  background-color: yellow;',
'',
'  color: black;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_max_width=>'400'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1068908938370951431)
,p_name=>'P46_VORSCHRIFT_REF_VORSCHRIFTID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1068908889444951430)
,p_name=>'P46_RR_GETEX_KEY'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1068908773257951429)
,p_name=>'P46_DEM_GETEX_KEY'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1068908608749951427)
,p_name=>'P46_LBL_EMPTY'
,p_item_sequence=>40
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>3
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1068908462494951426)
,p_name=>'P46_LBL_GETEX2_WERT'
,p_item_sequence=>50
,p_prompt=>'Lbl Getex2 Wert'
,p_source=>'<span style="background-color:#dddddd">Getex 2 Wert</span>'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1068908356579951425)
,p_name=>'P46_LBL_REGINDEX_WERT'
,p_item_sequence=>60
,p_prompt=>'Lbl Getex2 Wert'
,p_source=>'<span style="background-color:#dddddd">Regindex Wert</span>'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1068908274844951424)
,p_name=>'P46_LBL_EINSATZDATUM_NT'
,p_item_sequence=>80
,p_prompt=>'Lbl Einsatzdatum Nt'
,p_source=>'<span style="background-color:#dddddd">Einsatzdatum NT</span>'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>3
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1068908186462951423)
,p_name=>'P46_EINSATZ_NT_GETEX'
,p_item_sequence=>100
,p_prompt=>'Lbl Getex2 Wert'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(trunc(sc_date), ''dd.mm.yyyy'') --, sc_type, Reg_number,vorschriftid,  target_reg_number, multigroupid , successorsincluded',
' ',
' from MV_GETEX_Vorschrift_RELATION mv',
'  where v_id = :P46_RR_GETEX_KEY      --''653fb6e522dcb94d41b66276'' ',
'  and targetid = :P46_DEM_GETEX_KEY    --''65c9fa5f1d6f3d2e01c52c28''',
' and relationtype=''IS_DEMANDED_BY'' ',
' and SC_vehicletype in ( ''PCV'', ''INDEPENDENT'')',
'  and sc_type in ( ''New Types'') --''All Vehicles'',',
'  order by SC_vehicletype desc'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1068908089464951422)
,p_name=>'P46_EINSATZ_NT_REGINDEX'
,p_item_sequence=>120
,p_prompt=>'Lbl Getex2 Wert'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select --Datum_NEUE_TYPEN',
'case when (:P46_EINSATZ_NT_GETEX is null or  to_char(trunc(Datum_NEUE_TYPEN), ''dd.mm.yyyy'') != :P46_EINSATZ_NT_GETEX ) ',
'then ''<span style="background-color:yellow">'' || to_char(trunc(Datum_NEUE_TYPEN), ''dd.mm.yyyy'')  ||'' </span>''',
'else to_char(trunc(Datum_NEUE_TYPEN), ''dd.mm.yyyy'') end as val ',
'from T_VORSCHRIFT_REF_VORSCHRIFT',
'where VORSCHRIFT_REF_VORSCHRIFTID =:P46_VORSCHRIFT_REF_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1068908002723951421)
,p_name=>'P46_LBL_EINSATZDATUM_AT'
,p_item_sequence=>130
,p_prompt=>'Lbl Einsatzdatum Nt'
,p_source=>'<span style="background-color:#dddddd"> Einsatzdatum AT </>'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>3
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1068907858856951420)
,p_name=>'P46_EINSATZ_AT_GETEX'
,p_item_sequence=>150
,p_prompt=>'Lbl Getex2 Wert'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select   --to_char(trunc(sc_date), ''dd.mm.yyyy'')  as val',
'    to_char(trunc(sc_date), ''dd.mm.yyyy'') ',
' from MV_GETEX_Vorschrift_RELATION mv',
'  where v_id = :P46_RR_GETEX_KEY      --''653fb6e522dcb94d41b66276'' ',
'  and targetid = :P46_DEM_GETEX_KEY    --''65c9fa5f1d6f3d2e01c52c28''',
' and relationtype=''IS_DEMANDED_BY'' ',
' and SC_vehicletype in ( ''PCV'', ''INDEPENDENT'')',
'  and sc_type in ( ''All Vehicles'') --,''New Types''',
'  order by SC_vehicletype desc'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1068907785882951419)
,p_name=>'P46_EINSATZ_AT_REGINDEX'
,p_item_sequence=>170
,p_prompt=>'Lbl Getex2 Wert'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select --Datum_ALLE_TYPEN',
'case when (:P46_EINSATZ_AT_GETEX is null or  to_char(trunc(Datum_ALLE_TYPEN), ''dd.mm.yyyy'') != :P46_EINSATZ_AT_GETEX ) ',
'then ''<span style="background-color:yellow">'' || to_char(trunc(Datum_ALLE_TYPEN), ''dd.mm.yyyy'')  ||'' </span>''',
'else to_char(trunc(Datum_ALLE_TYPEN), ''dd.mm.yyyy'') end as val ',
'from T_VORSCHRIFT_REF_VORSCHRIFT',
'where VORSCHRIFT_REF_VORSCHRIFTID =:P46_VORSCHRIFT_REF_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1068907648762951418)
,p_name=>'P46_LBL_HOEHERE_SERIE'
,p_item_sequence=>180
,p_prompt=>'Lbl Einsatzdatum Nt'
,p_source=>unistr('<span style="background-color:#dddddd"> H\00F6here Serien einbeziehen </>')
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>3
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1068907577485951417)
,p_name=>'P46_HOEHERE_SERIE_GETEX'
,p_item_sequence=>190
,p_prompt=>'Lbl Getex2 Wert'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct -- Reg_number,vorschriftid,  target_reg_number, multigroupid , successorsincluded,',
' case when (mv.multigroupid  is null or nvl(mv.successorsincluded, ''false'') =''false'' ) then ''Nein'' else ''Ja'' end as hohere_Ser',
' from MV_GETEX_Vorschrift_RELATION mv',
'  where v_id = :P46_RR_GETEX_KEY      --''653fb6e522dcb94d41b66276'' ',
'  and targetid = :P46_DEM_GETEX_KEY    --''65c9fa5f1d6f3d2e01c52c28''',
' and relationtype=''IS_DEMANDED_BY'' and SC_vehicletype in ( ''PCV'', ''INDEPENDENT'')',
'  and sc_type in (''All Vehicles'', ''New Types'')'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1068907442830951416)
,p_name=>'P46_HOEHERE_SERIE_REGINDEX'
,p_item_sequence=>200
,p_prompt=>'Lbl Getex2 Wert'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    case when nvl(Homologation_serie, 0) = 0 ',
'     then ',
'          case when nvl(:P46_HOEHERE_SERIE_GETEX, ''Nein'') = ''Ja''',
'         then ''<span style="background-color:yellow">Nein </span>''',
'         else ''Nein''  end  ',
'     else',
'        case when nvl(:P46_HOEHERE_SERIE_GETEX, ''Nein'') = ''Ja''',
'         then ''Ja'' ',
'         else ''<span style="background-color:yellow">Ja</span>''  end  ',
'     end as res',
'from T_VORSCHRIFT_REF_VORSCHRIFT',
'where VORSCHRIFT_REF_VORSCHRIFTID =:P46_VORSCHRIFT_REF_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
