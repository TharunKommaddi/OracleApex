prompt --application/pages/page_00044
begin
--   Manifest
--     PAGE: 00044
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>44
,p_name=>'Massenupdate Getex Attribute'
,p_alias=>'MASSENUPDATE-GETEX-ATTRIBUTE'
,p_step_title=>'Massenupdate Getex Attribute'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#IR_AT'').on(''click'', ''th input'', function() {',
'    var check_all = $("#IR_AT").find("th input:checked").is(":checked");',
'',
'    $("#IR_AT").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'',
'   // setSelecteVerknuepfungen();',
'});',
' ',
'$(''#r_lis'').on(''click'', ''th input'', function() {',
'    var check_all = $("#r_lis").find("th input:checked").is(":checked");',
'',
'    $("#r_lis").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'});',
'',
'$(''#r_edat'').on(''click'', ''th input'', function() {',
'    var check_all = $("#r_edat").find("th input:checked").is(":checked");',
'',
'    $("#r_edat").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'});',
'',
'',
'',
'',
'$(''#r_relation_bits'').on(''click'', ''th input'', function() {',
'    var check_all = $("#r_relation_bits").find("th input:checked").is(":checked");',
'',
'    $("#r_relation_bits").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'});',
'',
'',
'/////////////////////////////////////////////',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
'// Common function used by all reports to toggle switch states',
'function setRadioValue(baseId, value) {',
'    if (value === ''Y'') {',
'        apex.jQuery(`#${baseId}_Y`).prop(''checked'', true);',
'        apex.jQuery(`#${baseId}_N`).prop(''checked'', false);',
'    } else {',
'        apex.jQuery(`#${baseId}_Y`).prop(''checked'', false);',
'        apex.jQuery(`#${baseId}_N`).prop(''checked'', true);',
'    }',
'}',
'',
'/***********************************************',
' * REPORT 1: KERNDATEN (IDs: 1-8)',
' ***********************************************/',
'// Master switch control for Kerndaten',
'apex.jQuery(''#SWITCH_ALL_KERNDATEN_Y, #SWITCH_ALL_KERNDATEN_N'').on(''change'', function() {',
'    var isYes = this.id.endsWith(''_Y'');',
'    ',
'    // Update all Kerndaten switches',
'    for(let i = 1; i <= 8; i++) {',
'        setRadioValue(`SWITCH_KERNDATEN_${i}`, isYes ? ''Y'' : ''N'');',
'    }',
'});',
'',
'// Individual switch control for Kerndaten',
'for(let i = 1; i <= 8; i++) {',
'    apex.jQuery(`#SWITCH_KERNDATEN_${i}_Y, #SWITCH_KERNDATEN_${i}_N`).on(''change'', function() {',
'        var allYes = true;',
'        for(let j = 1; j <= 8; j++) {',
'            if (!apex.jQuery(`#SWITCH_KERNDATEN_${j}_Y`).prop(''checked'')) {',
'                allYes = false;',
'                break;',
'            }',
'        }',
'        setRadioValue(''SWITCH_ALL_KERNDATEN'', allYes ? ''Y'' : ''N'');',
'    });',
'}',
'',
'/***********************************************',
' * REPORT 2: EINSATZDATEN (IDs: 9-10)',
' ***********************************************/',
'// Master switch control for Einsatzdaten',
'apex.jQuery(''#SWITCH_ALL_EINSATZDATEN_Y, #SWITCH_ALL_EINSATZDATEN_N'').on(''change'', function() {',
'    var isYes = this.id.endsWith(''_Y'');',
'    ',
'    // Update all Einsatzdaten switches',
'    for(let i = 9; i <= 10; i++) {',
'        setRadioValue(`SWITCH_EINSATZDATEN_${i}`, isYes ? ''Y'' : ''N'');',
'    }',
'});',
'',
'// Individual switch control for Einsatzdaten',
'for(let i = 9; i <= 10; i++) {',
'    apex.jQuery(`#SWITCH_EINSATZDATEN_${i}_Y, #SWITCH_EINSATZDATEN_${i}_N`).on(''change'', function() {',
'        var allYes = true;',
'        for(let j = 9; j <= 10; j++) {',
'            if (!apex.jQuery(`#SWITCH_EINSATZDATEN_${j}_Y`).prop(''checked'')) {',
'                allYes = false;',
'                break;',
'            }',
'        }',
'        setRadioValue(''SWITCH_ALL_EINSATZDATEN'', allYes ? ''Y'' : ''N'');',
'    });',
'}',
'',
'/***********************************************',
' * REPORT 3: LISTEN ATTRIBUTE (IDs: 17-19)',
' ***********************************************/',
'// Master switch control for Listen Attribute',
'apex.jQuery(''#SWITCH_ALL_LISTEN_Y, #SWITCH_ALL_LISTEN_N'').on(''change'', function() {',
'    var isYes = this.id.endsWith(''_Y'');',
'    ',
'    // Update all Listen switches (now only 17-19)',
'    for(let i = 17; i <= 19; i++) {',
'        setRadioValue(`SWITCH_LISTEN_${i}`, isYes ? ''Y'' : ''N'');',
'    }',
'});',
'',
'// Individual switch control for Listen Attribute',
'for(let i = 17; i <= 19; i++) {',
'    apex.jQuery(`#SWITCH_LISTEN_${i}_Y, #SWITCH_LISTEN_${i}_N`).on(''change'', function() {',
'        var allYes = true;',
'        for(let j = 17; j <= 19; j++) {',
'            if (!apex.jQuery(`#SWITCH_LISTEN_${j}_Y`).prop(''checked'')) {',
'                allYes = false;',
'                break;',
'            }',
'        }',
'        setRadioValue(''SWITCH_ALL_LISTEN'', allYes ? ''Y'' : ''N'');',
'    });',
'}',
'',
'/***********************************************',
' * REPORT 4: RELATIONTYPE ATTRIBUTE (IDs: 12-16, 20)',
' ***********************************************/',
'// Master switch control for Relationtype Attribute',
'apex.jQuery(''#SWITCH_ALL_RELATIONTYPE_Y, #SWITCH_ALL_RELATIONTYPE_N'').on(''change'', function() {',
'    var isYes = this.id.endsWith(''_Y'');',
'    ',
'    // Update all Relationtype switches',
'    var relationIds = [12, 13, 14, 15, 16, 20];',
'    relationIds.forEach(function(id) {',
'        setRadioValue(`SWITCH_RELATIONTYPE_${id}`, isYes ? ''Y'' : ''N'');',
'    });',
'});',
'',
'// Individual switch control for Relationtype Attribute',
'var relationIds = [12, 13, 14, 15, 16, 20];',
'relationIds.forEach(function(i) {',
'    apex.jQuery(`#SWITCH_RELATIONTYPE_${i}_Y, #SWITCH_RELATIONTYPE_${i}_N`).on(''change'', fun'))
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4505130722735853826)
,p_plug_name=>'Content'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1083218943101632033)
,p_plug_name=>'Attributen Gruppen1'
,p_parent_plug_id=>wwv_flow_imp.id(4505130722735853826)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1083218836320632032)
,p_plug_name=>'Auswahl1'
,p_parent_plug_id=>wwv_flow_imp.id(1083218943101632033)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1083218785804632031)
,p_name=>'Attribute zur Aktualisierung - heading'
,p_parent_plug_id=>wwv_flow_imp.id(1083218836320632032)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_new_grid_column=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    to_number(''999999'') as attr_id,  -- Using a number for consistent data type',
'    APEX_ITEM.SWITCH(',
'        p_idx => 4,',
'        p_value => ''Y'',',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_ALL_KERNDATEN'',',
'        p_item_label => ''Kerndaten: All'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    ''Kerndaten'' as kerndaten',
'from dual',
'',
'union all',
'',
'select ',
'    attr_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 1,',
'        p_value => CASE ',
'                    WHEN INSTR('':''||:P44_SELECTED_KERNDATEN||'':'','':''||attr_id||'':'') > 0 ',
'                    THEN ''Y'' ',
'                    ELSE ''Y''',
'                  END,',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_KERNDATEN_''||attr_id,',
'        p_item_label => kerndaten||'': Switch'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    kerndaten',
'from (',
'    select 1 as attr_id, ''Vorschriftennummer'' as kerndaten from dual',
'    union',
'    select 2 as attr_id, ''Dokumentendatum'' as kerndaten from dual',
'    union',
'    select 3 as attr_id, ''Dokumententyp'' as kerndaten from dual',
'    union',
'    select 4 as attr_id, ''Titel Kurz'' as kerndaten from dual',
'    union',
'    select 5 as attr_id, ''Titel Lang'' as kerndaten from dual',
'    union',
'    select 6 as attr_id, ''Status der Vorschrift'' as kerndaten from dual',
'    union',
'    select 7 as attr_id, ''Einsatzdatum Modell'' as kerndaten from dual',
'    union',
'    select 8 as attr_id, ''Vorschriftentyp'' as kerndaten from dual',
') cte;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1083218638086632030)
,p_query_column_id=>1
,p_column_alias=>'ATTR_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1083217566347632019)
,p_query_column_id=>2
,p_column_alias=>'SWITCH_ITEM'
,p_column_display_sequence=>40
,p_column_heading=>'Switch Item'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1083218480253632028)
,p_query_column_id=>3
,p_column_alias=>'KERNDATEN'
,p_column_display_sequence=>50
,p_column_heading=>'Kerndaten'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1083218404290632027)
,p_name=>'Einsatzdaten Attribute  - heading'
,p_parent_plug_id=>wwv_flow_imp.id(1083218836320632032)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_grid_column_span=>2
,p_display_column=>3
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    to_number(''999999'') as edat_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 5,',
'        p_value => ''Y'',',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_ALL_EINSATZDATEN'',',
'        p_item_label => ''Einsatzdaten: All'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    ''Einsatzdaten'' as Einsatzdaten',
'from dual',
'',
'union all',
'',
'select ',
'    edat_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 2,',
'        p_value => CASE ',
'                    WHEN INSTR('':''||:P44_SELECTED_EINSATZDATEN||'':'','':''||edat_id||'':'') > 0 ',
'                    THEN ''Y'' ',
'                    ELSE ''Y''',
'                  END,',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_EINSATZDATEN_''||edat_id,',
'        p_item_label => Einsatzdaten||'': Switch'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    Einsatzdaten',
'from (',
'    select 9 as edat_id, ''Inkraftsetzungsdatum'' as Einsatzdaten from dual',
'    union',
'    select 10 as edat_id, ''Einsatzdatum Daten'' as Einsatzdaten from dual',
'    -- union',
unistr('    -- select 11 as edat_id, ''Au\00DFerkraftsetzungsdatum'' as Einsatzdaten from dual'),
') cte;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1083218134634632025)
,p_query_column_id=>1
,p_column_alias=>'EDAT_ID'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1083217501667632018)
,p_query_column_id=>2
,p_column_alias=>'SWITCH_ITEM'
,p_column_display_sequence=>40
,p_column_heading=>'Switch Item'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1083218115181632024)
,p_query_column_id=>3
,p_column_alias=>'EINSATZDATEN'
,p_column_display_sequence=>50
,p_column_heading=>'Einsatzdaten'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1083217975036632023)
,p_name=>'Listen Attribute - heading'
,p_parent_plug_id=>wwv_flow_imp.id(1083218836320632032)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_grid_column_span=>2
,p_display_column=>5
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    to_number(''999999'') as liAtt_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 6,',
'        p_value => ''Y'',',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_ALL_LISTEN'',',
'        p_item_label => ''Listen Attribute: All'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    ''Listen Attribute'' as Listen_Attribute',
'from dual',
'',
'union all',
'',
'select ',
'    liAtt_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 3,',
'        p_value => CASE ',
'                    WHEN INSTR('':''||:P44_SELECTED_LISTEN||'':'','':''||liAtt_id||'':'') > 0 ',
'                    THEN ''Y'' ',
'                    ELSE ''Y''',
'                  END,',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_LISTEN_''||liAtt_id,',
'        p_item_label => Listen_Attribute||'': Switch'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    Listen_Attribute',
'from (',
unistr('    select 17 as liAtt_id, ''L\00E4nder'' as Listen_Attribute from dual'),
'    union',
'    select 18 as liAtt_id, ''Themen'' as Listen_Attribute from dual',
'    union',
'    select 19 as liAtt_id, ''Fahrzeugklassen'' as Listen_Attribute from dual',
') cte;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    to_number(''999999'') as liAtt_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 6,',
'        p_value => ''Y'',',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_ALL_LISTEN'',',
'        p_item_label => ''Listen Attribute: All'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    ''Listen Attribute'' as Listen_Attribute',
'from dual',
'',
'union all',
'',
'select ',
'    liAtt_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 3,',
'        p_value => CASE ',
'                    WHEN INSTR('':''||:P44_SELECTED_LISTEN||'':'','':''||liAtt_id||'':'') > 0 ',
'                    THEN ''Y'' ',
'                    ELSE ''Y''',
'                  END,',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_LISTEN_''||liAtt_id,',
'        p_item_label => Listen_Attribute||'': Switch'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    Listen_Attribute',
'from (',
'    select 12 as liAtt_id, ''Sucessor / Predecessor'' as Listen_Attribute from dual',
'    union',
'    select 13 as liAtt_id, ''Linked'' as Listen_Attribute from dual',
'    union',
'    select 14 as liAtt_id, ''Changes'' as Listen_Attribute from dual',
'    union',
'    select 15 as liAtt_id, ''Demands'' as Listen_Attribute from dual',
'    union',
'    select 16 as liAtt_id, ''Equivalent'' as Listen_Attribute from dual',
'    union',
unistr('    select 17 as liAtt_id, ''L\00E4nder'' as Listen_Attribute from dual'),
'    union',
'    select 18 as liAtt_id, ''Themen'' as Listen_Attribute from dual',
'    union',
'    select 19 as liAtt_id, ''Fahrzeugklassen'' as Listen_Attribute from dual',
') cte;'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1083217746885632021)
,p_query_column_id=>1
,p_column_alias=>'LIATT_ID'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1083217383849632017)
,p_query_column_id=>2
,p_column_alias=>'SWITCH_ITEM'
,p_column_display_sequence=>40
,p_column_heading=>'Switch Item'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1083217676517632020)
,p_query_column_id=>3
,p_column_alias=>'LISTEN_ATTRIBUTE'
,p_column_display_sequence=>50
,p_column_heading=>'Listen Attribute'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1057074870399661227)
,p_name=>'Relationtype Attribute - heading'
,p_parent_plug_id=>wwv_flow_imp.id(1083218836320632032)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_grid_column_span=>2
,p_display_column=>7
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    to_number(''999999'') as relAtt_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 7,',
'        p_value => ''Y'',',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_ALL_RELATIONTYPE'',',
'        p_item_label => ''Relationtype Attribute: All'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    ''Relationtype Attribute'' as Relationtype_Attribute',
'from dual',
'',
'union all',
'',
'select ',
'    relAtt_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 4,',
'        p_value => CASE ',
'                    WHEN INSTR('':''||:P44_SELECTED_RELATIONTYPE||'':'','':''||relAtt_id||'':'') > 0 ',
'                    THEN ''Y'' ',
'                    ELSE ''Y''',
'                  END,',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_RELATIONTYPE_''||relAtt_id,',
'        p_item_label => Relationtype_Attribute||'': Switch'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    Relationtype_Attribute',
'from (',
'    select 12 as relAtt_id, ''Successor / Predecessor'' as Relationtype_Attribute from dual',
'    union',
'    select 13 as relAtt_id, ''Linked'' as Relationtype_Attribute from dual',
'    union',
'    select 14 as relAtt_id, ''Changes'' as Relationtype_Attribute from dual',
'    union',
'    select 15 as relAtt_id, ''Demands'' as Relationtype_Attribute from dual',
'    union',
'    select 16 as relAtt_id, ''Equivalent'' as Relationtype_Attribute from dual',
'    union',
'    select 20 as relAtt_id, ''Consolidates'' as Relationtype_Attribute from dual',
') cte;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    to_number(''999999'') as liAtt_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 6,',
'        p_value => ''Y'',',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_ALL_LISTEN'',',
'        p_item_label => ''Listen Attribute: All'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    ''Listen Attribute'' as Listen_Attribute',
'from dual',
'',
'union all',
'',
'select ',
'    liAtt_id,',
'    APEX_ITEM.SWITCH(',
'        p_idx => 3,',
'        p_value => CASE ',
'                    WHEN INSTR('':''||:P44_SELECTED_LISTEN||'':'','':''||liAtt_id||'':'') > 0 ',
'                    THEN ''Y'' ',
'                    ELSE ''Y''',
'                  END,',
'        p_on_value => ''Y'',',
'        p_on_label => ''Ja'',',
'        p_off_value => ''N'',',
'        p_off_label => ''Nein'',',
'        p_item_id => ''SWITCH_LISTEN_''||liAtt_id,',
'        p_item_label => Listen_Attribute||'': Switch'',',
'        p_attributes => ''class="custom-switch"''',
'    ) as switch_item,',
'    Listen_Attribute',
'from (',
'    select 12 as liAtt_id, ''Sucessor / Predecessor'' as Listen_Attribute from dual',
'    union',
'    select 13 as liAtt_id, ''Linked'' as Listen_Attribute from dual',
'    union',
'    select 14 as liAtt_id, ''Changes'' as Listen_Attribute from dual',
'    union',
'    select 15 as liAtt_id, ''Demands'' as Listen_Attribute from dual',
'    union',
'    select 16 as liAtt_id, ''Equivalent'' as Listen_Attribute from dual',
'    union',
unistr('    select 17 as liAtt_id, ''L\00E4nder'' as Listen_Attribute from dual'),
'    union',
'    select 18 as liAtt_id, ''Themen'' as Listen_Attribute from dual',
'    union',
'    select 19 as liAtt_id, ''Fahrzeugklassen'' as Listen_Attribute from dual',
') cte;'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1057074504987661223)
,p_query_column_id=>1
,p_column_alias=>'RELATT_ID'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1057074706874661225)
,p_query_column_id=>2
,p_column_alias=>'SWITCH_ITEM'
,p_column_display_sequence=>20
,p_column_heading=>'Switch Item'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1057074412122661222)
,p_query_column_id=>3
,p_column_alias=>'RELATIONTYPE_ATTRIBUTE'
,p_column_display_sequence=>40
,p_column_heading=>'Relationtype Attribute'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4061556255266152951)
,p_plug_name=>'Fehlermeldung'
,p_parent_plug_id=>wwv_flow_imp.id(4505130722735853826)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:t-Alert--removeHeading:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('In der Massenbearbeitung k\00F6nnen nur Vorschriften bearbeitet werden, die Status Master = "GETEX" haben.')
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P44_ANY_MASTER_NOT_GETEX > 0'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4513709708359111389)
,p_plug_name=>'Attributen Gruppen'
,p_parent_plug_id=>wwv_flow_imp.id(4505130722735853826)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4513710093588111393)
,p_plug_name=>'Auswahl'
,p_parent_plug_id=>wwv_flow_imp.id(4513709708359111389)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1060110765700159388)
,p_name=>'Relationtype Atrribute'
,p_region_name=>'r_relation_bits'
,p_parent_plug_id=>wwv_flow_imp.id(4513710093588111393)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>70
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_grid_column_span=>2
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte as (',
'    select 12 as liAtt_id, ''Successor / Predecessor'' as Relationtype_Atrribute from dual',
'    union',
'    select 13 as liAtt_id, ''Linked To'' as Relationtype_Atrribute from dual',
'    union',
'    select 14 as liAtt_id, ''Changes'' as Relationtype_Atrribute from dual',
'    union',
'    select 15 as liAtt_id, ''Demands'' as Relationtype_Atrribute from dual',
'    union',
'    select 16 as liAtt_id, ''Equivalent'' as Relationtype_Atrribute from dual',
'    union',
'    select 20 as liAtt_id, ''Consolidates'' as Relationtype_Atrribute from dual',
')',
'select liAtt_id, ',
'       APEX_ITEM.CHECKBOX2(4, cte.liAtt_id, null, :P44_SELECTED_RELATIONTYPE, '':'') as checkbox, ',
'       Relationtype_Atrribute',
'from cte'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte as ( ',
'    select 15 as newBit_id, ''Successor/Predecessor'' as New_Bits_Attribute from dual',
'    union',
'    select 16 as newBit_id, ''Amendment/Supplement'' as New_Bits_Attribute from dual',
'    union',
'    select 17 as newBit_id, ''Demands'' as New_Bits_Attribute from dual',
'    union',
'    select 18 as newBit_id, ''Linked To'' as New_Bits_Attribute from dual',
'    union',
'    select 19 as newBit_id, ''Equivalent'' as New_Bits_Attribute from dual',
'    union',
'    select 20 as newBit_id, ''Consolidates'' as New_Bits_Attribute from dual',
')',
'select ',
'    newBit_id, ',
'    APEX_ITEM.CHECKBOX2(4, cte.newBit_id, null, :P44_SELECTED_NEW_BITS, '':'') as checkbox,',
'    New_Bits_Attribute',
'from cte'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1057075385971661232)
,p_query_column_id=>1
,p_column_alias=>'LIATT_ID'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1060110650016159387)
,p_query_column_id=>2
,p_column_alias=>'CHECKBOX'
,p_column_display_sequence=>10
,p_column_heading=>'<input type="checkbox" />'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1057074937929661228)
,p_query_column_id=>3
,p_column_alias=>'RELATIONTYPE_ATRRIBUTE'
,p_column_display_sequence=>30
,p_column_heading=>'Relationtype Atrribute'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(4513711273304111405)
,p_name=>'Attribute zur Aktualisierung'
,p_region_name=>'IR_AT'
,p_parent_plug_id=>wwv_flow_imp.id(4513710093588111393)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_new_grid_column=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte as ( select 1 as attr_id, ''Vorschriftennummer'' as kerndaten from dual',
'                union',
'                select 2 as attr_id,  ''Dokumentendatum'' as kerndaten from dual',
'                union',
'                select 3 as attr_id,  ''Dokumententyp'' as kerndaten from dual',
'                union',
'                select 4 as attr_id,  ''Titel Kurz'' as kerndaten from dual',
'                union',
'                select 5 as attr_id,  ''Titel Lang'' as kerndaten from dual',
'                union',
'                select 6 as attr_id, ''Status der Vorschrift'' as kerndaten from dual',
'                union',
'                select 7 as attr_id,  ''Einsatzdatum Modell'' as kerndaten from dual',
'                union',
'                select 8 as attr_id,  ''Vorschriftentyp'' as kerndaten from dual',
')',
'select  attr_id, APEX_ITEM.CHECKBOX2(1,cte.attr_id, null, :P44_SELECTED_EINSATZDATEN,'':'') as checkbox, kerndaten',
'from cte ',
'',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1092686762175109093)
,p_query_column_id=>1
,p_column_alias=>'ATTR_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1092686385948109092)
,p_query_column_id=>2
,p_column_alias=>'CHECKBOX'
,p_column_display_sequence=>20
,p_column_heading=>'<input type="checkbox" />'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1092685935269109092)
,p_query_column_id=>3
,p_column_alias=>'KERNDATEN'
,p_column_display_sequence=>30
,p_column_heading=>'Kerndaten'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(4513712892770111421)
,p_name=>'Einsatzdaten Attribute '
,p_region_name=>'r_edat'
,p_parent_plug_id=>wwv_flow_imp.id(4513710093588111393)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_grid_column_span=>2
,p_display_column=>3
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte as ( select 9 as edat_id, ''Inkraftsetzungsdatum'' as Einsatzdaten from dual',
'                union',
'                select 10 as edat_id,  ''Einsatzdatum Daten'' as Einsatzdaten from dual',
'               -- union',
unistr('              --  select 11 as edat_id,  ''Au\00DFerkraftsetzungsdatum '' as Einsatzdaten from dual'),
')',
'select  edat_id, APEX_ITEM.CHECKBOX2(2, cte.edat_id, null, :P44_SELECTED_EINSATZDATEN, '':'') as checkbox, Einsatzdaten',
'from cte ',
'',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1092685251889109090)
,p_query_column_id=>1
,p_column_alias=>'EDAT_ID'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1092684908350109090)
,p_query_column_id=>2
,p_column_alias=>'CHECKBOX'
,p_column_display_sequence=>20
,p_column_heading=>'<input type="checkbox" />'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1092684435286109090)
,p_query_column_id=>3
,p_column_alias=>'EINSATZDATEN'
,p_column_display_sequence=>40
,p_column_heading=>'Einsatzdaten'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(4514843460856970479)
,p_name=>'Listen Attribute '
,p_region_name=>'r_lis'
,p_parent_plug_id=>wwv_flow_imp.id(4513710093588111393)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_grid_column_span=>2
,p_display_column=>5
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte as ( ',
unistr('                select 17 as liAtt_id,  ''L\00E4nder'' as Listen_Attribute from dual'),
'                union',
'                select 18 as liAtt_id,  ''Themen'' as Listen_Attribute from dual',
'                union',
'                select 19 as liAtt_id,  ''Fahrzeugarten'' as Listen_Attribute from dual',
'               ',
')',
'select  liAtt_id, APEX_ITEM.CHECKBOX2(3, cte.liAtt_id, null, :P44_SELECTED_LISTEN, '':'') as checkbox, Listen_Attribute',
'from cte ',
'',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte as ( select 12 as liAtt_id, ''Sucessor / Predecessor'' as Listen_Attribute from dual',
'                union',
'                select 13 as liAtt_id,  ''Linked'' as Listen_Attribute from dual',
'                union',
'                select 14 as liAtt_id,  ''Changes'' as Listen_Attribute from dual',
'                union',
'                select 15 as liAtt_id,  ''Demands'' as Listen_Attribute from dual',
'                union',
'                select 16 as liAtt_id,  ''Equivalent'' as Listen_Attribute from dual',
'                union',
unistr('                select 17 as liAtt_id,  ''L\00E4nder'' as Listen_Attribute from dual'),
'                union',
'                select 18 as liAtt_id,  ''Themen'' as Listen_Attribute from dual',
'                union',
'                select 19 as liAtt_id,  ''Fahrzeugklassen'' as Listen_Attribute from dual',
'                union',
'                select 20 as liAtt_id,  ''Consolidates'' as Listen_Attribute from dual',
')',
'select  liAtt_id, APEX_ITEM.CHECKBOX2(3, cte.liAtt_id, null, :P44_SELECTED_LISTEN, '':'') as checkbox, Listen_Attribute',
'from cte ',
'',
''))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1092683742783109089)
,p_query_column_id=>1
,p_column_alias=>'LIATT_ID'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1092683407114109089)
,p_query_column_id=>2
,p_column_alias=>'CHECKBOX'
,p_column_display_sequence=>10
,p_column_heading=>'<input type="checkbox" />'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1092682956917109089)
,p_query_column_id=>3
,p_column_alias=>'LISTEN_ATTRIBUTE'
,p_column_display_sequence=>30
,p_column_heading=>'Listen Attribute'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5838341632904595943)
,p_plug_name=>unistr('Ausgew\00E4hlte Vorschriften')
,p_parent_plug_id=>wwv_flow_imp.id(4505130722735853826)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(5838341753729595944)
,p_name=>unistr('Ausgew\00E4hlte Vorschriften')
,p_parent_plug_id=>wwv_flow_imp.id(5838341632904595943)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select VORSCHRIFTID,',
'        null as link_abgleich, ',
'       VORSCHRIFT_NUMMER,',
'       VORSCHRIFT_BEZEICHNUNG,',
unistr('       case when MASTER= 20 then ''GETEX'' when MASTER= 30 then ''GETEX mit autom. \00DCbernahme'' when MASTER= 10 then ''Regindex'' else ''-'' end as Master,'),
'       case when status_update_Getex =20 then ''nicht aktuell'' when  status_update_Getex =20 then ''aktuell'' else  ''-'' end as status_update_Getex,',
'      -- PROGNOSE_QUALITAET,',
'       --JIRA_TICKET,',
'       --VORSCHRIFT_FREIGABESTATUSID,',
'       --BEMERKUNG,',
'       --LINK_ZUR_VORSCHRIFT_DMS,',
'       --LINK_ZUR_VORSCHRIFT_GETEX,',
'       --TYPSCHILD,',
'       --LETZTE_AENDERUNG_DATUM,',
'       --LETZTE_AENDERUNG_BENUTZERID,',
'       --WEBSITEID,',
'       --WEBSITELINK,',
'       --EINSATZDATUM_MODELLID,',
'       VORSCHRIFT_TYPID,',
'       --NORMID,',
'       --HOMOLOGATION_MOEGLICH,',
'       --KSUID,',
'       VORSCHRIFT_STATUSID--,',
'       --HOMOLOGATIONSRELEVANT,',
'       --RXSWIN',
'  from T_VORSCHRIFT',
'  ',
' where vorschriftid in (',
'    select column_value ',
'    from table(apex_string.split_numbers(:P44_SELECTED_VORSCHRIFTEN, '':''))',
')',
'    '))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'\P44_SELECTED_VORSCHRIFTEN\'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>unistr('Es wurden keine bearbeitbaren Vorschriften ausgew\00E4hlt.')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1092682001840109088)
,p_query_column_id=>1
,p_column_alias=>'VORSCHRIFTID'
,p_column_display_sequence=>80
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1092681594553109088)
,p_query_column_id=>2
,p_column_alias=>'LINK_ABGLEICH'
,p_column_display_sequence=>10
,p_column_heading=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:29:P29_VORSCHRIFTID:#VORSCHRIFTID#'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-code-fork fa-rotate-180"></span>'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1092681124838109088)
,p_query_column_id=>3
,p_column_alias=>'VORSCHRIFT_NUMMER'
,p_column_display_sequence=>20
,p_column_heading=>'Vorschriften&shy;nummer'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1092680814433109087)
,p_query_column_id=>4
,p_column_alias=>'VORSCHRIFT_BEZEICHNUNG'
,p_column_display_sequence=>30
,p_column_heading=>'Titel'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1092680380856109087)
,p_query_column_id=>5
,p_column_alias=>'MASTER'
,p_column_display_sequence=>60
,p_column_heading=>'Master'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1092680010696109087)
,p_query_column_id=>6
,p_column_alias=>'STATUS_UPDATE_GETEX'
,p_column_display_sequence=>70
,p_column_heading=>'Status Update Getex'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1092679578350109086)
,p_query_column_id=>7
,p_column_alias=>'VORSCHRIFT_TYPID'
,p_column_display_sequence=>40
,p_column_heading=>'Vorschrift Typ'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(2656545044559578040)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1092679189420109086)
,p_query_column_id=>8
,p_column_alias=>'VORSCHRIFT_STATUSID'
,p_column_display_sequence=>50
,p_column_heading=>'Status der Vorschrift'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(2490458092659806028)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1092691127371109103)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4505130722735853826)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Zur\00FCck zur Vorschriftenliste')
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1092690784116109102)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(4505130722735853826)
,p_button_name=>'APPLY'
,p_button_static_id=>'b_App'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':P44_ANY_MASTER_NOT_GETEX = 0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1092676662482109085)
,p_branch_name=>'redirect to Vorschriften'
,p_branch_action=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1092690784116109102)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1092690377763109101)
,p_name=>'P44_LOAD_FROM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4505130722735853826)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1092689963709109099)
,p_name=>'P44_SELECTED_VORSCHRIFTEN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(4505130722735853826)
,p_use_cache_before_default=>'NO'
,p_source=>':&P44_LOAD_FROM.'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1092689604233109099)
,p_name=>'P44_SELECTED_KERNDATEN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4505130722735853826)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1092689117746109098)
,p_name=>'P44_SELECTED_EINSATZDATEN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(4505130722735853826)
,p_use_cache_before_default=>'NO'
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1092688728593109098)
,p_name=>'P44_SELECTED_LISTEN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(4505130722735853826)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1092688345164109098)
,p_name=>'P44_ANY_MASTER_NOT_GETEX'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(4505130722735853826)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1064036060062015292)
,p_name=>'P44_SELECTED_NEW_BITS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(4505130722735853826)
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1057075041834661229)
,p_name=>'P44_SELECTED_RELATIONTYPE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(4505130722735853826)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1092677931804109085)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Kerndaten  Attribute Ids auslesen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'debug(''Prozess Checkboxen auslesen'',APEX_APPLICATION.G_F01.COUNT);',
'',
':P44_SELECTED_KERNDATEN := null;',
'',
'FOR i IN 1..APEX_APPLICATION.G_F01.COUNT LOOP ',
'    debug(''element ''||I||'' has a value of ''||APEX_APPLICATION.G_F01(i)); ',
'    :P44_SELECTED_KERNDATEN := :P44_SELECTED_KERNDATEN || APEX_APPLICATION.G_F01(i) || '':'';',
'END LOOP;',
'debug(''P44_SELECTED_KERNDATEN =''|| :P44_SELECTED_KERNDATEN);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1092690784116109102)
,p_internal_uid=>2579534384095279150
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1092677531420109085)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Einsatzdaten Attribute Ids auslesen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'debug(''Prozess Checkboxen auslesen'',APEX_APPLICATION.G_F02.COUNT);',
'',
':P44_SELECTED_EINSATZDATEN := null;',
'',
'FOR i IN 1..APEX_APPLICATION.G_F02.COUNT LOOP ',
'    debug(''element ''||I||'' has a value of ''||APEX_APPLICATION.G_F02(i)); ',
'    :P44_SELECTED_EINSATZDATEN := :P44_SELECTED_EINSATZDATEN || APEX_APPLICATION.G_F02(i) || '':'';',
'END LOOP;',
'debug(''P44_SELECTED_EINSATZDATEN =''|| :P44_SELECTED_EINSATZDATEN);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1092690784116109102)
,p_internal_uid=>2579534784479279150
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1057075123890661230)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Listen Attribute Ids auslesen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'debug(''Prozess Checkboxen auslesen'',APEX_APPLICATION.G_F03.COUNT);',
'',
':P44_SELECTED_LISTEN := null;',
'',
'FOR i IN 1..APEX_APPLICATION.G_F03.COUNT LOOP ',
'   -- debug(''element ''||I||'' has a value of ''||APEX_APPLICATION.G_F03(i)); ',
'    :P44_SELECTED_LISTEN := :P44_SELECTED_LISTEN || APEX_APPLICATION.G_F03(i) || '':'';',
'END LOOP;',
'debug(''P44_SELECTED_LISTEN =''|| :P44_SELECTED_LISTEN);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1092690784116109102)
,p_internal_uid=>2615137192008727005
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1092677172071109085)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Relationtype Attribute Ids auslesen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'debug(''Prozess Checkboxen auslesen'',APEX_APPLICATION.G_F04.COUNT);',
'',
':P44_SELECTED_RELATIONTYPE := null;',
'',
'FOR i IN 1..APEX_APPLICATION.G_F04.COUNT LOOP ',
'    debug(''element ''||I||'' has a value of ''||APEX_APPLICATION.G_F04(i)); ',
'    :P44_SELECTED_RELATIONTYPE := :P44_SELECTED_RELATIONTYPE || APEX_APPLICATION.G_F04(i) || '':'';',
'END LOOP;',
'debug(''P44_SELECTED_RELATIONTYPE =''|| :P44_SELECTED_RELATIONTYPE);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1092690784116109102)
,p_internal_uid=>2579535143828279150
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1092678324497109086)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'aktualisiere Attribute'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_msg VARCHAR2(2000);',
'BEGIN',
'    -- Log the start of updating Kerndaten',
'    -- DEBUG(''Starting pMassenAktualisierung_Kerndaten_VomGetex'', ',
'    --       ''P44_SELECTED_KERNDATEN: '' || :P44_SELECTED_KERNDATEN || ',
'    --       '', P44_SELECTED_VORSCHRIFTEN: '' || :P44_SELECTED_VORSCHRIFTEN);',
'    PCK_RI_GETEX_APPLY.pMassenUpdateGetexKernDaten(:P44_SELECTED_KERNDATEN, :P44_SELECTED_VORSCHRIFTEN);',
' ',
'',
'    -- Log before updating Einsatzdaten',
'    -- DEBUG(''Starting pMassenAktualisierung_Einsatzdaten_VomGetex'', ',
'    --       ''P44_SELECTED_EINSATZDATEN: '' || :P44_SELECTED_EINSATZDATEN || ',
'    --       '', P44_SELECTED_VORSCHRIFTEN: '' || :P44_SELECTED_VORSCHRIFTEN);',
'   ',
'    PCK_RI_GETEX_APPLY.pMassenUpdateGetexEinsatzdaten(:P44_SELECTED_EINSATZDATEN, :P44_SELECTED_VORSCHRIFTEN);',
'',
'    -- Log before updating ListenAttributen',
'    -- DEBUG(''Starting pMassenAktualisierung_ListenAttributen_VomGetex'', ',
'    --       ''Listen/RelationType: '' || (:P44_SELECTED_LISTEN || :P44_SELECTED_RELATIONTYPE) || ',
'    --       '', P44_SELECTED_VORSCHRIFTEN: '' || :P44_SELECTED_VORSCHRIFTEN);',
'',
'    PCK_RI_GETEX_APPLY.pMassenUpdateGetexListAttrs(:P44_SELECTED_LISTEN || :P44_SELECTED_RELATIONTYPE, :P44_SELECTED_VORSCHRIFTEN);',
'',
'    -- Process each Vorschrift value',
'    FOR cur IN (SELECT column_value FROM TABLE(apex_string.split_numbers(:P44_SELECTED_VORSCHRIFTEN, '':'')))',
'    LOOP',
'        -- DEBUG(''Calling pCompareVorschrift'', ''Value: '' || cur.column_value);',
'        PCK_RI_GETEX_COMPARE.pCompareVorschrift(cur.column_value);',
'    END LOOP;',
'',
'    -- Check conditions and prepare cockpit data if needed',
'    IF ((length(:P44_SELECTED_LISTEN) > 1 and instr(:P44_SELECTED_LISTEN, ''17'') > 0)',
'        OR (length(:P44_SELECTED_RELATIONTYPE) > 1 and (instr(:P44_SELECTED_RELATIONTYPE, ''15'') > 0 or instr(:P44_SELECTED_RELATIONTYPE, ''16'') > 0)))',
'    THEN',
'        -- DEBUG(''Calling pAufbereitungDaten'', ''Preparing cockpit data.'');',
'        PCK_RI_COCKPIT2.pAufbereitungDaten;',
'    END IF;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        DEBUG(''Error encountered'', SQLERRM);',
'        RAISE;',
'END;',
'',
'',
' '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1092690784116109102)
,p_internal_uid=>2579533991402279149
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Original',
'',
'pck_ri_getex.pMassenAktualisierung_Kerndaten_VomGetex(:P44_SELECTED_KERNDATEN, :P44_SELECTED_VORSCHRIFTEN);',
'pck_ri_getex.pMassenAktualisierung_Einsatzdaten_VomGetex(:P44_SELECTED_EINSATZDATEN, :P44_SELECTED_VORSCHRIFTEN);',
'pck_ri_getex.pMassenAktualisierung_ListenAttributen_VomGetex(:P44_SELECTED_LISTEN, :P44_SELECTED_VORSCHRIFTEN);',
'',
' for cur in (select column_value from table (apex_string.split_numbers(:P44_SELECTED_VORSCHRIFTEN, '':'')))',
' loop',
'    pck_ri_getex.pCompareVorschrift(cur.column_value);',
' end loop;',
unistr(' -- aufbereiten Cockpit wenn l\00E4nder Abgleich    oder Demand, Equivalant - Verkn\00FCpfungen Abgleich'),
' if (length(:P44_SELECTED_LISTEN) >1 ',
'     and (instr(:P44_SELECTED_LISTEN, ''17'')>0 or instr(:P44_SELECTED_LISTEN, ''15'')>0 or instr(:P44_SELECTED_LISTEN, ''16'')>0) ',
' )then',
'    PCK_RI_COCKPIT2.pAufbereitungDaten;',
' end if;',
'',
'',
'',
'',
'-- 20.02.2025',
'',
'',
'',
'pck_ri_getex.pMassenAktualisierung_Kerndaten_VomGetex(:P44_SELECTED_KERNDATEN, :P44_SELECTED_VORSCHRIFTEN);',
'pck_ri_getex.pMassenAktualisierung_Einsatzdaten_VomGetex(:P44_SELECTED_EINSATZDATEN, :P44_SELECTED_VORSCHRIFTEN);',
'pck_ri_getex.pMassenAktualisierung_ListenAttributen_VomGetex(:P44_SELECTED_LISTEN || :P44_SELECTED_RELATIONTYPE, :P44_SELECTED_VORSCHRIFTEN);',
'',
'for cur in (select column_value from table (apex_string.split_numbers(:P44_SELECTED_VORSCHRIFTEN, '':'')))',
'loop',
'    pck_ri_getex.pCompareVorschrift(cur.column_value);',
'end loop;',
'',
unistr('-- aufbereiten Cockpit wenn L\00E4nder Abgleich oder Demand, Equivalent - Verkn\00FCpfungen Abgleich'),
'if (',
'    (length(:P44_SELECTED_LISTEN) > 1 and instr(:P44_SELECTED_LISTEN, ''17'') > 0)',
'    OR',
'    (length(:P44_SELECTED_RELATIONTYPE) > 1 and (instr(:P44_SELECTED_RELATIONTYPE, ''15'') > 0 or instr(:P44_SELECTED_RELATIONTYPE, ''16'') > 0))',
') then',
'    PCK_RI_COCKPIT2.pAufbereitungDaten;',
'end if;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1064035433661015286)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Selected New Bits'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P44_SELECTED_NEW_BITS := null;',
'',
'FOR i IN 1..APEX_APPLICATION.G_F04.COUNT LOOP ',
'    :P44_SELECTED_NEW_BITS := :P44_SELECTED_NEW_BITS || APEX_APPLICATION.G_F04(i) || '':'';',
'END LOOP;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1092690784116109102)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2608176882238372949
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1064035375656015285)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Selected New Bits Process to Call Mass Update Procedure'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- PCK_RI_GETEX.pMassenAktualisierung_NewBits_VomGetex(:P44_SELECTED_NEW_BITS, :P44_SELECTED_VORSCHRIFTEN);',
'',
' for cur in (select column_value from table (apex_string.split_numbers(:P44_SELECTED_VORSCHRIFTEN, '':'')))',
' loop',
'    pck_ri_getex.pCompareVorschrift(cur.column_value);',
' end loop;',
unistr(' -- aufbereiten Cockpit wenn l\00E4nder Abgleich    oder Demand, Equivalant - Verkn\00FCpfungen Abgleich'),
' if (length(:P44_SELECTED_NEW_BITS) >1 ',
'     and (instr(:P44_SELECTED_NEW_BITS, ''17'')>0 or instr(:P44_SELECTED_NEW_BITS, ''19'')>0  )',
'    --  or instr(:P44_SELECTED_NEW_BITS, ''16'')>0 ',
' )then',
'    PCK_RI_COCKPIT2.pAufbereitungDaten;',
' end if;',
'',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1092690784116109102)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2608176940243372950
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1092678727421109086)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P44_SELECTED_VORSCHRIFTEN := :P26_SELECTED_ROWS;',
'',
'select  count(*) into :P44_ANY_MASTER_NOT_GETEX',
'         from table (apex_string.split_numbers( :P44_SELECTED_VORSCHRIFTEN , '':'')  ) x      ',
'         join t_vorschrift v  on ( x.column_value is not null and  x.column_value = v.vorschriftid)',
'         where nvl(v.master, 0) not in (20, 30);'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2579533588478279149
);
wwv_flow_imp.component_end;
end;
/
