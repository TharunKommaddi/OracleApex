prompt --application/pages/page_00422
begin
--   Manifest
--     PAGE: 00422
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>422
,p_name=>'Vorschriften Bearbeitung'
,p_alias=>'VORSCHRIFTEN-BEARBEITUNG'
,p_page_mode=>'MODAL'
,p_step_title=>'Vorschriften Bearbeitung'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2355672916411274196)
,p_plug_name=>unistr('Regulierungsverantwortlichen hinzuf\00FCgen / bearbeiten')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2355675245055274219)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1094425875309611787)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(2355675245055274219)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1094425427379611786)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(2355675245055274219)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P422_VORSCHRIFT_REF_VERANTWORTLICHERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1094425062689611786)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2355675245055274219)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P422_VORSCHRIFT_REF_VERANTWORTLICHERID'
,p_button_condition_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1094424616192611786)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(2355675245055274219)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P422_VORSCHRIFT_REF_VERANTWORTLICHERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1094420322043611783)
,p_branch_name=>'Go To Page 421'
,p_branch_action=>'f?p=&APP_ID.:421:&SESSION.::&DEBUG.:421:P421_VERANTWORTLICHERID:&P422_VERANTWORTLICHERID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1094428517041611788)
,p_name=>'P422_VERANTWORTLICHERID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2355672916411274196)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1094428195523611788)
,p_name=>'P422_VORSCHRIFT_REF_VERANTWORTLICHERID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2355672916411274196)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1094427723301611788)
,p_name=>'P422_REGULIERUNGSVERANTWORTLICHER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2355672916411274196)
,p_prompt=>'Regulierungsverantwortlicher'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'--v.vorschriftid vorschriftid,',
'listagg(vv.nachname || '', '' || vv.vorname, '';'') within group (order by vv.nachname) as verantwortlicher  ',
'    from t_verantwortlicher vv  where vv.verantwortlicherid = :P422_VERANTWORTLICHERID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'--v.vorschriftid vorschriftid,',
'listagg(vv.nachname || '', '' || vv.vorname, '';'') within group (order by vv.nachname) as verantwortlicher  ',
'    from t_vorschrift v',
'    join t_vorschrift_ref_verantwortlicher vrv on (vrv.vorschriftid = v.vorschriftid)',
'    join t_verantwortlicher vv on (vv.verantwortlicherid = vrv.verantwortlicherid)',
'    group by v.vorschriftid'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1094427338188611788)
,p_name=>'P422_VORSCHRIFTID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2355672916411274196)
,p_prompt=>'Vorschriften'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_read_only_when=>'P422_VORSCHRIFT_REF_VERANTWORTLICHERID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'FIRST_ROWSET',
  'send_on_page_submit', 'N',
  'submit_when_enter_pressed', 'POPUP',
  'subtype', 'N',
  'trim_spaces', 'N')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vorschriftid',
'from t_vorschrift_ref_verantwortlicher',
'where verantwortlicherid = :P421_VERANTWORTLICHERID'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1094426934277611787)
,p_name=>'P422_SWR_HAUPTUMSETZENDE_OE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2355672916411274196)
,p_prompt=>'Hauptumsetzende OE2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1094426547235611787)
,p_name=>'P422_IST_HAUPTVERANTWORTLICHER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(2355672916411274196)
,p_item_default=>'10'
,p_prompt=>'Ist Hauptverantwortlicher'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Nebenverantwortlicher',
  'off_value', '20',
  'on_label', 'Hauptverantwortlicher',
  'on_value', '10',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1094422277446611784)
,p_name=>'Populate SWR_HAUPTUMSETZENDE_OE'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P422_VORSCHRIFTID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1094421767865611784)
,p_event_id=>wwv_flow_imp.id(1094422277446611784)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P422_SWR_HAUPTUMSETZENDE_OE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT SWR_HAUPTUMSETZENDE_OE',
'FROM T_VORSCHRIFT',
'WHERE VORSCHRIFTID = :P422_VORSCHRIFTID;',
''))
,p_attribute_07=>'P422_VORSCHRIFTID'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1094421406714611784)
,p_name=>'Cancel Dialog'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1094425875309611787)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1094420842614611784)
,p_event_id=>wwv_flow_imp.id(1094421406714611784)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1094424228044611786)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process - Insert - Update'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'',
'    IF :P422_VORSCHRIFT_REF_VERANTWORTLICHERID IS NULL THEN',
'        -- Insert a new row',
'        INSERT INTO T_VORSCHRIFT_REF_VERANTWORTLICHER (',
'            ',
'            VORSCHRIFTID, ',
'            VERANTWORTLICHERID,',
'            IST_HAUPTVERANTWORTLICHER',
'        ) VALUES (',
'            ',
'            :P422_VORSCHRIFTID, ',
'            :P422_VERANTWORTLICHERID,',
'            :P422_IST_HAUPTVERANTWORTLICHER',
'        );',
'',
'    ELSE',
'        -- Update an existing row',
'        UPDATE T_VORSCHRIFT_REF_VERANTWORTLICHER',
'        SET ',
'            VORSCHRIFTID = :P422_VORSCHRIFTID, ',
'            VERANTWORTLICHERID = :P422_VERANTWORTLICHERID,',
'            IST_HAUPTVERANTWORTLICHER = :P422_IST_HAUPTVERANTWORTLICHER',
'        WHERE ',
'            VORSCHRIFT_REF_VERANTWORTLICHERID = :P422_VORSCHRIFT_REF_VERANTWORTLICHERID;',
'',
'    END IF;',
'',
'    -- Update related SWR_HAUPTUMSETZENDE_OE field in the T_VORSCHRIFT table',
'    UPDATE T_VORSCHRIFT',
'    SET ',
'        SWR_HAUPTUMSETZENDE_OE = :P422_SWR_HAUPTUMSETZENDE_OE',
'    WHERE ',
'        VORSCHRIFTID = :P422_VORSCHRIFTID;',
'        ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        RAISE;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Diese Vorschrift wurde dem Regulierungsverantwortlichen bereits zugeordnet.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2577788087854776449
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1094423476371611785)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process - Delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Delete  an existing row',
'    DELETE FROM T_VORSCHRIFT_REF_VERANTWORTLICHER',
'    WHERE ',
'        VORSCHRIFT_REF_VERANTWORTLICHERID = :P422_VORSCHRIFT_REF_VERANTWORTLICHERID;',
'       ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        RAISE;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1094425427379611786)
,p_internal_uid=>2577788839527776450
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1094422704498611784)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1094425427379611786)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2577789611400776451
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1094423051512611785)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2577789264386776450
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1094423892949611786)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Initialize'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  IF :P422_VORSCHRIFT_REF_VERANTWORTLICHERID IS NOT NULL THEN',
'    SELECT --vrv.VORSCHRIFT_REF_VERANTWORTLICHERID ,',
'          -- vv.nachname || '', '' || vv.vorname AS REGULIERUNGSVERANTWORTLICHER,',
'           vrv.VERANTWORTLICHERID,',
'           vo.vorschriftid, ',
'           vo.swr_hauptumsetzende_oe,',
'           vrv.ist_Hauptverantwortlicher',
'    INTO ',
'    --:P422_REGULIERUNGSVERANTWORTLICHER,',
'    :P422_VERANTWORTLICHERID,',
'    :P422_VORSCHRIFTID, ',
'    :P422_SWR_HAUPTUMSETZENDE_OE,',
'    :P422_IST_HAUPTVERANTWORTLICHER',
'    FROM t_vorschrift vo ',
'    JOIN t_vorschrift_ref_verantwortlicher vrv ON vrv.vorschriftid = vo.vorschriftid',
'  --  JOIN t_verantwortlicher vv ON vv.verantwortlicherid = vrv.verantwortlicherid',
'    WHERE vrv.VORSCHRIFT_REF_VERANTWORTLICHERID = :P422_VORSCHRIFT_REF_VERANTWORTLICHERID;',
'  END IF;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2577788422949776449
);
wwv_flow_imp.component_end;
end;
/
