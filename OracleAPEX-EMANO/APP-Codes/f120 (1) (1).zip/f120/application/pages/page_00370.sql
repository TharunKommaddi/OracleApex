prompt --application/pages/page_00370
begin
--   Manifest
--     PAGE: 00370
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>370
,p_name=>unistr('\00DCbersicht Antriebsart Vorschrift')
,p_alias=>unistr('\00DCBERSICHT-ANTRIEBSART-VORSCHRIFT')
,p_step_title=>unistr('\00DCbersicht Antriebsart Vorschrift')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(2660026449262803947)
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(925687090130665512)
,p_plug_name=>'Report Antriebsart'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ANTRIEBSARTID,',
'        CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN a.BEZEICHNUNG ',
'        ELSE a.name_eng ',
'       END AS BEZEICHNUNG,',
'       a.LETZTE_AENDERUNG_DATUM,',
'       nvl2(a.letzte_aenderung_benutzerid, b.nachname || '', '' || b.vorname, null) as LETZTE_AENDERUNG_BENUTZER',
'  from T_ANTRIEBSART a',
'left outer join t_benutzer b on b.benutzerid = a.letzte_aenderung_benutzerid',
' ORDER BY a.BEZEICHNUNG, a.name_eng'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Report Antriebsart'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(925686704780665512)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:375:&SESSION.::&DEBUG.:RP,:P375_ANTRIEBSARTID:\#ANTRIEBSARTID#\'
,p_detail_link_text=>'<span aria-label="Bearbeiten"><span class="fa fa-pencil" aria-hidden="true" title="Bearbeiten"></span></span>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>187006232314468892
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(925686554520665507)
,p_db_column_name=>'ANTRIEBSARTID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Antriebsartid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(925686232878665490)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Antriebsart Vorschrift'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(925685776915665490)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY HH24:mi'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(931186847238163901)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>13
,p_column_identifier=>'E'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(925681391615634192)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1870116'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BEZEICHNUNG:LETZTE_AENDERUNG_DATUM:LETZTE_AENDERUNG_BENUTZER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(925684861287665489)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(925687090130665512)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:375:&SESSION.::&DEBUG.:375'
);
wwv_flow_imp.component_end;
end;
/
