prompt --application/pages/page_00265
begin
--   Manifest
--     PAGE: 00265
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>265
,p_name=>'Publisher Zuordnung'
,p_alias=>'GETEX-PUBLISHER-FORM'
,p_page_mode=>'MODAL'
,p_step_title=>'Publisher Zuordnung'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2062602948731538602)
,p_plug_name=>'Getex-Publisher Form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PUBLISHERID, Name, Einsatzdatum_modellid, ANZEIGE_MIT_DOKUMENTENDATUM',
'from T_PUBLISHER',
'--join T_Einsatzmodel'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_add_authorization_scheme=>wwv_flow_imp.id(2702777556132462106)
,p_update_authorization_scheme=>wwv_flow_imp.id(2702777556132462106)
,p_delete_authorization_scheme=>wwv_flow_imp.id(2702777556132462106)
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2062605417284538624)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1062614114595179911)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2062605417284538624)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1062613656352179909)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2062605417284538624)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P265_PUBLISHERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1062613287053179909)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2062605417284538624)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P265_PUBLISHERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1062612884212179909)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2062605417284538624)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P265_PUBLISHERID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1062617238493179917)
,p_name=>'P265_PUBLISHERID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2062602948731538602)
,p_item_source_plug_id=>wwv_flow_imp.id(2062602948731538602)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Publisherid'
,p_source=>'PUBLISHERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1062616875154179915)
,p_name=>'P265_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2062602948731538602)
,p_item_source_plug_id=>wwv_flow_imp.id(2062602948731538602)
,p_prompt=>'Publisher Name'
,p_source=>'NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct PUBL_NAME',
' from MV_GETEX_VORSCHRIFT ',
'--  where timelinedatetype is  null ',
' order by PUBL_NAME'))
,p_lov_display_null=>'YES'
,p_cSize=>60
,p_cMaxlength=>500
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1062616453296179915)
,p_name=>'P265_EINSATZDATUM_MODELLID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2062602948731538602)
,p_item_source_plug_id=>wwv_flow_imp.id(2062602948731538602)
,p_prompt=>'Einsatzdatum Modell'
,p_source=>'EINSATZDATUM_MODELLID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_EINSATZDATUM_MODELL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT EINSATZDATUM_MODELLID, CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN MODELL ELSE MODELL_ENG END FROM T_EINSATZDATUM_MODELL;',
''))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>500
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(981292605873851929)
,p_name=>'P265_ANZEIGE_MIT_DOKUMENTENDATUM'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2062602948731538602)
,p_item_source_plug_id=>wwv_flow_imp.id(2062602948731538602)
,p_item_default=>'10'
,p_prompt=>'Anzeige Mit Dokumentendatum'
,p_source=>'ANZEIGE_MIT_DOKUMENTENDATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ''Nein (kein Dokumentendatum)'' as display_value, 10 as return_value FROM dual',
'UNION ALL',
'SELECT ''Ja (mit Dokumentendatum)'' as display_value, 20 as return_value FROM dual',
'ORDER BY return_value'))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1062612111612179908)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1062614114595179911)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1062611542059179907)
,p_event_id=>wwv_flow_imp.id(1062612111612179908)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1062614730700179911)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(2062602948731538602)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Getex-Publisher Form'
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'merge into t_publisher t',
'using (',
'    select :P265_NAME as name, ',
'           :P265_EINSATZDATUM_MODELLID as einsatzdatum_modellid,',
'           :P265_ANZEIGE_MIT_DOKUMENTENDATUM as anzeige_mit_dokumentendatum',
'    from dual',
') u',
'on (t.name = u.name)',
'when matched then update set ',
'    t.einsatzdatum_modellid = u.einsatzdatum_modellid,',
'    t.ANZEIGE_MIT_DOKUMENTENDATUM = u.anzeige_mit_dokumentendatum',
'when not matched then insert (name, einsatzdatum_modellid, ANZEIGE_MIT_DOKUMENTENDATUM) ',
'    values (u.name, u.einsatzdatum_modellid, u.anzeige_mit_dokumentendatum);'))
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2609597585199208324
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1057094595275192912)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('L\00F6sche Zuordnung')
,p_process_sql_clob=>'delete from T_PUBLISHER where PUBLISHERID = :P265_PUBLISHERID;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1062613656352179909)
,p_internal_uid=>2615117720624195323
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1062612459351179908)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2609599856548208327
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1062615135606179912)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(2062602948731538602)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Getex-Publisher Form'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2609597180293208323
);
wwv_flow_imp.component_end;
end;
/
