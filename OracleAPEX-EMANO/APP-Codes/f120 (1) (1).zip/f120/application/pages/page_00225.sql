prompt --application/pages/page_00225
begin
--   Manifest
--     PAGE: 00225
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>225
,p_name=>unistr('Verkn\00FCpfte Eigenschaften')
,p_alias=>unistr('VERKN\00DCPFTE-EIGENSCHAFTEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Verkn\00FCpfte Eigenschaften')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2441472802113373368)
,p_plug_name=>'Container'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(2441473116481373371)
,p_name=>'Arbeitskreise'
,p_parent_plug_id=>wwv_flow_imp.id(2441472802113373368)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ak.et_b_akid, ak.kurz, ak.bezeichnung, listagg(distinct t.nummer,'', '') within group (order by t.nummer) themenliste ',
'from t_vorschrift_ref_et_b_ak ref',
'join t_et_b_ak ak on (ref.et_b_akid = ak.et_b_akid)',
'join t_vorschrift_ref_thema rt on (ref.vorschriftid = rt.vorschriftid and rt.geloescht = 0)',
'join t_thema t on (rt.themaid = t.themaid)',
'join t_thema_ref_et_b_ak reft on (reft.themaid = t.themaid and ref.et_b_akid = reft.et_b_akid)',
'where ref.vorschriftid = :P225_VORSCHRIFTID and ref.geloescht = 0',
'group by ak.et_b_akid, ak.kurz, ak.bezeichnung'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Keine Arbeitskreise zugeordnet.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(545905560943292017)
,p_query_column_id=>1
,p_column_alias=>'ET_B_AKID'
,p_column_display_sequence=>1
,p_column_heading=>' '
,p_column_link=>unistr('javascript:apex.confirm("Zuordnung l\00F6schen?", {   request:"AK_DELETE",   set:{"P225_AK_DELETE":#ET_B_AKID#}});')
,p_column_linktext=>unistr('<span class="fa fa-trash" title="Zuordnung l\00F6schen"></span>')
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(545905220914292014)
,p_query_column_id=>2
,p_column_alias=>'KURZ'
,p_column_display_sequence=>2
,p_column_heading=>'AK'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(545904820739292014)
,p_query_column_id=>3
,p_column_alias=>'BEZEICHNUNG'
,p_column_display_sequence=>3
,p_column_heading=>'Bezeichnung'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(545904390347292014)
,p_query_column_id=>4
,p_column_alias=>'THEMENLISTE'
,p_column_display_sequence=>4
,p_column_heading=>'aus Themen'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(2441474486490373385)
,p_name=>'Antriebsarten'
,p_parent_plug_id=>wwv_flow_imp.id(2441472802113373368)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select aa.antriebsartid, aa.bezeichnung, listagg(distinct t.nummer,'', '') within group (order by t.nummer) themenliste ',
'from t_vorschrift_ref_antriebsart ref',
'join t_antriebsart aa on (ref.antriebsartid = aa.antriebsartid)',
unistr('-- Left join, da die Antriebsarten der Vorschrift und Antriebsarten des Themas unterschiedlich sein k\00F6nnen'),
'left outer join t_vorschrift_ref_thema rt on (ref.vorschriftid = rt.vorschriftid and rt.geloescht = 0)',
'left outer join t_thema t on (rt.themaid = t.themaid)',
'left outer join t_thema_ref_antriebsart refa on (refa.themaid = t.themaid and ref.antriebsartid = refa.antriebsartid)',
'where ref.vorschriftid = :P225_VORSCHRIFTID and ref.geloescht = 0',
'group by aa.antriebsartid, aa.bezeichnung'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Keine Arbeitskreise zugeordnet.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(545903377367292009)
,p_query_column_id=>1
,p_column_alias=>'ANTRIEBSARTID'
,p_column_display_sequence=>1
,p_column_heading=>' '
,p_column_link=>unistr('javascript:apex.confirm("Zuordnung l\00F6schen?", {   request:"AA_DELETE",   set:{"P225_AA_DELETE":#ANTRIEBSARTID#}});')
,p_column_linktext=>unistr('<span class="fa fa-trash" title="Zuordnung l\00F6schen"></span>')
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>'(pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0)'
,p_display_when_condition2=>'PLSQL'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(545902997096292009)
,p_query_column_id=>2
,p_column_alias=>'BEZEICHNUNG'
,p_column_display_sequence=>2
,p_column_heading=>'Bezeichnung'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(545902577695292009)
,p_query_column_id=>3
,p_column_alias=>'THEMENLISTE'
,p_column_display_sequence=>3
,p_column_heading=>'aus Themen'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2441472934072373369)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(545903982385292014)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2441473116481373371)
,p_button_name=>'RESET_AK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Zur\00FCcksetzen auf Zuordnungen der Themengebiete')
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'(pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(545902160089292009)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2441474486490373385)
,p_button_name=>'RESET_AA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Zur\00FCcksetzen auf Zuordnungen der Themengebiete')
,p_button_position=>'COPY'
,p_button_condition=>'(pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(545907071039292039)
,p_name=>'P225_VORSCHRIFTID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2441472802113373368)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(545906705577292033)
,p_name=>'P225_AK_DELETE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2441472802113373368)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(545906279503292032)
,p_name=>'P225_AA_DELETE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2441472802113373368)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(545901456447291974)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reset AK'
,p_process_sql_clob=>'pck_ri.pResetAK(:P225_VORSCHRIFTID);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(545903982385292014)
,p_internal_uid=>3126310859452096261
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(545900725782291971)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reset AA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.pResetAA(:P225_VORSCHRIFTID);',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(545902160089292009)
,p_internal_uid=>3126311590117096264
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(545901043154291972)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete AK'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_vorschrift_ref_et_b_ak',
'set geloescht = 1,',
'letzte_aenderung_datum = sysdate,',
'letzte_aenderung_benutzerid = :G_BENUTZERID',
'where et_b_akid = :P225_AK_DELETE',
'and vorschriftid = :P225_VORSCHRIFTID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'AK_DELETE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>3126311272745096263
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(545900281061291971)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete AA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_vorschrift_ref_antriebsart',
'set geloescht = 1,',
'letzte_aenderung_datum = sysdate,',
'letzte_aenderung_benutzerid = :G_BENUTZERID',
'where antriebsartid = :P225_AA_DELETE',
'and vorschriftid = :P225_VORSCHRIFTID;',
'-- letzte _aender Getex attr',
' update t_vorschrift set letzte_aenderung_Getex_attr = sysdate where vorschriftid = :P225_VORSCHRIFTID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'AA_DELETE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>3126312034838096264
);
wwv_flow_imp.component_end;
end;
/
