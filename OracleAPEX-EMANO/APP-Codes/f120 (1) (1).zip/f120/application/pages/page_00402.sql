prompt --application/pages/page_00402
begin
--   Manifest
--     PAGE: 00402
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>402
,p_name=>'Mockup GANTT (Sicherung)'
,p_alias=>'MOCKUP-GANTT-SICHERUNG'
,p_step_title=>'Mockup GANTT (Sicherung)'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.oj-gantt-task.rot {',
'    fill: red;',
'}',
'/*.oj-gantt-task.gradient {',
'    fill: linear-gradient(153deg, rgba(2,0,36,1) 0%, rgba(87,87,96,1) 35%, rgba(255,255,255,1) 100%);',
'}*/',
'',
'/*.oj-gantt-task.gradient {',
'  fill: url(#header-shape-gradient) #fff;',
'}',
'',
'#header-shape-gradient {',
'  --color-stop: #f12c06;',
'  --color-bot: #faed34;',
'}*/'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'04'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(323075487029152361)
,p_plug_name=>'Mockup GANTT-Chart'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(323075539117152362)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_imp.id(323075487029152361)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(1003910018408917696)
,p_region_id=>wwv_flow_imp.id(323075539117152362)
,p_chart_type=>'gantt'
,p_height=>'700'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'visible'
,p_vertical_grid=>'visible'
,p_row_axis_rendered=>'on'
,p_gantt_axis_position=>'top'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(1003908292886917686)
,p_chart_id=>wwv_flow_imp.id(1003910018408917696)
,p_seq=>10
,p_name=>'New'
,p_data_source_type=>'SQL'
,p_data_source=>'select * from t_x_gantt'
,p_items_label_rendered=>true
,p_items_label_display_as=>'PERCENT'
,p_gantt_start_date_source=>'ITEM'
,p_gantt_start_date_item=>'P402_START'
,p_gantt_end_date_source=>'ITEM'
,p_gantt_end_date_item=>'P402_ENDE'
,p_gantt_row_id=>'THEMAID'
,p_gantt_task_id=>'VORSCHRIFTID'
,p_gantt_task_name=>'VORSCHRIFT_NUMMER'
,p_gantt_task_start_date=>'DATUMSTART'
,p_gantt_task_end_date=>'DATUMENDE'
,p_gantt_task_css_class=>'&CSS_CLASS.'
,p_gantt_baseline_start_column=>'BASELINESTART'
,p_gantt_baseline_end_column=>'BASELINEENDE'
,p_task_label_position=>'innerStart'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(1003908882792917690)
,p_chart_id=>wwv_flow_imp.id(1003910018408917696)
,p_axis=>'major'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_axis_scale=>'years'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>true
,p_zoom_order_weeks=>true
,p_zoom_order_months=>true
,p_zoom_order_quarters=>true
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(1003909482984917692)
,p_chart_id=>wwv_flow_imp.id(1003910018408917696)
,p_axis=>'minor'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_axis_scale=>'months'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>true
,p_zoom_order_weeks=>true
,p_zoom_order_months=>true
,p_zoom_order_quarters=>true
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1003911849034917714)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(323075487029152361)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1003911517779917707)
,p_name=>'P402_LAND'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(323075487029152361)
,p_prompt=>'Land'
,p_source=>'1022'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b_nummer || '' - '' || CASE ',
'    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'    ELSE land_eng',
'END as d, landid as r from t_land order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1003911061227917703)
,p_name=>'P402_START'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(323075487029152361)
,p_prompt=>'Start'
,p_format_mask=>'dd.mm.yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1003910721070917703)
,p_name=>'P402_ENDE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(323075487029152361)
,p_prompt=>'Ende'
,p_format_mask=>'dd.mm.yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
