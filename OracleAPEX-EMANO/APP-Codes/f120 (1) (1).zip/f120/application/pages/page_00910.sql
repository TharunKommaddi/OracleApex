prompt --application/pages/page_00910
begin
--   Manifest
--     PAGE: 00910
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>910
,p_name=>'Audittypen'
,p_alias=>'AUDITTYPEN'
,p_step_title=>'Audittypen'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(193644588056972107)
,p_name=>'Audittypen <span onclick="redirect(910)" class="fa fa-question-square-o"></span>'
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select AUDIT_TYPID,',
'       2 as link,',
'       BEZEICHNUNG,',
'       name_eng,',
'       DAUER_GUELTIGKEIT,',
'       CASE a.Status ',
'           WHEN 10 THEN emano_util.fLang(''Aktiv'', ''Active'')',
'           WHEN 20 THEN emano_util.fLang(''Inaktiv'', ''Inactive'')',
'',
'       END as Status,',
'       ',
'       a.LETZTE_AENDERUNG_DATUM,',
'       nvl2(a.letzte_aenderung_benutzer_id, nachname || '', '' || vorname, null) as LETZTE_AENDERUNG_BENUTZER',
'  from T_AUDIT_TYP a',
'  left join t_benutzer b on b.benutzerid = a.LETZTE_AENDERUNG_BENUTZER_ID',
'  order by bezeichnung, name_eng;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(473566405731995685)
,p_query_column_id=>1
,p_column_alias=>'AUDIT_TYPID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(449112617158757927)
,p_query_column_id=>2
,p_column_alias=>'LINK'
,p_column_display_sequence=>2
,p_column_link=>'f?p=&APP_ID.:915:&SESSION.::&DEBUG.:RP,905:P915_AUDIT_TYPID:#AUDIT_TYPID#'
,p_column_linktext=>'<span aria-label="Eintrag bearbeiten"><span class="fa fa-edit" aria-hidden="true" title="Eintrag bearbeiten"></span></span>'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(449113810534757928)
,p_query_column_id=>3
,p_column_alias=>'BEZEICHNUNG'
,p_column_display_sequence=>3
,p_column_heading=>'Bezeichnung'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual',
'where :FSP_LANGUAGE_PREFERENCE = ''de''',
''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(949209567191439891)
,p_query_column_id=>4
,p_column_alias=>'NAME_ENG'
,p_column_display_sequence=>44
,p_column_heading=>'Name Eng'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual',
'where :FSP_LANGUAGE_PREFERENCE = ''en''',
''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(449113411687757928)
,p_query_column_id=>5
,p_column_alias=>'DAUER_GUELTIGKEIT'
,p_column_display_sequence=>4
,p_column_heading=>unistr('G\00FCltigkeit (Monate)')
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1095212070737265231)
,p_query_column_id=>6
,p_column_alias=>'STATUS'
,p_column_display_sequence=>14
,p_column_heading=>'Status'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(449113027074757927)
,p_query_column_id=>7
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>24
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_column_format=>'DD.MM.YYYY HH24:Mi'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(449112230617757927)
,p_query_column_id=>8
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZER'
,p_column_display_sequence=>34
,p_column_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(449111811453757924)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(193644588056972107)
,p_button_name=>'Create'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:915:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(473564166513995663)
,p_name=>'Edit Page 915 closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(193644588056972107)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(473564124862995662)
,p_event_id=>wwv_flow_imp.id(473564166513995663)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(193644588056972107)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(473564034459995661)
,p_name=>'Create Page 915 closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(449111811453757924)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(473563929026995660)
,p_event_id=>wwv_flow_imp.id(473564034459995661)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(193644588056972107)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
