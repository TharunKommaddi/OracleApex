prompt --application/pages/page_00950
begin
--   Manifest
--     PAGE: 00950
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>950
,p_name=>'Arbeitsaufgaben-Typen'
,p_alias=>'ARBEITSAUFGABEN-TYPEN'
,p_step_title=>'Arbeitsaufgaben-Typen'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(401866634998305792)
,p_name=>'Arbeitsaufgaben-Typen'
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select at.ROWID as at_rowid,',
'       ARBEITSAUFGABE_TYPID,',
'       AUFGABE_DE,',
'       AUFGABE_EN,       ',
'       at.LETZTE_AENDERUNG_DATUM,',
'       nvl2(at.letzte_aenderung_benutzerid, nachname || '', '' || vorname, null) as LETZTE_AENDERUNG_BENUTZER',
'  from T_ARBEITSAUFGABE_TYP at',
'  left join t_benutzer b on b.benutzerid = at.LETZTE_AENDERUNG_BENUTZERID'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126014834175526643)
,p_query_column_id=>1
,p_column_alias=>'AT_ROWID'
,p_column_display_sequence=>1
,p_column_link=>'f?p=&APP_ID.:955:&SESSION.::&DEBUG.:955:P955_ROWID:#AT_ROWID#'
,p_column_linktext=>'<span aria-label="Eintrag bearbeiten"><span class="fa fa-edit" aria-hidden="true" title="Eintrag bearbeiten"></span></span>'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126014728333526642)
,p_query_column_id=>2
,p_column_alias=>'ARBEITSAUFGABE_TYPID'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126014908689526644)
,p_query_column_id=>3
,p_column_alias=>'AUFGABE_DE'
,p_column_display_sequence=>4
,p_column_heading=>'Name Deutsch'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual',
'where :FSP_LANGUAGE_PREFERENCE = ''de'''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126015040929526645)
,p_query_column_id=>4
,p_column_alias=>'AUFGABE_EN'
,p_column_display_sequence=>5
,p_column_heading=>'Name Englisch'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual',
'where :FSP_LANGUAGE_PREFERENCE = ''en'''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(401865347383305788)
,p_query_column_id=>5
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>6
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_column_format=>'DD.MM.YYYY HH24:Mi'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(126015154334526646)
,p_query_column_id=>6
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZER'
,p_column_display_sequence=>7
,p_column_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(401863632473305786)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(401866634998305792)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:955:&SESSION.::&DEBUG.:955'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(401864603009305787)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(401866634998305792)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401864124057305786)
,p_event_id=>wwv_flow_imp.id(401864603009305787)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(401866634998305792)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
