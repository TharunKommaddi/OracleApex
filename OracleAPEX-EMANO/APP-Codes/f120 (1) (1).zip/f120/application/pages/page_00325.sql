prompt --application/pages/page_00325
begin
--   Manifest
--     PAGE: 00325
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>325
,p_name=>'Suchparameter'
,p_page_mode=>'MODAL'
,p_step_title=>'Suchparameter'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function loadLaenderShuttle() {',
'    var shuttleName = ''P325_FILTER_LAND'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadLaenderShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P325_FILTER_LAENDERGRUPPE''),',
'          x03: $v(''P325_STARTDATUM_TYP'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                console.log(pData);',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'function loadThemenShuttle() {',
'    var shuttleName = ''P325_FILTER_THEMEN'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lAntriebsart = $v(''P325_ANTRIEBSART'');',
'    var lArbeitskreis = $v(''P325_ARBEITSKREISE'');    ',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadThemenShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P325_FILTER_THEMEN_PRE''),',
'          x03: lAntriebsart,',
'          x04: lArbeitskreis',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'function updateLabelDatumSop() {',
'    var lItem = apex.item("P325_STARTDATUM_TYP");',
'    var lValue = lItem.getValue();',
'',
'    if (lValue == 20) {',
'    $("label[for=P325_DATUM_SOP]").text("Datum ME");',
'    } else {',
'    $("label[for=P325_DATUM_SOP]").text("Datum SOP");',
'    } ',
'}',
'',
'$(document).ready(function() {',
'   updateLabelDatumSop(); ',
'});',
'',
'$(''.shuttleSort2'').css(''display'', ''none'');',
'$(''.apex-item-wrapper--shuttle'').css(''padding-top'', ''0rem'');',
'',
'function addItemToShuttle(aShuttle, aID, aDisplay) {',
'    var lLeft = $(''#'' + aShuttle + ''_LEFT'');',
'    var lRight = $(''#'' + aShuttle + ''_RIGHT'');',
'    lLeft.find(''option[value='' + aID + '']'').remove();',
'    lRight.append(''<option value="'' + aID + ''">'' + aDisplay + ''</option>'');',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1200'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2663071478202150349)
,p_plug_name=>'Suchparameter'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(852077110251380102)
,p_plug_name=>'Trennlinie'
,p_parent_plug_id=>wwv_flow_imp.id(2663071478202150349)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>90
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<hr>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(852076953989380101)
,p_plug_name=>'Risikobewertung'
,p_parent_plug_id=>wwv_flow_imp.id(2663071478202150349)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>100
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(213246820784506819)
,p_plug_name=>unistr('Box Vorfilter L\00E4nder')
,p_parent_plug_id=>wwv_flow_imp.id(2663071478202150349)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>70
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(213246952381506820)
,p_plug_name=>unistr('Box Filter L\00E4nder')
,p_parent_plug_id=>wwv_flow_imp.id(2663071478202150349)
,p_region_template_options=>'#DEFAULT#:margin-left-md'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(213247017237506821)
,p_plug_name=>'Trennlinie'
,p_parent_plug_id=>wwv_flow_imp.id(2663071478202150349)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<hr>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(213247123106506822)
,p_plug_name=>'Box Vorfilter Themen'
,p_parent_plug_id=>wwv_flow_imp.id(2663071478202150349)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(213247230064506823)
,p_plug_name=>'Box Filter Themen'
,p_parent_plug_id=>wwv_flow_imp.id(2663071478202150349)
,p_region_template_options=>'#DEFAULT#:margin-left-md'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(213247341239506824)
,p_plug_name=>'Trennlinie'
,p_parent_plug_id=>wwv_flow_imp.id(2663071478202150349)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<hr>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(213247479027506825)
,p_plug_name=>'Haupteinstellungen'
,p_parent_plug_id=>wwv_flow_imp.id(2663071478202150349)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2663872523952773837)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noBorder'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1003879938557808363)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(213246952381506820)
,p_button_name=>'B_KOMMENTARE_PRUEFEN'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('Kommentar bez. ausgew\00E4hlten L\00E4ndern pr\00FCfen')
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-info-square-o'
,p_button_cattributes=>'style="margin: 0px; padding: 0px; "'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1016219338661619189)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(213247479027506825)
,p_button_name=>'B_FALKO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--iconRight:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'SOP/EOP (FALKO)'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:366:&SESSION.::&DEBUG.:365::'
,p_icon_css_classes=>'fa-search'
,p_grid_column_css_classes=>'t-Form-inputContainer'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2663072260390150356)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2663872523952773837)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2663872586579773838)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2663872523952773837)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(2684761346005888537)
,p_branch_name=>'Go To Page 300'
,p_branch_action=>'f?p=&APP_ID.:320:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
,p_branch_condition_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_branch_condition=>'B_KOMMENTARE_PRUEFEN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1018243480762985703)
,p_name=>'P325_CKD_FBU_MODE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(213247479027506825)
,p_item_default=>'0'
,p_prompt=>'FBU/CKD'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'CKD',
  'off_value', '1',
  'on_label', 'FBU',
  'on_value', '0',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1003879641071808360)
,p_name=>'P325_BESONDERHEITEN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(213246952381506820)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(994912148256239301)
,p_name=>'P325_MJ_START'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(213247479027506825)
,p_prompt=>'Mj Start'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(994912120188239300)
,p_name=>'P325_MJ_ENDE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(213247479027506825)
,p_prompt=>'Mj Ende'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(980179453528826090)
,p_name=>'P325_URL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(213246952381506820)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(980176562477826061)
,p_name=>'P325_LAND_STATUS_DATENSTAND'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(213246952381506820)
,p_prompt=>unistr('Die folgenden L\00E4nder sind derzeit im Regulation Index nicht abgebildet:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="font-size: 12px; font-weight: 100; line-height: 16px; margin:0px; padding:0px;"'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#:margin-top-none:margin-bottom-none'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(852076850908380100)
,p_name=>'P325_LOW_RISK'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(852076953989380101)
,p_prompt=>'Mittleres Risko in Monaten'
,p_source=>'24'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_cMaxlength=>2
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(852076832113380099)
,p_name=>'P325_HIGH_RISK'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(852076953989380101)
,p_prompt=>'Hohes Risiko in Monaten'
,p_source=>'12'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_cMaxlength=>2
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(852076476761380096)
,p_name=>'P325_HILFE_RISIKO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(852076953989380101)
,p_prompt=>'Risikobewertung'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    emano_util.fLang(''Risikobewertung'', ''Risk Assessment'') ',
'    || '' <span onclick="redirect(241)" class="fa fa-question-square-o"></span>'' ',
'    AS localized_string',
'FROM DUAL;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(3414144103148820565)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(852069812466359782)
,p_name=>'P325_ARBEITSKREISE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(213247123106506822)
,p_item_default=>'-1'
,p_prompt=>'Vorfilter Arbeitskreise'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    kurz || '' '' || ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END AS d, ',
'    et_b_akid AS r',
'FROM ',
'    t_et_b_ak',
'WHERE ',
'    et_b_akid != 1200',
'AND ',
'    et_b_akid IN (SELECT et_b_akid FROM t_thema_ref_et_b_ak)',
'ORDER BY ',
'    1;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- alle -'
,p_lov_null_value=>'-1'
,p_cHeight=>5
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(845259045313776703)
,p_name=>'P325_THEMEN_CHILDREN_TO_ADD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(213247123106506822)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(842883180598700803)
,p_name=>'P325_SUCHE_JSON_DATEN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2663071478202150349)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1455628898524718031)
,p_name=>'P325_ANTRIEBSART'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(213247123106506822)
,p_item_default=>'-1'
,p_prompt=>'Vorfilter Antriebsart'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END AS d,',
'    antriebsartid AS r ',
'FROM ',
'    t_antriebsart',
'ORDER BY ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END;',
''))
,p_cHeight=>5
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663071632319150350)
,p_name=>'P325_SUCHE_TEMPID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2663071478202150349)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663071794472150352)
,p_name=>'P325_DATUM_MEILENSTEIN'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(213247479027506825)
,p_item_default=>'Sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Datum Meilenstein'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663071923039150353)
,p_name=>'P325_DATUM_SOP'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(213247479027506825)
,p_prompt=>'Datum SOP'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663071977339150354)
,p_name=>'P325_DATUM_EOP'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(213247479027506825)
,p_prompt=>'Datum EOP'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663072350602150357)
,p_name=>'P325_STATUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2663071478202150349)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663307605344664040)
,p_name=>'P325_FILTER_LAENDERGRUPPE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(213246820784506819)
,p_prompt=>unistr('Vorfilter L\00E4nder&shy;gruppen')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select lg.laendergruppe, lg.laendergruppeid ',
'from t_laendergruppe lg where lg.laendergruppeid!=1220',
'order by 1;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- alle -'
,p_cHeight=>5
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663307733680664041)
,p_name=>'P325_FILTER_LAND'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(213246952381506820)
,p_prompt=>unistr('L\00E4nder')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select l.b_nummer || '' - '' ||  ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.land',
'        ELSE l.land_eng ',
'    END AS Land_Name, l.landid',
'from t_land l',
'where (:P325_FILTER_LAENDERGRUPPE is null or landid in (select landid from t_land_ref_laendergruppe where laendergruppeid = :P325_FILTER_LAENDERGRUPPE))',
'    and (:P325_STARTDATUM_TYP is null or startdatum_typ = :P325_STARTDATUM_TYP)',
'ORDER BY NLSSORT(l.B_NUMMER, ''NLS_SORT=BINARY_AI'') ASC'))
,p_cHeight=>4
,p_tag_css_classes=>'margin-bottom-none'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663307769278664042)
,p_name=>'P325_FILTER_THEMEN_PRE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(213247123106506822)
,p_prompt=>'Vorfilter Themen'
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" onclick="loadThemenShuttle()"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663307931405664043)
,p_name=>'P325_FILTER_THEMEN'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(213247230064506823)
,p_prompt=>'Themengebiete'
,p_display_as=>'NATIVE_SHUTTLE'
,p_named_lov=>'LOV_THEMA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    NUMMER || '' - '' || ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN BEZEICHNUNG',
'        ELSE name_eng',
'    END as d,',
'    THEMAID as r',
'FROM V_THEMA_BAUM vtb',
'-- It excludes topics linked to et_b_akid = 1036 in t_thema_ref_et_b_ak, ensuring results are relevant to users without access to these excluded topics.',
'-- WHERE vtb.themaid not in (select themaid from t_thema_ref_et_b_ak where et_b_akid =1036 )',
'ORDER BY vtb.thema_sortorder;'))
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2666177556070204545)
,p_name=>'P325_STARTDATUM_TYP'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(213247479027506825)
,p_item_default=>'10'
,p_prompt=>'Art des Startdatums'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lResult number;',
'begin',
'    select l.startdatum_typ into lResult',
'    from t_land l',
'    where l.landid in (select column_value from TABLE(APEX_STRING.split_numbers(:P325_FILTER_LAND, '':'')))',
'    OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY;',
'    ',
'    return lResult;',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'    lResult := null;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_STARTDATUM_TYP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''SOP'', ''SOP'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Markteinf\00FChrung (ME)'', ''Market Introduction (MI)'') AS display_value,'),
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:margin-bottom-none'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2667654866759616641)
,p_name=>'P325_SUCHE_MODUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(213247479027506825)
,p_prompt=>'Suche Modus'
,p_source=>'0'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Bestehender Typ',
  'off_value', '10',
  'on_label', 'Neue Typen',
  'on_value', '0',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1455628724860718030)
,p_validation_name=>'Validation_EOP'
,p_validation_sequence=>10
,p_validation=>'to_date(:P325_DATUM_EOP) > to_date(:P325_DATUM_SOP)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Der EOP muss nach dem SOP liegen'
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(2663071977339150354)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(896553611393355376)
,p_validation_name=>'Validation_EOP_not_null'
,p_validation_sequence=>20
,p_validation=>'(:P325_DATUM_EOP is not null)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Es muss ein Datum EOP festgelegt werden.'
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(2663071977339150354)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(896553451571355375)
,p_validation_name=>'Validation_SOP_not_null'
,p_validation_sequence=>30
,p_validation=>'(:P325_DATUM_SOP is not null)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Es muss ein Datum SOP festgelegt werden.'
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(2663071923039150353)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(896553232950355372)
,p_validation_name=>'Validation_Datum_Meilenstei_not_null'
,p_validation_sequence=>40
,p_validation=>'(:P325_DATUM_MEILENSTEIN is not null)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Es muss ein Datum Meilenstein festgelegt werden.'
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(2663071794472150352)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(896553346352355374)
,p_validation_name=>'Validation Thema gewaehlt'
,p_validation_sequence=>50
,p_validation=>'(:P325_FILTER_THEMEN is not null)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Es muss mindestens ein Thema ausgew\00E4hlt werden.')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(2663307931405664043)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(896553286399355373)
,p_validation_name=>'Validation Land gewaehlt'
,p_validation_sequence=>60
,p_validation=>'(:P325_FILTER_LAND is not null)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Es muss mindestens ein Land ausgew\00E4hlt werden.')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(2663307733680664041)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(840699629147540401)
,p_validation_name=>'Validation Risiko Low Reihenvolge'
,p_validation_sequence=>70
,p_validation=>'(:P325_low_risk> :P325_HIGH_RISK)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Das Mittlere Risiko muss gr\00F6\00DFer als das Hohe Risiko sein.')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(852076850908380100)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(840699519620540400)
,p_validation_name=>'Validation Risiko High Reihenvolge'
,p_validation_sequence=>80
,p_validation=>'(:P325_low_risk> :P325_HIGH_RISK)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Das Mittlere Risiko muss gr\00F6\00DFer als das Hohe Risiko sein.')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(852076832113380099)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2663308164202664045)
,p_name=>'FILTER_LAENDERGRUPPE_CHANGED'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P325_FILTER_LAENDERGRUPPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2663308265782664046)
,p_event_id=>wwv_flow_imp.id(2663308164202664045)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2663308279529664047)
,p_name=>'FILTER_THEMEN_PRE_CHANGED'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P325_FILTER_THEMEN_PRE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2663308369846664048)
,p_event_id=>wwv_flow_imp.id(2663308279529664047)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadThemenShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2663872765609773839)
,p_name=>'CANCEL'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2663872586579773838)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2663872861302773840)
,p_event_id=>wwv_flow_imp.id(2663872765609773839)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2666177342081204543)
,p_name=>'FILTER_LAND_CHANGED'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P325_FILTER_LAND'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2666177439719204544)
,p_event_id=>wwv_flow_imp.id(2666177342081204543)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    select l.startdatum_typ into :P325_STARTDATUM_TYP',
'    from t_land l',
'    where l.landid in (select column_value from TABLE(APEX_STRING.split_numbers(:P325_FILTER_LAND, '':'')))',
'    OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY;',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'    :P325_STARTDATUM_TYP := null;',
'end;'))
,p_attribute_02=>'P325_FILTER_LAND'
,p_attribute_03=>'P325_STARTDATUM_TYP'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2666475985716620537)
,p_name=>'STARTDATUM_TYP_CHANGE'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P325_STARTDATUM_TYP'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2666476225034620539)
,p_event_id=>wwv_flow_imp.id(2666475985716620537)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P325_FILTER_LAND'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2666476119906620538)
,p_event_id=>wwv_flow_imp.id(2666475985716620537)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'loadLaenderShuttle();',
'updateLabelDatumSop();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1455993548926153832)
,p_name=>'Antriebart changed'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P325_ANTRIEBSART'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1455993675042153833)
,p_event_id=>wwv_flow_imp.id(1455993548926153832)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadThemenShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1460575088385518262)
,p_name=>'Disable mode switch when limited User'
,p_event_sequence=>70
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>'pck_ri.fIsLimitedUser = 1 '
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1460575215154518263)
,p_event_id=>wwv_flow_imp.id(1460575088385518262)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P325_SUCHE_MODUS'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1016216699523619162)
,p_name=>'Dialog Falko closed'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1016219338661619189)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1016216622849619161)
,p_event_id=>wwv_flow_imp.id(1016216699523619162)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P325_DATUM_SOP'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P367_SOP'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1016216524831619160)
,p_event_id=>wwv_flow_imp.id(1016216699523619162)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P325_DATUM_EOP'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P367_EOP'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1016216408018619159)
,p_event_id=>wwv_flow_imp.id(1016216699523619162)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P325_FILTER_LAND'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P367_BNUMMERN'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1003879848572808362)
,p_name=>'FILTER_LAND_CHANGED_BESNDERHEITEN'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P325_FILTER_LAND'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(980180662871826102)
,p_event_id=>wwv_flow_imp.id(1003879848572808362)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(landid, '':'') into :P325_BESONDERHEITEN',
'from t_land',
'where landid in (select column_value from table(apex_string.split_numbers(:P325_FILTER_LAND, '':'')))',
'and besonderheiten is not null;',
'--APEX_UTIL.SET_SESSION_STATE(''P325_BESONDERHEITEN'', ''SOME VALUE'');'))
,p_attribute_02=>'P325_FILTER_LAND'
,p_attribute_03=>'P325_BESONDERHEITEN'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1003879523851808358)
,p_name=>'LAENDER_MIT_BESONDERHEIT_CHANGED'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P325_BESONDERHEITEN'
,p_condition_element=>'P325_BESONDERHEITEN'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1003879407132808357)
,p_event_id=>wwv_flow_imp.id(1003879523851808358)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(1003879938557808363)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1003879272121808356)
,p_event_id=>wwv_flow_imp.id(1003879523851808358)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(1003879938557808363)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(980179354764826089)
,p_event_id=>wwv_flow_imp.id(1003879523851808358)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apeX_page.get_url (',
'    p_page => 136,',
'    p_items => ''P136_LAENDER'',',
'    p_values => ''\'' || :P325_BESONDERHEITEN || ''\'',',
'    p_clear_cache => 136',
') into :P325_URL FROM DUAL;'))
,p_attribute_02=>'P325_BESONDERHEITEN'
,p_attribute_03=>'P325_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(980179229262826087)
,p_name=>'open_modal'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1003879938557808363)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(980179078375826086)
,p_event_id=>wwv_flow_imp.id(980179229262826087)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window.location=$("#P325_URL").val();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(980176795788826063)
,p_name=>'FILTER_LAND_CHANGED_UMSETZUNGSSTAND'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P325_FILTER_LAND'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(980176722629826062)
,p_event_id=>wwv_flow_imp.id(980176795788826063)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('select nvl2(listagg(landid), --''Die Folgenden L\00E4nder sind derzeit im Regulation Index nicht abgebildet:<br />'' '),
'            '''' || listagg(b_nummer || '' - '' || land, '', ''), null) into :P325_LAND_STATUS_DATENSTAND',
'from t_land',
'where landid in (select column_value from table(apex_string.split_numbers(:P325_FILTER_LAND, '':'')))',
'    and STATUS_DATENSTAND = 0',
'',
';'))
,p_attribute_02=>'P325_FILTER_LAND'
,p_attribute_03=>'P325_LAND_STATUS_DATENSTAND'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(980176487578826060)
,p_name=>'UMSETZUNGSTATUS_DATENSTAND_CHANGED'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P325_LAND_STATUS_DATENSTAND'
,p_condition_element=>'P325_LAND_STATUS_DATENSTAND'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(980176401847826059)
,p_event_id=>wwv_flow_imp.id(980176487578826060)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P325_LAND_STATUS_DATENSTAND'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(980176303334826058)
,p_event_id=>wwv_flow_imp.id(980176487578826060)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P325_LAND_STATUS_DATENSTAND'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(852076657222380098)
,p_name=>'Arbeitskreis_changed'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P325_ARBEITSKREISE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(852076630566380097)
,p_event_id=>wwv_flow_imp.id(852076657222380098)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadThemenShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(845260645753785472)
,p_name=>'add childThemen'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P325_FILTER_THEMEN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(845259828601785460)
,p_event_id=>wwv_flow_imp.id(845260645753785472)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lThemenliste apex_t_number := apex_string.split_numbers(:P325_FILTER_THEMEN,'':'');',
'begin    ',
'',
'    apex_json.initialize_clob_output;',
'    apex_json.open_array;    ',
'',
unistr('    -- Jedes bereits ausgew\00E4hlte Thema durchgehen und dessen Kinder selektieren'),
'    for i in 1 .. lThemenliste.count loop',
'        for childthemen in (',
'            select themaid, nummer || '' - '' || bezeichnung as d',
'            from t_thema',
'            connect by parentid = prior themaid',
'            start with parentid = lThemenliste(i)',
'        ) loop',
'            -- Wenn das entsprechende Kind noch nicht im Shuttle ist, dann ',
unistr('            -- zu einer Hinzuf\00FCgungs-Liste addieren'),
'            if (childthemen.themaid not member of lThemenliste) then',
'                apex_json.open_object;',
'                apex_json.write(''id'',childthemen.themaid);',
'                apex_json.write(''display'',childthemen.d);',
'                apex_json.close_object;',
'            end if;',
'        end loop;',
'    ',
'    end loop;',
unistr('    -- Hinzuf\00FCgungs-Liste ist hidden item'),
unistr('    -- Direktes Hinzuf\00FCgen w\00FCrde zu einem Refresh der Scrollbalken des Items f\00FChren'),
'    apex_json.close_array;',
'    :P325_THEMEN_CHILDREN_TO_ADD := apex_json.get_clob_output;',
'    apex_json.free_output;',
'end;    '))
,p_attribute_02=>'P325_FILTER_THEMEN'
,p_attribute_03=>'P325_THEMEN_CHILDREN_TO_ADD'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(845260294222785461)
,p_event_id=>wwv_flow_imp.id(845260645753785472)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var items = JSON.parse($v(''P325_THEMEN_CHILDREN_TO_ADD''));',
'',
unistr('// alle Items im Shuttle hinzuf\00FCgen'),
'for (item of items) {',
'    if (item) addItemToShuttle(''P325_FILTER_THEMEN'',item.id,item.display);',
'} ',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(769854017568276103)
,p_event_id=>wwv_flow_imp.id(845260645753785472)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var obj = new Object();',
'obj.LAENDER = $v(''P325_FILTER_LAND'');',
'obj.THEMEN = $v(''P325_FILTER_THEMEN'');',
'obj.LOW_RISK =  $v(''P325_LOW_RISK'');',
'obj.HIGH_RISK =  $v(''P325_HIGH_RISK'');',
'obj.CKD_FBU_MODE = $v(''P325_CKD_FBU_MODE'');',
'obj.DATUM_SOP = $v(''P325_DATUM_SOP'');',
'obj.DATUM_EOP = $v(''P325_DATUM_EOP'');',
'obj.DATUM_MEILENSTEIN = $v(''P325_DATUM_MEILENSTEIN'');',
'obj.SUCHTYP = $v(''P325_SUCHE_MODUS'');',
'',
'',
'$s(''P325_SUCHE_JSON_DATEN'', JSON.stringify(obj));',
'',
'apex.server.process(''DUMMY_PROCESS'', {',
'    pageItems: ''#P325_SUCHE_JSON_DATEN''',
'}, {',
'    dataType: "text"',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(842883056164700802)
,p_name=>'FILTER_CHANGE'
,p_event_sequence=>160
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P325_FILTER_LAND,P325_FILTER_THEMEN,P325_SUCHE_MODUS,P325_LOW_RISK,P325_HIGH_RISK,P325_DATUM_MEILENSTEIN,P325_DATUM_SOP,P325_DATUM_EOP,P325_CKD_FBU_MODE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(842882978995700801)
,p_event_id=>wwv_flow_imp.id(842883056164700802)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var obj = new Object();',
'obj.LAENDER = $v(''P325_FILTER_LAND'');',
'obj.THEMEN = $v(''P325_FILTER_THEMEN'');',
'obj.LOW_RISK =  $v(''P325_LOW_RISK'');',
'obj.HIGH_RISK =  $v(''P325_HIGH_RISK'');',
'obj.CKD_FBU_MODE = $v(''P325_CKD_FBU_MODE'');',
'obj.DATUM_SOP = $v(''P325_DATUM_SOP'');',
'obj.DATUM_EOP = $v(''P325_DATUM_EOP'');',
'obj.DATUM_MEILENSTEIN = $v(''P325_DATUM_MEILENSTEIN'');',
'obj.SUCHTYP = $v(''P325_SUCHE_MODUS'');',
'',
'',
'$s(''P325_SUCHE_JSON_DATEN'', JSON.stringify(obj));',
'',
'apex.server.process(''DUMMY_PROCESS'', {',
'    pageItems: ''#P325_SUCHE_JSON_DATEN''',
'}, {',
'    dataType: "text"',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(840699787005540403)
,p_name=>'FILTER_CHANGE_1'
,p_event_sequence=>170
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(840699645092540402)
,p_event_id=>wwv_flow_imp.id(840699787005540403)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var obj = new Object();',
'obj.LAENDER = $v(''P325_FILTER_LAND'');',
'obj.THEMEN = $v(''P325_FILTER_THEMEN'');',
'obj.LOW_RISK =  $v(''P325_LOW_RISK'');',
'obj.HIGH_RISK =  $v(''P325_HIGH_RISK'');',
'obj.CKD_FBU_MODE = $v(''P325_CKD_FBU_MODE'');',
'obj.DATUM_SOP = $v(''P325_DATUM_SOP'');',
'obj.DATUM_EOP = $v(''P325_DATUM_EOP'');',
'obj.DATUM_MEILENSTEIN = $v(''P325_DATUM_MEILENSTEIN'');',
'obj.SUCHTYP = $v(''P325_SUCHE_MODUS'');',
'',
'',
'$s(''P325_SUCHE_JSON_DATEN'', JSON.stringify(obj));',
'',
'apex.server.process(''DUMMY_PROCESS'', {',
'    pageItems: ''#P325_SUCHE_JSON_DATEN''',
'}, {',
'    dataType: "text"',
'});'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2663072422820150358)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_SUCHPARAMETER'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'update t_suche_temp t',
'set t.suchdaten.datum_meilenstein = :P325_DATUM_MEILENSTEIN,',
' t.suchdaten.datum_sop = :P325_DATUM_SOP,',
' t.suchdaten.datum_eop = :P325_DATUM_EOP,',
' t.suchdaten.liste_laender = :P325_FILTER_LAND,',
' t.suchdaten.liste_themen = :P325_FILTER_THEMEN,',
' t.suchdaten.suchtyp = :P325_SUCHE_MODUS,',
' t.suchdaten.ckd_fbu_mode = :P325_ckd_fbu_mode',
'where suche_tempid = :P325_SUCHE_TEMPID;',
'*/',
'',
'--Neue JSON Variante',
'update t_suche_JSON_TEMP',
'set SUCHDATEN = :P325_SUCHE_JSON_DATEN',
'where suche_tempid = :P325_SUCHE_TEMPID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2663072260390150356)
,p_internal_uid=>6335284738719538593
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2663072152843150355)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LOAD_SUCHPARAMETER'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (:P325_STATUS is null) then',
'',
'',
'    -- Daten der Suche aus T_SUCHE_TEMP laden',
'/*',
'    select t.suchdaten.datum_meilenstein, t.suchdaten.datum_sop, t.suchdaten.datum_eop, ',
'        t.suchdaten.liste_laender, t.suchdaten.liste_themen, t.suchdaten.suchtyp, t.suchdaten.ckd_fbu_mode',
'    into :P325_DATUM_MEILENSTEIN, :P325_DATUM_SOP, :P325_DATUM_EOP,',
'        :P325_FILTER_LAND, :P325_FILTER_THEMEN, :P325_SUCHE_MODUS, :P325_ckd_fbu_mode',
'    from t_suche_temp t',
'    where SUCHE_TEMPID = :P325_SUCHE_TEMPID;',
'*/',
'Select JSON_VALUE(SUCHDATEN,''$.DATUM_MEILENSTEIN''),JSON_VALUE(SUCHDATEN,''$.DATUM_SOP''),JSON_VALUE(SUCHDATEN,''$.DATUM_EOP'' ),',
'JSON_VALUE(SUCHDATEN,''$.LAENDER''), JSON_VALUE(SUCHDATEN,''$.THEMEN'' ),JSON_VALUE(SUCHDATEN,''$.SUCHTYP'' ),JSON_VALUE(SUCHDATEN,''$.CKD_FBU_MODE'' ),',
'JSON_VALUE(SUCHDATEN,''$.LOW_RISK'' ),JSON_VALUE(SUCHDATEN,''$.HIGH_RISK'' )',
'into :P325_DATUM_MEILENSTEIN, :P325_DATUM_SOP, :P325_DATUM_EOP,',
'        :P325_FILTER_LAND, :P325_FILTER_THEMEN, :P325_SUCHE_MODUS, :P325_ckd_fbu_mode,',
'        :P325_LOW_RISK, :P325_HIGH_RISK',
'',
'',
'',
'from t_suche_json_temp t',
'    where SUCHE_TEMPID = :P325_SUCHE_TEMPID;',
'',
'',
'    :P325_STATUS := 10;',
'        ',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6335284468742538590
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2663308044059664044)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLaenderShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lLaendergruppe varchar2(2000) := apex_application.g_x02;',
'    lStartdatumTyp number := apex_application.g_x03;',
'BEGIN',
'    ',
'   -- debug(lLaendergruppe);',
'    ',
'    apex_json.open_array;',
'    for l in (',
'        select b_nummer || '' - '' || CASE ',
'    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'    ELSE land_eng',
'END as d, landid',
'        from t_land',
'        where landid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))        ',
'        and (',
'            lLaendergruppe is null',
'            or landid in (',
'                select landid from t_land_ref_laendergruppe where laendergruppeid in (',
'                    select column_value from table(apex_string.split_numbers(lLaendergruppe,'':''))',
'                )',
'            )',
'        ) and (',
'            lStartdatumTyp is null',
'            or startdatum_typ = lStartdatumTyp',
'        )',
'        order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'')        ',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.landid);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'    ',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>6335520359959052279
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2663308475237664049)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadThemenShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lText varchar2(2000) := apex_application.g_x02;',
'    lAntriebsart varchar2(2000) := apex_application.g_x03;',
'    lArbeitskreise varchar2(2000) := apex_application.g_x04;',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    for l in (',
'        select nummer || '' - '' || bezeichnung as d, t.themaid as r',
'        from v_thema_baum t',
'        left outer join t_thema_ref_antriebsart tra on (tra.themaid = t.themaid)',
'        where upper(nummer || '' - '' || bezeichnung) like ''%'' || upper(lText) || ''%''',
'        and t.themaid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))    ',
'        and',
'         (',
'            lArbeitskreise = ''-1'' or t.themaid  in (Select themaid from t_thema_ref_et_b_ak tre where et_b_akid in (',
'                select column_value from table(apex_string.split(lArbeitskreise,'':''))',
'            )',
'            )',
'        )',
'        and (tra.antriebsartid in (select column_value from table(apex_string.split(lantriebsart,'':'')))',
'             or lantriebsart is null',
'            )',
'        group by nummer, bezeichnung, t.themaid, thema_sortorder',
'        order by thema_sortorder',
'        ',
'       ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.r);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6335520791137052284
);
wwv_flow_imp.component_end;
end;
/
