prompt --application/pages/page_00351
begin
--   Manifest
--     PAGE: 00351
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>351
,p_name=>unistr('\00C4nderungshistorie Vorschrift Einsatzdaten')
,p_alias=>unistr('\00C4NDERUNGSHISTORIE-VORSCHRIFT-EINSATZDATEN1')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('\00C4nderungshistorie Vorschrift Einsatzdaten')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IR_HIST .t-fht-tbody {max-height: calc(100vh - 200px)}',
'.t-Body-topButton {display: none !important}',
'.t-Body-content {padding-bottom: 3px !important}',
'.t-Body {margin-bottom: 3px !important}',
'.t-Body-contentInner {padding-bottom: 0px !important}'))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(844790046696077275)
,p_plug_name=>'Historie Vorschrift Einsatzdaten'
,p_region_name=>'IR_HIST'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select H_VORSCHRIFT_REF_EINSATZDATUM_TYPIDNUMBER,',
'    VORSCHRIFT_REF_EINSATZDATUM_TYPID,',
'    v.VORSCHRIFT_NUMMER as VORSCHRIFT,',
'    et.EINSATZDATUM_TYP as EINSATZDATUM_TYP,',
'    pck_ri_history.fdiff(vre.EINSATZDATUM, LAG(vre.EINSATZDATUM) over(partition by vre.vorschriftid, vre.VORSCHRIFT_REF_EINSATZDATUM_TYPID order by vre.letzte_aenderung_datum asc)) as EINSATZDATUM,',
'    pck_ri_history.fdiff(vre.EINSATZDATUM_TEXT, LAG(vre.EINSATZDATUM_TEXT) over(partition by vre.vorschriftid, vre.VORSCHRIFT_REF_EINSATZDATUM_TYPID order by vre.letzte_aenderung_datum asc)) as EINSATZDATUM_TEXT,    ',
'    pck_ri_history.fdiff(',
'        case vre.MANUELLE_EINTRAGUNG when 10 then ''durch Anwender'' when 20 then ''durch System'' else to_char(vre.MANUELLE_EINTRAGUNG) end,',
'        case LAG(vre.MANUELLE_EINTRAGUNG) over(partition by vre.vorschriftid, vre.VORSCHRIFT_REF_EINSATZDATUM_TYPID order by vre.letzte_aenderung_datum asc)',
'             when 10 then ''durch Anwender'' when 20 then ''durch System'' else ',
'                to_char(LAG(vre.MANUELLE_EINTRAGUNG) over(partition by vre.vorschriftid, vre.VORSCHRIFT_REF_EINSATZDATUM_TYPID order by vre.letzte_aenderung_datum asc)) end',
'    ',
'    ) as MANUELLE_EINTRAGUNG,',
'    ',
'    vre.letzte_aenderung_datum as letzte_aenderung_datum,',
'    pck_ri.fCreatePermalinkUrl(vre.vorschriftid) as PERMALINK,',
'    b.email as EMAIL,',
'    nvl2(vre.letzte_aenderung_benutzerid, b.nachname || '', '' || b.vorname, null) AS LETZTE_AENDERUNG_BENUTZER',
'',
'from T_H_VORSCHRIFT_REF_EINSATZDATUM_TYP vre',
'left outer join t_benutzer b on (b.benutzerid = vre.letzte_aenderung_benutzerid)',
'left outer join t_vorschrift v on v.vorschriftid = vre.vorschriftid',
'left outer join t_einsatzdatum_typ et on et.einsatzdatum_typid = vre.einsatzdatum_typid',
'',
'where vre.VORSCHRIFTID = :P351_VORSCHRIFTID',
'order by vre.LETZTE_AENDERUNG_DATUM desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Historie Vorschrift Einsatzdaten'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(844789970159077275)
,p_name=>'Historie Vorschrift Kerndaten'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>unistr('Es gibt keine historischen Einsatzdaten f\00FCr diese Vorschrift.')
,p_allow_save_rpt_public=>'Y'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'mailto:#EMAIL#?body=#PERMALINK#'
,p_detail_link_text=>'<span class="fa fa-envelope-o" aria-hidden="true"></span></a>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>267902966936057129
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016294068107110273)
,p_db_column_name=>'H_VORSCHRIFT_REF_EINSATZDATUM_TYPIDNUMBER'
,p_display_order=>10
,p_column_identifier=>'AP'
,p_column_label=>'H Vorschrift Ref Einsatzdatum Typidnumber'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016293642423110271)
,p_db_column_name=>'VORSCHRIFT_REF_EINSATZDATUM_TYPID'
,p_display_order=>20
,p_column_identifier=>'AQ'
,p_column_label=>'Vorschrift Ref Einsatzdatum Typid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016293298540110271)
,p_db_column_name=>'VORSCHRIFT'
,p_display_order=>30
,p_column_identifier=>'AR'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016292927315110270)
,p_db_column_name=>'EINSATZDATUM_TYP'
,p_display_order=>40
,p_column_identifier=>'AS'
,p_column_label=>'Einsatzdatum'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016292530525110270)
,p_db_column_name=>'EINSATZDATUM'
,p_display_order=>50
,p_column_identifier=>'AT'
,p_column_label=>'Datum'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016292038359110270)
,p_db_column_name=>'EINSATZDATUM_TEXT'
,p_display_order=>60
,p_column_identifier=>'AU'
,p_column_label=>'Bemerkung Datum'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016291717918110269)
,p_db_column_name=>'MANUELLE_EINTRAGUNG'
,p_display_order=>70
,p_column_identifier=>'AV'
,p_column_label=>'Manuelle Eintragung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016291290906110269)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>80
,p_column_identifier=>'AW'
,p_column_label=>unistr('\00C4nderung Datum')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016290921593110269)
,p_db_column_name=>'PERMALINK'
,p_display_order=>90
,p_column_identifier=>'AX'
,p_column_label=>'Permalink'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016290507413110269)
,p_db_column_name=>'EMAIL'
,p_display_order=>100
,p_column_identifier=>'AY'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016290132601110268)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>110
,p_column_identifier=>'AZ'
,p_column_label=>unistr('\00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(844771795805064102)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'964032'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LETZTE_AENDERUNG_BENUTZER:LETZTE_AENDERUNG_DATUM:VORSCHRIFT:EINSATZDATUM_TYP:EINSATZDATUM:EINSATZDATUM_TEXT:MANUELLE_EINTRAGUNG:'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1016289333193110250)
,p_name=>'P351_VORSCHRIFTID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(844790046696077275)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
