prompt --application/pages/page_00165
begin
--   Manifest
--     PAGE: 00165
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>165
,p_name=>'Hilfstext bearbeiten'
,p_page_mode=>'MODAL'
,p_step_title=>'Hilfstext bearbeiten'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('var htmldb_delete_message=''Wollen Sie den Hilfstext l\00F6schen?'';'),
'function loadLaenderShuttle() {',
'    var shuttleName = ''P165_FILTER_BLAND'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadLaenderShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P165_FILTER_LAENDERGRUPPE''),',
'          x03: $v(''P165_FILTER_BLAND_PRE''),',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                console.log(pData);',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'1000'
,p_dialog_width=>'1400'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2684479195858686759)
,p_plug_name=>'Form on T_HILFE'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_HILFE'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(370184135247936079)
,p_plug_name=>'Hilfetext'
,p_parent_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(370183963181936078)
,p_plug_name=>'&nbsp;'
,p_parent_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>6
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(371689286955184633)
,p_plug_name=>unistr('L\00E4nderspezifisch')
,p_parent_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_column=>7
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2684479885381686763)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2684480321431686764)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2684479885381686763)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2684479791427686763)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2684479885381686763)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P165_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2684479730986686763)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2684479885381686763)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P165_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2684479573549686763)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2684479885381686763)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P165_ROWID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(962881766415665185)
,p_name=>'P165_HILFETEXT_ENGLISCH'
,p_data_type=>'CLOB'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(370184135247936079)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Help Text Box English'
,p_source=>'HILFETEXT_ENGLISCH'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_custom_html', 'Y',
  'format', 'HTML',
  'min_height', '180',
  'toolbar', 'FULL',
  'toolbar_style', 'MULTILINE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(962881660503665184)
,p_name=>'P165_TITEL_ENG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(370183963181936078)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Titel_Englisch'
,p_source=>'TITEL_ENGLISCH'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>50
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144407257820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(962881562805665183)
,p_name=>'P165_TOOLTIP_ENG'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(370183963181936078)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Tooltip_Englisch'
,p_source=>'TOOLTIP_ENGLISCH'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>1000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(848080910746850983)
,p_name=>'P165_HILFEID_1'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_item_source_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_source=>'HILFEID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(848080832269850982)
,p_name=>'P165_TITEL_1'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_item_source_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_prompt=>'Titel'
,p_source=>'TITEL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(848080679545850981)
,p_name=>'P165_TOOLTIP_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_item_source_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_prompt=>'Tooltip'
,p_source=>'TOOLTIP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>1000
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(848080624536850980)
,p_name=>'P165_HILFETEXT_1'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_item_source_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_prompt=>'Hilfetext'
,p_source=>'HILFETEXT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(848080502828850979)
,p_name=>'P165_URL_VIDEO_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_item_source_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_prompt=>'Url Video'
,p_source=>'URL_VIDEO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>250
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(848080338921850978)
,p_name=>'P165_BASISEINTRAGID_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_item_source_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_prompt=>'Basiseintragid'
,p_source=>'BASISEINTRAGID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(848080282267850977)
,p_name=>'P165_TITEL_ENGLISCH'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_item_source_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_prompt=>'Titel Englisch'
,p_source=>'TITEL_ENGLISCH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>50
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(848080210324850976)
,p_name=>'P165_TOOLTIP_ENGLISCH'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_item_source_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_prompt=>'Tooltip Englisch'
,p_source=>'TOOLTIP_ENGLISCH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>1000
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(848080107333850975)
,p_name=>'P165_HILFETEXT_ENGLISCH_1'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_item_source_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_prompt=>'Hilfetext Englisch'
,p_source=>'HILFETEXT_ENGLISCH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(370184487348936083)
,p_name=>'P165_HILFEID'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_use_cache_before_default=>'NO'
,p_source=>'HILFEID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(370184427488936082)
,p_name=>'P165_BASISEINTRAGID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(370183963181936078)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Referenzeintrag'
,p_source=>'BASISEINTRAGID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN titel ELSE titel_englisch END AS d,',
'    hilfeid r ',
'FROM ',
'    t_HILFE ',
'ORDER BY ',
'    CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN titel ELSE titel_englisch END;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Basiseintrag -'
,p_cSize=>60
,p_grid_column=>1
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(370183027224936068)
,p_name=>'P165_BASISEINTRAG'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(370184135247936079)
,p_prompt=>'<h3>Basiseintrag</h3>'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_tag_attributes=>'readonly'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_custom_html', 'Y',
  'format', 'HTML',
  'min_height', '180',
  'toolbar', 'INTERMEDIATE',
  'toolbar_style', 'MULTILINE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(368973423182554650)
,p_name=>'P165_FILTER_LAENDERGRUPPE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(371689286955184633)
,p_prompt=>unistr('Vorfilter L\00E4ndergruppe')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select laendergruppe, laendergruppeid',
'from t_laendergruppe where laendergruppeid != 1220',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- alle -'
,p_cHeight=>5
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(368973010753554645)
,p_name=>'P165_FILTER_BLAND_PRE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(371689286955184633)
,p_prompt=>unistr('Vorfilter L\00E4nder')
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" onclick="loadLaenderShuttle()"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(368972599713554644)
,p_name=>'P165_FILTER_BLAND'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(371689286955184633)
,p_prompt=>unistr('L\00E4nder')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(landid, '':'') within group (order by landid) ',
'from T_HILFE_ref_LAND hrl',
'join T_HILFE h on (h.HILFEID = hrl.HILFEID )',
'where h.HILFEID = :P165_HILFEID;'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b_nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'        ELSE land_eng',
'    END as d, landid',
'from t_land l',
'where (:P165_FILTER_LAENDERGRUPPE is null or landid in (select landid from t_land_ref_laendergruppe where laendergruppeid = :P165_FILTER_LAENDERGRUPPE))',
'    and status_datenstand <> 0',
'order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'')'))
,p_cHeight=>5
,p_tag_css_classes=>'margin-bottom-none padding-bottom-none'
,p_begin_on_new_line=>'N'
,p_grid_column=>5
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_css_classes=>'margin-bottom-none padding-bottom-none'
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2684482753934686823)
,p_name=>'P165_ROWID'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(2684479195858686759)
,p_use_cache_before_default=>'NO'
,p_source=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2684483118726686835)
,p_name=>'P165_TITEL'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(370183963181936078)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Titel'
,p_source=>'TITEL'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(3414144407257820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2684483481332686839)
,p_name=>'P165_TOOLTIP'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(370183963181936078)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Tooltip'
,p_source=>'TOOLTIP'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>1000
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2684483887959686839)
,p_name=>'P165_HILFETEXT'
,p_data_type=>'CLOB'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(370184135247936079)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Help Text Box German'
,p_source=>'HILFETEXT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_custom_html', 'Y',
  'format', 'HTML',
  'min_height', '180',
  'toolbar', 'FULL',
  'toolbar_style', 'MULTILINE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2684484290929686839)
,p_name=>'P165_URL_VIDEO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(370183963181936078)
,p_use_cache_before_default=>'NO'
,p_prompt=>'URL Video'
,p_source=>'URL_VIDEO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>1000
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1036495290142372575)
,p_validation_name=>'check referencies on Delete'
,p_validation_sequence=>10
,p_validation=>'SELECT * from t_Hilfe where  basiseintragid = :P165_HILFEID'
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>unistr('Dieser Basis Eintrag wird von anderen Hilfetexten referenziert und kann nicht gel\00F6scht werden')
,p_when_button_pressed=>wwv_flow_imp.id(2684479791427686763)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2684480430017686764)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2684480321431686764)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2684481211214686770)
,p_event_id=>wwv_flow_imp.id(2684480430017686764)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(370185221375936090)
,p_name=>'Change laender Filter'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P165_FILTER_LAENDERGRUPPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370185108807936089)
,p_event_id=>wwv_flow_imp.id(370185221375936090)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(370185026366936088)
,p_name=>'Enter im Laender Filter'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P165_FILTER_BLAND_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370184918103936087)
,p_event_id=>wwv_flow_imp.id(370185026366936088)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'loadLaenderShuttle();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(370183788121936076)
,p_name=>'Anzeigen wenn'
,p_event_sequence=>40
,p_condition_element=>'P165_BASISEINTRAGID'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370183654266936075)
,p_event_id=>wwv_flow_imp.id(370183788121936076)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(371689286955184633)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370182614261936064)
,p_event_id=>wwv_flow_imp.id(370183788121936076)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P165_BASISEINTRAG'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(370183565118936074)
,p_name=>'Changing'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P165_BASISEINTRAGID'
,p_condition_element=>'P165_BASISEINTRAGID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370183515293936073)
,p_event_id=>wwv_flow_imp.id(370183565118936074)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(371689286955184633)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370183276466936071)
,p_event_id=>wwv_flow_imp.id(370183565118936074)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P165_FILTER_BLAND,P165_BASISEINTRAG'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370182441821936063)
,p_event_id=>wwv_flow_imp.id(370183565118936074)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P165_BASISEINTRAG'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370183371321936072)
,p_event_id=>wwv_flow_imp.id(370183565118936074)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(371689286955184633)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370182343300936062)
,p_event_id=>wwv_flow_imp.id(370183565118936074)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P165_BASISEINTRAG'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(370184630436936084)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'load Rowid'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (:P165_ROWID is null and :P165_HILFEID is not null)',
'then',
'select rowid into :P165_ROWID from T_HILFE where hilfeid = :P165_HILFEID;',
'  --debug(''page 165: loadrowid'', ''rowid:''|| :P125_ROWID);',
'elsif (:P125_ROWID is not null and :P165_HILFEID is  null) then',
'  --debug(''page 165: loadrowid'', ''rowid:''|| :P125_ROWID);',
'select hilfeid into :P165_HILFEID from T_HILFE where rowid = :P165_ROWID ;',
'',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3302027685462452151
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2684485114505686842)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_HILFE'
,p_attribute_02=>'T_HILFE'
,p_attribute_03=>'P165_ROWID'
,p_attribute_04=>'ROWID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6356697430405075077
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(370183202424936070)
,p_process_sequence=>30
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add landerspezifisch'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'',
'  l_spec_help varchar2(1000);',
'begin',
'  if (:P165_BASISEINTRAGID is not null) then',
'     select hilfetext into :P165_BASISEINTRAG from  t_hilfe where hilfeid = :P165_BASISEINTRAGID;',
'    -- select  --:P165_HILFETEXT ||'' <br>  specifische hilfe <br><br>''|| ',
'    -- l_spec_help  into :P165_BASISEINTRAG from dual; ',
'',
'  end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3302029113474452165
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(370184757793936086)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process_Row of Hilfe'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_sqlcode varchar2(32);',
'    l_err_msg varchar2(200);',
'    e_user_def EXCEPTION;',
'    PRAGMA exception_init( e_user_def, -20101 );',
'begin',
'if (:REQUEST = ''CREATE'') then -- neue Hilfe anlegen',
'       -- debug(''page 165: insert Hilfe'', '''');',
'        insert into T_HILFE ( titel, Tooltip, hilfetext, URL_Video, BASISEINTRAGID',
'               )',
'            VALUES( :P165_TITEL, :P165_TOOLTIP, :P165_HILFETEXT, :P165_URL_VIDEO , :P165_BASISEINTRAGID',
'        ) returning rowid, hilfeid into :P165_ROWID, :P165_HILFEID;',
'        ',
'  elsif (:REQUEST = ''SAVE'') then',
'       -- debug(''page 165: update Norm'', ''rowid:''|| :P165_ROWID);',
'        UPDATE t_HILFE SET',
'             titel = :P165_TITEL, ',
'             Tooltip = :P165_TOOLTIP,',
'             hilfetext = :P165_HILFETEXT, ',
'            URL_Video = :P165_URL_VIDEO,',
'            BASISEINTRAGID = :P165_BASISEINTRAGID',
'        WHERE rowid = :P165_ROWID;',
'  end if;',
'  --Exception when OTHERS then',
'   --      l_sqlcode := sqlcode;',
'   --     l_err_msg := SUBSTR(SQLERRM, 1, 180);',
'    --       debug(''except: pag 165, Process_Row, code:''|| l_sqlcode, ''msg:''||l_err_msg);',
'    --     raise e_user_def;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE, SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_internal_uid=>3302027558105452149
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(370184643761936085)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Aktualisiere Laender'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_hilfeid number;',
'begin',
'    l_hilfeid := :P165_HILFEID;',
'    -- neue Konzern_Cluster einfuegen',
'    merge into t_HILFE_ref_LAND dest',
'    using (select l_hilfeid as hilfeid, column_value as landid from table(APEX_STRING.split_numbers(:P165_FILTER_BLAND, '':''))) src',
'    on (src.hilfeid = dest.hilfeid ',
'       and src.landid = dest.landid)',
'    when not matched then',
'    insert (hilfeid, landid)',
'    values (src.hilfeid, src.landid);',
'    ',
'    -- entfernte laender loeschen',
'    delete from t_hilfe_ref_land rl',
'     where rl.hilfeid = l_hilfeid',
'       and rl.landid not in (select column_value from table(APEX_STRING.split_numbers(:P165_FILTER_BLAND, '':'')));',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE, SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_internal_uid=>3302027672137452150
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(370184175931936080)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete_Hilfe'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from t_hilfe_ref_land where hilfeid =:P165_HILFEID;',
'delete from T_HILFE where rowid = :P165_ROWID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2684479791427686763)
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_internal_uid=>3302028139967452155
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2684485933959686843)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2684479791427686763)
,p_internal_uid=>6356698249859075078
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2684486355828686843)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>6356698671728075078
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(848081915051850993)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(2684479195858686759)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Hilfstext bearbeiten'
,p_internal_uid=>2824130400847537242
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(370184246913936081)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLaenderShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lLaendergruppe varchar2(2000) := apex_application.g_x02;',
'    lTextfilter varchar2(2000) := apex_application.g_x03;',
'    --include_Land_inaktDaten number := apex_application.g_x04; -- visible with switsch (ON) for VKO & FachAdm',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    for l in (',
'        select b_nummer || '' - '' || CASE ',
'    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'    ELSE land_eng',
'END as d, landid',
'        from t_land',
'        where landid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))        ',
'        and (',
'            lLaendergruppe is null',
'            or landid in (',
'                select landid from t_land_ref_laendergruppe where laendergruppeid in (',
'                    select column_value from table(apex_string.split_numbers(lLaendergruppe,'':''))',
'                )',
'            )',
'        )',
'        and (',
'            lTextfilter is null',
'            or instr(upper(b_nummer),upper(lTextFilter)) != 0',
'            or instr(upper(land),upper(lTextFilter)) != 0',
'        )',
'        --and (--status_datenstand <> 0 and include_Land_inaktDaten=0 OR',
'            -- include_Land_inaktDaten=1 )',
'        order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'')        ',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.landid);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>3302028068985452154
);
wwv_flow_imp.component_end;
end;
/
