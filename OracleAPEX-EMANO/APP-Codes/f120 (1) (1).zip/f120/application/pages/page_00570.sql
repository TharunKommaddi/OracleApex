prompt --application/pages/page_00570
begin
--   Manifest
--     PAGE: 00570
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>570
,p_name=>'MfV Typ'
,p_alias=>'MFV-TYP1'
,p_page_mode=>'MODAL'
,p_step_title=>'MfV Typ'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_dialog_width=>'1000'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10107134273708627822)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(637561291400734979)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10107134380240627822)
,p_plug_name=>'Mfv Typ'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10107134515279627822)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1006048528928086917)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10107134515279627822)
,p_button_name=>'BACK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1006048156199086917)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10107134515279627822)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1006047764681086917)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(10107134515279627822)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Arbeitskreise'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1006045558609086915)
,p_branch_name=>'Go To Page 571'
,p_branch_action=>'f?p=&APP_ID.:571:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1006047764681086917)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1006045940013086915)
,p_branch_name=>'Go To Page 582'
,p_branch_action=>'f?p=&APP_ID.:582:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1006048528928086917)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006049216040086918)
,p_name=>'P570_MFV_TYP'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10107134380240627822)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_result NUMBER;',
'BEGIN',
'    -- If cloning, get MfV Teil from source ticket',
'    IF :P581_IS_CLONE = 1 AND :P581_CLONE_SOURCE_TICKET IS NOT NULL THEN',
'        SELECT NVL(teil, 1)',
'        INTO l_result',
'        FROM t_mfv_ref_mfv_teil tr',
'        JOIN t_mfv_teil tm ON (tr.mfv_teilid = tm.mfv_teilid)',
'        JOIN t_mfv tmfv ON (tr.mfvid = tmfv.mfvid)',
'        WHERE tmfv.jira_ticket = :P581_CLONE_SOURCE_TICKET',
'        FETCH FIRST 1 ROWS ONLY;',
'    ELSE',
'        -- Normal mode: get from previous MfV if selected',
'        SELECT NVL(teil, 1)',
'        INTO l_result',
'        FROM t_mfv_ref_mfv_teil tr',
'        JOIN t_mfv_teil tm ON (tr.mfv_teilid = tm.mfv_teilid)',
'        WHERE tr.mfvid = :P581_MFVS',
'        FETCH FIRST 1 ROWS ONLY;',
'    END IF;',
'    ',
'    RETURN l_result;',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        RETURN 1; -- Default to Information',
'END;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'MfV Typ'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Information;1,Interpretation;2'
,p_read_only_when=>'P581_IS_CLONE'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select NVL(teil,1) from t_mfv_ref_mfv_teil tr join t_mfv_teil tm on (tr.mfv_teilid = tm.mfv_teilid)',
'where tr.mfvid =',
':P581_MFVS',
'fetch first 1 rows only'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(916342659098945406)
,p_name=>'P570_CLONE_INFO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10107134380240627822)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT emano_util.fLang(',
unistr('    ''Dieser Wert wurde aus dem Quellticket '' || :P581_CLONE_SOURCE_TICKET || '' \00FCbernommen.'','),
'    ''This value was taken from source ticket '' || :P581_CLONE_SOURCE_TICKET || ''.''',
') as lang',
'FROM dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P581_IS_CLONE'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1006047305430086916)
,p_validation_name=>'Validation for choosing'
,p_validation_sequence=>10
,p_validation=>'P570_MFV_TYP'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'MfV Typ muss einen Wert haben'
,p_when_button_pressed=>wwv_flow_imp.id(1006047764681086917)
,p_associated_item=>wwv_flow_imp.id(1006049216040086918)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1006046931048086916)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1006048156199086917)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006046504328086916)
,p_event_id=>wwv_flow_imp.id(1006046931048086916)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp.component_end;
end;
/
