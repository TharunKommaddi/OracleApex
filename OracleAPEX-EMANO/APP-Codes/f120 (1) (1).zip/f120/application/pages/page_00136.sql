prompt --application/pages/page_00136
begin
--   Manifest
--     PAGE: 00136
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>136
,p_name=>'Besonderheiten Markt'
,p_alias=>'BESONDERHEITEN-MARKT'
,p_page_mode=>'MODAL'
,p_step_title=>'Besonderheiten Markt'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'dt:not(:first-of-type), dd:not(:first-of-type) {',
'    border-top: 1px solid grey;',
'}'))
,p_step_template=>wwv_flow_imp.id(3414111602455820538)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1003881946071808383)
,p_name=>'Besonderheiten Markt'
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select LAND,',
'       regexp_replace(apex_escape.html(BESONDERHEITEN), '''' || chr(10) || ''?'' || chr(13), ''<br />'') as BESONDERHEITEN',
'  from T_LAND',
' where landid IN (select column_value from table(apex_string.split_numbers(:P136_LAENDER, '':'')))',
'     and BESONDERHEITEN is not null',
'ORDER BY B_NUMMER asc;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P136_LAENDER'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414134944261820557)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1003881577941808379)
,p_query_column_id=>1
,p_column_alias=>'LAND'
,p_column_display_sequence=>1
,p_column_heading=>'Land'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1003880159240808365)
,p_query_column_id=>2
,p_column_alias=>'BESONDERHEITEN'
,p_column_display_sequence=>2
,p_column_heading=>'Besonderheiten'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1003881842600808382)
,p_name=>'P136_LAENDER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1003881946071808383)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
