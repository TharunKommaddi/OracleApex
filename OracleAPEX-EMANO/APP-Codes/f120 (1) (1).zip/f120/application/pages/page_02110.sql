prompt --application/pages/page_02110
begin
--   Manifest
--     PAGE: 02110
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>2110
,p_name=>'Tableau-View'
,p_alias=>'TABLEAU-VIEW'
,p_step_title=>'Tableau-View'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(988067241632880395)
,p_plug_name=>'&nbsp;'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Auf dieser Seite k\00F6nnen Sie den potentiellen Fehler als i.O gepr\00FCft markieren. <br>'),
unistr('Dies bedeutet, dass wir den Fehlercode im Dashboard ignorieren bis zur n\00E4chsten \00C4nderung der Vorschrift. <br>'),
unistr('Den Kommentar k\00F6nnen Sie auf einem separaten Dashboard in Power BI einsehen. In RegIndex wird dieser Kommentar nur im Free VKO Report ausgegeben.')))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(687433262680921457)
,p_plug_name=>'Werte der Vorschrift'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(684046827882613903)
,p_plug_name=>'Erstellung einer Testseite'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(684046463579613900)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(684046827882613903)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(682180052480328079)
,p_branch_name=>'Go To Page 25'
,p_branch_action=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:&P2110_VORSCHRIFTID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(3095365207235678228)
,p_branch_name=>'Go To Page 1000'
,p_branch_action=>'f?p=&APP_ID.:1000:&SESSION.::&DEBUG.:1000::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>':P2110_VORSCHRIFTID is null'
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988067156546880394)
,p_name=>'P2110_KOMMENTAR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(684046827882613903)
,p_prompt=>'Kommentar'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>150
,p_cMaxlength=>2999
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(687433181477921456)
,p_name=>'P2110_ATTRIBUT_INHALTLICH_SACHLICH_GEPRUEFT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(687433262680921457)
,p_prompt=>unistr('Attribut Inhaltlich Sachlich Gepr\00FCft')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>unistr('STATIC:nicht gepr\00FCft;10,n.i.O gepr\00FCft;20,i.O gepr\00FCft;30')
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(687433106390921455)
,p_name=>'P2110_PERMALINK'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(687433262680921457)
,p_prompt=>'Permalink'
,p_source=>'PCK_RI.fCreatePermalinkUrl(:P2110_VORSCHRIFTID)'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(684046639338613902)
,p_name=>'P2110_VORSCHRIFTEN_NUMMER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(684046827882613903)
,p_prompt=>'Vorschriften Nummer'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(682415051255434203)
,p_name=>'P2110_VORSCHRIFTID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(687433262680921457)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(682331476559509901)
,p_name=>'P2110_KIPPSCHALTER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(684046827882613903)
,p_prompt=>unistr('Kippschalter inhaltlich sachlich gepr\00FCft')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>unistr('STATIC2:nicht gepr\00FCft;10,n.i.O gepr\00FCft;20,i.O gepr\00FCft;30')
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(682180161099328080)
,p_name=>'P2110_NEW'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(684046827882613903)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    VORSCHRIFTID || '', '' || VORSCHRIFT_NUMMER || '', '' || INHALTLICH_SACHLICH_GEPRUEFT AS comma_separated_values',
'FROM ',
'    t_vorschrift',
'WHERE  --2563;',
'    VORSCHRIFTID = :P2110_VORSCHRIFTID;'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(682331647416509903)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UPDATE_INHALTLICH_SACHLICH_GEPRUEFT_SWITCH'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Update the table with the switch value',
'    UPDATE t_vorschrift',
'    SET inhaltlich_sachlich_geprueft = :P2110_KIPPSCHALTER,',
'        KOMMENTAR_INHALTLICH_SACHLICH_GEPRUEFT = :P2110_KOMMENTAR',
'    WHERE VORSCHRIFTID = :P2110_VORSCHRIFTID; --2563;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(684046463579613900)
,p_internal_uid=>2989880668482878332
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(682331587910509902)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Retrieve Vorschrift Details'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'--   IF :P2110_VORSCHRIFTID IS NOT NULL THEN',
'    SELECT',
'    VORSCHRIFT_NUMMER,',
'    --case when INHALTLICH_SACHLICH_GEPRUEFT =10 then 20 else INHALTLICH_SACHLICH_GEPRUEFT end ',
'    INHALTLICH_SACHLICH_GEPRUEFT,',
'    INHALTLICH_SACHLICH_GEPRUEFT,',
'    KOMMENTAR_INHALTLICH_SACHLICH_GEPRUEFT     ',
'    INTO',
'    :P2110_VORSCHRIFTEN_NUMMER,',
'    :P2110_KIPPSCHALTER,',
'    :P2110_ATTRIBUT_INHALTLICH_SACHLICH_GEPRUEFT,',
'    :P2110_KOMMENTAR ',
'    FROM t_vorschrift ',
'    WHERE VORSCHRIFTID = :P2110_VORSCHRIFTID; -- 2563; -- 3785 ',
'--   END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2989880727988878333
);
wwv_flow_imp.component_end;
end;
/
