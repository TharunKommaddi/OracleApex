prompt --application/pages/page_00481
begin
--   Manifest
--     PAGE: 00481
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>481
,p_name=>unistr('\00DCbergangsbestimmung')
,p_alias=>unistr('\00DCBERGANGSBESTIMMUNG')
,p_step_title=>unistr('\00DCbergangsbestimmung')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// function setCellBackground() {',
'//     $("span[bg-style]").each(function() {',
'//         $(this).parent().addClass($(this).attr(''bg-style''));',
'//     });',
'// }',
'',
'',
'function setCellBackground() {',
'    ',
'    $("span[bg-style]").each(function() {',
'        var bgColor = $(this).attr(''bg-style'');',
'        ',
'        $(this).parent().css("background-color", bgColor);',
'        $(this).parent().css("font-weight", "bold");',
'    });',
'}'))
,p_javascript_code_onload=>'setCellBackground();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.lightgreen {',
'    background-color: #8fe6f5 !important;',
'    color: black !important;',
'}',
'.brown {',
'    background-color: brown !important;',
'    color: black !important;',
'}',
'.yellow {',
'    background-color: yellow !important;',
'    color: black !important;',
'}',
'',
'.pink {',
'    background-color: pink !important;',
'    color: black !important;',
'}',
'',
'.gray {',
'    background-color: gray !important;',
'    color: black !important;',
'}',
'.orange {',
'    background-color: orange !important;',
'    color: black !important;',
'}',
'.red {',
'    background-color: red !important;',
'    color: black !important;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2054363828285579820)
,p_plug_name=>unistr('\00DCbergangsbestimmung')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_nop as (',
'    select ''1'' as blink, UEBERGANGSBESTIMMUNGID,',
'       NOP,                                         -- NO. kommt aus Rahmenverordnung',
'        SUBJECT,                        -- kommt aus Rahmenverordnung',
'       VORSCHRIFT_RRID,                   -- rahmenrichtlin Id       (invisible)',
'       VORSCHRIFT_UNRID,                         -- regulatoryacts    nr',
'       trunc(vre.einsatzdatum) as in_kraftsetzung,',
'       u.VORSCHRIFT_AENDERUNGID,         ----- regulatory_acts',
'       VORSCHRIFT_SERIE_UNRID, ',
'       OJ_REFERENCE as OJ_REFERENCE,',
'       APPLICABILITY as  Applicability_M1,',
'         -- case  when u.VORSCHRIFT_AENDERUNGID is not null  then  uf.farbe --hg_color  ',
'        --  else null end  ',
'        hg_color as  cell_class,  -- (invisible)',
'        DATUM_NT,',
'       DATUM_OT,',
'       REMARKS,',
'       END_OF_SERIES,              --13',
'       DATUM_AUSLAUFENDE_SERIE,     --14',
'       DATUM_NICHT_MEHR_ANWENDBAR,   --15',
'       ADDITIONAL_COMMENTS,              -- 16 ',
'       ADDITIONAL_SPECIFIC_TECHNICAL_PROVISIONS,',
'       hg_color as NOP_Farbe',
'     from T_UEBERGANGSBESTIMMUNG u',
'  left outer join T_VORSCHRIFT_REF_EINSATZDATUM_TYP vre on (u.VORSCHRIFT_AENDERUNGID = vre.vorschriftid and vre.einsatzdatum_typid = 1000)',
'  --left outer join T_UEBERGANGSBESTIMMUNG_FARBE uf on (uf.VORSCHRIFT_AENDERUNGID = u.VORSCHRIFT_AENDERUNGID )',
'   where ',
'        ( pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') >0) ',
'        OR (  nvl(vre.einsatzdatum, null) < sysdate ) -- for all user',
' )',
'  select cte_nop.*, row_number() over (order by substr(cte_nop.nop,1,1), to_number(substr(cte_nop.nop,2))) as sortorder',
'  ',
'  from cte_nop',
' /*ORDER by  NLSSORT(substr(cte_nop.NOP, 1,1),''NLS_SORT=GERMAN'') asc',
'            , NLSSORT(length(cte_nop.NOP), ''NLS_SORT=BINARY_AI'')  asc ',
'            ,  NLSSORT(substr(cte_nop.NOP, 2), ''NLS_SORT=BINARY_AI'')  asc*/'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('\00DCbergangsbestimmung')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(4189515530369900669)
,p_max_row_count=>'10000'
,p_max_row_count_message=>'Keine Daten gefunden'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>7861727846269288904
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048887148307305902)
,p_db_column_name=>'BLINK'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:486:&SESSION.::&DEBUG.::P486_UEBERGANGSBESTIMMUNGID,P486_INKRAFTSETZUNG_AMENDMENT,P486_NOP_FARBE:#UEBERGANGSBESTIMMUNGID#,#IN_KRAFTSETZUNG#,#NOP_FARBE#'
,p_column_linktext=>'<span class="fa fa-edit" aria-hidden="true"></span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048886718053305901)
,p_db_column_name=>'UEBERGANGSBESTIMMUNGID'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Uebergangsbestimmungid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048893482516305909)
,p_db_column_name=>'NOP'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Nr.'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!--td class="u-tL" style="background-color:#CELL_CLASS#;font-weight:bold;">#NOP#</td-->',
'<!-- <span style="background-color:#CELL_CLASS#;font-weight:bold;">#NOP#</span>  -->',
'',
'',
'<span bg-style="#CELL_CLASS#">#NOP#</span>',
'<!--span bg-style="#CELL_CLASS#">#NOP#</span-->'))
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048892658590305908)
,p_db_column_name=>'SUBJECT'
,p_display_order=>60
,p_column_identifier=>'H'
,p_column_label=>'Gegenstand'
,p_column_html_expression=>'<div style="display:block; width:200px">#SUBJECT#</div>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048886368208305900)
,p_db_column_name=>'VORSCHRIFT_RRID'
,p_display_order=>70
,p_column_identifier=>'C'
,p_column_label=>'Rahmenverordnung-/rechtsakt'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(1031670891478091972)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048893895320305911)
,p_db_column_name=>'VORSCHRIFT_UNRID'
,p_display_order=>80
,p_column_identifier=>'E'
,p_column_label=>unistr('Rechtsakt mit \00DCbergangsbestimmungen')
,p_column_html_expression=>'<div style="display:block; width:300px">#VORSCHRIFT_UNRID#</div>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(2642128612516763789)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048893113632305908)
,p_db_column_name=>'IN_KRAFTSETZUNG'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>unistr('Einsatzdatum der \00C4nderungsvorschrift der Rahmenverordnung/des Rahmenrechtsaktes')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048885983572305900)
,p_db_column_name=>'VORSCHRIFT_AENDERUNGID'
,p_display_order=>100
,p_column_identifier=>'D'
,p_column_label=>unistr('\00C4nderungsvorschrift der Rahmenverordnung/des Rahmenrechtsaktes')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(1031670891478091972)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1034411388062783734)
,p_db_column_name=>'VORSCHRIFT_SERIE_UNRID'
,p_display_order=>110
,p_column_identifier=>'V'
,p_column_label=>'Rechtsakt, welcher bis zum Datum der auslaufenden Serie verwendet werden darf'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(1031670891478091972)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048892252471305907)
,p_db_column_name=>'OJ_REFERENCE'
,p_display_order=>120
,p_column_identifier=>'I'
,p_column_label=>'Allgemeine Sicherheitsverordnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048888305012305903)
,p_db_column_name=>'APPLICABILITY_M1'
,p_display_order=>130
,p_column_identifier=>'T'
,p_column_label=>'Anwendbar auf M1 (Einsatzszenario)'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048891856061305907)
,p_db_column_name=>'CELL_CLASS'
,p_display_order=>140
,p_column_identifier=>'K'
,p_column_label=>'Cell Class'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048891112561305906)
,p_db_column_name=>'DATUM_NT'
,p_display_order=>150
,p_column_identifier=>'M'
,p_column_label=>'Anwendbar ab (M1 NT)'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048890665817305906)
,p_db_column_name=>'DATUM_OT'
,p_display_order=>160
,p_column_identifier=>'N'
,p_column_label=>'Anwendbar ab (M1 AT)'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048890243928305906)
,p_db_column_name=>'REMARKS'
,p_display_order=>170
,p_column_identifier=>'O'
,p_column_label=>'Anmerkungen zum Rechtsakt'
,p_column_html_expression=>'<div style="display:block; width:200px">#REMARKS#</div>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048889816915305905)
,p_db_column_name=>'END_OF_SERIES'
,p_display_order=>180
,p_column_identifier=>'P'
,p_column_label=>unistr('\00C4nderungsvorschrift der allgemeinen Sicherheitsverordnung')
,p_column_html_expression=>'<div style="display:block; width:200px">#END_OF_SERIES#</div>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048889515807305905)
,p_db_column_name=>'ADDITIONAL_COMMENTS'
,p_display_order=>190
,p_column_identifier=>'Q'
,p_column_label=>unistr('Zus\00E4tzliche Anmerkungen zur auslaufende Serie ')
,p_column_html_expression=>'<div style="display:block; width:300px">#ADDITIONAL_COMMENTS#</div>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048889031160305905)
,p_db_column_name=>'DATUM_AUSLAUFENDE_SERIE'
,p_display_order=>200
,p_column_identifier=>'R'
,p_column_label=>'Datum der auslaufenden Serie'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048888627129305903)
,p_db_column_name=>'DATUM_NICHT_MEHR_ANWENDBAR'
,p_display_order=>210
,p_column_identifier=>'S'
,p_column_label=>unistr('Einsatzdatum der \00C4nderungsvorschrift der allgemeinen Sicherheitsverordnung')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048891509009305907)
,p_db_column_name=>'ADDITIONAL_SPECIFIC_TECHNICAL_PROVISIONS'
,p_display_order=>220
,p_column_identifier=>'L'
,p_column_label=>unistr('Zus\00E4tzliche spezifische technische Anforderungen')
,p_column_html_expression=>'<div style="display:block; width:300px">#ADDITIONAL_SPECIFIC_TECHNICAL_PROVISIONS#</div>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048887614357305902)
,p_db_column_name=>'NOP_FARBE'
,p_display_order=>230
,p_column_identifier=>'U'
,p_column_label=>'Nop Farbe'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3136214829125152427)
,p_db_column_name=>'SORTORDER'
,p_display_order=>240
,p_column_identifier=>'W'
,p_column_label=>'Sortorder'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2098052088686848694)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5236566'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BLINK:VORSCHRIFT_RRID:VORSCHRIFT_AENDERUNGID:IN_KRAFTSETZUNG:OJ_REFERENCE:END_OF_SERIES:DATUM_NICHT_MEHR_ANWENDBAR:NOP:SUBJECT:VORSCHRIFT_UNRID:APPLICABILITY_M1:DATUM_NT:DATUM_OT:ADDITIONAL_SPECIFIC_TECHNICAL_PROVISIONS:REMARKS:VORSCHRIFT_SERIE_UNRID'
||':DATUM_AUSLAUFENDE_SERIE:ADDITIONAL_COMMENTS:'
,p_sort_column_1=>'SORTORDER'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3148580543083251412)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2054363828285579820)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Erstellen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:486:&SESSION.::&DEBUG.:486::'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1048884208897305860)
,p_name=>'After refresh'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2054363828285579820)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1048883690361305859)
,p_event_id=>wwv_flow_imp.id(1048884208897305860)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'setCellBackground();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1048884962655305865)
,p_name=>'Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2054363828285579820)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1048884610832305860)
,p_event_id=>wwv_flow_imp.id(1048884962655305865)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2054363828285579820)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
