prompt --application/pages/page_00275
begin
--   Manifest
--     PAGE: 00275
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>275
,p_name=>'Erstellen/Bearbeiten Norm Prefix'
,p_alias=>'EDIT-NORM-SUFFIX1'
,p_page_mode=>'MODAL'
,p_step_title=>'Erstellen/Bearbeiten Norm Prefix'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1595820428604745753)
,p_plug_name=>'Form on T_GETEX_MAPPING_NORM'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7923266313679246984)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1037126507154627472)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(7923266313679246984)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1037126099311627471)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(7923266313679246984)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_redirect_url=>unistr('javascript:apex.confirm(''Soll die Getex Mapping Norm gel\00F6scht werden?'',''DELETE'');')
,p_button_execute_validations=>'N'
,p_button_condition=>'P275_GETEX_MAPPING_NORMID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1037125629176627471)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(7923266313679246984)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_condition=>'P275_GETEX_MAPPING_NORMID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1037125263153627471)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(7923266313679246984)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_condition=>'P275_GETEX_MAPPING_NORMID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1039264197525015003)
,p_name=>'P275_LETZTE_AENDERUNG_DATUM'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1595820428604745753)
,p_prompt=>unistr('Letzte \00C4nderung Datum')
,p_format_mask=>'DD.MM.YYYY HH24:MI:SS'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P275_GETEX_MAPPING_NORMID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1039264070932015002)
,p_name=>'P275_LETZTE_AENDERUNG_BENUTZERID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(1595820428604745753)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037124459241627470)
,p_name=>'P275_GETEX_MAPPING_NORMID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1595820428604745753)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037124013332627467)
,p_name=>'P275_PREFIX'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1595820428604745753)
,p_prompt=>'Prefix'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1036080532294328224)
,p_name=>'P275_LETZTE_AENDERUNG_BENUTZERID_PLACEHOLDER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(1595820428604745753)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Letzte \00C4nderung Benutzer')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NACHNAME || '', '' || VORNAME ',
'FROM T_BENUTZER ',
'WHERE BENUTZERID = :P275_LETZTE_AENDERUNG_BENUTZERID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P275_GETEX_MAPPING_NORMID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1037123228717627466)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1037126507154627472)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1037122732928627466)
,p_event_id=>wwv_flow_imp.id(1037123228717627466)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1039263765671014999)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Insert Row in T_GETEX_MAPPING_NORM'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Process for INSERT operation on T_GETEX_MAPPING_NORM',
'BEGIN',
'  IF :REQUEST = ''CREATE'' THEN',
'    INSERT INTO T_GETEX_MAPPING_NORM (',
'      PREFIX,',
'      LETZTE_AENDERUNG_DATUM,',
'      LETZTE_AENDERUNG_BENUTZERID',
'    ) VALUES (',
'      :P275_PREFIX,',
'      SYSDATE,',
'      :G_BENUTZERID',
'    )',
'    RETURNING GETEX_MAPPING_NORMID INTO :P275_GETEX_MAPPING_NORMID;',
'  END IF;',
'EXCEPTION',
'  WHEN OTHERS THEN',
'    apex_error.add_error(',
'      p_message => ''Fehler beim Erstellen: '' || SQLERRM,',
'      p_display_location => apex_error.c_inline_in_notification',
'    );',
'    RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2632948550228373236
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1039263624764014998)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update Row in T_GETEX_MAPPING_NORM'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Process for UPDATE operation on T_GETEX_MAPPING_NORM',
'BEGIN',
'  IF :REQUEST = ''SAVE'' THEN',
'    UPDATE T_GETEX_MAPPING_NORM',
'    SET PREFIX = :P275_PREFIX,',
'        LETZTE_AENDERUNG_DATUM = SYSDATE,',
'        LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'    WHERE GETEX_MAPPING_NORMID = :P275_GETEX_MAPPING_NORMID;',
'  END IF;',
'EXCEPTION',
'  WHEN OTHERS THEN',
'    apex_error.add_error(',
'      p_message => ''Fehler beim Aktualisieren: '' || SQLERRM,',
'      p_display_location => apex_error.c_inline_in_notification',
'    );',
'    RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>',,,,,,,,,'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'mm,,m'
,p_internal_uid=>2632948691135373237
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1039263565408014997)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete Row from T_GETEX_MAPPING_NORM'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Process for DELETE operation on T_GETEX_MAPPING_NORM',
'BEGIN',
'  IF :REQUEST = ''DELETE'' THEN',
'    DELETE FROM T_GETEX_MAPPING_NORM',
'    WHERE GETEX_MAPPING_NORMID = :P275_GETEX_MAPPING_NORMID;',
'  END IF;',
'EXCEPTION',
'  WHEN OTHERS THEN',
'    apex_error.add_error(',
unistr('      p_message => ''Fehler beim L\00F6schen: '' || SQLERRM,'),
'      p_display_location => apex_error.c_inline_in_notification',
'    );',
'    RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2632948750491373238
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1037123587562627467)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2635088728336760768
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1039263843787015000)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'FETCH ROW FROM T_GETEX_MAPPING_NORM'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Process for fetching row from T_GETEX_MAPPING_NORM',
'BEGIN',
'  IF :P275_GETEX_MAPPING_NORMID IS NOT NULL THEN',
'    SELECT ',
'      GETEX_MAPPING_NORMID,',
'      PREFIX,',
'      LETZTE_AENDERUNG_DATUM,',
'      LETZTE_AENDERUNG_BENUTZERID',
'    INTO ',
'      :P275_GETEX_MAPPING_NORMID,',
'      :P275_PREFIX,',
'      :P275_LETZTE_AENDERUNG_DATUM,',
'      :P275_LETZTE_AENDERUNG_BENUTZERID',
'    FROM T_GETEX_MAPPING_NORM',
'    WHERE GETEX_MAPPING_NORMID = :P275_GETEX_MAPPING_NORMID;',
'  END IF;',
'EXCEPTION',
'  WHEN NO_DATA_FOUND THEN',
'    apex_error.add_error(',
'      p_message => ''Datensatz nicht gefunden'',',
'      p_display_location => apex_error.c_inline_in_notification',
'    );',
'    :P275_GETEX_MAPPING_NORMID := NULL;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2632948472112373235
);
wwv_flow_imp.component_end;
end;
/
