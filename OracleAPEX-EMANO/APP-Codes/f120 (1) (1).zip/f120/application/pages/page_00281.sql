prompt --application/pages/page_00281
begin
--   Manifest
--     PAGE: 00281
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>281
,p_name=>unistr('LRSA hinzuf\00FCgen  (Mehrfachauswahl)')
,p_alias=>unistr('LRSA-HINZUF\00DCGEN-MEHRFACHAUSWAHL')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('LRSA hinzuf\00FCgen  (Mehrfachauswahl)')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function getParentArray(n){',
'    var arr = [], ln = n;',
'    while (ln._parent !== null) arr.push(ln = ln._parent);',
'    return arr.reverse(); // in correct order',
'};',
'',
'function expandUpTo(aID) {',
'    if (aID == '''') return;',
'    var tree = $("#mytree div[role=''tree'']");',
'    ',
'    var arr = tree.treeView("getExpandedNodeIds");',
'    if (arr.indexOf(aID.toString()) != -1) {',
'        console.log(''skip!!!'');',
'        return;',
'    } ',
'    ',
'    ',
'    var treenode = tree.treeView("find", {',
'        depth: -1,',
'        findAll: false,',
'        match: function(n) {',
'            return n.id == aID;',
'        }',
'    });',
'',
'    var mnode = tree.treeView("getNodes",treenode);',
'',
'    try {',
'        getParentArray(mnode[0]).forEach(function(p){',
'            if (arr.indexOf(p.id.toString()) != -1) {',
'                throw BreakException;            ',
'            }',
'            tree.treeView("expand",tree.treeView("getTreeNode",p));',
'        });',
'    } catch (e) {',
'        null;',
'    }        ',
'}',
'',
'$(''#r_vo'').on(''click'', ''th input'', function() {',
'    var check_all = $("#r_vo").find("th input:checked").is(":checked");',
'',
'    $("#r_vo").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'});'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var tree$ = $("#mytree div[role=''tree'']"), // change this to use whatever id you give the tree',
'    nodeAdapter = tree$.treeView("getNodeAdapter");',
'',
'// Set a custom node renderer that adds a checkbox icon span',
'nodeAdapter.renderNodeContent = function( node, out, options, state ) {',
'    out.markup("<span class=''treeSelCheck''></span>"); // this is the checkbox - its not a real checkbox input',
'    // the rest of this code is essentially a copy of what is in widget.treeView.js function renderTreeNodeContent',
'    if ( this.getIcon ) {',
'        icon = this.getIcon( node );',
'        if ( icon !== null ) {',
'            out.markup( "<span" ).attr( "class", options.iconType + " " + icon ).markup( "></span>" );',
'        }',
'    }',
'    link = options.useLinks && this.getLink && this.getLink( node );',
'    if ( link ) {',
'        elementName = "a";',
'    } else {',
'        elementName = "span";',
'    }',
'    out.markup( "<" + elementName + " tabIndex=''-1'' role=''treeitem''" ).attr( "class",options.labelClass )',
'        .optionalAttr( "href", link )',
'        .attr( "aria-level", state.level )',
'        .attr( "aria-selected", state.selected ? "true" : "false" )',
'        .optionalAttr( "aria-disabled", state.disabled ? "true" : null )',
'        .optionalAttr( "aria-expanded", state.hasChildren === false ? null : state.expanded ? "true" : "false" )',
'        .markup( ">" )',
'        .content( this.getLabel( node ) )',
'        .markup( "</" + elementName + ">" );',
'',
'};',
'',
'',
'',
'// Standard Event Handler des Trees deaktivieren',
'tree$.off("click");',
'',
'tree$.treeView("option","multiple", true) // make the tree support multiple selection',
'    .treeView("refresh") // refresh so that all the nodes are redrawn with custom renderer',
'    .on("click", ".treeSelCheck", function(event) { // make that "checkbox" span control the selection',
'        var nodeContent$ = $(event.target).closest(".a-TreeView-content"),',
'            isSelected = nodeContent$.hasClass("is-selected"),',
'            selection$ = tree$.treeView("getSelection");',
'        if ( isSelected ) {',
'            selection$ = selection$.not(nodeContent$);',
'        } else {',
'            selection$ = selection$.add(nodeContent$);',
'        }',
'        tree$.treeView("setSelection", selection$);',
'        return false; // stop propagation and prevent default',
'    });',
'',
'tree$.on("click",".fa-level-down", function(event) {',
'    var nodeContent$ = $(event.target).closest(".a-TreeView-content"),',
'        isSelected = nodeContent$.hasClass("is-selected"),',
'        modelNode = tree$.treeView("getNodes",nodeContent$)[0],',
'        selection$ = tree$.treeView("getSelection");',
'    /*dynActionActive = false;',
'    if (isSelected) {',
'        toggleSubTree(modelNode,false);',
'    } else {        ',
'        toggleSubTree(modelNode,true);        ',
'    }',
'    dynActionActive = true;*/',
'    ',
'    tree$.treeView("expandAll",nodeContent$);',
'    if (isSelected) {',
'        selection$ = selection$.not($(event.target).parent().parent().find(''.a-TreeView-content''));',
'    } else {',
'        selection$ = selection$.add($(event.target).parent().parent().find(''.a-TreeView-content''));',
'    }',
'    tree$.treeView("setSelection", selection$);',
'    ',
'    ',
'    ',
'    ',
'    return false;',
'    ',
'});',
'',
'tree$.on("click",".a-TreeView-toggle", function(event) {',
'    var nodeContent$ = $(event.target).next(),',
'        treeNode = nodeContent$.parent(),',
'        isExpanded = treeNode.hasClass("is-collapsible");',
'    if (isExpanded) {',
'        //tree$.treeView("collapse",nodeContent$);    ',
'        treeNode.removeClass("is-collapsible").addClass("is-expandable").children(".a-TreeView-content").find(".a-TreeView-label").attr("aria-expanded", false );',
'        treeNode.children( "ul" ).hide();            ',
'    } else {',
'        tree$.treeView("expand",nodeContent$);  ',
'    ',
'    }',
'    return false; ',
'});',
'',
'var selected = $v("P281_SELECTED");',
'if (selected != "") {',
'    var splitSelected = $v("P281_SELECTED").split(":");',
'    if (splitSelected.length <= 100) {',
'        $v("P281_SELECTED").split(":").forEach(function(i) { expandUpTo(i) });  ',
'    } else {',
'        tree$.treeView("expandAll");',
'    }',
'    tree$.treeView("setSelectedNodes", $v("P281_SELECTED").split(":").map(function(i) { return { id: i }; }));       ',
'}'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* These are the same styles as fa */',
'.treeSelCheck {',
'    display: inline-block;',
'    font: normal normal normal 14px/1 "Font APEX Small";',
'    text-rendering: auto;',
'    width: 14px;',
'    margin-right: 4px;',
'    cursor: default;',
'    color: black;',
'}',
'',
'/* fa-square-o */',
'.treeSelCheck::before {',
unistr('    content: "\F096";'),
'}',
'',
'/* fa-check-square-o */',
'.is-selected > .treeSelCheck::before {',
unistr('    content: "\F046";'),
'}',
'',
'',
'.a-TreeView-row.is-selected {',
'    border-bottom: none !important;',
'    background-color: #f7f7f7 !important;',
'    color: black;',
'}',
'',
'.a-TreeView-content.is-selected .a-Icon, .a-TreeView-content.is-selected .a-TreeView-label {',
'    color: black;',
'}',
'.a-TreeView-row.is-selected+.a-TreeView-toggle {',
'    color: black;',
'}',
'',
'.a-TreeView-row.is-selected, .a-TreeView-row.is-selected.is-hover {',
'    ',
'}',
'',
'',
'',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2721698047943186423)
,p_plug_name=>'Dialog Footer'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2989241146337206379)
,p_plug_name=>'LRSA (Baumansicht)'
,p_region_name=>'mytree'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    lrsa_id, ',
'    parent_id,',
'    lrsa_nummer || '' - '' || bezeichnung as bezeichnung,',
'    ''javascript:$s("P281_SELECTED","'' || lrsa_id || ''")'' as link',
'from t_lrsa'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_JSTREE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'activate_node_link_with', 'S',
  'node_id_column', 'LRSA_ID',
  'node_label_column', 'BEZEICHNUNG',
  'node_value_column', 'LRSA_ID',
  'parent_key_column', 'PARENT_ID',
  'selected_node_page_item', 'P281_SELECTED',
  'start_tree_with', 'NULL',
  'tree_hierarchy', 'SQL',
  'tree_tooltip', 'N')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025598814267192823)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2989241146337206379)
,p_button_name=>'NO_PARENT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Ohne Parent'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P281_CAME_FROM'
,p_button_condition2=>'345'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025600708379192825)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2721698047943186423)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025600250107192825)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2721698047943186423)
,p_button_name=>'APPL2'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Zwischenspeichern'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025599816580192825)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2721698047943186423)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025599428381192825)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2721698047943186423)
,p_button_name=>'APPLY'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P281_CAME_FROM != 35 and :P281_CAME_FROM !=25'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025598363036192823)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2989241146337206379)
,p_button_name=>'RESET_V'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Zur\00FCcksetzung auf Zuordnungen zu Themengebiet')
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P281_CAME_FROM'
,p_button_condition2=>'25'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025598003027192823)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2989241146337206379)
,p_button_name=>'EXPAND'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Alle aufklappen'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025597545911192823)
,p_name=>'P281_THEMAID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2989241146337206379)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025597201828192822)
,p_name=>'P281_VORSCHRIFTID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2989241146337206379)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025596790369192822)
,p_name=>'P281_CAME_FROM'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2989241146337206379)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025596373148192822)
,p_name=>'P281_SELECTED'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2989241146337206379)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025595989016192822)
,p_name=>'P281_EXPIRED_AUS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2989241146337206379)
,p_item_default=>'1'
,p_prompt=>'Expired ausblenden'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', '1',
  'unchecked_value', '0',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025595553985192821)
,p_name=>'P281_SELECTED_RECURSIVE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(2989241146337206379)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025594012284192819)
,p_name=>'Close Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1025599428381192825)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025593485903192819)
,p_event_id=>wwv_flow_imp.id(1025594012284192819)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025593041658192819)
,p_name=>'Cancel Dialog'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1025600708379192825)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025592602279192818)
,p_event_id=>wwv_flow_imp.id(1025593041658192819)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025592121855192818)
,p_name=>'no parent'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1025598814267192823)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025591654152192818)
,p_event_id=>wwv_flow_imp.id(1025592121855192818)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P281_SELECTED'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025591292610192818)
,p_name=>'tree selection change'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2989241146337206379)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'treeviewselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025590794843192817)
,p_event_id=>wwv_flow_imp.id(1025591292610192818)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var nodes = $("#mytree div[role=''tree'']").treeView("getSelectedNodes");',
'$s("P281_SELECTED", nodes.map(function(n) {return n.id;}).join(":"));'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025590391635192817)
,p_name=>'Expand'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1025598003027192823)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025589857887192816)
,p_event_id=>wwv_flow_imp.id(1025590391635192817)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2989241146337206379)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025589500743192816)
,p_name=>'change'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P281_EXPIRED_AUS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025588919192192814)
,p_event_id=>wwv_flow_imp.id(1025589500743192816)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P281_EXPIRED_AUS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025588449164192814)
,p_event_id=>wwv_flow_imp.id(1025589500743192816)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2989241146337206379)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1025595198631192820)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Speichern LRSA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'debug(:P281_SELECTED);',
'',
'with cte_selected as (',
'        select distinct lrsa_id, column_value as vorgaenger',
'        from t_lrsa,',
'        apex_string.split_numbers(parent_id, '':'')',
'    ), ',
'    recursion_view(base, vorgaenger, lrsa_id) as (',
'       select vorgaenger base, ',
'        vorgaenger, ',
'        lrsa_id',
'      from cte_selected',
'      union all',
'      select',
'        previous_level.base,',
'        current_level.vorgaenger,',
'        current_level.lrsa_id',
'      from',
'        recursion_view previous_level,',
'        cte_selected current_level',
'      where',
'        current_level.vorgaenger = previous_level.lrsa_id',
'        --or previous_level.lrsa_id is null',
'    ),',
'    cte_parents as (',
'        select distinct ',
'         base as lrsa_id, lrsa_id as parent_id',
'        from recursion_view',
'        where lrsa_id in (select column_value from TABLE(apex_string.split_numbers(:P281_SELECTED, '':''))) ',
'        order by lrsa_id',
'    ),',
'    cte_alle as (',
'        select lrsa_id as base',
'        from cte_parents',
'       ',
'        union ',
'        select parent_id as base ',
'        from cte_parents',
'    )',
'    select LISTAGG (distinct base, '':'') into :P281_SELECTED_RECURSIVE ',
'    from cte_alle;',
'',
'update T_THEMA_REF_LRSA',
'set GELOESCHT = 10, LETZTE_AENDERUNG_DATUM = sysdate, LETZTE_AENDERUNG_BENUTZERID = pck_ri.fGetUserId',
'where THEMAID = :P281_THEMAID',
'and GELOESCHT = 20',
'and LRSAID not in (',
'    select column_value',
'    from table(apex_string.split_numbers(:P281_SELECTED_RECURSIVE,'':''))',
');',
'',
'update T_THEMA_REF_LRSA',
'set GELOESCHT = 20, LETZTE_AENDERUNG_DATUM = sysdate, LETZTE_AENDERUNG_BENUTZERID = pck_ri.fGetUserId',
'where THEMAID = :P281_THEMAID',
'and GELOESCHT = 10',
'and LRSAID in (',
'    select column_value',
'    from table(apex_string.split_numbers(:P281_SELECTED_RECURSIVE,'':''))',
');',
'insert into T_THEMA_REF_LRSA (',
'    THEMAID, LRSAID, LETZTE_AENDERUNG_BENUTZERID, LETZTE_AENDERUNG_DATUM',
')',
'with cte1 as (',
'    select column_value as LRSAID',
'    from table(apex_string.split_numbers(:P281_SELECTED_RECURSIVE,'':''))',
'',
')',
'select :P281_THEMAID, LRSAID, pck_ri.fGetUserId, sysdate',
'from cte1',
'where LRSAID not in (',
'    select LRSAID',
'    from T_THEMA_REF_LRSA',
'    where THEMAID = :P281_THEMAID',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1025599816580192825)
,p_internal_uid=>2646617117268195415
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1025594809585192820)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close dialog'
,p_attribute_01=>'P281_SELECTED_RECURSIVE'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2646617506314195415
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1025594359618192819)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Items setzen'
,p_process_sql_clob=>':P281_SELECTED := :P35_LRSAID;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2646617956281195416
);
wwv_flow_imp.component_end;
end;
/
