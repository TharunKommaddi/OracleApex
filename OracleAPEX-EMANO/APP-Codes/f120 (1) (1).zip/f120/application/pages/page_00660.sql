prompt --application/pages/page_00660
begin
--   Manifest
--     PAGE: 00660
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>660
,p_name=>'GETEX Bitmaske History'
,p_alias=>'GETEX-BITMASKE-HISTORY'
,p_step_title=>'GETEX Bitmaske History'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1957250765751387213)
,p_plug_name=>'Historische Daten'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1962937822864233026)
,p_name=>'Getex Vergleich: Historische Daten'
,p_parent_plug_id=>wwv_flow_imp.id(1957250765751387213)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- anzahl der Vorschrift mit DokumentenDat = abweichend je tag',
' with cte_h_Dokdat as ( select count( hv.vorschriftid) cou,  trunc(hv.Letzte_aenderung_Datum) datum -- to_timestamp(Letzte_aenderung_Datum ,''dd.mm.yyyy HH24:mi:SSFF3'')',
'             , t.GETEX_VERGLEICH_BITMASKE  bitmask',
'              from t_H_vorschrift hv',
'              join table( PCK_RI_GETEX_CTRL.fGetBitmaskHistory(vorschriftid,13) ) t on (t.Letzte_aenderung_Datum = hv.Letzte_aenderung_Datum)',
'              where nvl(t.GETEX_VERGLEICH_BITMASKE, -1)>0   and  letzte_aenderung_datum > sysdate - 1 - :P660_DAYS_BACK ',
'               group by  trunc(hv.letzte_aenderung_datum) , t.GETEX_VERGLEICH_BITMASKE',
'   ),',
'   cte_h_inKraft as ( select count( hv.vorschriftid) cou_2,  trunc(hv.Letzte_aenderung_Datum) datum -- to_timestamp(Letzte_aenderung_Datum ,''dd.mm.yyyy HH24:mi:SSFF3'')',
'             , t.GETEX_VERGLEICH_BITMASKE  bitmask',
'              from t_H_vorschrift hv',
'              join table( PCK_RI_GETEX_CTRL.fGetBitmaskHistory(vorschriftid,12) ) t on (t.Letzte_aenderung_Datum = hv.Letzte_aenderung_Datum)',
'              where nvl(t.GETEX_VERGLEICH_BITMASKE, -1)>0   and  letzte_aenderung_datum > sysdate - 1 - :P660_DAYS_BACK ',
'               group by  trunc(hv.letzte_aenderung_datum) , t.GETEX_VERGLEICH_BITMASKE',
'   ),',
'   cte_days as (',
'           select trunc(sysdate - xn.column_value) as datum  ',
'           from table ( apex_string.split_numbers(''0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30'', '','') ) xn',
'           where xn.column_value < :P660_DAYS_BACK',
'   )',
'    select  d.datum Datum,  nvl(h.cou,0) as "Anzahl Vorschriften mit abweichenden Einsatzdaten" ,',
'                           nvl(ik.cou_2,0) as "Anzahl Vorschriften mit abweichenden Inkraftsetzung"',
'    from cte_days d',
'     left outer join cte_h_Dokdat h  on (h.datum = d.datum   ) ',
'     left outer join cte_h_inKraft ik  on (ik.datum = d.datum   ) order by d.datum desc'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1098351124422463662)
,p_query_column_id=>1
,p_column_alias=>'DATUM'
,p_column_display_sequence=>1
,p_column_heading=>'Datum'
,p_column_alignment=>'CENTER'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1098350844739463661)
,p_query_column_id=>2
,p_column_alias=>'Anzahl Vorschriften mit abweichenden Einsatzdaten'
,p_column_display_sequence=>2
,p_column_heading=>'Anzahl der Vorschriften mit Abweichenden Einsatzdaten'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1098350432921463661)
,p_query_column_id=>3
,p_column_alias=>'Anzahl Vorschriften mit abweichenden Inkraftsetzung'
,p_column_display_sequence=>12
,p_column_heading=>'Anzahl Vorschriften Mit Abweichenden Inkraftsetzung'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1098351816390463675)
,p_name=>'P660_DAYS_BACK'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1957250765751387213)
,p_prompt=>unistr('Anzeige f\00FCr Tagen in Vergangenheit')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select xn.column_value d, xn.column_value r',
'from table ( apex_string.split_numbers(''0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30'', '','') ) xn'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1098349106875463651)
,p_name=>'Change'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P660_DAYS_BACK'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1098348522171463648)
,p_event_id=>wwv_flow_imp.id(1098349106875463651)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P660_DAYS_BACK'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1098348084701463648)
,p_event_id=>wwv_flow_imp.id(1098349106875463651)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1962937822864233026)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1098349457644463654)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>':P660_DAYS_BACK := 5;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2573862858254924581
);
wwv_flow_imp.component_end;
end;
/
