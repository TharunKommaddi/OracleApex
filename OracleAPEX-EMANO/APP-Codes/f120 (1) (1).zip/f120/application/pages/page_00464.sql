prompt --application/pages/page_00464
begin
--   Manifest
--     PAGE: 00464
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>464
,p_name=>unistr('Massenupdate - Schritt 1 (Typ ausw\00E4hlen)')
,p_alias=>unistr('MASSENUPDATE-SCHRITT-1-TYP-AUSW\00C4HLEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Massenupdate - Schritt 1 (Typ ausw\00E4hlen)')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* tr:hover .t-Button {',
'    background-color: black !important;',
'    color: white !important;',
'} */',
'',
'',
'/* Hover state - all turn white */',
'',
'/* ET Verwendung text white on hover */',
'tr:hover span[style*="color: #666"],',
'tr:hover span[style*="color: #27ae60"], ',
'tr:hover span[style*="color: #e74c3c"] {',
'    color: #ffffff !important;',
'}',
'',
'/* ET Verwendung icons white on hover */',
'tr:hover .fa-check,',
'tr:hover .fa-times {',
'    color: #ffffff !important;',
'}',
'',
'',
'/* Hover state - all turn white */'))
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_dialog_width=>'1000'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4436928856400939105)
,p_plug_name=>'Mass Update Explanations'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="unece_help" style="display:none;">',
'    <div style="background-color: #d4edda; border: 1px solid #c3e6cb; padding: 15px; margin: 10px 0; border-radius: 5px;">',
'        <h3 style="color: #155724; margin-top: 0;">UNECE Highest Series Selection Spezial</h3>',
unistr('        <p>Bei diesem Massenupdate werden bei allen markierten Zeilen immer die h\00F6chsten verwendbaren UNECE Vorschriften gesucht.</p>'),
'        <p><strong>Wichtige Hinweise:</strong></p>',
'        <ul>',
unistr('            <li>Kommentar kann eingegeben werden (gilt f\00FCr alle Zeilen)</li>'),
unistr('            <li>Bereits bewertete Eintr\00E4ge werden nicht bearbeitet</li>'),
unistr('            <li>Alternativen d\00FCrfen sich nicht widersprechen</li>'),
unistr('            <li>Themengebiete d\00FCrfen sich nicht widersprechen</li>'),
'        </ul>',
'    </div>',
'</div>',
'',
'<div id="deactivate_help" style="display:none;">',
'    <div style="background-color: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; margin: 10px 0; border-radius: 5px;">',
unistr('        <h3 style="color: #856404; margin-top: 0;">Vorschriften nicht relevant f\00FCr Umsetzung</h3>'),
unistr('        <p>Mit diesem Massenupdate k\00F6nnen nur komplette Zeilen deaktiviert werden.</p>'),
'        <p><strong>Wichtige Hinweise:</strong></p>',
'        <ul>',
'            <li>Nur komplette Zeilen werden deaktiviert</li>',
unistr('            <li>Keine Einzelauswahl m\00F6glich</li>'),
unistr('            <li>Kein Kommentarfeld verf\00FCgbar</li>'),
unistr('            <li>Bereits bewertete Eintr\00E4ge werden nicht bearbeitet</li>'),
'        </ul>',
'    </div>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="mass_update_explanations">',
'    <div id="unece_explanation" style="display:none; margin-top:15px; padding:15px; background-color:#f8f9fa; border-left:4px solid #007bff;">',
'        <h4 style="color:#007bff; margin-top:0;">UNECE Highest Series Selection Spezial</h4>',
unistr('        <p><strong>Beschreibung:</strong> Bei diesem Massenupdate werden bei allen markierten Zeilen immer die h\00F6chsten verwendbaren UNECE Vorschriften gesucht und f\00FCr die jeweilige Zeile ausgew\00E4hlt und gespeichert.</p>'),
'        <p><strong>Wichtige Hinweise:</strong></p>',
'        <ul>',
unistr('            <li>Sie k\00F6nnen einen Kommentar schreiben - dieser kann nicht zwischen den verschiedenen Zeilen variiert werden</li>'),
unistr('            <li>Wenn etwas bewertet wurde, soll es per Massenupdate nicht bearbeitet werden k\00F6nnen</li>'),
unistr('            <li>Kriterien werden gepr\00FCft - bei Fehlern wird angezeigt, welche Zeilen nicht verarbeitbar sind</li>'),
unistr('            <li>Alternativen d\00FCrfen sich nicht widersprechen</li>'),
unistr('            <li>Themengebiete d\00FCrfen sich nicht widersprechen</li>'),
'        </ul>',
'    </div>',
'    ',
'    <div id="deactivate_explanation" style="display:none; margin-top:15px; padding:15px; background-color:#fff3cd; border-left:4px solid #ffc107;">',
unistr('        <h4 style="color:#856404; margin-top:0;">Vorschriften in Zeilen nicht relevant f\00FCr Umsetzung</h4>'),
unistr('        <p><strong>Beschreibung:</strong> Mit dem Massenupdate kann man nur Zeilen komplett deaktivieren. Es ist keine Auswahl einer einzelnen Vorschrift m\00F6glich.</p>'),
'        <p><strong>Wichtige Hinweise:</strong></p>',
'        <ul>',
unistr('            <li>Nur komplette Zeilen k\00F6nnen deaktiviert werden</li>'),
unistr('            <li>Keine Einzelauswahl von Vorschriften m\00F6glich</li>'),
unistr('            <li>Wenn etwas bewertet wurde, soll es per Massenupdate nicht bearbeitet werden k\00F6nnen</li>'),
'            <li>Zusammenfassung des zu erwartenden Ergebnisses wird angezeigt</li>',
unistr('            <li>Kommentarfeld ist nicht verf\00FCgbar f\00FCr diese Option</li>'),
'        </ul>',
'    </div>',
'</div>'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17017731781910318554)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_component_template_options=>'#DEFAULT#:t-WizardSteps--displayLabels'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(964128428368451140)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17017732975492324087)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964125766881446475)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(17017732975492324087)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964125352271446475)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(17017732975492324087)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Weiter'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(964116248641446460)
,p_branch_name=>'Go To Page 468'
,p_branch_action=>'f?p=&APP_ID.:468:&SESSION.::&DEBUG.:468:P468_SELECTED_ROWS,P468_SEARCH_SELECTION,P468_MILESTONE_SELECTION,P468_CARD_NUM,P468_UPDATE_TYPE,P468_COMMENT:&P464_SELECTED_ROWS.,&P464_SEARCH_SELECTION.,&P464_MILESTONE_SELECTION.,&P464_CARD_NUM.,&P464_UPDATE_TYPE.,&P464_COMMENT.'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(964125352271446475)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964124926726446474)
,p_name=>'P464_LOAD_FROM'
,p_item_sequence=>20
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964124574187446474)
,p_name=>'P464_SELECTED_ROWS'
,p_item_sequence=>30
,p_use_cache_before_default=>'NO'
,p_source=>':&P464_LOAD_FROM.'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964124127328446474)
,p_name=>'P464_SEARCH_SELECTION'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964123810370446473)
,p_name=>'P464_MILESTONE_SELECTION'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964123399456446473)
,p_name=>'P464_CARD_NUM'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964122939204446473)
,p_name=>'P464_UPDATE_TYPE'
,p_item_sequence=>70
,p_prompt=>unistr('Welche Art von Massenupdate m\00F6chten Sie durchf\00FChren?')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT display_value, return_value',
'FROM (',
'    SELECT ''UNECE Highest Series Selection Spezial'' as display_value, ''UNECE_HIGHEST_SERIES'' as return_value, 1 as sort_order FROM DUAL',
'    UNION ALL',
unistr('    SELECT ''Vorschriften in Zeilen nicht relevant f\00FCr Umsetzung'' as display_value, ''DEACTIVATE_ROWS'' as return_value, 2 as sort_order FROM DUAL'),
'    -- UNION ALL',
'    -- SELECT ''Export to Sheets'' as display_value, ''EXPORT_TO_SHEETS'' as return_value, 3 as sort_order FROM DUAL',
')',
'ORDER BY sort_order'))
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:margin-top-lg'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964122517568446472)
,p_name=>'P464_COMMENT'
,p_item_sequence=>90
,p_prompt=>'Kommentar'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>50
,p_cHeight=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>unistr('<b>Dieser Kommentar wird f\00FCr alle ausgew\00E4hlten Zeilen verwendet und kann nicht zwischen den verschiedenen Zeilen variiert werden.</b>')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(964120740892446464)
,p_validation_name=>'Update Type Required'
,p_validation_sequence=>10
,p_validation=>'P464_UPDATE_TYPE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Bitte w\00E4hlen Sie eine Massenupdate-Option aus.')
,p_when_button_pressed=>wwv_flow_imp.id(964125352271446475)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(964121606970446467)
,p_validation_name=>'Rows Required'
,p_validation_sequence=>20
,p_validation=>'P464_SELECTED_ROWS'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Keine Zeilen f\00FCr Massenupdate ausgew\00E4hlt.')
,p_when_button_pressed=>wwv_flow_imp.id(964125352271446475)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(964121165430446465)
,p_validation_name=>'Minimum Rows Check'
,p_validation_sequence=>30
,p_validation=>'LENGTH(:P464_SELECTED_ROWS) - LENGTH(REPLACE(:P464_SELECTED_ROWS, '':'', '''')) + 1 >= 2'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Mindestens 2 Zeilen m\00FCssen f\00FCr Massenupdate ausgew\00E4hlt werden.')
,p_validation_condition_type=>'NEVER'
,p_when_button_pressed=>wwv_flow_imp.id(964125352271446475)
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964120450970446464)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(964125766881446475)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964119971160446463)
,p_event_id=>wwv_flow_imp.id(964120450970446464)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964119596832446463)
,p_name=>'Help Text'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P464_UPDATE_TYPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964119072594446462)
,p_event_id=>wwv_flow_imp.id(964119596832446463)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Hide all explanation divs first',
'$(''#unece_help'').hide();',
'$(''#deactivate_help'').hide();',
'',
'// Show the relevant explanation based on selection',
'var selectedValue = $v(''P464_UPDATE_TYPE'');',
'console.log(''Selected value:'', selectedValue);',
'',
'if (selectedValue === ''UNECE_HIGHEST_SERIES'') {',
'    $(''#unece_help'').fadeIn(500);',
'    apex.item(''P464_COMMENT'').show();',
'} else if (selectedValue === ''DEACTIVATE_ROWS'') {',
'    $(''#deactivate_help'').fadeIn(500);',
'    apex.item(''P464_COMMENT'').hide();',
'    apex.item(''P464_COMMENT'').setValue(''''); // Clear comment when hidden',
'} else {',
'    // No selection - hide comment field and clear value',
'    apex.item(''P464_COMMENT'').hide();',
'    apex.item(''P464_COMMENT'').setValue('''');',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964118520779446462)
,p_event_id=>wwv_flow_imp.id(964119596832446463)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Hide all explanation divs first',
'$(''#unece_explanation'').hide();',
'$(''#deactivate_explanation'').hide();',
'',
'// Show the relevant explanation based on selection',
'var selectedValue = $v(''P464_UPDATE_TYPE'');',
'console.log(''Selected value:'', selectedValue);',
'',
'if (selectedValue === ''UNECE_HIGHEST_SERIES'') {',
'    $(''#unece_explanation'').fadeIn(300);',
'} else if (selectedValue === ''DEACTIVATE_ROWS'') {',
'    $(''#deactivate_explanation'').fadeIn(300);',
'}'))
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964118143404446462)
,p_name=>'Initialize Page State'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964117679577446461)
,p_event_id=>wwv_flow_imp.id(964118143404446462)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Hide all explanation divs first',
'$(''#unece_help'').hide();',
'$(''#deactivate_help'').hide();',
'',
'// Hide comment field initially',
'apex.item(''P464_COMMENT'').hide();',
'',
'// Show the relevant explanation based on selection',
'var selectedValue = $v(''P464_UPDATE_TYPE'');',
'console.log(''Selected value:'', selectedValue);',
'',
'if (selectedValue === ''UNECE_HIGHEST_SERIES'') {',
'    $(''#unece_help'').fadeIn(500);',
'    apex.item(''P464_COMMENT'').show();',
'} else if (selectedValue === ''DEACTIVATE_ROWS'') {',
'    $(''#deactivate_help'').fadeIn(500);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964117258170446461)
,p_name=>'New'
,p_event_sequence=>50
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964116778195446461)
,p_event_id=>wwv_flow_imp.id(964117258170446461)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Check if we came from page 468 (URL will have P464_SELECTED_ROWS)',
'var urlParams = new URLSearchParams(window.location.search);',
'var pageParams = window.location.href;',
'',
'// Look for P464_SELECTED_ROWS in the URL',
'if (pageParams.includes(''P464_SELECTED_ROWS:'') && !pageParams.includes(''P464_SELECTED_ROWS:P461_SELECTED_ROWS'')) {',
'    // We came from page 468 - extract the value from URL',
'    var urlParts = pageParams.split(''P464_SELECTED_ROWS:'')[1];',
'    if (urlParts) {',
'        var selectedRows = urlParts.split('','')[0]; // Get value before next parameter',
'        ',
'        // Set the item value, overriding the source expression',
'        apex.item(''P464_SELECTED_ROWS'').setValue(selectedRows);',
'        ',
'        console.log(''Set selected rows from page 468:'', selectedRows);',
'    }',
'}',
'// If we came from page 461, let the source expression handle it normally'))
);
wwv_flow_imp.component_end;
end;
/
