prompt --application/pages/page_00050
begin
--   Manifest
--     PAGE: 00050
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>50
,p_name=>'Benutzerverwaltung'
,p_step_title=>'Benutzerverwaltung'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_comment=>'a'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2642953310440609146)
,p_plug_name=>'Benutzerverwaltung'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select benutzer."ROWID" as benutzer_rowid, ',
'benutzer."NACHNAME",',
'benutzer."VORNAME",',
'benutzer."ABTEILUNG",',
'list_rolle,',
'benutzer."GID",',
'benutzer."TELEFON",',
'benutzer."EMAIL",',
'benutzer."STATUS",',
'benutzer."LETZTE_AENDERUNG_DATUM",',
'aenderung_benutzer.nachname || '', '' || aenderung_benutzer.vorname',
'from "#OWNER#"."T_BENUTZER" benutzer',
'left outer join T_BENUTZER aenderung_benutzer on aenderung_benutzer.benutzerid = benutzer.letzte_aenderung_benutzerid',
'outer apply (',
'    select listagg(rolle.rolle, '', '') within group(order by rolle.rolle) list_rolle',
'    from t_benutzer_ref_rolle brf ',
'    join t_rolle rolle on rolle.rolleid = brf.rolleid',
'    where brf.benutzerid = benutzer.benutzerid',
')',
'where benutzer.benutzerid in (select benutzerid from t_benutzer_ref_rolle where rolleid not in( 1004, 1010))',
'order by benutzer."NACHNAME", benutzer."VORNAME"'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2642953701053609147)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:55:&SESSION.::&DEBUG.:55:P55_ROWID:#BENUTZER_ROWID#'
,p_detail_link_text=>'<span class="fa fa-pencil" aria-hidden="true" alt="Bearbeiten" title="Bearbeiten"></span>'
,p_detail_link_condition_type=>'EXPRESSION'
,p_detail_link_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(userId => PCK_RI.fGetUserId, ',
'                      pageId => :APP_PAGE_ID,',
'                      accessMode => 200))'))
,p_detail_link_cond2=>'PLSQL'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>153607135095336911
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2642963232979662256)
,p_db_column_name=>'BENUTZER_ROWID'
,p_display_order=>10
,p_column_identifier=>'L'
,p_column_label=>'Benutzer Rowid'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2642954257605609152)
,p_db_column_name=>'NACHNAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nachname'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2642954589169609153)
,p_db_column_name=>'VORNAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Vorname'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2642955017619609153)
,p_db_column_name=>'ABTEILUNG'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Abteilung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2642955462246609153)
,p_db_column_name=>'GID'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'GID'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2642963312462662257)
,p_db_column_name=>'LIST_ROLLE'
,p_display_order=>70
,p_column_identifier=>'M'
,p_column_label=>'Rollen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2642955791957609153)
,p_db_column_name=>'TELEFON'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'Telefon'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2642956209001609154)
,p_db_column_name=>'EMAIL'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'E-Mail'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2642956577249609154)
,p_db_column_name=>'STATUS'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>'Status'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(958149918160538260)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2642957014394609154)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>110
,p_column_identifier=>'I'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2642961344089662237)
,p_db_column_name=>'AENDERUNG_BENUTZER.NACHNAME||'',''||AENDERUNG_BENUTZER.VORNAME'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2642960746214616023)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1536142'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NACHNAME:VORNAME:ABTEILUNG:GID:LIST_ROLLE:TELEFON:EMAIL:STATUS:LETZTE_AENDERUNG_DATUM:AENDERUNG_BENUTZER.NACHNAME||'',''||AENDERUNG_BENUTZER.VORNAME:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2642958738486609156)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2642953310440609146)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:55:&SESSION.::&DEBUG.:55::'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(userId => PCK_RI.fGetUserId, ',
'                      pageId => :APP_PAGE_ID,',
'                      accessMode => 200)) AND (pck_ri.fIsUserInRolle(listRolleId => ''1005'')) > 0'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2642963440939662258)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2642953310440609146)
,p_button_name=>'LDAP_CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'LDAP Benutzersuche'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:65:&SESSION.::&DEBUG.:RP,65:P65_CAMEFROM:50'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(userId => PCK_RI.fGetUserId, ',
'                      pageId => :APP_PAGE_ID,',
'                      accessMode => 200))'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2642957816541609155)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2642953310440609146)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2642958353880609156)
,p_event_id=>wwv_flow_imp.id(2642957816541609155)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2642953310440609146)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2642959093464609156)
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2642958738486609156)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2642959653620609157)
,p_event_id=>wwv_flow_imp.id(2642959093464609156)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2642953310440609146)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
