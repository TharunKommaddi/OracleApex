prompt --application/pages/page_00042
begin
--   Manifest
--     PAGE: 00042
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>42
,p_name=>'466 Backup - 12.08.2025'
,p_alias=>'466-BACKUP-12-08-2025'
,p_page_mode=>'MODAL'
,p_step_title=>'466 Backup - 12.08.2025'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_dialog_width=>'1000'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4932545321657616103)
,p_plug_name=>'Form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11441076302719154915)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(988055748953491626)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(11441076302719154915)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(988055361131491623)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(11441076302719154915)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>unistr('javascript:apex.confirm(''M\00F6chten Sie den FilterProfil l\00F6schen?'',''DELETE'');')
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(988054970077491622)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(11441076302719154915)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(988054567012491621)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(11441076302719154915)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988053913781491597)
,p_name=>'P42_BEWERTUNG_ANSICHT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4932545321657616103)
,p_item_default=>'ET'
,p_prompt=>'<b>Bewertung Ansicht</b>'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'SELECT display_value as d, return_value as r',
'FROM (',
'    SELECT ''ET-B Abstimmung'' as display_value, ''ET'' as return_value, 1 as sort_order FROM dual',
'    UNION ALL',
'    SELECT ''ET-A Vorschlag'', ''FB'', 2 FROM dual',
'    UNION ALL',
'    SELECT ''ET-G Vorschlag'', ''ANDERE'', 3 FROM dual',
')',
'ORDER BY sort_order'))
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988053466866491589)
,p_name=>'P42_SELECTED_ROWS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(4932545321657616103)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988053028484491589)
,p_name=>'P42_ET_KOMMENTAR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(4932545321657616103)
,p_prompt=>'ET Kommentar'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>':P42_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988052661381491588)
,p_name=>'P42_ET_VERWENDUNG'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4932545321657616103)
,p_prompt=>'ET Verwendung'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT d, r FROM (',
'    SELECT ''nicht bewertet'' as d, ''nicht bewertet'' as r FROM dual',
'    UNION ALL',
'    SELECT ''ja'' as d, ''ja'' as r FROM dual  ',
'    UNION ALL',
'    SELECT ''nein'' as d, ''nein'' as r FROM dual',
'  ) ORDER BY CASE WHEN r = ''nicht bewertet'' THEN 1 WHEN r = ''ja'' THEN 2 ELSE 3 END'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Bitte ausw\00E4hlen --')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>':P42_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988052292324491588)
,p_name=>'P42_ET_VORSCHLAG_VORSCHRIFT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(4932545321657616103)
,p_use_cache_before_default=>'NO'
,p_prompt=>'ET Vorschlag Vorschrift'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ms.vorschriftnummer',
'FROM T_MS_SUCHERGEBNISS ms',
'WHERE ms.sucheid = :P42_SEARCH_SELECTION ',
'AND ms.meilenstein = :P42_MILESTONE_SELECTION',
'AND ms.VORSCHRIFTID = :P42_SINGLE_REG_ID',
'AND ROWNUM = 1'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT regulation_option as d, regulation_option as r',
'FROM (',
'    -- Get the main regulation number',
'    SELECT DISTINCT ms.vorschriftnummer as regulation_option, 1 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    WHERE ms.sucheid = :P42_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P42_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P42_SINGLE_REG_ID',
'    AND ms.vorschriftnummer IS NOT NULL',
'    ',
'    UNION',
'    ',
'    -- Get all alternative regulation numbers for this main regulation',
'    SELECT DISTINCT tv.vorschrift_nummer as regulation_option, 2 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'    WHERE ms.sucheid = :P42_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P42_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P42_SINGLE_REG_ID',
'    AND tv.vorschrift_nummer IS NOT NULL',
'    AND ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL',
')',
'-- ORDER BY sort_order, regulation_option',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Vorschrift ausw\00E4hlen --')
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P42_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')',
'',
'',
'SELECT DISTINCT regulation_option as d, regulation_option as r',
'  FROM (',
'      SELECT ms.vorschriftnummer as regulation_option',
'      FROM T_MS_SUCHERGEBNISS ms',
'      WHERE ms.sucheid = :P42_SEARCH_SELECTION ',
'      AND ms.meilenstein = :P42_MILESTONE_SELECTION',
'      UNION',
'      SELECT tv.vorschrift_nummer as regulation_option  ',
'      FROM T_MS_SUCHERGEBNISS ms',
'      LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'      WHERE ms.sucheid = :P42_SEARCH_SELECTION ',
'      AND ms.meilenstein = :P42_MILESTONE_SELECTION',
'      AND tv.vorschrift_nummer IS NOT NULL',
'  ) ORDER BY regulation_option'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988051831210491587)
,p_name=>'P42_ET_VORSCHLAG_VORSCHRIFT_2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(4932545321657616103)
,p_use_cache_before_default=>'NO'
,p_prompt=>'ET Vorschlag Vorschrift'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN tv.vorschrift_nummer IS NOT NULL THEN ',
'            ms.vorschriftnummer || '', '' || tv.vorschrift_nummer',
'        ELSE ',
'            ms.vorschriftnummer',
'    END as regulation_numbers',
'FROM T_MS_SUCHERGEBNISS ms',
'LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'WHERE ms.sucheid = :P42_SEARCH_SELECTION ',
'AND ms.meilenstein = :P42_MILESTONE_SELECTION',
'AND (',
'    CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END',
') = :P42_SINGLE_REG_ID',
'AND ROWNUM = 1'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>':P42_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988051418195491587)
,p_name=>'P42_FB_KOMMENTAR'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(4932545321657616103)
,p_prompt=>'FB Kommentar'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>':P42_BEWERTUNG_ANSICHT IN (''ET'', ''FB'')'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988051092396491586)
,p_name=>'P42_FB_VERWENDUNG'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(4932545321657616103)
,p_prompt=>'FB Verwendung'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT d, r FROM (',
'    SELECT ''nicht bewertet'' as d, ''nicht bewertet'' as r FROM dual',
'    UNION ALL',
'    SELECT ''ja'' as d, ''ja'' as r FROM dual  ',
'    UNION ALL',
'    SELECT ''nein'' as d, ''nein'' as r FROM dual',
'  ) ORDER BY CASE WHEN r = ''nicht bewertet'' THEN 1 WHEN r = ''ja'' THEN 2 ELSE 3 END'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Bitte ausw\00E4hlen --')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>':P42_BEWERTUNG_ANSICHT IN (''ET'', ''FB'')'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988050664680491586)
,p_name=>'P42_FB_VORSCHLAG_VORSCHRIFT'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(4932545321657616103)
,p_use_cache_before_default=>'NO'
,p_prompt=>'FB Vorschlag Vorschrift'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ms.vorschriftnummer',
'FROM T_MS_SUCHERGEBNISS ms',
'WHERE ms.sucheid = :P42_SEARCH_SELECTION ',
'AND ms.meilenstein = :P42_MILESTONE_SELECTION',
'AND ms.VORSCHRIFTID = :P42_SINGLE_REG_ID',
'AND ROWNUM = 1'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT regulation_option as d, regulation_option as r',
'FROM (',
'    -- Get the main regulation number',
'    SELECT DISTINCT ms.vorschriftnummer as regulation_option, 1 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    WHERE ms.sucheid = :P42_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P42_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P42_SINGLE_REG_ID',
'    AND ms.vorschriftnummer IS NOT NULL',
'    ',
'    UNION',
'    ',
'    -- Get all alternative regulation numbers for this main regulation',
'    SELECT DISTINCT tv.vorschrift_nummer as regulation_option, 2 as sort_order',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'    WHERE ms.sucheid = :P42_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P42_MILESTONE_SELECTION',
'    AND ms.VORSCHRIFTID = :P42_SINGLE_REG_ID',
'    AND tv.vorschrift_nummer IS NOT NULL',
'    AND ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL',
')',
'ORDER BY regulation_option'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Vorschrift ausw\00E4hlen --')
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P42_BEWERTUNG_ANSICHT IN (''ET'', ''FB'')',
'',
'',
'',
'SELECT DISTINCT regulation_option as d, regulation_option as r',
'  FROM (',
'      SELECT ms.vorschriftnummer as regulation_option',
'      FROM T_MS_SUCHERGEBNISS ms',
'      WHERE ms.sucheid = :P42_SEARCH_SELECTION ',
'      AND ms.meilenstein = :P42_MILESTONE_SELECTION',
'      UNION',
'      SELECT tv.vorschrift_nummer as regulation_option  ',
'      FROM T_MS_SUCHERGEBNISS ms',
'      LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'      WHERE ms.sucheid = :P42_SEARCH_SELECTION ',
'      AND ms.meilenstein = :P42_MILESTONE_SELECTION',
'      AND tv.vorschrift_nummer IS NOT NULL',
'  ) ORDER BY regulation_option'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988050243247491585)
,p_name=>'P42_FB_VORSCHLAG_VORSCHRIFT_2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(4932545321657616103)
,p_use_cache_before_default=>'NO'
,p_prompt=>'FB Vorschlag Vorschrift'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN tv.vorschrift_nummer IS NOT NULL THEN ',
'            ms.vorschriftnummer || '', '' || tv.vorschrift_nummer',
'        ELSE ',
'            ms.vorschriftnummer',
'    END as regulation_numbers',
'FROM T_MS_SUCHERGEBNISS ms',
'LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.alternative_vorschriftid',
'WHERE ms.sucheid = :P42_SEARCH_SELECTION ',
'AND ms.meilenstein = :P42_MILESTONE_SELECTION',
'AND (',
'    CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END',
') = :P42_SINGLE_REG_ID',
'AND ROWNUM = 1'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>':P42_BEWERTUNG_ANSICHT IN (''ET'', ''FB'')'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988049821531491585)
,p_name=>'P42_SEARCH_SELECTION'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(4932545321657616103)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988049464618491585)
,p_name=>'P42_MILESTONE_SELECTION'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(4932545321657616103)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988049080845491584)
,p_name=>'P42_CARD_NUM'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(4932545321657616103)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988048651464491584)
,p_name=>'P42_LOAD_FROM'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(4932545321657616103)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988048260374491584)
,p_name=>'P42_RECORD_COUNT'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(4932545321657616103)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CASE ',
'    WHEN :P42_SELECTED_ROWS IS NULL THEN ''No records selected''',
'    ELSE ''Selected '' || COUNT(*) || '' record(s): '' || :P42_SELECTED_ROWS',
'END',
'FROM TABLE(apex_string.split(:P42_SELECTED_ROWS, '':''))',
'WHERE TRIM(column_value) IS NOT NULL'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988047878346491584)
,p_name=>'P42_SINGLE_REG_ID'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(4932545321657616103)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(988047440078491583)
,p_name=>'P42_SELECTED_ROWS_1'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(4932545321657616103)
,p_use_cache_before_default=>'NO'
,p_source=>':&P42_LOAD_FROM.'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(988044806601491548)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(988055748953491626)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(988044237192491542)
,p_event_id=>wwv_flow_imp.id(988044806601491548)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(988043872770491541)
,p_name=>'Show / Hide Columns'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P42_BEWERTUNG_ANSICHT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(988043355800491541)
,p_event_id=>wwv_flow_imp.id(988043872770491541)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P42_BEWERTUNG_ANSICHT'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(988042836347491540)
,p_event_id=>wwv_flow_imp.id(988043872770491541)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Store switch value before refresh',
'var switchValue = $v(''P461_BEWERTUNG_ANSICHT'');',
'sessionStorage.setItem(''P461_SWITCH_VALUE'', switchValue);'))
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(988042390249491539)
,p_event_id=>wwv_flow_imp.id(988043872770491541)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4932545321657616103)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(988047099009491555)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Single Update Bewertungen speichern'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'BEGIN',
'    -- apex_debug.message(''=== SAVING SINGLE REGULATION BEWERTUNG ==='');',
'    -- apex_debug.message(''P42_SINGLE_REG_ID: '' || :P42_SINGLE_REG_ID);',
'    -- apex_debug.message(''P42_ET_VERWENDUNG: '' || :P42_ET_VERWENDUNG);',
'    -- apex_debug.message(''P42_FB_VERWENDUNG: '' || :P42_FB_VERWENDUNG);',
'    ',
'    -- Validate that we have a regulation ID',
'    IF :P42_SINGLE_REG_ID IS NULL THEN',
'        apex_debug.message(''ERROR: No regulation ID to save'');',
'        RAISE_APPLICATION_ERROR(-20001, ''Keine Vorschrift-ID zum Speichern gefunden'');',
'    END IF;',
'    ',
'    -- Update or insert evaluation for the single regulation',
'    MERGE INTO T_MS_BEWERTUNG bew',
'    USING (',
'        SELECT ',
'            :P42_SEARCH_SELECTION as sucheid,',
'            :P42_MILESTONE_SELECTION as meilenstein, ',
'            :P42_CARD_NUM as card_number,',
'            :P42_SINGLE_REG_ID as vorschriftid,',
'            :G_BENUTZERID as benutzerid',
'        FROM dual',
'    ) src ON (',
'        bew.SUCHEID = src.sucheid ',
'        AND bew.MEILENSTEIN = src.meilenstein',
'        AND bew.CARD_NUMBER = src.card_number',
'        AND bew.VORSCHRIFTID = src.vorschriftid',
'        AND bew.BENUTZERID = src.benutzerid',
'    )',
'    WHEN MATCHED THEN',
'        UPDATE SET ',
'            ET_VERWENDUNG = NVL(:P42_ET_VERWENDUNG, ''nicht bewertet''),',
'            ET_VORSCHLAG_VORSCHRIFT = :P42_ET_VORSCHLAG_VORSCHRIFT,',
'            ET_KOMMENTAR = :P42_ET_KOMMENTAR,',
'            FB_VERWENDUNG = NVL(:P42_FB_VERWENDUNG, ''nicht bewertet''),',
'            FB_VORSCHLAG_VORSCHRIFT = :P42_FB_VORSCHLAG_VORSCHRIFT,',
'            FB_KOMMENTAR = :P42_FB_KOMMENTAR,',
'            LETZTE_AENDERUNG_DATUM = SYSDATE,',
'            LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'    WHEN NOT MATCHED THEN',
'        INSERT (',
'            SUCHEID, MEILENSTEIN, CARD_NUMBER, VORSCHRIFTID, BENUTZERID,',
'            ET_VERWENDUNG, ET_VORSCHLAG_VORSCHRIFT, ET_KOMMENTAR,',
'            FB_VERWENDUNG, FB_VORSCHLAG_VORSCHRIFT, FB_KOMMENTAR,',
'            ERSTELLUNG_DATUM, LETZTE_AENDERUNG_DATUM, LETZTE_AENDERUNG_BENUTZERID',
'        ) VALUES (',
'            src.sucheid, src.meilenstein, src.card_number, src.vorschriftid, src.benutzerid,',
'            NVL(:P42_ET_VERWENDUNG, ''nicht bewertet''),',
'            :P42_ET_VORSCHLAG_VORSCHRIFT,',
'            :P42_ET_KOMMENTAR,',
'            NVL(:P42_FB_VERWENDUNG, ''nicht bewertet''),',
'            :P42_FB_VORSCHLAG_VORSCHRIFT,',
'            :P42_FB_KOMMENTAR,',
'            SYSDATE, SYSDATE, :G_BENUTZERID',
'        );',
'    ',
'    COMMIT;',
'    ',
unistr('    apex_debug.message(''SUCCESS: Bewertung gespeichert f\00FCr Vorschrift ID: '' || :P42_SINGLE_REG_ID);'),
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        apex_debug.message(''ERROR beim Speichern: '' || SQLERRM);',
'        RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(988054970077491622)
,p_internal_uid=>2684165216889896680
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(988045951680491553)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Bulk Update Bewertungen speichern_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_selected_rows VARCHAR2(4000) := :P42_SELECTED_ROWS;',
'    l_search_id NUMBER := :P42_SEARCH_SELECTION;',
'    l_milestone NUMBER := :P42_MILESTONE_SELECTION;',
'    l_card_number NUMBER := :P42_CARD_NUM;',
'    l_count NUMBER := 0;',
'BEGIN',
'    -- Process each selected row (SPECIFIC_REG_ID values)',
'    FOR rec IN (',
'        SELECT TO_NUMBER(TRIM(column_value)) as specific_reg_id',
'        FROM TABLE(apex_string.split(l_selected_rows, '':''))',
'        WHERE TRIM(column_value) IS NOT NULL',
'    ) LOOP',
'        ',
'        -- Update or insert evaluation for each regulation',
'        MERGE INTO T_MS_BEWERTUNG bew',
'        USING (',
'            SELECT ',
'                l_search_id as sucheid,',
'                l_milestone as meilenstein, ',
'                l_card_number as card_number,',
'                rec.specific_reg_id as vorschriftid,',
'                :G_BENUTZERID as benutzerid',
'            FROM dual',
'        ) src ON (',
'            bew.SUCHEID = src.sucheid ',
'            AND bew.MEILENSTEIN = src.meilenstein',
'            AND bew.CARD_NUMBER = src.card_number',
'            AND bew.VORSCHRIFTID = src.vorschriftid',
'            AND bew.BENUTZERID = src.benutzerid',
'        )',
'        WHEN MATCHED THEN',
'            UPDATE SET ',
'                ET_VERWENDUNG = CASE WHEN :P42_ET_VERWENDUNG IS NOT NULL THEN :P42_ET_VERWENDUNG ELSE bew.ET_VERWENDUNG END,',
'                ET_VORSCHLAG_VORSCHRIFT = CASE WHEN :P42_ET_VORSCHLAG_VORSCHRIFT IS NOT NULL THEN :P42_ET_VORSCHLAG_VORSCHRIFT ELSE bew.ET_VORSCHLAG_VORSCHRIFT END,',
'                ET_KOMMENTAR = CASE WHEN :P42_ET_KOMMENTAR IS NOT NULL THEN :P42_ET_KOMMENTAR ELSE bew.ET_KOMMENTAR END,',
'                FB_VERWENDUNG = CASE WHEN :P42_FB_VERWENDUNG IS NOT NULL THEN :P42_FB_VERWENDUNG ELSE bew.FB_VERWENDUNG END,',
'                FB_VORSCHLAG_VORSCHRIFT = CASE WHEN :P42_FB_VORSCHLAG_VORSCHRIFT IS NOT NULL THEN :P42_FB_VORSCHLAG_VORSCHRIFT ELSE bew.FB_VORSCHLAG_VORSCHRIFT END,',
'                FB_KOMMENTAR = CASE WHEN :P42_FB_KOMMENTAR IS NOT NULL THEN :P42_FB_KOMMENTAR ELSE bew.FB_KOMMENTAR END,',
'                LETZTE_AENDERUNG_DATUM = SYSDATE,',
'                LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'        WHEN NOT MATCHED THEN',
'            INSERT (',
'                SUCHEID, MEILENSTEIN, CARD_NUMBER, VORSCHRIFTID, BENUTZERID,',
'                ET_VERWENDUNG, ET_VORSCHLAG_VORSCHRIFT, ET_KOMMENTAR,',
'                FB_VERWENDUNG, FB_VORSCHLAG_VORSCHRIFT, FB_KOMMENTAR,',
'                ERSTELLUNG_DATUM, LETZTE_AENDERUNG_DATUM, LETZTE_AENDERUNG_BENUTZERID',
'            ) VALUES (',
'                src.sucheid, src.meilenstein, src.card_number, src.vorschriftid, src.benutzerid,',
'                NVL(:P42_ET_VERWENDUNG, ''nicht bewertet''),',
'                :P42_ET_VORSCHLAG_VORSCHRIFT,',
'                :P42_ET_KOMMENTAR,',
'                NVL(:P42_FB_VERWENDUNG, ''nicht bewertet''),',
'                :P42_FB_VORSCHLAG_VORSCHRIFT,',
'                :P42_FB_KOMMENTAR,',
'                SYSDATE, SYSDATE, :G_BENUTZERID',
'            );',
'            ',
'        l_count := l_count + 1;',
'    END LOOP;',
'    ',
'',
'    ',
'    -- Success message',
'    -- apex_application.g_print_success_message := l_count || '' Bewertungen erfolgreich aktualisiert'';',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_process_success_message=>'fdxfdgfdg'
,p_internal_uid=>2684166364218896682
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(988046751156491554)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(988054970077491622)
,p_internal_uid=>2684165564742896681
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(988045152946491552)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Page Data Button Link Icon'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'BEGIN',
'    -- Debug the incoming parameters',
'    -- apex_debug.message(''=== PAGE 466 LOAD SINGLE REGULATION ==='');',
'    -- apex_debug.message(''P42_SINGLE_REG_ID: '' || :P42_SINGLE_REG_ID);',
'    -- apex_debug.message(''P42_SEARCH_SELECTION: '' || :P42_SEARCH_SELECTION);',
'    -- apex_debug.message(''P42_MILESTONE_SELECTION: '' || :P42_MILESTONE_SELECTION);',
'    -- apex_debug.message(''P42_CARD_NUM: '' || :P42_CARD_NUM);',
'    -- apex_debug.message(''G_BENUTZERID: '' || :G_BENUTZERID);',
'    ',
'    -- Always load data for the single regulation ID',
'    IF :P42_SINGLE_REG_ID IS NOT NULL THEN',
'        ',
'        -- Load existing evaluation data for this regulation',
'        BEGIN',
'            SELECT ',
'                NVL(ET_VERWENDUNG, ''nicht bewertet'') as ET_VERWENDUNG,',
'                ET_VORSCHLAG_VORSCHRIFT,',
'                ET_KOMMENTAR,',
'                NVL(FB_VERWENDUNG, ''nicht bewertet'') as FB_VERWENDUNG,',
'                FB_VORSCHLAG_VORSCHRIFT,',
'                FB_KOMMENTAR',
'            INTO ',
'                :P42_ET_VERWENDUNG,',
'                :P42_ET_VORSCHLAG_VORSCHRIFT,',
'                :P42_ET_KOMMENTAR,',
'                :P42_FB_VERWENDUNG,',
'                :P42_FB_VORSCHLAG_VORSCHRIFT,',
'                :P42_FB_KOMMENTAR',
'            FROM T_MS_BEWERTUNG',
'            WHERE SUCHEID = :P42_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P42_MILESTONE_SELECTION',
'            AND CARD_NUMBER = :P42_CARD_NUM',
'            AND VORSCHRIFTID = :P42_SINGLE_REG_ID',
'            AND BENUTZERID = :G_BENUTZERID;',
'            ',
'            apex_debug.message(''SUCCESS: Loaded existing data for regulation ID: '' || :P42_SINGLE_REG_ID);',
'            apex_debug.message(''ET_VERWENDUNG: '' || :P42_ET_VERWENDUNG);',
'            apex_debug.message(''FB_VERWENDUNG: '' || :P42_FB_VERWENDUNG);',
'            ',
'        EXCEPTION',
'            WHEN NO_DATA_FOUND THEN',
'                -- No existing evaluation, set defaults',
'                :P42_ET_VERWENDUNG := ''nicht bewertet'';',
'                :P42_FB_VERWENDUNG := ''nicht bewertet'';',
'                :P42_ET_VORSCHLAG_VORSCHRIFT := NULL;',
'                :P42_ET_KOMMENTAR := NULL;',
'                :P42_FB_VORSCHLAG_VORSCHRIFT := NULL;',
'                :P42_FB_KOMMENTAR := NULL;',
'                ',
'                apex_debug.message(''NO_DATA_FOUND: Using default values'');',
'        END;',
'        ',
'    ELSE',
'        apex_debug.message(''ERROR: No regulation ID provided'');',
'        -- Set safe defaults',
'        :P42_ET_VERWENDUNG := ''nicht bewertet'';',
'        :P42_FB_VERWENDUNG := ''nicht bewertet'';',
'        :P42_ET_VORSCHLAG_VORSCHRIFT := NULL;',
'        :P42_ET_KOMMENTAR := NULL;',
'        :P42_FB_VORSCHLAG_VORSCHRIFT := NULL;',
'        :P42_FB_KOMMENTAR := NULL;',
'    END IF;',
'    ',
'    apex_debug.message(''=== PAGE 466 LOAD COMPLETE ==='');',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_debug.message(''ERROR in Load Page Data: '' || SQLERRM);',
'        -- Set safe defaults',
'        :P42_ET_VERWENDUNG := ''nicht bewertet'';',
'        :P42_FB_VERWENDUNG := ''nicht bewertet'';',
'        :P42_ET_VORSCHLAG_VORSCHRIFT := NULL;',
'        :P42_ET_KOMMENTAR := NULL;',
'        :P42_FB_VORSCHLAG_VORSCHRIFT := NULL;',
'        :P42_FB_KOMMENTAR := NULL;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2684167162952896683
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(988046355161491553)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Page Data MehrfachBearbeitung Button'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Set the page items from URL parameters',
'    :P42_CARD_NUM := :P42_CARD_NUM;',
'    :P42_SEARCH_SELECTION := :P42_SEARCH_SELECTION;',
'    :P42_MILESTONE_SELECTION := :P42_MILESTONE_SELECTION;',
'    :P42_SELECTED_ROWS := :P42_SELECTED_ROWS;',
'   ',
'    -- Debug',
'    -- apex_debug.message(''P42_SELECTED_ROWS: '' || :P42_SELECTED_ROWS);',
'    -- apex_debug.message(''P42_SEARCH_SELECTION: '' || :P42_SEARCH_SELECTION);',
'    -- apex_debug.message(''P42_MILESTONE_SELECTION: '' || :P42_MILESTONE_SELECTION);',
'    -- apex_debug.message(''P42_CARD_NUM: '' || :P42_CARD_NUM);',
'    ',
'',
'    ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2684165960737896682
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(988045583936491552)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Page Data_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    debug(''P42_LOAD_FROM value'', :P42_LOAD_FROM);',
'    ',
'    -- Manually resolve the selected rows since automatic resolution failed',
'    IF :P42_LOAD_FROM = ''P461_SELECTED_ROWS'' THEN',
'        :P42_SELECTED_ROWS := apex_util.get_session_state(''P461_SELECTED_ROWS'');',
'        debug(''Manually set P42_SELECTED_ROWS'', :P42_SELECTED_ROWS);',
'    END IF;',
'    ',
'    debug(''P42_SEARCH_SELECTION'', :P42_SEARCH_SELECTION);',
'    debug(''P42_MILESTONE_SELECTION'', :P42_MILESTONE_SELECTION);',
'    debug(''P42_CARD_NUM'', :P42_CARD_NUM);',
'    debug(''G_BENUTZERID'', :G_BENUTZERID);',
'    ',
'    -- Check if we have selected rows',
'    IF :P42_SELECTED_ROWS IS NOT NULL AND TRIM(:P42_SELECTED_ROWS) != '''' THEN',
'        debug(''Selected rows found'', :P42_SELECTED_ROWS);',
'        ',
'        -- Count selected records using simple approach',
'        DECLARE',
'            l_selected_count NUMBER;',
'            l_first_reg_id NUMBER;',
'            l_selected_string VARCHAR2(4000) := :P42_SELECTED_ROWS;',
'        BEGIN',
'            -- Simple count - if no colon, then 1 record, otherwise count colons + 1',
'            IF INSTR(l_selected_string, '':'') = 0 THEN',
'                l_selected_count := 1;',
'                l_first_reg_id := TO_NUMBER(TRIM(l_selected_string));',
'            ELSE',
'                -- Count colons and add 1',
'                l_selected_count := LENGTH(l_selected_string) - LENGTH(REPLACE(l_selected_string, '':'', '''')) + 1;',
'                -- Get first ID (before first colon)',
'                l_first_reg_id := TO_NUMBER(TRIM(SUBSTR(l_selected_string, 1, INSTR(l_selected_string, '':'') - 1)));',
'            END IF;',
'            ',
'            debug(''Selected count'', l_selected_count);',
'            debug(''First regulation ID'', l_first_reg_id);',
'            ',
'            -- If only one record, load its existing evaluation data',
'            IF l_selected_count = 1 THEN',
'                debug(''Loading data for single record'', l_first_reg_id);',
'                ',
'                -- Load existing evaluation data',
'                BEGIN',
'                    SELECT ',
'                        ET_VERWENDUNG,',
'                        NVL(ET_VORSCHLAG_VORSCHRIFT, ''-'') as ET_VORSCHLAG_VORSCHRIFT,',
'                        ET_KOMMENTAR,',
'                        FB_VERWENDUNG,',
'                        NVL(FB_VORSCHLAG_VORSCHRIFT, ''-'') as FB_VORSCHLAG_VORSCHRIFT,',
'                        FB_KOMMENTAR',
'                    INTO ',
'                        :P42_ET_VERWENDUNG,',
'                        :P42_ET_VORSCHLAG_VORSCHRIFT,',
'                        :P42_ET_KOMMENTAR,',
'                        :P42_FB_VERWENDUNG,',
'                        :P42_FB_VORSCHLAG_VORSCHRIFT,',
'                        :P42_FB_KOMMENTAR',
'                    FROM T_MS_BEWERTUNG',
'                    WHERE SUCHEID = :P42_SEARCH_SELECTION',
'                    AND MEILENSTEIN = :P42_MILESTONE_SELECTION',
'                    AND CARD_NUMBER = :P42_CARD_NUM',
'                    AND VORSCHRIFTID = l_first_reg_id',
'                    AND BENUTZERID = :G_BENUTZERID;',
'                    ',
'                    debug(''SUCCESS - ET_VERWENDUNG'', :P42_ET_VERWENDUNG);',
'                    debug(''SUCCESS - ET_KOMMENTAR'', :P42_ET_KOMMENTAR);',
'                    debug(''SUCCESS - FB_VERWENDUNG'', :P42_FB_VERWENDUNG);',
'                    debug(''SUCCESS - FB_KOMMENTAR'', :P42_FB_KOMMENTAR);',
'                    ',
'                EXCEPTION',
'                    WHEN NO_DATA_FOUND THEN',
'                        debug(''Data loading'', ''NO_DATA_FOUND'');',
'                    WHEN OTHERS THEN',
'                        debug(''Data loading ERROR'', SQLERRM);',
'                END;',
'            ELSE',
'                debug(''Multiple records selected'', ''Form will be empty for bulk entry'');',
'            END IF;',
'        END;',
'    ELSE',
'        debug(''No selected rows'', ''P42_SELECTED_ROWS is still null or empty'');',
'    END IF;',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        debug(''Before Header Process ERROR'', SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2684166731962896683
);
wwv_flow_imp.component_end;
end;
/
