prompt --application/pages/page_00603
begin
--   Manifest
--     PAGE: 00603
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>603
,p_name=>'MS Suchparameter Anzeigen'
,p_alias=>'MS-SUCHPARAMETER-ANZEIGEN'
,p_page_mode=>'MODAL'
,p_step_title=>'MS Suchparameter Anzeigen'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function loadLaenderShuttle() {',
'    var shuttleName = ''P325_FILTER_LAND'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadLaenderShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P325_FILTER_LAENDERGRUPPE''),',
'          x03: $v(''P325_STARTDATUM_TYP'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                console.log(pData);',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'function loadThemenShuttle() {',
'    var shuttleName = ''P325_FILTER_THEMEN'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lAntriebsart = $v(''P325_ANTRIEBSART'');',
'    var lArbeitskreis = $v(''P325_ARBEITSKREISE'');    ',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadThemenShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P325_FILTER_THEMEN_PRE''),',
'          x03: lAntriebsart,',
'          x04: lArbeitskreis',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'function updateLabelDatumSop() {',
'    var lItem = apex.item("P325_STARTDATUM_TYP");',
'    var lValue = lItem.getValue();',
'',
'    if (lValue == 20) {',
'    $("label[for=P325_DATUM_SOP]").text("Datum ME");',
'    } else {',
'    $("label[for=P325_DATUM_SOP]").text("Datum SOP");',
'    } ',
'}',
'',
'$(document).ready(function() {',
'   updateLabelDatumSop(); ',
'});',
'',
'$(''.shuttleSort2'').css(''display'', ''none'');',
'$(''.apex-item-wrapper--shuttle'').css(''padding-top'', ''0rem'');',
'',
'function addItemToShuttle(aShuttle, aID, aDisplay) {',
'    var lLeft = $(''#'' + aShuttle + ''_LEFT'');',
'    var lRight = $(''#'' + aShuttle + ''_RIGHT'');',
'    lLeft.find(''option[value='' + aID + '']'').remove();',
'    lRight.append(''<option value="'' + aID + ''">'' + aDisplay + ''</option>'');',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1200'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3918495465179342437)
,p_plug_name=>'Suchparameter'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(403346876725811986)
,p_plug_name=>'Trennlinie'
,p_parent_plug_id=>wwv_flow_imp.id(3918495465179342437)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>90
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<hr>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(403347032987811987)
,p_plug_name=>'Risikobewertung'
,p_parent_plug_id=>wwv_flow_imp.id(3918495465179342437)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>100
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1468670939358698908)
,p_plug_name=>unistr('Box Filter L\00E4nder')
,p_parent_plug_id=>wwv_flow_imp.id(3918495465179342437)
,p_region_template_options=>'#DEFAULT#:margin-left-md'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1468671004214698909)
,p_plug_name=>'Trennlinie'
,p_parent_plug_id=>wwv_flow_imp.id(3918495465179342437)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<hr>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1468671217041698911)
,p_plug_name=>'Box Filter Themen'
,p_parent_plug_id=>wwv_flow_imp.id(3918495465179342437)
,p_region_template_options=>'#DEFAULT#:margin-left-md'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1468671328216698912)
,p_plug_name=>'Trennlinie'
,p_parent_plug_id=>wwv_flow_imp.id(3918495465179342437)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<hr>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1468671466004698913)
,p_plug_name=>'Haupteinstellungen'
,p_parent_plug_id=>wwv_flow_imp.id(3918495465179342437)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3919296510929965925)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noBorder'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(400784053686886569)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3919296510929965925)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(400783659009886566)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3919296510929965925)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(400781569820886532)
,p_branch_name=>'Go To Page 450'
,p_branch_action=>'f?p=&APP_ID.:450:&SESSION.::&DEBUG.:RP,::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
,p_branch_condition_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_branch_condition=>'B_KOMMENTARE_PRUEFEN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(400790491038886593)
,p_name=>'P603_SUCHEID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3918495465179342437)
,p_prompt=>'Sucheid'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(400790092265886585)
,p_name=>'P603_SUCHE_INDEX'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3918495465179342437)
,p_prompt=>'Suche Meilenstein'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(400788775338886575)
,p_name=>'P603_FILTER_LAND'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1468670939358698908)
,p_prompt=>unistr('L\00E4nder')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select l.b_nummer || '' - '' || l.land, l.landid',
'from t_land l',
'where (:P603_FILTER_LAENDERGRUPPE is null or landid in (select landid from t_land_ref_laendergruppe where laendergruppeid = :P603_FILTER_LAENDERGRUPPE))',
'    and (:P603_STARTDATUM_TYP is null or startdatum_typ = :P603_STARTDATUM_TYP)',
'ORDER BY NLSSORT(l.B_NUMMER, ''NLS_SORT=BINARY_AI'') ASC'))
,p_cHeight=>4
,p_tag_css_classes=>'margin-bottom-none'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(400787807750886574)
,p_name=>'P603_FILTER_THEMEN'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1468671217041698911)
,p_prompt=>'Themengebiete'
,p_display_as=>'NATIVE_SHUTTLE'
,p_named_lov=>'LOV_THEMA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    NUMMER || '' - '' || ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN BEZEICHNUNG',
'        ELSE name_eng',
'    END as d,',
'    THEMAID as r',
'FROM V_THEMA_BAUM vtb',
'-- It excludes topics linked to et_b_akid = 1036 in t_thema_ref_et_b_ak, ensuring results are relevant to users without access to these excluded topics.',
'-- WHERE vtb.themaid not in (select themaid from t_thema_ref_et_b_ak where et_b_akid =1036 )',
'ORDER BY vtb.thema_sortorder;'))
,p_cHeight=>4
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(400786814916886572)
,p_name=>'P603_SUCHE_MODUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1468671466004698913)
,p_prompt=>'Suche Modus'
,p_source=>'0'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_YES_NO'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Bestehender Typ',
  'off_value', '10',
  'on_label', 'Neue Typen',
  'on_value', '0',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(400786340533886571)
,p_name=>'P603_DATUM_MEILENSTEIN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1468671466004698913)
,p_item_default=>'Sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Datum Meilenstein'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(400785945459886571)
,p_name=>'P603_STARTDATUM_TYP'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1468671466004698913)
,p_item_default=>'10'
,p_prompt=>'Art des Startdatums'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lResult number;',
'begin',
'    select l.startdatum_typ into lResult',
'    from t_land l',
'    where l.landid in (select column_value from TABLE(APEX_STRING.split_numbers(:P603_FILTER_LAND, '':'')))',
'    OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY;',
'    ',
'    return lResult;',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'    lResult := null;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_STARTDATUM_TYP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''SOP'', ''SOP'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Markteinf\00FChrung (ME)'', ''Market Introduction (MI)'') AS display_value,'),
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:margin-bottom-none'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(400785602899886570)
,p_name=>'P603_DATUM_SOP'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(1468671466004698913)
,p_prompt=>'Datum SOP'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(400785207386886570)
,p_name=>'P603_DATUM_EOP'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(1468671466004698913)
,p_prompt=>'Datum EOP'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(400784742745886570)
,p_name=>'P603_CKD_FBU_MODE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(1468671466004698913)
,p_item_default=>'0'
,p_prompt=>'FBU/CKD'
,p_display_as=>'NATIVE_YES_NO'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'CKD',
  'off_value', '1',
  'on_label', 'FBU',
  'on_value', '0',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(400782537932886540)
,p_name=>'CANCEL'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(400783659009886566)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(400782114482886535)
,p_event_id=>wwv_flow_imp.id(400782537932886540)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(400783268161886544)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LOAD_SUCHPARAMETER'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--  debug(''p603: Sucheid:''|| :P603_SUCHEID, ''P603_SUCHE_INDEX:''||:P603_SUCHE_INDEX);',
'select --d_ms,  sop, eop,    --   laender,  themen,         smode,         ckd_fbu_mode,',
'           l_risk,       h_risk',
'  into --:P603_DATUM_MEILENSTEIN, :P603_DATUM_SOP, :P603_DATUM_EOP,',
'        --:P603_FILTER_LAND, :P603_FILTER_THEMEN, :P603_SUCHE_MODUS, :P603_ckd_fbu_mode,',
'        :P603_LOW_RISK, :P603_HIGH_RISK',
' from (',
'            select sucheid, t.bezeichnung, t.beschreibung, row_number() over(order by t.meilenstein) rn, ',
'             t.ms d_ms,  t.sop sop, t.eop eop, ',
'                     t.laender laender, t.themen themen,   t.smode smode, t.ckd_fbu_mode ckd_fbu_mode,',
'                     t.l_risk l_risk, t.h_risk h_risk,  t.meilenstein meilenstein',
'              from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'                nested path ''$[*]'' COLUMNS(',
'                    laender varchar2(500) PATH ''$.LAENDER'',',
'                    themen varchar2(2000) path ''$.THEMEN'',',
'                    l_risk number path ''$.LOW_RISK'',',
'                    h_risk number path ''$.HIGH_RISK'',',
'                    ms varchar2(25) path ''$.DATUM_MEILENSTEIN'',',
'                    sop varchar2(25) path ''$.DATUM_SOP'',',
'                    eop varchar2(25) path ''$.DATUM_EOP'',',
'                    smode varchar2(20) path ''$.SUCHTYP'',',
'                    ckd_fbu_mode number path''$.CKD_FBU_MODE'',',
'                    meilenstein number path''$.MEILENSTEIN''',
'                    ))) t where sucheid = :P603_SUCHEID',
'          )  where meilenstein = :P603_SUCHE_INDEX;',
'      '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3271429047737501691
);
wwv_flow_imp.component_end;
end;
/
