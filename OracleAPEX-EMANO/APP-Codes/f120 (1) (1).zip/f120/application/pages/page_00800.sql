prompt --application/pages/page_00800
begin
--   Manifest
--     PAGE: 00800
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>800
,p_name=>'Report Nachfolger'
,p_alias=>'REPORT-NACHFOLGER'
,p_step_title=>'Report Nachfolger'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1805252507709351600)
,p_plug_name=>'Report Nachfolger'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'Select * from V_VORSCHRIFTEN_NACHFOLGER_END_DATE'
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_page_header=>'Report Nachfolger'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1805252641978351600)
,p_name=>'Report Nachfolger'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>2917945579073486004
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571961807956223900)
,p_db_column_name=>'VORSCHRIFT_LINK'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Permalink zum kopieren'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571957921210223897)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_column_linktext=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571961442920223898)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>21
,p_column_identifier=>'B'
,p_column_label=>'Vorschrift Nummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571961089439223898)
,p_db_column_name=>unistr('AU\00DFER_KRAFT')
,p_display_order=>31
,p_column_identifier=>'C'
,p_column_label=>unistr('Au\00DFer Kraft')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571960638938223898)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>41
,p_column_identifier=>'D'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571960308951223898)
,p_db_column_name=>'LETZTE_AENDER_DURCH'
,p_display_order=>51
,p_column_identifier=>'E'
,p_column_label=>'Letzte Aender Durch'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571959910212223898)
,p_db_column_name=>'NACHFOLGER'
,p_display_order=>61
,p_column_identifier=>'F'
,p_column_label=>'Nachfolger'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571959442720223897)
,p_db_column_name=>'NEUE_TYPEN'
,p_display_order=>71
,p_column_identifier=>'G'
,p_column_label=>'Neue Typen'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571959129834223897)
,p_db_column_name=>'ALLE_FZG'
,p_display_order=>81
,p_column_identifier=>'H'
,p_column_label=>'Alle Fzg'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571958724749223897)
,p_db_column_name=>'LINK_NACHFOLGER'
,p_display_order=>91
,p_column_identifier=>'I'
,p_column_label=>'Link Nachfolger'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571958248097223897)
,p_db_column_name=>'HINWEIS'
,p_display_order=>101
,p_column_identifier=>'J'
,p_column_label=>'Hinweisbox'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571957473407223896)
,p_db_column_name=>'NACHFOLGERID'
,p_display_order=>111
,p_column_identifier=>'L'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::P25_VORSCHRIFTID:#NACHFOLGERID#'
,p_column_linktext=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(912734566393980334)
,p_db_column_name=>'NICHT_MEHR_ANWENDBAR_PCV'
,p_display_order=>121
,p_column_identifier=>'M'
,p_column_label=>'Nicht Mehr Anwendbar PCV'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(912734417421980333)
,p_db_column_name=>'NICHT_MEHR_ANWENDBAR_CKD_PCV'
,p_display_order=>131
,p_column_identifier=>'N'
,p_column_label=>'Nicht Mehr Anwendbar CKD PCV'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(912734371818980332)
,p_db_column_name=>'NICHT_MEHR_ANWENDBAR_FBU_PCV'
,p_display_order=>141
,p_column_identifier=>'O'
,p_column_label=>'Nicht Mehr Anwendbar FBU PCV'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(912734314010980331)
,p_db_column_name=>'NEUE_TYPEN_CKD'
,p_display_order=>151
,p_column_identifier=>'P'
,p_column_label=>'Neue Typen CKD'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(912734159932980330)
,p_db_column_name=>'ALLE_FZG_CKD'
,p_display_order=>161
,p_column_identifier=>'Q'
,p_column_label=>'Alle FZG CKD'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1805258699812365617)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5407358'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>unistr('VORSCHRIFT_LINK:VORSCHRIFTID:VORSCHRIFT_NUMMER:NICHT_MEHR_ANWENDBAR_CKD_PCV:NICHT_MEHR_ANWENDBAR_FBU_PCV:NICHT_MEHR_ANWENDBAR_PCV:AU\00DFER_KRAFT:KOMMENTAR:LETZTE_AENDER_DURCH:HINWEIS:NACHFOLGERID:NACHFOLGER:ALLE_FZG_CKD:NEUE_TYPEN_CKD:NEUE_TYPEN:ALLE_FZ')
||'G:LINK_NACHFOLGER:'
);
wwv_flow_imp.component_end;
end;
/
