prompt --application/pages/page_00544
begin
--   Manifest
--     PAGE: 00544
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>544
,p_name=>'Einsatzdatum'
,p_alias=>'EINSATZDATUM'
,p_page_mode=>'MODAL'
,p_step_title=>'Einsatzdatum'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'function store_einsatzdaten() {',
'',
'var model = apex.region("ig_einsatzdaten").call("getViews").grid.model;',
'var keyEinsatzdatum = model.getFieldKey("EINSATZDATUM_TYP");',
'var keyEinsatzdatumId = model.getFieldKey("EINSATZDATUM_TYPID");',
'var keyDatum = model.getFieldKey("EINSATZDATUM");',
'var keyMJ = model.getFieldKey("MODELJAHR");',
'var keyBemerkung = model.getFieldKey("EINSATZDATUM_TEXT");',
'var anzRecords = model.getTotalRecords();',
'var array = [];',
'',
'//console.log(anzRecords);',
'',
'model.forEach(function(record, index, identity){',
'	var row = {',
'		einsatzDatum: record[keyEinsatzdatum],',
'		einsatzDatumId: record[keyEinsatzdatumId],',
'		datum: record[keyDatum],',
'        modeljahr: record[keyMJ],',
'		bemerkung: record[keyBemerkung]',
'	};',
'		',
'	array.push(row);',
'});',
'',
'  $s("P544_EINSATZDATEN", JSON.stringify(array));',
'  apex.page.submit(''PREVIOUS'');',
'}',
'//console.log($v("P544_EINSATZDATEN"));',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(631771686115396424)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(179012362273849688)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(712760182011977984)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3136226833217537561)
,p_plug_name=>'GRID_EINSATZDATEN'
,p_region_name=>'ig_einsatzdaten'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select edt.EINSATZDATUM_TYP,',
'  edt.EINSATZDATUM_TYPID,',
'    null as  einsatzdatum,',
'    case when (:P540_NEW_EINSATZDATUM_MODELLID=30 and edt.EINSATZDATUM_TYPID in (1060,1063, 1041,1030,1031) )',
'      then nvl2(vredt.Modeljahr, to_char(to_date(vredt.Modeljahr,''YYYY''), ''YYYY''), null)',
'      else null end Modeljahr,',
'    null as  einsatzdatum_text  ',
'from T_EINSATZDATUM_TYP edt',
'left outer join T_VORSCHRIFT_REF_EINSATZDATUM_TYP vredt on (vredt.einsatzdatum_typid = edt.einsatzdatum_typid',
'                                                              AND (vredt.vorschriftid is null ',
'                                                                OR vredt.vorschriftid = :P540_NEW_VORSCHRIFTID ))',
'where (',
'        (edt.einsatzdatum_modellid is null and  :P540_NEW_EINSATZDATUM_MODELLID != 20)',
'        OR (:P540_NEW_VORSCHRIFT_TYPID IN (10, 30, 40) AND edt.einsatzdatum_modellid = :P540_NEW_EINSATZDATUM_MODELLID)',
'        or (:P540_NEW_EINSATZDATUM_MODELLID = 20 and edt.EINSATZDATUM_TYPID = 1000)',
'      )',
'      and :P544_EINSATZDATEN IS NULL',
'      ',
'UNION ALL',
'',
' select jt.EINSATZDATUM_TYP,',
'   jt.EINSATZDATUM_TYPID,',
'   jt.einsatzdatum einsatzdatum,',
'   ',
'   case when (:P540_NEW_EINSATZDATUM_MODELLID=30 and jt.EINSATZDATUM_TYPID in (1060,1063, 1041,1030,1031) )',
'          then nvl2(jt.modeljahr, to_char(to_date(jt.modeljahr,''YYYY''), ''YYYY''), null)',
'          else null end Modeljahr,',
'   jt.einsatzdatum_text',
' FROM JSON_TABLE(',
'       :P544_EINSATZDATEN, ''$[*]'' COLUMNS (',
'           EINSATZDATUM_TYP    VARCHAR2(40 CHAR) PATH ''$.einsatzDatum'', ',
'           EINSATZDATUM_TYPID    number PATH ''$.einsatzDatumId'', ',
'           einsatzdatum    VARCHAR2(40 CHAR) PATH ''$.datum'', ',
'           modeljahr     VARCHAR2(40 CHAR) PATH ''$.modeljahr'', ',
'           einsatzdatum_text    VARCHAR2(250 CHAR) PATH ''$.bemerkung'' )',
'   ) jt',
' left outer join T_VORSCHRIFT_REF_EINSATZDATUM_TYP vredt on (vredt.einsatzdatum_typid = jt.einsatzdatum_typid',
'                                                              AND (vredt.vorschriftid is null ',
'                                                                OR vredt.vorschriftid = :P540_NEW_VORSCHRIFTID ))',
'    where :P544_EINSATZDATEN IS NOT NULL;',
'   '))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_read_only_when_type=>'NEVER'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1063831958798809855)
,p_name=>'MODELJAHR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MODELJAHR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Modeljahr'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_format_mask=>'YYYY'
,p_item_width=>4
,p_is_required=>false
,p_max_length=>4
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P540_NEW_EINSATZDATUM_MODELLID'
,p_display_condition2=>'30'
,p_readonly_condition_type=>'FUNCTION_BODY'
,p_readonly_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (:EINSATZDATUM_TYPID = 1000 or :EINSATZDATUM_TYPID = 1041 ) then',
unistr('    -- Datum in Kraft ist als Modeljahr nicht bearbeitbar sowie auch au\00DFer Kraft datum'),
'    return true;',
'elsif ( :P540_NEW_EINSATZDATUM_MODELLID =30  ) then',
'    -- Im Klardatumsmodus alle Modeljahrangaben bearbeitbar',
'    return false;',
'elsif ( :P540_NEW_EINSATZDATUM_MODELLID !=30 ) then',
'    -- Wenn kein  Modelljahres-Modus, dann nicht bearbeitbar',
'    return true;',
'else',
unistr('    -- Bearbeitungsmodus ist aus (keine Bearbeitung m\00F6glich)'),
'    return true;',
'end if;'))
,p_readonly_condition2=>'PLSQL'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3136227194264537565)
,p_name=>'EINSATZDATUM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EINSATZDATUM'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER'
,p_heading=>'Datum'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
,p_format_mask=>'DD.MM.YYYY'
,p_is_required=>false
,p_max_length=>160
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'FUNCTION_BODY'
,p_readonly_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (:EINSATZDATUM_TYPID = 1000  ) then',
'    -- Datum in Kraft ist immer bearbeitbar',
'    return false;',
'elsif ( :P540_NEW_EINSATZDATUM_MODELLID !=30  ) then',
'    -- Im Klardatumsmodus alle Datumsangaben bearbeitbar',
'    return false;',
'elsif (:P540_NEW_EINSATZDATUM_MODELLID =30 ) then',
'    -- Wenn Modelljahres-Modus, dann nicht bearbeitbar',
'    return true;',
'else',
unistr('    -- Bearbeitungsmodus ist aus (keine Bearbeitung m\00F6glich)'),
'    return true;',
'end if;'))
,p_readonly_condition2=>'PLSQL'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3136227239914537566)
,p_name=>'EINSATZDATUM_TEXT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EINSATZDATUM_TEXT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Bemerkung Datum'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>1000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3136228010951537573)
,p_name=>'EINSATZDATUM_TYP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EINSATZDATUM_TYP'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Einsatzdatum'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>160
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3136228225970537575)
,p_name=>'EINSATZDATUM_TYPID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EINSATZDATUM_TYPID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>70
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(3136226918019537562)
,p_internal_uid=>4248919855114671966
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>false
,p_no_data_found_message=>'Es wurden noch keine Einsatzdaten zugeordnet.'
,p_show_toolbar=>false
,p_toolbar_buttons=>null
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>true
,p_fixed_header=>'NONE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(3136323540996233629)
,p_interactive_grid_id=>wwv_flow_imp.id(3136226918019537562)
,p_static_id=>'715943'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(3136323701734233629)
,p_report_id=>wwv_flow_imp.id(3136323540996233629)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1041084726510590809)
,p_view_id=>wwv_flow_imp.id(3136323701734233629)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(1063831958798809855)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3136325200386233635)
,p_view_id=>wwv_flow_imp.id(3136323701734233629)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(3136227194264537565)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3136325669786233636)
,p_view_id=>wwv_flow_imp.id(3136323701734233629)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(3136227239914537566)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3136381094069718217)
,p_view_id=>wwv_flow_imp.id(3136323701734233629)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(3136228010951537573)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3136486281369462770)
,p_view_id=>wwv_flow_imp.id(3136323701734233629)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(3136228225970537575)
,p_is_visible=>true
,p_is_frozen=>false
,p_sort_order=>1
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(631771312781396423)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(631771686115396424)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(631768888660396408)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(631771686115396424)
,p_button_name=>'NEXT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Verkn\00FCpfungen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(631752008453977169)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(631771686115396424)
,p_button_name=>'PREVIOUS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(632210556401546192)
,p_branch_name=>'Go to Page 541'
,p_branch_action=>'f?p=&APP_ID.:541:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(631768888660396408)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(632210497535546191)
,p_branch_name=>'Go To Page 540'
,p_branch_action=>'f?p=&APP_ID.:540:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(631752008453977169)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1040360733432747099)
,p_name=>'P544_PHASEIN_ENTHALTEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3136226833217537561)
,p_prompt=>'<b><font size="3">Sind Phase in''s enthalten?</font></b>'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:;1'
,p_display_when=>'P540_NEW_EINSATZDATUM_MODELLID'
,p_display_when2=>'30'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(631749963814793381)
,p_name=>'P544_VORSCHRIFTNUMMER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3136226833217537561)
,p_use_cache_before_default=>'NO'
,p_source=>'P540_VORSCHRIFTNUMMER'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(605817327063152676)
,p_name=>'P544_EINSATZDATEN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(3136226833217537561)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(631771224731396423)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(631771312781396423)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(631770345540396416)
,p_event_id=>wwv_flow_imp.id(631771224731396423)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(605817529105152678)
,p_name=>'store Einsatzdaten'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(631768888660396408)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(605817432528152677)
,p_event_id=>wwv_flow_imp.id(605817529105152678)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var model = apex.region("ig_einsatzdaten").call("getViews").grid.model;',
'var keyEinsatzdatum = model.getFieldKey("EINSATZDATUM_TYP");',
'var keyEinsatzdatumId = model.getFieldKey("EINSATZDATUM_TYPID");',
'var keyDatum = model.getFieldKey("EINSATZDATUM");',
'var keyMJ = model.getFieldKey("MODELJAHR");',
'var keyBemerkung = model.getFieldKey("EINSATZDATUM_TEXT");',
'var anzRecords = model.getTotalRecords();',
'var array = [];',
'',
'console.log(anzRecords);',
'',
'model.forEach(function(record, index, identity){',
'	var row = {',
'		einsatzDatum: record[keyEinsatzdatum],',
'		einsatzDatumId: record[keyEinsatzdatumId],',
'		datum: record[keyDatum],',
'        modeljahr: record[keyMJ],',
'		bemerkung: record[keyBemerkung]',
'	};',
'		',
'	array.push(row);',
'});',
'',
'$s("P544_EINSATZDATEN", JSON.stringify(array));',
'',
'console.log($v("P544_EINSATZDATEN"));',
'',
'apex.page.submit(''NEXT'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1040360226061747094)
,p_name=>'Store Einsatzdaten'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(631752008453977169)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1040360073293747093)
,p_event_id=>wwv_flow_imp.id(1040360226061747094)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var model = apex.region("ig_einsatzdaten").call("getViews").grid.model;',
'var keyEinsatzdatum = model.getFieldKey("EINSATZDATUM_TYP");',
'var keyEinsatzdatumId = model.getFieldKey("EINSATZDATUM_TYPID");',
'var keyDatum = model.getFieldKey("EINSATZDATUM");',
'var keyMJ = model.getFieldKey("MODELJAHR");',
'var keyBemerkung = model.getFieldKey("EINSATZDATUM_TEXT");',
'var anzRecords = model.getTotalRecords();',
'var array = [];',
'',
'//console.log(anzRecords);',
'',
'model.forEach(function(record, index, identity){',
'	var row = {',
'		einsatzDatum: record[keyEinsatzdatum],',
'		einsatzDatumId: record[keyEinsatzdatumId],',
'		datum: record[keyDatum],',
'        modeljahr: record[keyMJ],',
'		bemerkung: record[keyBemerkung]',
'	};',
'		',
'	array.push(row);',
'});',
'',
'  $s("P544_EINSATZDATEN", JSON.stringify(array));',
'  apex.page.submit(''PREVIOUS'');'))
);
wwv_flow_imp.component_end;
end;
/
