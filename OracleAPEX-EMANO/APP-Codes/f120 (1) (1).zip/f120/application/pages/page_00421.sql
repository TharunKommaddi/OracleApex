prompt --application/pages/page_00421
begin
--   Manifest
--     PAGE: 00421
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>421
,p_name=>'Regulierungsverantwortlichkeit bestaetigen'
,p_alias=>'REV'
,p_step_title=>'Regulierungsverantwortlichkeit bestaetigen'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'function delete_fun(){',
'    // alert(''TEST'');',
'    apex.submit(''DELETE'');',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    var grid$ = apex.region("ig_vorschr").call("getCurrentView").view$;',
'',
'        grid$.grid("hideColumn","NEUER_VERANTWORTLICHERID");',
''))
,p_step_template=>wwv_flow_imp.id(3414110812204820537)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8065737935309942452)
,p_plug_name=>'Regulierungsverantwortlichkeit bearbeiten <span onclick="redirect(1500)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3163689675621928899)
,p_plug_name=>unistr('Best\00E4tigen / Ablehnen <span onclick="redirect(1501)" style="font-size:1.5em" class="fa fa-question-square-o"></span>')
,p_parent_plug_id=>wwv_flow_imp.id(8065737935309942452)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7650682053910907628)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_imp.id(8065737935309942452)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7652387339229432195)
,p_plug_name=>'Neuen Verantwortlichen zuordnen <span onclick="redirect(1502)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'
,p_parent_plug_id=>wwv_flow_imp.id(8065737935309942452)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8367128900889231457)
,p_plug_name=>unistr('Vorschriften und Hauptumsetzende OE f\00FCr SW-Relevanz')
,p_region_name=>'ig_vorschr'
,p_parent_plug_id=>wwv_flow_imp.id(8065737935309942452)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'vrv.VORSCHRIFT_REF_VERANTWORTLICHERID as VORSCHRIFT_REF_VERANTWORTLICHERID,',
'1 as link_details,',
'vo.vorschriftid as Vorschriftid,',
'vo.vorschrift_nummer as Vorschrift,',
unistr('decode(vo.RXSWIN, 10, ''ja'', 0, ''nein'', 20, ''nicht gepr\00FCft'') as potentiell_sums_relevant,'),
'vo.swr_hauptumsetzende_oe as hauptumsetzende_oe, ',
'CASE vrv.ist_Hauptverantwortlicher',
'        WHEN 10 THEN ''Hauptverantwortlicher''',
'        WHEN 20 THEN ''Nebenverantwortlicher''',
'END AS Ist_Hauptverantwortlicher,',
'--vrv.STATUS_BESTAETIGUNG AS VERANTWORTLICH,',
'rev_ctrl_vorschrift.rev_kontrolle_id,',
'rev_ctrl_vorschrift.STATUS AS VERANTWORTLICH_TEST,',
'rev_ctrl_vorschrift.neuer_verantwortlicherid,',
'rev_ctrl_vorschrift.rev_kontrolle_vorschrift_id,',
'case when ben.benutzerid is not null then ben.vorname || '', '' || ben.nachname else '''' end as NEUER_VERANTWORTLICHER',
'from t_vorschrift vo ',
'join t_vorschrift_ref_verantwortlicher vrv on (vrv.vorschriftid = vo.vorschriftid)',
'join t_rev_kontrolle rev_ctrl on rev_ctrl.verantwortlicherid = vrv.verantwortlicherid ',
'join T_REV_KONTROLLE_VORSCHRIFT rev_ctrl_vorschrift on (rev_ctrl_vorschrift.vorschriftid = vo.vorschriftid and rev_ctrl_vorschrift.rev_kontrolle_id = rev_ctrl.rev_kontrolle_id)',
'left join t_benutzer ben on ben.benutzerid = rev_ctrl_vorschrift.neuer_verantwortlicherid',
'where rev_ctrl.rev_kontrolle_id = :P421_REV_KONTROLLE_ID',
''))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P421_VERANTWORTLICHERID'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Vorschriften und Hauptumsetzende OE f\00FCr SW-Relevanz')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3163689899375928901)
,p_name=>'NEUER_VERANTWORTLICHERID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NEUER_VERANTWORTLICHERID'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>180
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3163689725608928900)
,p_name=>'REV_KONTROLLE_VORSCHRIFT_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'REV_KONTROLLE_VORSCHRIFT_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>190
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2033629206361372207)
,p_name=>'LINK_DETAILS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LINK_DETAILS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_LINK'
,p_heading=>'&nbsp;'
,p_label=>'Details'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>170
,p_value_alignment=>'CENTER'
,p_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:25'
,p_link_text=>'<span class="fa fa-search"></span>'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7650678900481907596)
,p_name=>'VORSCHRIFT_REF_VERANTWORTLICHERID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFT_REF_VERANTWORTLICHERID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7650679280361907600)
,p_name=>'VORSCHRIFTID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFTID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>70
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7650679365452907601)
,p_name=>'VORSCHRIFT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Vorschriften Nummer'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7650679510428907602)
,p_name=>'POTENTIELL_SUMS_RELEVANT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'POTENTIELL_SUMS_RELEVANT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Potentiell SUMS-Relevant'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7650679620560907603)
,p_name=>'HAUPTUMSETZENDE_OE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HAUPTUMSETZENDE_OE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'OE2 des REV'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7650679679407907604)
,p_name=>'IST_HAUPTVERANTWORTLICHER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IST_HAUPTVERANTWORTLICHER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Ist Hauptverantwortlicher'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7650681052827907618)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'Y',
  'hide_control', 'N',
  'show_select_all', 'Y')).to_clob
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7650683413286907641)
,p_name=>'NEUER_VERANTWORTLICHER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NEUER_VERANTWORTLICHER'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Neuer Verantwortlicher'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>3202
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7663448221384281998)
,p_name=>'VERANTWORTLICH_TEST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VERANTWORTLICH_TEST'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_RADIOGROUP'
,p_heading=>'Status Verantwortlichkeit'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_is_required=>false
,p_lov_type=>'STATIC'
,p_lov_source=>unistr('STATIC2:best\00E4tigt;10,abgelehnt;20')
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>false
,p_include_in_export=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7663448489312282001)
,p_name=>'REV_KONTROLLE_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'REV_KONTROLLE_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>60
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(7650678765557907595)
,p_internal_uid=>11322891081457295830
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>false
,p_fixed_row_height=>false
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:RESET'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(7650687301139907973)
,p_interactive_grid_id=>wwv_flow_imp.id(7650678765557907595)
,p_static_id=>'4721577'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(7650687495047907974)
,p_report_id=>wwv_flow_imp.id(7650687301139907973)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1073480921246063003)
,p_view_id=>wwv_flow_imp.id(7650687495047907974)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(3163689899375928901)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1073476459044989729)
,p_view_id=>wwv_flow_imp.id(7650687495047907974)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(3163689725608928900)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(2033943725491974051)
,p_view_id=>wwv_flow_imp.id(7650687495047907974)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(2033629206361372207)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>40
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(7650687991464907981)
,p_view_id=>wwv_flow_imp.id(7650687495047907974)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(7650678900481907596)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(7650691597582907999)
,p_view_id=>wwv_flow_imp.id(7650687495047907974)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(7650679280361907600)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(7650692467083908001)
,p_view_id=>wwv_flow_imp.id(7650687495047907974)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(7650679365452907601)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(7650693347770908003)
,p_view_id=>wwv_flow_imp.id(7650687495047907974)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(7650679510428907602)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(7650694255648908006)
,p_view_id=>wwv_flow_imp.id(7650687495047907974)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(7650679620560907603)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(7650695217195908008)
,p_view_id=>wwv_flow_imp.id(7650687495047907974)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(7650679679407907604)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(7650845447647845492)
,p_view_id=>wwv_flow_imp.id(7650687495047907974)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(7650683413286907641)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(7663453742107318486)
,p_view_id=>wwv_flow_imp.id(7650687495047907974)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(7663448221384281998)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(7663458846976503875)
,p_view_id=>wwv_flow_imp.id(7650687495047907974)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(7663448489312282001)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1073515899279211091)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(7650682053910907628)
,p_button_name=>'Vorschrifthinzufuegen'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Vorschrift hinzuf\00FCgen')
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:422:&SESSION.::&DEBUG.:422:P422_VERANTWORTLICHERID:&P421_VERANTWORTLICHERID.'
,p_button_condition=>'P421_VERANTWORTLICHERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3163689495292928897)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8065737935309942452)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Alle \00C4nderungen speichern')
,p_button_position=>'COPY'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1073509241159211081)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3163689675621928899)
,p_button_name=>'APPROVE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'Approve'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-check'
,p_button_cattributes=>'style="background-color:green"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1073507331740211078)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(7652387339229432195)
,p_button_name=>'SEARCH_LDAP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'In LDAP suchen'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:65:&SESSION.::&DEBUG.:65:P65_CAMEFROM:421'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1073508915158211080)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3163689675621928899)
,p_button_name=>'REJECT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'Reject'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-window-close-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1073506973093211078)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(7652387339229432195)
,p_button_name=>'SET_VERANTWORTLICHER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Verantwortlichen setzen'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3163689981140928902)
,p_name=>'P421_NEUER_VERANTWORTLICHER_ID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(7652387339229432195)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1073517752445211094)
,p_name=>'P421_VERANTWORTLICHERID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8065737935309942452)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1073517318436211092)
,p_name=>'P421_NACHNAME'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(8065737935309942452)
,p_prompt=>'Nachname'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1073517005697211092)
,p_name=>'P421_VORNAME'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(8065737935309942452)
,p_prompt=>'Vorname'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1073516526318211091)
,p_name=>'P421_REV_KONTROLLE_ID'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(8065737935309942452)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1073515449380211090)
,p_name=>'P421_GID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(7650682053910907628)
,p_prompt=>'GID'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1073515039833211090)
,p_name=>'P421_READ_TRACKING_CODE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(7650682053910907628)
,p_prompt=>'Tracking Code'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1073508459704211080)
,p_name=>'P421_SELECTED_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8367128900889231457)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1073506571641211078)
,p_name=>'P421_NEUER_VERANTWORTLICHER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8367128900889231457)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1073505892536211077)
,p_name=>'P421_NEUER_VERANTWORTLICHER_DISPLAY'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(7652387339229432195)
,p_prompt=>'Neuer Verantwortlicher'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1073504315868211075)
,p_name=>'Edit - P422 closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(8367128900889231457)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1073503807965211075)
,p_event_id=>wwv_flow_imp.id(1073504315868211075)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P421_DELETE_CONDITION'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1073503263596211075)
,p_event_id=>wwv_flow_imp.id(1073504315868211075)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8367128900889231457)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1073502904759211074)
,p_name=>'Create - P422 closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1073515899279211091)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1073502402535211074)
,p_event_id=>wwv_flow_imp.id(1073502904759211074)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8367128900889231457)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1073501851013211074)
,p_event_id=>wwv_flow_imp.id(1073502904759211074)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P421_DELETE_CONDITION'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1073501469499211074)
,p_name=>'Change'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(8367128900889231457)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1073500923914211073)
,p_event_id=>wwv_flow_imp.id(1073501469499211074)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i, selectedIds = "",',
'model = this.data.model;',
'for ( i = 0; i < this.data.selectedRecords.length; i++ ) {',
'    selectedIds += model.getValue( this.data.selectedRecords[i], "VORSCHRIFT_REF_VERANTWORTLICHERID") + ":";',
'}',
'$s("P421_SELECTED_ID", selectedIds);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1073500575476211073)
,p_name=>'reject'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1073508915158211080)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1073500078293211073)
,p_event_id=>wwv_flow_imp.id(1073500575476211073)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var model = apex.region("ig_vorschr").widget().interactiveGrid("getViews", "grid").model;',
'var records = apex.region("ig_vorschr").call("getViews").grid.getSelectedRecords();',
'for ( i = 0; i < records.length; i++ ) {',
'    model.setValue(records[i], "VERANTWORTLICH_TEST", ''20'');',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1073499619485211072)
,p_name=>'approve'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1073509241159211081)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1073499158443211072)
,p_event_id=>wwv_flow_imp.id(1073499619485211072)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var model = apex.region("ig_vorschr").widget().interactiveGrid("getViews", "grid").model;',
'var records = apex.region("ig_vorschr").call("getViews").grid.getSelectedRecords();',
'for ( i = 0; i < records.length; i++ ) {',
'    model.setValue(records[i], "VERANTWORTLICH_TEST", ''10'');',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1073498804166211072)
,p_name=>'set_new_rev'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1073506973093211078)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1073498242601211071)
,p_event_id=>wwv_flow_imp.id(1073498804166211072)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var model = apex.region("ig_vorschr").widget().interactiveGrid("getViews", "grid").model;',
'var records = apex.region("ig_vorschr").call("getViews").grid.getSelectedRecords();',
'var new_rev = $v(''P421_NEUER_VERANTWORTLICHER_DISPLAY'');',
'var new_revid = $v(''P421_NEUER_VERANTWORTLICHER_ID'');',
'for ( i = 0; i < records.length; i++ ) {',
'    model.setValue(records[i], "NEUER_VERANTWORTLICHER", new_rev);',
'    model.setValue(records[i], "NEUER_VERANTWORTLICHERID", new_revid);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3163690181737928904)
,p_name=>'Dialog closed'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1073507331740211078)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3163690081229928903)
,p_event_id=>wwv_flow_imp.id(3163690181737928904)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P421_NEUER_VERANTWORTLICHER_ID := pck_ri.fCreatePlaceHolderUser(:P65_GID_CHOSEN);',
'select nachname || '', '' || vorname || '' ('' || abteilung || '')'' into :P421_NEUER_VERANTWORTLICHER_DISPLAY',
'from t_benutzer',
'where benutzerid = :P421_NEUER_VERANTWORTLICHER_ID;'))
,p_attribute_02=>'P65_GID_CHOSEN'
,p_attribute_03=>'P421_NEUER_VERANTWORTLICHER_ID,P421_NEUER_VERANTWORTLICHER_DISPLAY'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1073508020013211080)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(8367128900889231457)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Grid Verantwortlichstatus'
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'lverantwortlicherid number;',
'lvorschriftid number;',
'lrev_kontrolleid number;',
'lzeitpunkt date;',
'begin',
'',
'    select verantwortlicherid, vorschriftid into lverantwortlicherid, lvorschriftid from t_vorschrift_ref_verantwortlicher',
'    where vorschrift_ref_verantwortlicherid = :VORSCHRIFT_REF_VERANTWORTLICHERID;',
'',
'    update t_vorschrift_ref_verantwortlicher ',
'    set status_bestaetigung = :VERANTWORTLICH_TEST, zeitpunkt_status = sysdate()',
'    where vorschrift_ref_verantwortlicherid = :VORSCHRIFT_REF_VERANTWORTLICHERID;',
'',
'    update t_rev_kontrolle',
'    set zeitpunkt_erste_taetigkeit = nvl(zeitpunkt_erste_taetigkeit, sysdate)',
'    where rev_kontrolle_id = :P421_REV_KONTROLLE_ID;',
'',
'    update t_rev_kontrolle_vorschrift',
'    set status = :VERANTWORTLICH_TEST, neuer_verantwortlicherid = :NEUER_VERANTWORTLICHERID,',
'    letzte_aenderung_datum = sysdate, letzte_aenderung_benutzer_id = :G_BENUTZERID',
'    where rev_kontrolle_vorschrift_id = :REV_KONTROLLE_VORSCHRIFT_ID;',
'',
'',
'end;'))
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2598704295886177155
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3163689584801928898)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Status Kontrolle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lAnzahl number;',
'begin',
'    select count(*) into lAnzahl',
'    from t_rev_kontrolle_vorschrift',
'    where status = 0',
'    and rev_kontrolle_id = :P421_REV_KONTROLLE_ID;',
'',
'    if lAnzahl = 0 then',
'        update t_rev_kontrolle set zeitpunkt_abschluss = nvl(zeitpunkt_abschluss,sysdate), status = case when status in (10,20) then 30 else status end',
'        where rev_kontrolle_id = :P421_REV_KONTROLLE_ID;',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>508522731097459337
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1073505034988211076)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Initialize form Regulierungsverantwortlichkeit bearbeiten'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'lCount number;',
'begin',
'select distinct v.verantwortlicherid, v.nachname, v.vorname, v.gid, rk.rev_kontrolle_id',
'into :P421_VERANTWORTLICHERID,:P421_NACHNAME,:P421_VORNAME,:P421_GID, :P421_REV_KONTROLLE_ID',
' from T_REV_KONTROLLE rk',
' join t_verantwortlicher v on v.verantwortlicherid = rk.verantwortlicherid',
' where wert_hash like :P421_READ_TRACKING_CODE;',
'',
' select count(zeitpunkt_klick) into lCount from T_REV_KONTROLLE',
' where wert_hash like :P421_READ_TRACKING_CODE',
' and status = 10;',
' if (lCount < 1) then',
'    update T_REV_KONTROLLE set zeitpunkt_klick = sysdate where wert_hash like :P421_READ_TRACKING_CODE',
'    and status = 10;',
' end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2598707280911177159
);
wwv_flow_imp.component_end;
end;
/
