prompt --application/pages/page_00141
begin
--   Manifest
--     PAGE: 00141
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>141
,p_name=>'Backup Mehrfachbearbeitung'
,p_page_mode=>'MODAL'
,p_step_title=>'Backup Mehrfachbearbeitung'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(2652734963787598041)
,p_dialog_height=>'800'
,p_dialog_width=>'1400'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2879488440281891439)
,p_plug_name=>'Content'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1271420241133853823)
,p_plug_name=>'<input id="toggleRegion" region="SEARCH_REPLACE" type="checkbox" /> Suchen und Ersetzen'
,p_parent_plug_id=>wwv_flow_imp.id(2879488440281891439)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1271420323207853824)
,p_plug_name=>'Info'
,p_parent_plug_id=>wwv_flow_imp.id(1271420241133853823)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('In diesem Bereich k\00F6nnen Teile von Text-Attributen der Vorschriften ersetzt werden.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1271420484425853826)
,p_plug_name=>'Suchen & Ersetzen-Parameter'
,p_parent_plug_id=>wwv_flow_imp.id(1271420241133853823)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1271421000140853831)
,p_name=>'Vorschau'
,p_parent_plug_id=>wwv_flow_imp.id(1271420241133853823)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with selected_vorschriften as (',
'    select regexp_substr(:P141_SELECTED_VORSCHRIFTEN, ''[^:]+'', 1, level) selected_vorschriftid',
'    from dual',
'    connect by level <= regexp_count(:P141_SELECTED_VORSCHRIFTEN, '':'') + 1',
'),',
'selected_attribut as (',
'    select vorschriftid, case to_char(:P141_TEXT_ATTRIBUT)',
'        when ''10'' then vorschrift_nummer',
'        when ''20'' then vorschrift_bezeichnung',
'        when ''30'' then bemerkung',
'        when ''40'' then LINK_ZUR_VORSCHRIFT_DMS',
'        when ''50'' then LINK_ZUR_VORSCHRIFT_GETEX',
'        when ''60'' then WEBSITELINK',
'    end attribut_wert',
'    from t_vorschrift',
')',
'select vs.vorschrift_nummer, sa.attribut_wert Alter_Wert, case to_char(:P141_REGEX_PLAIN)',
'        when ''0'' then replace(sa.attribut_wert, :P141_SEARCH_TEXT, :P141_REPLACE_TEXT) ',
'        when ''1'' then regexp_replace(sa.attribut_wert, :P141_SEARCH_TEXT, :P141_REPLACE_TEXT) ',
'     end Neuer_Wert',
'from t_vorschrift vs',
'join selected_vorschriften sv on sv.selected_vorschriftid = vs.vorschriftid',
'join selected_attribut sa on sa.vorschriftid = vs.vorschriftid',
'',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P141_TEXT_ATTRIBUT,P141_REGEX_PLAIN,P141_SEARCH_TEXT,P141_REPLACE_TEXT'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(213204055813504954)
,p_query_column_id=>1
,p_column_alias=>'VORSCHRIFT_NUMMER'
,p_column_display_sequence=>1
,p_column_heading=>'Vorschrift Nummer'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(213204431199504957)
,p_query_column_id=>2
,p_column_alias=>'ALTER_WERT'
,p_column_display_sequence=>2
,p_column_heading=>unistr('Ausgew\00E4hlte Spalte')
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P141_TEXT_ATTRIBUT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(213204826677504957)
,p_query_column_id=>3
,p_column_alias=>'NEUER_WERT'
,p_column_display_sequence=>3
,p_column_heading=>'Neuer Wert'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P141_SEARCH_TEXT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2879488663775891441)
,p_plug_name=>'<input id="toggleRegion" region="ATTRIBUTE" type="checkbox" /> Attribute'
,p_parent_plug_id=>wwv_flow_imp.id(2879488440281891439)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2879489091019891445)
,p_plug_name=>'Info'
,p_parent_plug_id=>wwv_flow_imp.id(2879488663775891441)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('In diesem Bereich k\00F6nnen Attributwerte zugeordnet werden. Bereits existierende Werte werden \00FCberschrieben.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2879489496029891449)
,p_plug_name=>'Container left'
,p_parent_plug_id=>wwv_flow_imp.id(2879488663775891441)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2879489598073891450)
,p_plug_name=>'Container right'
,p_parent_plug_id=>wwv_flow_imp.id(2879488663775891441)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2879488773625891442)
,p_plug_name=>'<input id="toggleRegion" region="WEBSITES" type="checkbox" /> Websites'
,p_parent_plug_id=>wwv_flow_imp.id(2879488440281891439)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2879490247038891457)
,p_plug_name=>'Info'
,p_parent_plug_id=>wwv_flow_imp.id(2879488773625891442)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('In diesem Bereich k\00F6nnen Websites erg\00E4nzt werden. Sollte eine Vorschrift bereits einen entsprechenden Link haben, so bleibt dieser bestehen und wird nicht \00FCberschrieben.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2879490802633891462)
,p_plug_name=>'Container'
,p_parent_plug_id=>wwv_flow_imp.id(2879488773625891442)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2879488909280891443)
,p_plug_name=>unistr('<input id="toggleRegion" region="LAENDER" type="checkbox" /> Themengebiete nach L\00E4ndern kopieren')
,p_parent_plug_id=>wwv_flow_imp.id(2879488440281891439)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2879491244842891467)
,p_plug_name=>'Info'
,p_parent_plug_id=>wwv_flow_imp.id(2879488909280891443)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('In diesem Bereich k\00F6nnen die Zuordnungen zu den Themengebieten von einem Quellland auf ein Zielland kopiert werden.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2879491329734891468)
,p_plug_name=>'Quellland'
,p_parent_plug_id=>wwv_flow_imp.id(2879488909280891443)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2879491499367891469)
,p_plug_name=>'Zielland'
,p_parent_plug_id=>wwv_flow_imp.id(2879488909280891443)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2890595764390140583)
,p_plug_name=>unistr('<input id="toggleRegion" region="THEMEN" type="checkbox" /> L\00E4nder nach Themengebieten kopieren')
,p_parent_plug_id=>wwv_flow_imp.id(2879488440281891439)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2891911898453352138)
,p_plug_name=>'Info'
,p_parent_plug_id=>wwv_flow_imp.id(2890595764390140583)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('In diesem Bereich k\00F6nnen die Zuordnungen zu den L\00E4ndern von einem Quell-Themengebiet auf ein Ziel-Themengebiet kopiert werden.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2891912025706352139)
,p_plug_name=>'Ziel-Themengebiet'
,p_parent_plug_id=>wwv_flow_imp.id(2890595764390140583)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2891912051319352140)
,p_plug_name=>'Quell-Themengebiet'
,p_parent_plug_id=>wwv_flow_imp.id(2890595764390140583)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2879488596139891440)
,p_plug_name=>'Dialog footer'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(213205251442504957)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1271421000140853831)
,p_button_name=>'BTN_SEARCH_PREVIEW'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Vorschau aktualisieren'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(213205672799504958)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1271421000140853831)
,p_button_name=>'BTN_SEARCH_SAVE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Suchen und Ersetzen ausf\00FChren')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'apex_disabled'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(213199330774504932)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2879488596139891440)
,p_button_name=>'APPLY'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00C4nderungen \00FCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(213199758411504935)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2879488596139891440)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213200459275504942)
,p_name=>'P141_SELECTED_VORSCHRIFTEN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2879488440281891439)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213201187720504948)
,p_name=>'P141_REGION_SEARCH_REPLACE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1271420241133853823)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213202168448504949)
,p_name=>'P141_TEXT_ATTRIBUT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1271420484425853826)
,p_prompt=>'Attribut/Tabellenspalte'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'STATIC:',
'Vorschriftennummer;10,',
unistr('Titel (\00DCberschrift);20,'),
'Bemerkung zur Vorschrift;30,',
'Link zu DMS;40, ',
'Link zu GETEX;50, ',
'Link zu Web Site;60'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('W\00E4hlen Sie das Attribut/Tabellenspalte aus')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213202535767504950)
,p_name=>'P141_REGEX_PLAIN'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1271420484425853826)
,p_prompt=>'Art der Suche'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Einfacher Text',
  'off_value', '0',
  'on_label', unistr('Regul\00E4rer Ausdruck'),
  'on_value', '1',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213202939031504950)
,p_name=>'P141_SEARCH_TEXT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1271420484425853826)
,p_prompt=>'Suchen nach'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213203380080504950)
,p_name=>'P141_REPLACE_TEXT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1271420484425853826)
,p_prompt=>'Ersetzen durch'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213206311654504958)
,p_name=>'P141_REGION_THEMEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2890595764390140583)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213207354437504960)
,p_name=>'P141_Z_THEMA_PRE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2891912025706352139)
,p_prompt=>'Suche'
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" id="#zPre"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213207773628504961)
,p_name=>'P141_Z_THEMA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2891912025706352139)
,p_prompt=>'Thema'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUMMER || '' - '' || BEZEICHNUNG as d,',
'       THEMAID as r',
'from V_THEMA_BAUM',
'where :P141_Z_THEMA_PRE is null',
'    or instr(upper(NUMMER || '' - '' || BEZEICHNUNG),upper(:P141_Z_THEMA_PRE)) != 0'))
,p_lov_cascade_parent_items=>'P141_Z_THEMA_PRE'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213208449433504962)
,p_name=>'P141_Q_THEMA_PRE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2891912051319352140)
,p_prompt=>'Suche'
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" id="#zPre"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213208858838504962)
,p_name=>'P141_Q_THEMA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2891912051319352140)
,p_prompt=>'Thema'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUMMER || '' - '' || BEZEICHNUNG as d,',
'       THEMAID as r',
'from V_THEMA_BAUM',
'where :P141_Q_THEMA_PRE is null',
'    or instr(upper(NUMMER || '' - '' || BEZEICHNUNG),upper(:P141_Q_THEMA_PRE)) != 0'))
,p_lov_cascade_parent_items=>'P141_Q_THEMA_PRE'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213209509414504962)
,p_name=>'P141_REGION_ATTRIBUTE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2879488663775891441)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213210522906504963)
,p_name=>'P141_EINSATZDATUM_MODELL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2879489496029891449)
,p_prompt=>'Einsatzdatum Modell'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select modell, einsatzdatum_modellid',
'from t_einsatzdatum_modell',
'order by einsatzdatum_modellid asc'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213210910487504964)
,p_name=>'P141_VORSCHRIFT_BEZEICHNUNG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2879489496029891449)
,p_prompt=>unistr('Titel (\00DCberschrift)')
,p_placeholder=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>300
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213211386748504964)
,p_name=>'P141_PROGNOSE_QUALITAET'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2879489496029891449)
,p_prompt=>unistr('Prognose Qualit\00E4t')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VORSCHRIFT_PROGNOSE_QUALITAET'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''offen'', ''open'') AS display_value,',
'        0 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''sicher'', ''secure'') AS display_value,',
'        10 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'    ',
'    UNION ALL',
'    ',
'    SELECT ',
unistr('        emano_util.fLang(''absch\00E4tzbar'', ''estimable'') AS display_value,'),
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213211789492504965)
,p_name=>'P141_FREIGABESTATUS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2879489496029891449)
,p_prompt=>'Interner DB Freigabestatus'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VORSCHRIFT_FREIGABE_STATUS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vorschrift_freigabestatusid as actual_value, emano_util.fLang(name_deutsch,name_englisch) as display_value',
'from t_vorschrift_freigabestatus',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213212190789504965)
,p_name=>'P141_RXSWIN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2879489496029891449)
,p_prompt=>'potentiell RxSWIN-Relevant'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Ja;10,Nein;0'
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213212889911504966)
,p_name=>'P141_VORSCHRIFT_STATUS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2879489598073891450)
,p_prompt=>'Status der Vorschrift '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VORSCHRIFT_STATUS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select Status as d,',
'       Vorschrift_statusid as r',
'  from T_vorschrift_status',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213213288832504966)
,p_name=>'P141_HOMOLOGATION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2879489598073891450)
,p_prompt=>'Homologationsrelevant'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Ja;10,Nein;0'
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213213658031504966)
,p_name=>'P141_BEMERKUNG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2879489598073891450)
,p_prompt=>'Bemerkung'
,p_placeholder=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213214365965504967)
,p_name=>'P141_REGION_WEBSITES'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2879488773625891442)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213215306881504968)
,p_name=>'P141_LINK_GETEX'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2879490802633891462)
,p_prompt=>'Link zu GETEX'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213215754734504968)
,p_name=>'P141_LINK_DMS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2879490802633891462)
,p_prompt=>'Link zu DMS'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213216105369504968)
,p_name=>'P141_WEBSITE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2879490802633891462)
,p_prompt=>'Webseite'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select website_name, websiteid',
'from t_website',
'order by 2'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_cHeight=>1
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213216596590504969)
,p_name=>'P141_WEBSITE_LINK'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2879490802633891462)
,p_prompt=>'Link zu Web Site'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>8
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213217238107504969)
,p_name=>'P141_REGION_LAENDER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2879488909280891443)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213218293324504970)
,p_name=>'P141_Q_LAENDERGRUPPE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2879491329734891468)
,p_prompt=>'Gruppe'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select laendergruppe, laendergruppeid',
'from t_laendergruppe',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- alle -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213218677047504971)
,p_name=>'P141_Q_PRE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2879491329734891468)
,p_prompt=>'Suche'
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" id="#qPre"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213219000160504971)
,p_name=>'P141_Q_LAND'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2879491329734891468)
,p_prompt=>'Land'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'        select b_nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'        ELSE land_eng',
'    END as d, landid',
'        from t_land',
'        where (',
'            :P141_Q_LAENDERGRUPPE is null',
'            or landid in (select landid from t_land_ref_laendergruppe where laendergruppeid = :P141_Q_LAENDERGRUPPE)',
'        )',
'        and (',
'            :P141_Q_PRE is null',
'            or instr(upper(b_nummer),upper(:P141_Q_PRE)) != 0',
'            or instr(upper(land),upper(:P141_Q_PRE)) != 0',
'        )',
'        /*where landid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))        ',
'        and (',
'            lLaendergruppe is null',
'            or landid in (select landid from t_land_ref_laendergruppe where laendergruppeid = lLaendergruppe)',
'        )',
'        and (',
'            lTextfilter is null',
'            or instr(upper(b_nummer),upper(lTextFilter)) != 0',
'            or instr(upper(land),upper(lTextFilter)) != 0',
'        )*/',
'        order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'') '))
,p_lov_cascade_parent_items=>'P141_Q_LAENDERGRUPPE,P141_Q_PRE'
,p_ajax_optimize_refresh=>'N'
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213219715897504972)
,p_name=>'P141_Z_LAENDERGRUPPE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2879491499367891469)
,p_prompt=>'Gruppe'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select laendergruppe, laendergruppeid',
'from t_laendergruppe',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- alle -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213220107280504972)
,p_name=>'P141_Z_PRE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2879491499367891469)
,p_prompt=>'Suche'
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" id="#zPre"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213220573520504972)
,p_name=>'P141_Z_LAND'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2879491499367891469)
,p_prompt=>'Land'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'        select b_nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'        ELSE land_eng',
'    END as d, landid',
'        from t_land',
'        where (',
'            :P141_Z_LAENDERGRUPPE is null',
'            or landid in (select landid from t_land_ref_laendergruppe where laendergruppeid = :P141_Z_LAENDERGRUPPE)',
'        )',
'        and (',
'            :P141_Z_PRE is null',
'            or instr(upper(b_nummer),upper(:P141_Z_PRE)) != 0',
'            or instr(upper(land),upper(:P141_Z_PRE)) != 0',
'        )',
'        order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'') '))
,p_lov_cascade_parent_items=>'P141_Z_LAENDERGRUPPE,P141_Z_PRE'
,p_ajax_optimize_refresh=>'N'
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(213221089439504992)
,p_validation_name=>'V_EINSATZDATUM_STATUS'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from t_vorschrift v',
'left outer join T_VORSCHRIFT_REF_EINSATZDATUM_TYP vret ',
'    on vret.vorschriftid = v.vorschriftid',
'    and vret.einsatzdatum_typid = 1000',
'where v.vorschriftid in (5100, 3457)',
'  and vret.vorschriftid is null',
';'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>unistr('Alle ausgew\00E4hlten Vorschriften ben\00F6tigen ein in Kraft-Datum bevor diese den Status In Kraft erhalten k\00F6nnen.')
,p_validation_condition=>'P141_VORSCHRIFT_STATUS'
,p_validation_condition2=>'40'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(2666336082420772647)
,p_associated_item=>wwv_flow_imp.id(213212889911504966)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(213227568754505003)
,p_name=>'toggleRegion'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'input#toggleRegion'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213228089099505003)
,p_event_id=>wwv_flow_imp.id(213227568754505003)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var region = $(this.triggeringElement).attr("region");',
'var stateChecked = $(this.triggeringElement).is(":checked");',
'',
'if (stateChecked) {',
'    $s("P141_REGION_" + region,1);',
'} else {',
'    $s("P141_REGION_" + region,0);    ',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(213228452563505003)
,p_name=>'toggle items attribute'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P141_REGION_ATTRIBUTE'
,p_condition_element=>'P141_REGION_ATTRIBUTE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213228962953505004)
,p_event_id=>wwv_flow_imp.id(213228452563505003)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P141_VORSCHRIFT_BEZEICHNUNG,P141_FREIGABESTATUS,P141_BEMERKUNG,P141_PROGNOSE_QUALITAET,P141_EINSATZDATUM_MODELL,P141_RXSWIN,P141_HOMOLOGATION,P141_VORSCHRIFT_STATUS'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213229424590505004)
,p_event_id=>wwv_flow_imp.id(213228452563505003)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P141_VORSCHRIFT_BEZEICHNUNG,P141_FREIGABESTATUS,P141_BEMERKUNG,P141_PROGNOSE_QUALITAET,P141_EINSATZDATUM_MODELL,P141_RXSWIN,P141_HOMOLOGATION,P141_VORSCHRIFT_STATUS'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(213229898112505004)
,p_name=>'toggle items websites'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P141_REGION_WEBSITES'
,p_condition_element=>'P141_REGION_WEBSITES'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213230372580505004)
,p_event_id=>wwv_flow_imp.id(213229898112505004)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P141_LINK_GETEX,P141_LINK_DMS,P141_WEBSITE,P141_WEBSITE_LINK'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213230856008505005)
,p_event_id=>wwv_flow_imp.id(213229898112505004)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P141_LINK_GETEX,P141_LINK_DMS,P141_WEBSITE,P141_WEBSITE_LINK'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(213231202200505005)
,p_name=>'toggle items laender'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P141_REGION_LAENDER'
,p_condition_element=>'P141_REGION_LAENDER'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213231739821505005)
,p_event_id=>wwv_flow_imp.id(213231202200505005)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2879491499367891469)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213232245130505005)
,p_event_id=>wwv_flow_imp.id(213231202200505005)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2879491329734891468)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213232786892505006)
,p_event_id=>wwv_flow_imp.id(213231202200505005)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2879491499367891469)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213233294507505006)
,p_event_id=>wwv_flow_imp.id(213231202200505005)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2879491329734891468)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(213233602941505006)
,p_name=>unistr('enter im Q L\00E4ndersuchfeld')
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P141_Q_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213234164250505007)
,p_event_id=>wwv_flow_imp.id(213233602941505006)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P141_Q_PRE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(213234517992505007)
,p_name=>unistr('enter im Z L\00E4ndersuchfeld')
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P141_Z_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213235042583505008)
,p_event_id=>wwv_flow_imp.id(213234517992505007)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P141_Z_PRE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(213235467060505008)
,p_name=>'klick suchicon Q'
,p_event_sequence=>70
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#qPre'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213235991321505009)
,p_event_id=>wwv_flow_imp.id(213235467060505008)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P141_Q_PRE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(213236281740505009)
,p_name=>'klick suchicon Z'
,p_event_sequence=>80
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#zPre'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213236750885505009)
,p_event_id=>wwv_flow_imp.id(213236281740505009)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P141_Z_PRE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(213238041485505010)
,p_name=>'toggle items themen'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P141_REGION_THEMEN'
,p_condition_element=>'P141_REGION_THEMEN'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213238514733505010)
,p_event_id=>wwv_flow_imp.id(213238041485505010)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2891912051319352140)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213239073736505010)
,p_event_id=>wwv_flow_imp.id(213238041485505010)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2891912051319352140)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213239536497505011)
,p_event_id=>wwv_flow_imp.id(213238041485505010)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2891912025706352139)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213240045744505011)
,p_event_id=>wwv_flow_imp.id(213238041485505010)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2891912025706352139)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(213240435022505011)
,p_name=>'enter im Q Themensuchfeld'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P141_Q_THEMA_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213240906301505011)
,p_event_id=>wwv_flow_imp.id(213240435022505011)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(213241332408505012)
,p_name=>'enter im Z Themensuchfeld'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P141_Z_THEMA_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213241898475505012)
,p_event_id=>wwv_flow_imp.id(213241332408505012)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(213223768897504996)
,p_name=>'toggle items suche'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P141_REGION_SEARCH_REPLACE'
,p_condition_element=>'P141_REGION_SEARCH_REPLACE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213225295128505001)
,p_event_id=>wwv_flow_imp.id(213223768897504996)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1271420484425853826)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213225779651505001)
,p_event_id=>wwv_flow_imp.id(213223768897504996)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1271420484425853826)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213224216986505000)
,p_event_id=>wwv_flow_imp.id(213223768897504996)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1271421000140853831)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213224708981505001)
,p_event_id=>wwv_flow_imp.id(213223768897504996)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1271421000140853831)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(213226179150505002)
,p_name=>'refresh search preview'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(213205251442504957)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213227135411505003)
,p_event_id=>wwv_flow_imp.id(213226179150505002)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1271421000140853831)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213226699899505002)
,p_event_id=>wwv_flow_imp.id(213226179150505002)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(213205672799504958)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(213242283547505012)
,p_name=>'ACTION_SEARCH_PARAM_CHANGED'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P141_TEXT_ATTRIBUT,P141_REGEX_PLAIN,P141_SEARCH_TEXT,P141_REPLACE_TEXT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213242797435505013)
,p_event_id=>wwv_flow_imp.id(213242283547505012)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(213205672799504958)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(213243136593505013)
,p_name=>'save search and replace'
,p_event_sequence=>160
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(213205672799504958)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213243673569505013)
,p_event_id=>wwv_flow_imp.id(213243136593505013)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'     lResult number;',
'begin',
'',
'lResult := PCK_RI.fSearchAndReplaceVorschriftenAttribut(aListVorschriftId => :P141_SELECTED_VORSCHRIFTEN, ',
'                                             aAttribut => :P141_TEXT_ATTRIBUT, ',
'                                             aPlainRegexReplace => :P141_REGEX_PLAIN, ',
'                                             aSearchText => :P141_SEARCH_TEXT, ',
'                                             aReplaceText => :P141_REPLACE_TEXT);',
'end;'))
,p_attribute_02=>'P141_TEXT_ATTRIBUT,P141_REGEX_PLAIN,P141_SEARCH_TEXT,P141_REPLACE_TEXT'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213244606195505014)
,p_event_id=>wwv_flow_imp.id(213243136593505013)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1271421000140853831)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213244152153505014)
,p_event_id=>wwv_flow_imp.id(213243136593505013)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>unistr('Suchen und Ersetzen wurde ausgef\00FChrt.')
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(213221774338504994)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_ATTRIBUTE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  result boolean;',
'begin',
'  --debug(''mehrfachbearbeitung'', ''attribute'');',
'  result := pck_ri.fChangeVorschriftenAttribut(:P141_SELECTED_VORSCHRIFTEN, :P141_VORSCHRIFT_BEZEICHNUNG, ',
'        :P141_BEMERKUNG, :P141_FREIGABESTATUS, :P141_EINSATZDATUM_MODELL,',
'        :P141_PROGNOSE_QUALITAET, :P141_HOMOLOGATION, :P141_VORSCHRIFT_STATUS, :P141_RXSWIN);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2666336082420772647)
,p_process_when=>'P141_REGION_ATTRIBUTE'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1'
,p_process_success_message=>unistr('\00C4nderungen wurden \00FCbernommen.')
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_internal_uid=>3885434090237893229
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(213222156985504995)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_LINK'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  result boolean;',
'begin',
' -- debug(''mehrfachbearbeitung'', ''links'');',
'  result := pck_ri.fChangeVorschriftenLinks(:P141_SELECTED_VORSCHRIFTEN, :P141_LINK_GETEX, ',
'        :P141_LINK_DMS, :P141_WEBSITE, :P141_WEBSITE_LINK);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2666336082420772647)
,p_process_when=>'P141_REGION_WEBSITES'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1'
,p_process_success_message=>unistr('\00C4nderungen wurden \00FCbernommen.')
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_internal_uid=>3885434472884893230
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(213222545311504995)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'COPY_THEMEN_BY_LAND'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  result boolean;',
'begin',
'  --debug(''mehrfachbearbeitung'', ''links'');',
'  result := pck_ri.fCopyVorschriftenThemenByLand(:P141_SELECTED_VORSCHRIFTEN, ',
'                                                   :P141_Q_LAND, ',
'                                                   :P141_Z_LAND);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2666336082420772647)
,p_process_when=>'P141_REGION_LAENDER'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1'
,p_process_success_message=>unistr('\00C4nderungen wurden \00FCbernommen.')
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_internal_uid=>3885434861210893230
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(213223321500504995)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'COPY_LAENDER_BY_THEMA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  result boolean;',
'begin',
'  --debug(''mehrfachbearbeitung'', ''links'');',
'  result := pck_ri.fCopyVorschriftenLaenderByThema(:P141_SELECTED_VORSCHRIFTEN, ',
'                                                   :P141_Q_THEMA, ',
'                                                   :P141_Z_THEMA);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2666336082420772647)
,p_process_when=>'P141_REGION_THEMEN'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1'
,p_process_success_message=>unistr('\00C4nderungen wurden \00FCbernommen.')
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_internal_uid=>3885435637399893230
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(213221347271504992)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'refresh cockpit'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri_cockpit_refresh.pTriggerRefresh;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3885433663170893227
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(213222980836504995)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'CLOSE_DIALOG'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2666336082420772647)
,p_process_when=>'APPLY'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3885435296735893230
);
wwv_flow_imp.component_end;
end;
/
