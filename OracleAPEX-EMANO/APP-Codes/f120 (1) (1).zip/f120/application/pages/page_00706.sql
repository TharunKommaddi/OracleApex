prompt --application/pages/page_00706
begin
--   Manifest
--     PAGE: 00706
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>706
,p_name=>'Parameter bearbeiten'
,p_alias=>'MS-PARAMETER-FORM-DIALOG'
,p_page_mode=>'MODAL'
,p_step_title=>'Parameter bearbeiten'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1200'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(323201588047842668)
,p_plug_name=>'MS Parameter Form Dialog'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(323176735087842643)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(323176295100842643)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(323176735087842643)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(323174310817842639)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(323176735087842643)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P706_MS_PARAMETERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(323173900804842638)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(323176735087842643)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P706_MS_PARAMETERID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(323201146901842667)
,p_name=>'P706_MS_PARAMETERID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(323201588047842668)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(323200762343842660)
,p_name=>'P706_NUMMER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(323201588047842668)
,p_prompt=>'Parameter Nummer'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144407257820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(323197969638842657)
,p_name=>'P706_AUSGABE_TEXT'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(323201588047842668)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Ausgabe Text'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg (ms_ausgabe_textid,'':'') within group (order by ms_ausgabe_textid)',
'  from  t_ms_parameter_ref_ausgabe ',
' where ms_parameterid = :P706_MS_PARAMETERID;'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nr||'': ''||ausgabe_text d,  ms_ausgabe_textid r',
'  from t_ms_ausgabe_text ',
'order by nr'))
,p_cHeight=>5
,p_display_when=>'P706_MS_PARAMETERID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(323197623808842657)
,p_name=>'P706_BILD_NUMMER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(323201588047842668)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Bild Nummer'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select   ms_bildid',
'  from  t_ms_parameter_ref_bild ',
' where ms_parameterid = :P706_MS_PARAMETERID;'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bild_nummer d,  ms_bildid r',
'  from t_ms_bild ',
'order by 1'))
,p_cHeight=>5
,p_display_when=>'P706_MS_PARAMETERID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(323176142910842643)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(323176295100842643)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(323175431763842641)
,p_event_id=>wwv_flow_imp.id(323176142910842643)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(323219323188066502)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'process bild und Ausgabetext'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--text',
'declare ',
'l_count number :=0;',
'begin',
'      --select count(*) into l_count from t_ms_parameter_ref_ausgabe where ms_parameterid = :P706_MS_PARAMETERID;',
'   --debug(''P706_MS_PARAMETERID=''|| :P706_MS_PARAMETERID, ''P706_AUSGABE_TEXT=''|| :P706_AUSGABE_TEXT );',
'   merge into t_ms_parameter_ref_ausgabe dest',
'    using (select :P706_MS_PARAMETERID as ms_parameterid, column_value as ms_ausgabe_textid from TABLE(APEX_STRING.split_numbers(:P706_AUSGABE_TEXT, '':''))) src',
'    on (dest.ms_parameterid = src.ms_parameterid',
'       and dest.ms_ausgabe_textid = src.ms_ausgabe_textid)',
'    when not matched then insert(dest.ms_parameterid, dest.ms_ausgabe_textid)',
'       values(src.ms_parameterid, src.ms_ausgabe_textid);',
'   ',
'   delete from t_ms_parameter_ref_ausgabe pra',
'    where pra.ms_parameterid = :P706_MS_PARAMETERID',
'        and ( :P706_AUSGABE_TEXT is null OR pra.ms_ausgabe_textid not in (select column_value from TABLE(APEX_STRING.split_numbers(:P706_AUSGABE_TEXT, '':'')))',
'         );    ',
'       ',
'  -- if(l_count>0) then',
'--   end if;',
'',
'    ',
'     -- bild ----',
'      merge into t_ms_parameter_ref_bild dest',
'    using ( select :P706_MS_PARAMETERID as ms_parameterid, x.column_value as ms_bildid    ',
'            from TABLE (APEX_STRING.split_numbers(:P706_BILD_NUMMER, '':'')) x',
'            ) src',
'    on (dest.ms_parameterid = src.ms_parameterid',
'       and dest.ms_bildid = src.ms_bildid)',
'    when not matched then insert(dest.ms_parameterid, dest.ms_bildid)',
'       values(src.ms_parameterid, src.ms_bildid);',
'      ',
'    delete from t_ms_parameter_ref_bild prb',
'    where prb.ms_parameterid = :P706_MS_PARAMETERID',
'        and (:P706_BILD_NUMMER is null or prb.ms_bildid not in ( select x.column_value from TABLE (APEX_STRING.split_numbers(:P706_BILD_NUMMER, '':'')) x',
'        )  );',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE, CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3348992992711321733
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(323219159578066501)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3348993156321321734
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(323172696548842638)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3349039619350545597
);
wwv_flow_imp.component_end;
end;
/
