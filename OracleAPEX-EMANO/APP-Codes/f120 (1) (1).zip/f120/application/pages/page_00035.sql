prompt --application/pages/page_00035
begin
--   Manifest
--     PAGE: 00035
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>35
,p_name=>unistr('Thema bearbeiten / hinzuf\00FCgen')
,p_alias=>unistr('THEMA-BEARBEITEN-HINZUF\00DCGEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Thema bearbeiten / hinzuf\00FCgen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>unistr('var htmldb_delete_message=''"M\00F6chten Sie das Thema l\00F6schen?"'';')
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1200'
,p_protection_level=>'C'
,p_page_comment=>'a'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5375886181409709731)
,p_plug_name=>'Form on T_THEMA'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5375886931590709731)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025095942423159969)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_button_name=>'EDIT_ANTRIEBSARTEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Bearbeiten'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:38:P38_CAME_FROM,P38_THEMAID:35,&P35_THEMAID.'
,p_button_condition=>'PCK_RI.fIsAuthorized(pageID => 35, accessMode => 200)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025095547392159968)
,p_button_sequence=>210
,p_button_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_button_name=>'EDIT_ARBEITSKREISE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Bearbeiten'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:36:P36_CAME_FROM,P36_THEMAID:35,&P35_THEMAID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- prevent assignment if thema is inactive',
'PCK_RI.fIsAuthorized(pageID => 35, accessMode => 200)',
'and nvl(:P35_GUELTIGKEIT_ENDEDATUM, sysdate +100 ) > sysdate'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025095138767159968)
,p_button_sequence=>260
,p_button_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_button_name=>'EDIT_FUNKTIONEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Bearbeiten'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:343:&SESSION.::&DEBUG.:343:P343_CAME_FROM,P343_THEMAID:35,&P35_THEMAID.'
,p_button_condition=>'PCK_RI.fIsAuthorized(pageID => 35, accessMode => 200) = true'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025094810622159967)
,p_button_sequence=>370
,p_button_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_button_name=>'EDIT_LRSA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Bearbeiten'
,p_button_redirect_url=>'f?p=&APP_ID.:281:&SESSION.::&DEBUG.:RP,281:P281_CAME_FROM,P281_THEMAID,P281_SELECTED:35,&P35_THEMAID.,&P35_LRSAID.'
,p_button_condition=>'PCK_RI.fIsAuthorized(pageID => 35, accessMode => 200) = true'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025080420130159934)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5375886931590709731)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025080070935159933)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(5375886931590709731)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025079708650159933)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(5375886931590709731)
,p_button_name=>'SAVE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P35_THEMAID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025079278685159933)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(5375886931590709731)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_condition=>'P35_THEMAID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025094319740159956)
,p_name=>'P35_VI_CHANGED'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_source=>'0'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025094076751159954)
,p_name=>'P35_SMTH_CHANGED'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_source=>'0'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025093622077159954)
,p_name=>'P35_NUMMER'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Nummer'
,p_source=>'NUMMER'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>10
,p_cMaxlength=>40
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025093217968159953)
,p_name=>'P35_GUELTIGKEIT_STARTDATUM'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_item_default=>'trunc(sysdate)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>unistr('G\00FCltigkeit Startdatum')
,p_source=>'GUELTIGKEIT_STARTDATUM'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025092845232159953)
,p_name=>'P35_GUELTIGKEIT_ENDEDATUM'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('G\00FCltigkeit Endedatum')
,p_source=>'GUELTIGKEIT_ENDEDATUM'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when=>' pck_ri.fIsUserInRolle(listRolleId => ''1003'') = 0'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025092429340159952)
,p_name=>'P35_ROWID'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_source=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when_type=>'NEVER'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025092023909159952)
,p_name=>'P35_BEZEICHNUNG'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Thema Bezeichnung Deutsch'
,p_source=>'BEZEICHNUNG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>120
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--PCK_RI.fIsAuthorized(pageID => 35, accessMode => 300) = false',
'-- sperren wegen abgleich mit GETEX [Anf] 1357',
'--or ',
':P35_BEZEICHNUNG is not null ',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025091619446159951)
,p_name=>'P35_BEZEICHNUNG_ENGLISCH'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Thema Bezeichnung Englisch'
,p_source=>'NAME_ENG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>256
,p_begin_on_new_line=>'N'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--PCK_RI.fIsAuthorized(pageID => 35, accessMode => 300) = false',
'-- sperren wegen abgleich mit GETEX [Anf] 1357',
'--or ',
':P35_BEZEICHNUNG_ENGLISCH is not null '))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025091225355159951)
,p_name=>'P35_DESCRIPTION_SOC_DE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Beschreibung SoC Deutsch'
,p_source=>'DESCRIPTION_SOC_DE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>2000
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025090828447159951)
,p_name=>'P35_DESCRIPTION_SOC_EN'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Beschreibung SoC Englisch'
,p_source=>'DESCRIPTION_SOC_EN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>2000
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025090468898159950)
,p_name=>'P35_PARENTID'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('\00DCbergeordnetes Thema')
,p_source=>'PARENTID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_THEMA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    NUMMER || '' - '' || ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN BEZEICHNUNG',
'        ELSE name_eng',
'    END as d,',
'    THEMAID as r',
'FROM V_THEMA_BAUM vtb',
'-- It excludes topics linked to et_b_akid = 1036 in t_thema_ref_et_b_ak, ensuring results are relevant to users without access to these excluded topics.',
'-- WHERE vtb.themaid not in (select themaid from t_thema_ref_et_b_ak where et_b_akid =1036 )',
'ORDER BY vtb.thema_sortorder;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'keines'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025090069670159948)
,p_name=>'P35_ANTRIEBSART_VORSCHRIFT'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Antriebsart'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--select tra.antriebsartid',
'--from t_thema_ref_antriebsart tra',
'--where tra.themaid = :P35_THEMAID and tra.antriebsartid is not null',
'select listagg(trim(aa.bezeichnung),'', '' ON OVERFLOW TRUNCATE ''...'') within group (order by aa.bezeichnung)',
'from t_antriebsart aa',
'join table(apex_string.split_numbers(:P35_ANTRIEBSARTEN_ID,'':'')) c on (aa.antriebsartID = c.column_value);'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng ',
'    END  d,',
'    antriebsartid r',
'FROM ',
'    t_antriebsart ',
'--ORDER BY ',
' --   CASE ',
' --       WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
' --       ELSE name_eng ',
' --   END;',
''))
,p_colspan=>11
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025089695684159947)
,p_name=>'P35_ANTRIEBSARTEN_ID'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select antriebsartID',
'from t_thema_ref_antriebsart',
'where themaid = :P35_THEMAID'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025089226867159947)
,p_name=>'P35_SELECTED_VORSCHRIFTEN_AA'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025088856376159946)
,p_name=>'P35_BETROFFENHEIT'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Betroffenheit'
,p_source=>'BETROFFENHEIT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>250
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PCK_RI.fIsAuthorized(pageID => 35, accessMode => 200) = false',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025088426661159946)
,p_name=>'P35_THEMAID'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_source=>'THEMAID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025088065261159946)
,p_name=>'P35_KONZERN_CLUSTER'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Konzern Cluster'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tc.konzern_clusterid',
'from t_thema_ref_cluster tc',
'where tc.themaid = :P35_THEMAID'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_KONZERN_CLUSTER'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_cMaxlength=>500
,p_read_only_when=>'PCK_RI.fIsAuthorized(pageID => 35, accessMode => 200) = false'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025087647566159946)
,p_name=>'P35_D_ARBEITSKREISE'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Arbeitskreise'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--select listagg(trim(ak.kurz), '', '' ON OVERFLOW TRUNCATE ''...'') within group (order by ak.kurz)',
'select listagg(trim(ak.bezeichnung),'', '' ON OVERFLOW TRUNCATE ''...'') within group (order by ak.bezeichnung)',
'from t_ET_B_AK ak',
'join table(apex_string.split_numbers(:P35_ARBEITSKREISEID,'':'') ) sp on (sp.column_value is not null and ak.ET_B_AKID = sp.column_value);'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>11
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025087302656159946)
,p_name=>'P35_ARBEITSKREISEID'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ET_B_AKID',
'from t_thema_ref_ET_B_AK',
'where themaid = :P35_THEMAID'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025086909651159946)
,p_name=>'P35_SELECTED_VORSCHRIFTEN_AK'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025086482737159945)
,p_name=>'P35_FAHRZEUGKLASSE'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fahrzeugart'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    FAHRZEUGKLASSEID',
'FROM ',
'    T_THEMA_REF_FAHRZEUGKLASSE',
'WHERE ',
'    THEMAID = :P35_THEMAID'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    BEZEICHNUNG as display,',
'    FAHRZEUGKLASSEID as return',
'FROM ',
'    T_FAHRZEUGKLASSE',
'ORDER BY ',
'    BEZEICHNUNG'))
,p_lov_display_null=>'YES'
,p_cSize=>70
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025086061499159945)
,p_name=>'P35_D_FUNKTIONEN'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_prompt=>'Funktionen'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>11
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025085677078159945)
,p_name=>'P35_FUNKTIONEN'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select funktionid',
'from t_thema_ref_funktion',
'where themaid = :P35_THEMAID'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025085256267159945)
,p_name=>'P35_SELECTED_VORSCHRIFTEN_FU'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025084889814159945)
,p_name=>'P35_ET_B_AK_KURZ'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_prompt=>'ET-B AK Kurzbezeichnung'
,p_source=>'ET_B_AKID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select kurz, et_b_akid',
'from t_et_b_ak',
'order by kurz'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'(kein AK)'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_read_only_when=>'PCK_RI.fIsAuthorized(pageID => 35, accessMode => 200) = false'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025084455028159945)
,p_name=>'P35_ET_BAK'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_prompt=>'ET-B AK'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select BEZEICHNUNG ',
'from t_et_b_ak ',
'where et_b_akid = :P35_ET_B_AK_KURZ'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>250
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'Y',
  'send_on_page_submit', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025084049175159944)
,p_name=>'P35_LEAD_SYVA'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_prompt=>'LEAD SYVA'
,p_source=>'LEAD_SYVA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>250
,p_read_only_when=>'PCK_RI.fIsAuthorized(pageID => 35, accessMode => 200) = false'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Dieses Feld wird durch eine andere Abteilung gepflegt.'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025083192958159942)
,p_name=>'P35_BETA_FLAG'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>'Beta Flag'
,p_source=>'BETA_FLAG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_read_only_when=>'PCK_RI.fIsAuthorized(pageID => 35, accessMode => 200) = false'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Nein',
  'off_value', '0',
  'on_label', 'Ja',
  'on_value', '10',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025082744422159942)
,p_name=>'P35_MIRG_ZUORDNUNG'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_prompt=>'MIRG-Zuordnung'
,p_source=>'MIRG_ZUORDNUNG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>250
,p_read_only_when=>'PCK_RI.fIsAuthorized(pageID => 35, accessMode => 200) = false'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025082351910159942)
,p_name=>'P35_SYSTEMTEAM_ZUORDNUNG'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Systemteam-Zuordnung'
,p_source=>'SYSTEMTEAM_ZUORDNUNG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>250
,p_read_only_when=>'PCK_RI.fIsAuthorized(pageID => 35, accessMode => 200) = false'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025081987003159942)
,p_name=>'P35_GUELTIG'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_source=>'GUELTIG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025081542179159941)
,p_name=>'P35_D_LRSA'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_prompt=>'LRSA-Zuordnung'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(trim(l.bezeichnung),'', '' ON OVERFLOW TRUNCATE ''...'') within group (order by l.bezeichnung)',
'from t_lrsa l',
'join table(apex_string.split_numbers(:P35_LRSAID,'':'')) c on (l.lrsa_id = c.column_value);'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>11
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025081132437159941)
,p_name=>'P35_LRSAID'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_imp.id(5375886181409709731)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(trim(l.LRSAID),'':'' ON OVERFLOW TRUNCATE ''...'') within group (order by l.LRSAID)',
'from T_THEMA_REF_LRSA l',
'where themaid = :P35_THEMAID',
'and l.geloescht = 20;'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1025078318613159924)
,p_validation_name=>'VALIDATE_NO_CIRCULAR_REFERENCE'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'exists (select 1 ',
'from dual)'))
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Das \00FCbergeordnete Thema bildet einen Zirkelbezug.')
,p_associated_item=>wwv_flow_imp.id(1025090468898159950)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1025077931658159923)
,p_validation_name=>'VALIDATE_NO_SELF_REFERENCE'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P35_PARENTID is null or',
'(select t.themaid ',
'    from t_thema t',
'    where t.themaid = :P35_THEMAID) is null or',
':P35_PARENTID <> (select t.themaid ',
'    from t_thema t',
'    where t.themaid = :P35_THEMAID)'))
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Ein Thema kann nicht auf sich selbst verweisen.'
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(1025090468898159950)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1025077529336159923)
,p_validation_name=>'VALIDATE_THEMA_NUMMER'
,p_validation_sequence=>30
,p_validation=>'P35_NUMMER'
,p_validation2=>'^([0-9]+)(\.[0-9]+)*$'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>'Das Feld muss eine Thema-Nummer nach dem Schema "1", "1.3" oder "3.23.44" enthalten.'
,p_associated_item=>wwv_flow_imp.id(1025093622077159954)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1025078797980159925)
,p_validation_name=>unistr('VALIDATE_G\00DCLTIGKEIT_ENDE')
,p_validation_sequence=>40
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
' declare ',
'    l_co number :=0;',
' begin ',
'   if(:P35_GUELTIGKEIT_ENDEDATUM is not null) then',
'   --check blattelemente',
'      select count(*) into l_co',
'      from T_Thema  ',
'      where parentid = :P35_THEMAID ',
'      and nvl(gueltig, 0) = 1; --  or gueltig > sysdate;',
' ',
'  end if;',
'  ',
'   if (l_co > 0) then',
'     return false;',
'    else ',
'     return true;',
'    end if;',
'  ',
' end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('Einige abh\00E4ngige Subthemen sind noch g\00FCltig!')
,p_when_button_pressed=>wwv_flow_imp.id(1025079708650159933)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025072105801159917)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1025080420130159934)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025071571430159913)
,p_event_id=>wwv_flow_imp.id(1025072105801159917)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025071166088159912)
,p_name=>'ak_kurz changed'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P35_ET_B_AK_KURZ'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025070672005159912)
,p_event_id=>wwv_flow_imp.id(1025071166088159912)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P35_ET_BAK'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung ',
'from t_et_b_ak',
'where et_b_akid = :P35_ET_B_AK_KURZ'))
,p_attribute_07=>'P35_ET_B_AK_KURZ'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025070223520159911)
,p_name=>unistr('Click Save (vernetzte Infos ge\00E4ndert)')
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1025079708650159933)
,p_condition_element=>'P35_VI_CHANGED'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025069776344159911)
,p_event_id=>wwv_flow_imp.id(1025070223520159911)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Durch die \00C4nderung der vernetzten Informationen (Antriebsart, Arbeitskreise, Funktionen) erfolgt automatisiert eine Zur\00FCcksetzung der bei den Vorschriften zugeordneten Informationen. M\00F6chten Sie dies durchf\00FChren?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025069269916159910)
,p_event_id=>wwv_flow_imp.id(1025070223520159911)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'SAVE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025068874783159910)
,p_name=>unistr('Click Save (vernetzte Infos nicht ge\00E4ndert)')
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1025079708650159933)
,p_condition_element=>'P35_VI_CHANGED'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025068387551159910)
,p_event_id=>wwv_flow_imp.id(1025068874783159910)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'SAVE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025067967806159910)
,p_name=>unistr('VI ge\00E4ndert')
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P35_ANTRIEBSART_VORSCHRIFT,P35_D_ARBEITSKREISE,P35_FUNKTIONEN,P35_KONZERN_CLUSTER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025067481069159910)
,p_event_id=>wwv_flow_imp.id(1025067967806159910)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P35_VI_CHANGED'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025067063741159910)
,p_name=>unistr('Funktionen ge\00E4ndert')
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1025095138767159968)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025066591446159909)
,p_event_id=>wwv_flow_imp.id(1025067063741159910)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Set Funktionen'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P35_FUNKTIONEN'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P343_SELECTED'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025066033577159909)
,p_event_id=>wwv_flow_imp.id(1025067063741159910)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'set Vorschriften FU'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P35_SELECTED_VORSCHRIFTEN_FU'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P343_SELECTED_VORSCHRIFTEN'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025065547075159909)
,p_event_id=>wwv_flow_imp.id(1025067063741159910)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_name=>'Set Display Values'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P35_D_FUNKTIONEN'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(trim(f.bezeichnung),'', '' ON OVERFLOW TRUNCATE ''...'') within group (order by f.bezeichnung)',
'from t_funktion f',
'join table(apex_string.split_numbers(:P35_FUNKTIONEN,'':'')) c on (f.funktionid = c.column_value);'))
,p_attribute_07=>'P35_FUNKTIONEN'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025065090914159908)
,p_event_id=>wwv_flow_imp.id(1025067063741159910)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P35_FUNKTIONEN,P35_SELECTED_VORSCHRIFTEN_FU'
,p_attribute_03=>'P35_FUNKTIONEN,P35_SELECTED_VORSCHRIFTEN_FU'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025064552538159908)
,p_event_id=>wwv_flow_imp.id(1025067063741159910)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--debug(''P35_SELECTED_VORSCHRIFTEN_FU=''||:P35_SELECTED_VORSCHRIFTEN_FU);',
'null;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025064123884159908)
,p_name=>'Disable Edit Funktion'
,p_event_sequence=>70
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025063639167159906)
,p_event_id=>wwv_flow_imp.id(1025064123884159908)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(1025095138767159968)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025063290726159906)
,p_name=>unistr('Items ge\00E4ndert')
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P35_ANTRIEBSART_VORSCHRIFT,P35_BETROFFENHEIT,P35_KONZERN_CLUSTER,P35_D_ARBEITSKREISE,P35_FUNKTIONEN,P35_LEAD_SYVA,P35_BETA_FLAG,P35_MIRG_ZUORDNUNG,P35_SYSTEMTEAM_ZUORDNUNG,P35_BEZEICHNUNG,P35_NUMMER,P35_PARENTID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025062798250159905)
,p_event_id=>wwv_flow_imp.id(1025063290726159906)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P35_SMTH_CHANGED'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025062368857159905)
,p_name=>'AK bearbeitet'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1025095547392159968)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025061868928159905)
,p_event_id=>wwv_flow_imp.id(1025062368857159905)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Set Arbeitskreise  IDs'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P35_ARBEITSKREISEID'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P36_ARBEITSKREISE'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025061388172159905)
,p_event_id=>wwv_flow_imp.id(1025062368857159905)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Set Ak Vorschriften IDs'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P35_SELECTED_VORSCHRIFTEN_AK'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P36_SELECTED_VORSCHRIFTEN'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025060910950159904)
,p_event_id=>wwv_flow_imp.id(1025062368857159905)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_name=>'Set AK diisplay values'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P35_D_ARBEITSKREISE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(trim(ak.bezeichnung),'', '' ON OVERFLOW TRUNCATE ''...'') within group (order by ak.bezeichnung)',
'from t_ET_B_AK ak',
'join table(apex_string.split_numbers(:P35_ARBEITSKREISEID,'':'')) c on (ak.ET_B_AKID = c.column_value);'))
,p_attribute_07=>'P35_ARBEITSKREISEID'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025060331517159904)
,p_event_id=>wwv_flow_imp.id(1025062368857159905)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P35_SELECTED_VORSCHRIFTEN_AK,P35_ARBEITSKREISEID'
,p_attribute_03=>'P35_SELECTED_VORSCHRIFTEN_AK,P35_ARBEITSKREISEID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025059946485159904)
,p_name=>'AA_bearbeitet'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1025095942423159969)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025059441510159904)
,p_event_id=>wwv_flow_imp.id(1025059946485159904)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Set AA Ids'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P35_ANTRIEBSARTEN_ID'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P38_ANTRIEBSARTEN'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025058948824159904)
,p_event_id=>wwv_flow_imp.id(1025059946485159904)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Set AA Vorschr IDs'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P35_SELECTED_VORSCHRIFTEN_AA'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P38_SELECTED_VORSCHRIFTEN'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025058444168159903)
,p_event_id=>wwv_flow_imp.id(1025059946485159904)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_name=>'Set AA Display '
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P35_ANTRIEBSART_VORSCHRIFT'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(trim(aa.bezeichnung),'', '' ON OVERFLOW TRUNCATE ''...'') within group (order by aa.bezeichnung)',
'from t_Antriebsart aa',
'join table(apex_string.split_numbers(:P35_ANTRIEBSARTEN_ID,'':'')) c on (aa.AntriebsartID = c.column_value);'))
,p_attribute_07=>'P35_ANTRIEBSARTEN_ID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025057994619159903)
,p_event_id=>wwv_flow_imp.id(1025059946485159904)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P35_ANTRIEBSARTEN_ID,P35_SELECTED_VORSCHRIFTEN_AA'
,p_attribute_03=>'P35_ANTRIEBSARTEN_ID,P35_SELECTED_VORSCHRIFTEN_AA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025057535794159903)
,p_name=>'Change'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P35_GUELTIGKEIT_ENDEDATUM'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025057070157159903)
,p_event_id=>wwv_flow_imp.id(1025057535794159903)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P35_GUELTIG'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when (:P35_GUELTIGKEIT_ENDEDATUM is null or :P35_GUELTIGKEIT_ENDEDATUM >= Sysdate ) then 1 else 0 end ',
'from dual;'))
,p_attribute_07=>'P35_GUELTIGKEIT_ENDEDATUM'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025056690268159903)
,p_name=>unistr('LRSA ge\00E4ndert')
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1025094810622159967)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025056143014159902)
,p_event_id=>wwv_flow_imp.id(1025056690268159903)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Set LRSA'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P35_LRSAID'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P281_SELECTED_RECURSIVE'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025055682920159902)
,p_event_id=>wwv_flow_imp.id(1025056690268159903)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_name=>'Set Display Values'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P35_D_LRSA'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(trim(l.lrsa_nummer || '' - '' || l.bezeichnung),'', '' ON OVERFLOW TRUNCATE ''...'') within group (order by l.lrsa_nummer, l.bezeichnung)',
'from t_lrsa l',
'join table(apex_string.split_numbers(:P35_LRSAID,'':'')) c on (l.lrsa_id = c.column_value);'))
,p_attribute_07=>'P35_LRSAID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025055198403159902)
,p_event_id=>wwv_flow_imp.id(1025056690268159903)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P35_LRSAID'
,p_attribute_03=>'P35_LRSAID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025054640796159901)
,p_event_id=>wwv_flow_imp.id(1025056690268159903)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5375886181409709731)
,p_attribute_01=>'N'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1025073667677159919)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_THEMA'
,p_attribute_02=>'T_THEMA'
,p_attribute_03=>'P35_THEMAID'
,p_attribute_04=>'THEMAID'
,p_internal_uid=>2647138648222228316
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1025075629754159920)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reset Attribute'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN  ',
'--:P35_ANTRIEBSARTEN_ID := null;',
'--:P35_ARBEITSKREISEID := null;',
':P35_SELECTED_VORSCHRIFTEN_AA := null;',
':P35_SELECTED_VORSCHRIFTEN_AK := null;',
':P35_SELECTED_VORSCHRIFTEN_FU := null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2647136686145228315
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1025073273700159919)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of T_THEMA'
,p_attribute_02=>'T_THEMA'
,p_attribute_03=>'P35_THEMAID'
,p_attribute_04=>'THEMAID'
,p_attribute_09=>'P35_THEMAID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_process_error_message=>'Nicht gespeichert!'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>2647139042199228316
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1025074864627159920)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process Row of T_THEMA_REF_FAHRZEUGKLASSE '
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    l_themaid NUMBER;',
'BEGIN',
'    -- Get THEMAID from the current record',
'    SELECT themaid INTO l_themaid',
'    FROM t_thema',
'    WHERE themaid =:P35_THEMAID; --rowid = :P35_ROWID;',
'  ',
'    -- Insert or merge new Fahrzeugklasse references',
'    MERGE INTO T_THEMA_REF_FAHRZEUGKLASSE dest',
'    USING (',
'        SELECT l_themaid as themaid, ',
'               column_value as fahrzeugklasseid',
'        FROM TABLE(APEX_STRING.split_numbers(:P35_FAHRZEUGKLASSE, '':''))',
'        WHERE column_value IS NOT NULL',
'    ) src',
'    ON (dest.themaid = src.themaid AND dest.fahrzeugklasseid = src.fahrzeugklasseid)',
'    WHEN NOT MATCHED THEN',
'        INSERT (themaid, fahrzeugklasseid, letzte_aenderung_datum, letzte_aenderung_benutzer)',
'        VALUES (src.themaid, src.fahrzeugklasseid, SYSDATE, :G_BENUTZERID);',
'  ',
'    -- Remove unused Fahrzeugklasse references',
'    DELETE FROM T_THEMA_REF_FAHRZEUGKLASSE trf',
'    WHERE trf.themaid = l_themaid',
'    AND trf.fahrzeugklasseid NOT IN (',
'        SELECT column_value ',
'        FROM TABLE(APEX_STRING.split_numbers(:P35_FAHRZEUGKLASSE, '':''))',
'        WHERE column_value IS NOT NULL',
'    );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>2647137451272228315
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1025076820585159922)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_benutzer'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_thema set letzte_aenderung_benutzerid = pck_ri.fgetUserId',
'where themaid =:P35_THEMAID; --rowid = :P35_ROWID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':REQUEST in (''SAVE'') and :P35_SMTH_CHANGED = 1'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>2647135495314228313
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1025074445682159920)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process Funktionen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_themaid number;',
'begin',
'    select themaid into l_themaid',
'    from t_thema',
'    where themaid =:P35_THEMAID; --rowid = :P35_ROWID;',
'  ',
'    merge into t_thema_ref_funktion dest',
'    using (select l_themaid as themaid, column_value as funktionid',
'          from TABLE(APEX_STRING.split_numbers(:P35_FUNKTIONEN, '':''))) src',
'    on (dest.themaid = src.themaid',
'        and dest.funktionid = src.funktionid)',
'    when not matched then insert(dest.themaid, dest.funktionid)',
'        values(src.themaid, src.funktionid);',
'  ',
'    delete from t_thema_ref_funktion trf',
'    where trf.themaid = l_themaid',
'        and trf.funktionid not in (select column_value FROM TABLE(APEX_STRING.split_numbers(:P35_FUNKTIONEN, '':'')));',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':REQUEST in (''SAVE'',''CREATE'')'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>2647137870217228315
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1025076023609159921)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process Arbeitskreise'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_themaid number;',
'begin',
'    select themaid into l_themaid',
'    from t_thema',
'    where themaid =:P35_THEMAID; --rowid = :P35_ROWID;',
'  ',
'    -- neue Arbeitskreise einfuegen',
'    merge into t_thema_ref_et_b_ak dest',
'    using (select l_themaid as themaid, column_value as et_b_akid',
'          from TABLE(APEX_STRING.split_numbers(:P35_ARBEITSKREISEID, '':''))) src',
'    on (dest.themaid = src.themaid',
'        and dest.et_b_akid = src.et_b_akid)',
'    when not matched then insert(themaid, et_b_akid, letzte_aenderung_datum, letzte_aenderung_benutzerid)',
'        values(src.themaid, src.et_b_akid, sysdate, :G_BENUTZERID);',
'  ',
'    -- nicht mehr verwendete Arbeitskreise entfernen',
unistr('    -- zuerst die Abh\00E4ngigkeiten'),
'    delete from t_et_b_ak_ref_thema_benutzer_ref_et_b_ak_ref_thema',
'    where thema_ref_et_b_akid in (',
'    select trak.thema_ref_et_b_akid',
'    from t_thema_ref_et_b_ak trak',
'    where trak.themaid = l_themaid',
'        and trak.et_b_akid not in (select column_value FROM TABLE(APEX_STRING.split_numbers(:P35_ARBEITSKREISEID, '':'')))',
'    );',
'    ',
unistr('    -- dann die Verkn\00FCpfung zum Arbeitskreis'),
'    delete from t_thema_ref_et_b_ak trf',
'    where trf.themaid = l_themaid',
'        and trf.et_b_akid not in (select column_value FROM TABLE(APEX_STRING.split_numbers(:P35_ARBEITSKREISEID, '':'')));',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':REQUEST in (''SAVE'',''CREATE'')'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>2647136292290228314
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1025077247314159923)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process Antriebsart'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_themaid number;',
'begin',
'    select themaid into l_themaid',
'    from t_thema',
'    where themaid =:P35_THEMAID; --rowid = :P35_ROWID;',
'  ',
'    merge into t_thema_ref_antriebsart dest',
'    using (select l_themaid as themaid, column_value as antriebsartid',
'          from TABLE(APEX_STRING.split_numbers(:P35_ANTRIEBSARTEN_ID, '':'')) where column_value is not null) src',
'    on (dest.themaid = src.themaid',
'        and dest.antriebsartid = src.antriebsartid)',
'    when not matched then insert(dest.themaid, dest.antriebsartid)',
'        values(src.themaid, src.antriebsartid);',
'  ',
'    delete from t_thema_ref_antriebsart tra',
'    where tra.themaid = l_themaid',
'        and tra.antriebsartid not in (select column_value FROM TABLE(APEX_STRING.split_numbers(:P35_ANTRIEBSARTEN_ID, '':'')) where column_value is not null);',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':REQUEST in (''SAVE'',''CREATE'')'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>2647135068585228312
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1025075248492159920)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process Konzern_cluster'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_themaid number;',
'begin',
'    select themaid into l_themaid',
'    from t_thema',
'    where themaid =:P35_THEMAID; --rowid = :P35_ROWID;',
'  --debug(''P35_KONZERN_CLUSTER ='', :P35_KONZERN_CLUSTER);',
'    -- neue Arbeitskreise einfuegen',
'    merge into t_thema_ref_cluster dest',
'    using (select l_themaid as themaid, column_value as konzern_clusterid',
'          from TABLE(APEX_STRING.split_numbers(:P35_KONZERN_CLUSTER, '':''))) src',
'    on (dest.themaid = src.themaid',
'        and dest.konzern_clusterid = src.konzern_clusterid)',
'    when not matched then insert(themaid, konzern_clusterid, letzte_aenderung_datum, letzte_aenderung_benutzerid)',
'        values(src.themaid, src.konzern_clusterid, sysdate, :G_BENUTZERID);',
' ',
'    -- nicht mehr verwendete konzern_clusterid ref. entfernen',
'    delete from t_thema_ref_cluster trc',
'    where trc.themaid = l_themaid',
'        and trc.konzern_clusterid not in (select column_value FROM TABLE(APEX_STRING.split_numbers(:P35_KONZERN_CLUSTER, '':'')));',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE, CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2647137067407228315
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3095362092318678197)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'refresh MView'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
' pck_ri.P_REFRESH_MV_THEMA_REPORT;',
'',
'  /*  CTX_DDL.SYNC_INDEX(''MV_THEMA_EXTENDED_IDX'');',
'    CTX_DDL.SYNC_INDEX(''MV_THEMA_BEZEICHNUNG_IDX'');*/',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>576850223580710038
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1025074103994159920)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process LRSA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*    merge into T_THEMA_REF_LRSA dest',
'    using (select l_themaid as themaid, column_value as funktionid',
'          from TABLE(APEX_STRING.split_numbers(:P35_FUNKTIONEN, '':''))) src',
'    on (dest.themaid = src.themaid',
'        and dest.funktionid = src.funktionid)',
'    when not matched then insert(dest.themaid, dest.funktionid)',
'        values(src.themaid, src.funktionid);*/',
'',
'        -- noch anzupassen'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2647138211905228315
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1025076495794159922)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reset VI'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lThemaID number;',
'begin',
'',
'    select themaid into lThemaID',
'    from t_thema',
'    where themaid =:P35_THEMAID; --rowid = :P35_ROWID;',
'',
'    /*for v in (',
'        select distinct vorschriftid',
'        from t_vorschrift_ref_thema',
'        where nvl(geloescht,0) = 0',
'        and themaid = lThemaID',
'    ) loop',
'        pck_ri.pResetVI(v.vorschriftid);',
'    end loop;',
'*/',
'    for v in (',
'        select distinct vorschriftid',
'        from t_vorschrift_ref_thema vrt',
'        join table ( apex_string.split_numbers(:P35_SELECTED_VORSCHRIFTEN_AK,'':'')  ) st on (st.column_value = vrt.vorschriftid)',
'        ',
'        where nvl(geloescht,0) = 0',
'        and themaid = lThemaID',
'    ) loop',
'        pck_ri.pResetAK(v.vorschriftid);',
'    end loop;',
'  -- Antriebsarten',
' for v in (',
'        select distinct vorschriftid',
'        from t_vorschrift_ref_thema vrt',
'        join table ( apex_string.split_numbers(:P35_SELECTED_VORSCHRIFTEN_AA,'':'')  ) st on (st.column_value = vrt.vorschriftid)',
'        ',
'        where nvl(geloescht,0) = 0',
'        and themaid = lThemaID',
'    ) loop',
'        pck_ri.pResetAA(v.vorschriftid);',
'    end loop;  ',
'',
'  for v in (',
'        select distinct vorschriftid',
'        from t_vorschrift_ref_thema vrt',
'        join table ( apex_string.split_numbers(:P35_SELECTED_VORSCHRIFTEN_FU,'':'')  ) st on (st.column_value = vrt.vorschriftid)',
'        ',
'        where nvl(geloescht,0) = 0',
'        and themaid = lThemaID',
'    ) loop',
'        pck_ri.pResetFunktionen(v.vorschriftid);',
'    end loop;  ',
'end;    ',
'    ',
'    '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':REQUEST in (''SAVE'',''CREATE'') and :P35_VI_CHANGED = 1'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>2647135820105228313
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1025072838282159919)
,p_process_sequence=>120
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1025080070935159933)
,p_internal_uid=>2647139477617228316
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1025072428652159919)
,p_process_sequence=>130
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2647139887247228316
);
wwv_flow_imp.component_end;
end;
/
