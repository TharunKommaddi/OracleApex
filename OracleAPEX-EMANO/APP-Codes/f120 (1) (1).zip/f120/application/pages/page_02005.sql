prompt --application/pages/page_02005
begin
--   Manifest
--     PAGE: 02005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>2005
,p_name=>'Pflege Document Type und Publisher'
,p_alias=>'PFLEGE_DOCUMENT_TYP_UND_PUBLISHER'
,p_page_mode=>'MODAL'
,p_step_title=>'Pflege Document Type und Publisher'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(941831480416351392)
,p_plug_name=>'Form_Vor'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(941831125856351388)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(941831480416351392)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(941831007704351387)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(941831480416351392)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(941829807509351375)
,p_branch_action=>'f?p=&APP_ID.:2000:&SESSION.::&DEBUG.:2000::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3182770134917391811)
,p_name=>'P2005_FLAG_KONSOLIDIERTE_FASSUNGEN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(941831480416351392)
,p_item_default=>'0'
,p_prompt=>'Flag konsolidierte Fassung vorhanden'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT emano_util.fLang(''Ja'', ''Yes'') d, 1 r ',
'FROM dual',
'UNION ALL',
'SELECT emano_util.fLang(''Nein'', ''No'') d, 0 r ',
'FROM dual'))
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
' declare ',
'   l_co number :=0;',
' begin  ',
'',
'    with cte as  (',
'     select count(*) co , Document_typeid ',
'     from T_Vorschrift                                                    --  ''120:234:1306''  ''537:538''',
'     where   Vorschriftid in (select column_value from table (apex_string.split_numbers(:P2005_SELECTED_VORSCHRIFTEN, '':'') ) ) ',
'     group by Document_typeid',
'     ) ',
'     select 1 into l_co ',
'     from cte',
'     where ( (select count(*) from cte )  =1 ) ',
'     and  cte.Document_typeid = 1001;  -- Aenderungvorschrift',
'',
'   exception when others then',
'     null;',
'   return (l_co != 1);',
' end;',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:margin-bottom-md:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(941831390782351391)
,p_name=>'P2005_DOC_TYP'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(941831480416351392)
,p_prompt=>'Doc Typ'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct  Document_typeid ',
'     from T_Vorschrift                                                    --  ''120:234:1306''  ''537:538''',
'     where   Vorschriftid in (select column_value from table (apex_string.split_numbers(:P2005_SELECTED_VORSCHRIFTEN, '':'') ) )',
'   and Document_typeid is not null'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'  emano_util.fLang(text_deutsch, text_englisch) as display_value,',
'  document_typeid as return_value',
'FROM t_document_type',
'ORDER BY document_typeid;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Ausw\00E4hlen --')
,p_cSize=>60
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_inline_help_text=>unistr('<b><i class="fa fa-info-circle"></i> F\00FCr "<span style="color: #bb0a31;">\00C4nderungsregulation/Change Regulation</span>", Flag konsolidierte Fassung vorhanden ist auf "<span style="color: #bb0a31;">Ja</span>" gesetzt</b>')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(941831320655351390)
,p_name=>'P2005_PUBLISHER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(941831480416351392)
,p_prompt=>'Publisher'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(933459790931376256)
,p_name=>'P2005_LOAD_FROM'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(941831480416351392)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(933434293721817158)
,p_name=>'P2005_SELECTED_VORSCHRIFTEN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(941831480416351392)
,p_source=>':&P2005_LOAD_FROM.'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(941830381083351381)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(941831125856351388)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(941830314516351380)
,p_event_id=>wwv_flow_imp.id(941830381083351381)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(941830233661351379)
,p_name=>'sSAVE pPROCESS'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(941831007704351387)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(941830095588351378)
,p_event_id=>wwv_flow_imp.id(941830233661351379)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE  T_VORSCHRIFT SET DOCUMENT_TYPE = :P2005_DOC_TYP, PUBLISHER = :P2005_PUBLISHER',
' where vorschriftID in  (select y.column_value',
'                            from table(apex_string.split_numbers(:P2005_SELECTED_VORSCHRIFTEN, '':'')) y);'))
,p_attribute_02=>'P2005_SELECTED_VORSCHRIFTEN,P2005_DOC_TYP,P2005_PUBLISHER'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(941829965601351377)
,p_event_id=>wwv_flow_imp.id(941830233661351379)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3182770033396391810)
,p_name=>'Setting Document Value'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2005_DOC_TYP'
,p_condition_element=>'P2005_DOC_TYP'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1001'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3182769690333391806)
,p_event_id=>wwv_flow_imp.id(3182770033396391810)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2005_FLAG_KONSOLIDIERTE_FASSUNGEN'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1068996632183462232)
,p_event_id=>wwv_flow_imp.id(3182770033396391810)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2005_FLAG_KONSOLIDIERTE_FASSUNGEN'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3182769860543391808)
,p_event_id=>wwv_flow_imp.id(3182770033396391810)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2005_FLAG_KONSOLIDIERTE_FASSUNGEN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3182769770455391807)
,p_event_id=>wwv_flow_imp.id(3182770033396391810)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2005_FLAG_KONSOLIDIERTE_FASSUNGEN'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(941829865569351376)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Insert Update'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE T_VORSCHRIFT ',
'SET --DOCUMENT_TYPEID = :P2005_DOC_TYP,',
'    --PUBLISHER = :P2005_PUBLISHER, ',
'    FLAG_KONSOLIDIERTE_FASSUNGEN = to_number(:P2005_FLAG_KONSOLIDIERTE_FASSUNGEN)  ',
'         ',
'WHERE vorschriftID IN (',
'    SELECT y.column_value',
'    FROM table(apex_string.split_numbers(:P2005_SELECTED_VORSCHRIFTEN, '':'')) y',
') and DOCUMENT_TYPEID = 1001;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(941831007704351387)
,p_internal_uid=>2730382450330036859
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE  T_VORSCHRIFT SET DOCUMENT_TYPE = :P2005_DOC_TYP, PUBLISHER = :P2005_PUBLISHER',
' where vorschriftID in  (select y.column_value',
'                            from table(apex_string.split_numbers(:P2005_SELECTED_VORSCHRIFTEN, '':'')) y);'))
);
wwv_flow_imp.component_end;
end;
/
