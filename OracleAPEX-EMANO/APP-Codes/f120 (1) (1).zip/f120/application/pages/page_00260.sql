prompt --application/pages/page_00260
begin
--   Manifest
--     PAGE: 00260
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>260
,p_name=>'Publisher Stammdaten'
,p_alias=>'GETEX-PUBLISHER'
,p_step_title=>'Publisher Stammdaten'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2062604300649499929)
,p_plug_name=>'Publisher Stammdaten'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PUBLISHERID, ',
'       Name, ',
'       Einsatzdatum_modellid,',
'       ANZEIGE_MIT_DOKUMENTENDATUM,',
'       CASE ',
'           WHEN ANZEIGE_MIT_DOKUMENTENDATUM = 20 THEN ''Ja (mit Dokumentendatum)''',
'           WHEN ANZEIGE_MIT_DOKUMENTENDATUM = 10 THEN ''Nein (kein Dokumentendatum)''',
'       END as DOKUMENTENDATUM_STATUS',
'from T_PUBLISHER',
'-- where ANZEIGE_MIT_DOKUMENTENDATUM = :P260_FILTER_DOKUMENTENDATUM',
'order by name'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Publisher Stammdaten'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2062604409362499929)
,p_name=>'Getex Publisher'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'Keine Daten gefunden'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:265:&SESSION.::&DEBUG.:RP,265:P265_PUBLISHERID:\#PUBLISHERID#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>5734816725261888164
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1062623213656218588)
,p_db_column_name=>'PUBLISHERID'
,p_display_order=>0
,p_column_identifier=>'A'
,p_column_label=>'Publisherid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1062622762575218585)
,p_db_column_name=>'NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Publisher Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1062622327650218584)
,p_db_column_name=>'EINSATZDATUM_MODELLID'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Einsatzdatum Modell'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(1076773784946225404)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(981292919843851933)
,p_db_column_name=>'DOKUMENTENDATUM_STATUS'
,p_display_order=>23
,p_column_identifier=>'E'
,p_column_label=>'Anzeige Mit Dokumentendatum'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(981293040840851934)
,p_db_column_name=>'ANZEIGE_MIT_DOKUMENTENDATUM'
,p_display_order=>33
,p_column_identifier=>'D'
,p_column_label=>'Anzeige Mit Dokumentendatum'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2062608992305609186)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5156708'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NAME:EINSATZDATUM_MODELLID:DOKUMENTENDATUM_STATUS:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1062621688956218567)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2062604300649499929)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:265:&APP_SESSION.::&DEBUG.:265::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(981292843575851932)
,p_name=>'P260_FILTER_DOKUMENTENDATUM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2062604300649499929)
,p_item_default=>'10'
,p_prompt=>'Nur Publisher mit Dokumentendatum anzeigen'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT display_text, return_value ',
'FROM (',
'    SELECT ''Nein (kein Dokumentendatum)'' as display_text, ''10'' as return_value FROM dual',
'    UNION ALL',
'    SELECT ''Ja (mit Dokumentendatum)'' as display_text, ''20'' as return_value FROM dual',
')',
'ORDER BY return_value'))
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1062620732037218534)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2062604300649499929)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1062620227013218531)
,p_event_id=>wwv_flow_imp.id(1062620732037218534)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2062604300649499929)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(981292765503851931)
,p_name=>'Change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P260_FILTER_DOKUMENTENDATUM'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(981292686176851930)
,p_event_id=>wwv_flow_imp.id(981292765503851931)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2062604300649499929)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
