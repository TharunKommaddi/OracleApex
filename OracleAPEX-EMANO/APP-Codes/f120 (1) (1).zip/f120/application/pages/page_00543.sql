prompt --application/pages/page_00543
begin
--   Manifest
--     PAGE: 00543
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>543
,p_name=>'Verlinkte Normen'
,p_alias=>'VERLINKTE-NORMEN'
,p_page_mode=>'MODAL'
,p_step_title=>'Verlinkte Normen'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Click auf Checkbox in Tabellenheader: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'$(''#report-normen'').on(''click'', ''th input'', function() {',
'    var check_all = $("#report-normen").find("th input:checked").is(":checked");',
'',
'    $("#report-normen").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'    setSelecteVerknuepfungen();',
'});',
'',
'/* Click auf Checkbox in Tabellenzeile: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'',
'$(''#report-normen'').on(''click'', ''td input'', function() {',
'    setSelecteVerknuepfungen();',
'});',
'',
'function setSelecteVerknuepfungen() {',
'    var sel_rows = $("#P543_SELECTED_NORMEN");',
'    sel_rows.val("");',
'    $("#report-normen").find("td input:checked").each(function() {',
'      // alert(this.value);',
'      if(sel_rows.val().length > 0) {',
'        sel_rows.val(sel_rows.val() + ":");    ',
'      }',
'      sel_rows.val(sel_rows.val() + this.value);',
'    });',
'    alert(sel_rows.val());',
'}',
'            ',
''))
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_dialog_height=>'400'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(519846797291173350)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(712760182011977984)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(519846816170173350)
,p_plug_name=>'Vorschrift kopieren'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(700567619541495990)
,p_name=>'Verlinkte Normen'
,p_region_name=>'report-normen'
,p_parent_plug_id=>wwv_flow_imp.id(519846816170173350)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vn.rowid',
'    , vn.VERLINKTE_NORMID',
'    , vn.VORSCHRIFTID',
'    , vn.NUMMER as NormNummer',
'    , vn.BEZEICHNUNG AS NormBezeichnung',
'    , vn.LETZTE_AENDERUNG_DATUM',
'    , nvl2(vn.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname  , null) AS LETZTE_AENDERUNG_BENUTZER',
'FROM T_VERLINKTE_NORM vn',
'LEFT OUTER JOIN T_BENUTZER b on b.benutzerid = vn.LETZTE_AENDERUNG_BENUTZERID',
'WHERE VORSCHRIFTID = :P540_SOURCE_VORSCHRIFTID',
';'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>10000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(700567533402495989)
,p_query_column_id=>1
,p_column_alias=>'ROWID'
,p_column_display_sequence=>1
,p_column_heading=>'<input type="checkbox" />'
,p_column_html_expression=>'<input type="checkbox" value="#VERLINKTE_NORMID#" />'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(697276684826037099)
,p_query_column_id=>2
,p_column_alias=>'VERLINKTE_NORMID'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(700567413577495988)
,p_query_column_id=>3
,p_column_alias=>'VORSCHRIFTID'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(700567259286495987)
,p_query_column_id=>4
,p_column_alias=>'NORMNUMMER'
,p_column_display_sequence=>3
,p_column_heading=>'Nummer der Norm'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(700567161754495986)
,p_query_column_id=>5
,p_column_alias=>'NORMBEZEICHNUNG'
,p_column_display_sequence=>4
,p_column_heading=>'Bezeichnung der Norm'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(700567060054495985)
,p_query_column_id=>6
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>5
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_column_format=>'dd.mm.yyyy hh24:mi'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(700566987048495984)
,p_query_column_id=>7
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZER'
,p_column_display_sequence=>6
,p_column_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(519846922870173350)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(701790532967059770)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(519846922870173350)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(701790133818059770)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(519846922870173350)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('L\00E4nder und Themen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(700566431937495978)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(519846922870173350)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(701781717734059760)
,p_branch_name=>'Go To Page 545'
,p_branch_action=>'f?p=&APP_ID.:545:&SESSION.::&DEBUG.:25::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(701790133818059770)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(700566244286495977)
,p_branch_name=>'Go To Page 542'
,p_branch_action=>'f?p=&APP_ID.:542:&SESSION.::&DEBUG.:25::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(700566431937495978)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(697277018202037102)
,p_name=>'P543_SELECTED_NORMEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(700567619541495990)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(701786368876059764)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(701790532967059770)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(701785851642059762)
,p_event_id=>wwv_flow_imp.id(701786368876059764)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(701789335944059768)
,p_name=>'copy nachfolger changed'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P543_COPY_NACHFOLGER'
,p_condition_element=>'P543_COPY_NACHFOLGER'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Y'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(701788754955059767)
,p_event_id=>wwv_flow_imp.id(701789335944059768)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P543_COPY_ALL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(701788321977059766)
,p_event_id=>wwv_flow_imp.id(701789335944059768)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P543_COPY_ALL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(701785466080059761)
,p_name=>'Goto Next'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(701790133818059770)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(701784456544059761)
,p_event_id=>wwv_flow_imp.id(701785466080059761)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(701784984830059761)
,p_event_id=>wwv_flow_imp.id(701785466080059761)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(701783159653059761)
,p_name=>'VORSCHRIFT_CHANGED'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P543_SOURCE_VORSCHRIFTID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(701782715071059760)
,p_event_id=>wwv_flow_imp.id(701783159653059761)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P543_SOURCE_VORSCHRIFTID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(701782228806059760)
,p_event_id=>wwv_flow_imp.id(701783159653059761)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P543_VORSCHRIFT_BEZEICHNUNG,P543_SOURCE_VORSCHRIFT_NUMMER'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(701784049802059761)
,p_name=>'copy all changed'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P543_COPY_ALL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(701789678488059770)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Copy Vorschrift'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P543_NEW_VORSCHRIFTID := pck_ri.fCopyVorschrift(aSourceVorschriftId => :P543_SOURCE_VORSCHRIFTID, ',
'                                                 aTargetVorschriftNummer => :P543_VORSCHRIFTNUMMER,',
'                                                 aCopyNachfolger => (:P543_COPY_NACHFOLGER = ''Y''), ',
'                                                 aCopyAll => (:P543_COPY_ALL = ''Y''));'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2970422637411328465
);
wwv_flow_imp.component_end;
end;
/
