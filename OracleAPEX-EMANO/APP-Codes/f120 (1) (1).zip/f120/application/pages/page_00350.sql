prompt --application/pages/page_00350
begin
--   Manifest
--     PAGE: 00350
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>350
,p_name=>unistr('\00C4nderungshistorie Vorschrift Kerndaten')
,p_alias=>unistr('\00C4NDERUNGSHISTORIE-VORSCHRIFT-KERNDATEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('\00C4nderungshistorie Vorschrift Kerndaten')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IR_HIST .t-fht-tbody {max-height: calc(100vh - 200px)}',
'.t-Body-topButton {display: none !important}',
'.t-Body-content {padding-bottom: 3px !important}',
'.t-Body {margin-bottom: 3px !important}',
'.t-Body-contentInner {padding-bottom: 0px !important}'))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(932995171403791989)
,p_plug_name=>'Historie Vorschrift Kerndaten'
,p_region_name=>'IR_HIST'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'select H_VORSCHRIFTID,',
'       v.VORSCHRIFTID,',
'       vt.BEZEICHNUNG as VORSCHRIFT_TYP, LAG(vt.BEZEICHNUNG) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as VORSCHRIFT_TYP_H,',
'       edm.MODELL as EINSATZDATUM_MODELL, LAG(edm.MODELL) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as EINSATZDATUM_MODELL_H,',
'       vn.BEZEICHNUNG as NORM, LAG(vn.BEZEICHNUNG) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as NORM_H,',
'       v.VORSCHRIFT_NUMMER as VORSCHRIFT_NUMMER, LAG(v.VORSCHRIFT_NUMMER) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as VORSCHRIFT_NUMMER_H,',
'       v.vorschrift_bezeichnung as VORSCHRIFT_BEZEICHNUNG, LAG(v.vorschrift_bezeichnung) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as VORSCHRIFT_BEZEICHNUNG_H,',
'       -- pq.display_value as PROGNOSE_QUALITAET, LAG(pq.display_value) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as PROGNOSE_QUALITAET_H,',
unistr('       decode(v.PROGNOSE_QUALITAETid, 0, ''offen'', 10, ''sicher'', 20, ''absch\00E4tzbar'', 30, ''best\00E4tigt (in Kraft)'') as PROGNOSE_QUALITAET, LAG(decode(v.PROGNOSE_QUALITAETid, 0, ''offen'', 10, ''sicher'', 20, ''absch\00E4tzbar'', 30, ''best\00E4tigt (in Kraft)'')) over(pa')
||'rtition by v.vorschriftid order by v.letzte_aenderung_datum asc) as PROGNOSE_QUALITAET_H,',
'       v.JIRA_TICKET as JIRA_TICKET, LAG(v.JIRA_TICKET) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as JIRA_TICKET_H,',
'       -- fs.display_value as VORSCHRIFT_FREIGABESTATUS, LAG(fs.display_value) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as VORSCHRIFT_FREIGABESTATUS_H,',
'       DECODE(v.VORSCHRIFT_FREIGABESTATUSID,',
'        -1, ''Neue Vorschrift aus GETEX'',',
unistr('         1, ''Grundbef\00FCllung (sichtbar f\00FCr VKO)'','),
unistr('        10, ''in Bearbeitung (sichtbar f\00FCr VKO und VEX)'','),
unistr('        20, ''Freigegeben (sichtbar f\00FCr alle User)'','),
unistr('        30, ''nicht relevant (sichtbar f\00FCr VKO und VEX)'') as VORSCHRIFT_FREIGABESTATUS, '),
'        LAG(DECODE(v.VORSCHRIFT_FREIGABESTATUSID,',
'        -1, ''Neue Vorschrift aus GETEX'',',
unistr('         1, ''Grundbef\00FCllung (sichtbar f\00FCr VKO)'','),
unistr('        10, ''in Bearbeitung (sichtbar f\00FCr VKO und VEX)'','),
unistr('        20, ''Freigegeben (sichtbar f\00FCr alle User)'','),
unistr('        30, ''nicht relevant (sichtbar f\00FCr VKO und VEX)''))'),
'        OVER (PARTITION BY v.vorschriftid ORDER BY v.letzte_aenderung_datum asc) AS VORSCHRIFT_FREIGABESTATUS_H,',
'',
'',
'       vs.STATUS as VORSCHRIFT_STATUS, LAG(vs.STATUS) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as VORSCHRIFT_STATUS_H,',
'       -- hr.display_value as HOMOLOGATION_MOEGLICH, LAG(hr.display_value) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as HOMOLOGATION_MOEGLICH_H,',
unistr('       DECODE(v.HOMOLOGATIONSRELEVANT, 10,''Ja'',0,''Nein'',20, ''Nicht gepr\00FCft'') AS HOMOLOGATIONSRELEVANT,'),
unistr('       LAG(DECODE(v.HOMOLOGATIONSRELEVANT, 10,''Ja'',0,''Nein'',20, ''Nicht gepr\00FCft''))'),
'      OVER (PARTITION BY v.vorschriftid ORDER BY v.letzte_aenderung_datum ASC) AS HOMOLOGATIONSRELEVANT_H,',
'       ',
'',
unistr('       decode(v.rxswin,10,''Ja'',0,''Nein'',20, ''Nicht gepr\00FCft'') as rxswin, lag(decode(v.rxswin,10,''Ja'',0,''Nein'',20,''Nicht gepr\00FCft'')) over (partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as rxswin_h,'),
'       --rwr.display_value as RXSWIN, LAG(rwr.display_value) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as RXSWIN_H,',
'       ',
'       ',
'       v.bemerkung as BEMERKUNG, LAG(v.bemerkung) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as BEMERKUNG_H,',
'       v.LINK_ZUR_VORSCHRIFT_DMS as LINK_ZUR_VORSCHRIFT_DMS, LAG(v.LINK_ZUR_VORSCHRIFT_DMS) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as LINK_ZUR_VORSCHRIFT_DMS_H,',
'       v.LINK_ZUR_VORSCHRIFT_GETEX as LINK_ZUR_VORSCHRIFT_GETEX, LAG(v.LINK_ZUR_VORSCHRIFT_GETEX) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as LINK_ZUR_VORSCHRIFT_GETEX_H,',
'       ws.WEBSITE_NAME as WEBSITE, LAG(ws.WEBSITE_NAME) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as WEBSITE_H,',
'       v.WEBSITELINK as WEBSITELINK, LAG(v.WEBSITELINK) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as WEBSITELINK_H,',
'       ksu.BEZEICHNUNG as KSU, LAG(ksu.BEZEICHNUNG) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as KSU_H,',
unistr('       /*case v.cop_relevant when 0 then ''nein'' when 10 then ''ja'' when 20 then ''nicht gepr\00FCft'' else '''' || v.cop_relevant end as cop_relevant, case LAG(v.cop_relevant) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) when 0 then')
||unistr(' ''nein'' when 10 then ''ja'' WHEN 20 THEN ''nicht gepr\00FCft'' else '''' || LAG(v.cop_relevant) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) end  as cop_relevant_h,*/'),
unistr('       decode(v.cop_relevant,0,''Nein'',10,''Ja'',20,''Nicht gepr\00FCft'') as cop_relevant, lag(decode(v.cop_relevant,0,''Nein'',10,''Ja'',20, ''Nicht gepr\00FCft'')) over (partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as cop_relevant_h,'),
'       v.letzte_aenderung_datum as letzte_aenderung_datum,',
'       pck_ri.fCreatePermalinkUrl(v.vorschriftid) as PERMALINK,',
'       decode(v.rev_notwendig,10,''Nicht bewertet'',20,''Ja'',30,''Nein'') as rev_notwendig, lag(decode(v.rev_notwendig,10,''Nicht bewertet'',20,''Ja'',30, ''Nein'')) over (partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as rev_notwendig_h,',
'       b.email as EMAIL,',
'       nvl2(v.letzte_aenderung_benutzerid, b.nachname || '', '' || b.vorname, null) AS LETZTE_AENDERUNG_BENUTZER,',
'',
'       -- newly added ',
'',
'       decode(v.MASTER,10,''Master in RegIndex'',20,''Master in GETEX'') as MASTER, lag(decode(v.MASTER,10,''Master in RegIndex'',20,''Master in GETEX'')) over (partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as MASTER_H,',
'',
'       /*',
'       v.MASTER as MASTER,',
'       LAG(v.MASTER) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as MASTER_H,',
'       */',
'       v.DOKUMENTENDATUM as DOKUMENTENDATUM,',
'       LAG(v.DOKUMENTENDATUM) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as DOKUMENTENDATUM_H,',
'       v.SWR_HAUPTUMSETZENDE_OE as SWR_HAUPTUMSETZENDE_OE,',
'       LAG(v.SWR_HAUPTUMSETZENDE_OE) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as SWR_HAUPTUMSETZENDE_OE_H,',
'       v.TITEL_KURZ as TITEL_KURZ,',
'       LAG(v.TITEL_KURZ) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as TITEL_KURZ_H,',
'       v.URL_GETEX_VORSCHRIFT as URL_GETEX_VORSCHRIFT,',
'       LAG(v.URL_GETEX_VORSCHRIFT) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as URL_GETEX_VORSCHRIFT_H,',
'       v.TECHNOLOGIE as TECHNOLOGIE,',
'       LAG(v.TECHNOLOGIE) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as TECHNOLOGIE_H,',
'       v.BEMERKUNG_ENGLISCH as BEMERKUNG_ENGLISCH,',
'       LAG(v.BEMERKUNG_ENGLISCH) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as BEMERKUNG_ENGLISCH_H,',
'    --    dt.TEXT_DEUTSCH as TEXT_DEUTSCH,',
'    --    LAG(dt.TEXT_DEUTSCH) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as TEXT_DEUTSCH_H,',
'    --    dt.TEXT_ENGLISCH as TEXT_ENGLISCH,',
'    --    LAG(dt.TEXT_ENGLISCH) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as TEXT_ENGLISCH_H',
'    CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN dt.TEXT_DEUTSCH ELSE dt.TEXT_ENGLISCH END AS DOCUMENT_TYPE_TEXT,',
'    LAG(CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN dt.TEXT_DEUTSCH ELSE dt.TEXT_ENGLISCH END) OVER (PARTITION BY v.vorschriftid ORDER BY v.letzte_aenderung_datum ASC) AS DOCUMENT_TYPE_TEXT_H,',
'    v.LEAD_VKO_BENUTZER as LEAD_VKO_BENUTZER, ',
'    LAG(v.LEAD_VKO_BENUTZER) over(partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as LEAD_VKO_BENUTZER_H,',
'    decode(v.flag_konsolidierte_fassungen,0,''Nein'',1,''Ja'') as FLAG_KONSOLIDIERTE_FASSUNGEN, ',
'    lag(decode(v.flag_konsolidierte_fassungen,0,''Nein'',1,''Ja'')) over (partition by v.vorschriftid order by v.letzte_aenderung_datum asc) as FLAG_KONSOLIDIERTE_FASSUNGEN_H',
'',
'',
'',
'       ',
'',
'from T_H_VORSCHRIFT v',
'LEFT OUTER JOIN t_vorschrift tv ON tv.vorschriftid = v.vorschriftid',
'LEFT OUTER JOIN t_document_type dt ON tv.document_typeid = dt.document_typeid',
'left outer join t_benutzer b on (b.benutzerid = v.letzte_aenderung_benutzerid)',
'left outer join T_VORSCHRIFT_TYP vt on (vt.VORSCHRIFT_TYPID = v.VORSCHRIFT_TYPID)',
'left outer join T_EINSATZDATUM_MODELL edm on (edm.EINSATZDATUM_MODELLID = v.EINSATZDATUM_MODELLID)',
'left outer join T_NORM vn on (vn.NORMID = v.NORMID)',
'/*',
'left outer join apex_application_lov_entries pq on (pq.return_value = v.prognose_qualitaet ',
'                                                    and pq.list_of_values_name = ''LOV_VORSCHRIFT_PROGNOSE_QUALITAET''',
'                                                    and pq.application_id = :APP_ID)',
'*/',
'',
'/*',
'left outer join apex_application_lov_entries fs on (fs.return_value = v.VORSCHRIFT_FREIGABESTATUSID ',
'                                                    and fs.list_of_values_name = ''LOV_VORSCHRIFT_FREIGABE_STATUS''',
'                                                    and fs.application_id = :APP_ID)',
'*/',
'',
'',
'left outer join T_VORSCHRIFT_STATUS vs on (vs.VORSCHRIFT_STATUSID = v.VORSCHRIFT_STATUSID)',
'/*',
'left outer join apex_application_lov_entries hr on (hr.return_value = v.HOMOLOGATIONSRELEVANT ',
'                                                    and hr.list_of_values_name = ''LOV_HOMOLOGATIONSRELEVANT''',
'                                                    and hr.application_id = :APP_ID)',
'',
'*/',
'',
'/*',
'left outer join apex_application_lov_entries rwr on (rwr.return_value = v.RXSWIN ',
'                                                    and rwr.list_of_values_name = ''LOV_RXSWIN_RELEVANT''',
'                                                    and rwr.application_id = :APP_ID)',
'*/',
'left outer join T_WEBSITE ws on (ws.WEBSITEID = v.WEBSITEID)',
'left outer join T_KSU ksu on (ksu.KSUID = v.KSUID)',
'',
'where v.VORSCHRIFTID = :P350_VORSCHRIFTID',
')',
'select cte1.H_VORSCHRIFTID,',
'       cte1.VORSCHRIFTID,',
'       pck_ri_history.fdiff(cte1.VORSCHRIFT_TYP, cte1.VORSCHRIFT_TYP_H) as VORSCHRIFT_TYP,',
'       pck_ri_history.fdiff(cte1.EINSATZDATUM_MODELL, cte1.EINSATZDATUM_MODELL_H) as EINSATZDATUM_MODELL,',
'       pck_ri_history.fdiff(cte1.NORM, cte1.NORM_H) as NORM,',
'       pck_ri_history.fdiff(cte1.VORSCHRIFT_NUMMER, cte1.VORSCHRIFT_NUMMER_H) as VORSCHRIFT_NUMMER,',
'       pck_ri_history.fdiff(cte1.VORSCHRIFT_BEZEICHNUNG, cte1.VORSCHRIFT_BEZEICHNUNG_H) as VORSCHRIFT_BEZEICHNUNG,',
'       pck_ri_history.fdiff(cte1.PROGNOSE_QUALITAET, cte1.PROGNOSE_QUALITAET_H) as PROGNOSE_QUALITAET,',
'       pck_ri_history.fdiff(cte1.JIRA_TICKET, cte1.JIRA_TICKET_H) as JIRA_TICKET,',
'       pck_ri_history.fdiff(cte1.VORSCHRIFT_FREIGABESTATUS, cte1.VORSCHRIFT_FREIGABESTATUS_H) as VORSCHRIFT_FREIGABESTATUS,',
'       pck_ri_history.fdiff(cte1.VORSCHRIFT_STATUS, cte1.VORSCHRIFT_STATUS_H) as VORSCHRIFT_STATUS,',
'       pck_ri_history.fdiff(cte1.HOMOLOGATIONSRELEVANT, cte1.HOMOLOGATIONSRELEVANT_H) as HOMOLOGATIONSRELEVANT,',
'       pck_ri_history.fdiff(cte1.RXSWIN, cte1.RXSWIN_H) as RXSWIN,',
'       pck_ri_history.fdiff(cte1.BEMERKUNG, cte1.BEMERKUNG_H) as BEMERKUNG,',
'       pck_ri_history.fdiff(cte1.LINK_ZUR_VORSCHRIFT_DMS, cte1.LINK_ZUR_VORSCHRIFT_DMS_H) as LINK_ZUR_VORSCHRIFT_DMS,',
'       pck_ri_history.fdiff(cte1.LINK_ZUR_VORSCHRIFT_GETEX, cte1.LINK_ZUR_VORSCHRIFT_GETEX_H) as LINK_ZUR_VORSCHRIFT_GETEX,',
'       pck_ri_history.fdiff(cte1.WEBSITE, cte1.WEBSITE_H) as WEBSITE,',
'       pck_ri_history.fdiff(cte1.WEBSITELINK, cte1.WEBSITELINK_H) as WEBSITELINK,',
'       pck_ri_history.fdiff(cte1.KSU, cte1.KSU_H) as KSU,',
'       pck_ri_history.fdiff(cte1.cop_relevant, cte1.cop_relevant_h) as cop_relevant,',
'       cte1.letzte_aenderung_datum as letzte_aenderung_datum,',
'       cte1.PERMALINK as PERMALINK,',
'       cte1.email as EMAIL,',
'       pck_ri_history.fdiff(cte1.rev_notwendig, cte1.rev_notwendig_h) as rev_notwendig,',
'       cte1.LETZTE_AENDERUNG_BENUTZER AS LETZTE_AENDERUNG_BENUTZER,',
'        -- newly added ',
'       pck_ri_history.fdiff(cte1.MASTER, cte1.MASTER_H) as MASTER,',
'       pck_ri_history.fdiff(cte1.DOKUMENTENDATUM, cte1.DOKUMENTENDATUM_H) as DOKUMENTENDATUM,',
'       pck_ri_history.fdiff(cte1.SWR_HAUPTUMSETZENDE_OE, cte1.SWR_HAUPTUMSETZENDE_OE_H) as SWR_HAUPTUMSETZENDE_OE,',
'       pck_ri_history.fdiff(cte1.TITEL_KURZ, cte1.TITEL_KURZ_H) as TITEL_KURZ,',
'       pck_ri_history.fdiff(cte1.URL_GETEX_VORSCHRIFT, cte1.URL_GETEX_VORSCHRIFT_H) as URL_GETEX_VORSCHRIFT,',
'       pck_ri_history.fdiff(cte1.TECHNOLOGIE, cte1.TECHNOLOGIE_H) as TECHNOLOGIE,',
'       pck_ri_history.fdiff(cte1.BEMERKUNG_ENGLISCH, cte1.BEMERKUNG_ENGLISCH_H) as BEMERKUNG_ENGLISCH,',
'    --    pck_ri_history.fdiff(cte1.TEXT_DEUTSCH, cte1.TEXT_DEUTSCH_H) AS DOCUMENT_TYPE_DEUTSCH,',
'    --    pck_ri_history.fdiff(cte1.TEXT_ENGLISCH, cte1.TEXT_ENGLISCH_H) AS DOCUMENT_TYPE_ENGLISCH',
'       pck_ri_history.fdiff(cte1.DOCUMENT_TYPE_TEXT, cte1.DOCUMENT_TYPE_TEXT_H) AS DOCUMENT_TYPE_TEXT,',
'       pck_ri_history.fdiff(cte1.LEAD_VKO_BENUTZER, cte1.LEAD_VKO_BENUTZER_H) as LEAD_VKO_BENUTZER,',
'       pck_ri_history.fdiff(cte1.FLAG_KONSOLIDIERTE_FASSUNGEN, cte1.FLAG_KONSOLIDIERTE_FASSUNGEN_H) as FLAG_KONSOLIDIERTE_FASSUNGEN',
'',
'',
'',
'',
'from cte1 ',
'where ',
'       (cte1.VORSCHRIFT_TYP <> cte1.VORSCHRIFT_TYP_H)',
'       OR (nvl(cte1.EINSATZDATUM_MODELL, ''-1'') <> nvl(cte1.EINSATZDATUM_MODELL_H, ''-1''))',
'       OR (nvl(cte1.NORM, ''-1'') <> nvl(cte1.NORM_H, ''-1''))',
'       OR (nvl(cte1.VORSCHRIFT_NUMMER, ''-1'') <> nvl(cte1.VORSCHRIFT_NUMMER_H, ''-1''))',
'       OR (nvl(cte1.VORSCHRIFT_BEZEICHNUNG, ''-1'') <> nvl(cte1.VORSCHRIFT_BEZEICHNUNG_H, ''-1''))',
'       OR (nvl(cte1.PROGNOSE_QUALITAET, ''-1'') <> nvl(cte1.PROGNOSE_QUALITAET_H, ''-1''))',
'       OR (nvl(cte1.JIRA_TICKET, ''-1'') <> nvl(cte1.JIRA_TICKET_H, ''-1''))',
'       OR (nvl(cte1.VORSCHRIFT_FREIGABESTATUS, ''-1'') <> nvl(cte1.VORSCHRIFT_FREIGABESTATUS_H, ''-1''))',
'       OR (nvl(cte1.VORSCHRIFT_STATUS, ''-1'') <> nvl(cte1.VORSCHRIFT_STATUS_H, ''-1''))',
'       OR (nvl(cte1.HOMOLOGATIONSRELEVANT, ''-1'') <> nvl(cte1.HOMOLOGATIONSRELEVANT_H, ''-1''))',
'       OR (nvl(cte1.RXSWIN, ''-1'') <> nvl(cte1.RXSWIN_H, ''-1''))',
'       OR (nvl(cte1.BEMERKUNG, ''-1'') <> nvl(cte1.BEMERKUNG_H, ''-1''))',
'       OR (nvl(cte1.BEMERKUNG_ENGLISCH, ''-1'') <> nvl(cte1.BEMERKUNG_ENGLISCH_H, ''-1''))       ',
'       OR (nvl(cte1.LINK_ZUR_VORSCHRIFT_DMS, ''-1'') <> nvl(cte1.LINK_ZUR_VORSCHRIFT_DMS_H, ''-1''))',
'       OR (nvl(cte1.LINK_ZUR_VORSCHRIFT_GETEX, ''-1'') <> nvl(cte1.LINK_ZUR_VORSCHRIFT_GETEX_H, ''-1''))',
'       OR (nvl(cte1.WEBSITE, ''-1'') <> nvl(cte1.WEBSITE_H, ''-1''))',
'       OR (nvl(cte1.WEBSITELINK, ''-1'') <> nvl(cte1.WEBSITELINK_H, ''-1''))',
'       OR (nvl(cte1.KSU, ''-1'') <> nvl(cte1.KSU_H, ''-1''))',
'       OR (nvl(cte1.cop_relevant, ''-1'') <> nvl(cte1.cop_relevant_H, ''-1''))',
'',
'        OR (nvl(cte1.MASTER, ''-1'') <> nvl(cte1.MASTER_H, ''-1''))',
'        ---OR (nvl(cte1.DOKUMENTENDATUM, TO_DATE(''01.01.0001'',''DD.MM.YYYY'')) <> nvl(cte1.DOKUMENTENDATUM_H, TO_DATE(''01.01.0001'',''DD.MM.YYYY'')))',
'        OR (NVL(TO_CHAR(cte1.DOKUMENTENDATUM, ''DD.MM.YYYY''), ''N/A'') <> NVL(TO_CHAR(cte1.DOKUMENTENDATUM_H, ''DD.MM.YYYY''), ''N/A''))',
'        OR (nvl(cte1.SWR_HAUPTUMSETZENDE_OE, ''-1'') <> nvl(cte1.SWR_HAUPTUMSETZENDE_OE_H, ''-1''))',
'        OR (nvl(cte1.TITEL_KURZ, ''-1'') <> nvl(cte1.TITEL_KURZ_H, ''-1''))',
'        OR (nvl(cte1.URL_GETEX_VORSCHRIFT, ''-1'') <> nvl(cte1.URL_GETEX_VORSCHRIFT_H, ''-1''))',
'        OR (nvl(cte1.TECHNOLOGIE, ''-1'') <> nvl(cte1.TECHNOLOGIE_H, ''-1''))',
'        ',
'        -- OR (nvl(cte1.TEXT_DEUTSCH, ''-1'') <> nvl(cte1.TEXT_DEUTSCH_H, ''-1''))',
'        -- OR (nvl(cte1.TEXT_ENGLISCH, ''-1'') <> nvl(cte1.TEXT_ENGLISCH_H, ''-1''))',
'        OR (nvl(cte1.DOCUMENT_TYPE_TEXT, ''-1'') <> nvl(cte1.DOCUMENT_TYPE_TEXT_H, ''-1''))',
'        OR (nvl(cte1.LEAD_VKO_BENUTZER, ''-1'') <> nvl(cte1.LEAD_VKO_BENUTZER_H, ''-1''))',
'         OR (nvl(cte1.FLAG_KONSOLIDIERTE_FASSUNGEN, ''-1'') <> nvl(cte1.FLAG_KONSOLIDIERTE_FASSUNGEN_H, ''-1''))',
'',
'',
'',
'order by cte1.LETZTE_AENDERUNG_DATUM desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_page_header=>'Historie Vorschrift Kerndaten'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(932995094866791989)
,p_name=>'Historie Vorschrift Kerndaten'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>unistr('Es gibt noch keine historischen Eintr\00E4ge f\00FCr diese Vorschrift.')
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>1000
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'mailto:#EMAIL#?body=#PERMALINK#'
,p_detail_link_text=>'<span class="fa fa-envelope-o" aria-hidden="true"></span>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>179697842228342415
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016220512789619200)
,p_db_column_name=>'H_VORSCHRIFTID'
,p_display_order=>10
,p_column_identifier=>'AU'
,p_column_label=>'H Vorschriftid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016384322237116579)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Vorschriftid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016393039031116589)
,p_db_column_name=>'VORSCHRIFT_TYP'
,p_display_order=>30
,p_column_identifier=>'Y'
,p_column_label=>'Vorschrift Typ'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016392695128116586)
,p_db_column_name=>'EINSATZDATUM_MODELL'
,p_display_order=>40
,p_column_identifier=>'Z'
,p_column_label=>'Einsatz DATUM Modell'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016392314406116585)
,p_db_column_name=>'NORM'
,p_display_order=>50
,p_column_identifier=>'AA'
,p_column_label=>'Notation Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016391873738116585)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>60
,p_column_identifier=>'AB'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016391525924116585)
,p_db_column_name=>'VORSCHRIFT_BEZEICHNUNG'
,p_display_order=>70
,p_column_identifier=>'AC'
,p_column_label=>unistr('Titel (\00DCberschrift)')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016391097964116584)
,p_db_column_name=>'PROGNOSE_QUALITAET'
,p_display_order=>80
,p_column_identifier=>'AD'
,p_column_label=>unistr('Prognosequalit\00E4t Einsatztermine')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016390659501116584)
,p_db_column_name=>'JIRA_TICKET'
,p_display_order=>90
,p_column_identifier=>'AE'
,p_column_label=>'Jira-Tickets'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016390291375116584)
,p_db_column_name=>'VORSCHRIFT_FREIGABESTATUS'
,p_display_order=>100
,p_column_identifier=>'AF'
,p_column_label=>'Interner DB Freigabestatus'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016389877146116583)
,p_db_column_name=>'VORSCHRIFT_STATUS'
,p_display_order=>110
,p_column_identifier=>'AG'
,p_column_label=>'Status der Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016389038157116583)
,p_db_column_name=>'RXSWIN'
,p_display_order=>130
,p_column_identifier=>'AI'
,p_column_label=>'Potentiell SUMS-relevant'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016388647143116582)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>140
,p_column_identifier=>'AJ'
,p_column_label=>'Bemerkung zur Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016388277977116582)
,p_db_column_name=>'LINK_ZUR_VORSCHRIFT_DMS'
,p_display_order=>150
,p_column_identifier=>'AK'
,p_column_label=>'Link zu DMS'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016387863333116582)
,p_db_column_name=>'LINK_ZUR_VORSCHRIFT_GETEX'
,p_display_order=>160
,p_column_identifier=>'AL'
,p_column_label=>'Getex 1.0 ID'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016387470810116581)
,p_db_column_name=>'WEBSITE'
,p_display_order=>170
,p_column_identifier=>'AM'
,p_column_label=>'Webseite'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016387092637116581)
,p_db_column_name=>'WEBSITELINK'
,p_display_order=>180
,p_column_identifier=>'AN'
,p_column_label=>'Link zu Web Site'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016386668022116581)
,p_db_column_name=>'KSU'
,p_display_order=>190
,p_column_identifier=>'AO'
,p_column_label=>'KSU'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016386315079116581)
,p_db_column_name=>'EMAIL'
,p_display_order=>200
,p_column_identifier=>'AQ'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016385864537116580)
,p_db_column_name=>'PERMALINK'
,p_display_order=>210
,p_column_identifier=>'AR'
,p_column_label=>'Permalink'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016385507634116580)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>220
,p_column_identifier=>'AS'
,p_column_label=>unistr('\00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016385061201116579)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>230
,p_column_identifier=>'AT'
,p_column_label=>unistr('\00C4nderung Datum')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(895789886841594087)
,p_db_column_name=>'COP_RELEVANT'
,p_display_order=>240
,p_column_identifier=>'AV'
,p_column_label=>'Cop Relevant'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(708794035584753979)
,p_db_column_name=>'MASTER'
,p_display_order=>260
,p_column_identifier=>'BC'
,p_column_label=>unistr('Master f\00FCr diese Vorschrift')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(708793904494753978)
,p_db_column_name=>'DOKUMENTENDATUM'
,p_display_order=>270
,p_column_identifier=>'BD'
,p_column_label=>'Dokumentendatum'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(708793765427753977)
,p_db_column_name=>'SWR_HAUPTUMSETZENDE_OE'
,p_display_order=>280
,p_column_identifier=>'BE'
,p_column_label=>'OE2 des REV'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(708793727999753976)
,p_db_column_name=>'TITEL_KURZ'
,p_display_order=>290
,p_column_identifier=>'BF'
,p_column_label=>'Kurztitel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(708793623186753975)
,p_db_column_name=>'URL_GETEX_VORSCHRIFT'
,p_display_order=>300
,p_column_identifier=>'BG'
,p_column_label=>'Getex URL'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(708793445819753974)
,p_db_column_name=>'TECHNOLOGIE'
,p_display_order=>310
,p_column_identifier=>'BH'
,p_column_label=>'Technologie'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(708791634872753955)
,p_db_column_name=>'BEMERKUNG_ENGLISCH'
,p_display_order=>320
,p_column_identifier=>'BI'
,p_column_label=>'Bemerkung zur Vorschrift English'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(701662318792422901)
,p_db_column_name=>'DOCUMENT_TYPE_TEXT'
,p_display_order=>330
,p_column_identifier=>'BM'
,p_column_label=>'Document Type'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(701662175635422900)
,p_db_column_name=>'HOMOLOGATIONSRELEVANT'
,p_display_order=>340
,p_column_identifier=>'BN'
,p_column_label=>'Homologationsrelevant'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(645329461449071803)
,p_db_column_name=>'REV_NOTWENDIG'
,p_display_order=>350
,p_column_identifier=>'BO'
,p_column_label=>'REV Notwendig'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3192356723663204720)
,p_db_column_name=>'LEAD_VKO_BENUTZER'
,p_display_order=>360
,p_column_identifier=>'BP'
,p_column_label=>'Lead VKO'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1023438012218058799)
,p_db_column_name=>'FLAG_KONSOLIDIERTE_FASSUNGEN'
,p_display_order=>370
,p_column_identifier=>'BQ'
,p_column_label=>'Flag konsolidierte Fassung vorhanden'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(932976920512778816)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'963090'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LETZTE_AENDERUNG_BENUTZER:LETZTE_AENDERUNG_DATUM:LEAD_VKO_BENUTZER:MASTER:VORSCHRIFT_TYP:EINSATZDATUM_MODELL:NORM:VORSCHRIFT_NUMMER:TITEL_KURZ:VORSCHRIFT_BEZEICHNUNG:PROGNOSE_QUALITAET:VORSCHRIFT_FREIGABESTATUS:VORSCHRIFT_STATUS:RXSWIN:SWR_HAUPTUMSET'
||'ZENDE_OE:COP_RELEVANT:HOMOLOGATIONSRELEVANT:REV_NOTWENDIG:BEMERKUNG:BEMERKUNG_ENGLISCH:LINK_ZUR_VORSCHRIFT_DMS:LINK_ZUR_VORSCHRIFT_GETEX:URL_GETEX_VORSCHRIFT:WEBSITE:WEBSITELINK:KSU:TECHNOLOGIE:DOKUMENTENDATUM:DOCUMENT_TYPE_TEXT:JIRA_TICKET:FLAG_KONS'
||'OLIDIERTE_FASSUNGEN:'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1016383524068116561)
,p_name=>'P350_VORSCHRIFTID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(932995171403791989)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
