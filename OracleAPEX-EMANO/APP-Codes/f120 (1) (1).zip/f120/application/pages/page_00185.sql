prompt --application/pages/page_00185
begin
--   Manifest
--     PAGE: 00185
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>185
,p_name=>'Jira -Ticket erstellen'
,p_page_mode=>'MODAL'
,p_step_title=>'Jira-Ticket erstellen'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1058219478141348903)
,p_plug_name=>'JIRA'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1058219765340348906)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1058219689526348905)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1058219765340348906)
,p_button_name=>'BTN_URL_OPEN'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'URL aufrufen'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1058219558366348904)
,p_name=>'P185_URL_TEXT'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(1058219478141348903)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Jira-Ticket-URL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' l_vs_nummer varchar2(4096);',
' l_vs_bezeichnung varchar2(4096);',
' l_vs_status varchar2(4096);',
' l_progn_quali varchar2(4096);',
' l_datum_in_kraft varchar2(4096);',
' l_datum_neuer_typ varchar2(4096);',
' l_datum_alle_typen varchar2(4096);',
' l_laender_fields varchar2(4096);',
' l_ak_fields varchar2(4096);',
'begin',
'',
'select v.vorschrift_nummer, v.vorschrift_bezeichnung,',
' s.status',
'into l_vs_nummer, l_vs_bezeichnung,',
' l_vs_status',
'from t_vorschrift v',
'left outer join t_vorschrift_status s on s.VORSCHRIFT_STATUSID = v.VORSCHRIFT_STATUSID',
'where v.vorschriftid = :P185_VORSCHRIFTID;',
'',
'select case when v.prognose_qualitaet = 10 then ''sicher''',
unistr('  when v.prognose_qualitaet = 20 then ''absch\00E4tzbar'''),
'  else null',
' end into l_progn_quali',
'from T_VORSCHRIFT v',
'where v.vorschriftid = :P185_VORSCHRIFTID;',
'',
'select to_char(einsatzdatum, ''DD.MM.YYYY'') into l_datum_in_kraft',
'from t_vorschrift_ref_einsatzdatum_typ vre',
'where vre.vorschriftid = :P185_VORSCHRIFTID',
'and vre.einsatzdatum_typid = 1000',
'union all select null from dual',
'fetch first 1 rows only;',
'',
'select to_char(einsatzdatum, ''DD.MM.YYYY'') into l_datum_alle_typen',
'from t_vorschrift_ref_einsatzdatum_typ vre',
'where vre.vorschriftid = :P185_VORSCHRIFTID',
'and vre.einsatzdatum_typid = 1011',
'union all select null from dual',
'fetch first 1 rows only;',
'',
'select to_char(einsatzdatum, ''DD.MM.YYYY'') into l_datum_neuer_typ',
'from t_vorschrift_ref_einsatzdatum_typ vre',
'where vre.vorschriftid = :P185_VORSCHRIFTID',
'and vre.einsatzdatum_typid = 1010',
'union all select null from dual',
'fetch first 1 rows only;',
'',
'with land_jira_codes as (',
' select distinct land.jira_code',
' from T_VORSCHRIFT_REF_LAND vl ',
' left outer join t_land land on land.landid = vl.landid',
' where vl.vorschriftid = :P185_VORSCHRIFTID ',
'  and vl.geloescht = 0',
'  and land.jira_code is not null',
')',
'select listagg(''&customfield_16470='' || land_jira_codes.jira_code, '''') into l_laender_fields',
'from land_jira_codes;',
'',
'with ak_jira_codes as ( -- AK-Kurzebez. muessen noch in Jira-IDs umgewandelt werden',
' select distinct t.ET_B_AK_KURZ',
' from T_VORSCHRIFT_REF_THEMA vt ',
' left outer join t_thema t on t.themaid = vt.themaid',
' where vt.vorschriftid = :P185_VORSCHRIFTID ',
'  and vt.geloescht = 0',
'  and t.ET_B_AK_KURZ is not null',
')',
'select listagg(''&components='' || ak_jira_codes.ET_B_AK_KURZ, '''') into l_ak_fields',
'from ak_jira_codes;',
'',
'return ''https://portal.epp.audi.vwg/aenjira/secure/CreateIssueDetails!init.jspa?pid=21724&issuetype=3&priority=4'' ||',
'''&components=44408'' || -- Komponente Testticket (44408)',
'''&summary='' || apex_util.url_encode(''MfV Titel der Vorschrift kommt aus +APEX+'') ||',
'''&customfield_10695='' || apex_util.url_encode(:P185_VORSCHRIFT_NUMMER) ||',
'l_laender_fields || ',
'''&description='' || apex_util.url_encode(''h2. +Hilfen+: \\'' ||',
unistr(' ''* Anleitung f\00FCr das MfV Ticket (Aufgabe): {color}[https://portal.epp.audi.vwg/wiki/display/ETW/Anleitung+zum+Thema+MfV+Teil+x+Vorgang]\005C\005C'' ||'),
' ''h2. *Informationen:*\\'' ||',
' ''* Lange Bezeichnung der Vorschrift:\\'' ||',
' ''** +'' || :P185_VORSCHRIFT_BEZEICHNUNG || ''+\\'' ||',
' ''* Einleitende Informationen vom VIK / VKO:\\'' ||',
' ''** hier steht ihre Einleitung'' ||',
' ''* Quellenangabe: Quelle der Information (z.B. Importeur, Datenbank Abos, Newsletter, K-VKO)\\'' || ',
' ''** z.B. Importeur\\'' ||',
' ''* Getex Link zur Vorschrift order Getex ID:\\ \\'' ||',
unistr(' ''* Zus\00E4tzliche Links (Optional falls in Getex nicht vorhanden): \005C\005C \005C\005C'' ||'),
' ''* Status der Vorschrift: \\'' ||',
' ''** +aus APEX+ '' || :P185_VORSCHRIFT_STATUS || ''\\'' ||',
' ''* Inkrafttreten der Vorschrift:\\'' ||',
' ''** +aus APEX+ '' || :P185_DATUM_IN_KRAFT || ''\\'' ||',
unistr(' ''* Einsatzdatum f\00FCr neuen Typ:\005C\005C'' ||'),
' ''** +aus APEX+ '' || :P185_DATUM_NEUER_TYP || ''\\'' ||',
unistr(' ''* Einsatzdatum f\00FCr allen Typen:\005C\005C'' ||'),
' ''** +aus APEX+ '' || :P185_DATUM_ALLE_TYPEN || ''\\'') ||',
'''&customfield_14872='' || apex_util.url_encode(''Scope Inhalt Details:'') ||',
'''&customfield_10696='' || apex_util.url_encode(''h2. +Link zu MfV Power Point:+\\ \\'' ||',
' ''+Links zu AK Protokollen:+\\ \\'' ||',
' ''+Links zu ET-B Forum Protokoll:+\\ \\'' ||',
' ''+Links zum SKFV Protokoll:+'');',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>20
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1058220009845348909)
,p_name=>'P185_VORSCHRIFT_NUMMER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1058219478141348903)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vorschr.VORSCHRIFT_NUMMER',
'from T_VORSCHRIFT vorschr',
'where vorschr.vorschriftid = :P185_VORSCHRIFTID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1058220116376348910)
,p_name=>'P185_VORSCHRIFTID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1058219478141348903)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1058220250051348911)
,p_name=>'P185_VORSCHRIFT_BEZEICHNUNG'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(1058219478141348903)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vorschr.VORSCHRIFT_BEZEICHNuNG',
'from T_VORSCHRIFT vorschr',
'where vorschr.vorschriftid = :P185_VORSCHRIFTID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1058220394798348912)
,p_name=>'P185_LAENDER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(1058219478141348903)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct land.jira_code',
'from T_VORSCHRIFT_REF_LAND vl ',
'left outer join t_land land on land.landid = vl.landid',
'where vl.vorschriftid = :P185_VORSCHRIFTID ',
'    and vl.geloescht = 0',
'    and land.jira_code is not null',
';'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1058220477754348913)
,p_name=>'P185_VORSCHRIFT_STATUS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1058219478141348903)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vs.status',
'from T_VORSCHRIFT vorschr',
'inner join T_VORSCHRIFT_STATUS vs on vs.VORSCHRIFT_STATUSID = vorschr.VORSCHRIFT_STATUSID',
'where vorschr.vorschriftid = :P185_VORSCHRIFTID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1058220502118348914)
,p_name=>'P185_PROGNOSE_QUALITAET'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1058219478141348903)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when vorschr.prognose_qualitaet = 10 then emano_util.fLang(''sicher'', ''certain'')',
unistr('        when vorschr.prognose_qualitaet = 20 then emano_util.fLang(''absch\00E4tzbar'', ''estimable'')'),
'        else null',
'    end prognose_status',
'from T_VORSCHRIFT vorschr',
'where vorschr.vorschriftid = :P185_VORSCHRIFTID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1058220610792348915)
,p_name=>'P185_AK_KURZBEZEICHNUNG'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(1058219478141348903)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct et_b_ak_kurz etb',
' from t_vorschrift_ref_thema vtl',
' join t_thema t on (vtl.themaid = t.themaid)',
' where vtl.vorschriftid = :P185_VORSCHRIFTID and vtl.geloescht = 0'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1058220730314348916)
,p_name=>'P185_DATUM_IN_KRAFT'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(1058219478141348903)
,p_use_cache_before_default=>'NO'
,p_format_mask=>'DD.MM.YYYY'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(einsatzdatum, ''DD.MM.YYYY'')',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = :P185_VORSCHRIFTID',
'    and vre.einsatzdatum_typid = 1000',
'    fetch first 1 rows only'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1058220856215348917)
,p_name=>'P185_DATUM_NEUER_TYP'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(1058219478141348903)
,p_format_mask=>'DD.MM.YYYY'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(einsatzdatum, ''DD.MM.YYYY'')',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = :P185_VORSCHRIFTID',
'    and vre.einsatzdatum_typid = 1010',
'    fetch first 1 rows only'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1058220991853348918)
,p_name=>'P185_DATUM_ALLE_TYPEN'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(1058219478141348903)
,p_format_mask=>'DD.MM.YYYY'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(einsatzdatum, ''DD.MM.YYYY'')',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = :P185_VORSCHRIFTID',
'    and vre.einsatzdatum_typid = 1011',
'    fetch first 1 rows only'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1058219839713348907)
,p_name=>'ACTION_URL_OPEN'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1058219689526348905)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1058219944116348908)
,p_event_id=>wwv_flow_imp.id(1058219839713348907)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lUrl = apex.item("P185_URL_TEXT").getValue();',
'//alert(Url);',
'window.open(lUrl, ''_blank'');'))
);
wwv_flow_imp.component_end;
end;
/
