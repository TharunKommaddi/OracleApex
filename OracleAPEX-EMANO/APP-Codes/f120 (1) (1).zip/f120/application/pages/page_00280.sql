prompt --application/pages/page_00280
begin
--   Manifest
--     PAGE: 00280
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>280
,p_name=>'LRSA'
,p_alias=>'LRSA'
,p_step_title=>'LRSA'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2153690278398645049)
,p_plug_name=>'LRSA'
,p_region_name=>'lrsa_tree'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select l.LRSA_ID,',
'       l.LRSA_NUMMER || '' - '' || l.BEZEICHNUNG,',
'       l.PARENT_ID,',
'       l.LETZTE_AENDERUNG_DATUM,',
'       l.LETZTE_AENDERUNG_BENUTZERID,',
'       apex_page.get_url(p_page => 286, p_items => ''P286_LRSA_ID'', p_values => l.lrsa_id, p_clear_cache => 286) as link',
'  from T_LRSA l'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_JSTREE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'activate_node_link_with', 'S',
  'default_icon_css_class', 'icon-tree-folder',
  'icon_type_css_class', 'a-Icon',
  'link_column', 'LINK',
  'node_id_column', 'LRSA_ID',
  'node_label_column', 'L.LRSA_NUMMER||''-''||L.BEZEICHNUNG',
  'node_value_column', 'LRSA_ID',
  'parent_key_column', 'PARENT_ID',
  'start_tree_with', 'NULL',
  'tree_hierarchy', 'SQL',
  'tree_tooltip', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2154988120065085534)
,p_plug_name=>'REGION_VERSION'
,p_parent_plug_id=>wwv_flow_imp.id(2153690278398645049)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>40
,p_plug_grid_column_span=>5
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025608903580197410)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2154988120065085534)
,p_button_name=>'CHANGE_VERSION'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padTop:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Version \00E4ndern')
,p_button_redirect_url=>'f?p=&APP_ID.:282:&SESSION.::&DEBUG.:RP,282:P282_VERSION_NUMMER:&P280_VERSION_NUMMER.'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025611187300197434)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2153690278398645049)
,p_button_name=>'ADD'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('LRSA hinzuf\00FCgen')
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:286:&SESSION.::&DEBUG.:286::'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025610786343197433)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2153690278398645049)
,p_button_name=>'EXPAND_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Aufklappen'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025610381346197432)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(2153690278398645049)
,p_button_name=>'CONTRACT_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Zuklappen'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1025609939768197432)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2153690278398645049)
,p_button_name=>'ADD_THEMA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Thema hinzuf\00FCgen')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:281:&SESSION.::&DEBUG.:RP,281::'
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025609519677197419)
,p_name=>'P280_VERSION_NUMMER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2153690278398645049)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025608497786197410)
,p_name=>'P280_VERSION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2154988120065085534)
,p_prompt=>'Version: &P280_VERSION_NUMMER.'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>5
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025607699774197394)
,p_name=>'Refresh Page'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#lrsa_tree'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025606622223197389)
,p_event_id=>wwv_flow_imp.id(1025607699774197394)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025606303704197389)
,p_name=>'CONTRACT_ALL'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1025610381346197432)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025605742367197388)
,p_event_id=>wwv_flow_imp.id(1025606303704197389)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_COLLAPSE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2153690278398645049)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025605351474197388)
,p_name=>'EXPAND_ALL'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1025610786343197433)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025604858564197388)
,p_event_id=>wwv_flow_imp.id(1025605351474197388)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2153690278398645049)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1025604497596197388)
,p_name=>'Expand Tree'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1025604015483197387)
,p_event_id=>wwv_flow_imp.id(1025604497596197388)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Expand Tree'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2153690278398645049)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1025608092469197397)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Versionsnummer holen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    select VERSION_NUMMER into :P280_VERSION_NUMMER',
'    from T_LRSA_VERSION;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2646604223430190838
);
wwv_flow_imp.component_end;
end;
/
