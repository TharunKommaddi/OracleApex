prompt --application/pages/page_00075
begin
--   Manifest
--     PAGE: 00075
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>75
,p_name=>unistr('MfV bearbeiten / hinzuf\00FCgen')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('MfV bearbeiten / hinzuf\00FCgen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>unistr('var htmldb_delete_message=''"M\00F6chten Sie die MFV l\00F6schen?"'';')
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2643460451174718992)
,p_plug_name=>'Form on T_MFV'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(2643272620140755357)
,p_name=>'Vorschriften'
,p_parent_plug_id=>wwv_flow_imp.id(2643460451174718992)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-top-md'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mrv.rowid as mrvrowid,',
'       MFV_REF_VORSCHRIFTID,',
'       mrv.MFVID,',
'       mrv.VORSCHRIFTID,',
'       mrv.LETZTE_AENDERUNG_DATUM,',
'       b.NACHNAME || '', '' || b.vorname as LETZTE_AENDERUNG_BENUTZER,',
'       v.rowid vorschrift_rowid',
'from T_MFV_REF_VORSCHRIFT mrv',
'join T_MFV m on m.MFVID = mrv.MFVID',
'join t_vorschrift v on (mrv.vorschriftid = v.vorschriftid)',
'left outer join T_BENUTZER b on b.BENUTZERID = mrv.LETZTE_AENDERUNG_BENUTZERID',
'where m.rowid = :P75_ROWID;'))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'Noch keine Vorschriften zugeordnet.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>unistr('StTh: Kann gel\00F6scht werden, sobald das Popup-LOV akzeptiert wurde.')
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1460575006807518261)
,p_query_column_id=>1
,p_column_alias=>'MRVROWID'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2643272827860755359)
,p_query_column_id=>2
,p_column_alias=>'MFV_REF_VORSCHRIFTID'
,p_column_display_sequence=>2
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:RP,25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_column_linktext=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2643272920918755360)
,p_query_column_id=>3
,p_column_alias=>'MFVID'
,p_column_display_sequence=>1
,p_column_link=>'f?p=&APP_ID.:85:&SESSION.::&DEBUG.:RP:P85_ROWID:#MRVROWID#'
,p_column_linktext=>'<span class="fa fa-pencil" aria-hidden="true"></span>'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2643272978103755361)
,p_query_column_id=>4
,p_column_alias=>'VORSCHRIFTID'
,p_column_display_sequence=>3
,p_column_heading=>'Vorschrift'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(2642128612516763789)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2643273143198755362)
,p_query_column_id=>5
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>4
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_column_format=>'DD.MM.YYYY HH24:Mi'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2643273481681755366)
,p_query_column_id=>6
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZER'
,p_column_display_sequence=>5
,p_column_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2645607178877931437)
,p_query_column_id=>7
,p_column_alias=>'VORSCHRIFT_ROWID'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2643461132741718997)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2643461565613718997)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2643461132741718997)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2643461043923718997)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2643461132741718997)
,p_button_name=>'DELETE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P75_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_security_scheme=>wwv_flow_imp.id(2660026449262803947)
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2645049622345950754)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2643272620140755357)
,p_button_name=>'ADD_VORSCHRIFT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:85:&SESSION.::&DEBUG.:RP,85:P85_MFVID,P85_CAME_FROM:&P75_MFVID.,75'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2643460945022718997)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2643461132741718997)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P75_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2643460794257718997)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2643461132741718997)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P75_ROWID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(895789824838594086)
,p_name=>'P75_DMS_DOKUMENTENSTATUS'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(2643460451174718992)
,p_use_cache_before_default=>'NO'
,p_prompt=>'DMS Dokumentenstatus'
,p_source=>'DMS_DOKUMENTENSTATUS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_DMS_DOKUMENTENSTATUS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''In Bearbeitung'', ''In Progress'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Freigegeben'', ''Released'') AS display_value,',
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'    ',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Ung\00FCltig'', ''Invalid'') AS display_value,'),
'        30 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''N.N.'', ''n.a.'') AS display_value,',
'        40 AS actual_value,',
'        4 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(808705267723716303)
,p_name=>'P75_MFV_REF_VORSCHRIFT'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(2643460451174718992)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Vorschriften'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select --mrv.rowid as mrvrowid,',
'       --MFV_REF_VORSCHRIFTID,',
'       --mrv.MFVID,',
'       mrv.VORSCHRIFTID--,',
'       --mrv.LETZTE_AENDERUNG_DATUM,',
'       --b.NACHNAME || '', '' || b.vorname as LETZTE_AENDERUNG_BENUTZER,',
'       --v.rowid vorschrift_rowid',
'from T_MFV_REF_VORSCHRIFT mrv',
'join T_MFV m on m.MFVID = mrv.MFVID',
'join t_vorschrift v on (mrv.vorschriftid = v.vorschriftid)',
'left outer join T_BENUTZER b on b.BENUTZERID = mrv.LETZTE_AENDERUNG_BENUTZERID',
'where m.rowid = :P75_ROWID;'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_VORSCHRIFT_DETAIL'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_display_when=>'P75_ROWID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(602812732415777381)
,p_name=>'P75_MFV_REF_ET_B_AK'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(2643460451174718992)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Arbeitskreise'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  mra.ET_B_AKID',
'   from T_MFV_REF_ET_B_AK mra',
'   join T_MFV m on m.MFVID = mra.MFVID',
'   join t_ET_B_AK ak on (mra.ET_B_AKID = ak.ET_B_AKID)',
'--left outer join T_BENUTZER b on b.BENUTZERID = mra.LETZTE_AENDERUNG_BENUTZERID',
'where m.rowid = :P75_ROWID;'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_ARBEITSKREIS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' SELECT ',
'    ET_B_AKID, ',
'    kurz, ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN Bezeichnung',
'        ELSE name_eng',
'    END AS name',
'FROM T_ET_B_AK ',
'WHERE ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN Bezeichnung',
'        ELSE name_eng',
'    END NOT IN ',
'    (',
'        CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''Administratoren'' ELSE ''Administrators'' END,',
'        CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''Redaktionsteam'' ELSE ''Editorial Team'' END',
'    );',
''))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(565124561840321290)
,p_name=>'P75_GUELTIGKEITSDATUM'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(2643460451174718992)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('G\00FCltigkeitsdatum')
,p_format_mask=>'DD.MM.YYYY'
,p_source=>'GUELTIGKEITSDATUM'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2643463955693719039)
,p_name=>'P75_ROWID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2643460451174718992)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Rowid'
,p_source=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2643464274432719055)
,p_name=>'P75_MFV_TEILID'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2643460451174718992)
,p_prompt=>'MfV Teil'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  mrt.mfv_teilid  ',
'  from t_mfv_ref_mfv_teil mrt',
' where mfvid = :P75_MFVID'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Teil '' || t.teil || '' '' || t.bezeichnung as bezeichnung, t.mfv_teilid',
'from t_mfv_teil t',
'order by 1;'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2643464596713719058)
,p_name=>'P75_SCHLAGWORTE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2643460451174718992)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Schlagworte'
,p_source=>'SCHLAGWORTE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>1024
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2643465402862719059)
,p_name=>'P75_BETEILIGTE_OES'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(2643460451174718992)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Beteiligte OEs'
,p_source=>'BETEILIGTE_OES'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>120
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2643465789311719059)
,p_name=>'P75_LINK_MFV_DMS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(2643460451174718992)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zur Ablage DMS'
,p_source=>'LINK_MFV_DMS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>1024
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2645049688914950755)
,p_name=>'P75_MFVID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2643460451174718992)
,p_use_cache_before_default=>'NO'
,p_source=>'MFVID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2656500096618854243)
,p_name=>'P75_JIRA_TICKET'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(2643460451174718992)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Jira-Tickets'
,p_source=>'JIRA_TICKET'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>150
,p_cMaxlength=>600
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2677392815226635641)
,p_name=>'P75_KSU'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(2643460451174718992)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1020'
,p_prompt=>'KSU'
,p_source=>'KSUID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN k.bezeichnung ELSE k.name_eng END, ',
'    k.ksuid',
'FROM ',
'    t_ksu k',
'ORDER BY ',
'    CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN k.bezeichnung ELSE k.name_eng END;',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2678714955770847256)
,p_name=>'P75_MFV_NAME'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2643460451174718992)
,p_use_cache_before_default=>'NO'
,p_prompt=>'MfV ID'
,p_source=>'MFV_NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>500
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2678715045080847257)
,p_name=>'P75_MFV_THEMA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2643460451174718992)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Thema der MfV'
,p_source=>'MFV_THEMA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>1000
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2643461578009718997)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2643461565613718997)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2643462373220719003)
,p_event_id=>wwv_flow_imp.id(2643461578009718997)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2650733305956831458)
,p_name=>'DIALOG_VORSCHRIFT_CLOSED'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2643272620140755357)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2650733428483831459)
,p_event_id=>wwv_flow_imp.id(2650733305956831458)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2643272620140755357)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(211493707308285615)
,p_name=>'ACTION_DELETE_MFV'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2643461043923718997)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(211493830143285616)
,p_event_id=>wwv_flow_imp.id(211493707308285615)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('M\00F6chten Sie die MfV ''&P75_MFV_NAME.'' mit allen verkn\00FCpften Daten und Historie endg\00FCltig l\00F6schen?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(211494083776285618)
,p_event_id=>wwv_flow_imp.id(211493707308285615)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lResult boolean;',
'begin',
'    lResult := PCK_RI.fDeleteMfv(aMfvID => :P75_MFVID);',
'end;'))
,p_attribute_02=>'P75_MFVID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(211494170222285619)
,p_event_id=>wwv_flow_imp.id(211493707308285615)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>unistr('apex.message.showPageSuccess(''Die MfV \005C''&P75_MFV_NAME.\005C'' wurde gel\00F6scht.'');')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(211494251742285620)
,p_event_id=>wwv_flow_imp.id(211493707308285615)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2643466578692719061)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_MFV'
,p_attribute_02=>'T_MFV'
,p_attribute_03=>'P75_ROWID'
,p_attribute_04=>'ROWID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6315678894592107296
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(565124344860321288)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set_Gueltigkeit'
,p_process_sql_clob=>'select (sysdate + 730) into :P75_GUELTIGKEITSDATUM FROM DUAL;'
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('Fehler beim F\00FCllen des G\00FCltigkeitsdatums.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2643460794257718997)
,p_internal_uid=>3107087971039066947
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2643467043873719062)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of T_MFV'
,p_attribute_02=>'T_MFV'
,p_attribute_03=>'P75_ROWID'
,p_attribute_04=>'ROWID'
,p_attribute_09=>'P75_ROWID'
,p_attribute_11=>'I:U'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'MfV erstellt.'
,p_internal_uid=>6315679359773107297
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(95795529320792302)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'MFVID holen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mfvid into :P75_MFVID',
'from t_mfv',
'where rowid = :P75_ROWID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P75_MFVID'
,p_process_when_type=>'ITEM_IS_NULL'
,p_internal_uid=>3576416786578595933
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(808705108386716301)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process MFV Ref Vorschrift'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'merge into t_mfv_ref_vorschrift dest',
'using (select :P75_MFVID as mfvid, column_value as vorschriftid from table(apex_string.split_numbers(:P75_MFV_REF_VORSCHRIFT, '':''))) src',
'on (src.mfvid = dest.mfvid ',
'   and src.vorschriftid = dest.vorschriftid)',
'when not matched then',
'insert (mfvid, vorschriftid)',
'values (src.mfvid, src.vorschriftid);',
'',
'',
'delete from t_mfv_ref_vorschrift',
'where mfvid = :P75_MFVID',
'    and vorschriftid not in (select column_value from table(apex_string.split_numbers(:P75_MFV_REF_VORSCHRIFT, '':'')));',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2643460945022718997)
,p_internal_uid=>2863507207512671934
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(602812562943777380)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process MFV Ref AK'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'merge into t_mfv_ref_ET_B_AK dest',
' using (select :P75_MFVID as mfvid, column_value as ET_B_AKID from table(apex_string.split_numbers(:P75_MFV_REF_ET_B_AK, '':''))) src',
' on (src.mfvid = dest.mfvid ',
'   and src.ET_B_AKID = dest.ET_B_AKID)',
' when not matched then',
' insert (mfvid, ET_B_AKID)',
' values (src.mfvid, src.ET_B_AKID);',
'',
' delete from t_mfv_ref_ET_B_AK',
'  where mfvid = :P75_MFVID',
'    and ET_B_AKID not in (select column_value from table(apex_string.split_numbers(:P75_MFV_REF_ET_B_AK, '':'')));',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3069399752955610855
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1078791398985398575)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process MFV Ref MFV Teil'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' merge into t_mfv_ref_mfv_teil dest',
'   using ( select :P75_MFVID as mfvid, column_value as mfv_teilid from table (apex_string.split_numbers(:P75_MFV_TEILID, '':''))) src',
'   on (src.mfvid = dest.mfvid ',
'       and src.mfv_teilid = dest.mfv_teilid)',
'  when not matched then',
' insert (mfvid, mfv_teilid)',
' values (src.mfvid, src.mfv_teilid);',
'',
'delete from t_mfv_ref_mfv_teil',
'where mfvid = :P75_MFVID',
'    and mfv_teilid not in (select column_value from table(apex_string.split_numbers(:P75_MFV_TEILID, '':'')));'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE, CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2593420916913989660
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(565121994493321264)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set_DokumentenStatus'
,p_process_sql_clob=>'PCK_RI.pUpdateDocumentStatus(:P75_MFV_NAME);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2643460794257718997)
,p_internal_uid=>3107090321406066971
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2643467367678719062)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2643461043923718997)
,p_internal_uid=>6315679683578107297
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2643467852545719062)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>6315680168445107297
);
wwv_flow_imp.component_end;
end;
/
