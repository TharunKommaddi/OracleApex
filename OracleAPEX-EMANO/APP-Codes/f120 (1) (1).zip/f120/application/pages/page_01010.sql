prompt --application/pages/page_01010
begin
--   Manifest
--     PAGE: 01010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>1010
,p_name=>'MFV_ERROR'
,p_alias=>'MFV-ERROR'
,p_step_title=>'MFV_ERROR'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function deleteMFVRecord(mfvid) {',
'    apex.message.confirm(',
unistr('        ''Sind Sie sicher, dass Sie diesen MFV-Datensatz (ID: '' + mfvid + '') und alle zugeh\00F6rigen Daten l\00F6schen m\00F6chten?'', '),
'        function(okPressed) {',
'            if (okPressed) {',
'                apex.item(''P1010_MFVID_TO_DELETE'').setValue(mfvid);',
'                apex.page.submit({',
'                    request: ''DELETE_MFV'',',
'                    showWait: true',
'                });',
'            }',
'        }',
'    );',
'}',
'',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Default delete icon - red */',
'.delete-icon {',
'    color: red;',
'    transition: color 0.3s ease;',
'}',
'',
'/* When hovering over the table row, icon turns white */',
'.t-Report-report tr:hover .delete-icon,',
'.a-IRR-table tr:hover .delete-icon {',
'    color: white !important;',
'}',
'',
'/* Smooth transition effect */',
'.delete-icon-btn {',
'    cursor: pointer;',
'    transition: all 0.3s ease;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_comment=>'f'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(946468166524772933)
,p_name=>'Jira_Post'
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>110
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'T_JIRA_POST'
,p_include_rowid_column=>false
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(946468115275772932)
,p_query_column_id=>1
,p_column_alias=>'JIRA_POST_ID'
,p_column_display_sequence=>10
,p_column_heading=>'Jira Post Id'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(946467970044772931)
,p_query_column_id=>2
,p_column_alias=>'ERSTELLUNGS_DATUM'
,p_column_display_sequence=>20
,p_column_heading=>'Erstellungs Datum'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(946467819448772930)
,p_query_column_id=>3
,p_column_alias=>'POST_DATUM'
,p_column_display_sequence=>30
,p_column_heading=>'Post Datum'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(946467745242772929)
,p_query_column_id=>4
,p_column_alias=>'POST_STATUS'
,p_column_display_sequence=>40
,p_column_heading=>'Post Status'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(946467649956772928)
,p_query_column_id=>5
,p_column_alias=>'JIRA_KEY'
,p_column_display_sequence=>50
,p_column_heading=>'Jira Key'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(946467589564772927)
,p_query_column_id=>6
,p_column_alias=>'POST_CLOB'
,p_column_display_sequence=>60
,p_column_heading=>'Post Clob'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(946467512352772926)
,p_query_column_id=>7
,p_column_alias=>'COCOA_TICKET'
,p_column_display_sequence=>70
,p_column_heading=>'Cocoa Ticket'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(946467349006772925)
,p_query_column_id=>8
,p_column_alias=>'ERROR_MSG'
,p_column_display_sequence=>80
,p_column_heading=>'Error Msg'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3793866559087692444)
,p_name=>unistr('Fehler L\00F6schung')
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select v.JIRA_TICKET,',
'       tm.MFVID,',
'       ''<a href="javascript:deleteMFVRecord('' || tm.MFVID || '');" ',
'          class="t-Button t-Button--hot t-Button--simple delete-icon-btn" ',
unistr('          title="MFV-Datensatz l\00F6schen">'' ||'),
'       ''<span class="fa fa-trash delete-icon" aria-hidden="true" style="color: red;"></span></a>'' as DELETE_ACTION',
'from v_MFV_geloescht_error v',
'join t_mfv tm on (v.jira_ticket = tm.jira_ticket)'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(949418548323387624)
,p_query_column_id=>1
,p_column_alias=>'JIRA_TICKET'
,p_column_display_sequence=>30
,p_column_heading=>'Jira Ticket'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(951939434653316319)
,p_query_column_id=>2
,p_column_alias=>'MFVID'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(951939403597316318)
,p_query_column_id=>3
,p_column_alias=>'DELETE_ACTION'
,p_column_display_sequence=>10
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(6358772533124814764)
,p_name=>'SUMS Relevant'
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (Select * from t_MFV_SUMS tms',
'), cte2 as (Select nvl(SUMS_RELEVANT,0)  Sums_land,tms.vorschriftid, tl.landid, tl.land',
'from t_MFV_SUMS tms',
' join t_vorschrift_ref_land tvrl on (tms.VORSCHRIFTID = tvrl.VORSCHRIFTID)',
' join t_land tl on (tvrl.landid = tl.landid)',
'), cte_land_agg  as (',
'    Select sum(sums_land) as sums_land, listagg(distinct land,'', '') as land,',
'    vorschriftid',
'    from cte2',
'    where sums_land > 0',
'    group by vorschriftid',
')',
'',
'Select MFV_SUMSID,',
' ''<a href="https://cicd.cloud.audi/jira/browse/'' || JIRA_KEY || ''" target="_blank">'' || JIRA_KEY || ''</a>'' AS  JIRA_KEY,',
'SUMS_STATUS,',
'vorschrift_nummer,',
'UEBERNAHME_STATUS,',
'KOMMENTAR,',
'tms.LETZTE_AENDERUNG_DATUM,',
'tms.LETZTE_AENDERUNG_BENUTZERID,',
'',
' RXSWIN as Sums_vorschrift,',
' case when nvl(sums_land,0)> 0 then ''ja'' else ''nein'' end as Sums_land,',
' land',
' from t_MFV_SUMS tms',
' join t_vorschrift tv on (tms.vorschriftid = tv.VORSCHRIFTID)',
' left outer join  cte_land_agg cl on (tms.vorschriftid = cl.vorschriftid)',
' /*left outer join t_vorschrift_ref_land tvrl on (tv.VORSCHRIFTID = tvrl.VORSCHRIFTID)',
' left outer join t_land tl on (tvrl.landid = tl.landid)*/',
'  where (UEBERNAHME_STATUS = 0 and :P1010_SWITCH = 1) or :P1010_SWITCH = 0'))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(949423234984387660)
,p_query_column_id=>1
,p_column_alias=>'MFV_SUMSID'
,p_column_display_sequence=>10
,p_column_heading=>'Mfv Sumsid'
,p_column_link=>'f?p=&APP_ID.:1015:&SESSION.::&DEBUG.:1015:P1015_MFV_SUMSID:#MFV_SUMSID#'
,p_column_linktext=>'<span class="fa fa-pencil" aria-hidden="true"></span>'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(949422885585387659)
,p_query_column_id=>2
,p_column_alias=>'JIRA_KEY'
,p_column_display_sequence=>20
,p_column_heading=>'VEX-Ticket'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(949422476503387658)
,p_query_column_id=>3
,p_column_alias=>'SUMS_STATUS'
,p_column_display_sequence=>30
,p_column_heading=>'Sums Status VEX-Ticket'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(949420446154387656)
,p_query_column_id=>4
,p_column_alias=>'VORSCHRIFT_NUMMER'
,p_column_display_sequence=>40
,p_column_heading=>'Vorschrift Nummer'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(949420093580387656)
,p_query_column_id=>5
,p_column_alias=>'UEBERNAHME_STATUS'
,p_column_display_sequence=>60
,p_column_heading=>'Uebernahme Status'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>unistr('STATIC:nicht \00FCbernommen;0,Ja;10,Nein;20')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(949419626276387655)
,p_query_column_id=>6
,p_column_alias=>'KOMMENTAR'
,p_column_display_sequence=>90
,p_column_heading=>'Kommentar'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(949419260337387655)
,p_query_column_id=>7
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>100
,p_column_heading=>'Letzte Aenderung Datum'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(949422094263387658)
,p_query_column_id=>8
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZERID'
,p_column_display_sequence=>110
,p_column_heading=>'Letzte Aenderung Benutzerid'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(949421688953387657)
,p_query_column_id=>9
,p_column_alias=>'SUMS_VORSCHRIFT'
,p_column_display_sequence=>50
,p_column_heading=>'Sums Status Regindex'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(958135905312245351)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(949421273729387657)
,p_query_column_id=>10
,p_column_alias=>'SUMS_LAND'
,p_column_display_sequence=>70
,p_column_heading=>'Sums Land'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(949420856837387657)
,p_query_column_id=>11
,p_column_alias=>'LAND'
,p_column_display_sequence=>80
,p_column_heading=>'Land'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6359813649741038081)
,p_plug_name=>'SUMS Relevant IR'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (Select * from t_MFV_SUMS tms',
'), cte2 as (Select nvl(SUMS_RELEVANT,0)  Sums_land,tms.vorschriftid, tl.landid, tl.land',
'from t_MFV_SUMS tms',
' join t_vorschrift_ref_land tvrl on (tms.VORSCHRIFTID = tvrl.VORSCHRIFTID)',
' join t_land tl on (tvrl.landid = tl.landid)',
'), cte_land_agg  as (',
'    Select sum(case when sums_land = 10 then 1 else 0 end) as sums_land, listagg(distinct land,'', '') as land,',
'    vorschriftid',
'    from cte2',
'    where sums_land = 10',
'    group by vorschriftid',
')',
'',
'Select MFV_SUMSID,',
' ''<a href="https://cicd.cloud.audi/jira/browse/'' || JIRA_KEY || ''" target="_blank">'' || JIRA_KEY || ''</a>'' AS  JIRA_KEY,',
'SUMS_STATUS,',
'vorschrift_nummer,',
'UEBERNAHME_STATUS,',
'KOMMENTAR,',
'tms.LETZTE_AENDERUNG_DATUM,',
'tms.LETZTE_AENDERUNG_BENUTZERID,',
'',
' RXSWIN as Sums_vorschrift,',
' case when nvl(sums_land,0)> 0 then ''ja'' else ''nein'' end as Sums_land,',
' land,',
'',
' tms.vorschriftid as Vorschriftlink',
' from t_MFV_SUMS tms',
' join t_vorschrift tv on (tms.vorschriftid = tv.VORSCHRIFTID)',
' left outer join  cte_land_agg cl on (tms.vorschriftid = cl.vorschriftid)',
' /*left outer join t_vorschrift_ref_land tvrl on (tv.VORSCHRIFTID = tvrl.VORSCHRIFTID)',
' left outer join t_land tl on (tvrl.landid = tl.landid)*/',
'',
' where (UEBERNAHME_STATUS = 0 and :P1010_SWITCH = 1) or :P1010_SWITCH = 0'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'SUMS Relevant IR'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(6359814829040038093)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>10032027144939426328
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949417842830387608)
,p_db_column_name=>'MFV_SUMSID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Mfv Sumsid'
,p_column_link=>'f?p=&APP_ID.:1015:&SESSION.::&DEBUG.:1015:P1015_MFV_SUMSID:#MFV_SUMSID#'
,p_column_linktext=>'<span class="fa fa-pencil" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949417468175387607)
,p_db_column_name=>'JIRA_KEY'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'VEX-Ticket'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949417063127387606)
,p_db_column_name=>'SUMS_STATUS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Sums Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949416664271387606)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Vorschrift Nummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949416230539387606)
,p_db_column_name=>'UEBERNAHME_STATUS'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Uebernahme Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949415852876387605)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949415435097387605)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Letzte Aenderung Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949415098298387605)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZERID'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Letzte Aenderung Benutzerid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949414707086387604)
,p_db_column_name=>'SUMS_VORSCHRIFT'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Sums Vorschrift'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(958135905312245351)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949414233418387603)
,p_db_column_name=>'SUMS_LAND'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Sums Land'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949413872025387603)
,p_db_column_name=>'LAND'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949413416321387603)
,p_db_column_name=>'VORSCHRIFTLINK'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Vorschriftlink'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::P25_VORSCHRIFTID:#VORSCHRIFTLINK#'
,p_column_linktext=>'#VORSCHRIFTLINK#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(6360561137948866357)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'26230735'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'VORSCHRIFT_NUMMER:MFV_SUMSID:JIRA_KEY:VORSCHRIFTLINK:SUMS_STATUS:UEBERNAHME_STATUS:KOMMENTAR:LETZTE_AENDERUNG_DATUM:LETZTE_AENDERUNG_BENUTZERID:SUMS_VORSCHRIFT:SUMS_LAND:LAND:'
,p_break_on=>'VORSCHRIFT_NUMMER:0:0:0:0:0'
,p_break_enabled_on=>'VORSCHRIFT_NUMMER:0:0:0:0:0'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6568640907854768412)
,p_plug_name=>unistr('Pr\00FCfung Permalink')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select VMEP.MFVID,',
'       VMEP.VORSCHRIFTID as mfv_vor_id,',
'       tv.VORSCHRIFTID,',
'       ''<a href="https://cicd.cloud.audi/jira/browse/'' || VMEP.JIRAKEY || ''" target="_blank">'' || VMEP.JIRAKEY || ''</a>'' AS JIRA_LINK,',
'         case WHEN to_char(VMEP.VORSCHRIFTID) != to_char(tv.VORSCHRIFTID) THEN ''Error, vorschrift not matched''',
unistr('          when (VMEP.VORSCHRIFTID is not null and  tv.VORSCHRIFTID is null) then ''Permalink, kann nicht aufgel\00F6st werden'''),
'          when vmep.VORSCHRIFTID is null  then ''Error, vorschrift nicht gefunden''',
'          WHEN to_char(VMEP.VORSCHRIFTID) = to_char(tv.VORSCHRIFTID) THEN ''Matched''',
'       else',
'       null',
'       end Permalink_Error',
'from MV_MFV_ERROR_PERMALINK VMEP left outer join T_VORSCHRIFT tv on(to_char(VMEP.VORSCHRIFTID) = to_char(',
'    tv.VORSCHRIFTID)  )',
'where (case when :P1010_SWITCH =1 and to_char(VMEP.VORSCHRIFTID) != to_char(tv.VORSCHRIFTID)  then 1 else 0 end)=:P1010_SWITCH',
'or VMEP.VORSCHRIFTID is null or tv.VORSCHRIFTID is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P1010_SWITCH'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Pr\00FCfung Permalink')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_value clob;',
'begin',
'if :P1010_SWITCH =''Error'' then ',
'l_value :=''select VMEP.MFVID,',
'       VMEP.VORSCHRIFTID,',
'       VMEP.JIRAKEY ',
'from V_MFV_ERROR_PERMALINK VMEP',
'WHERE to_char(VMEP.VORSCHRIFTID) not in(select to_char(tv.VORSCHRIFTID) from T_VORSCHRIFT tv)',
'or VMEP.VORSCHRIFTID is null',
'             ',
'      ',
'',
''';',
'else ',
'l_value :=''select VMEP.MFVID,',
'       VMEP.VORSCHRIFTID,',
'       VMEP.JIRAKEY ',
'from V_MFV_ERROR_PERMALINK VMEP',
'WHERE   to_char(VMEP.VORSCHRIFTID) in(select to_char(tv.VORSCHRIFTID) from T_VORSCHRIFT tv)',
'and VMEP.VORSCHRIFTID is not null',
'      ',
''';',
'',
'end if;',
'return(l_value);',
'-- dbms_output.put_line(l_value);',
'end;',
'',
'',
'',
'',
'',
'---- today 12.12.2023',
'',
'select VMEP.MFVID,',
'       VMEP.VORSCHRIFTID,',
'       ''<a href="https://www.cip.audi.de/jira/browse/'' || VMEP.JIRAKEY || ''" target="_blank">'' || VMEP.JIRAKEY || ''</a>'' AS JIRA_LINK,',
'       case when to_char(VMEP.VORSCHRIFTID) != to_char(tv.VORSCHRIFTID) or VMEP.VORSCHRIFTID is null or tv.VORSCHRIFTID is null then ''Error''',
'       else',
'       ''Not Error''',
'       end Permalink_Error',
'from V_MFV_ERROR_PERMALINK VMEP left outer join T_VORSCHRIFT tv on(to_char(VMEP.VORSCHRIFTID) = to_char(tv.VORSCHRIFTID)  )',
'where (case when :P1010_SWITCH =1 and to_char(VMEP.VORSCHRIFTID) != to_char(tv.VORSCHRIFTID)  then 1 else 0 end)=:P1010_SWITCH',
'or VMEP.VORSCHRIFTID is null or tv.VORSCHRIFTID is null'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(6568641275576768416)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>10240853591476156651
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949412464384387584)
,p_db_column_name=>'MFVID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Mfvid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(835543187651475371)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949412023923387584)
,p_db_column_name=>'PERMALINK_ERROR'
,p_display_order=>40
,p_column_identifier=>'E'
,p_column_label=>'Error'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949411645447387584)
,p_db_column_name=>'JIRA_LINK'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Jira Link'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949411290785387583)
,p_db_column_name=>'MFV_VOR_ID'
,p_display_order=>60
,p_column_identifier=>'G'
,p_column_label=>'Permalink'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949410835296387583)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Permalink'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(6571690381349971122)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2746834'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'MFVID:MFV_VOR_ID:JIRA_LINK:PERMALINK_ERROR:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6568640999277768413)
,p_plug_name=>unistr('Pr\00FCfung Teil')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from(select VMEP.MFVID,',
'       VMEP.MFV_TEILID,',
'       VMEP.MFV_TEIL,',
'        -- VMEP.JIRAKEY,',
'        ''<a href="https://cicd.cloud.audi/jira/browse/'' || VMEP.JIRAKEY || ''" target="_blank">'' || VMEP.JIRAKEY || ''</a>'' AS JIRA_LINK,',
unistr('       CASE WHEN VMEP.MFV_TEILID IS NULL or VMEP.MFV_TEIL IS NULL then ''Teil, kann nicht aufgel\00F6st werden'''),
'       else',
'       ''Not Error'' ',
'       end Error_teil   ',
'from MV_MFV_ERROR_PART VMEP)',
'where (case when :P1010_SWITCH=1 AND Error_teil =''Error'' then 1 else 0 end)=:P1010_SWITCH;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P1010_SWITCH'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Pr\00FCfung Teil')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(6568641753274768420)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>10240854069174156655
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949407239760387577)
,p_db_column_name=>'MFVID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Mfvid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(835543187651475371)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949406845461387577)
,p_db_column_name=>'MFV_TEILID'
,p_display_order=>30
,p_column_identifier=>'D'
,p_column_label=>'Mfv Teilid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949406510245387577)
,p_db_column_name=>'MFV_TEIL'
,p_display_order=>40
,p_column_identifier=>'E'
,p_column_label=>'Mfv Teil'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949406108329387577)
,p_db_column_name=>'ERROR_TEIL'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Error'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949405698998387576)
,p_db_column_name=>'JIRA_LINK'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Jira Link'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(6571692667516977176)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2746856'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'MFVID:MFV_TEIL:JIRA_LINK:ERROR_TEIL:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6568642145509768424)
,p_plug_name=>unistr('Pr\00FCfung MFVID und Linksammelordner')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>90
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from (Select VMEM.MFVID,',
'    VMEM.MFV_NAME,',
'    VMEM.LINKSAMMELORDNER,',
'',
'    -- VMEM.JIRAKEY,',
'    ''<a href="https://cicd.cloud.audi/jira/browse/'' || VMEM.JIRAKEY || ''" target="_blank">'' || VMEM.JIRAKEY || ''</a>'' AS JIRA_LINK,',
'',
'',
'   ',
'    CASE',
'        WHEN VMEM.MFVID IS NULL and  (DMS_DOKUMENTENSTATUS != 40  or jira_Status !=0)THEN ''MFVid ist leer''',
unistr('        WHEN VMEM.LINKSAMMELORDNER IS NULL and (DMS_DOKUMENTENSTATUS != 40 and jira_Status =10) THEN ''Link, kann nicht aufgel\00F6st werden 1'''),
unistr('        WHEN VMEM.LINKSAMMELORDNER NOT LIKE ''https://%'' and (DMS_DOKUMENTENSTATUS != 40 and jira_Status =10 ) THEN ''Link, kann nicht aufgel\00F6st werden 2'''),
unistr('        WHEN VMEM.LINKSAMMELORDNER LIKE ''% %''  and DMS_DOKUMENTENSTATUS != 40 and jira_Status =10 THEN ''Link, kann nicht aufgel\00F6st werden 3'' -- To catch links with spaces'),
'        ELSE ''Not Error''',
'    END AS MFV_ERROR',
'from MV_MFV_ERROR_MFV VMEM)',
unistr('where (case when :P1010_SWITCH=1 AND (MFV_ERROR = ''MFVid ist leer'' OR substr(MFV_ERROR,0,33) = ''Link, kann nicht aufgel\00F6st werden'') then 1 else 0 end)=:P1010_SWITCH;')))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P1010_SWITCH'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Pr\00FCfung MFVID und Linksammelordner')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from (Select VMEM.MFVID,',
'    -- VMEM.MFV_NAME,',
'    VMEM.LINKSAMMELORDNER,',
'    -- VMEM.BETEILIGTE_OES,',
'    -- -- VMEM.JIRAKEY,',
'    -- ''<a href="https://www.cip.audi.de/jira/browse/'' || VMEM.JIRAKEY || ''" target="_blank">'' || VMEM.JIRAKEY || ''</a>'' AS JIRA_LINK,',
'    -- VMEM.MFV_THEMA,',
'    -- VMEM.ENVIRONMENT,',
'    -- VMEM.STATUS_CLOSED,',
'    CASE',
'        WHEN VMEM.MFVID IS NULL THEN ''Error''',
'        WHEN VMEM.LINKSAMMELORDNER IS NULL THEN ''Error''',
'        WHEN VMEM.LINKSAMMELORDNER NOT LIKE ''https://%'' THEN ''Error''',
'        WHEN VMEM.LINKSAMMELORDNER LIKE ''% %'' THEN ''Error'' -- To catch links with spaces',
'        ELSE ''Not Error''',
'    END AS MFV_ERROR',
'from V_MFV_ERROR_MFV VMEM)',
'where (case when :P1010_SWITCH=1 AND MFV_ERROR =''Error'' then 1 else 0 end)=:P1010_SWITCH;'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(6568642270421768425)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>10240854586321156660
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949409858068387581)
,p_db_column_name=>'MFVID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Mfvid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(835543187651475371)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949409500024387581)
,p_db_column_name=>'LINKSAMMELORDNER'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Linksammelordner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949409089280387581)
,p_db_column_name=>'MFV_ERROR'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Error'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949408704756387580)
,p_db_column_name=>'MFV_NAME'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Mfv Name'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949408221784387580)
,p_db_column_name=>'JIRA_LINK'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Jira Link'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(6572410524027728987)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2754035'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'MFVID:LINKSAMMELORDNER:JIRA_LINK:MFV_ERROR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6572549400831891701)
,p_plug_name=>unistr('Pr\00FCfung Arbeitskreis')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>60
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select VMEA.ET_B_AKID,',
'        -- TEBA.ET_B_AKID,',
'       VMEA.MFVID,',
'       VMEA.MFV_REF_ET_B_AKID,',
'       VMEA.AK_KURZ,',
'    --    TEBA.KURZ tk,',
'        ',
'       ''<a href="https://cicd.cloud.audi/jira/browse/'' || VMEA.JIRAKEY || ''" target="_blank">'' || VMEA.JIRAKEY || ''</a>'' AS JIRA_LINK,',
'       case when to_char(VMEA.ET_B_AKID) = to_char(TEBA.ET_B_AKID) AND TRIM(UPPER(VMEA.AK_KURZ)) = TRIM(UPPER(TEBA.KURZ)) then ''Not Error''',
unistr('       else ''Arbeitskreis, kann nicht aufgel\00F6st werden'''),
'       end as AK_Error',
'from MV_MFV_ERROR_AK VMEA left outer join T_ET_B_AK TEBA on(to_char(VMEA.ET_B_AKID) = to_char(TEBA.ET_B_AKID) AND TRIM(UPPER(VMEA.AK_KURZ)) = TRIM(UPPER(TEBA.KURZ)) )',
'where (case when :P1010_SWITCH =1 and to_char(VMEA.ET_B_AKID) != to_char(TEBA.ET_B_AKID) AND TRIM(UPPER(VMEA.AK_KURZ)) != TRIM(UPPER(TEBA.KURZ))  then 1 else 0 end)= :P1010_SWITCH',
'or VMEA.ET_B_AKID is null or TEBA.ET_B_AKID is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P1010_SWITCH'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Pr\00FCfung Arbeitskreis')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>'s'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(6572549508469891702)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>10244761824369279937
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949404681612387575)
,p_db_column_name=>'ET_B_AKID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Et B Akid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949404227427387575)
,p_db_column_name=>'MFVID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Mfvid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(835543187651475371)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949403840153387574)
,p_db_column_name=>'MFV_REF_ET_B_AKID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Mfv Ref Et B Akid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949403448541387574)
,p_db_column_name=>'AK_KURZ'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Ak Kurz'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949403109465387574)
,p_db_column_name=>'AK_ERROR'
,p_display_order=>60
,p_column_identifier=>'G'
,p_column_label=>'Error'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949402656378387574)
,p_db_column_name=>'JIRA_LINK'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Jira Link'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(6573827419146673134)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2768204'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'MFVID:AK_KURZ:JIRA_LINK:AK_ERROR:'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(951939256230316317)
,p_name=>'P1010_MFVID_TO_DELETE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(3793866559087692444)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(949401994283387566)
,p_name=>'P1010_SWITCH'
,p_item_sequence=>20
,p_item_default=>'1'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Error',
  'off_value', '1',
  'on_label', 'Alle',
  'on_value', '0',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(949401534694387558)
,p_name=>'Refresh'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1010_SWITCH'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(949401030810387553)
,p_event_id=>wwv_flow_imp.id(949401534694387558)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6568640907854768412)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(949400555244387552)
,p_event_id=>wwv_flow_imp.id(949401534694387558)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6572549400831891701)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(949400067904387551)
,p_event_id=>wwv_flow_imp.id(949401534694387558)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6568640999277768413)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(949399591259387551)
,p_event_id=>wwv_flow_imp.id(949401534694387558)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6568642145509768424)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(949399163940387551)
,p_name=>'dialog_closed'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(6359813649741038081)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(949398627828387550)
,p_event_id=>wwv_flow_imp.id(949399163940387551)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6359813649741038081)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(951939126275316316)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DELETE_MFV_RECORD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_mfvid NUMBER := :P1010_MFVID_TO_DELETE;',
'    v_jira_ticket VARCHAR2(150);',
'BEGIN',
'    -- Get JIRA ticket for confirmation message',
'    SELECT jira_ticket INTO v_jira_ticket',
'    FROM T_MFV',
'    WHERE MFVID = v_mfvid;',
'    ',
'    -- Delete from reference tables first (due to foreign keys)',
'    DELETE FROM T_MFV_REF_VORSCHRIFT WHERE MFVID = v_mfvid;',
'    DELETE FROM T_MFV_REF_ET_B_AK WHERE MFVID = v_mfvid;',
'    DELETE FROM T_MFV_REF_MFV_TEIL WHERE MFVID = v_mfvid;',
'    ',
'    -- Delete from main table',
'    DELETE FROM T_MFV WHERE MFVID = v_mfvid;',
'    ',
'    COMMIT;',
'    ',
'    -- apex_application.g_print_success_msg := ''MFV Record deleted successfully (JIRA: '' || v_jira_ticket || '')'';',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        apex_error.add_error(',
'            p_message => ''Error deleting MFV record: '' || SQLERRM,',
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DELETE_MFV'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>unistr('MFV-Datensatz erfolgreich gel\00F6scht')
,p_internal_uid=>2720273189624071919
);
wwv_flow_imp.component_end;
end;
/
