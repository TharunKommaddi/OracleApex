prompt --application/pages/page_00036
begin
--   Manifest
--     PAGE: 00036
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>36
,p_name=>unistr('Zuweisung AK f\00FCr thema und Vorschriften')
,p_alias=>unistr('ZUWEISUNG-AK-F\00DCR-THEMA-UND-VORSCHRIFTEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Zuweisung AK f\00FCr thema und Vorschriften')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#r_vorsch'').on(''click'', ''th input'', function() {',
'    var check_all = $("#r_vorsch").find("th input:checked").is(":checked");',
'',
'    $("#r_vorsch").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'});'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'800'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(658638757019621086)
,p_plug_name=>'Arbeitskreise'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(658638273880621081)
,p_name=>'Vorschriften'
,p_region_name=>'r_vorsch'
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte as (  select v.vorschriftid vorschriftid, v.vorschrift_nummer vorschrift_nummer, t.nummer nummer, t.bezeichnung',
'                  from t_Vorschrift_ref_thema vrt',
'                 join t_vorschrift v  on (v.vorschriftid = vrt.vorschriftid )',
'                join t_Thema t on (t.Themaid =vrt.Themaid)',
'                -- where vrt.themaid = :P343_THEMAID  --(ThemaId aus P35) 1319',
'                where vrt.themaid = :P36_THEMAID  --(ThemaId aus P35) 1319',
'                and vrt.geloescht =0 ',
'    )',
'    select APEX_ITEM.CHECKBOX2(1, cte.vorschriftid, null, :P36_SELECTED_VORSCHRIFTEN_AK_P35, '':'' ) as checkbox, ',
'         cte.vorschrift_nummer ',
'       , listagg( ak.kurz, '','' on overflow truncate ''...'') within group (order by ak.kurz) Arbeitskreise',
'    from cte',
'     left join t_vorschrift_ref_ET_B_AK vra on (vra.vorschriftid = cte.vorschriftid)',
'    left join t_ET_B_AK ak on (ak.ET_B_AKid = vra.ET_B_AKid and vra.geloescht=0)',
'      --where cte.vorschriftid= 11260',
'    group by cte.vorschrift_nummer, cte.vorschriftid'))
,p_display_when_condition=>'P35_THEMAID'
,p_display_condition_type=>'ITEM_IS_NUMERIC'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P36_THEMAID,P36_SELECTED_VORSCHRIFTEN_AK_P35'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>200
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(658636685072621065)
,p_query_column_id=>1
,p_column_alias=>'CHECKBOX'
,p_column_display_sequence=>10
,p_column_heading=>'<input type="checkbox"7>'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(658638088143621079)
,p_query_column_id=>2
,p_column_alias=>'VORSCHRIFT_NUMMER'
,p_column_display_sequence=>20
,p_column_heading=>'Vorschrift Nummer'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(653890581831692699)
,p_query_column_id=>3
,p_column_alias=>'ARBEITSKREISE'
,p_column_display_sequence=>30
,p_column_heading=>'Arbeitskreise'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(658637196814621070)
,p_plug_name=>'Dialog Footer'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(658636940863621068)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(658637196814621070)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(658637494324621073)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(658637196814621070)
,p_button_name=>'APPLY'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Zwischenspeichern'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(658638639190621085)
,p_name=>'P36_THEMAID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(658638757019621086)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(658638583371621084)
,p_name=>'P36_THEMA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(658638757019621086)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(658638500847621083)
,p_name=>'P36_ARBEITSKREISE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(658638757019621086)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Arbeitskreise'
,p_source=>'select :P35_ARBEITSKREISEID from dual;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_ARBEITSKREIS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' SELECT ',
'    ET_B_AKID, ',
'    kurz, ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN Bezeichnung',
'        ELSE name_eng',
'    END AS name',
'FROM T_ET_B_AK ',
'WHERE ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN Bezeichnung',
'        ELSE name_eng',
'    END NOT IN ',
'    (',
'        CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''Administratoren'' ELSE ''Administrators'' END,',
'        CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''Redaktionsteam'' ELSE ''Editorial Team'' END',
'    );',
''))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0',
  'width', '700')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(658637631334621074)
,p_name=>'P36_CAME_FROM'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(658638757019621086)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(653890095572692694)
,p_name=>'P36_SELECTED_VORSCHRIFTEN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(658638757019621086)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(653888485699692678)
,p_name=>'P36_SELECTED_VORSCHRIFTEN_AK_P35'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(658638757019621086)
,p_use_cache_before_default=>'NO'
,p_source=>'select :P35_SELECTED_VORSCHRIFTEN_AK from dual;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(658636871256621067)
,p_name=>'Cancel Dialog'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(658636940863621068)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(658636799831621066)
,p_event_id=>wwv_flow_imp.id(658636871256621067)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(658636538035621064)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Checkboxen auslesen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'   :P36_SELECTED_VORSCHRIFTEN := null;',
'   --debug('' P36 APP.G_F01: count = ''|| APEX_APPLICATION.G_F01.COUNT);',
'     FOR i IN 1.. APEX_APPLICATION.G_F01.COUNT LOOP ',
'    -- debug('' P36: element ''||I||'' = ''||APEX_APPLICATION.G_F01(i)); ',
'      :P36_SELECTED_VORSCHRIFTEN := :P36_SELECTED_VORSCHRIFTEN || APEX_APPLICATION.G_F01(i) || '':'';',
'     END LOOP; '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(658637494324621073)
,p_process_success_message=>'Applyed'
,p_internal_uid=>3013575777863767171
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(658635579431621054)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'close Dlg'
,p_attribute_01=>'P36_ARBEITSKREISE,P36_SELECTED_VORSCHRIFTEN'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(658637494324621073)
,p_internal_uid=>3013576736467767181
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(653888538721692679)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load AKs'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (:P36_CAME_FROM in (35)) then',
'',
'  --debug (''P35_ARBEITSKREISEID=''|| :P35_ARBEITSKREISEID );',
'    ',
'    :P36_ARBEITSKREISE := :P35_ARBEITSKREISEID;',
'  -- debug (''P36_ARBEITSKREISE=''|| :P36_ARBEITSKREISE );',
'    ',
'    :P36_SELECTED_VORSCHRIFTEN_AK_P35 :=  :P35_SELECTED_VORSCHRIFTEN_AK;',
'  --  debug ('' P36_SELECTED_VORSCHRIFTEN_AK_P35=''||:P36_SELECTED_VORSCHRIFTEN_AK_P35); ',
'END IF;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>3018323777177695556
);
wwv_flow_imp.component_end;
end;
/
