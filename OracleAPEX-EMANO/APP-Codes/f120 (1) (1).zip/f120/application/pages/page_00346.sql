prompt --application/pages/page_00346
begin
--   Manifest
--     PAGE: 00346
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>346
,p_name=>'Funktionen zuordnen'
,p_page_mode=>'MODAL'
,p_step_title=>'Funktionen zuordnen'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(213990599953655443)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(215973868834853537)
,p_name=>'Funktionen'
,p_region_name=>'tabfunk'
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct ',
'    APEX_ITEM.checkbox2(1, f.funktionid, nvl2(vrf.vorschrift_ref_funktionid, ''checked'', null)) as "CHECKBOX",',
'     vrf.vorschrift_ref_funktionid as VORSCHRIFT_REF_FUNKTIONID,',
'    :P346_VORSCHRIFTID AS "VORSCHRIFT",',
'    f.funktionid,',
'    f.bezeichnung as "FUNKTION",',
'    vrf.LETZTE_AENDERUNG_DATUM,',
'    nvl2(vrf.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) AS "LETZTE_AENDERUNG_BENUTZERID"',
'from t_vorschrift_ref_thema vt ',
'inner join t_thema_ref_funktion trf on trf.themaid = vt.themaid',
'inner join t_funktion f on f.funktionid = trf.funktionid',
'left outer join t_vorschrift_ref_funktion vrf on (vrf.vorschriftid = vt.vorschriftid ',
'                                                  and vrf.funktionid = f.funktionid)',
'left outer join t_benutzer b on b.benutzerid = vrf.LETZTE_AENDERUNG_BENUTZERID',
'where vt.geloescht = 0',
'    and vt.vorschriftid = :P346_VORSCHRIFTID',
'order by f.bezeichnung asc',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('Es k\00F6nnen keine Funktionen zugeordnet werden.')
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(213991149766655449)
,p_query_column_id=>1
,p_column_alias=>'CHECKBOX'
,p_column_display_sequence=>1
,p_column_heading=>'<input type="checkbox" /> '
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(215974258736853541)
,p_query_column_id=>2
,p_column_alias=>'VORSCHRIFT_REF_FUNKTIONID'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(213990276024655440)
,p_query_column_id=>3
,p_column_alias=>'VORSCHRIFT'
,p_column_display_sequence=>5
,p_column_heading=>'Vorschrift'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(2642128612516763789)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(215975029528853542)
,p_query_column_id=>4
,p_column_alias=>'FUNKTIONID'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(213990370513655441)
,p_query_column_id=>5
,p_column_alias=>'FUNKTION'
,p_column_display_sequence=>4
,p_column_heading=>'Funktion'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(215975411236853542)
,p_query_column_id=>6
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>6
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_column_format=>'DD.MM.YYYY HH24::mi'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(215975877253853542)
,p_query_column_id=>7
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZERID'
,p_column_display_sequence=>7
,p_column_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(213990663989655444)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(213990599953655443)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(213990730430655445)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(213990599953655443)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213990402838655442)
,p_name=>'P346_VORSCHRIFTID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(215973868834853537)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(216137160268779006)
,p_name=>'P346_SELECTED_ROWS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(215973868834853537)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(213991226995655450)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(213990663989655444)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(216136671601779001)
,p_event_id=>wwv_flow_imp.id(213991226995655450)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(216137238410779007)
,p_name=>'select row'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'td input[type=checkbox]'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#tabfunk'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(216137378979779008)
,p_event_id=>wwv_flow_imp.id(216137238410779007)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var sel_rows = apex.item(''P346_SELECTED_ROWS'');',
'sel_rows.setValue("");',
'$("#tabfunk").find("td input:checked").each(function() {',
'  if(sel_rows.getValue().length > 0) {',
'    sel_rows.setValue(sel_rows.getValue() + ":");    ',
'  }',
'  sel_rows.setValue(sel_rows.getValue() + this.value);',
'});',
'//alert(sel_rows.getValue());',
'// werte serverseitig bekannt machen',
'apex.server.process(''DUMMY_PROCESS'', {',
'    pageItems: ''#P346_SELECTED_ROWS''',
'},{dataType: ''text''});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(216137404561779009)
,p_name=>'select all rows'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'th input[type=checkbox]'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#tabfunk'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(216137557742779010)
,p_event_id=>wwv_flow_imp.id(216137404561779009)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var check_all = $("#tabfunk").find("th input[type=checkbox]:checked").is(":checked");',
'',
unistr('// alle Zeilen ausw\00E4hlen/abw\00E4hlen'),
'$("#tabfunk").find("td input[type=checkbox]").each(function() {',
'    this.checked = check_all;',
'});',
'',
unistr('// alle ausgew\00E4hlten Zeilen-IDs in das Item P346_SELECTED_ROWS'),
'var sel_rows = apex.item(''P346_SELECTED_ROWS'');',
'sel_rows.setValue("");',
'$("#tabfunk").find("td input[type=checkbox]:checked").each(function() {',
'  if(sel_rows.getValue().length > 0) {',
'    sel_rows.setValue(sel_rows.getValue() + ":");    ',
'  }',
'  sel_rows.setValue(sel_rows.getValue() + this.value);',
'});',
'// werte serverseitig bekannt machen',
'apex.server.process(''DUMMY_PROCESS'', {',
'    pageItems: ''#P346_SELECTED_ROWS''',
'},{dataType: ''text''});',
'//alert (sel_rows.getValue());',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(216136733484779002)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process Row of T_VORSCHRIFT_REF_FUNKTION'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'merge into T_VORSCHRIFT_REF_FUNKTION dest',
'using (select :P346_VORSCHRIFTID as vorschriftid, column_value as funktionid',
'       from TABLE(APEX_STRING.split_numbers(:P346_SELECTED_ROWS, '':''))) src',
'on (src.vorschriftid = dest.vorschriftid ',
'   and src.funktionid = dest.funktionid)',
'when not matched then',
'    insert(vorschriftid, funktionid)',
'    values(src.vorschriftid, src.funktionid);',
'    ',
'delete from T_VORSCHRIFT_REF_FUNKTION vrf',
'where vrf.vorschriftid = :P346_VORSCHRIFTID',
'        and vrf.funktionid not in (select column_value FROM TABLE(APEX_STRING.split_numbers(:P346_SELECTED_ROWS, '':'')));',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3888349049384167237
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(216136898054779003)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3888349213954167238
);
wwv_flow_imp.component_end;
end;
/
