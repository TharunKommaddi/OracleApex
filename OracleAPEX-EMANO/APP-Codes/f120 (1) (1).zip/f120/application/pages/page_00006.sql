prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>unistr('Ung\00FCltige Vorschrift ausgew\00E4hlt')
,p_alias=>unistr('UNG\00DCLTIGE-VORSCHRIFT-AUSGEW\00C4HLT')
,p_step_title=>unistr('Ung\00FCltige Vorschrift ausgew\00E4hlt')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(3414109515918820536)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(644938228160799742)
,p_plug_name=>unistr('Ung\00FCltige Vorschrift')
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--danger'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<br />Sie haben einen Link f\00FCr eine Vorschrift verwendet, der ung\00FCltig ist oder f\00FCr die Sie nicht berechtigt sind.<br /><br />'),
'<a style="text-decoration: underline; text-decoration-style:dashed" href="f?p=regindex">Zur Startseite</a>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
