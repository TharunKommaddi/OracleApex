prompt --application/pages/page_00424
begin
--   Manifest
--     PAGE: 00424
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>424
,p_name=>unistr('Vorschriften mit REV \00C4nderung')
,p_alias=>unistr('VORSCHRIFTEN-MIT-REV-\00C4NDERUNG')
,p_step_title=>unistr('Vorschriften mit REV \00C4nderung')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'function delete_fun(){',
'    // alert(''TEST'');',
'    apex.submit(''DELETE'');',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3360041842613222249)
,p_plug_name=>unistr('Vorschriften mit REV \00C4nderung')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3661432808192511254)
,p_plug_name=>unistr('Vorschriften mit REV \00C4nderung')
,p_region_name=>'ig_vorschr'
,p_parent_plug_id=>wwv_flow_imp.id(3360041842613222249)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'vrv.VORSCHRIFT_REF_VERANTWORTLICHERID as VORSCHRIFT_REF_VERANTWORTLICHERID,',
'1 as details,',
'vo.vorschriftid as Vorschriftid,',
'vo.vorschrift_nummer as Vorschrift,',
'v.nachname || '', '' || v.vorname as BISHER_VERANTWORTLICHER,',
unistr('decode(vo.RXSWIN, 10, ''ja'', 0, ''nein'', 20, ''nicht gepr\00FCft'') as potentiell_sums_relevant,'),
'vo.swr_hauptumsetzende_oe as hauptumsetzende_oe, ',
'CASE vrv.ist_Hauptverantwortlicher',
'        WHEN 10 THEN ''Hauptverantwortlicher''',
'        WHEN 20 THEN ''Nebenverantwortlicher''',
'END AS Ist_Hauptverantwortlicher,',
'rev_ctrl_vorschrift.rev_kontrolle_id,',
unistr('decode(rev_ctrl_vorschrift.STATUS, 10, ''best\00E4tigt'', 0, ''offen'', 20, ''abgelehnt'') as status,'),
'case when ben.benutzerid is not null then ben.vorname || '', '' || ben.nachname else '''' end as NEUER_VERANTWORTLICHER',
'from t_vorschrift vo ',
'join t_vorschrift_ref_verantwortlicher vrv on (vrv.vorschriftid = vo.vorschriftid)',
'join t_rev_kontrolle rev_ctrl on rev_ctrl.verantwortlicherid = vrv.verantwortlicherid ',
'join t_verantwortlicher v on v.verantwortlicherid = rev_ctrl.verantwortlicherid',
'join T_REV_KONTROLLE_VORSCHRIFT rev_ctrl_vorschrift on (rev_ctrl_vorschrift.vorschriftid = vo.vorschriftid and rev_ctrl_vorschrift.rev_kontrolle_id = rev_ctrl.rev_kontrolle_id)',
'left join t_benutzer ben on (ben.benutzerid = vrv.neuer_verantwortlicherid or ben.benutzerid = rev_ctrl_vorschrift.neuer_verantwortlicherid)',
'where rev_ctrl_vorschrift.STATUS = 20',
'or ben.benutzerid is not null',
''))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Vorschriften mit REV \00C4nderung')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1978228344804563345)
,p_name=>'VORSCHRIFT_REF_VERANTWORTLICHERID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFT_REF_VERANTWORTLICHERID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>90
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1978228564890563347)
,p_name=>'VORSCHRIFTID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFTID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1978228723442563348)
,p_name=>'VORSCHRIFT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Vorschrift'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1978228813458563349)
,p_name=>'POTENTIELL_SUMS_RELEVANT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'POTENTIELL_SUMS_RELEVANT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Potentiell Sums Relevant'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1978228834203563350)
,p_name=>'HAUPTUMSETZENDE_OE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HAUPTUMSETZENDE_OE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Hauptumsetzende Oe'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1978228952151563351)
,p_name=>'IST_HAUPTVERANTWORTLICHER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IST_HAUPTVERANTWORTLICHER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Ist Hauptverantwortlicher'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1978229043290563352)
,p_name=>'REV_KONTROLLE_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'REV_KONTROLLE_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>160
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1978229126682563353)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Status'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>180
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1978229312159563354)
,p_name=>'NEUER_VERANTWORTLICHER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NEUER_VERANTWORTLICHER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Neuer Verantwortlicher'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>190
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1978229675363563358)
,p_name=>'BISHER_VERANTWORTLICHER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BISHER_VERANTWORTLICHER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'bisher Verantwortlicher'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>170
,p_value_alignment=>'CENTER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2944984960131187415)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'Y',
  'hide_control', 'N',
  'show_select_all', 'Y')).to_clob
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2944985481674187420)
,p_name=>'DETAILS'
,p_source_type=>'NONE'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_LINK'
,p_heading=>'&nbsp;'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'CENTER'
,p_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:&VORSCHRIFTID.'
,p_link_text=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_link_attributes=>'target="_blank"'
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(2944982672861187392)
,p_internal_uid=>6617194988760575627
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>false
,p_fixed_row_height=>false
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(2944991208443187770)
,p_interactive_grid_id=>wwv_flow_imp.id(2944982672861187392)
,p_static_id=>'4721577'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(2944991402351187771)
,p_report_id=>wwv_flow_imp.id(2944991208443187770)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1978249881958620745)
,p_view_id=>wwv_flow_imp.id(2944991402351187771)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(1978228344804563345)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1978250782647620755)
,p_view_id=>wwv_flow_imp.id(2944991402351187771)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(1978228564890563347)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1978251666265620758)
,p_view_id=>wwv_flow_imp.id(2944991402351187771)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(1978228723442563348)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1978252562823620762)
,p_view_id=>wwv_flow_imp.id(2944991402351187771)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(1978228813458563349)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1978253483078620766)
,p_view_id=>wwv_flow_imp.id(2944991402351187771)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(1978228834203563350)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1978254391883620769)
,p_view_id=>wwv_flow_imp.id(2944991402351187771)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(1978228952151563351)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1978255284956620771)
,p_view_id=>wwv_flow_imp.id(2944991402351187771)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(1978229043290563352)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1978256212984620774)
,p_view_id=>wwv_flow_imp.id(2944991402351187771)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(1978229126682563353)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1978257068748620776)
,p_view_id=>wwv_flow_imp.id(2944991402351187771)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(1978229312159563354)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1978270916584678253)
,p_view_id=>wwv_flow_imp.id(2944991402351187771)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(1978229675363563358)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(2945053382265875286)
,p_view_id=>wwv_flow_imp.id(2944991402351187771)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(2944985481674187420)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>40
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2946156774703412295)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_imp.id(3661432808192511254)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2946691246532711992)
,p_plug_name=>'Neuer Verantwortlicher'
,p_parent_plug_id=>wwv_flow_imp.id(2946156774703412295)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1094392474340603735)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2946156774703412295)
,p_button_name=>'SEARCH_LDAP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'In LDAP suchen'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:65:&SESSION.::&DEBUG.:65:P65_CAMEFROM:423'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1094392042869603734)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2946156774703412295)
,p_button_name=>'SET_VERANTWORTLICHER'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Verantwortlichen setzen'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1094393133714603735)
,p_name=>'P424_SELECTED_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3661432808192511254)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1094391643246603734)
,p_name=>'P424_NEUER_VERANTWORTLICHER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2946156774703412295)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1094390986342603733)
,p_name=>'P424_NEW_NACHNAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2946691246532711992)
,p_prompt=>'Nachname'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1094390589041603733)
,p_name=>'P424_NEW_VORNAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2946691246532711992)
,p_prompt=>'Vorname'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1094390190903603733)
,p_name=>'P424_NEW_ABTEILUNG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2946691246532711992)
,p_prompt=>'Abteilung'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1094389728737603732)
,p_name=>'P424_NEW_MAIL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2946691246532711992)
,p_prompt=>'E-Mail'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1094388523401603731)
,p_name=>'Edit - P422 closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(3661432808192511254)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1094388073220603731)
,p_event_id=>wwv_flow_imp.id(1094388523401603731)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3661432808192511254)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1094387598721603731)
,p_event_id=>wwv_flow_imp.id(1094388523401603731)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P424_DELETE_CONDITION'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1094387170327603730)
,p_name=>'Change'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(3661432808192511254)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1094386660770603730)
,p_event_id=>wwv_flow_imp.id(1094387170327603730)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i, selectedIds = "",',
'model = this.data.model;',
'for ( i = 0; i < this.data.selectedRecords.length; i++ ) {',
'    selectedIds += model.getValue( this.data.selectedRecords[i], "VORSCHRIFT_REF_VERANTWORTLICHERID") + ":";',
'}',
'$s("P424_SELECTED_ID", selectedIds);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1094386243416603730)
,p_name=>'set_new_rev'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1094392042869603734)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1094385726990603730)
,p_event_id=>wwv_flow_imp.id(1094386243416603730)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var model = apex.region("ig_vorschr").widget().interactiveGrid("getViews", "grid").model;',
'var records = apex.region("ig_vorschr").call("getViews").grid.getSelectedRecords();',
'var new_rev = $v(''P424_NEUER_VERANTWORTLICHER'');',
'for ( i = 0; i < records.length; i++ ) {',
'    model.setValue(records[i], "NEUER_VERANTWORTLICHER", new_rev);',
'}'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1094388916303603732)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'lVerantId number;',
'lCount number;',
'lVorschriftid number;',
'lCountNewVerantw number;',
'begin',
'select count(benutzerid) into lCount from t_benutzer where gid like :P424_NEUER_VERANTWORTLICHER;',
'if (lCount > 0) then',
'    select benutzerid into lVerantId from t_benutzer where gid like :P424_NEUER_VERANTWORTLICHER;',
'    for c in (select column_value as vorschrift_ref_verantwortlicherid from apex_string.split_numbers(:P424_SELECTED_ID, '':'')) loop',
'        select vorschriftid into lVorschriftid from t_vorschrift_ref_verantwortlicher where vorschrift_ref_verantwortlicherid = c.vorschrift_ref_verantwortlicherid;',
'        select count(*) into lCountNewVerantw from t_vorschrift_ref_verantwortlicher where vorschriftid = lVorschriftid and verantwortlicherid = lVerantId;',
'        if (lCountNewVerantw < 1) then',
'            insert into t_vorschrift_ref_verantwortlicher (VORSCHRIFTID, VERANTWORTLICHERID, IST_HAUPTVERANTWORTLICHER, NEUER_VERANTWORTLICHERID)values(lVorschriftid, lVerantId, 10, lVerantId);',
'        end if;',
'    end loop;',
'end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1094392042869603734)
,p_internal_uid=>2577823399595784503
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1094389355468603732)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Initialize form Regulierungsverantwortlichkeit bearbeiten'
,p_process_sql_clob=>'null;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2577822960430784503
);
wwv_flow_imp.component_end;
end;
/
