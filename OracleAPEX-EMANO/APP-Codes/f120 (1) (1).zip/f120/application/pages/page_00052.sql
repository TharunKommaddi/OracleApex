prompt --application/pages/page_00052
begin
--   Manifest
--     PAGE: 00052
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>52
,p_name=>'450 - with lock'
,p_alias=>'450-WITH-LOCK'
,p_step_title=>'450 - with lock'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/**',
unistr('* refresh page jede 6 sec wenn ERGEBNIS_STATUS in suche ( Suchprocess steht bevor  oder l\00E4uft)'),
'* beende wenn STATUS =10 oder nach 40 sec',
'*/',
'function refreshPage() {',
'  var i = 0;',
'   var id = window.setInterval(function(){',
'         var refreshed =0;',
'    if( ($v(''P450_ERGEBNIS_STATUS'') == 10 || $v(''P450_ERGEBNIS_STATUS'') == 0) ){',
'        if( $v(''P450_TIMER_STARTED'') == '''') {',
'          refreshed = 1;',
'        }',
'         // $s(''P450_TIMER_STARTED'', '''');            //apex.page.submit(''REFRESH'');',
'     }',
'      //  console.log('' erg. Status(vor timer):'' + $v(''P450_ERGEBNIS_STATUS''));',
'',
'     $s(''P450_TIMER_STARTED'', ''1'');',
'    if( $v(''P450_ERGEBNIS_STATUS'') == 0  || $v(''P450_ERGEBNIS_STATUS'') == 10',
'      || $v(''P450_SUCHEID'') <2 ) {',
'        //console.log('' vor clearInterval(): Ergebnis status: ''+$v(''P450_ERGEBNIS_STATUS''));',
'        clearInterval(id);',
'        $s(''P450_TIMER_STARTED'', '''');',
'        i++;',
'       // console.log(''refreshed: '' + refreshed);',
'        if(0 == refreshed){',
'            refreshed = 1;',
'            apex.page.submit(''REFRESH'');',
'        }',
'       ',
'      // console.log(i);',
'        return;',
'    }',
'        // console.log('' ende function: Ergeb. status: ''+$v(''P450_ERGEBNIS_STATUS''));',
'    i++;',
'    // console.log(i);',
'',
'  }, 4000); // end of timeout function',
'};',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'function toggleMilestoneLock(milestone, isLocked) {',
'    apex.server.process(''TOGGLE_MILESTONE_LOCK'', {',
'        x01: $v(''P450_SUCHEID''),',
'        x02: milestone,',
'        x03: isLocked ? 1 : 0',
'    }, {',
'        success: function(data) {',
'            if (data.status === ''success'') {',
'                apex.message.showPageSuccess(',
'                    ''Meilenstein '' + milestone + '' Schreibschutz '' + ',
'                    (isLocked ? ''aktiviert'' : ''deaktiviert'')',
'                );',
'                // apex.region(''rSuche'').refresh();',
'                apex.page.submit();',
'                ',
'                // Update search button state',
'                setTimeout(function() {',
'                    updateSearchButtonState();',
'                }, 200);',
'                ',
'            } else {',
'                // apex.message.showPageError(''Error: '' + data.message);',
'            }',
'        },',
'        error: function(xhr, status, error) {',
'            // apex.message.showPageError(''Error: '' + error);',
'        },',
'        dataType: ''json''',
'    });',
'}',
'',
'',
'',
'// Function to update BTN_SUCHE button state based on milestone locks',
'function updateSearchButtonState() {',
'    // Check if any milestone is locked',
'    var milestone1Locked = $(''.milestone-locked'').length > 0;',
'    var anyCheckboxChecked = $(''input[onchange*="toggleMilestoneLock"]'').is('':checked'');',
'    ',
'    if (milestone1Locked || anyCheckboxChecked) {',
'        // Disable search button if any milestone is locked',
'        $(''#BTN_SUCHE'').addClass(''apex_disabled'').prop(''disabled'', true);',
'        $(''#BTN_SUCHE'').attr(''title'', ''Search disabled - milestone is write protected'');',
'    } else {',
'        // Enable search button if no milestones are locked',
'        $(''#BTN_SUCHE'').removeClass(''apex_disabled'').prop(''disabled'', false);',
'        $(''#BTN_SUCHE'').attr(''title'', ''Search'');',
'    }',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Hilfe-Buztton',
'//$(''#rSuche .t-Region-title'').append('' <span onclick="redirect(161)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'//$(''#rSuche_heading'').append('' <span onclick="redirect(161)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rSuche .t-Region-title:first'').append('' <span onclick="redirect(161)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'',
'',
'',
'',
'',
'',
'',
'// Initialize search button state on page load',
'$(document).ready(function() {',
'    updateSearchButtonState();',
'});'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.apex_disabled {',
'    opacity: 0.5;',
'    cursor: not-allowed !important;',
'}',
'',
'.tooltip-wrapper {',
'    display: inline-block;',
'}',
'',
'.t-Region-buttons {',
'    display: flex;',
'    flex-wrap: nowrap;',
'    gap: 8px;',
'}',
'',
'.t-Region-buttons .t-Button {',
'    white-space: nowrap;',
'}',
'',
'',
'',
'',
'/* SEARCH DETAILS */',
'',
'.search-info-enhanced {',
'    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);',
'    border-left: 4px solid #bb0a31;',
'    padding: 4px 4px;',
'    /* margin: 5px 0 10px 0; */',
'    border-radius: 4px;',
'    box-shadow: 0 1px 3px rgba(0,0,0,0.1);',
'}',
'',
'.search-title {',
'    color: #bb0a31;',
'    font-size: 16px;',
'    font-weight: bold;',
'    margin-bottom: 0px;',
'    line-height: 1.2;    ',
'}',
'',
'.search-meta {',
'    display: flex;',
'    flex-wrap: wrap;',
'    gap: 2px;',
'    font-size: 13px;',
'    align-items: center;',
'    margin-top: 2px;     ',
'    line-height: 1.1;  ',
'}',
'',
'.user-info {',
'    color: #495057;',
'    font-weight: 500;',
'    background: rgba(255,255,255,0.7);',
'    padding: 2px 6px;',
'    border-radius: 10px;',
'}',
'',
'.search-date {',
'    color: #6c757d;',
'    font-family: ''Courier New'', monospace;',
'    background: rgba(255,255,255,0.5);',
'    padding: 2px 6px;',
'    border-radius: 10px;',
'}',
'',
'.search-id {',
'    background: #bb0a31;',
'    color: white;',
'    padding: 3px 8px;',
'    border-radius: 10px;',
'    /* font-size: 11px; */',
'    font-weight: bold;',
'}',
'',
'.search-info-enhanced i {',
'    margin-right: 4px;',
'    width: 14px;',
'    text-align: center;',
'}',
'',
'/* SEARCH DETAILS */'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4778004347562137887)
,p_plug_name=>'Info VKO only'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_source=>unistr('Die Suche ist vorerst nur f\00FCr VKO freigegeben um die neu ben\00F6tigten Daten aufzubereiten!')
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9887302192210321086)
,p_plug_name=>'Suche'
,p_region_name=>'rSuche'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(5005417650388504056)
,p_name=>'CARD_SUCHLISTE 23 jul'
,p_parent_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_component_template_options=>'#DEFAULT#:t-Cards--animColorFill:t-Cards--3cols:t-Cards--basic'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select --:P52_SUCHEID, ',
'    ''<a href="'' || apex_page.get_url(p_page => 455, p_items => ''P455_SUCHEID,P455_MEILENSTEIN'', p_values => :P52_SUCHEID||'',1'', p_clear_cache => 455) ||',
'   ''"><span aria-hidden="true" class="fa fa-pencil-square"></span> '' || emano_util.fLang(''Eingabe Suchparameter'', ''Enter SearchParameters'') || '' </a>''  as CARD_SUBTEXT, ',
'   emano_util.fLang(''Meilenstein 1'',''Milestone 1'')    as CARD_TITLE,',
'     case when not exists (select  t.meilenstein',
'           from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN''',
'            ))) t where sucheid = :P52_SUCHEID and  t.meilenstein = 1 ) then ''<table> <tr><td>''|| emano_util.fLang(''Noch keine Suchparameter eingestellt'', ''No search parameters set yet'') || ''</td></tr></table>''',
'      else',
'      (',
'          select      ''<table>'' || ',
'    NVL2(t.ms, ''<tr><td>'' || emano_util.fLang(''Datum Meilenstein:'', ''Milestone Date:'') || ''</td><td>'' || t.ms || ''</td></tr>'', NULL)',
'         || nvl2( t.sop, ''<tr><td>'' ',
'                 || PCK_RI_SUCHE.fGetBezeichnungStartdatumTyp(t.laender) || '':</td><td>'' || t.sop || ''</td></tr>'', null)',
'         || NVL2(t.eop, ''<tr><td>'' || emano_util.fLang(''Datum EOP:'', ''EOP Date:'') || ''</td><td>'' || t.eop || ''</td></tr>'', NULL)',
unistr('         || NVL2(t.laender, ''<tr><td>'' || emano_util.fLang(''Relevante L\00E4nder:'', ''Relevant Countries:'') || ''</td><td>'' || TO_CHAR(REGEXP_COUNT(t.laender, '':'')+1) || ''</td></tr>'', NULL)'),
'',
'         || NVL2(t.themen, ''<tr><td>'' || emano_util.fLang(''Relevante Themen:'', ''Relevant Topics:'') || ''</td><td>'' || TO_CHAR(COUNT(DISTINCT x.column_value)) || ''</td></tr>'', NULL)',
'         || case when  t.laender is null or t.themen is null then ''<tr><td>''|| emano_util.fLang(''Noch keine Suchparameter eingestellt'', ''No search parameters set yet'') || ''</td></tr>'' else null end',
'         || ''</table>'' tab_e  ',
'         from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN'',',
'                laender varchar2(4000) PATH ''$.LAENDER'',',
'                themen varchar2(2000) path ''$.THEMEN'',',
'                ms varchar2(20) path ''$.DATUM_MEILENSTEIN'',',
'                sop varchar2(20) path ''$.DATUM_SOP'',',
'                eop varchar2(20) path ''$.DATUM_EOP''',
'                ))) t ,',
'          table ( select apex_string.split_numbers(t.themen, '':'') from dual) x,     ',
'          v_thema_baum vt  ',
'            where vt.Themaid = x.column_value  and sucheid = :P52_SUCHEID and t.meilenstein =1 and leaf=1   ',
'           group by  t.meilenstein , t.ms, t.sop, t.eop, t.laender, t.themen',
'     )  end AS CARD_TEXT',
'     from T_suche_json where sucheid = :P52_SUCHEID ',
'    ',
'    union ',
'     select   --:P52_SUCHEID, ',
'    ''<a href="'' || apex_page.get_url(p_page => 455, p_items => ''P455_SUCHEID,P455_MEILENSTEIN'', p_values => :P52_SUCHEID||'',2'', p_clear_cache => 455) ||',
'   ''"><span aria-hidden="true" class="fa fa-pencil-square"></span> '' || emano_util.fLang(''Eingabe Suchparameter'', ''Enter SearchParameters'') || '' </a>''   as CARD_SUBTEXT, ',
'    emano_util.fLang(''Meilenstein 2'',''Milestone 2'')     as CARD_TITLE,',
'    case when not exists (select  t.meilenstein',
'           from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN''',
'            ))) t where sucheid = :P52_SUCHEID and  t.meilenstein = 2 ) then ''<table> <tr><td>''|| emano_util.fLang(''Noch keine Suchparameter eingestellt'', ''No search parameters set yet'') || ''</td></tr></table>'' ',
'      else',
'      (',
'          select''<table>'' ||',
'                NVL2(t.ms, ''<tr><td>'' || emano_util.fLang(''Datum Meilenstein:'', ''Milestone Date:'') || ''</td><td>'' || t.ms || ''</td></tr>'', NULL)',
'                || NVL2(t.sop, ''<tr><td>'' ',
'                             || PCK_RI_SUCHE.fGetBezeichnungStartdatumTyp(t.laender) || '':</td><td>'' || t.sop || ''</td></tr>'', NULL)',
'                || NVL2(t.eop, ''<tr><td>'' || emano_util.fLang(''Datum EOP:'', ''EOP Date:'') || ''</td><td>'' || t.eop  || ''</td></tr>'', NULL)',
unistr('                || NVL2(t.laender, ''<tr><td>'' || emano_util.fLang(''Relevante L\00E4nder:'', ''Relevant Countries:'') || ''</td><td>'' || TO_CHAR(REGEXP_COUNT(t.laender, '':'')+1) || ''</td></tr>'', NULL)'),
'                || NVL2(t.themen, ''<tr><td>'' || emano_util.fLang(''Relevante Themen:'', ''Relevant Topics:'') || ''</td><td>'' || TO_CHAR(COUNT(DISTINCT x.column_value)) || ''</td></tr>'', NULL)',
'                || CASE WHEN t.laender IS NULL OR t.themen IS NULL THEN ''<tr><td>'' || emano_util.fLang(''Noch keine Suchparameter eingestellt'', ''No search parameters set yet'') || ''</td></tr>'' ELSE NULL END',
'                || ''</table>''',
'                    tab_e  ',
'         from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN'',',
'                laender varchar2(2000) PATH ''$.LAENDER'',',
'                themen varchar2(2000) path ''$.THEMEN'',',
'                ms varchar2(20) path ''$.DATUM_MEILENSTEIN'',',
'                sop varchar2(20) path ''$.DATUM_SOP'',',
'                eop varchar2(20) path ''$.DATUM_EOP''',
'                ))) t ,',
'          table ( select apex_string.split_numbers(t.themen, '':'') from dual) x,     ',
'          v_thema_baum vt  ',
'            where vt.Themaid = x.column_value  and sucheid = :P52_SUCHEID and t.meilenstein =2 and leaf=1   ',
'           group by  t.meilenstein , t.ms, t.sop, t.eop, t.laender, t.themen',
'     ) end AS CARD_TEXT',
'    from T_suche_json where sucheid = :P52_SUCHEID ',
'',
' union ',
'     select --:P52_SUCHEID, ',
'    ''<a href="'' || apex_page.get_url(p_page => 455, p_items => ''P455_SUCHEID,P455_MEILENSTEIN'', p_values => :P52_SUCHEID||'',3'', p_clear_cache => 455) ||',
'''"><span aria-hidden="true" class="fa fa-pencil-square"></span> '' || emano_util.fLang(''Eingabe Suchparameter'', ''Input Search Parameters'') || ''</a>'' AS CARD_SUBTEXT, ',
'emano_util.fLang(''Meilenstein 3'', ''Milestone 3'')',
'   as CARD_TITLE,',
'    case when not exists (select  t.meilenstein',
'           from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN''',
'            ))) t where sucheid = :P52_SUCHEID and  t.meilenstein = 3 ) then ''<table> <tr><td>'' || emano_util.fLang(''Noch keine Suchparameter eingestellt'', ''No search parameters set yet'') || ''</td></tr></table>''',
'',
'     else',
'     (',
'          select     ''<table>'' ||',
'                nvl2( t.ms, ''<tr><td>'' || emano_util.fLang(''Datum Meilenstein:'', ''Milestone Date:'') || ''</td><td>'' || t.ms || ''</td></tr>'', null)',
'                || nvl2( t.sop, ''<tr><td>'' || emano_util.fLang(PCK_RI_SUCHE.fGetBezeichnungStartdatumTyp(t.laender), PCK_RI_SUCHE.fGetBezeichnungStartdatumTyp(t.laender)) || '':</td><td>'' || t.sop || ''</td></tr>'', null) -- Assuming there''s no English '
||'version for this function''s return value',
'                || nvl2(t.eop, ''<tr><td>'' || emano_util.fLang(''Datum EOP:'', ''EOP Date:'') || ''</td><td>'' || t.eop || ''</td></tr>'', null)',
unistr('                || nvl2( t.laender, ''<tr><td>'' || emano_util.fLang(''Relevante L\00E4nder:'', ''Relevant Countries:'') || ''</td><td>'' || to_char(regexp_count(t.laender, '':'')+1) || ''</td></tr>'', null)'),
'                || nvl2( t.themen, ''<tr><td>'' || emano_util.fLang(''Relevante Themen:'', ''Relevant Topics:'') || ''</td><td>'' || to_char(count(distinct x.column_value)) || ''</td></tr>'', null)',
'                || case when  t.laender is null or t.themen is null then ''<tr><td>'' || emano_util.fLang(''Noch keine Suchparameter eingestellt'', ''No search parameters set yet'') || ''</td></tr>'' else null end',
'                || ''</table>''',
'             tab_e  ',
'         from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN'',',
'                laender varchar2(2000) PATH ''$.LAENDER'',',
'                themen varchar2(2000) path ''$.THEMEN'',',
'                ms varchar2(20) path ''$.DATUM_MEILENSTEIN'',',
'                sop varchar2(20) path ''$.DATUM_SOP'',',
'                eop varchar2(20) path ''$.DATUM_EOP''',
'                ))) t,',
'          table ( select apex_string.split_numbers(t.themen, '':'') from dual) x,     ',
'          v_thema_baum vt  ',
'            where vt.Themaid = x.column_value  and sucheid = :P52_SUCHEID and t.meilenstein =3 and leaf=1   ',
'           group by  t.meilenstein , t.ms, t.sop, t.eop, t.laender, t.themen  ',
'    ) end AS CARD_TEXT',
'   from T_suche_json where sucheid = :P52_SUCHEID ;',
''))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414129911996820551)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913650884673022891)
,p_query_column_id=>1
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>10
,p_column_heading=>'Card Subtext'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913650477096022889)
,p_query_column_id=>2
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>20
,p_column_heading=>'Card Title'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913650026243022888)
,p_query_column_id=>3
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>30
,p_column_heading=>'Card Text'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(9887302476333321089)
,p_name=>'CARD_SUCHLISTE'
,p_parent_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_component_template_options=>'#DEFAULT#:t-Cards--animColorFill:t-Cards--3cols:t-Cards--basic'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Meilenstein 1',
'SELECT ',
'    1 as sort_order, ',
'    CASE ',
'        WHEN EXISTS (',
'            SELECT 1 FROM t_suche_json t2, ',
'            json_table (t2.suchdaten, ''$[*]'' columns (',
'                meilenstein number path ''$.MEILENSTEIN'',',
'                locked number path ''$.LOCKED''',
'            )) jt2 ',
'            WHERE t2.sucheid = :P52_SUCHEID ',
'            AND jt2.meilenstein = 1 ',
'            AND NVL(jt2.locked, 0) = 1',
'        ) THEN',
unistr('            ''<span style="color: #999; cursor: not-allowed;" title="Meilenstein ist gesperrt - Bearbeitung nicht m\00F6glich">'),
'                <span class="fa fa-lock" style="margin-right: 5px;"></span>',
'                <span aria-hidden="true" class="fa fa-pencil-square"></span> '' || emano_util.fLang(''Eingabe Suchparameter'', ''Enter SearchParameters'') || '' ',
'            </span>''',
'        ELSE',
'            ''<a href="'' || apex_page.get_url(p_page => 455, p_items => ''P455_SUCHEID,P455_MEILENSTEIN'', p_values => :P52_SUCHEID||'',1'', p_clear_cache => 455) ||',
'            ''"><span aria-hidden="true" class="fa fa-pencil-square"></span> '' || emano_util.fLang(''Eingabe Suchparameter'', ''Enter SearchParameters'') || '' </a>''',
'    END as CARD_SUBTEXT,',
'    ',
'    CASE ',
'        WHEN EXISTS (',
'            SELECT 1 FROM t_suche_json t2, ',
'            json_table (t2.suchdaten, ''$[*]'' columns (',
'                meilenstein number path ''$.MEILENSTEIN'',',
'                locked number path ''$.LOCKED''',
'            )) jt2 ',
'            WHERE t2.sucheid = :P52_SUCHEID ',
'            AND jt2.meilenstein = 1 ',
'            AND NVL(jt2.locked, 0) = 1',
'        ) THEN',
'            ''<div class="milestone-locked">',
'                <span class="fa fa-lock"></span> Meilenstein 1 (Gesperrt)',
'                <div style="margin-top: 8px;">',
'                    <label>',
'                        <input type="checkbox" checked onchange="toggleMilestoneLock(1, false)"> ',
'                        Meilenstein Schreibschutz',
'                    </label>',
'                </div>',
'            </div>''',
'        ELSE',
'            ''<div>',
'                Meilenstein 1',
'                <div style="margin-top: 8px;">',
'                    <label>',
'                        <input type="checkbox" onchange="toggleMilestoneLock(1, true)"> ',
'                        Meilenstein Schreibschutz',
'                    </label>',
'                </div>',
'            </div>''',
'    END as CARD_TITLE,',
'    ',
'    case when not exists (select  t.meilenstein',
'           from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN''',
'            ))) t where sucheid = :P52_SUCHEID and  t.meilenstein = 1 ) then ''<table> <tr><td>''|| emano_util.fLang(''Noch keine Suchparameter eingestellt'', ''No search parameters set yet'') || ''</td></tr></table>''',
'      else',
'      (',
'          select      ''<table>'' || ',
'    NVL2(t.ms, ''<tr><td>'' || emano_util.fLang(''Datum Meilenstein:'', ''Milestone Date:'') || ''</td><td>'' || t.ms || ''</td></tr>'', NULL)',
'         || nvl2( t.sop, ''<tr><td>'' ',
'                 || PCK_RI_SUCHE.fGetBezeichnungStartdatumTyp(t.laender) || '':</td><td>'' || t.sop || ''</td></tr>'', null)',
'         || NVL2(t.eop, ''<tr><td>'' || emano_util.fLang(''Datum EOP:'', ''EOP Date:'') || ''</td><td>'' || t.eop || ''</td></tr>'', NULL)',
unistr('         || NVL2(t.laender, ''<tr><td>'' || emano_util.fLang(''Relevante L\00E4nder:'', ''Relevant Countries:'') || ''</td><td>'' || TO_CHAR(REGEXP_COUNT(t.laender, '':'')+1) || ''</td></tr>'', NULL)'),
'         || NVL2(t.themen, ''<tr><td>'' || emano_util.fLang(''Relevante Themen:'', ''Relevant Topics:'') || ''</td><td>'' || TO_CHAR(COUNT(DISTINCT x.column_value)) || ''</td></tr>'', NULL)',
'         || case when  t.laender is null or t.themen is null then ''<tr><td>''|| emano_util.fLang(''Noch keine Suchparameter eingestellt'', ''No search parameters set yet'') || ''</td></tr>'' else null end',
'         || ''</table>'' tab_e  ',
'         from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN'',',
'                laender varchar2(4000) PATH ''$.LAENDER'',',
'                themen varchar2(2000) path ''$.THEMEN'',',
'                ms varchar2(20) path ''$.DATUM_MEILENSTEIN'',',
'                sop varchar2(20) path ''$.DATUM_SOP'',',
'                eop varchar2(20) path ''$.DATUM_EOP''',
'                ))) t ,',
'          table ( select apex_string.split_numbers(t.themen, '':'') from dual) x,     ',
'          v_thema_baum vt  ',
'            where vt.Themaid = x.column_value  and sucheid = :P52_SUCHEID and t.meilenstein =1 and leaf=1   ',
'           group by  t.meilenstein , t.ms, t.sop, t.eop, t.laender, t.themen',
'     )  end AS CARD_TEXT',
'     from T_suche_json where sucheid = :P52_SUCHEID ',
'    ',
'UNION ',
'',
'-- Meilenstein 2',
'SELECT ',
'    2 as sort_order,',
'    CASE ',
'        WHEN EXISTS (',
'            SELECT 1 FROM t_suche_json t2, ',
'            json_table (t2.suchdaten, ''$[*]'' columns (',
'                meilenstein number path ''$.MEILENSTEIN'',',
'                locked number path ''$.LOCKED''',
'            )) jt2 ',
'            WHERE t2.sucheid = :P52_SUCHEID ',
'            AND jt2.meilenstein = 2 ',
'            AND NVL(jt2.locked, 0) = 1',
'        ) THEN',
unistr('            ''<span style="color: #999; cursor: not-allowed;" title="Meilenstein ist gesperrt - Bearbeitung nicht m\00F6glich">'),
'                <span class="fa fa-lock" style="margin-right: 5px;"></span>',
'                <span aria-hidden="true" class="fa fa-pencil-square"></span> '' || emano_util.fLang(''Eingabe Suchparameter'', ''Enter SearchParameters'') || '' ',
'            </span>''',
'        ELSE',
'            ''<a href="'' || apex_page.get_url(p_page => 455, p_items => ''P455_SUCHEID,P455_MEILENSTEIN'', p_values => :P52_SUCHEID||'',2'', p_clear_cache => 455) ||',
'            ''"><span aria-hidden="true" class="fa fa-pencil-square"></span> '' || emano_util.fLang(''Eingabe Suchparameter'', ''Enter SearchParameters'') || '' </a>''',
'    END as CARD_SUBTEXT,',
'    ',
'    CASE ',
'        WHEN EXISTS (',
'            SELECT 1 FROM t_suche_json t2, ',
'            json_table (t2.suchdaten, ''$[*]'' columns (',
'                meilenstein number path ''$.MEILENSTEIN'',',
'                locked number path ''$.LOCKED''',
'            )) jt2 ',
'            WHERE t2.sucheid = :P52_SUCHEID ',
'            AND jt2.meilenstein = 2 ',
'            AND NVL(jt2.locked, 0) = 1',
'        ) THEN',
'            ''<div class="milestone-locked">',
'                <span class="fa fa-lock"></span> Meilenstein 2 (Gesperrt)',
'                <div style="margin-top: 8px;">',
'                    <label>',
'                        <input type="checkbox" checked onchange="toggleMilestoneLock(2, false)"> ',
'                        Meilenstein Schreibschutz',
'                    </label>',
'                </div>',
'            </div>''',
'        ELSE',
'            ''<div>',
'                Meilenstein 2',
'                <div style="margin-top: 8px;">',
'                    <label>',
'                        <input type="checkbox" onchange="toggleMilestoneLock(2, true)"> ',
'                        Meilenstein Schreibschutz',
'                    </label>',
'                </div>',
'            </div>''',
'    END as CARD_TITLE,',
'    ',
'    case when not exists (select  t.meilenstein',
'           from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN''',
'            ))) t where sucheid = :P52_SUCHEID and  t.meilenstein = 2 ) then ''<table> <tr><td>''|| emano_util.fLang(''Noch keine Suchparameter eingestellt'', ''No search parameters set yet'') || ''</td></tr></table>'' ',
'      else',
'      (',
'          select''<table>'' ||',
'                NVL2(t.ms, ''<tr><td>'' || emano_util.fLang(''Datum Meilenstein:'', ''Milestone Date:'') || ''</td><td>'' || t.ms || ''</td></tr>'', NULL)',
'                || NVL2(t.sop, ''<tr><td>'' ',
'                             || PCK_RI_SUCHE.fGetBezeichnungStartdatumTyp(t.laender) || '':</td><td>'' || t.sop || ''</td></tr>'', NULL)',
'                || NVL2(t.eop, ''<tr><td>'' || emano_util.fLang(''Datum EOP:'', ''EOP Date:'') || ''</td><td>'' || t.eop  || ''</td></tr>'', NULL)',
unistr('                || NVL2(t.laender, ''<tr><td>'' || emano_util.fLang(''Relevante L\00E4nder:'', ''Relevant Countries:'') || ''</td><td>'' || TO_CHAR(REGEXP_COUNT(t.laender, '':'')+1) || ''</td></tr>'', NULL)'),
'                || NVL2(t.themen, ''<tr><td>'' || emano_util.fLang(''Relevante Themen:'', ''Relevant Topics:'') || ''</td><td>'' || TO_CHAR(COUNT(DISTINCT x.column_value)) || ''</td></tr>'', NULL)',
'                || CASE WHEN t.laender IS NULL OR t.themen IS NULL THEN ''<tr><td>'' || emano_util.fLang(''Noch keine Suchparameter eingestellt'', ''No search parameters set yet'') || ''</td></tr>'' ELSE NULL END',
'                || ''</table>''',
'                    tab_e  ',
'         from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN'',',
'                laender varchar2(2000) PATH ''$.LAENDER'',',
'                themen varchar2(2000) path ''$.THEMEN'',',
'                ms varchar2(20) path ''$.DATUM_MEILENSTEIN'',',
'                sop varchar2(20) path ''$.DATUM_SOP'',',
'                eop varchar2(20) path ''$.DATUM_EOP''',
'                ))) t ,',
'          table ( select apex_string.split_numbers(t.themen, '':'') from dual) x,     ',
'          v_thema_baum vt  ',
'            where vt.Themaid = x.column_value  and sucheid = :P52_SUCHEID and t.meilenstein =2 and leaf=1   ',
'           group by  t.meilenstein , t.ms, t.sop, t.eop, t.laender, t.themen',
'     ) end AS CARD_TEXT',
'    from T_suche_json where sucheid = :P52_SUCHEID ',
'',
'UNION ',
'',
'-- Meilenstein 3',
'SELECT ',
'    3 as sort_order,',
'    CASE ',
'        WHEN EXISTS (',
'            SELECT 1 FROM t_suche_json t2, ',
'            json_table (t2.suchdaten, ''$[*]'' columns (',
'                meilenstein number path ''$.MEILENSTEIN'',',
'                locked number path ''$.LOCKED''',
'            )) jt2 ',
'            WHERE t2.sucheid = :P52_SUCHEID ',
'            AND jt2.meilenstein = 3 ',
'            AND NVL(jt2.locked, 0) = 1',
'        ) THEN',
unistr('            ''<span style="color: #999; cursor: not-allowed;" title="Meilenstein ist gesperrt - Bearbeitung nicht m\00F6glich">'),
'                <span class="fa fa-lock" style="margin-right: 5px;"></span>',
'                <span aria-hidden="true" class="fa fa-pencil-square"></span> '' || emano_util.fLang(''Eingabe Suchparameter'', ''Input Search Parameters'') || '' ',
'            </span>''',
'        ELSE',
'            ''<a href="'' || apex_page.get_url(p_page => 455, p_items => ''P455_SUCHEID,P455_MEILENSTEIN'', p_values => :P52_SUCHEID||'',3'', p_clear_cache => 455) ||',
'            ''"><span aria-hidden="true" class="fa fa-pencil-square"></span> '' || emano_util.fLang(''Eingabe Suchparameter'', ''Input Search Parameters'') || ''</a>''',
'    END AS CARD_SUBTEXT,',
'    ',
'    CASE ',
'        WHEN EXISTS (',
'            SELECT 1 FROM t_suche_json t2, ',
'            json_table (t2.suchdaten, ''$[*]'' columns (',
'                meilenstein number path ''$.MEILENSTEIN'',',
'                locked number path ''$.LOCKED''',
'            )) jt2 ',
'            WHERE t2.sucheid = :P52_SUCHEID ',
'            AND jt2.meilenstein = 3 ',
'            AND NVL(jt2.locked, 0) = 1',
'        ) THEN',
'            ''<div class="milestone-locked">',
'                <span class="fa fa-lock"></span> Meilenstein 3 (Gesperrt)',
'            </div>''',
'        ELSE',
'            ''<div>',
'                Meilenstein 3',
'            </div>''',
'    END as CARD_TITLE,',
'    ',
'    case when not exists (select  t.meilenstein',
'           from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN''',
'            ))) t where sucheid = :P52_SUCHEID and  t.meilenstein = 3 ) then ''<table> <tr><td>'' || emano_util.fLang(''Noch keine Suchparameter eingestellt'', ''No search parameters set yet'') || ''</td></tr></table>''',
'',
'     else',
'     (',
'          select     ''<table>'' ||',
'                nvl2( t.ms, ''<tr><td>'' || emano_util.fLang(''Datum Meilenstein:'', ''Milestone Date:'') || ''</td><td>'' || t.ms || ''</td></tr>'', null)',
'                || nvl2( t.sop, ''<tr><td>'' || emano_util.fLang(PCK_RI_SUCHE.fGetBezeichnungStartdatumTyp(t.laender), PCK_RI_SUCHE.fGetBezeichnungStartdatumTyp(t.laender)) || '':</td><td>'' || t.sop || ''</td></tr>'', null)',
'                || nvl2(t.eop, ''<tr><td>'' || emano_util.fLang(''Datum EOP:'', ''EOP Date:'') || ''</td><td>'' || t.eop || ''</td></tr>'', null)',
unistr('                || nvl2( t.laender, ''<tr><td>'' || emano_util.fLang(''Relevante L\00E4nder:'', ''Relevant Countries:'') || ''</td><td>'' || to_char(regexp_count(t.laender, '':'')+1) || ''</td></tr>'', null)'),
'                || nvl2( t.themen, ''<tr><td>'' || emano_util.fLang(''Relevante Themen:'', ''Relevant Topics:'') || ''</td><td>'' || to_char(count(distinct x.column_value)) || ''</td></tr>'', null)',
'                || case when  t.laender is null or t.themen is null then ''<tr><td>'' || emano_util.fLang(''Noch keine Suchparameter eingestellt'', ''No search parameters set yet'') || ''</td></tr>'' else null end',
'                || ''</table>''',
'             tab_e  ',
'         from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN'',',
'                laender varchar2(2000) PATH ''$.LAENDER'',',
'                themen varchar2(2000) path ''$.THEMEN'',',
'                ms varchar2(20) path ''$.DATUM_MEILENSTEIN'',',
'                sop varchar2(20) path ''$.DATUM_SOP'',',
'                eop varchar2(20) path ''$.DATUM_EOP''',
'                ))) t,',
'          table ( select apex_string.split_numbers(t.themen, '':'') from dual) x,     ',
'          v_thema_baum vt  ',
'            where vt.Themaid = x.column_value  and sucheid = :P52_SUCHEID and t.meilenstein =3 and leaf=1   ',
'           group by  t.meilenstein , t.ms, t.sop, t.eop, t.laender, t.themen  ',
'    ) end AS CARD_TEXT',
'   from T_suche_json where sucheid = :P52_SUCHEID',
'',
'ORDER BY sort_order'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414129911996820551)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913649336289022886)
,p_query_column_id=>1
,p_column_alias=>'SORT_ORDER'
,p_column_display_sequence=>13
,p_column_heading=>'Sort Order'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913648957537022885)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>1
,p_column_heading=>'Card Subtext'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913648590891022884)
,p_query_column_id=>3
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>2
,p_column_heading=>'Card Title'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913648153886022884)
,p_query_column_id=>4
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>3
,p_column_heading=>'Card Text'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9901841765209892806)
,p_plug_name=>'Ergebnis 1'
,p_parent_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(5005417050041504050)
,p_name=>'ergebnis1 23 jul'
,p_parent_plug_id=>wwv_flow_imp.id(9901841765209892806)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'select distinct ',
'                -- nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) Vorschriftnummer,',
'                CASE ',
'                    WHEN p_alt.ANZEIGE_MIT_DOKUMENTENDATUM = 20 ',
'                         AND tv.DOKUMENTENDATUM IS NOT NULL ',
'                    THEN tv.vorschrift_nummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'                    ELSE nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) ',
'                END as Vorschriftnummer,',
'                nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) as vorschriftid , ',
'                 regelnummer as Regel,',
'                  Risiko,',
'                   tmat.ausgabe_text einsatz_erlaeuterung, ',
'                -- nvl(tmb.bild_nummer,0) bild_nummer',
'                (select nvl(tmb.bild_nummer,0) from T_MS_BILD tmb where tmb.MS_BILDID=tmrb.MS_BILDID   ',
'                   and tmb.FILENAME is not null) bild_nummer, ',
'             row_number() over (partition by nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) order by nvl(tmat.KRITIKALITAET,0) ) as xrow,',
'             l.COCKPIT_ERW_ANZEIGE,',
'             nvl(einsatzdatum,v.dokumentendatum) Einsatzdatum',
'  from t_MS_SUCHERGEBNISS tms',
'  left outer join t_ms_parameter tmp on (tms.regelnummer = tmp.nummer)',
'  left outer join t_ms_parameter_ref_ausgabe tmpra on (tmp.MS_PARAMETERID = tmpra.MS_PARAMETERID)',
' ',
'  left outer join t_ms_ausgabe_text tmat on (tmpra.MS_AUSGABE_TEXTID = tmat.MS_AUSGABE_TEXTID)',
'  left outer join t_vorschrift tv on (tms.ALTERNATIVE_VORSCHRIFTID = tv.vorschriftid)',
'  left outer join t_publisher p_alt on (tv.publisherid = p_alt.publisherid)',
'  left outer join T_MS_PARAMETER_REF_BILD tmrb on tmrb.MS_PARAMETERID=tmp.MS_PARAMETERID',
'  left outer join T_MS_BILD tmb on tmb.MS_BILDID=tmrb.MS_BILDID',
'  left outer join T_VORSCHRIFT_REF_EINSATZDATUM_TYP ref on (ref.VORSCHRIFTID = tms.VORSCHRIFTID and ref.EINSATZDATUM_TYPID = 1000)',
'  left outer join T_LAND l on l.landid = tms.LANDID',
'  left outer join T_VORSCHRIFT v on v.VORSCHRIFTID = tms.VORSCHRIFTID',
'  where sucheid =:P52_SUCHEID and meilenstein =1 and AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE= 1',
' )',
'select  VORSCHRIFTNUMMER || case when max(COCKPIT_ERW_ANZEIGE) = 1 then ( '', '' || max(einsatzdatum)) else '''' end as VORSCHRIFTNUMMER, ',
'         vorschriftid , ',
'         -- Regel,',
'          Risiko,',
'        einsatz_erlaeuterung, ',
'listagg(case when bild_nummer !=0 or bild_nummer is not null then ''<a href="'' ||apex_page.get_url(p_page => 702, p_clear_cache => ''702,RP'', ',
'                  p_items =>''P702_REGEL_NUMMER'', p_values => Regel)|| ',
'    ''" target="_blank"> <span >''||to_char(Regel)||''</span></a>''|| ''<a href="'' ||apex_page.get_url(p_page => 2010, p_clear_cache => ''2010,RP'', ',
'                  p_items =>''P2010_BILD_NUMMER'', p_values => bild_nummer)|| ',
'    ''"> <span class="fa fa-camera" aria-hidden="true"></span></a>'' else ',
'   ''<a href="'' ||apex_page.get_url(p_page => 702, p_clear_cache => ''702,RP'', ',
'                  p_items =>''P702_REGEL_NUMMER'', p_values => Regel)|| ',
'    ''" target="_blank"> <span >''||to_char(Regel)||''</span></a>''  end, '', '') within group (order by bild_nummer) Regel',
'from cte1',
'where xrow =1',
'  group by VORSCHRIFTNUMMER, ',
'        vorschriftid, ',
'        Regel,',
'        Risiko,',
'        einsatz_erlaeuterung;'))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
' --select BILD_1 from T_MS_bild where BILD_NUMMER=:P2010_BILD_NUMMER',
'--t_ms_bild -> t_ms_parameter_ref_bild -> t_ms_paramete'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913647122226022881)
,p_query_column_id=>1
,p_column_alias=>'VORSCHRIFTNUMMER'
,p_column_display_sequence=>40
,p_column_heading=>'Vorschriftnummer'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_column_linktext=>'#VORSCHRIFTNUMMER#'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913646786791022880)
,p_query_column_id=>2
,p_column_alias=>'VORSCHRIFTID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913646388178022880)
,p_query_column_id=>3
,p_column_alias=>'RISIKO'
,p_column_display_sequence=>30
,p_column_heading=>'Risiko'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(958143412491459185)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913645957715022879)
,p_query_column_id=>4
,p_column_alias=>'EINSATZ_ERLAEUTERUNG'
,p_column_display_sequence=>50
,p_column_heading=>unistr('Einsatz Erl\00E4uterung')
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913645610392022879)
,p_query_column_id=>5
,p_column_alias=>'REGEL'
,p_column_display_sequence=>20
,p_column_heading=>'Regel'
,p_column_link=>'f?p=&APP_ID.:702:&SESSION.::&DEBUG.::P702_REGEL_NUMMER:#REGEL#'
,p_column_linktext=>'#REGEL#'
,p_column_link_attr=>'target="_blank"'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(9887541090981834805)
,p_name=>'ergebnis1'
,p_parent_plug_id=>wwv_flow_imp.id(9901841765209892806)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'select distinct ',
'                -- nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) Vorschriftnummer,',
'                -- CASE ',
'                --     WHEN p_alt.ANZEIGE_MIT_DOKUMENTENDATUM = 20  AND tv.DOKUMENTENDATUM IS NOT NULL ',
'                --         THEN tv.vorschrift_nummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'                --     ELSE nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) ',
'                -- END as Vorschriftnummer,',
'',
'                CASE ',
'            WHEN p_main.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND v.DOKUMENTENDATUM IS NOT NULL ',
'            THEN v.vorschrift_nummer || ''_'' || TO_CHAR(v.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'            ELSE tms.Vorschriftnummer',
'        END AS Vorschriftnummer,',
'',
'        ',
'                nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) as vorschriftid , ',
'                 regelnummer as Regel,',
'                  Risiko,',
'                   tmat.ausgabe_text einsatz_erlaeuterung, ',
'                -- nvl(tmb.bild_nummer,0) bild_nummer',
'                (select nvl(tmb.bild_nummer,0) from T_MS_BILD tmb where tmb.MS_BILDID=tmrb.MS_BILDID   ',
'                   and tmb.FILENAME is not null) bild_nummer, ',
'             row_number() over (partition by nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) order by nvl(tmat.KRITIKALITAET,0) ) as xrow,',
'             l.COCKPIT_ERW_ANZEIGE,',
'             nvl(einsatzdatum,v.dokumentendatum) Einsatzdatum',
'  from t_MS_SUCHERGEBNISS tms',
'  left outer join t_ms_parameter tmp on (tms.regelnummer = tmp.nummer)',
'  left outer join t_ms_parameter_ref_ausgabe tmpra on (tmp.MS_PARAMETERID = tmpra.MS_PARAMETERID)',
' ',
'  left outer join t_ms_ausgabe_text tmat on (tmpra.MS_AUSGABE_TEXTID = tmat.MS_AUSGABE_TEXTID)',
'  left outer join t_vorschrift tv on (tms.ALTERNATIVE_VORSCHRIFTID = tv.vorschriftid)',
'  left outer join t_publisher p_alt on (tv.publisherid = p_alt.publisherid)',
'  left outer join T_MS_PARAMETER_REF_BILD tmrb on tmrb.MS_PARAMETERID=tmp.MS_PARAMETERID',
'  left outer join T_MS_BILD tmb on tmb.MS_BILDID=tmrb.MS_BILDID',
'  left outer join T_VORSCHRIFT_REF_EINSATZDATUM_TYP ref on (ref.VORSCHRIFTID = tms.VORSCHRIFTID and ref.EINSATZDATUM_TYPID = 1000)',
'  left outer join T_LAND l on l.landid = tms.LANDID',
'  left outer join T_VORSCHRIFT v on v.VORSCHRIFTID = tms.VORSCHRIFTID',
'',
'  LEFT JOIN T_PUBLISHER p_main ON (v.PUBLISHERID = p_main.PUBLISHERID)',
'',
'',
'  where sucheid =:P52_SUCHEID and meilenstein =1 and AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE= 1',
' )',
'select  ',
'-- VORSCHRIFTNUMMER || case when max(COCKPIT_ERW_ANZEIGE) = 1 then ( '', '' || max(einsatzdatum)) else '''' end as VORSCHRIFTNUMMER, ',
'VORSCHRIFTNUMMER,',
'',
'         vorschriftid , ',
'         -- Regel,',
'          Risiko,',
'        einsatz_erlaeuterung, ',
'listagg(case when bild_nummer !=0 or bild_nummer is not null then ''<a href="'' ||apex_page.get_url(p_page => 702, p_clear_cache => ''702,RP'', ',
'                  p_items =>''P702_REGEL_NUMMER'', p_values => Regel)|| ',
'    ''" target="_blank"> <span >''||to_char(Regel)||''</span></a>''|| ''<a href="'' ||apex_page.get_url(p_page => 2010, p_clear_cache => ''2010,RP'', ',
'                  p_items =>''P2010_BILD_NUMMER'', p_values => bild_nummer)|| ',
'    ''"> <span class="fa fa-camera" aria-hidden="true"></span></a>'' else ',
'   ''<a href="'' ||apex_page.get_url(p_page => 702, p_clear_cache => ''702,RP'', ',
'                  p_items =>''P702_REGEL_NUMMER'', p_values => Regel)|| ',
'    ''" target="_blank"> <span >''||to_char(Regel)||''</span></a>''  end, '', '') within group (order by bild_nummer) Regel',
'from cte1',
'where xrow =1',
'  group by VORSCHRIFTNUMMER, ',
'        vorschriftid, ',
'        Regel,',
'        Risiko,',
'        einsatz_erlaeuterung;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
' --select BILD_1 from T_MS_bild where BILD_NUMMER=:P2010_BILD_NUMMER',
'--t_ms_bild -> t_ms_parameter_ref_bild -> t_ms_paramete'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913644894539022878)
,p_query_column_id=>1
,p_column_alias=>'VORSCHRIFTNUMMER'
,p_column_display_sequence=>4
,p_column_heading=>'Vorschriftnummer'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_column_linktext=>'#VORSCHRIFTNUMMER#'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913644498531022877)
,p_query_column_id=>2
,p_column_alias=>'VORSCHRIFTID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913644047518022877)
,p_query_column_id=>3
,p_column_alias=>'RISIKO'
,p_column_display_sequence=>3
,p_column_heading=>'Risiko'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(958143412491459185)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913643696471022877)
,p_query_column_id=>4
,p_column_alias=>'EINSATZ_ERLAEUTERUNG'
,p_column_display_sequence=>14
,p_column_heading=>unistr('Einsatz Erl\00E4uterung')
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913643254627022875)
,p_query_column_id=>5
,p_column_alias=>'REGEL'
,p_column_display_sequence=>2
,p_column_heading=>'Regel'
,p_column_link=>'f?p=&APP_ID.:702:&SESSION.::&DEBUG.::P702_REGEL_NUMMER:#REGEL#'
,p_column_linktext=>'#REGEL#'
,p_column_link_attr=>'target="_blank"'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9901842058708892809)
,p_plug_name=>'head1'
,p_parent_plug_id=>wwv_flow_imp.id(9901841765209892806)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9901842103937892810)
,p_plug_name=>'footer1'
,p_parent_plug_id=>wwv_flow_imp.id(9901841765209892806)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9901841896664892807)
,p_plug_name=>'Ergebnis 2'
,p_parent_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(9887541626539834811)
,p_name=>'Ergebnis 2'
,p_parent_plug_id=>wwv_flow_imp.id(9901841896664892807)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1_base as (',
'select distinct ',
'                -- nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) Vorschriftnummer,',
'                 CASE ',
'                    WHEN p_alt.ANZEIGE_MIT_DOKUMENTENDATUM = 20 ',
'                         AND tv.DOKUMENTENDATUM IS NOT NULL ',
'                    THEN tv.vorschrift_nummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'                    ELSE nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) ',
'                END as Vorschriftnummer,',
'                nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) as vorschriftid , ',
'                 regelnummer as Regel,',
'                  Risiko,',
'                   tmat.ausgabe_text einsatz_erlaeuterung, ',
'                -- nvl(tmb.bild_nummer,0) bild_nummer',
'                (select nvl(tmb.bild_nummer,0) from T_MS_BILD tmb where tmb.MS_BILDID=tmrb.MS_BILDID   ',
'                   and tmb.FILENAME is not null) bild_nummer, ',
'                row_number() over (partition by nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) order by nvl(tmat.KRITIKALITAET,0) ) as xrow,',
'                l.COCKPIT_ERW_ANZEIGE,',
'                nvl(einsatzdatum,v.dokumentendatum) Einsatzdatum,',
'                v.VORSCHRIFT_NUMMER,',
'                v.DOKUMENTENDATUM,',
'                p.ANZEIGE_MIT_DOKUMENTENDATUM',
'  from t_MS_SUCHERGEBNISS tms',
'  left outer join t_ms_parameter tmp on (tms.regelnummer = tmp.nummer)',
'  left outer join t_ms_parameter_ref_ausgabe tmpra on (tmp.MS_PARAMETERID = tmpra.MS_PARAMETERID)',
'  left outer join t_ms_ausgabe_text tmat on (tmpra.MS_AUSGABE_TEXTID = tmat.MS_AUSGABE_TEXTID)',
'  left outer join t_vorschrift tv on (tms.ALTERNATIVE_VORSCHRIFTID = tv.vorschriftid)',
'  left outer join t_publisher p_alt on (tv.publisherid = p_alt.publisherid)',
'  left outer join T_MS_PARAMETER_REF_BILD tmrb on tmrb.MS_PARAMETERID=tmp.MS_PARAMETERID',
'  left outer join T_MS_BILD tmb on tmb.MS_BILDID=tmrb.MS_BILDID',
'  left outer join T_VORSCHRIFT_REF_EINSATZDATUM_TYP ref on (ref.VORSCHRIFTID = tms.VORSCHRIFTID and ref.EINSATZDATUM_TYPID = 1000)',
'  left outer join T_LAND l on l.landid = tms.LANDID',
'  left outer join T_VORSCHRIFT v on v.VORSCHRIFTID = tms.VORSCHRIFTID',
'  left outer join T_PUBLISHER p on v.PUBLISHERID = p.PUBLISHERID',
'  where sucheid = :P52_SUCHEID and meilenstein = 1 and :P52_VIEW_DELTA2 = 1 and AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE= 1),',
'',
'cte1 as (select  case when max(ANZEIGE_MIT_DOKUMENTENDATUM) = 20 AND max(DOKUMENTENDATUM) IS NOT NULL',
'     then max(VORSCHRIFT_NUMMER) || ''_'' || TO_CHAR(max(DOKUMENTENDATUM), ''DD.MM.YYYY'')',
'     else max(VORSCHRIFT_NUMMER) ',
'end as VORSCHRIFTNUMMER, ',
'         vorschriftid , ',
'          Risiko,',
'        einsatz_erlaeuterung, ',
'listagg(case when bild_nummer !=0 or bild_nummer is not null then ''<a href="'' ||apex_page.get_url(p_page => 702, p_clear_cache => ''702,RP'', ',
'                  p_items =>''P702_REGEL_NUMMER'', p_values => regel)|| ',
'    ''" target="_blank"> <span >''||to_char(Regel)||''</span></a>''||''<a href="'' ||apex_page.get_url(p_page => 2010, p_clear_cache => ''2010,RP'', ',
'                  p_items =>''P2010_BILD_NUMMER'', p_values => bild_nummer)|| ',
'    ''"> <span class="fa fa-camera" aria-hidden="true"></span></a>'' else ',
'   ''<a href="'' ||apex_page.get_url(p_page => 702, p_clear_cache => ''702,RP'', ',
'                  p_items =>''P702_REGEL_NUMMER'', p_values => regel)|| ',
'    ''" target="_blank"> <span >''||to_char(Regel)||''</span></a>''  end, '', '') within group (order by bild_nummer) Regel',
'from cte1_base',
'where xrow = 1',
'  group by vorschriftid, Risiko, einsatz_erlaeuterung',
'), cte2_base as (',
'select distinct ',
'                -- nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) Vorschriftnummer, ',
'                CASE ',
'                    WHEN p_alt.ANZEIGE_MIT_DOKUMENTENDATUM = 20 ',
'                         AND tv.DOKUMENTENDATUM IS NOT NULL ',
'                    THEN tv.vorschrift_nummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'                    ELSE nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) ',
'                END as Vorschriftnummer,',
'                nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) as vorschriftid , ',
'                regelnummer as Regel,',
'                Risiko,',
'                tmat.ausgabe_text einsatz_erlaeuterung, ',
'                (select nvl(tmb.bild_nummer,0) from T_MS_BILD tmb where tmb.MS_BILDID=tmrb.MS_BILDID   ',
'                    and tmb.FILENAME is not null) as bild_nummer,',
'                tmat.KRITIKALITAET,',
'                row_number() over (partition by nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) order by nvl(tmat.KRITIKALITAET,0) ) as xrow,',
'                l.COCKPIT_ERW_ANZEIGE,',
'                nvl(einsatzdatum,v.dokumentendatum) Einsatzdatum,',
'                v.VORSCHRIFT_NUMMER,',
'                v.DOKUMENTENDATUM,',
'                p.ANZEIGE_MIT_DOKUMENTENDATUM',
'  from t_MS_SUCHERGEBNISS tms',
'  left outer join t_ms_parameter tmp on (tms.regelnummer = tmp.nummer)',
'  left outer join t_ms_parameter_ref_ausgabe tmpra on (tmp.MS_PARAMETERID = tmpra.MS_PARAMETERID)',
'  left outer join t_ms_ausgabe_text tmat on (tmpra.MS_AUSGABE_TEXTID = tmat.MS_AUSGABE_TEXTID)',
'  left outer join t_vorschrift tv on (tms.ALTERNATIVE_VORSCHRIFTID = tv.vorschriftid)',
'  left outer join t_publisher p_alt on (tv.publisherid = p_alt.publisherid)',
'  left outer join T_MS_PARAMETER_REF_BILD tmrb on tmrb.MS_PARAMETERID=tmp.MS_PARAMETERID',
'  left outer join T_MS_BILD tmb on tmb.MS_BILDID=tmrb.MS_BILDID',
'  left outer join T_VORSCHRIFT_REF_EINSATZDATUM_TYP ref on (ref.VORSCHRIFTID = tms.VORSCHRIFTID and ref.EINSATZDATUM_TYPID = 1000)',
'  left outer join T_LAND l on l.landid = tms.LANDID',
'  left outer join T_VORSCHRIFT v on v.VORSCHRIFTID = tms.VORSCHRIFTID',
'  left outer join T_PUBLISHER p on v.PUBLISHERID = p.PUBLISHERID',
' where sucheid = :P52_SUCHEID and meilenstein  =2 and AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE= 1',
'), cta2_kardinal as (',
'Select * from cte2_base where xrow = 1',
'),',
'Cte2 as (select  case when max(ANZEIGE_MIT_DOKUMENTENDATUM) = 20 AND max(DOKUMENTENDATUM) IS NOT NULL',
'     then max(VORSCHRIFT_NUMMER) || ''_'' || TO_CHAR(max(DOKUMENTENDATUM), ''DD.MM.YYYY'')',
'     else max(VORSCHRIFT_NUMMER) ',
'end as VORSCHRIFTNUMMER,',
'         vorschriftid , ',
'          Risiko,',
'        einsatz_erlaeuterung, ',
'listagg(case when bild_nummer !=0 or bild_nummer is not null then ''<a href="'' ||apex_page.get_url(p_page => 702, p_clear_cache => ''702,RP'', ',
'                  p_items =>''P702_REGEL_NUMMER'', p_values => regel)|| ',
'    ''" target="_blank"> <span >''||to_char(Regel)||''</span></a>''||''<a href="'' ||apex_page.get_url(p_page => 2010, p_clear_cache => ''2010,RP'', ',
'                  p_items =>''P2010_BILD_NUMMER'', p_values => bild_nummer)|| ',
'    ''"> <span class="fa fa-camera" aria-hidden="true"></span></a>'' else ',
'   ''<a href="'' ||apex_page.get_url(p_page => 702, p_clear_cache => ''702,RP'', ',
'                  p_items =>''P702_REGEL_NUMMER'', p_values => regel)|| ',
'    ''" target="_blank"> <span >''||to_char(Regel)||''</span></a>''  end, '', '') within group (order by bild_nummer) Regel',
'from cta2_kardinal',
'  group by vorschriftid, Risiko, einsatz_erlaeuterung',
')',
'Select case when (t1.vorschriftnummer is null and :P52_VIEW_DELTA2 = 1) then ''<span style="color:green">'' || tv.Vorschriftnummer ||''</span> ''  ',
'       when (tv.Vorschriftnummer is null and :P52_VIEW_DELTA2 = 1) then ''<span style="color:orange">'' || t1.Vorschriftnummer ||''</span> '' ',
'        else nvl(t1.vorschriftnummer,tv.Vorschriftnummer) end as vorschriftnummer, ',
'    case when t1.vorschriftnummer is null then ''Neu'' when tv.Vorschriftnummer is null then ''entfallen'' else ''wegen Projektverschiebung'' end  as Delta,',
'    nvl(tv.vorschriftid, t1.vorschriftid) as vorschriftid, ',
'     tv.regel   as regel ,',
'     nvl(tv.Risiko,t1.Risiko) Risiko, tv.einsatz_erlaeuterung',
'from cte2 tv',
'full outer join cte1 t1 on (tv.vorschriftnummer = t1.vorschriftnummer)',
'where :P52_VIEW_DELTA2 = 0 or (:P52_VIEW_DELTA2 = 1 and (( t1.vorschriftnummer is null or tv.Vorschriftnummer is null)',
'                                                           or (t1.regel is null or tv.regel is null or tv.regel != t1.regel))',
')'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'Es wurden keine Daten gefunden'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913638818217022870)
,p_query_column_id=>1
,p_column_alias=>'VORSCHRIFTNUMMER'
,p_column_display_sequence=>5
,p_column_heading=>'Vorschriftnummer'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_column_linktext=>'#VORSCHRIFTNUMMER#'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913638478885022870)
,p_query_column_id=>2
,p_column_alias=>'DELTA'
,p_column_display_sequence=>1
,p_column_heading=>'Delta'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P52_VIEW_DELTA2'
,p_display_when_condition2=>'1'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913638068991022869)
,p_query_column_id=>3
,p_column_alias=>'VORSCHRIFTID'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913637660739022868)
,p_query_column_id=>4
,p_column_alias=>'REGEL'
,p_column_display_sequence=>3
,p_column_heading=>'Regel'
,p_column_link=>'f?p=&APP_ID.:702:&SESSION.::&DEBUG.::P702_REGEL_NUMMER:#REGEL#'
,p_column_linktext=>'#REGEL#'
,p_column_link_attr=>'target="_blank"'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913637232892022868)
,p_query_column_id=>5
,p_column_alias=>'RISIKO'
,p_column_display_sequence=>4
,p_column_heading=>'Risiko'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(958143412491459185)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913636846361022867)
,p_query_column_id=>6
,p_column_alias=>'EINSATZ_ERLAEUTERUNG'
,p_column_display_sequence=>15
,p_column_heading=>unistr('Einsatz Erl\00E4uterung')
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9901842295891892811)
,p_plug_name=>'head2'
,p_parent_plug_id=>wwv_flow_imp.id(9901841896664892807)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9901842438742892813)
,p_plug_name=>'footer2'
,p_parent_plug_id=>wwv_flow_imp.id(9901841896664892807)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9901841925132892808)
,p_plug_name=>'Ergebnis 3'
,p_parent_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(9887542276696834817)
,p_name=>'Ergebnis 3'
,p_parent_plug_id=>wwv_flow_imp.id(9901841925132892808)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1_base as ',
'(',
'    select distinct ',
'                    -- nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) Vorschriftnummer, ',
'                    -- CASE ',
'                    --     WHEN p_alt.ANZEIGE_MIT_DOKUMENTENDATUM = 20 ',
'                    --          AND tv.DOKUMENTENDATUM IS NOT NULL ',
'                    --     THEN tv.vorschrift_nummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'                    --     ELSE nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) ',
'                    -- END as Vorschriftnummer,',
'',
'                        CASE',
'            WHEN p_main.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND v.DOKUMENTENDATUM IS NOT NULL',
'            THEN v.vorschrift_nummer || ''_'' || TO_CHAR(v.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'            ELSE tms.Vorschriftnummer',
'        END AS Vorschriftnummer,',
'',
'',
'                    nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) as vorschriftid , ',
'                    regelnummer as Regel,',
'                    Risiko,',
'                    tmat.ausgabe_text einsatz_erlaeuterung, ',
'                    -- nvl(tmb.bild_nummer,0) bild_nummer',
'                    (select nvl(tmb.bild_nummer,0) from T_MS_BILD tmb where tmb.MS_BILDID=tmrb.MS_BILDID   ',
'                       and tmb.FILENAME is not null) bild_nummer, ',
'                    row_number() over (partition by nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) order by nvl(tmat.KRITIKALITAET,0) ) as xrow,',
'                    l.COCKPIT_ERW_ANZEIGE,',
'                    nvl(einsatzdatum,v.dokumentendatum) Einsatzdatum',
'    from t_MS_SUCHERGEBNISS tms',
'    left outer join t_ms_parameter tmp on (tms.regelnummer = tmp.nummer)',
'    left outer join t_ms_parameter_ref_ausgabe tmpra on (tmp.MS_PARAMETERID = tmpra.MS_PARAMETERID)',
'    left outer join t_ms_ausgabe_text tmat on (tmpra.MS_AUSGABE_TEXTID = tmat.MS_AUSGABE_TEXTID)',
'    left outer join t_vorschrift tv on (tms.ALTERNATIVE_VORSCHRIFTID = tv.vorschriftid)',
'    left outer join t_publisher p_alt on (tv.publisherid = p_alt.publisherid)',
'    left outer join T_MS_PARAMETER_REF_BILD tmrb on tmrb.MS_PARAMETERID=tmp.MS_PARAMETERID',
'    left outer join T_MS_BILD tmb on tmb.MS_BILDID=tmrb.MS_BILDID',
'    left outer join T_VORSCHRIFT_REF_EINSATZDATUM_TYP ref on (ref.VORSCHRIFTID = tms.VORSCHRIFTID and ref.EINSATZDATUM_TYPID = 1000)',
'    left outer join T_LAND l on l.landid = tms.LANDID',
'    left outer join T_VORSCHRIFT v on v.VORSCHRIFTID = tms.VORSCHRIFTID',
'',
'    LEFT JOIN T_PUBLISHER p_main ON (v.PUBLISHERID = p_main.PUBLISHERID)',
'',
'    where sucheid = :P52_SUCHEID and meilenstein = 2 and :P52_VIEW_DELTA3 = 1 and AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE= 1',
'),',
'cte1 as (',
'    select ',
'    -- Vorschriftnummer || case when max(COCKPIT_ERW_ANZEIGE) = 1 then ( '', '' || max(einsatzdatum)) else '''' end as VORSCHRIFTNUMMER, ',
'    Vorschriftnummer,',
'         vorschriftid , ',
'        -- Regel,',
'        Risiko,',
'        einsatz_erlaeuterung, ',
'        listagg(case when bild_nummer !=0 or bild_nummer is not null then ''<a href="'' ||apex_page.get_url(p_page => 702, p_clear_cache => ''702,RP'', ',
'                      p_items =>''P702_REGEL_NUMMER'', p_values => regel)|| ',
'        ''" target="_blank"> <span >''||to_char(Regel)||''</span></a>''||''<a href="'' ||apex_page.get_url(p_page => 2010, p_clear_cache => ''2010,RP'', ',
'                      p_items =>''P2010_BILD_NUMMER'', p_values => bild_nummer)|| ',
'        ''"> <span class="fa fa-camera" aria-hidden="true"></span></a>'' else ',
'        ''<a href="'' ||apex_page.get_url(p_page => 702, p_clear_cache => ''702,RP'', ',
'                      p_items =>''P702_REGEL_NUMMER'', p_values => regel)|| ',
'        ''" target="_blank"> <span >''||to_char(Regel)||''</span></a>''  end, '', '') within group (order by bild_nummer) as Regel',
'    from cte1_base',
'    where xrow = 1',
'    group by Vorschriftnummer, ',
'        vorschriftid , ',
'        Regel,',
'        Risiko,',
'        einsatz_erlaeuterung',
'), ',
'cte2_base as (',
'    select distinct ',
'    ',
'                -- nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) Vorschriftnummer,',
'                CASE',
'               WHEN p_main.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND v.DOKUMENTENDATUM IS NOT NULL',
'               THEN v.vorschrift_nummer || ''_'' || TO_CHAR(v.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'               ELSE tms.Vorschriftnummer',
'           END AS Vorschriftnummer,',
'',
'                nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) as vorschriftid , ',
'                regelnummer as Regel,',
'                Risiko,',
'                tmat.ausgabe_text einsatz_erlaeuterung, ',
'                -- nvl(tmb.bild_nummer,0) bild_nummer',
'                (select nvl(tmb.bild_nummer,0) from T_MS_BILD tmb where tmb.MS_BILDID=tmrb.MS_BILDID   ',
'                   and tmb.FILENAME is not null) bild_nummer,',
'                tmat.KRITIKALITAET,',
'                row_number() over (partition by nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) order by nvl(tmat.KRITIKALITAET,0) ) as xrow,',
'                l.COCKPIT_ERW_ANZEIGE,',
'                nvl(einsatzdatum,v.dokumentendatum) Einsatzdatum      ',
'    from t_MS_SUCHERGEBNISS tms',
'    left outer join t_ms_parameter tmp on (tms.regelnummer = tmp.nummer)',
'    left outer join t_ms_parameter_ref_ausgabe tmpra on (tmp.MS_PARAMETERID = tmpra.MS_PARAMETERID)',
'    left outer join t_ms_ausgabe_text tmat on (tmpra.MS_AUSGABE_TEXTID = tmat.MS_AUSGABE_TEXTID)',
'    left outer join t_vorschrift tv on (tms.ALTERNATIVE_VORSCHRIFTID = tv.vorschriftid)',
'    left outer join t_publisher p_alt on (tv.publisherid = p_alt.publisherid)',
'    left outer join T_MS_PARAMETER_REF_BILD tmrb on tmrb.MS_PARAMETERID=tmp.MS_PARAMETERID',
'    left outer join T_MS_BILD tmb on tmb.MS_BILDID=tmrb.MS_BILDID',
'    left outer join T_VORSCHRIFT_REF_EINSATZDATUM_TYP ref on (ref.VORSCHRIFTID = tms.VORSCHRIFTID and ref.EINSATZDATUM_TYPID = 1000)',
'    left outer join T_LAND l on l.landid = tms.LANDID',
'    left outer join T_VORSCHRIFT v on v.VORSCHRIFTID = tms.VORSCHRIFTID',
'    LEFT JOIN T_PUBLISHER p_main ON (v.PUBLISHERID = p_main.PUBLISHERID)',
'    where sucheid = :P52_SUCHEID and meilenstein  =3 and AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE= 1',
'), ',
'cta2_kardinal as (',
'    Select * from cte2_base where xrow = 1',
'),',
'Cte2 as (',
'    select  ',
'    ',
'    -- Vorschriftnummer || case when max(COCKPIT_ERW_ANZEIGE) = 1 then ( '', '' || max(einsatzdatum)) else '''' end as VORSCHRIFTNUMMER, ',
'    Vorschriftnummer,',
'        vorschriftid , ',
'        -- Regel,',
'        Risiko,',
'        einsatz_erlaeuterung, ',
'        listagg(case when bild_nummer !=0 or bild_nummer is not null then ''<a href="'' ||apex_page.get_url(p_page => 702, p_clear_cache => ''702,RP'', ',
'                  p_items =>''P702_REGEL_NUMMER'', p_values => regel)|| ',
'        ''" target="_blank"> <span >''||to_char(Regel)||''</span></a>''||''<a href="'' ||apex_page.get_url(p_page => 2010, p_clear_cache => ''2010,RP'', ',
'                      p_items =>''P2010_BILD_NUMMER'', p_values => bild_nummer)|| ',
'        ''"> <span class="fa fa-camera" aria-hidden="true"></span></a>'' else ',
'       ''<a href="'' ||apex_page.get_url(p_page => 702, p_clear_cache => ''702,RP'', ',
'                      p_items =>''P702_REGEL_NUMMER'', p_values => regel)|| ',
'        ''" target="_blank"> <span >''||to_char(Regel)||''</span></a>''  end, '', '') within group (order by bild_nummer) as Regel',
'    from cta2_kardinal',
'    group by Vorschriftnummer, ',
'        vorschriftid , ',
'        Regel,',
'        Risiko,',
'        einsatz_erlaeuterung',
')',
'Select case when (t1.vorschriftnummer is null and :P52_VIEW_DELTA3 = 1) then ''<span style="color:green">'' || tv.Vorschriftnummer ||''</span> ''  ',
'            when (tv.Vorschriftnummer is null and :P52_VIEW_DELTA3 = 1) then ''<span style="color:orange">'' || t1.Vorschriftnummer ||''</span> '' ',
'            else nvl(t1.vorschriftnummer,tv.Vorschriftnummer) end as vorschriftnummer, ',
'        case when t1.vorschriftnummer is null then ''Neu'' when tv.Vorschriftnummer is null then ''entfallen'' else ''wegen Projektverschiebung'' end  as Delta,',
'        nvl(tv.vorschriftid, t1.vorschriftid) as vorschriftid, ',
'        tv.regel as regel ,',
'        nvl(tv.Risiko,t1.Risiko) Risiko, tv.einsatz_erlaeuterung',
'from cte2 tv',
'full outer join cte1 t1 on (tv.vorschriftnummer = t1.vorschriftnummer)',
'where :P52_VIEW_DELTA3 = 0 or (:P52_VIEW_DELTA3 = 1 and (( t1.vorschriftnummer is null or tv.Vorschriftnummer is null)',
'                                                           or (t1.regel is null or tv.regel is null or tv.regel != t1.regel))',
')'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'Es wurden keine Daten gefunden'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- report 3',
'',
'',
'with cte1 as (select distinct nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) Vorschriftnummer, nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) as vorschriftid , ',
' regelnummer as Regel, Risiko, tmat.ausgabe_text einsatz_erlaeuterung',
'  from t_MS_SUCHERGEBNISS tms',
'  left outer join t_ms_parameter tmp on (tms.regelnummer = tmp.nummer)',
'  left outer join t_ms_parameter_ref_ausgabe tmpra on (tmp.MS_PARAMETERID = tmpra.MS_PARAMETERID)',
'  left outer join t_ms_ausgabe_text tmat on (tmpra.MS_AUSGABE_TEXTID = tmat.MS_AUSGABE_TEXTID)',
'  left outer join t_vorschrift tv on (tms.ALTERNATIVE_VORSCHRIFTID = tv.vorschriftid)',
'  where sucheid = :P450_SUCHEID and meilenstein = 2 and :P450_VIEW_DELTA3 = 1 ',
'), ',
'Cte2 as ( select distinct nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) Vorschriftnummer, nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) as vorschriftid , ',
' regelnummer as Regel, Risiko, tmat.ausgabe_text einsatz_erlaeuterung',
'  from t_MS_SUCHERGEBNISS tms',
'  left outer join t_ms_parameter tmp on (tms.regelnummer = tmp.nummer)',
'  left outer join t_ms_parameter_ref_ausgabe tmpra on (tmp.MS_PARAMETERID = tmpra.MS_PARAMETERID)',
'  left outer join t_ms_ausgabe_text tmat on (tmpra.MS_AUSGABE_TEXTID = tmat.MS_AUSGABE_TEXTID)',
'  left outer join t_vorschrift tv on (tms.ALTERNATIVE_VORSCHRIFTID = tv.vorschriftid)',
'  where sucheid = :P450_SUCHEID and meilenstein  =3 ',
')',
'',
'Select case when (t1.vorschriftnummer is null and :P450_VIEW_DELTA3 = 1) then ''<span style="color:green">'' || tv.Vorschriftnummer ||''</span> ''  ',
'       when (tv.Vorschriftnummer is null and :P450_VIEW_DELTA3 = 1) then ''<span style="color:orange">'' || t1.Vorschriftnummer ||''</span> '' ',
'        else nvl(t1.vorschriftnummer,tv.Vorschriftnummer) end as vorschriftnummer, ',
'    case when t1.vorschriftnummer is null then ''Neu'' when tv.Vorschriftnummer is null then ''entfallen'' else ''wegen Projektverschiebung'' end  as Delta,',
'    nvl(tv.vorschriftid, t1.vorschriftid) as vorschriftid, ',
'     tv.regel   as regel ,',
'     nvl(tv.Risiko,t1.Risiko) Risiko, tv.einsatz_erlaeuterung',
'from cte2 tv',
'full outer join cte1 t1 on (tv.vorschriftnummer = t1.vorschriftnummer)',
'where :P450_VIEW_DELTA3 = 0 or (:P450_VIEW_DELTA2 = 1 and (( t1.vorschriftnummer is null or tv.Vorschriftnummer is null)',
'                                                           or (t1.regel is null or tv.regel is null or tv.regel != t1.regel))',
'                                )',
'',
'',
''))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913632844905022862)
,p_query_column_id=>1
,p_column_alias=>'VORSCHRIFTNUMMER'
,p_column_display_sequence=>5
,p_column_heading=>'Vorschriftnummer'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_column_linktext=>'#VORSCHRIFTNUMMER#'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913632456890022860)
,p_query_column_id=>2
,p_column_alias=>'DELTA'
,p_column_display_sequence=>1
,p_column_heading=>'Delta'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P52_VIEW_DELTA3'
,p_display_when_condition2=>'1'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913632037434022860)
,p_query_column_id=>3
,p_column_alias=>'VORSCHRIFTID'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913631711365022859)
,p_query_column_id=>4
,p_column_alias=>'REGEL'
,p_column_display_sequence=>3
,p_column_heading=>'Regel'
,p_column_link=>'f?p=&APP_ID.:702:&SESSION.::&DEBUG.::P702_REGEL_NUMMER:#REGEL#'
,p_column_linktext=>'#REGEL#'
,p_column_link_attr=>'target="_blank"'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913631234417022859)
,p_query_column_id=>5
,p_column_alias=>'RISIKO'
,p_column_display_sequence=>4
,p_column_heading=>'Risiko'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(958143412491459185)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(913630823332022859)
,p_query_column_id=>6
,p_column_alias=>'EINSATZ_ERLAEUTERUNG'
,p_column_display_sequence=>15
,p_column_heading=>unistr('Einsatz Erl\00E4uterung')
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9901842319745892812)
,p_plug_name=>'head3'
,p_parent_plug_id=>wwv_flow_imp.id(9901841925132892808)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9901842694226892815)
,p_plug_name=>'footer3'
,p_parent_plug_id=>wwv_flow_imp.id(9901841925132892808)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913657571111022918)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_button_name=>'BTN_SUCHE'
,p_button_static_id=>'BTN_SUCHE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Suchen'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':P52_SUCHEID >1 and :P52_BEZEICHNUNG is not null'
,p_button_condition2=>'SQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'Y'
,p_grid_column_span=>1
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913629430847022857)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(9901842694226892815)
,p_button_name=>'CSV3'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Download'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-download'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913635471450022865)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(9901842438742892813)
,p_button_name=>'CSV2'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Download'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-download'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913641482331022873)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(9901842103937892810)
,p_button_name=>'CSV1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Download'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-download'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913657150079022914)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_button_name=>'BTN_PARAM_UEBERNEHMEN2'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Suchparameter \00FCbernehmen')
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  t.meilenstein',
'           from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN''',
'            ))) t where sucheid = :P52_SUCHEID and  t.meilenstein = 1'))
,p_button_condition_type=>'EXISTS'
,p_grid_new_row=>'N'
,p_grid_column_span=>2
,p_grid_column=>5
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913656797453022913)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_button_name=>'BTN_PARAM_UEBERNEHMEN3'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Suchparameter \00FCbernehmen')
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  t.meilenstein',
'           from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN''',
'            ))) t where sucheid = :P52_SUCHEID and  t.meilenstein = 2'))
,p_button_condition_type=>'EXISTS'
,p_grid_new_row=>'N'
,p_grid_column_span=>2
,p_grid_column=>9
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913656389045022913)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_button_name=>'SUCHMASKEN_LEEREN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Parameter leeren'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:52:&SESSION.::&DEBUG.::P52_SUCHEID:1'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913655916375022912)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_button_name=>'COPY_SUCHE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Suche an anderen Anwender weitergeben'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:457:&SESSION.::&DEBUG.:RP,457:P457_SUCHEID,P457_REASSIGN_USER:&P52_SUCHEID.,true'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913655554126022911)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_button_name=>'MERGE_SUCHE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Suche zusammenf\00FChren')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:452:&SESSION.::&DEBUG.:RP,457::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913655160809022911)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_button_name=>'LOAD_SUCHE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Historische Suchen laden/verwalten'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:456:&SESSION.::&DEBUG.:RP,::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913654719122022910)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_button_name=>'SAVE_SUCHE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Suche Speichern'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:459:&SESSION.::&DEBUG.:RP,459:P459_SUCHEID:&P52_SUCHEID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913641035777022873)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9901842103937892810)
,p_button_name=>'SUCHE_ANZEIGEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Detail Analyse View ET-B'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:601:&SESSION.::&DEBUG.:601:P601_SUCHEID,P601_MEILENSTEIN:&P52_SUCHEID.,1'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913635112745022865)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9901842438742892813)
,p_button_name=>'SUCHE_ANZEIGEN_2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Detail Analyse View ET-B'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:601:&SESSION.::&DEBUG.:601:P601_SUCHEID,P601_MEILENSTEIN:&P52_SUCHEID.,2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913629039740022857)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9901842694226892815)
,p_button_name=>'SUCHE_ANZEIGEN_3'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Detail Analyse View ET-B'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:601:&SESSION.::&DEBUG.:601:P601_SUCHEID,P601_MEILENSTEIN:&P52_SUCHEID.,3'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913640644044022873)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(9901842103937892810)
,p_button_name=>'Suche_SHORT1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Detail View FB'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:451:&SESSION.::&DEBUG.:451:P451_DELTA,P451_MS,P451_SUCHEID:0,1,&P52_SUCHEID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913634695399022865)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(9901842438742892813)
,p_button_name=>'Suche_SHORT2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Detail View FB'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:451:&SESSION.::&DEBUG.:451:P451_DELTA,P451_MS,P451_SUCHEID:&P52_VIEW_DELTA2.,2,&P52_SUCHEID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913628713759022856)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(9901842694226892815)
,p_button_name=>'Suche_SHORT3'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Detail View FB'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:451:&SESSION.::&DEBUG.:451:P451_DELTA,P451_MS,P451_SUCHEID:&P52_VIEW_DELTA3.,3,&P52_SUCHEID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913628281148022856)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(9901842694226892815)
,p_button_name=>'BTN_ADD_REGULATION_M3'
,p_button_static_id=>'BTN_ADD_REGULATION_M3'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Vorschrift hinzuf\00FCgen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:465:&SESSION.::&DEBUG.:52:P465_MODE,P465_SEARCH_SELECTION,P465_MILESTONE_SELECTION,P465_RETURN_PAGE:CREATE,&P52_SUCHEID.,3,450'
,p_icon_css_classes=>'fa-gears'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913641852248022874)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(9901842103937892810)
,p_button_name=>'BTN_ADD_REGULATION_M1'
,p_button_static_id=>'BTN_ADD_REGULATION_M1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Vorschrift hinzuf\00FCgen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:465:&SESSION.::&DEBUG.:465:P465_MODE,P465_SEARCH_SELECTION,P465_MILESTONE_SELECTION,P465_RETURN_PAGE,P465_LANDIDS:CREATE,&P52_SUCHEID.,1,450,&P52_LANDIDS.'
,p_icon_css_classes=>'fa-gears'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(913634228138022864)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(9901842438742892813)
,p_button_name=>'BTN_ADD_REGULATION_M2'
,p_button_static_id=>'BTN_ADD_REGULATION_M2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Vorschrift hinzuf\00FCgen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:465:&SESSION.::&DEBUG.:52:P465_MODE,P465_SEARCH_SELECTION,P465_MILESTONE_SELECTION,P465_RETURN_PAGE:CREATE,&P52_SUCHEID.,2,450'
,p_icon_css_classes=>'fa-gears'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(913608558883022785)
,p_branch_name=>'Branch_DOWNLOAD1'
,p_branch_action=>'f?p=&APP_ID.:0:&SESSION.:APPLICATION_PROCESS=downloadCSV:&DEBUG.:RP,:G_CSV_EXPORTTYPE,G_CSV_INDEX,G_CSV_SUCHEIDS,G_CSV_DELTAMODE:&P52_EXPORT_FORMAT1.,1,&P52_SUCHEID.,0&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(913641482331022873)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(913609369416022785)
,p_branch_name=>'Branch_Download2_new'
,p_branch_action=>'f?p=&APP_ID.:0:&SESSION.:APPLICATION_PROCESS=downloadCSV:&DEBUG.::G_CSV_DELTAMODE,G_CSV_EXPORTTYPE,G_CSV_INDEX,G_CSV_SUCHEIDS:&P52_VIEW_DELTA2.,&P52_EXPORT_FORMAT2.,2,&P52_SUCHE_TEMPIDS.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(913635471450022865)
,p_branch_sequence=>40
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(913608994632022785)
,p_branch_name=>'Branch_Download3_new'
,p_branch_action=>'f?p=&APP_ID.:0:&SESSION.:APPLICATION_PROCESS=downloadCSV:&DEBUG.::G_CSV_DELTAMODE,G_CSV_EXPORTTYPE,G_CSV_INDEX,G_CSV_SUCHEIDS:&P52_VIEW_DELTA3.,&P52_EXPORT_FORMAT3.,3,&P52_SUCHE_TEMPIDS.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(913629430847022857)
,p_branch_sequence=>50
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(913609790828022786)
,p_branch_action=>'f?p=&APP_ID.:465:&SESSION.::&DEBUG.:465:P465_MODE,P465_RETURN_PAGE,P465_SEARCH_SELECTION,P465_MILESTONE_SELECTION:CREATE,450,&P52_SUCHEID.,3'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>60
,p_branch_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(913654382231022910)
,p_name=>'P52_ERGEBNIS_STATUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when :P52_SUCHEID is null then',
'                   null',
'        when :P52_SUCHEID >1 then ',
'           ERGEBNIS_STATUS ',
'     else null end',
' from t_suche_json where sucheid= :P52_SUCHEID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(913653967582022905)
,p_name=>'P52_STATUS_BEZ'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_use_cache_before_default=>'NO'
,p_prompt=>'&nbsp;'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_SUCH_ERGEBNIS_STATUS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
unistr('        emano_util.fLang(''Suche Ausf\00FChrung geplant'', ''Search execution planned'') AS display_value,'),
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Suche nicht ausgef\00FChrt'', ''Search not executed'') AS display_value,'),
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'    ',
'    UNION ALL',
'    ',
'    SELECT ',
'        emano_util.fLang(''Suche im Hintergrund ..'', ''Search in the background ..'') AS display_value,',
'        -1 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Ergebnisse geladen'', ''Results loaded'') AS display_value,',
'        10 AS actual_value,',
'        4 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_grid_column=>2
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_protection_level=>'P'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(913653534882022903)
,p_name=>'P52_BEZEICHNUNG'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_use_cache_before_default=>'NO'
,p_prompt=>'New'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :P52_SUCHEID IS NULL THEN',
'            emano_util.fLang(''Keine Suche geladen'', ''No search loaded'')',
'        WHEN :P52_SUCHEID > 1 THEN ',
'            ''<div class="search-info-enhanced">'' ||',
'               ',
'                ''<div class="search-meta">'' ||',
'                    ''<span class="user-info">'' ||',
'                        ''<i class="fa fa-user"></i> '' ||',
'                        NVL(b.nachname || '', '' || b.vorname, ''Unknown User'') ||',
'                    ''</span>'' ||',
'                    ''<span class="search-date">'' ||',
'                        ''<i class="fa fa-calendar"></i> '' ||',
'                        TO_CHAR(sj.zeitpunkt, ''DD.MM.YYYY HH24:MI:SS'') ||',
'                    ''</span>'' ||',
'                    ''<span class="search-id">'' ||',
'                        ''<i class="fa fa-tag"></i> '' ||',
'                        ''Suche ID: '' || sj.sucheid ||',
'                    ''</span>'' ||',
'                ''</div>'' ||',
'            ''</div>''',
'        ELSE ',
'            emano_util.fLang(''Keine Suche geladen'', ''No search loaded'') ',
'    END AS result_value',
'FROM t_suche_json sj',
'LEFT JOIN t_benutzer b ON sj.benutzerid = b.benutzerid',
'WHERE sj.sucheid = :P52_SUCHEID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_grid_column=>3
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:margin-left-sm:margin-right-sm'
,p_protection_level=>'P'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'N')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :P52_SUCHEID IS NULL THEN',
'            emano_util.fLang(''Keine Suche geladen'', ''No search loaded'')',
'        WHEN :P52_SUCHEID > 1 THEN ',
'            ''<div class="search-info-enhanced">'' ||',
'                ''<div class="search-title">'' || ',
'                    -- Clean search name (remove user_ prefix and timestamp)',
'                    CASE ',
'                        WHEN sj.bezeichnung LIKE ''user_%'' THEN',
'                            REGEXP_REPLACE(sj.bezeichnung, ''^user_[^,]+,\s*[^0-9]*[0-9]{2}\.[0-9]{2}\.[0-9]{4}\s*[0-9]{2}:[0-9]{2}:[0-9]{2}.*$'', ''My Search'')',
'                        ELSE ',
'                            NVL(sj.bezeichnung, ''Unnamed Search'')',
'                    END ||',
'                ''</div>'' ||',
'                ''<div class="search-meta">'' ||',
'                    ''<span class="user-info">'' ||',
'                        ''<i class="fa fa-user"></i> '' ||',
'                        COALESCE(b.nachname || '', '' || b.vorname, ''Unknown User'') ||',
'                    ''</span>'' ||',
'                    ''<span class="search-date">'' ||',
'                        ''<i class="fa fa-calendar"></i> '' ||',
'                        TO_CHAR(sj.zeitpunkt, ''DD.MM.YYYY HH24:MI:SS'') ||',
'                    ''</span>'' ||',
'                    ''<span class="search-id">'' ||',
'                        ''<i class="fa fa-tag"></i> '' ||',
'                        ''Suche ID: '' || sj.sucheid ||',
'                    ''</span>'' ||',
'                ''</div>'' ||',
'            ''</div>''',
'        ELSE ',
'            emano_util.fLang(''Keine Suche geladen'', ''No search loaded'') ',
'    END AS result_value',
'FROM t_suche_json sj',
'LEFT JOIN t_benutzer b ON sj.benutzerid = b.benutzerid',
'WHERE sj.sucheid = :P52_SUCHEID;'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(913653146145022901)
,p_name=>'P52_BEZEICHNUNG_1'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when :P52_SUCHEID is null then',
'            emano_util.fLang(''Keine Suche geladen'', ''No search loaded'')',
'        when :P52_SUCHEID >1 then ',
'           bezeichnung || '', Suche ID: '' || sucheid',
'     else emano_util.fLang(''Keine Suche geladen'', ''No search loaded'') end result_value',
' from t_suche_json where sucheid= :P52_SUCHEID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_grid_column=>3
,p_grid_label_column_span=>0
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:margin-left-sm:margin-right-sm'
,p_protection_level=>'P'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(913652785698022900)
,p_name=>'P52_SUCHEID'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(913652397349022899)
,p_name=>'P52_TIMER_STARTED'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(913651917251022899)
,p_name=>'P52_HIDDEN_REFRESH_ITEM'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(913651528687022898)
,p_name=>'P52_LANDIDS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(9887302192210321086)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT LISTAGG(DISTINCT ms.LANDID, '';'') WITHIN GROUP (ORDER BY ms.LANDID)',
'FROM T_MS_SUCHERGEBNISS ms  ',
'WHERE ms.SUCHEID = :P52_SUCHEID',
'AND ms.MEILENSTEIN IN (1, 2, 3)'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(913642566451022875)
,p_name=>'P52_PLACEHOLDER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9901842058708892809)
,p_prompt=>'&nbsp;'
,p_source=>'&nbsp;'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="visibility:hidden;"'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(913640292367022873)
,p_name=>'P52_EXPORT_FORMAT1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9901842103937892810)
,p_prompt=>'Export Format'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
unistr('        emano_util.fLang(''Export f\00FCr Baureihe'', ''Export for Series'') AS display_value, '),
'        1 AS actual_value,',
'        1 AS sort_order ',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Export f\00FCr Themengebiete'', ''Export for Topic areas'') AS display_value,'),
'        2 AS actual_value,',
'        2 AS sort_order  ',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Export f\00FCr Vorschriften'', ''Export for Regulations'') AS display_value,'),
'        3 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(913639913578022872)
,p_name=>'P52_DETAILS_1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(9901842103937892810)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(913636209119022866)
,p_name=>'P52_VIEW_DELTA2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9901842295891892811)
,p_item_default=>'0'
,p_prompt=>'New'
,p_source=>'0'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Alle Ergebnisse'', ''All Results'') AS display_value, ',
'        0 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Delta'', ''Delta'') AS display_value,',
'        1 AS actual_value,',
'        2 AS sort_order ',
'    FROM dual',
'',
') ',
'ORDER BY sort_order;',
''))
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(913633883503022864)
,p_name=>'P52_EXPORT_FORMAT2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9901842438742892813)
,p_prompt=>'Export Format'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
unistr('        emano_util.fLang(''Export f\00FCr Baureihe'', ''Export for Series'') AS display_value, '),
'        1 AS actual_value,',
unistr('        1 AS sort_order -- This ensures ''Export f\00FCr Baureihe''/''Export for Series'''' is the default selection'),
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Export f\00FCr Themengebiete'', ''Export for Topic areas'') AS display_value,'),
'        2 AS actual_value,',
'        2 AS sort_order  ',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Export f\00FCr Vorschriften'', ''Export for Regulations'') AS display_value,'),
'        3 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(913630214301022858)
,p_name=>'P52_VIEW_DELTA3'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9901842319745892812)
,p_item_default=>'0'
,p_prompt=>'New'
,p_source=>'0'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Alle Ergebnisse'', ''All Results'') AS display_value, ',
'        0 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Delta'', ''Delta'') AS display_value,',
'        1 AS actual_value,',
'        2 AS sort_order ',
'    FROM dual',
'',
') ',
'ORDER BY sort_order;',
''))
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(913627913997022856)
,p_name=>'P52_EXPORT_FORMAT3'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9901842694226892815)
,p_prompt=>'Export Format'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
unistr('        emano_util.fLang(''Export f\00FCr Baureihe'', ''Export for Series'') AS display_value, '),
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Export f\00FCr Themengebiete'', ''Export for Topic areas'') AS display_value,'),
'        2 AS actual_value,',
'        2 AS sort_order  ',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Export f\00FCr Vorschriften'', ''Export for Regulations'') AS display_value,'),
'        3 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(913627367942022816)
,p_validation_name=>'VALIDATE_SOP_1'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    lMeilenstein number := 1;',
'    lResult date;',
'begin',
'    select meilenst_dat into lResult',
'    from (',
'        select  row_number() over( order by t.meilenstein) rn, t.ms meilenst_dat ',
'            from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'                nested path ''$[*]'' COLUMNS(',
'                         ms varchar2(20) path ''$.DATUM_MEILENSTEIN'',',
'                         meilenstein number path ''$.MEILENSTEIN''',
'            ))) t where sucheid = :P52_SUCHEID ',
'    )',
'    where rn = lMeilenstein;',
'    EXCEPTION',
'    when no_data_found then ',
'     null;',
'    return lResult is not null;',
'    ',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('Bitte setzen Sie zun\00E4chst das Datum SOP/ME in Meilenstein 1.')
,p_when_button_pressed=>wwv_flow_imp.id(913657571111022918)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(913625482741022807)
,p_name=>'Parameter Bearbeiten - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(9887302476333321089)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913624979057022801)
,p_event_id=>wwv_flow_imp.id(913625482741022807)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9887302476333321089)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(913624592335022800)
,p_name=>'Suche Speichern - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(9887302476333321089)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913624079808022800)
,p_event_id=>wwv_flow_imp.id(913624592335022800)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P52_SUCHEID'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(913623631152022799)
,p_name=>'ACTION_UEBERNEHMEN2'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(913657150079022914)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913622672997022798)
,p_event_id=>wwv_flow_imp.id(913623631152022799)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    pck_ri_suche.pCopyMSSuchparameter(:P52_SUCHEID, 1);    --   1- source meilenstein',
'end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913622124002022798)
,p_event_id=>wwv_flow_imp.id(913623631152022799)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913623123449022799)
,p_event_id=>wwv_flow_imp.id(913623631152022799)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9887302476333321089)
,p_attribute_01=>'N'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(913621798075022797)
,p_name=>'ACTION_UEBERNEHMEN3'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(913656797453022913)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913620239008022796)
,p_event_id=>wwv_flow_imp.id(913621798075022797)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'   pck_ri_suche.pCopyMSSuchparameter(:P52_SUCHEID, 2);    --   2- source meilenstein',
'end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913620756712022796)
,p_event_id=>wwv_flow_imp.id(913621798075022797)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913621262457022797)
,p_event_id=>wwv_flow_imp.id(913621798075022797)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9887302476333321089)
,p_attribute_01=>'N'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(913619897614022796)
,p_name=>'Change Switch Delta2'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P52_VIEW_DELTA2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913619366834022795)
,p_event_id=>wwv_flow_imp.id(913619897614022796)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(913618971496022795)
,p_name=>'Change switch delta 3'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P52_VIEW_DELTA3'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913618476816022795)
,p_event_id=>wwv_flow_imp.id(913618971496022795)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(913618110124022795)
,p_name=>'Change_Delta_Detail2'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P52_VIEW_DELTA2'
,p_condition_element=>'P52_VIEW_DELTA2'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913617598657022794)
,p_event_id=>wwv_flow_imp.id(913618110124022795)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P52_DETAILS_2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913617080351022794)
,p_event_id=>wwv_flow_imp.id(913618110124022795)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P52_DETAILS_2'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(913616702819022794)
,p_name=>'Change_Delta_Detail3'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P52_VIEW_DELTA3'
,p_condition_element=>'P52_VIEW_DELTA3'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913616197817022793)
,p_event_id=>wwv_flow_imp.id(913616702819022794)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P52_DETAILS_2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913615675219022793)
,p_event_id=>wwv_flow_imp.id(913616702819022794)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P52_DETAILS_2'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(913615280516022793)
,p_name=>'MS Suche Bearbeiten - Dialog closed'
,p_event_sequence=>100
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(9887302192210321086)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913614777810022792)
,p_event_id=>wwv_flow_imp.id(913615280516022793)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9887302192210321086)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(913614355070022792)
,p_name=>'Refresh_results'
,p_event_sequence=>120
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913613858507022792)
,p_event_id=>wwv_flow_imp.id(913614355070022792)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//',
'if($v(''P52_SUCHEID'') >1){',
'      refreshPage();',
'  }'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(913613460427022792)
,p_name=>'change refresh item'
,p_event_sequence=>130
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913613011642022791)
,p_event_id=>wwv_flow_imp.id(913613460427022792)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if($v(''P52_SUCHEID'') >1){',
'    setInterval( ()=> { $s(''P52_HIDDEN_REFRESH_ITEM'', ''refresh'') }, 4000 );',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(913612575564022791)
,p_name=>'get Ergebnis status'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P52_HIDDEN_REFRESH_ITEM'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913612108425022791)
,p_event_id=>wwv_flow_imp.id(913612575564022791)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  select ergebnis_status, ',
'  case when ergebnis_status= 10 then ',
'           emano_util.fLang(''Ergebnis geladen'', ''Result loaded'') ',
'           when ergebnis_status =1 then ',
'           emano_util.fLang(''Suche wird vorbereitet'', ''Search is being prepared'') ',
'           when  ergebnis_status =-1 then ',
'           emano_util.fLang(''Suche im Hintergrund..'', ''Search in the background..'')',
'           when ergebnis_status = 0 then ',
unistr('           emano_util.fLang(''keine Suche ausgef\00FChrt'', ''No search executed'')'),
'     else null end status',
'  into :P52_ERGEBNIS_STATUS, :P52_STATUS_BEZ ',
'  ',
'    FROM T_SUCHE_JSON',
'   WHERE SUCHEID = :P52_SUCHEID;',
''))
,p_attribute_02=>'P52_SUCHEID'
,p_attribute_03=>'P52_ERGEBNIS_STATUS,P52_STATUS_BEZ'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(913611629521022790)
,p_name=>'Enable/Disable Add Regulation'
,p_event_sequence=>150
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913611118456022790)
,p_event_id=>wwv_flow_imp.id(913611629521022790)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Function to wrap button with tooltip',
'function setButtonTooltip(buttonId, message, isEnabled) {',
'    var button = $(''#'' + buttonId);',
'    // console.log(''Setting tooltip for'', buttonId, ''message:'', message, ''enabled:'', isEnabled);',
'    ',
'    if (isEnabled) {',
'        button.prop(''disabled'', false).removeClass(''apex_disabled'');',
'       ',
'        if (button.parent(''.tooltip-wrapper'').length) {',
'            button.unwrap();',
'        }',
'        button.attr(''title'', message);',
'    } else {',
'        button.prop(''disabled'', true).addClass(''apex_disabled'');',
'        // Create wrapper div with tooltip',
'        if (!button.parent(''.tooltip-wrapper'').length) {',
'            button.wrap(''<div class="tooltip-wrapper" title="'' + message + ''"></div>'');',
'        } else {',
'            button.parent(''.tooltip-wrapper'').attr(''title'', message);',
'        }',
'        button.removeAttr(''title'');',
'    }',
'}',
'',
'// Check Milestone 1',
'apex.server.process(''CHECK_MILESTONE_EXISTS'', {',
'    x01: $v(''P52_SUCHEID''),',
'    x02: ''1''',
'}, {',
'    success: function(data) {',
'        // console.log(''Milestone 1 check result:'', data);',
'        setButtonTooltip(''BTN_ADD_REGULATION_M1'', ',
unistr('            data.exists ? ''Vorschrift f\00FCr Meilenstein 1 hinzuf\00FCgen'' : ''Keine Suchparameter f\00FCr diesen Meilenstein'','),
'            data.exists);',
'    }',
'});',
'',
'// Check Milestone 2  ',
'apex.server.process(''CHECK_MILESTONE_EXISTS'', {',
'    x01: $v(''P52_SUCHEID''),',
'    x02: ''2''',
'}, {',
'    success: function(data) {',
'        // console.log(''Milestone 2 check result:'', data);',
'        setButtonTooltip(''BTN_ADD_REGULATION_M2'',',
unistr('            data.exists ? ''Vorschrift f\00FCr Meilenstein 2 hinzuf\00FCgen'' : ''Keine Suchparameter f\00FCr diesen Meilenstein'', '),
'            data.exists);',
'    }',
'});',
'',
'// Check Milestone 3',
'apex.server.process(''CHECK_MILESTONE_EXISTS'', {',
'    x01: $v(''P52_SUCHEID''),',
'    x02: ''3''',
'}, {',
'    success: function(data) {',
'        // console.log(''Milestone 3 check result:'', data);',
'        setButtonTooltip(''BTN_ADD_REGULATION_M3'',',
unistr('            data.exists ? ''Vorschrift f\00FCr Meilenstein 3 hinzuf\00FCgen'' : ''Keine Suchparameter f\00FCr diesen Meilenstein'','),
'            data.exists);',
'    }',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(913610771013022789)
,p_name=>'Dialog Closed - Page 465'
,p_event_sequence=>160
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'body'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId == ''465'''
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(913610241915022789)
,p_event_id=>wwv_flow_imp.id(913610771013022789)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(913625829232022812)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Suche Ausf\00FChren')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_suche_JSON set ERGEBNIS_STATUS = 1 where sucheid = :P52_SUCHEID;',
'commit;',
'  dbms_scheduler.run_job(job_name=>''J_SUCHE_AUSFUEREN'', use_current_session =>false);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(913657571111022918)
,p_process_when=>'P52_SUCHEID'
,p_process_when_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_internal_uid=>2758586486667365423
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(913626234356022812)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Historische Suche laden'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' declare',
'    l_co number :=0;',
' begin',
'    :P52_BEZEICHNUNG :='''';',
'    if (:P52_SUCHEID is not null) then',
'       select count(*) into l_co from t_suche_json where sucheid = :P52_SUCHEID ;',
'        if  (l_co >0) then',
'            select  Bezeichnung  into :P52_BEZEICHNUNG from t_suche_json where sucheid=:P52_SUCHEID;',
'        else',
'            :P52_SUCHEID :=1;',
'        end if;',
unistr('      -- debug(''Suche ausgew\00E4hlt: id=''|| :P52_SUCHEID);'),
'    else',
'         :P52_SUCHEID :=1;',
'    end if;',
' end;',
'    ',
'    ',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2758586081543365423
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(913627104343022815)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CHECK_MILESTONE_EXISTS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_search_id NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_milestone NUMBER := TO_NUMBER(apex_application.g_x02);',
'    l_count NUMBER := 0;',
'BEGIN',
'    SELECT COUNT(*)',
'    INTO l_count',
'    FROM t_suche_json t, ',
'         json_table (t.suchdaten, ''$[*]'' columns (',
'             nested path ''$[*]'' COLUMNS( ',
'                 meilenstein number path ''$.MEILENSTEIN''',
'             )',
'         )) t ',
'    WHERE sucheid = l_search_id ',
'    AND t.meilenstein = l_milestone;',
'    ',
'    apex_json.open_object;',
'    apex_json.write(''exists'', CASE WHEN l_count > 0 THEN true ELSE false END);',
'    apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2758585211556365420
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(913626643261022813)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'TOGGLE_MILESTONE_LOCK'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_sucheid       NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_milestone     NUMBER := TO_NUMBER(apex_application.g_x02); ',
'    l_locked_value  NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_json_clob     CLOB;',
'    l_milestone_count PLS_INTEGER;',
'BEGIN',
'    -- Get current JSON data',
'    SELECT suchdaten INTO l_json_clob ',
'    FROM t_suche_json ',
'    WHERE sucheid = l_sucheid;',
'    ',
'    -- Parse existing JSON',
'    apex_json.parse(l_json_clob);',
'    apex_json.initialize_clob_output;',
'    apex_json.open_array;',
'    ',
'    -- Get number of milestones in JSON',
'    l_milestone_count := apex_json.get_count(p_path => ''.'');',
'    ',
'    -- Rebuild JSON with updated LOCKED value',
'    FOR i IN 1..l_milestone_count LOOP',
'        apex_json.open_object;',
'        ',
'        -- Copy all existing fields',
'        apex_json.write(''MEILENSTEIN'', apex_json.get_number(p_path => ''[%d].MEILENSTEIN'', p0 => i));',
'        apex_json.write(''LAENDER'', apex_json.get_varchar2(p_path => ''[%d].LAENDER'', p0 => i));',
'        apex_json.write(''THEMEN'', apex_json.get_varchar2(p_path => ''[%d].THEMEN'', p0 => i));',
'        apex_json.write(''LOW_RISK'', apex_json.get_number(p_path => ''[%d].LOW_RISK'', p0 => i));',
'        apex_json.write(''HIGH_RISK'', apex_json.get_number(p_path => ''[%d].HIGH_RISK'', p0 => i));',
'        apex_json.write(''CKD_FBU_MODE'', apex_json.get_number(p_path => ''[%d].CKD_FBU_MODE'', p0 => i));',
'        apex_json.write(''DATUM_SOP'', apex_json.get_varchar2(p_path => ''[%d].DATUM_SOP'', p0 => i));',
'        apex_json.write(''DATUM_EOP'', apex_json.get_varchar2(p_path => ''[%d].DATUM_EOP'', p0 => i));',
'        apex_json.write(''DATUM_MEILENSTEIN'', apex_json.get_varchar2(p_path => ''[%d].DATUM_MEILENSTEIN'', p0 => i));',
'        apex_json.write(''SUCHTYP'', apex_json.get_varchar2(p_path => ''[%d].SUCHTYP'', p0 => i));',
'        apex_json.write(''MJ_ANFANG'', apex_json.get_varchar2(p_path => ''[%d].MJ_ANFANG'', p0 => i));',
'        apex_json.write(''MJ_ENDE'', apex_json.get_varchar2(p_path => ''[%d].MJ_ENDE'', p0 => i));',
'        ',
'        -- Update LOCKED value for target milestone',
'        IF apex_json.get_number(p_path => ''[%d].MEILENSTEIN'', p0 => i) = l_milestone THEN',
'            apex_json.write(''LOCKED'', l_locked_value);',
'        ELSE',
'            apex_json.write(''LOCKED'', NVL(apex_json.get_number(p_path => ''[%d].LOCKED'', p0 => i), 0));',
'        END IF;',
'        ',
'        apex_json.close_object;',
'    END LOOP;',
'    ',
'    apex_json.close_array;',
'    l_json_clob := apex_json.get_clob_output;',
'    ',
'    -- Update database with new JSON',
'    UPDATE t_suche_json ',
'    SET suchdaten = l_json_clob ',
'    WHERE sucheid = l_sucheid;',
'    ',
'    COMMIT;',
'    ',
'    -- IMPORTANT: Clear previous JSON output before creating response',
'    apex_json.free_output;',
'    ',
'    -- Return success response',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
'    apex_json.write(''message'', ''Write protection updated successfully'');',
'    apex_json.close_object;',
'    ',
'    -- Output the JSON response',
'    htp.p(apex_json.get_clob_output);',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        -- Clear any existing output',
'        apex_json.free_output;',
'        -- Return error response',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;',
'        -- Output the error JSON',
'        htp.p(apex_json.get_clob_output);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2758585672638365422
);
wwv_flow_imp.component_end;
end;
/
