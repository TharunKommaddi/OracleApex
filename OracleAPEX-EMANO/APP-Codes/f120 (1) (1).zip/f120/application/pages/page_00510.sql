prompt --application/pages/page_00510
begin
--   Manifest
--     PAGE: 00510
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>510
,p_name=>'Konzern Cluster'
,p_alias=>'KONZERN-CLUSTER'
,p_step_title=>'Konzern Cluster'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(863786397231403845)
,p_plug_name=>'Report Konzern Cluster'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_laender as (',
'    select kcrl.konzern_clusterid, listagg(l.b_nummer,'', '') within group (order by l.b_nummer) liste',
'    from t_konzern_cluster_ref_land kcrl',
'    join t_land l on (kcrl.landid = l.landid)',
'    group by kcrl.konzern_clusterid',
'), cte1 as (',
'    select distinct b.benutzerid, b.nachname || '', '' || b.vorname || '' ('' || b.abteilung || '')'' as name, konzern_clusterid, rolleid',
'    from t_benutzer b',
'    join t_benutzer_ref_rolle brr on (b.benutzerid = brr.benutzerid)',
'    join t_benutzer_ref_konzern_cluster brkc on (b.benutzerid = brkc.benutzerid)',
'    where brr.rolleid in (1000,1060) -- VKO und KVKO',
')',
'select  kc.nummer,',
'kc.sammel_email,',
'kc.KONZERN_CLUSTERID,',
'       kc.BEZEICHNUNG,',
'       kc.BESCHREIBUNG,',
'       kc.LETZTE_AENDERUNG_DATUM,',
'       nvl2(kc.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) AS LETZTE_AENDERUNG_BENUTZER,',
'       l_vko.liste vko,',
'       l_kvko.liste kvko,',
'       cte_laender.liste as inaktive_laender',
'from T_KONZERN_CLUSTER kc',
'left outer join T_BENUTZER b on b.benutzerid = kc.LETZTE_AENDERUNG_BENUTZERID',
'left outer join cte_laender on (kc.konzern_clusterid = cte_laender.konzern_clusterid)',
'outer apply (',
'    select listagg(name,''; '') within group (order by name) liste',
'    from cte1',
'    where cte1.konzern_clusterid = kc.konzern_clusterid',
'    and rolleid  = 1000 -- VKO',
') l_vko',
'outer apply (',
'    select listagg(name,''; '') within group (order by name) liste',
'    from cte1',
'    where cte1.konzern_clusterid = kc.konzern_clusterid',
'    and rolleid  = 1060 -- KVKO',
') l_kvko',
'order by kc.bezeichnung asc'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Report Konzern Cluster'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(863785951336403845)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'Keine Konzern Cluster gefunden.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:515:&SESSION.::&DEBUG.:RP:P515_KONZERN_CLUSTERID:\#KONZERN_CLUSTERID#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-pencil" aria-hidden="true" title="Edit"></span></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>248906985758730559
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(863785928449403836)
,p_db_column_name=>'KONZERN_CLUSTERID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Konzern Clusterid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(863785543496403811)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(863785153373403810)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Beschreibung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(863784836449403810)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(863763628046305703)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>14
,p_column_identifier=>'F'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(848078489627850959)
,p_db_column_name=>'VKO'
,p_display_order=>24
,p_column_identifier=>'J'
,p_column_label=>'VKO'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(848078346696850958)
,p_db_column_name=>'KVKO'
,p_display_order=>34
,p_column_identifier=>'K'
,p_column_label=>'K-VKO'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(848078286269850957)
,p_db_column_name=>'NUMMER'
,p_display_order=>44
,p_column_identifier=>'L'
,p_column_label=>'Nummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(848078137395850956)
,p_db_column_name=>'SAMMEL_EMAIL'
,p_display_order=>54
,p_column_identifier=>'M'
,p_column_label=>'Sammel Email'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(848078096443850955)
,p_db_column_name=>'INAKTIVE_LAENDER'
,p_display_order=>64
,p_column_identifier=>'N'
,p_column_label=>unistr('Inaktive L\00E4nder')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(863778650721369860)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2489143'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMMER:BEZEICHNUNG:BESCHREIBUNG:SAMMEL_EMAIL:KVKO:VKO:INAKTIVE_LAENDER:LETZTE_AENDERUNG_DATUM:LETZTE_AENDERUNG_BENUTZER:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(863782312265403770)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(863786397231403845)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:515:&SESSION.::&DEBUG.:515'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(863783276093403773)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(863786397231403845)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(863782833167403771)
,p_event_id=>wwv_flow_imp.id(863783276093403773)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(863786397231403845)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
