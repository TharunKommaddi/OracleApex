prompt --application/pages/page_00251
begin
--   Manifest
--     PAGE: 00251
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>251
,p_name=>'Keywords'
,p_step_title=>'Keywords'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.a-TreeView-label'').each(function() {',
'    $(this).html($(this).text());',
'});',
'',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(644319598467513074)
,p_plug_name=>'Keywords - Baumansicht'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct schlagwortid, parentid, --stext,',
'regexp_replace(stext, ''('' || :P251_TEXTSUCHE || '')'',''<span style="background-color:yellow">\1</span>'', 1, 0, ''i'') ',
' as c_stext,',
'',
'apex_page.get_url(p_page => 255, p_items => ''P255_ROWID'', p_values => rowid) as link',
'  from t_schlagwort s',
' where :P251_TEXTSUCHE is not null',
'connect by schlagwortid = prior parentid',
'start with lower(stext) like ''%'' || lower(:P251_TEXTSUCHE) || ''%'' ',
'',
'union all',
'',
'select schlagwortid, parentid, stext as c_stext, ',
'apex_page.get_url(p_page => 255, p_items => ''P255_ROWID'', p_values => rowid) as link',
'  from t_schlagwort',
' where :P251_TEXTSUCHE is null;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_JSTREE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'activate_node_link_with', 'S',
  'default_icon_css_class', 'fa-search',
  'icon_type_css_class', 'fa',
  'link_column', 'LINK',
  'node_id_column', 'SCHLAGWORTID',
  'node_label_column', 'C_STEXT',
  'parent_key_column', 'PARENTID',
  'start_tree_with', 'NULL',
  'tree_hierarchy', 'SQL',
  'tree_tooltip', 'N')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(643999024369432833)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(644319598467513074)
,p_button_name=>'SEARCH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Suchen'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(629522421490220497)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(644319598467513074)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:255:&SESSION.::&DEBUG.:255::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(643880794352647719)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(644319598467513074)
,p_button_name=>'LISTENANSICHT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Zur Listenansicht wechseln'
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:250:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(644319194518513073)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(644319598467513074)
,p_button_name=>'CONTRACT_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Collapse All'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(644317919955513062)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(644319598467513074)
,p_button_name=>'EXPAND_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Aufklappen alle'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(643999436252438325)
,p_name=>'P251_TEXTSUCHE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(644319598467513074)
,p_prompt=>'Textsuche'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(644318788231513067)
,p_name=>'CONTRACT_ALL'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(644319194518513073)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(644318278522513063)
,p_event_id=>wwv_flow_imp.id(644318788231513067)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_COLLAPSE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(644319598467513074)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(644317463758513062)
,p_name=>'EXPAND_ALL'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(644317919955513062)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(644317017830513061)
,p_event_id=>wwv_flow_imp.id(644317463758513062)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(644319598467513074)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(644978247427140097)
,p_name=>'change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P251_TEXTSUCHE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(644978237075140096)
,p_event_id=>wwv_flow_imp.id(644978247427140097)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(643370457833880003)
,p_name=>'Dialog closed'
,p_event_sequence=>30
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window;'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(643370402605880002)
,p_event_id=>wwv_flow_imp.id(643370457833880003)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.page.submit(''REFRESH'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(619637114714229534)
,p_name=>'Expand tree'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_display_when_cond=>'P251_TEXTSUCHE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(619636687096229525)
,p_event_id=>wwv_flow_imp.id(619637114714229534)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(644319598467513074)
);
wwv_flow_imp.component_end;
end;
/
