prompt --application/pages/page_00125
begin
--   Manifest
--     PAGE: 00125
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>125
,p_name=>unistr('Normierte Eingabe bearbeiten / hinzuf\00FCgen')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Normierte Eingabe bearbeiten / hinzuf\00FCgen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'function loadLaenderShuttle() {',
'    var shuttleName = ''P125_FILTER_BLAND'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadLaenderShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P125_FILTER_LAENDERGRUPPE''),',
'          x03: $v(''P125_FILTER_BLAND_PRE''),',
'          //x04: $v(''P125_INCLUDE_INACT_BESTAND'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.ui-dialog-titlebar'').append('' <span onclick="redirect(12)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(372029966604395100)
,p_plug_name=>unistr('L\00E4nder Zuordnung')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2662235230743647339)
,p_plug_name=>'Form on T_NORM'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2662235893306647342)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1016220368894619199)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2662235893306647342)
,p_button_name=>'HILFE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Hilfe'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-lg fa-question-square-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2662236294985647343)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2662235893306647342)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2662235780948647342)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2662235893306647342)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P125_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2662235718516647342)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2662235893306647342)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P125_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2662235574376647342)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2662235893306647342)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P125_ROWID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(372015704343879452)
,p_name=>'P125_FILTER_LAENDERGRUPPE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(372029966604395100)
,p_prompt=>unistr('Vorfilter L\00E4ndergruppe')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select laendergruppe, laendergruppeid',
'from t_laendergruppe where laendergruppeid != 1220',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- alle -'
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(372015429673869017)
,p_name=>'P125_FILTER_BLAND_PRE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(372029966604395100)
,p_prompt=>unistr('Vorfilter L\00E4nder')
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" onclick="loadLaenderShuttle()"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>7
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(372015087474861731)
,p_name=>'P125_FILTER_BLAND'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(372029966604395100)
,p_prompt=>unistr('L\00E4nder')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(landid, '':'') within group (order by landid) ',
'from T_NORM_ref_LAND nrl',
'join t_NORM n on (n.NORMID = nrl.NORMID )',
'where n.NORMID = :P125_NORMID;'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b_nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'        ELSE land_eng',
'    END as d, landid',
'from t_land l',
'where (:P125_FILTER_LAENDERGRUPPE is null or landid in (select landid from t_land_ref_laendergruppe where laendergruppeid = :P125_FILTER_LAENDERGRUPPE))',
'    and status_datenstand <> 0',
'order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'')'))
,p_cHeight=>5
,p_tag_css_classes=>'margin-bottom-none padding-bottom-none'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_css_classes=>'margin-bottom-none padding-bottom-none'
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(370186248119936101)
,p_name=>'P125_NORMID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2662235230743647339)
,p_use_cache_before_default=>'NO'
,p_source=>'NORMID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2662238711016647353)
,p_name=>'P125_ROWID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2662235230743647339)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Rowid'
,p_source=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2662239144315647371)
,p_name=>'P125_BEZEICHNUNG'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2662235230743647339)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Bezeichnung'
,p_source=>'BEZEICHNUNG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>200
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2662239506478647378)
,p_name=>'P125_REGEX'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2662235230743647339)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Regex'
,p_source=>'REGEX'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>2000
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2662239913881647378)
,p_name=>'P125_BEISPIEL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2662235230743647339)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Beispiel'
,p_source=>'BEISPIEL'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>1024
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2662240310451647378)
,p_name=>'P125_BESCHREIBUNG'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2662235230743647339)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Beschreibung'
,p_source=>'BESCHREIBUNG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(2659996804395113565)
,p_validation_name=>'VALIDATE_REGEX'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lArrRegex wwv_flow_t_varchar2;',
'    lArrBeispiel wwv_flow_t_varchar2;',
'    lRegexFound number := 0;',
'',
'begin',
'    lArrRegex := apex_string.split(:P125_REGEX, apex_application.cr || ''?'' || apex_application.lf);',
'    lArrBeispiel := apex_string.split(:P125_BEISPIEL, apex_application.cr || ''?'' || apex_application.lf);',
'    for i in 1 .. lArrBeispiel.count loop',
'        lRegexFound := 0;',
'        for j in 1 .. lArrRegex.count loop',
'            if (regexp_like(lArrBeispiel(i), lArrRegex(j))) then',
'                lRegexFound := 1;',
'                exit;',
'            end if;',
'        end loop;',
'        if (lRegexFound = 0) then',
'            return ''Das Beispiel '''''' || lArrBeispiel(i) || '''''' kann nicht verifiziert werden.'';',
'        end if;',
'    end loop;',
'',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_associated_item=>wwv_flow_imp.id(2662239506478647378)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2662236404779647343)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2662236294985647343)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2662237190353647347)
,p_event_id=>wwv_flow_imp.id(2662236404779647343)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1016220242323619198)
,p_name=>'redirect Hilfe'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1016220368894619199)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1016220166781619197)
,p_event_id=>wwv_flow_imp.id(1016220242323619198)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'redirect(12);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(372029853545395099)
,p_name=>'Change Laender Filter'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P125_FILTER_LAENDERGRUPPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(372029766582395098)
,p_event_id=>wwv_flow_imp.id(372029853545395099)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(372029668010395097)
,p_name=>unistr('enter im l\00E4ndervorfilter')
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P125_FILTER_BLAND_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(372029622291395096)
,p_event_id=>wwv_flow_imp.id(372029668010395097)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(370186404686936102)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Rowid'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (:P125_ROWID is null and :P125_NORMID is not null)',
'then',
'select rowid into :P125_ROWID from T_NORM where normid = :P125_NORMID;',
'  --debug(''page 125: loadrowid'', ''rowid:''|| :P125_ROWID);',
'elsif (:P125_ROWID is not null and :P125_NORMID is  null) then',
'  --debug(''page 125: loadrowid'', ''rowid:''|| :P125_ROWID);',
'select normid into :P125_NORMID from T_NORM where  rowid= :P125_ROWID ;',
'',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3302025911212452133
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2662241118625647380)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_NORM'
,p_attribute_02=>'T_NORM'
,p_attribute_03=>'P125_ROWID'
,p_attribute_04=>'ROWID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6334453434525035615
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(370186184740936100)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Processing NORM'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'if (:REQUEST = ''CREATE'') then -- neue Vorschrift/Supplement anlegen',
'        --debug(''page 125: insert Norm'', '''');',
'        insert into t_NORM ( Regex, bezeichnung, beispiel, beschreibung',
'        )',
'        VALUES( :P125_REGEX, :P125_BEZEICHNUNG, :P125_BEISPIEL, :P125_BESCHREIBUNG',
'        ) returning rowid, normid into :P125_ROWID, :P125_NORMID;',
'        ',
'  elsif (:REQUEST = ''SAVE'') then',
'        --debug(''page 125: update Norm'', ''rowid:''|| :P125_ROWID);',
'        UPDATE t_NORM SET',
'             Regex = :P125_REGEX, ',
'             bezeichnung = :P125_BEZEICHNUNG,',
'             beispiel = :P125_BEISPIEL, ',
'            beschreibung = :P125_BESCHREIBUNG',
'        WHERE rowid = :P125_ROWID;',
'  end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE, SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_internal_uid=>3302026131158452135
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(370185892914936097)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Aktualisiere Laender'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_normid number;',
'begin',
'    l_normid := :P125_NORMID;',
'    -- neue Konzern_Cluster einfuegen',
'    merge into t_NORM_ref_LAND dest',
'    using (select l_normid as normid, column_value as landid from table(APEX_STRING.split_numbers(:P125_FILTER_BLAND, '':''))) src',
'    on (src.normid = dest.normid ',
'       and src.landid = dest.landid)',
'    when not matched then',
'    insert (normid, landid)',
'    values (src.normid, src.landid);',
'    ',
'    -- entfernte laender loeschen',
'    delete from t_norm_ref_land nrl',
'     where nrl.normid = l_normid',
'       and nrl.landid not in (select column_value from table(APEX_STRING.split_numbers(:P125_FILTER_BLAND, '':'')));',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE, SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_internal_uid=>3302026422984452138
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(370185692216936095)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'delete_NORM'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from t_norm_ref_land where normid =:P125_NORMID;',
'delete from t_NORM where rowid = :P125_ROWID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2662235780948647342)
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_internal_uid=>3302026623682452140
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2662241959487647382)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2662235780948647342)
,p_internal_uid=>6334454275387035617
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2662242285939647382)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>6334454601839035617
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(372029525697395095)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLaenderShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lLaendergruppe varchar2(2000) := apex_application.g_x02;',
'    lTextfilter varchar2(2000) := apex_application.g_x03;',
'    --include_Land_inaktDaten number := apex_application.g_x04; -- visible with switsch (ON) for VKO & FachAdm',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    for l in (',
'        select b_nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'        ELSE land_eng',
'    END as d, landid',
'        from t_land',
'        where landid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))        ',
'        and (',
'            lLaendergruppe is null',
'            or landid in (',
'                select landid from t_land_ref_laendergruppe where laendergruppeid in (',
'                    select column_value from table(apex_string.split_numbers(lLaendergruppe,'':''))',
'                )',
'            )',
'        )',
'        and (',
'            lTextfilter is null',
'            or instr(upper(b_nummer),upper(lTextFilter)) != 0',
'            or instr(upper(land),upper(lTextFilter)) != 0',
'        )',
'        and status_datenstand <> 0',
'        order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'')        ',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.landid);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'    ',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>3300182790201993140
);
wwv_flow_imp.component_end;
end;
/
