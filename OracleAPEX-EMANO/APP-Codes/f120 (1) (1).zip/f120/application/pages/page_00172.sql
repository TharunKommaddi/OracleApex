prompt --application/pages/page_00172
begin
--   Manifest
--     PAGE: 00172
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>172
,p_name=>'Demand Vorschriften mit Land'
,p_alias=>'DEMAND-VORSCHRIFTEN-MIT-LAND'
,p_step_title=>'Demand Vorschriften mit Land'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4338520730488331270)
,p_plug_name=>unistr('Liste der  Vorschriften aus Demands Verkn\00FCpfungen')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(4338521990039331282)
,p_name=>'Vorschriften'
,p_parent_plug_id=>wwv_flow_imp.id(4338520730488331270)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
unistr('        /* Alle Verkn\00FCpfungen selektieren, f\00FCr Analysezwecke mit den Vorschriftennummern'),
unistr('           Nur Vorg\00E4nger-Nachfolger-Verkn\00FCpfungen */'),
'        select v1.vorschriftid v_id, v1.vorschrift_nummer v_nr, v2.vorschriftid n_id, v2.vorschrift_nummer n_nr',
'        from t_vorschrift_ref_vorschrift vrv',
'        join t_vorschrift v1 on (vrv.vorgaenger_vorschriftid = v1.vorschriftid)',
'        join t_vorschrift v2 on (vrv.nachfolger_vorschriftid = v2.vorschriftid)',
'        where vrv.beziehung_art = 40',
unistr('   ), cte_ved as ( -- Vorschriften mit Au\00DFerkraftdatum <= sysdate ( d\00FCrfen nicht in die Kette )'),
'          select distinct vorschriftid, einsatzdatum_typid, einsatzdatum',
'          from t_vorschrift_ref_einsatzdatum_typ ',
'          where einsatzdatum_typid   in (1041, 1063, 1061)     --121',
'           and einsatzdatum <= sysdate                       --52',
'        order by Vorschriftid',
'  ), cte2 as (',
unistr('    /* Ausgehend von jeder Vorschrift rekursiv zu den Vorg\00E4ngern gehen, soweit es geht */'),
'    select  cte1.v_id, cte1.n_id, sys_connect_by_path(v_id,'':'') pfad --, level xlevel --, connect_by_root v_id as root_v_id --, connect_by_isleaf leaf',
'    from cte1 where  cte1.v_id not in (select vorschriftid from cte_ved)',
'    connect by prior n_id =  v_id',
'    START WITH  v_id =   :P25_VORSCHRIFTID  --2765 --10700 --30207 --436',
'  ) ',
'   select ',
'    vrv.nachfolger_vorschriftid   v_id',
'            , vn.vorschrift_nummer',
'   --select  listagg ( nachfolger_vorschriftid || ',
'    --    ''<a href="'' ||  apex_page.get_url(p_page => 25, p_items => '':P25_VORSCHRIFTID'', p_values => nachfolger_vorschriftid, p_clear_cache => 25) ',
'    --        || ''" target="_blank"><span class="fa fa-search"></span></a> '' , '','' on overflow truncate )  within group (order By nachfolger_vorschriftid)  list ',
'   from t_VORSCHRIFt_ref_vorschrift vrv',
'    join t_vorschrift vn on (vrv.nachfolger_vorschriftid = vn.vorschriftid)',
'   where Vorgaenger_Vorschriftid in (select cte2.v_id from cte2) ',
'   and beziehung_art = 40',
'    and nachfolger_vorschriftid in (select  vorschriftid from t_vorschrift_ref_land where landid  = :P172_LANDID and geloescht=0)'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993425159112907848)
,p_query_column_id=>1
,p_column_alias=>'V_ID'
,p_column_display_sequence=>30
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#V_ID#'
,p_column_linktext=>'<span class="fa fa-search" alt="Anzeigen" title="Anzeige Vorschrift"></span>'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993424743579907845)
,p_query_column_id=>2
,p_column_alias=>'VORSCHRIFT_NUMMER'
,p_column_display_sequence=>40
,p_column_heading=>'Vorschrift Nummer'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993426632802907856)
,p_name=>'P172_LANDID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4338520730488331270)
,p_source=>'select landid from t_land where b_nummer = :P172_B_NUMMER;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993426289106907854)
,p_name=>'P172_B_NUMMER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(4338520730488331270)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993425901456907854)
,p_name=>'P172_LAND_NAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4338520730488331270)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  :P172_B_NUMMER ||''-''|| land ',
'from t_land where B_Nummer = :P172_B_NUMMER'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
