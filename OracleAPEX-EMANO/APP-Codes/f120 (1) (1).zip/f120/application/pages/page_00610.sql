prompt --application/pages/page_00610
begin
--   Manifest
--     PAGE: 00610
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>610
,p_name=>'Benachrichtigungen'
,p_alias=>'BENACHRICHTIGUNGEN'
,p_step_title=>'Benachrichtigungen'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Hilfe Button',
'$(''#BenachrichtReg_toolbar_controls'').append('' <span onclick="redirect(541)" style="font-size:2.7em" class="fa fa-question-square-o"></span>'');'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(683260235614116555)
,p_plug_name=>'Benachrichtigungen  <span onclick="redirect(541)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'
,p_region_name=>'BenachrichtReg'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte as ( select kommentar, BENACHRICHTIGUNGID ',
'                from  t_BENACHRICHTIGUNG_KOMMENTAR k ',
'               where k.zeitpunkt=(select max(zeitpunkt) ',
'                                    from  T_BENACHRICHTIGUNG_KOMMENTAR where BENACHRICHTIGUNGID = k.BENACHRICHTIGUNGID)',
'            )',
'select ',
'    --APEX_ITEM.CHECKBOX(1,m.BENACHRICHTIGUNGID,null, :P610_SELECTED_IDS,'':'') as "select",',
'apex_item.hidden(01,m.benachrichtigungid) || apex_item.checkbox2(02,m.benachrichtigungid) check1 ',
',m.BENACHRICHTIGUNGID,',
'       m.ARBEITSKREISID,',
'       CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN a.Bezeichnung ',
'        ELSE a.name_eng',
'       END AS "ARBEITSKREIS",',
'       m.VORSCHRIFTID,',
'        v.Vorschrift_nummer "VORSCHRIFTNUMMER",',
'        nvl(m.loeschmarker,0) "LOESCHMARKER",',
'       v.VORSCHRIFT_BEZEICHNUNG "VORSCHRIFTTITEL",  ',
'        DECODE(m.STATUS, ',
'                    10, emano_util.fLang(''offen'', ''open''),',
'                    20, emano_util.fLang(''in Bearbeitung'', ''in progress''),',
'                    30, emano_util.fLang(''erledigt'', ''completed''),',
'                    emano_util.fLang(''offen'', ''open'')',
'                ) "STATUS",',
'       m.LETZTE_AENDERUNG_DATUM,',
'        round(sysdate - m.ERSTELLUNG_DATUM) "Tagen s. ERSTELLUNG",',
'        nvl(b.nachname,''-'') || '', '' || nvl(b.vorname,''-'') || '' ('' || nvl(b.abteilung,''-'') || '')'' as erstell_benutzer,',
'        m.grund,',
'        (m.erstellung_datum + 730) as loeschdatum,',
'        cte.kommentar,',
'        (select  ab.nachname || '', '' || ab.vorname from t_benutzer ab where m.bearbeiterid = ab.benutzerid) as bearbeiter,',
'         m.BETROFFENER_ANWENDER',
'from T_BENACHRICHTIGUNG m ',
'inner Join T_Vorschrift v on v.vorschriftid = m.vorschriftid',
'inner Join T_ET_B_AK a on a.et_B_AKID = m.ARBEITSKREISID',
'left outer join t_benutzer b on (b.benutzerid = m.erstellung_benutzerid)',
'left outer join cte  on (cte.BENACHRICHTIGUNGID = m.BENACHRICHTIGUNGID)',
'where (m.status in (10,20) or  NVL(:P610_STATUS, 0) =1) and m.ARBEITSKREISID not in (1200 , 1400)',
'-- nur eigene AKreise',
'and (a.et_B_AKID in (select et_B_AKID from T_ET_B_AK_ref_benutzer where benutzerid =  pck_ri.fgetUserId) ',
'     or pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0)',
'',
'    ',
'',
unistr('-- add benachrichtigungen f\00FCr administratoren wenn benutzer in der rolle Fachadmin  (1003)'),
'UNION',
'select ',
'   -- APEX_ITEM.CHECKBOX(1,m.BENACHRICHTIGUNGID,null, :P610_SELECTED_IDS,'':'') as "select", ',
'   apex_item.hidden(01,m.benachrichtigungid) || apex_item.checkbox2(02,m.benachrichtigungid) check1 ',
'   , m.BENACHRICHTIGUNGID,',
'       m.ARBEITSKREISID,',
'       CASE ',
'    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN a.bezeichnung ',
'    ELSE a.name_eng ',
'    END "ARBEITSKREIS",',
'       m.VORSCHRIFTID,',
'       v.Vorschrift_nummer "VORSCHRIFTNUMMER",',
'       nvl(m.loeschmarker,0) "LOESCHMARKER",',
'       v.VORSCHRIFT_BEZEICHNUNG "VORSCHRIFTTITEL",  ',
'        DECODE(m.STATUS, ',
'                10, emano_util.fLang(''offen'', ''open''),',
'                20, emano_util.fLang(''in Bearbeitung'', ''in progress''),',
'                30, emano_util.fLang(''erledigt'', ''completed''),',
'                emano_util.fLang(''offen'', ''open'')',
'            ) "STATUS",',
'',
'       m.LETZTE_AENDERUNG_DATUM,',
'       round(sysdate - m.ERSTELLUNG_DATUM) "Tagen s. ERSTELLUNG",',
'        nvl(b.nachname,''-'') || '', '' || nvl(b.vorname,''-'') || '' ('' || nvl(b.abteilung,''-'') || '')'' as erstell_benutzer,',
'        m.grund,',
'        (m.erstellung_datum + 730) as loeschdatum,',
'        cte.kommentar,',
'       (select  ab.nachname || '', '' || ab.vorname from t_benutzer ab where m.bearbeiterid = ab.benutzerid) as bearbeiter,',
'       m.BETROFFENER_ANWENDER',
'from T_BENACHRICHTIGUNG m ',
'full Join T_Vorschrift v on v.vorschriftid = m.vorschriftid',
'inner Join T_ET_B_AK a on a.et_B_AKID = m.ARBEITSKREISID',
'left outer join t_benutzer b on (b.benutzerid = m.erstellung_benutzerid)',
'left outer join cte  on (cte.BENACHRICHTIGUNGID = m.BENACHRICHTIGUNGID)',
'',
'WHERE (m.status in (10,20) OR NVL(:P610_STATUS, 0) = 1) ',
'  AND (a.bezeichnung = ''Administratoren'' or a.name_eng = ''Administrators'')',
'  AND (  pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0)',
' ',
' UNION',
'select ',
'   -- APEX_ITEM.CHECKBOX(1,m.BENACHRICHTIGUNGID,null, :P610_SELECTED_IDS,'':'') as "select", ',
'   apex_item.hidden(01,m.benachrichtigungid) || apex_item.checkbox2(02,m.benachrichtigungid) check1 ',
'   , m.BENACHRICHTIGUNGID,',
'       m.ARBEITSKREISID,',
'       CASE ',
'    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN a.bezeichnung ',
'    ELSE a.name_eng ',
'    END "ARBEITSKREIS",',
'       m.VORSCHRIFTID,',
'       v.Vorschrift_nummer "VORSCHRIFTNUMMER",',
'       nvl(m.loeschmarker,0) "LOESCHMARKER",',
'       v.VORSCHRIFT_BEZEICHNUNG "VORSCHRIFTTITEL",  ',
'         DECODE(m.STATUS, ',
'       10, emano_util.fLang(''offen'', ''open''),',
'       20, emano_util.fLang(''in Bearbeitung'', ''in progress''),',
'       30, emano_util.fLang(''erledigt'', ''completed''),',
'           emano_util.fLang(''offen'', ''open'')) "STATUS",',
'',
'       m.LETZTE_AENDERUNG_DATUM,',
'       round(sysdate - m.ERSTELLUNG_DATUM) "Tagen s. ERSTELLUNG",',
'        nvl(b.nachname,''-'') || '', '' || nvl(b.vorname,''-'') || '' ('' || nvl(b.abteilung,''-'') || '')'' as erstell_benutzer,',
'        m.grund,',
'        (m.erstellung_datum + 730) as loeschdatum,',
'        cte.kommentar,',
'       (select  ab.nachname || '', '' || ab.vorname from t_benutzer ab where m.bearbeiterid = ab.benutzerid) as bearbeiter,',
'       m.BETROFFENER_ANWENDER',
'from T_BENACHRICHTIGUNG m ',
'full Join T_Vorschrift v on v.vorschriftid = m.vorschriftid  -- auch mit m.vorschriftid = null',
'inner Join T_ET_B_AK a on a.et_B_AKID = m.ARBEITSKREISID',
'left outer join t_benutzer b on (b.benutzerid = m.erstellung_benutzerid)',
'left outer join cte  on (cte.BENACHRICHTIGUNGID = m.BENACHRICHTIGUNGID)',
'-- where (m.status in (10,20) or  NVL(:P610_STATUS, 0) =1) and a.bezeichnung = ''Redaktionsteam''',
'WHERE (m.status IN (10,20) OR NVL(:P610_STATUS, 0) = 1) AND (a.bezeichnung = ''Redaktionsteam'' or a.name_eng = ''Editorial Team'')',
'',
'-- a.bezeichnung = ''Redaktionsteam''',
'and (1 = pck_ri.fisInRedaktionsteam(pck_ri.fgetUserId) or pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0)',
'',
'',
'',
'UNION',
'',
'select ',
'   -- APEX_ITEM.CHECKBOX(1,m.BENACHRICHTIGUNGID,null, :P610_SELECTED_IDS,'':'') as "select", ',
'   apex_item.hidden(01,m.benachrichtigungid) || apex_item.checkbox2(02,m.benachrichtigungid) check1 ',
'   , m.BENACHRICHTIGUNGID,',
'       m.ARBEITSKREISID,',
'       CASE ',
'    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN a.bezeichnung ',
'    ELSE a.name_eng ',
'    END "ARBEITSKREIS",',
'       m.VORSCHRIFTID,',
'       v.Vorschrift_nummer "VORSCHRIFTNUMMER",',
'       nvl(m.loeschmarker,0) "LOESCHMARKER",',
'       v.VORSCHRIFT_BEZEICHNUNG "VORSCHRIFTTITEL",  ',
'         DECODE(m.STATUS, ',
'       10, emano_util.fLang(''offen'', ''open''),',
'    --    20, emano_util.fLang(''in Bearbeitung'', ''in progress''),',
'       30, emano_util.fLang(''erledigt'', ''completed''),',
'           emano_util.fLang(''offen'', ''open'')) "STATUS",',
'',
'       m.LETZTE_AENDERUNG_DATUM,',
'       round(sysdate - m.ERSTELLUNG_DATUM) "Tagen s. ERSTELLUNG",',
'        nvl(b.nachname,''-'') || '', '' || nvl(b.vorname,''-'') || '' ('' || nvl(b.abteilung,''-'') || '')'' as erstell_benutzer,',
'        m.grund,',
'        (m.erstellung_datum + 730) as loeschdatum,',
'        cte.kommentar,',
'       (select  ab.nachname || '', '' || ab.vorname from t_benutzer ab where m.bearbeiterid = ab.benutzerid) as bearbeiter,',
'      -- (select  ab.nachname || '', '' || ab.vorname from t_benutzer ab where  ab.benutzerid = m.BETROFFENER_ANWENDER) as BETROFFENER_ANWENDER',
'      case',
'        when REGEXP_LIKE (m.BETROFFENER_ANWENDER,''^[[:digit:]]+$'') ',
'        then (select  ab.nachname || '', '' || ab.vorname from t_benutzer ab where  ab.benutzerid = m.BETROFFENER_ANWENDER)',
'        else m.BETROFFENER_ANWENDER end as BETROFFENER_ANWENDER',
'',
'from T_BENACHRICHTIGUNG m ',
'full Join T_Vorschrift v on v.vorschriftid = m.vorschriftid  -- auch mit m.vorschriftid = null',
'inner Join T_ET_B_AK a on a.et_B_AKID = m.ARBEITSKREISID',
'left outer join t_benutzer b on (b.benutzerid = m.erstellung_benutzerid)',
'left outer join cte  on (cte.BENACHRICHTIGUNGID = m.BENACHRICHTIGUNGID)',
'-- where (m.status in (10,20) or  NVL(:P610_STATUS, 0) =1) and a.bezeichnung = ''Redaktionsteam''',
'WHERE (m.status IN (10,20) OR NVL(:P610_STATUS, 0) = 1) AND (a.bezeichnung = ''VKO/VEX-Register'' or a.name_eng = ''VKO/VEX-Register'')',
'',
'-- a.bezeichnung = ''Redaktionsteam''',
'and (1 = pck_ri.fisInRedaktionsteam(pck_ri.fgetUserId) or pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0);',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P610_STATUS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Benachrichtigungen  <span onclick="redirect(541)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(683260047738116555)
,p_name=>'Benachrichtigungen'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_detail_link_text=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_detail_link_attr=>'target="_blank"'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>429432889357017849
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683259701596116526)
,p_db_column_name=>'BENACHRICHTIGUNGID'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'&nbsp'
,p_column_link=>'f?p=&APP_ID.:615:&SESSION.::&DEBUG.:615:P615_BENACHRICHTIGUNGID:#BENACHRICHTIGUNGID#'
,p_column_linktext=>'<span class="fa fa-edit" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683242229228678289)
,p_db_column_name=>'VORSCHRIFTTITEL'
,p_display_order=>30
,p_column_identifier=>'M'
,p_column_label=>'Vorschrifttitel'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683242292592678290)
,p_db_column_name=>'ARBEITSKREIS'
,p_display_order=>40
,p_column_identifier=>'L'
,p_column_label=>'Arbeitskreis'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683259425693116520)
,p_db_column_name=>'ARBEITSKREISID'
,p_display_order=>50
,p_column_identifier=>'B'
,p_column_label=>'Arbeitskreisid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683259013919116520)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>60
,p_column_identifier=>'C'
,p_column_label=>'&nbsp;'
,p_display_in_default_rpt=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683242781079678295)
,p_db_column_name=>'STATUS'
,p_display_order=>70
,p_column_identifier=>'J'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(655934543813135302)
,p_db_column_name=>'LOESCHMARKER'
,p_display_order=>80
,p_column_identifier=>'P'
,p_column_label=>'Loeschmarker'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(655933938296135296)
,p_db_column_name=>'Tagen s. ERSTELLUNG'
,p_display_order=>90
,p_column_identifier=>'Q'
,p_column_label=>'Tagen S. Erstellung'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644943850715825581)
,p_db_column_name=>'ERSTELL_BENUTZER'
,p_display_order=>100
,p_column_identifier=>'R'
,p_column_label=>unistr('Ausl\00F6ser')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644943748912825580)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>110
,p_column_identifier=>'S'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd.mm.yyyy hh24:mi'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644943473243825577)
,p_db_column_name=>'GRUND'
,p_display_order=>120
,p_column_identifier=>'T'
,p_column_label=>'Grund'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(619924812765862105)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(628093792631742875)
,p_db_column_name=>'LOESCHDATUM'
,p_display_order=>130
,p_column_identifier=>'U'
,p_column_label=>unistr('L\00F6schdatum')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(581725975163660001)
,p_db_column_name=>'BEARBEITER'
,p_display_order=>140
,p_column_identifier=>'V'
,p_column_label=>'Bearbeiter'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(581725886737660000)
,p_db_column_name=>'VORSCHRIFTNUMMER'
,p_display_order=>150
,p_column_identifier=>'W'
,p_column_label=>'Vorschriftnummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(581725733449659998)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>160
,p_column_identifier=>'X'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(554260121022028758)
,p_db_column_name=>'CHECK1'
,p_display_order=>170
,p_column_identifier=>'AB'
,p_column_label=>'<input type="checkbox" id="selectUnselectAll" title="Select/UnselectAll">'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(877409874677999884)
,p_db_column_name=>'BETROFFENER_ANWENDER'
,p_display_order=>180
,p_column_identifier=>'AC'
,p_column_label=>'Betroffener Anwender'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(683256846457100843)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4294361'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BENACHRICHTIGUNGID:CHECK1:STATUS:ARBEITSKREIS:VORSCHRIFTNUMMER:VORSCHRIFTTITEL:ERSTELL_BENUTZER:GRUND:LOESCHDATUM:BEARBEITER:KOMMENTAR:BETROFFENER_ANWENDER:'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(872877893315590934)
,p_report_id=>wwv_flow_imp.id(683256846457100843)
,p_name=>unistr('Automatisches L\00F6schen in < 30 Tagen')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'LOESCHDATUM'
,p_operator=>'is in the next'
,p_expr=>'30'
,p_expr2=>'days'
,p_condition_sql=>' (case when ("LOESCHDATUM" between sysdate and sysdate + numtodsinterval(1 * #APXWS_EXPR#, ''day'')) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 30 #APXWS_EXPR2_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#ffd6d2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44056700777412474)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(683260235614116555)
,p_button_name=>'Status_Change'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Status \00E4ndern')
,p_button_position=>'TEMPLATE_DEFAULT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(683243458920678302)
,p_name=>'P610_STATUS'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(683260235614116555)
,p_prompt=>'Benachrichtigungen mit Status "erledigt"'
,p_source=>'0'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'ausblenden',
  'off_value', '0',
  'on_label', 'anzeigen',
  'on_value', '1',
  'use_defaults', 'N')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'default:  Vorschriften, die noch nicht im Status "erledigt".',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44056586851412473)
,p_name=>'P610_NEUE_STATUS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(683260235614116555)
,p_use_cache_before_default=>'NO'
,p_prompt=>'neuer Status'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_BENACHRICHTIGUNG_STATUS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''offen'', ''open'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''in Bearbeitung'', ''in progress'') AS display_value,',
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''erledigt'', ''completed'') AS display_value,',
'        30 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- select -'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(683243220073678299)
,p_name=>'Change switch'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P610_STATUS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(683243120141678298)
,p_event_id=>wwv_flow_imp.id(683243220073678299)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(683260235614116555)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(554259975414028757)
,p_name=>'select_unselect'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectUnselectAll'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554259882645028756)
,p_event_id=>wwv_flow_imp.id(554259975414028757)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'EVENT_SOURCE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if($(''#selectUnselectAll'').is('':checked'')){',
'   $(''input[type=checkbox][name=f02]'').attr(''checked'',true);',
'}',
'else{',
'   $(''input[type=checkbox][name=f02]'').attr(''checked'',false);',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44056433728412471)
,p_name=>'On Change'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P610_NEUE_STATUS'
,p_condition_element=>'P610_NEUE_STATUS'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44056269866412470)
,p_event_id=>wwv_flow_imp.id(44056433728412471)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(44056700777412474)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44056142224412469)
,p_event_id=>wwv_flow_imp.id(44056433728412471)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(44056700777412474)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(44056509253412472)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'change Status'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for i in 1 .. apex_application.G_F02.count ',
'LOOP',
'    update t_benachrichtigung set status =:P610_NEUE_STATUS',
'    where  benachrichtigungid = apex_application.G_F02(i);',
'end LOOP;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Status Aktualisierung fehlgeschlagen'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(44056700777412474)
,p_process_when=>'P610_NEUE_STATUS'
,p_process_when_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_process_success_message=>'Status aktualisiert'
,p_internal_uid=>3628155806645975763
);
wwv_flow_imp.component_end;
end;
/
