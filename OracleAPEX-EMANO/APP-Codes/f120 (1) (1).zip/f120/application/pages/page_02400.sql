prompt --application/pages/page_02400
begin
--   Manifest
--     PAGE: 02400
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>2400
,p_name=>'GETEX Monitor'
,p_alias=>'GETEX-MONITOR'
,p_step_title=>'GETEX Monitor'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2157655931315368584)
,p_plug_name=>'GETEX Schnittstellenmonitoring'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2157655796037368583)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_imp.id(2157655931315368584)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>unistr('Die nachfolgende Tabelle zeigt die letzten GETEX-Beladungen an. Anhand der Pr\00FCfsumme f\00FCr die Struktur der Daten k\00F6nnen Ver\00E4nderungen an der Schnittstelle hervorgehoben und ggf. n\00E4her gepr\00FCft werden.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3753964587283419913)
,p_name=>'GETEX Schnittstellenmonitoring'
,p_parent_plug_id=>wwv_flow_imp.id(2157655931315368584)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select g.*, ',
'lead(checksum_json,1,0) over (order by getex_monitorid desc) as prev_checksum,',
'case when nvl(',
'    lead(checksum_json,1,-1) over (order by getex_monitorid desc)',
'    ,-1) != nvl(checksum_json,-1) then ''yellow'' else null end as color',
'from t_getex_monitor g',
'order by 1 desc'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024913527228029730)
,p_query_column_id=>1
,p_column_alias=>'GETEX_MONITORID'
,p_column_display_sequence=>10
,p_column_heading=>'Getex Monitorid'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024913167660029728)
,p_query_column_id=>2
,p_column_alias=>'ZEITPUNKT_START'
,p_column_display_sequence=>20
,p_column_heading=>'Zeitpunkt Start'
,p_column_format=>'dd.mm.yy hh24:mi:ss'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024912771774029728)
,p_query_column_id=>3
,p_column_alias=>'ZEITPUNKT_POSTPROCESSING'
,p_column_display_sequence=>30
,p_column_heading=>'Zeitpunkt Postprocessing'
,p_column_format=>'dd.mm.yy hh24:mi:ss'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024912398502029728)
,p_query_column_id=>4
,p_column_alias=>'ZEITPUNKT_ENDE'
,p_column_display_sequence=>40
,p_column_heading=>'Zeitpunkt Ende'
,p_column_format=>'dd.mm.yy hh24:mi:ss'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024911992530029727)
,p_query_column_id=>5
,p_column_alias=>'CHECKSUM_JSON'
,p_column_display_sequence=>50
,p_column_heading=>unistr('Pr\00FCfsumme')
,p_column_html_expression=>'<span style="background-color: #COLOR#">#CHECKSUM_JSON#</span>'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024911613613029727)
,p_query_column_id=>6
,p_column_alias=>'DATAGUIDE'
,p_column_display_sequence=>60
,p_column_heading=>'Dataguide'
,p_column_html_expression=>'<button class="t-Button t-Button--noLabel t-Button--icon downloadjson" type="button" data-id="#GETEX_MONITORID#"><span class="fa fa-search"></span></button>'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1018997630750290391)
,p_query_column_id=>7
,p_column_alias=>'ANZ_DELTA_AUTO'
,p_column_display_sequence=>70
,p_column_heading=>unistr('Anzahl Vorschriften mit \00FCbernommenem Delta')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024911145948029726)
,p_query_column_id=>8
,p_column_alias=>'PREV_CHECKSUM'
,p_column_display_sequence=>80
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1024910764935029726)
,p_query_column_id=>9
,p_column_alias=>'COLOR'
,p_column_display_sequence=>90
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3753965809262419925)
,p_plug_name=>'Dataguide'
,p_region_template_options=>'#DEFAULT#:js-dialog-size720x480'
,p_plug_template=>wwv_flow_imp.id(3414122300140820546)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1024910072689029725)
,p_name=>'P2400_DATAGUIDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3753965809262419925)
,p_prompt=>'Dataguide'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>22
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144103148820565)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1024909711284029693)
,p_name=>'P2400_MONITORID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1024909253043029687)
,p_name=>'download'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.downloadjson'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1024908791345029684)
,p_event_id=>wwv_flow_imp.id(1024909253043029687)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P2400_MONITORID'',$(this.triggeringElement).attr(''data-id''));'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1024908246883029683)
,p_event_id=>wwv_flow_imp.id(1024909253043029687)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'select dataguide into :P2400_DATAGUIDE from t_getex_monitor where getex_monitorid = :P2400_MONITORID;'
,p_attribute_02=>'P2400_MONITORID'
,p_attribute_03=>'P2400_DATAGUIDE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1024907718140029682)
,p_event_id=>wwv_flow_imp.id(1024909253043029687)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3753965809262419925)
);
wwv_flow_imp.component_end;
end;
/
