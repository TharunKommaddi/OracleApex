prompt --application/pages/page_00469
begin
--   Manifest
--     PAGE: 00469
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>469
,p_name=>'Massenupdate - Schritt 3 (Ergebnis)'
,p_alias=>'MASSENUPDATE-SCHRITT-3-ERGEBNIS'
,p_page_mode=>'MODAL'
,p_step_title=>'Massenupdate - Schritt 3 (Ergebnis)'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_dialog_width=>'1000'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2314334331788990120)
,p_plug_name=>'Massenupdate Ergebnis'
,p_region_template_options=>'#DEFAULT#:margin-top-lg'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div style="background-color: #d4edda; border: 1px solid #c3e6cb; padding: 20px; margin: 15px 0; border-radius: 5px;">',
'    <h3 style="color: #155724; margin-top: 0;">',
'        <i class="fa fa-check-circle" style="color: #28a745; margin-top: 7px; margin-right: 5px;"></i>',
'        Massenupdate erfolgreich abgeschlossen',
'    </h3>',
'    <div style="margin: 15px 0;">',
'        <strong>Update-Typ:</strong> ',
'        <span id="update-type-display"></span>',
'    </div>',
'    <div style="margin: 15px 0;" id="comment-section" style="display: none;">',
'        <strong>Kommentar:</strong> ',
'        <span id="comment-display"></span>',
'    </div>',
'    <div style="margin: 15px 0;">',
unistr('        <strong>Verarbeitete Eintr\00E4ge:</strong> '),
'        <span style="color: #28a745; font-weight: bold;">&P469_TOTAL_PROCESSED.</span>',
'    </div>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4436965344664946690)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17017770921446328160)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_component_template_options=>'t-WizardSteps--displayLabels'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(964128428368451140)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964087521861438874)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4436965344664946690)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964087181146438873)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(4436965344664946690)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964086763559438873)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(4436965344664946690)
,p_button_name=>'FINISH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Fertig'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(964078880849438869)
,p_branch_name=>'Go To Page 468'
,p_branch_action=>'f?p=&APP_ID.:468:&SESSION.::&DEBUG.:468:P468_SELECTED_ROWS,P468_SEARCH_SELECTION,P468_MILESTONE_SELECTION,P468_CARD_NUM,P468_UPDATE_TYPE,P468_COMMENT:&P469_SELECTED_ROWS.,&P469_SEARCH_SELECTION.,&P469_MILESTONE_SELECTION.,&P469_CARD_NUM.,&P469_UPDATE_TYPE.,&P469_COMMENT.'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(964087521861438874)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964086045409438873)
,p_name=>'P469_SELECTED_ROWS'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964085632473438872)
,p_name=>'P469_SEARCH_SELECTION'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964085282318438872)
,p_name=>'P469_MILESTONE_SELECTION'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964085005752438872)
,p_name=>'P469_CARD_NUM'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964084608550438872)
,p_name=>'P469_UPDATE_TYPE'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964084138557438872)
,p_name=>'P469_COMMENT'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964083750474438871)
,p_name=>'P469_TOTAL_PROCESSED'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964083405236438871)
,p_name=>'P469_SUCCESS_MESSAGE'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964082577920438870)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(964087181146438873)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964082088289438870)
,p_event_id=>wwv_flow_imp.id(964082577920438870)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964081628694438870)
,p_name=>'Show Update Type'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964081203675438870)
,p_event_id=>wwv_flow_imp.id(964081628694438870)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var updateType = $v(''P469_UPDATE_TYPE'');',
'var displayText = '''';',
'',
'if (updateType === ''UNECE_HIGHEST_SERIES'') {',
'    displayText = ''UNECE Highest Series Selection Spezial'';',
'} else if (updateType === ''DEACTIVATE_ROWS'') {',
unistr('    displayText = ''Vorschriften nicht relevant f\00FCr Umsetzung'';'),
'}',
'',
'$(''#update-type-display'').text(displayText);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964080742147438870)
,p_name=>'Show Comment if UNECE'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964080232688438870)
,p_event_id=>wwv_flow_imp.id(964080742147438870)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var updateType = $v(''P469_UPDATE_TYPE'');',
'var comment = $v(''P469_COMMENT'');',
'',
'if (updateType === ''UNECE_HIGHEST_SERIES'' && comment && comment.trim() !== '''') {',
'    $(''#comment-display'').text(comment);',
'    $(''#comment-section'').show();',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964079828540438869)
,p_name=>'Close Dialog'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(964086763559438873)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964079321204438869)
,p_event_id=>wwv_flow_imp.id(964079828540438869)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964082922503438871)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Values from Previous Page'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Set values from page 468',
'    :P469_SELECTED_ROWS := :P468_SELECTED_ROWS;',
'    :P469_SEARCH_SELECTION := :P468_SEARCH_SELECTION;',
'    :P469_MILESTONE_SELECTION := :P468_MILESTONE_SELECTION;',
'    :P469_CARD_NUM := :P468_CARD_NUM;',
'    :P469_UPDATE_TYPE := :P468_UPDATE_TYPE;',
'    :P469_COMMENT := :P468_COMMENT;',
'    ',
'    -- Set result message based on type',
'    IF :P469_UPDATE_TYPE = ''DEACTIVATE_ROWS'' THEN',
unistr('        :P469_SUCCESS_MESSAGE := ''Ausgew\00E4hlte Zeilen wurden erfolgreich deaktiviert.'';'),
'    ELSIF :P469_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' THEN',
unistr('        :P469_SUCCESS_MESSAGE := ''UNECE Highest Series Selection wurde erfolgreich durchgef\00FChrt.'';'),
'    ELSE',
unistr('        :P469_SUCCESS_MESSAGE := ''Massenupdate wurde erfolgreich durchgef\00FChrt.'';'),
'    END IF;',
'    ',
'    -- Get actual processed count from database (last hour)',
'    BEGIN',
'        SELECT COUNT(*)',
'        INTO :P469_TOTAL_PROCESSED',
'        FROM t_ms_bewertung',
'        WHERE sucheid = :P469_SEARCH_SELECTION',
'        AND meilenstein = :P469_MILESTONE_SELECTION',
'        AND card_number = :P469_CARD_NUM',
'        AND benutzerid = :G_BENUTZERID',
'        AND letzte_aenderung_datum >= SYSDATE - 1/24; -- Last hour',
'    EXCEPTION',
'        WHEN OTHERS THEN',
'            -- Fallback to counting selected rows',
'            SELECT COUNT(*)',
'            INTO :P469_TOTAL_PROCESSED',
'            FROM TABLE(apex_string.split(:P469_SELECTED_ROWS, '':''))',
'            WHERE COLUMN_VALUE IS NOT NULL;',
'    END;',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        :P469_SUCCESS_MESSAGE := ''Massenupdate abgeschlossen, aber Ergebnis konnte nicht ermittelt werden.'';',
'        :P469_TOTAL_PROCESSED := 0;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2708129393395949364
);
wwv_flow_imp.component_end;
end;
/
