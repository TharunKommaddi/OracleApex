prompt --application/pages/page_00615
begin
--   Manifest
--     PAGE: 00615
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>615
,p_name=>'Benachrichtigung anzeigen'
,p_alias=>'BENACHRICHTIGUNG-ANZEIGEN'
,p_step_title=>'Benachrichtigung anzeigen'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* div.beta {',
'    display: inline-block;',
'    position: relative;',
'    right: 0px;',
'    font-weight: bold;',
'    color: #d30b37;    ',
'    font-size: 25px;',
'    margin-left: 5px;',
'    padding: 3px;',
'    border: 1px solid #bb0a31;',
'    max-width: 50px;',
'    ',
'} */',
'/* .oj-gantt-task.alle-fzg {',
'    fill: red;',
'} */',
'',
'',
'.apex-item-single-checkbox input:checked+.u-checkbox, ',
'.apex-item-single-checkbox input:checked+label, ',
'.u-checkbox.is-checked {',
'    --a-checkbox-background-color: #bb0a31 !important;',
'    --a-checkbox-text-color: var(--a-checkbox-checked-text-color);',
'    border-color: black !important;',
'    font-weight: bold !important;',
'    color: black !important;',
'}',
'',
'/* .apex-item-checkbox input+label:before, .apex-item-radio input+label:before, .apex-item-single-checkbox input+label:before, .u-checkbox:before, .u-radio:before {',
'    background-color: var(--a-checkbox-background-color);',
'    border-color: black !important;',
'    border-radius: var(--a-checkbox-border-radius,2px);',
'    border-style: solid;',
'    border-width: var(--a-checkbox-border-width,1px);',
'    font-size: var(--a-checkbox-icon-size,12px);',
'    height: var(--a-checkbox-size,16px);',
'    line-height: calc(var(--a-checkbox-size, 16px) - var(--a-checkbox-border-width, 1px)*2);',
'    width: var(--a-checkbox-size,16px);',
'} */',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(683242668016678294)
,p_plug_name=>'Benachrichtigung Details'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(683241471197678282)
,p_name=>'Kommentare zur Benachrichtigung'
,p_parent_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b.Nachname ||'', '' || b.vorname  "BENUTZERNAME",  b.Abteilung, k.kommentar, k.zeitpunkt ',
'from T_Benachrichtigung_kommentar k',
'Join T_Benutzer b on k.BenutzerID=b.BenutzerID ',
'join T_Benachrichtigung m on m.BenachrichtigungId = k.BenachrichtigungId  and k.BenachrichtigungId = :P615_BenachrichtigungId',
'order by k.zeitpunkt desc;',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(682711203201275003)
,p_query_column_id=>1
,p_column_alias=>'BENUTZERNAME'
,p_column_display_sequence=>2
,p_column_heading=>'Benutzername'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(683240875400678276)
,p_query_column_id=>2
,p_column_alias=>'ABTEILUNG'
,p_column_display_sequence=>3
,p_column_heading=>'Abteilung'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(682711082223275002)
,p_query_column_id=>3
,p_column_alias=>'KOMMENTAR'
,p_column_display_sequence=>4
,p_column_heading=>'Kommentar'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(682710732882274998)
,p_query_column_id=>4
,p_column_alias=>'ZEITPUNKT'
,p_column_display_sequence=>1
,p_column_heading=>'Zeitpunkt'
,p_column_format=>'dd.mm.yyyy hh24:mi'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(682710972456275001)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(683241471197678282)
,p_button_name=>'Hinzufuegen'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(669812212797498492)
,p_button_sequence=>160
,p_button_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_button_name=>'CHANGE_STATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Status \00E4ndern')
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(680059086257083578)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Zur\00FCck zur Benachrichrtigungsliste')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:610:&SESSION.::&DEBUG.:::'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(683241545471678283)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_button_name=>'Zeige_Vorschrift'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('Vorschrift \00D6ffnen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(877409790228999883)
,p_name=>'P615_BETROFFENER_ANWENDER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_prompt=>'Betroffener Anwender'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P615_GRUNDID'
,p_display_when2=>'130'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(877408978710999875)
,p_name=>'P615_STATUS_DMS'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_prompt=>'Status Dms'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_display_when=>'P615_GRUNDID'
,p_display_when2=>'130'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', '30',
  'unchecked_value', '10',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(877408873996999874)
,p_name=>'P615_GMT'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_prompt=>'Status Gmt'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_display_when=>'P615_GRUNDID'
,p_display_when2=>'130'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', '30',
  'unchecked_value', '10',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(877408777875999873)
,p_name=>'P615_JIRA'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_prompt=>'Status Jira'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_display_when=>'P615_GRUNDID'
,p_display_when2=>'130'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', '30',
  'unchecked_value', '10',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(877408638584999872)
,p_name=>'P615_REQMAN'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_prompt=>'Status ReqMan'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_display_when=>'P615_GRUNDID'
,p_display_when2=>'130'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', '30',
  'unchecked_value', '10',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(690528129940726661)
,p_name=>'P615_GRUNDID'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(683242593755678293)
,p_name=>'P615_BENACHRICHTIGUNGID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(683241939113678287)
,p_name=>'P615_VORSCHRIFTTITEL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_prompt=>'Vorschrifttitel'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P615_GRUNDID'
,p_display_when2=>'130'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(683241877992678286)
,p_name=>'P615_LETZTE_AENDERUNG'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_prompt=>unistr('Letzte \00C4nderung')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(683241747414678285)
,p_name=>'P615_BENACHRICHTIGUNGSTEXT'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_prompt=>'Beschreibung'
,p_source=>'select benachrichtigung_text from T_benachrichtigung where benachrichtigungid=:P615_benachrichtigungid;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(683241654739678284)
,p_name=>'P615_ARBEITSKREIS'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_prompt=>'Arbeitskreis'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(682710901362275000)
,p_name=>'P615_NEUER_KOMMENTAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(683241471197678282)
,p_prompt=>'Neuer Kommentar'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>5
,p_grid_column=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(682710608040274997)
,p_name=>'P615_STATUS'
,p_is_required=>true
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_prompt=>'Status von Benachrichtigung'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''offen'', ''open'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''in Bearbeitung'', ''in Progress'') AS display_value,',
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''erledigt'', ''done'') AS display_value,',
'        30 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(678104096969617603)
,p_name=>'P615_VORSCHRIFTID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(632210708738546193)
,p_name=>'P615_GRUND'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_prompt=>'Grund'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_BENACHRICHTIGUNG_GRUND'
,p_lov=>'.'||wwv_flow_imp.id(619924812765862105)||'.'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628093700851742874)
,p_name=>'P615_LOESCHDATUM'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_prompt=>unistr('L\00F6schdatum')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_BENACHRICHTIGUNG_GRUND'
,p_lov=>'.'||wwv_flow_imp.id(619924812765862105)||'.'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(581725765428659999)
,p_name=>'P615_VORSCHRIFT_NUMMER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_prompt=>'Vorschriftnummer'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P615_GRUNDID'
,p_display_when2=>'130'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(581724336737659984)
,p_name=>'P615_BEARBEITER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_prompt=>'Bearbeiter'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select distinct  b.nachName||'', ''||b.vorname || '' ('' || nvl(b.abteilung,''-'') || '')'' d , b.benutzerId  r ',
'from T_BENUTZER b',
'join T_ET_B_AK_REF_BENUTZER arb on(arb.benutzerId = b.benutzerId)',
'join t_benutzer_ref_rolle brr on (brr.benutzerid = b.benutzerid)',
'where (:P615_ARBEITSKREIS != ''Redaktionsteam'') and b.nachname  is not null and brr.rolleid in (1000) ',
'UNION',
'Select distinct  b.nachName||'', ''||b.vorname || '' ('' || nvl(b.abteilung,''-'') || '')'' d , b.benutzerId  r ',
'from T_BENUTZER b',
'where (:P615_ARBEITSKREIS = ''Redaktionsteam'') and b.nachname  is not null and 1= pck_ri.fisInRedaktionsteam(b.benutzerid)',
'order by 1;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('ausw\00E4hlen')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(581721498167659956)
,p_name=>'P615_AUSLOESER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(683242668016678294)
,p_prompt=>unistr('Ausl\00F6ser')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(680779834738785503)
,p_name=>'ZeigeVorschrift'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(683241545471678283)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(680779696228785502)
,p_event_id=>wwv_flow_imp.id(680779834738785503)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'javascript:window.open(''f?p=&APP_ID.:25:&APP_SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:''+$v("P615_VORSCHRIFTID") +'''',''_blank'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(701658119230422859)
,p_name=>'Gesamtstatus auf erledigt, wenn Unter-Statuswerte erledigt'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P615_STATUS_DMS,P615_GMT,P615_JIRA,P615_REQMAN'
,p_condition_element=>'P615_GRUNDID'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'130'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(701658030118422858)
,p_event_id=>wwv_flow_imp.id(701658119230422859)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P615_STATUS'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- that should be only for benachrichtigung of type '' sent to  VKO/VEX-Register'' !!  check condition!!',
'SELECT CASE  WHEN :P615_GRUNDID =130 AND TO_NUMBER(:P615_STATUS_DMS) = 30 AND TO_NUMBER(:P615_GMT) = 30 AND TO_NUMBER(:P615_JIRA) = 30 AND TO_NUMBER(:P615_REQMAN) = 30 THEN 30',
'               ELSE TO_NUMBER(:P615_STATUS)',
'               END AS STATUS FROM DUAL;'))
,p_attribute_07=>'P615_STATUS_DMS,P615_GMT,P615_JIRA,P615_REQMAN,P615_GRUND'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(682710797796274999)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Speichern_kommentar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Insert into T_BENACHRICHTIGUNG_KOMMENTAR (Benachrichtigungid, benutzerid, zeitpunkt, kommentar)',
' values(:P615_BENACHRICHTIGUNGID, :G_BENUTZERID, SYSDATE, :P615_NEUER_KOMMENTAR);',
' ',
' :P615_NEUER_KOMMENTAR :=null;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(682710972456275001)
,p_process_when=>'P615_NEUER_KOMMENTAR'
,p_process_when_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_internal_uid=>2989501518103113236
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(877408343130999869)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Status_Update'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- setting of additional specifical status is only for the Benachrichtigung of type  sent ''to VKO/VEX-Register''  Grund 130',
'-- check grund over database select grund into  l_grund from t_benachricht where t_benachrichtigungid = P615_BENACHRICHTIGUNGID',
'declare ',
'    l_grund number :=0;',
'begin',
'    select grund into l_grund from t_benachrichtigung where benachrichtigungid = :P615_BENACHRICHTIGUNGID;',
'',
unistr('    if(l_grund =130 ) then     --:P615_GRUND =''Benutzer zur Arbeitsgruppe hinzugef\00FCgt'') then '),
'        UPDATE T_BENACHRICHTIGUNG ',
'        SET ',
'           letzte_aenderung_datum =sysdate, ',
'         BEARBEITERID = :P615_BEARBEITER,',
'            STATUS_DMS = case when :P615_STATUS =30 then 30 else TO_NUMBER(:P615_STATUS_DMS) end,',
'            STATUS_GMT = case when :P615_STATUS  =30 then 30 else TO_NUMBER(:P615_GMT) end,',
'            STATUS_JIRA = case when :P615_STATUS  =30 then 30 else TO_NUMBER(:P615_JIRA) end,',
'            STATUS_REQMAN = case when :P615_STATUS =30 then 30 else TO_NUMBER(:P615_REQMAN) end,',
'            STATUS = CASE ',
'                       WHEN TO_NUMBER(:P615_STATUS_DMS) = 30 AND TO_NUMBER(:P615_GMT) = 30 AND TO_NUMBER(:P615_JIRA) = 30 AND TO_NUMBER(:P615_REQMAN) = 30 THEN 30',
'                       ELSE TO_NUMBER(:P615_STATUS)',
'                     END',
'            -- STATUS = TO_NUMBER(:P615_STATUS)',
'        WHERE BENACHRICHTIGUNGID = :P615_BENACHRICHTIGUNGID;',
'    else',
'        UPDATE T_BENACHRICHTIGUNG ',
'        SET STATUS = TO_NUMBER(:P615_STATUS), letzte_aenderung_datum =sysdate, BEARBEITERID = :P615_BEARBEITER',
'        WHERE BENACHRICHTIGUNGID = :P615_BENACHRICHTIGUNGID;',
'',
'     end if;',
' end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(669812212797498492)
,p_internal_uid=>2794803972768388366
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'P615_ARBEITS',
'KVKO/VEX-RegisterREIS'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(680779508419785500)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(b.nachname,''-'') || '', '' || nvl(b.vorname,''-'') || '' ('' || nvl(b.abteilung,''-'') || '')'' as ausloeser,',
'       a.Bezeichnung "ARBEITSKREIS",',
'       v.vorschriftid,',
'       v.VORSCHRIFT_Nummer "VORSCHRIFTNUMMER",',
'       v.VORSCHRIFT_BEZEICHNUNG "VORSCHRIFTTITEL",  ',
'       m.STATUS, ',
'       to_char(m.LETZTE_AENDERUNG_DATUM,''dd.mm.yyyy hh24:mi'') as letzte_aenderung_datum ,',
'       grund,',
'       grund,',
'       m.BENACHRICHTIGUNG_text,',
'       (m.erstellung_datum +730) as loeschdatum,',
'       m.bearbeiterid,',
'       --(select  ab.nachname || '', '' || ab.vorname from t_benutzer ab where  ab.benutzerid = m.BETROFFENER_ANWENDER) as BETROFFENER_ANWENDER,',
'       case',
'        when REGEXP_LIKE (m.BETROFFENER_ANWENDER,''^[[:digit:]]+$'') ',
'        then (select  ab.nachname || '', '' || ab.vorname from t_benutzer ab where  ab.benutzerid = m.BETROFFENER_ANWENDER)',
'        else m.BETROFFENER_ANWENDER end as BETROFFENER_ANWENDER,',
'       STATUS_DMS,',
'STATUS_GMT,',
'STATUS_JIRA,',
'STATUS_REQMAN',
'       INTO :P615_AUSLOESER, :P615_ARBEITSKREIS, :P615_VORSCHRIFTID, :P615_VORSCHRIFT_NUMMER, :P615_VORSCHRIFTTITEL,:P615_STATUS, ',
'       :P615_LETZTE_AENDERUNG, :P615_GRUND,:P615_GRUNDID ,:P615_BENACHRICHTIGUNGSTEXT, :P615_LOESCHDATUM, :P615_BEARBEITER, :P615_BETROFFENER_ANWENDER,',
'       :P615_STATUS_DMS, :P615_GMT, :P615_JIRA, :P615_REQMAN',
'       ',
'from T_BENACHRICHTIGUNG m ',
'full Join T_Vorschrift v on v.vorschriftid = m.vorschriftid',
'inner Join T_ET_B_AK a on a.et_B_AKID = m.ARBEITSKREISID',
'left outer join t_benutzer b on (b.benutzerid = m.erstellung_benutzerid)',
'where BENACHRICHTIGUNGID= :P615_BENACHRICHTIGUNGID;  ',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2991432807479602735
);
wwv_flow_imp.component_end;
end;
/
