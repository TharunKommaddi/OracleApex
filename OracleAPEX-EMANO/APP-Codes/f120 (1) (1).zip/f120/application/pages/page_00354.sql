prompt --application/pages/page_00354
begin
--   Manifest
--     PAGE: 00354
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>354
,p_name=>unistr('\00C4nderungshistorie Verlinkte Normen')
,p_alias=>unistr('\00C4NDERUNGSHISTORIE-VERLINKTE-NORMEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('\00C4nderungshistorie Verlinkte Normen')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IR_HIST .t-fht-tbody {max-height: calc(100vh - 200px)}',
'.t-Body-topButton {display: none !important}',
'.t-Body-content {padding-bottom: 3px !important}',
'.t-Body {margin-bottom: 3px !important}',
'.t-Body-contentInner {padding-bottom: 0px !important}'))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(841486804305213545)
,p_plug_name=>'Historie Verlinkte Normen'
,p_region_name=>'IR_HIST'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select H_VERLINKTE_NORMID,',
'       VERLINKTE_NORMID,',
'       pck_ri_history.fdiff(v.VORSCHRIFT_NUMMER, LAG(v.VORSCHRIFT_NUMMER) over(partition by v.vorschriftid order by n.letzte_aenderung_datum asc)) as VORSCHRIFT,',
'       pck_ri_history.fdiff(n.nummer, LAG(n.nummer) over(partition by n.vorschriftid, n.VERLINKTE_NORMID order by n.letzte_aenderung_datum asc)) AS NORM_NUMMER,',
'       pck_ri_history.fdiff(n.bezeichnung, LAG(n.bezeichnung) over(partition by n.vorschriftid, n.VERLINKTE_NORMID order by n.letzte_aenderung_datum asc)) AS NORM_BEZEICHNUNG,',
'       ',
'       n.letzte_aenderung_datum as letzte_aenderung_datum,',
'       pck_ri.fCreatePermalinkUrl(n.vorschriftid) as PERMALINK,',
'       b.email as EMAIL,',
'       nvl2(n.letzte_aenderung_benutzerid, b.nachname || '', '' || b.vorname, null) AS LETZTE_AENDERUNG_BENUTZER',
'',
'from T_H_VERLINKTE_NORM n',
'left outer join t_benutzer b on (b.benutzerid = n.letzte_aenderung_benutzerid)',
'left outer join T_VORSCHRIFT v on (v.VORSCHRIFTID = n.VORSCHRIFTID)',
'where n.VORSCHRIFTID = :P354_VORSCHRIFTID',
'order by n.LETZTE_AENDERUNG_DATUM desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Historie Verlinkte Normen'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(841486727768213545)
,p_name=>'Historie Vorschrift Kerndaten'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>600
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'mailto:#EMAIL#?body=#PERMALINK#'
,p_detail_link_text=>'<span class="fa fa-envelope-o" aria-hidden="true"></span>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>271206209326920859
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1018776208931833341)
,p_db_column_name=>'EMAIL'
,p_display_order=>432
,p_column_identifier=>'AQ'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1018775785156833340)
,p_db_column_name=>'PERMALINK'
,p_display_order=>442
,p_column_identifier=>'AR'
,p_column_label=>'Permalink'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1018775433802833340)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>452
,p_column_identifier=>'AS'
,p_column_label=>unistr('\00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1018775006711833339)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>462
,p_column_identifier=>'AT'
,p_column_label=>unistr('\00C4nderung Datum')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1020290255286660172)
,p_db_column_name=>'H_VERLINKTE_NORMID'
,p_display_order=>472
,p_column_identifier=>'AU'
,p_column_label=>'H Verlinkte Normid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1020290140722660171)
,p_db_column_name=>'VERLINKTE_NORMID'
,p_display_order=>482
,p_column_identifier=>'AV'
,p_column_label=>'Verlinkte Normid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1020290072534660170)
,p_db_column_name=>'VORSCHRIFT'
,p_display_order=>492
,p_column_identifier=>'AW'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1020289958268660169)
,p_db_column_name=>'NORM_NUMMER'
,p_display_order=>502
,p_column_identifier=>'AX'
,p_column_label=>'Nummer der Norm'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1020289889656660168)
,p_db_column_name=>'NORM_BEZEICHNUNG'
,p_display_order=>512
,p_column_identifier=>'AY'
,p_column_label=>'Bezeichnung der Norm'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(841468553414200372)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'939191'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'H_VORSCHRIFTIDIDIDIDID_ENG_TYP:EINSATZDATUM_MODELL_BEZEICHNUNG:JIRA_TICKET_FREIGABESTATUS_STATUS:EMAIL:PERMALINK:LETZTE_AENDERUNG_BENUTZER:LETZTE_AENDERUNG_DATUM:H_VERLINKTE_NORMID:VERLINKTE_NORMID:VORSCHRIFT:NORM_NUMMER:NORM_BEZEICHNUNG'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1018773415370833326)
,p_name=>'P354_VORSCHRIFTID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(841486804305213545)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
