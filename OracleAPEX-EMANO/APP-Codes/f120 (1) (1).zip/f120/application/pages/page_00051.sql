prompt --application/pages/page_00051
begin
--   Manifest
--     PAGE: 00051
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>51
,p_name=>'461 Backup - before that succ - 07.11.2026'
,p_alias=>'461-BACKUP-BEFORE-THAT-SUCC-07-11-2026'
,p_step_title=>'461 Backup - before that succ - 07.11.2026'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var savepos;',
'',
'',
'',
'// Status configurations',
'const STATUS_CONFIGS = {',
'''not-started'': {',
'icon: ''<span class="fa fa-clock-o" style="font-size: 16px;"></span>'',',
unistr('title: ''Nicht begonnen - Klicken zum \00C4ndern'','),
'message: ''Nicht begonnen''',
'},',
'''in-progress'': {',
'icon: ''<span class="fa fa-spinner" style="font-size: 16px;"></span>'',',
unistr('title: ''In Bearbeitung - Klicken zum \00C4ndern'','),
'message: ''In Bearbeitung''',
'},',
'''completed'': {',
'icon: ''<span class="fa fa-check-circle" style="font-size: 16px;"></span>'',',
unistr('title: ''Bearbeitung abgeschlossen - Klicken zum \00C4ndern'','),
'message: ''Abgeschlossen''',
'}',
'};',
'',
'// Initialize status indicator',
'function initDetailPageStatus() {',
'const cardNum = $v(''P461_CARD_NUM'');',
'const status = $v(''P461_CARD_STATUS'') || ''not-started'';',
'',
'console.log(''Initializing status for card:'', cardNum, ''Status:'', status);',
'',
'// Find or create status indicator',
'let statusIndicator = document.querySelector(''.status-indicator'');',
'if (!statusIndicator) {',
'statusIndicator = document.createElement(''span'');',
'statusIndicator.className = ''status-indicator'';',
'',
'// Find download and back buttons',
'const downloadButton = document.getElementById(''DownloadExcelReport'');',
'const backButton = document.getElementById(''BACK_TO_OVERVIEW'');',
'',
'// Insert before download button',
'if (downloadButton) {',
'    const buttonContainer = downloadButton.closest(''.a-IRR-buttons'');',
'    if (buttonContainer) {',
'        ',
'        buttonContainer.insertBefore(statusIndicator, downloadButton);',
'    }',
'} else if (backButton) {',
'',
'    backButton.after(statusIndicator);',
'} else {',
'',
'    const buttonContainer = document.querySelector(''.a-IRR-buttons'');',
'    if (buttonContainer) {',
'        buttonContainer.prepend(statusIndicator);',
'    } else {',
'        document.body.prepend(statusIndicator);',
'    }',
'}',
'}',
'',
'// Update indicator',
'statusIndicator.classList.remove(''not-started'', ''in-progress'', ''completed'');',
'statusIndicator.classList.add(status);',
'statusIndicator.setAttribute(''data-card'', cardNum);',
'',
'// Set icon and title',
'const config = STATUS_CONFIGS[status];',
'statusIndicator.innerHTML = config.icon;',
'statusIndicator.title = config.title;',
'',
'statusIndicator.onclick = () => cycleDetailStatus(cardNum);',
'',
'console.log(''Status indicator initialized'');',
'}',
'',
'function cycleDetailStatus(cardNumber) {',
'const statusIndicator = document.querySelector(''.status-indicator'');',
'if (!statusIndicator) {',
'console.error(''Status indicator not found'');',
'return;',
'}',
'',
'// Determine current and next status',
'const currentStatus = ',
'statusIndicator.classList.contains(''not-started'') ? ''not-started'' : ',
'statusIndicator.classList.contains(''in-progress'') ? ''in-progress'' : ',
'''completed'';',
'',
'const statusOrder = [''not-started'', ''in-progress'', ''completed''];',
'const currentIndex = statusOrder.indexOf(currentStatus);',
'const nextStatus = statusOrder[(currentIndex + 1) % statusOrder.length];',
'',
'console.log(`Cycling status from ${currentStatus} to ${nextStatus}`);',
'',
'statusIndicator.classList.remove(''not-started'', ''in-progress'', ''completed'');',
'statusIndicator.classList.add(nextStatus);',
'',
'// Update icon and title',
'const config = STATUS_CONFIGS[nextStatus];',
'statusIndicator.innerHTML = config.icon;',
'statusIndicator.title = config.title;',
'',
'apex.item(''P461_CARD_STATUS'').setValue(nextStatus);',
'console.log(`Page item P461_CARD_STATUS set to: ${nextStatus}`);',
'',
'// Save to database',
'saveDetailStatus(cardNumber, nextStatus);',
'}',
'',
'',
'',
'function saveDetailStatus(cardNumber, status) {',
'console.log(`Saving status for card ${cardNumber}: ${status}`);',
'',
'let msgTimeout = apex.item("P461_MSG_TIMEOUT").getValue();',
'if (!msgTimeout || isNaN(msgTimeout)) {',
'    msgTimeout = 3;',
'}',
'',
'apex.server.process(',
'    ''UPDATE_CARD_STATUS'',',
'    {',
'        x01: cardNumber,',
'        x02: status,',
'        x03: $v(''P461_SEARCH_SELECTION''),',
'        x04: $v(''P461_MILESTONE_SELECTION'')',
'    },',
'    {',
'        success: function(data) {',
'            const config = STATUS_CONFIGS[status];',
'            $(''.t-Alert--success'').remove();',
'            apex.message.showPageSuccess(`Karte ${cardNumber} Status aktualisiert: ${config.message}`);',
'            ',
'            setTimeout(function() {',
'                $(''.t-Alert--success'').fadeOut(function() { $(this).remove(); });',
'            }, msgTimeout * 1000);',
'            ',
'            $s(''P461_CARD_STATUS'', status);',
'            $s(''P460_JUST_UPDATED_CARD'', cardNumber);',
'            $s(''P460_JUST_UPDATED_STATUS'', status);',
'        },',
'        error: function(xhr, status, error) {',
'            console.error(''Error updating card status:'', error);',
'            // **THIS IS THE FIX**: Changed showPageError to showErrors',
'            apex.message.showErrors([{',
'                type: "error",',
'                location: "page",',
'                message: "Fehler beim Aktualisieren des Status: " + error,',
'                unsafe: false',
'            }]);',
'        },',
'        dataType: "json" // This was missing and is CRITICAL',
'    }',
');',
'}',
'',
'',
'// Card Download Function',
'function downloadCardData(landids) {',
'if (!landids) {',
'console.error(''No landids provided for download'');',
'return;',
'}',
'',
'// Use P461_LANDIDS if no landids parameter is provided',
'if (!landids) {',
'landids = $v(''P461_LANDIDS'');',
'}',
'',
'// Check again if we have landids',
'if (!landids) {',
'console.error(''No landids available for download'');',
'apex.message.showPageError(''No country data available for download'');',
'return;',
'}',
'',
'console.log(''Initiating download with landids:'', landids);',
'',
'const url = ''wwv_flow.show'';',
'const params = {',
'p_request: ''APPLICATION_PROCESS=DOWNLOAD_CARD_DATA'',',
'p_flow_id: $v(''pFlowId''),',
'p_flow_step_id: $v(''pFlowStepId''),',
'p_instance: $v(''pInstance''),',
'x01: landids,',
'x02: $v(''P461_SEARCH_SELECTION''),',
'x03: $v(''P461_MILESTONE_SELECTION'')',
'};',
'',
'const $form = $(''<form>'', {',
'action: url,',
'method: ''POST'',',
'target: ''_blank''',
'});',
'',
'$.each(params, function (key, value) {',
'$form.append($(''<input>'', {',
'    type: ''hidden'',',
'    name: key,',
'    value: value',
'}));',
'});',
'',
'$(''body'').append($form);',
'$form.submit();',
'$form.remove();',
'console.log(''Download form submitted with landids: '' + landids);',
'}',
'',
'',
'// Sets up header truncation for page 461',
'',
'function setupPage461HeaderTruncation() {',
'console.log(''Running header truncation function'');',
'',
'// Find the title element',
'const titleElement = document.querySelector(''.t-Region-title'');',
'if (!titleElement) {',
'console.log(''Title element not found'');',
'return;',
'}',
'',
'// Check if title editing is already applied',
'if (titleElement.querySelector(''.title-container'')) {',
'console.log(''Title editing already set up, skipping truncation'');',
'return; // Exit early to avoid conflicts',
'}',
'',
'// Get title text content',
'const fullText = titleElement.textContent.trim();',
'console.log(''Title text:'', fullText);',
'',
'// Check if it contains country list (with semicolons)',
'if (fullText && fullText.includes('';'')) {',
'// Split by semicolons',
'const countries = fullText.split('';'').map(c => c.trim()).filter(c => c);',
'console.log(''Found countries:'', countries);',
'',
'const totalCount = countries.length;',
'console.log(''Total countries:'', totalCount);',
'',
'// Only truncate if more than 2 countries',
'if (totalCount > 2) {',
'console.log(''Truncating to 2 countries'');',
'',
'// Create truncated with first 2 countries',
'const truncatedText = countries.slice(0, 2).join(''; '');',
'',
'// Store the full list for later',
'titleElement.setAttribute(''data-full-list'', fullText);',
'',
'// Update HTML with show more button',
'titleElement.innerHTML = truncatedText + ',
''' <span class="show-more-btn" style="color: #bb0a31; cursor: pointer; display: inline-block; vertical-align: middle; margin-left: 5px; font-size: 13px; white-space: nowrap; margin-bottom: 5px; border: 1px solid #e0e0e0; padding: 2px 6px; border-radiu'
||'s: 3px">'' +',
unistr('''<i class="fa fa-plus-circle" style="margin-right: 4px; vertical-align: middle; position: relative; top: -1px;"></i> alle L\00E4nder anzeigen ('' + totalCount + '')'' +'),
'''</span>'';',
'',
'// click event to the show more button',
'const showMoreBtn = titleElement.querySelector(''.show-more-btn'');',
'if (showMoreBtn) {',
'showMoreBtn.onclick = function(e) {',
'e.stopPropagation();',
'e.preventDefault();',
'',
'console.log(''Show more clicked'');',
'',
'// Show full list with show less button',
'titleElement.innerHTML = fullText + ',
'    '' <span class="show-less-btn" style="color: #bb0a31; cursor: pointer; display: inline-block; vertical-align: middle; margin-left: 5px; font-size: 13px; white-space: nowrap; margin-bottom: 5px; border: 1px solid #e0e0e0; padding: 2px 6px; border-r'
||'adius: 3px">'' +',
unistr('    ''<i class="fa fa-minus-circle" style="margin-right: 4px; vertical-align: middle; position: relative; top: -1px;"></i> weniger L\00E4nder anzeigen'' +'),
'    ''</span>'';',
'',
'// click event to the show less button',
'const showLessBtn = titleElement.querySelector(''.show-less-btn'');',
'if (showLessBtn) {',
'    showLessBtn.onclick = function(e) {',
'        e.stopPropagation();',
'        e.preventDefault();',
'        ',
'        console.log(''Show less clicked'');',
'        ',
'        // Restore truncated view',
'        titleElement.innerHTML = truncatedText + ',
'            '' <span class="show-more-btn" style="color: #bb0a31; cursor: pointer; display: inline-block; vertical-align: middle; margin-left: 5px; font-size: 13px; white-space: nowrap; margin-bottom: 5px; border: 1px solid #e0e0e0; padding: 2px 6px; '
||'border-radius: 3px">'' +',
unistr('            ''<i class="fa fa-plus-circle" style="margin-right: 4px; vertical-align: middle; position: relative; top: -1px;"></i> alle L\00E4nder anzeigen ('' + totalCount + '')'' +'),
'            ''</span>'';',
'        ',
'        // Restore click handler for show more',
'        const newShowMoreBtn = titleElement.querySelector(''.show-more-btn'');',
'        if (newShowMoreBtn) {',
'            newShowMoreBtn.onclick = showMoreBtn.onclick;',
'        }',
'    };',
'}',
'};',
'}',
'}',
'}',
'}',
'',
'',
'/**',
' * Title editing for page 461',
' * This function is modified to display countries on a new line after the custom title',
' */',
'function addTitleEditingToPage461() {',
'console.log(''Setting up title editing for page 461'');',
'',
'// Find the title element',
'const titleElement = document.querySelector(''.t-Region-title'');',
'if (!titleElement) {',
'console.log(''Title element not found for editing'');',
'return;',
'}',
'',
'// Get current card number from page item',
'const cardNumber = $v(''P461_CARD_NUM'');',
'if (!cardNumber) {',
'console.log(''Card number not found in page item'');',
'return;',
'}',
'',
'// Check if setup is already done to prevent duplicate processing',
'if (titleElement.querySelector(''.title-container'')) {',
'console.log(''Title editing already set up'');',
'return;',
'}',
'',
'// Check if custom title exists from passed parameter',
'let customTitle = $v(''P461_CUSTOM_TITLE'') || '''';',
'console.log(''Retrieved custom title:'', customTitle);',
'',
'// Save full text before we modify anything',
'let originalTitle = titleElement.textContent.trim();',
'let fullText = originalTitle;',
'',
'// If header truncation has already been applied, get the full list',
'if (titleElement.hasAttribute(''data-full-list'')) {',
'fullText = titleElement.getAttribute(''data-full-list'');',
'console.log(''Retrieved full country list from truncation:'', fullText);',
'}',
'',
'// Clear the title element to prepare for the new container',
'titleElement.innerHTML = '''';',
'',
'// Create a container for the title that we can manipulate',
'const titleContainer = document.createElement(''div'');',
'titleContainer.id = ''title-container-'' + cardNumber;',
'titleContainer.className = ''title-container'';',
'titleContainer.style.display = ''flex'';',
'titleContainer.style.flexDirection = ''column''; // Changed to column layout',
'titleContainer.style.width = ''100%'';',
'',
'// Create a top row for edit icons and custom title',
'const topRow = document.createElement(''div'');',
'topRow.className = ''title-top-row'';',
'topRow.style.display = ''flex'';',
'topRow.style.alignItems = ''center'';',
'topRow.style.marginBottom = ''8px''; // Space between rows',
'topRow.style.width = ''100%''; // to take full width',
'topRow.style.justifyContent = ''flex-start''; // Align contents to the left',
'',
'// Create edit icon',
'const editIcon = document.createElement(''span'');',
'editIcon.className = ''edit-icon'';',
'editIcon.title = ''Title bearbeiten'';',
'editIcon.innerHTML = ''<span class="fa fa-edit" style="font-size: 14px; color: #666;"></span>'';',
'editIcon.onclick = function() {',
'makeEditable(cardNumber);',
'};',
'',
'// Create reset icon (only visible when custom title exists)',
'const resetIcon = document.createElement(''span'');',
'resetIcon.className = ''reset-icon'';',
unistr('resetIcon.title = ''Zur\00FCcksetzen auf Standardtitel'';'),
'resetIcon.innerHTML = ''<span class="fa fa-trash" style="font-size: 14px; color: #666;"></span>'';',
'resetIcon.onclick = function() {',
'resetTitle(cardNumber, fullText);',
'};',
'resetIcon.style.display = customTitle ? '''' : ''none'';',
'',
'// Create custom title indicator (if exists)',
'let customTitleIndicator = null;',
'if (customTitle) {',
'customTitleIndicator = document.createElement(''div'');',
'customTitleIndicator.className = ''custom-title-indicator'';',
'customTitleIndicator.textContent = customTitle;',
'customTitleIndicator.style.textAlign = ''left''; // Align text to the left',
'customTitleIndicator.style.width = ''auto''; ',
'customTitleIndicator.style.marginLeft = ''8px''; // Add some spacing after icons',
'}',
'',
'// Add icons and custom title to top row',
'topRow.appendChild(editIcon);',
'topRow.appendChild(resetIcon);',
'if (customTitleIndicator) {',
'topRow.appendChild(customTitleIndicator);',
'}',
'',
'// Create a bottom row for the country list',
'const bottomRow = document.createElement(''div'');',
'bottomRow.className = ''title-bottom-row'';',
'bottomRow.style.width = ''100%'';',
'',
'// Create a span to hold the title text (countries)',
'const titleText = document.createElement(''span'');',
'titleText.id = ''card-title-'' + cardNumber;',
'titleText.className = ''title-text'';',
'titleText.textContent = fullText;',
'titleText.setAttribute(''data-custom-title'', customTitle || '''');',
'titleText.setAttribute(''data-original-title'', fullText);',
'titleText.setAttribute(''data-full-list'', fullText);',
'',
'// Add countries list to the bottom row',
'bottomRow.appendChild(titleText);',
'',
'// add both rows to the container',
'titleContainer.appendChild(topRow);',
'titleContainer.appendChild(bottomRow);',
'',
'// Replace the original title with our new container',
'titleElement.appendChild(titleContainer);',
'',
'// After we''ve set up title editing, apply truncation',
'applyTruncationToTitleText(titleText);',
'}',
'',
'/**',
' * card title editable for page 461',
' * ',
' */',
'function makeEditable(cardNumber) {',
'const titleContainer = document.getElementById(''title-container-'' + cardNumber);',
'if (!titleContainer) {',
'console.error(''Title container not found for card '' + cardNumber);',
'return;',
'}',
'',
'const titleText = document.getElementById(''card-title-'' + cardNumber);',
'const topRow = titleContainer.querySelector(''.title-top-row'');',
'const bottomRow = titleContainer.querySelector(''.title-bottom-row'');',
'',
'if (!titleText || !topRow || !bottomRow) {',
'console.error(''Required elements not found for card '' + cardNumber);',
'return;',
'}',
'',
'// Check if we''re already in edit mode',
'if (document.getElementById(''edit-title-'' + cardNumber)) {',
'return; // Already in edit mode',
'}',
'',
'// Get the custom title',
'const customTitle = titleText.getAttribute(''data-custom-title'') || '''';',
'',
'// Hide elements in top row',
'const editIcon = titleContainer.querySelector(''.edit-icon'');',
'const resetIcon = titleContainer.querySelector(''.reset-icon'');',
'const customTitleIndicator = titleContainer.querySelector(''.custom-title-indicator'');',
'',
'if (editIcon) editIcon.style.display = ''none'';',
'if (resetIcon) resetIcon.style.display = ''none'';',
'if (customTitleIndicator) customTitleIndicator.style.display = ''none'';',
'',
'// Hide the show-more and show-less buttons if present',
'const showMoreBtn = titleText.querySelector(''.show-more-btn'');',
'const showLessBtn = titleText.querySelector(''.show-less-btn'');',
'if (showMoreBtn) showMoreBtn.style.display = ''none'';',
'if (showLessBtn) showLessBtn.style.display = ''none'';',
'',
'// Create edit controls for the top row',
'const editInput = document.createElement(''input'');',
'editInput.type = ''text'';',
'editInput.id = ''edit-title-'' + cardNumber;',
'editInput.className = ''title-edit-input'';',
'editInput.value = customTitle;',
'editInput.placeholder = ''Titel eingeben'';',
'',
'const saveButton = document.createElement(''span'');',
'saveButton.className = ''save-icon'';',
'saveButton.setAttribute(''title'', ''Speichern'');',
'saveButton.innerHTML = ''<span class="fa fa-save" style="font-size: 14px; color: #bb0a31;"></span>'';',
'saveButton.onclick = function() {',
'saveTitle(cardNumber);',
'};',
'',
'const cancelButton = document.createElement(''span'');',
'cancelButton.className = ''cancel-icon'';',
'cancelButton.setAttribute(''title'', ''Abbrechen'');',
'cancelButton.innerHTML = ''<span class="fa fa-times" style="font-size: 14px; color: #666;"></span>'';',
'cancelButton.onclick = function() {',
'cancelTitleEdit(cardNumber);',
'};',
'',
'// Insert at the beginning of the top row',
'topRow.insertBefore(cancelButton, topRow.firstChild);',
'topRow.insertBefore(saveButton, topRow.firstChild);',
'topRow.insertBefore(editInput, topRow.firstChild);',
'',
'// Add Enter key handler',
'editInput.addEventListener(''keydown'', function(e) {',
'if (e.key === ''Enter'') {',
'    saveTitle(cardNumber);',
'    e.preventDefault();',
'}',
'});',
'',
'// Focus input',
'editInput.focus();',
'}',
'',
'/**',
' * Cancel title edit mode for page 461',
' */',
'function cancelTitleEdit(cardNumber) {',
'const titleContainer = document.getElementById(''title-container-'' + cardNumber);',
'if (!titleContainer) return;',
'',
'const topRow = titleContainer.querySelector(''.title-top-row'');',
'const titleText = document.getElementById(''card-title-'' + cardNumber);',
'',
'if (!topRow || !titleText) {',
'console.error(''Required elements not found for canceling edit'');',
'return;',
'}',
'',
'// Remove the editing elements',
'const editInput = document.getElementById(''edit-title-'' + cardNumber);',
'const saveButton = topRow.querySelector(''.save-icon'');',
'const cancelButton = topRow.querySelector(''.cancel-icon'');',
'',
'if (editInput) editInput.remove();',
'if (saveButton) saveButton.remove();',
'if (cancelButton) cancelButton.remove();',
'',
'// Show the edit icon',
'const editIcon = topRow.querySelector(''.edit-icon'');',
'if (editIcon) editIcon.style.display = '''';',
'',
'// Show the reset icon if a custom title exists',
'if (titleText && titleText.getAttribute(''data-custom-title'')) {',
'const resetIcon = topRow.querySelector(''.reset-icon'');',
'if (resetIcon) resetIcon.style.display = '''';',
'}',
'',
'// Show the custom title indicator if it exists',
'const customTitleIndicator = topRow.querySelector(''.custom-title-indicator'');',
'if (customTitleIndicator) {',
'customTitleIndicator.style.display = '''';',
'}',
'',
'// Re-apply truncation if needed',
'applyTruncationToTitleText(titleText);',
'}',
'',
'/**',
' * Save the custom title for page 461',
' */',
'function saveTitle(cardNumber) {',
'const editInput = document.getElementById(''edit-title-'' + cardNumber);',
'if (!editInput) {',
'console.error(''Edit input not found for card '' + cardNumber);',
'return;',
'}',
'',
'const newTitle = editInput.value.trim();',
'const titleContainer = document.getElementById(''title-container-'' + cardNumber);',
'const titleText = document.getElementById(''card-title-'' + cardNumber);',
'const topRow = titleContainer.querySelector(''.title-top-row'');',
'',
'if (!titleContainer || !titleText || !topRow) {',
'console.error(''Required elements not found for card '' + cardNumber);',
'return;',
'}',
'',
'// Show saving indicator',
'const saveIcon = topRow.querySelector(''.save-icon .fa'');',
'if (saveIcon) {',
'saveIcon.className = ''fa fa-spinner fa-spin'';',
'}',
'',
'apex.server.process(',
'''SAVE_CARD_TITLE'',',
'{',
'    x01: cardNumber,',
'    x02: newTitle',
'},',
'{',
'    success: function(data) {',
'        // Update data attribute',
'        titleText.setAttribute(''data-custom-title'', newTitle);',
'        ',
'        // Remove editing controls',
'        const editInput = document.getElementById(''edit-title-'' + cardNumber);',
'        const saveButton = topRow.querySelector(''.save-icon'');',
'        const cancelButton = topRow.querySelector(''.cancel-icon'');',
'        ',
'        if (editInput) editInput.remove();',
'        if (saveButton) saveButton.remove();',
'        if (cancelButton) cancelButton.remove();',
'        ',
'        // Show the edit icon',
'        const editIcon = topRow.querySelector(''.edit-icon'');',
'        if (editIcon) editIcon.style.display = '''';',
'        ',
'        // Handle custom title indicator',
'        if (newTitle) {',
'            // Find or create custom title indicator',
'            let customTitleIndicator = topRow.querySelector(''.custom-title-indicator'');',
'            if (!customTitleIndicator) {',
'                customTitleIndicator = document.createElement(''div'');',
'                customTitleIndicator.className = ''custom-title-indicator'';',
'                ',
'                // Insert after edit and reset icons',
'                const resetIcon = topRow.querySelector(''.reset-icon'');',
'                if (resetIcon) {',
'                    topRow.insertBefore(customTitleIndicator, resetIcon.nextSibling);',
'                } else if (editIcon) {',
'                    topRow.insertBefore(customTitleIndicator, editIcon.nextSibling);',
'                } else {',
'                    topRow.insertBefore(customTitleIndicator, topRow.firstChild);',
'                }',
'            } else {',
'                customTitleIndicator.style.display = '''';',
'            }',
'            ',
'            // Update custom title text',
'            customTitleIndicator.textContent = newTitle;',
'            ',
'            // Show reset icon',
'            const resetIcon = topRow.querySelector(''.reset-icon'');',
'            if (resetIcon) resetIcon.style.display = '''';',
'        } else {',
'            // Remove custom title indicator if title is empty',
'            const customTitleIndicator = topRow.querySelector(''.custom-title-indicator'');',
'            if (customTitleIndicator) {',
'                customTitleIndicator.remove();',
'            }',
'            ',
'            // Hide reset icon if title is empty',
'            const resetIcon = topRow.querySelector(''.reset-icon'');',
'            if (resetIcon) resetIcon.style.display = ''none'';',
'        }',
'        ',
'        // Show success message',
'        apex.message.showPageSuccess(''Title updated successfully'');',
'        ',
'        // Update P461_CUSTOM_TITLE item for passing back to page 460',
'        apex.item(''P461_CUSTOM_TITLE'').setValue(newTitle);',
'        ',
'        // Re-apply truncation if needed',
'        applyTruncationToTitleText(titleText);',
'    },',
'    error: function(xhr, status, error) {',
'        console.error("AJAX Error:", error);',
'        console.error("Response Text:", xhr.responseText);',
'        apex.message.showPageError("Error saving title: " + error);',
'        ',
'        // Restore save icon',
'        if (saveIcon) {',
'            saveIcon.className = ''fa fa-save'';',
'        }',
'    },',
'    dataType: "json"',
'}',
');',
'}',
'',
'/**',
' * Reset the title for page 461',
' */',
'function resetTitle(cardNumber, originalTitle) {',
'const titleContainer = document.getElementById(''title-container-'' + cardNumber);',
'if (!titleContainer) {',
'console.error(''Title container not found for card '' + cardNumber);',
'return;',
'}',
'',
'const topRow = titleContainer.querySelector(''.title-top-row'');',
'',
'console.log(''Resetting title for card'', cardNumber, ''to original:'', originalTitle);',
'',
'// Show spinner on reset icon',
'const resetIcon = topRow.querySelector(''.reset-icon .fa'');',
'if (resetIcon) {',
'resetIcon.className = ''fa fa-spinner fa-spin'';',
'}',
'',
'apex.server.process(',
'''SAVE_CARD_TITLE'',',
'{',
'    x01: cardNumber,',
'    x02: '''', ',
'    x03: ''RESET'' ',
'},',
'{',
'    success: function(data) {',
'        console.log(''Reset title success for card'', cardNumber);',
'        ',
'        // Clear custom title',
'        const titleText = document.getElementById(''card-title-'' + cardNumber);',
'        if (titleText) {',
'            titleText.setAttribute(''data-custom-title'', '''');',
'            ',
'            // Reset to original title',
'            titleText.textContent = originalTitle;',
'        }',
'        ',
'        // Remove custom title indicator',
'        const customTitleIndicator = topRow.querySelector(''.custom-title-indicator'');',
'        if (customTitleIndicator) {',
'            customTitleIndicator.remove();',
'        }',
'        ',
'        // Hide reset icon',
'        const resetIcon = topRow.querySelector(''.reset-icon'');',
'        if (resetIcon) {',
'            resetIcon.style.display = ''none'';',
'        }',
'        ',
'        // Show success message',
'        apex.message.showPageSuccess(''Title reset to default'');',
'        ',
'        // Update P461_CUSTOM_TITLE item for passing back to page 460',
'        apex.item(''P461_CUSTOM_TITLE'').setValue('''');',
'        ',
'        // Re-apply the header truncation',
'        applyTruncationToTitleText(titleText);',
'    },',
'    error: function(xhr, status, error) {',
'        console.error("Reset Error:", error);',
'        console.error("Response Text:", xhr.responseText);',
'        apex.message.showPageError("Error resetting title: " + error);',
'        ',
'        // Restore reset icon',
'        if (resetIcon) {',
'            resetIcon.className = ''fa fa-trash'';',
'        }',
'    },',
'    dataType: "json"',
'}',
');',
'}',
'',
'/**',
' * Apply truncation to the title text element',
' */',
'function applyTruncationToTitleText(titleTextElement) {',
'if (!titleTextElement) return;',
'',
'// If there''s an edit input visible, don''t apply truncation',
'const cardNumber = titleTextElement.id.replace(''card-title-'', '''');',
'if (document.getElementById(''edit-title-'' + cardNumber)) {',
'return;',
'}',
'',
'// Get the text content to truncate',
'const fullText = titleTextElement.getAttribute(''data-full-list'') || titleTextElement.textContent;',
'if (!fullText || !fullText.includes('';'')) return;',
'',
'// Parse countries (preserve any newlines in the format)',
'const countries = fullText.split('';'').map(c => c.trim()).filter(c => c);',
'const totalCount = countries.length;',
'',
'// Only apply truncation if more than 2 countries',
'if (totalCount > 2) {',
'// Create truncated content',
'const truncatedText = countries.slice(0, 2).join(''; '');',
'',
'// Update with truncated content and show-more button',
'titleTextElement.innerHTML = truncatedText + ',
'    '' <span class="show-more-btn" style="color: #bb0a31; cursor: pointer; display: inline-block; vertical-align: middle; margin-left: 5px; font-size: 13px; white-space: nowrap; margin-bottom: 5px; border: 1px solid #e0e0e0; padding: 2px 6px; border-r'
||'adius: 3px">'' +',
unistr('    ''<i class="fa fa-plus-circle" style="margin-right: 4px; vertical-align: middle; position: relative; top: -1px;"></i> alle L\00E4nder anzeigen ('' + totalCount + '')'' +'),
'    ''</span>'';',
'',
'// Add click event to the show more button',
'const showMoreBtn = titleTextElement.querySelector(''.show-more-btn'');',
'if (showMoreBtn) {',
'    showMoreBtn.onclick = function(e) {',
'        e.stopPropagation();',
'        e.preventDefault();',
'        ',
'        // Show full content',
'        titleTextElement.innerHTML = fullText + ',
'            '' <span class="show-less-btn" style="color: #bb0a31; cursor: pointer; display: inline-block; vertical-align: middle; margin-left: 5px; font-size: 13px; white-space: nowrap; margin-bottom: 5px; border: 1px solid #e0e0e0; padding: 2px 6px; '
||'border-radius: 3px">'' +',
unistr('            ''<i class="fa fa-minus-circle" style="margin-right: 4px; vertical-align: middle; position: relative; top: -1px;"></i> weniger L\00E4nder anzeigen'' +'),
'            ''</span>'';',
'        ',
'        // Add click for show less',
'        const showLessBtn = titleTextElement.querySelector(''.show-less-btn'');',
'        if (showLessBtn) {',
'            showLessBtn.onclick = function(e) {',
'                e.stopPropagation();',
'                e.preventDefault();',
'                ',
'                // Back to truncated view',
'                titleTextElement.innerHTML = truncatedText + ',
'                    '' <span class="show-more-btn" style="color: #bb0a31; cursor: pointer; display: inline-block; vertical-align: middle; margin-left: 5px; font-size: 13px; white-space: nowrap; margin-bottom: 5px; border: 1px solid #e0e0e0; padding: 2'
||'px 6px; border-radius: 3px">'' +',
unistr('                    ''<i class="fa fa-plus-circle" style="margin-right: 4px; vertical-align: middle; position: relative; top: -1px;"></i> alle L\00E4nder anzeigen ('' + totalCount + '')'' +'),
'                    ''</span>'';',
'                ',
'                // Restore click handler',
'                const newShowMoreBtn = titleTextElement.querySelector(''.show-more-btn'');',
'                if (newShowMoreBtn) {',
'                    newShowMoreBtn.onclick = showMoreBtn.onclick;',
'                }',
'            };',
'        }',
'    };',
'}',
'}',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'// Delete confirmation function',
'function confirmDeleteCard(cardNumber, specificRegId) {',
'apex.message.confirm(',
unistr('    ''Soll der manuelle Eintrag gel\00F6scht werden?'','),
'    function(isOk) {',
'        if (isOk) {',
'            deleteManualEntry(cardNumber, specificRegId);',
'        }',
'    }',
');',
'}',
'',
'// Delete function',
'function deleteManualEntry(cardNumber, specificRegId) {',
'apex.server.process(',
'    ''DELETE_MANUAL_ENTRY'',',
'    {',
'        x01: cardNumber,',
'        x02: $v(''P461_SEARCH_SELECTION''),',
'        x03: $v(''P461_MILESTONE_SELECTION''),',
'        x04: specificRegId',
'    },',
'    {',
'        success: function(data) {',
'            if (data.status === ''success'') {',
unistr('                apex.message.showPageSuccess(''Eintrag erfolgreich gel\00F6scht'');'),
'                // Refresh the region',
'                apex.region(''R45756756756575'').refresh();',
'            } else {',
'                apex.message.showPageError(''Fehler: '' + data.message);',
'            }',
'        },',
'        error: function(xhr, status, error) {',
unistr('            apex.message.showPageError(''Fehler beim L\00F6schen: '' + error);'),
'        },',
'        dataType: ''json''',
'    }',
');',
'}',
'',
'',
'',
'',
'/* beginn - check Box */',
'',
unistr('/* Erm\00F6glicht bei APEX-Checkbox-Items einen Quicklink um alle auszuw\00E4hlen */'),
'function fSelectAll(elem) {',
'',
'    var apexItem = $(elem).closest(''.t-Form-fieldContainer'');',
'    var itemValue = apexItem.find(''input'').map(function() {',
'        return this.value;',
'    }).get().join('':'');',
'    var itemName = apexItem.find(''label'').attr(''for'');',
'    $s(itemName,itemValue);',
'',
'}',
'',
'',
'/* Click auf Checkbox in Tabellenheader: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'// Checkbox handling for bulk operations',
'$(''#R45756756756575'').on(''click'', ''th input'', function() {',
'    var check_all = $("#R45756756756575").find("th input:checked").is(":checked");',
'',
unistr('    // alle Zeilen ausw\00E4hlen/abw\00E4hlen'),
'    $("#R45756756756575").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'    // Button aktivieren/deaktivieren',
'    if (check_all) {',
'        $("#b_mass_update").removeClass("apex_disabled");',
'    } else {',
'        $("#b_mass_update").addClass("apex_disabled");',
'    }',
'',
'    $("#b_mass_update").prop(''disabled'', !check_all);',
'',
unistr('    // alle ausgew\00E4hlten Zeilen-IDs in das Item P461_SELECTED_ROWS'),
'    var sel_rows = apex.item(''P461_SELECTED_ROWS'');',
'    sel_rows.setValue("");',
'    $("#R45756756756575").find("td input:checked").each(function() {',
'      if(sel_rows.getValue().length > 0) {',
'        sel_rows.setValue(sel_rows.getValue() + ":");    ',
'      }',
'      sel_rows.setValue(sel_rows.getValue() + this.value);',
'    });',
'    apex.server.process(''MY_PROCESS'', {',
'        pageItems: ''#P461_SELECTED_ROWS''',
'    },{dataType: ''text''});',
'});',
'',
'',
'',
'/* ende - check Box */',
'',
'',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(document).ready(function() {',
'    console.log(''Page 461 - Document ready'');',
'    ',
'    // Initialize the status indicator',
'    try {',
'        initDetailPageStatus();',
'    } catch (error) {',
'        console.error(''Error initializing status:'', error);',
'    }',
'    ',
'    if (!apex.item("P461_MSG_TIMEOUT").node) {',
'        console.log("Creating hidden P461_MSG_TIMEOUT item");',
'        ',
'        const timeoutInput = document.createElement(''input'');',
'        timeoutInput.type = ''hidden'';',
'        timeoutInput.id = ''P461_MSG_TIMEOUT'';',
'        timeoutInput.name = ''P461_MSG_TIMEOUT'';',
'        timeoutInput.value = ''3''; ',
'        ',
'        document.body.appendChild(timeoutInput);',
'    }',
'    ',
'    console.log("P461_LANDIDS value:", $v("P461_LANDIDS"));',
'    console.log("P461_LANDIDS length:", $v("P461_LANDIDS").length);',
'    console.log("Contains colons?", $v("P461_LANDIDS").includes(";"));',
'    var landIds = $v("P461_LANDIDS").split(";");',
'    console.log("Number of land IDs:", landIds.length);',
'    console.log("Land IDs array:", landIds);',
'    ',
'    // Get the card title value',
'    console.log("P461_CARD_TITLE value:", $v("P461_CARD_TITLE"));',
'    apex.server.process(',
'        "GET_CARD_TITLE",',
'        {',
'            x01: $v("P461_LANDIDS")',
'        },',
'        {',
'            success: function(data) {',
'                console.log("Query result:", data);',
'            },',
'            error: function(jqXHR, textStatus, errorThrown) {',
'                console.error("Error executing query:", textStatus, errorThrown);',
'            }',
'        }',
'    );',
'    ',
'    // Call ONLY addTitleEditingToPage461()',
'    addTitleEditingToPage461();',
'    ',
'    // Handle page refreshes',
'    $(document).on(''apexafterrefresh'', function() {',
'        console.log(''Page refreshed, running setup again'');',
'        // Call ONLY addTitleEditingToPage461() on refresh',
'        addTitleEditingToPage461();',
'    });',
'});',
'',
'',
'',
'/*********** */',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/**********************************************************',
' * Countries Header List Expand or Collapse',
' **********************************************************/',
'',
'.show-more-btn, .show-less-btn {',
'    color: #bb0a31; ',
'    cursor: pointer; ',
'    display: inline-block; ',
'    vertical-align: middle; ',
'    margin-left: 5px; ',
'    font-size: 13px; ',
'    white-space: nowrap; ',
'    margin-bottom: 5px; ',
'    border: 1px solid #e0e0e0; ',
'    padding: 2px 6px; ',
'    border-radius: 3px;',
'}',
'',
'.show-more-btn:hover, .show-less-btn:hover {',
'    color: #d01a45;',
'    background-color: #efefef;',
'    border-color: #ccc;',
'    text-decoration: underline;',
'}',
'',
'/**********************************************************',
' * Card Title Editing',
' **********************************************************/',
'',
'.title-container {',
'    display: flex;',
'    flex-wrap: wrap;',
'    align-items: center;',
'    flex-grow: 1;',
'    overflow: hidden;',
'}',
'',
'.edit-icon, .reset-icon, .save-icon, .cancel-icon {',
'    cursor: pointer;',
'    padding: 4px;',
'    margin-right: 4px;',
'    border-radius: 50%;',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    background-color: #f5f5f5;',
'    width: 24px;',
'    height: 24px;',
'    transition: all 0.2s;',
'    flex-shrink: 0;',
'}',
'',
'.edit-icon:hover, .reset-icon:hover, .save-icon:hover, .cancel-icon:hover {',
'    background-color: #e0e0e0;',
'    transform: scale(1.1);',
'}',
'',
'.custom-title-indicator {',
'    font-weight: bold;',
'    color: #2563EB;',
'    background-color: rgba(37, 99, 235, 0.08);',
'    padding: 4px 10px;',
'    margin-right: 10px;',
'    border-left: 3px solid #2563EB;',
'    border-radius: 0 4px 4px 0;',
'    font-size: 14px;',
'    flex-shrink: 0;',
'    transition: all 0.2s ease;',
'    box-shadow: 0 1px 2px rgba(37, 99, 235, 0.15);',
'    text-shadow: 0 1px 0 rgba(255, 255, 255, 0.8);',
'    letter-spacing: 0.3px;',
'}',
'',
'.custom-title-indicator:hover {',
'    background-color: rgba(37, 99, 235, 0.12);',
'    box-shadow: 0 2px 4px rgba(37, 99, 235, 0.25);',
'}',
'',
'.title-edit-input {',
'    flex-grow: 0;',
'    width: 200px;',
'    padding: 4px 8px;',
'    border: 1px solid #ccc;',
'    border-radius: 3px;',
'    margin-right: 4px;',
'    font-size: 14px;',
'}',
'',
'.title-edit-input::placeholder {',
'    font-size: 12px;',
'    color: #999;',
'}',
'',
'/**********************************************************',
' * Status Indicator Styles',
' **********************************************************/',
'',
'.status-indicator {',
'    display: inline-flex;',
'    align-items: center;',
'    justify-content: center;',
'    width: 30px; ',
'    height: 30px; ',
'    border-radius: 50%;',
'    margin-right: 10px;',
'    cursor: pointer;',
'    transition: all 0.3s ease;',
'    box-shadow: 0 2px 4px rgba(0,0,0,0.2);',
'    border: 2px solid #ddd;',
'}',
'',
'.status-indicator.not-started {',
'    background-color: #e8f5e9;',
'    border: 2px solid #c8e6c9;',
'    color: #388e3c;',
'}',
'',
'.status-indicator.in-progress {',
'    background-color: #f39c12;',
'    color: white;',
'    border: 2px solid #e67e22;',
'}',
'',
'.status-indicator.completed {',
'    background-color: #2ecc71;',
'    color: white;',
'    border: 2px solid #27ae60;',
'}',
'',
'.status-indicator:hover {',
'    transform: scale(1.1);',
'    box-shadow: 0 3px 6px rgba(0,0,0,0.3);',
'}',
'',
'',
'',
'/**********************************************************',
' * Change only the success icon to green',
' **********************************************************/',
'',
'',
'.t-Alert--success .t-Alert-icon .t-Icon {',
'    color: #2ecc71 !important;',
'}',
'',
'.t-Alert--success .t-Button--closeAlert .t-Icon {',
'    color: inherit !important; ',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'/* Disabled button styling */',
'.apex_disabled {',
'    opacity: 0.5;',
'    cursor: not-allowed !important;',
'}',
'',
'/* Checkbox column width',
'#R45756756756575 th:first-child,',
'#R45756756756575 td:first-child {',
'    width: 35px !important;',
'    min-width: 35px !important;',
'    max-width: 35px !important;',
'    text-align: center;',
'} */',
'',
'',
'',
'/***********************',
' * Checkbox and Popup Styles',
' ***********************/',
'.apex-item-single-checkbox input:checked+.u-checkbox:after, ',
'.apex-item-single-checkbox input:checked+label:after, ',
'.u-checkbox.is-checked:after {',
'    opacity: 1;',
'    background-color: #bb0a31;',
'}',
'',
'.apex-item-single-checkbox {',
'    margin-top: 13px;',
'}',
'',
'.a-PopupLOV-clearButton:hover {',
'    background-color: #bb0a31;',
'}',
'',
'',
'',
'',
'',
'/***********************',
' * MANUELLER_EINTRAG',
' ***********************/',
'',
'/* Make Entry Type column text WHITE when row is hovered */',
'/* tr:hover .manual-entry-indicator span,',
'tr:hover .auto-entry-indicator span {',
'    color: #ffffff !important;',
'} */',
'',
'/* Make Entry Type column icons WHITE when row is hovered */',
'tr:hover .manual-entry-indicator i,',
'tr:hover .auto-entry-indicator i {',
'    color: #ffffff !important;',
'}',
'',
'',
'',
'',
'',
'/***********************',
' * Delete Icons',
' ***********************/',
'',
'tr:hover .delete-icon,',
'tr:hover .fa-ban {',
'    color: #ffffff !important;',
'}',
'',
'',
'tr:hover .edit-icon,',
'tr:hover .fa-pencil {',
'    color: rgb(0, 0, 0) !important;',
'}',
'',
'',
'',
'/* Hover state - all turn white */',
'',
'tr:hover .et-ja,',
'tr:hover .et-nein,',
'tr:hover .et-nicht-bewertet,',
'tr:hover .fb-ja,',
'tr:hover .fb-nein,',
'tr:hover .fb-nicht-bewertet {',
'    color: #ffffff !important;',
'}',
'',
'tr:hover .et-ja i,',
'tr:hover .et-nein i,',
'tr:hover .fb-ja i,',
'tr:hover .fb-nein i {',
'    color: #ffffff !important;',
'}',
'',
'',
'',
'',
'/* SWITCH*/',
'',
'',
'',
'',
'',
'',
'/* SWITCH - END */',
'',
'',
'',
'',
'',
'/***********************',
' * Single Row Edit Link Icon',
' ***********************/',
'.single-edit-link .fa-external-link {',
'',
'    color: #bb0a31;',
'}',
'',
'tr:hover .single-edit-link .fa-external-link {',
'    color: #ffffff !important;',
'    ',
'}',
'',
'',
'/***********************',
' * Save Scroll Position',
' ***********************/',
'',
'tr.highlight td {',
'    background-color: #ffeb3b !important;',
'    color: #000 !important;',
'    transition: background-color 0.3s ease;',
'}',
'',
'',
'',
'/***********************',
' * Warning Icons',
' ***********************/',
'',
'',
'',
'',
' /* Warning Icon (Exclamation Triangle) */',
'.warning-icon {',
'    color: #ff6600 !important;',
'    cursor: help;',
'    font-size: 14px !important;',
'    margin-right: 5px;',
'    animation: pulse-warning 2s infinite;',
'}',
'',
'.warning-icon:hover {',
'    color: #ff4400 !important;',
'    transform: scale(1.1);',
'    animation: none;',
'}',
'',
'/* Checkmark Icon */',
'.checkmark-icon {',
'    color: #27ae60 !important;',
'    cursor: help;',
'    font-size: 14px !important;',
'    margin-right: 5px;',
'    opacity: 0.9;',
'}',
'',
'.checkmark-icon:hover {',
'    color: #1e8e3e !important;',
'    transform: scale(1.1);',
'    opacity: 1;',
'}',
'',
'/* Pulse Animation for Warning */',
'/* @keyframes pulse-warning {',
'    0% { opacity: 1; }',
'    50% { opacity: 0.6; }',
'    100% { opacity: 1; }',
'}',
' */',
'',
'',
'',
'',
'',
'',
'/* --- CSS to optimize column widths using Static IDs for report R45756756756575 --- */',
'',
'/* Column: "Themabezeichnung" (Static ID: THEMABEZEICHNUNG_COL) */',
'#R45756756756575_ir th#THEMABEZEICHNUNG_COL,',
'#R45756756756575_ir td[headers="THEMABEZEICHNUNG_COL"] {',
'    min-width: 250px !important;',
'}',
'',
'/* Column: "Homologationseigenschaft" (Static ID: HOMOLOGATION_COL) */',
'#R45756756756575_ir th#HOMOLOGATION_COL,',
'#R45756756756575_ir td[headers="HOMOLOGATION_COL"] {',
'    min-width: 280px !important;',
'}',
'',
'/* Column: "Nachfolger Vorschrift" (Static ID: NACHFOLGER_COL) */',
'#R45756756756575_ir th#NACHFOLGER_COL,',
'#R45756756756575_ir td[headers="NACHFOLGER_COL"] {',
'    min-width: 400px !important;',
'}',
'',
'/* Column: "Ausgabe Text von Regelnummer" (Static ID: AUSGABETEXT_COL) */',
'#R45756756756575_ir th#AUSGABETEXT_COL,',
'#R45756756756575_ir td[headers="AUSGABETEXT_COL"] {',
'    min-width: 400px !important;',
'}',
'',
'/* Column: "LRSA" (Static ID: LRSA_COL) */',
'#R45756756756575_ir th#LRSA_COL,',
'#R45756756756575_ir td[headers="LRSA_COL"] {',
'    min-width: 250px !important;',
'}',
'',
'',
'/* --- CSS to optimize column widths using Static IDs for report R45756756756575 --- */',
'',
'',
'',
'/* Criticality Change Arrows*/',
'',
'/* Criticality change arrows */',
'.fa-arrow-up {',
'    animation: bounce-up 1.5s ease-in-out infinite;',
'}',
'',
'.fa-arrow-down {',
'    animation: bounce-down 1.5s ease-in-out infinite;',
'}',
'',
'.fa-trending-up {',
'    animation: pulse-trend 2s ease-in-out infinite;',
'}',
'',
'.fa-trending-down {',
'    animation: pulse-trend 2s ease-in-out infinite;',
'}',
'',
'/* Animations for criticality indicators */',
'@keyframes bounce-up {',
'    0%, 20%, 50%, 80%, 100% {',
'        transform: translateY(0);',
'    }',
'    40% {',
'        transform: translateY(-3px);',
'    }',
'    60% {',
'        transform: translateY(-2px);',
'    }',
'}',
'',
'@keyframes bounce-down {',
'    0%, 20%, 50%, 80%, 100% {',
'        transform: translateY(0);',
'    }',
'    40% {',
'        transform: translateY(3px);',
'    }',
'    60% {',
'        transform: translateY(2px);',
'    }',
'}',
'',
'@keyframes pulse-trend {',
'    0% {',
'        opacity: 1;',
'    }',
'    50% {',
'        opacity: 0.6;',
'    }',
'    100% {',
'        opacity: 1;',
'    }',
'}',
'',
'/* Hover effects for criticality indicators */',
'.fa-arrow-up:hover,',
'.fa-arrow-down:hover,',
'.fa-minus:hover,',
'.fa-plus-circle:hover,',
'.fa-trending-up:hover,',
'.fa-trending-down:hover {',
'    transform: scale(1.2);',
'    transition: transform 0.2s ease;',
'}',
'',
'',
'/* Criticality Change Arrows*/',
'',
'',
'',
'',
'',
'/*columns for white text on row hover */',
'',
unistr('/* \00C4nderung zu M-1 column */'),
unistr('tr:hover span[style*="color: #27ae60"],     /* Neu hinzugef\00FCgt spans */'),
unistr('tr:hover span[style*="color: #f39c12"],     /* Kritikalit\00E4t ge\00E4ndert spans */'),
unistr('tr:hover span[style*="color: #3498db"],     /* Bewertung ge\00E4ndert spans */'),
unistr('tr:hover span[style*="color: #95a5a6"] {    /* Keine \00C4nderung spans */'),
'    color: #ffffff !important;',
'}',
'',
'/* Massenupdate Status column */',
'tr:hover .fa-ban,',
'tr:hover .fa-check {',
'    color: #ffffff !important;',
'}',
'',
'/* ET Verwendung (M-1) column - spans with specific colors */',
'/* tr:hover span[style*="color: #666"] {       nicht bewertet spans ',
'    color: #ffffff !important;',
'} */',
'',
'/*columns for white text on row hover */',
'',
'',
'',
'',
'/* Legend button - Info Blue styling */',
'#B577439449482037513 {',
'    background-color: #2196F3 !important;',
'    border-color: #1976D2 !important;',
'    color: #ffffff !important;',
'    transition: all 0.3s ease;',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'/* ========================================',
'   SUCCESSOR INDICATOR STYLING',
'   ======================================== */',
'',
'/* Successor indicator styling',
'.successor-indicator {',
'    display: inline-block;',
'    margin-right: 5px;',
'    vertical-align: middle;',
'}',
'',
'.successor-indicator i {',
'    animation: pulse-successor 2s ease-in-out infinite;',
'}',
'',
'@keyframes pulse-successor {',
'    0%, 100% { opacity: 1; }',
'    50% { opacity: 0.6; }',
'}',
'',
'Rule number styling',
'span[style*="Regel:"] {',
'    font-style: italic;',
'    background-color: #f5f5f5;',
'    padding: 2px 6px;',
'    border-radius: 3px;',
'    margin-left: 5px;',
'} */',
'',
'',
'',
'',
'',
'/* ========================================',
'   SUCCESSOR INDICATOR STYLING ',
'   ======================================== */',
'',
'/* Successor indicator container */',
'.successor-indicator {',
'    display: inline-block;',
'    margin-right: 5px;',
'    vertical-align: middle;',
'}',
'',
'/* Animated arrow for successor */',
'.successor-indicator i {',
'    animation: pulse-successor 2s ease-in-out infinite;',
'}',
'',
'@keyframes pulse-successor {',
'    0%, 100% { ',
'        opacity: 1; ',
'        transform: translateX(0);',
'    }',
'    50% { ',
'        opacity: 0.7; ',
'        transform: translateX(3px);',
'    }',
'}',
'',
'/* Rule number styling - applies to both main and alternative */',
'span[style*="Regel:"] {',
'    font-style: italic;',
'    background-color: #f5f5f5;',
'    padding: 2px 6px;',
'    border-radius: 3px;',
'    margin-left: 5px;',
'    white-space: nowrap;',
'    display: inline-block;',
'    border: 1px solid #e0e0e0;',
'}',
'',
'/* Hover effect for successor links */',
'.successor-indicator + a:hover {',
'    text-decoration: underline;',
'    /* color: #1976D2; */',
'}',
'',
'/* Ensure proper spacing in alternative column */',
'td[headers="ALTERNATIVE_VORSCHRIFTENNUMMER"] {',
'    line-height: 1.6;',
'}',
'',
'/* Make successor more prominent on row hover */',
'tr:hover .successor-indicator i {',
'    color: #1976D2 !important;',
'    animation: none;',
'    transform: scale(1.1);',
'}',
'',
'',
'/* Force Rule Number text to stay BLACK on row hover */',
'tr:hover .rule-number-tag {',
'    color: #000000 !important;       /* Force text to be Black */',
'    background-color: #f5f5f5 !important; /* Keep the light grey background so black text is readable */',
'    border: 1px solid #ccc !important;    /* Keep the border visible */',
'}',
'',
'',
'/* Help cursor for successor indicator */',
'.successor-indicator {',
'    cursor: help; ',
'}',
'',
'.successor-indicator:hover {',
'    opacity: 0.8; ',
'}',
'',
'',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'.show-more, .show-less {',
'    display: inline-block;',
'    cursor: pointer;',
'    color: #bb0a31;',
'    margin-left: 5px;',
'    margin-top: 8px !important;',
'    font-size: 13px;',
'    vertical-align: middle;',
'}',
'',
'.show-more:hover, .show-less:hover {',
'    color: #d01a45;',
'    text-decoration: underline;',
'}',
'',
'.show-more i, .show-less i {',
'    margin-right: 4px;',
'    font-size: 14px;',
'    vertical-align: middle;',
'    position: relative;',
'    top: -1px;',
'}',
'',
'.country-name {',
'    display: block;',
'    line-height: 1.5;',
'}',
'',
'',
'.fa-plus-circle-o, .fa-minus-circle-o {',
'    width: 14px;',
'    text-align: center;',
'}',
''))
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1792552374715008812)
,p_plug_name=>'&P51_CARD_TITLE. - working 28 oct'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>140
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ',
'--Check if this is the first search in the Post-process',
'first_search_check AS',
'(',
'SELECT CASE WHEN :P51_POSTPROZESS_ID IS NOT NULL THEN CASE WHEN (SELECT COUNT(DISTINCT prs.SUCHEID || ''-'' || prs.MEILENSTEIN) FROM T_POSTPROZESS_REF_SUCHE prs WHERE prs.POSTPROZESSID = :P51_POSTPROZESS_ID) = 1 THEN 1 WHEN EXISTS (SELECT 1 FROM T_POST'
||'PROZESS_REF_SUCHE prs WHERE prs.POSTPROZESSID = :P51_POSTPROZESS_ID AND prs.SUCHEID = :P51_SEARCH_SELECTION AND prs.MEILENSTEIN = :P51_MILESTONE_SELECTION AND prs.ZEITPUNKT = (SELECT MIN(ZEITPUNKT) FROM T_POSTPROZESS_REF_SUCHE WHERE POSTPROZESSID = :'
||'P51_POSTPROZESS_ID)) THEN 1 ELSE 0 END ELSE 0 END AS is_first_search FROM dual',
'),',
'base_results AS (',
'SELECT ms.sucheid, ms.meilenstein, ms.landid, ms.vorschriftid, ms.alternative_vorschriftid, ms.vorschriftnummer, ms.landnummer, ms.landbezeichnung, COALESCE(ms.themabezeichnung, ''[Kein Thema zugewiesen]'') as themabezeichnung, ms.manueller_eintrag, ms'
||'.regelnummer',
'FROM T_MS_SUCHERGEBNISS ms',
'WHERE ms.sucheid = :P51_SEARCH_SELECTION AND ms.meilenstein = :P51_MILESTONE_SELECTION AND ms.landid IN (SELECT TO_NUMBER(TRIM(column_value)) FROM TABLE(apex_string.split(TRIM(:P51_LANDIDS), '';''))) AND (ms.vorschriftnummer IS NOT NULL OR ms.manueller'
||'_eintrag = 10)',
'),',
'previous_milestone_data AS (',
'SELECT ms.sucheid, ms.meilenstein, ms.landid, ms.vorschriftid, ms.alternative_vorschriftid, COALESCE(mat.kritikalitaet, 0) as prev_kritikalitaet, mat.ausgabe_text as prev_ausgabe_text, bew.et_verwendung as prev_et_verwendung, bew.et_kommentar as prev'
||'_et_kommentar, CASE WHEN COALESCE(mat.kritikalitaet, 0) = 0 THEN ''no-prev-data'' ELSE ''has-prev-data'' END as prev_data_status',
'FROM t_ms_suchergebniss ms',
'LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'LEFT JOIN t_ms_parameter_ref_ausgabe pra ON p.ms_parameterid = pra.ms_parameterid',
'LEFT JOIN t_ms_ausgabe_text mat ON pra.ms_ausgabe_textid = mat.ms_ausgabe_textid',
'LEFT JOIN t_ms_bewertung bew ON (bew.sucheid = ms.sucheid AND bew.meilenstein = ms.meilenstein AND bew.vorschriftid = CASE WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid ELSE ms.vorschriftid END AND (bew.benutzerid = :G'
||'_BENUTZERID OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr WHERE brr.benutzerid = :G_BENUTZERID AND brr.rolleid = 1001)))',
'-- WHERE ms.sucheid = :P51_SEARCH_SELECTION AND ms.meilenstein = (:P51_MILESTONE_SELECTION - 1) AND ms.landid IN (SELECT TO_NUMBER(TRIM(column_value)) FROM TABLE(apex_string.split(TRIM(:P51_LANDIDS), '';'')))',
'CROSS JOIN first_search_check fsc',
'WHERE fsc.is_first_search = 0',
'AND ms.sucheid = :P51_SEARCH_SELECTION AND ms.meilenstein = (:P51_MILESTONE_SELECTION - 1) AND ms.landid IN (SELECT TO_NUMBER(TRIM(column_value)) FROM TABLE(apex_string.split(TRIM(:P51_LANDIDS), '';'')))',
'),',
'card_mapping AS (',
'SELECT split.sucheid, split.meilenstein, split.landid, split.card_number',
'FROM T_MS_SUCHE_SPLIT split',
'WHERE split.card_number = :P51_CARD_NUM AND (split.benutzerid = :G_BENUTZERID OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr WHERE brr.benutzerid = :G_BENUTZERID AND brr.rolleid = 1001))',
'),',
'filtered_base AS (',
'SELECT br.*, cm.card_number',
'FROM base_results br',
'INNER JOIN card_mapping cm ON (cm.sucheid = br.sucheid AND cm.meilenstein = br.meilenstein AND cm.landid = br.landid)',
'),',
'vorschrift_details AS (',
'SELECT v.vorschriftid, v.vorschrift_nummer, v.publisher, v.dokumentendatum, v.rxswin, tp.anzeige_mit_dokumentendatum',
'FROM t_vorschrift v',
'LEFT JOIN t_publisher tp ON v.publisherid = tp.publisherid',
'WHERE v.vorschriftid IN (SELECT vorschriftid FROM filtered_base UNION SELECT alternative_vorschriftid FROM filtered_base WHERE alternative_vorschriftid IS NOT NULL)',
'),',
'lrsa_data AS (',
'SELECT vrt.vorschriftid, CASE WHEN LENGTH(LISTAGG(DISTINCT l.lrsa_nummer || '' - '' || l.bezeichnung, '', '') WITHIN GROUP (ORDER BY l.bezeichnung ASC)) > 500 THEN SUBSTR(LISTAGG(DISTINCT l.lrsa_nummer || '' - '' || l.bezeichnung, '', '') WITHIN GROUP (ORDER'
||' BY l.bezeichnung ASC), 1, 500) || ''...'' ELSE LISTAGG(DISTINCT l.lrsa_nummer || '' - '' || l.bezeichnung, '', '') WITHIN GROUP (ORDER BY l.bezeichnung ASC) END AS lrsa',
'FROM t_vorschrift_ref_thema vrt',
'INNER JOIN T_THEMA_REF_LRSA ref ON vrt.themaid = ref.themaid',
'INNER JOIN T_LRSA l ON l.LRSA_ID = ref.LRSAID',
'WHERE vrt.geloescht = 0 AND vrt.vorschriftid IN (SELECT vorschriftid FROM filtered_base UNION SELECT alternative_vorschriftid FROM filtered_base WHERE alternative_vorschriftid IS NOT NULL)',
'GROUP BY vrt.vorschriftid',
'),',
'homolog_data AS (',
'SELECT vrt.vorschriftid, CASE WHEN LENGTH(REPLACE(LISTAGG(DISTINCT e.EIGENSCHAFT_KENNUNG || ''-'' || et.kuerzel || ''-'' || e.eigenschaft, '', '') WITHIN GROUP (ORDER BY e.eigenschaft), '', '', ''<br>'')) > 500 THEN SUBSTR(REPLACE(LISTAGG(DISTINCT e.EIGENSCHAF'
||'T_KENNUNG || ''-'' || et.kuerzel || ''-'' || e.eigenschaft, '', '') WITHIN GROUP (ORDER BY e.eigenschaft), '', '', ''<br>''), 1, 500) || ''...'' ELSE REPLACE(LISTAGG(DISTINCT e.EIGENSCHAFT_KENNUNG || ''-'' || et.kuerzel || ''-'' || e.eigenschaft, '', '') WITHIN GROUP '
||'(ORDER BY e.eigenschaft), '', '', ''<br>'') END AS homologationseigenschaften',
'FROM t_vorschrift_ref_thema vrt',
'INNER JOIN carmah2_admin.t_eigenschaft_ref_regindexthemen err ON vrt.themaid = err.regindex_themen_id',
'INNER JOIN carmah2_admin.t_eigenschaft e ON err.eigenschaft_id = e.eigenschaft_id',
'INNER JOIN carmah2_admin.t_eigenschaft_typ et ON e.eigenschaft_typ_id = et.eigenschaft_typ_id',
'WHERE vrt.geloescht = 0 AND vrt.vorschriftid IN (SELECT vorschriftid FROM filtered_base UNION SELECT alternative_vorschriftid FROM filtered_base WHERE alternative_vorschriftid IS NOT NULL)',
'GROUP BY vrt.vorschriftid',
'),',
'successor_data AS (',
'SELECT vrv.vorgaenger_vorschriftid, CASE WHEN LENGTH(LISTAGG(DISTINCT ''<a href="f?p='' || :APP_ID || '':25:'' || :APP_SESSION || ''::'' || :DEBUG || '':RP,25:P25_VORSCHRIFTID:'' || nv.vorschriftid || ''" target="_blank">'' || nv.vorschrift_nummer || ''</a>'', '''
||';<br>'') WITHIN GROUP (ORDER BY nv.vorschrift_nummer)) > 500 THEN SUBSTR(LISTAGG(DISTINCT ''<a href="f?p='' || :APP_ID || '':25:'' || :APP_SESSION || ''::'' || :DEBUG || '':RP,25:P25_VORSCHRIFTID:'' || nv.vorschriftid || ''" target="_blank">'' || nv.vorschrift_'
||'nummer || ''</a>'', '';<br>'') WITHIN GROUP (ORDER BY nv.vorschrift_nummer), 1, 500) || ''...'' ELSE LISTAGG(DISTINCT ''<a href="f?p='' || :APP_ID || '':25:'' || :APP_SESSION || ''::'' || :DEBUG || '':RP,25:P25_VORSCHRIFTID:'' || nv.vorschriftid || ''" target="_bla'
||'nk">'' || nv.vorschrift_nummer || ''</a>'', '';<br>'') WITHIN GROUP (ORDER BY nv.vorschrift_nummer) END AS nachfolger_vorschrift',
'FROM t_vorschrift_ref_vorschrift vrv',
'INNER JOIN t_vorschrift nv ON nv.vorschriftid = vrv.nachfolger_vorschriftid',
'WHERE vrv.beziehung_art = 10 AND vrv.vorgaenger_vorschriftid IN (SELECT vorschriftid FROM filtered_base UNION SELECT alternative_vorschriftid FROM filtered_base WHERE alternative_vorschriftid IS NOT NULL)',
'GROUP BY vrv.vorgaenger_vorschriftid',
'),',
'rule_criticality AS (',
'SELECT ',
'    fb.sucheid,',
'    fb.meilenstein,',
'    fb.landid,',
'    CASE WHEN fb.alternative_vorschriftid IS NOT NULL THEN fb.alternative_vorschriftid ELSE fb.vorschriftid END as specific_vorschrift_id,',
'    CASE WHEN LENGTH(LISTAGG(DISTINCT TO_CHAR(fb.regelnummer),''; '') WITHIN GROUP(ORDER BY fb.regelnummer))>500 THEN SUBSTR(LISTAGG(DISTINCT TO_CHAR(fb.regelnummer),''; '') WITHIN GROUP(ORDER BY fb.regelnummer),1,500)||''...'' ELSE LISTAGG(DISTINCT TO_CHA'
||'R(fb.regelnummer),''; '') WITHIN GROUP(ORDER BY fb.regelnummer) END AS regelnummer_list,',
'    CASE WHEN LENGTH(LISTAGG(DISTINCT CASE WHEN mat.KRITIKALITAET IS NOT NULL THEN TO_CHAR(mat.KRITIKALITAET) ELSE NULL END,''; '') WITHIN GROUP(ORDER BY mat.KRITIKALITAET))>500 THEN SUBSTR(LISTAGG(DISTINCT CASE WHEN mat.KRITIKALITAET IS NOT NULL THEN '
||'TO_CHAR(mat.KRITIKALITAET) ELSE NULL END,''; '') WITHIN GROUP(ORDER BY mat.KRITIKALITAET),1,500)||''...'' ELSE LISTAGG(DISTINCT CASE WHEN mat.KRITIKALITAET IS NOT NULL THEN TO_CHAR(mat.KRITIKALITAET) ELSE NULL END,''; '') WITHIN GROUP(ORDER BY mat.KRITIKAL'
||'ITAET) END AS kritikalitaet_von_regelnummer,',
'    CASE WHEN LENGTH(LISTAGG(DISTINCT CASE WHEN mat.AUSGABE_TEXT IS NOT NULL THEN mat.AUSGABE_TEXT ELSE NULL END,''<br>'') WITHIN GROUP(ORDER BY mat.AUSGABE_TEXT))>500 THEN SUBSTR(LISTAGG(DISTINCT CASE WHEN mat.AUSGABE_TEXT IS NOT NULL THEN mat.AUSGABE'
||'_TEXT ELSE NULL END,''<br>'') WITHIN GROUP(ORDER BY mat.AUSGABE_TEXT),1,500)||''...'' ELSE LISTAGG(DISTINCT CASE WHEN mat.AUSGABE_TEXT IS NOT NULL THEN mat.AUSGABE_TEXT ELSE NULL END,''<br>'') WITHIN GROUP(ORDER BY mat.AUSGABE_TEXT) END AS ausgabe_text_von'
||'_regelnummer,',
'    MAX(mat.KRITIKALITAET) as max_kritikalitaet',
'FROM filtered_base fb',
'LEFT JOIN T_MS_PARAMETER p ON fb.regelnummer = p.nummer',
'LEFT JOIN T_MS_PARAMETER_REF_AUSGABE pra ON p.MS_PARAMETERID = pra.MS_PARAMETERID',
'LEFT JOIN T_MS_AUSGABE_TEXT mat ON pra.MS_AUSGABE_TEXTID = mat.MS_AUSGABE_TEXTID',
'GROUP BY fb.sucheid, fb.meilenstein, fb.landid, CASE WHEN fb.alternative_vorschriftid IS NOT NULL THEN fb.alternative_vorschriftid ELSE fb.vorschriftid END',
'),',
'country_coverage AS (',
'SELECT :P51_CARD_NUM as card_number, COUNT(DISTINCT landid) as total_countries',
'FROM t_ms_suche_split ',
'WHERE card_number = :P51_CARD_NUM AND (benutzerid = :G_BENUTZERID OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr WHERE brr.benutzerid = :G_BENUTZERID AND brr.rolleid = 1001))',
'),',
'bewertung_data AS (',
'SELECT ',
'bew.sucheid,',
'bew.meilenstein,',
'bew.card_number,',
'bew.vorschriftid,',
'CASE WHEN LENGTH(LISTAGG(DISTINCT CASE WHEN bew.ET_VERWENDUNG=''nicht bewertet'' THEN ''<span class="et-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>'' WHEN bew.ET_VERWENDUNG=''ja'' THEN ''<span class="et-ja" style="color: #'
||'27ae60; font-weight: bold;"><i class="fa fa-check"></i> ja</span>'' WHEN bew.ET_VERWENDUNG=''nein'' THEN ''<span class="et-nein" style="color: #e74c3c; font-weight: bold;"><i class="fa fa-times"></i> nein</span>'' ELSE ''<span class="et-nicht-bewertet" sty'
||'le="color: #666; font-style: italic;">nicht bewertet</span>'' END,''; '') WITHIN GROUP(ORDER BY bew.ET_VERWENDUNG))>500 THEN SUBSTR(LISTAGG(DISTINCT CASE WHEN bew.ET_VERWENDUNG=''nicht bewertet'' THEN ''<span class="et-nicht-bewertet" style="color: #666; f'
||'ont-style: italic;">nicht bewertet</span>'' WHEN bew.ET_VERWENDUNG=''ja'' THEN ''<span class="et-ja" style="color: #27ae60; font-weight: bold;"><i class="fa fa-check"></i> ja</span>'' WHEN bew.ET_VERWENDUNG=''nein'' THEN ''<span class="et-nein" style="color:'
||' #e74c3c; font-weight: bold;"><i class="fa fa-times"></i> nein</span>'' ELSE ''<span class="et-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>'' END,''; '') WITHIN GROUP(ORDER BY bew.ET_VERWENDUNG),1,500)||''...'' ELSE LISTAGG'
||'(DISTINCT CASE WHEN bew.ET_VERWENDUNG=''nicht bewertet'' THEN ''<span class="et-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>'' WHEN bew.ET_VERWENDUNG=''ja'' THEN ''<span class="et-ja" style="color: #27ae60; font-weight: bol'
||'d;"><i class="fa fa-check"></i> ja</span>'' WHEN bew.ET_VERWENDUNG=''nein'' THEN ''<span class="et-nein" style="color: #e74c3c; font-weight: bold;"><i class="fa fa-times"></i> nein</span>'' ELSE ''<span class="et-nicht-bewertet" style="color: #666; font-st'
||'yle: italic;">nicht bewertet</span>'' END,''; '') WITHIN GROUP(ORDER BY bew.ET_VERWENDUNG) END AS ET_VERWENDUNG,',
'CASE WHEN LENGTH(LISTAGG(DISTINCT bew.ET_VORSCHLAG_VORSCHRIFT,''; '') WITHIN GROUP(ORDER BY bew.ET_VORSCHLAG_VORSCHRIFT))>500 THEN SUBSTR(LISTAGG(DISTINCT bew.ET_VORSCHLAG_VORSCHRIFT,''; '') WITHIN GROUP(ORDER BY bew.ET_VORSCHLAG_VORSCHRIFT),1,500)||''...'
||''' ELSE LISTAGG(DISTINCT bew.ET_VORSCHLAG_VORSCHRIFT,''; '') WITHIN GROUP(ORDER BY bew.ET_VORSCHLAG_VORSCHRIFT) END AS ET_VORSCHLAG_VORSCHRIFT,',
'CASE WHEN LENGTH(LISTAGG(DISTINCT bew.ET_KOMMENTAR,''; '') WITHIN GROUP(ORDER BY bew.ET_KOMMENTAR))>500 THEN SUBSTR(LISTAGG(DISTINCT bew.ET_KOMMENTAR,''; '') WITHIN GROUP(ORDER BY bew.ET_KOMMENTAR),1,500)||''...'' ELSE LISTAGG(DISTINCT bew.ET_KOMMENTAR,''; '
||''') WITHIN GROUP(ORDER BY bew.ET_KOMMENTAR) END AS ET_KOMMENTAR,',
'CASE WHEN MAX(CASE WHEN bew.ET_VERWENDUNG!=''nicht bewertet'' THEN 1 ELSE 0 END)=1 THEN 1 ELSE 0 END as is_evaluated',
'FROM T_MS_BEWERTUNG bew',
'INNER JOIN filtered_base fb ON (bew.SUCHEID = fb.sucheid AND bew.MEILENSTEIN = fb.meilenstein AND bew.CARD_NUMBER = fb.card_number AND bew.VORSCHRIFTID = CASE WHEN fb.alternative_vorschriftid IS NOT NULL THEN fb.alternative_vorschriftid ELSE fb.vorsc'
||'hriftid END AND (bew.BENUTZERID = :G_BENUTZERID OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr WHERE brr.benutzerid = :G_BENUTZERID AND brr.rolleid = 1001)))',
'GROUP BY bew.sucheid, bew.meilenstein, bew.card_number, bew.vorschriftid',
'),',
'cross_reference_check AS (',
'SELECT DISTINCT bew.vorschriftid, 1 as is_selected_elsewhere',
'FROM T_MS_BEWERTUNG bew',
'INNER JOIN T_MS_SUCHE_SPLIT split ON (bew.sucheid = split.sucheid AND bew.meilenstein = split.meilenstein AND bew.card_number = split.card_number)',
'WHERE bew.sucheid = :P51_SEARCH_SELECTION AND bew.meilenstein = :P51_MILESTONE_SELECTION AND (bew.benutzerid = :G_BENUTZERID OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr WHERE brr.benutzerid = :G_BENUTZERID AND brr.rolleid = 1001)) AND bew.ET_VE'
||'RWENDUNG = ''ja'' AND bew.card_number != :P51_CARD_NUM AND bew.vorschriftid IN (SELECT CASE WHEN fb.alternative_vorschriftid IS NOT NULL THEN fb.alternative_vorschriftid ELSE fb.vorschriftid END FROM filtered_base fb)',
')',
'SELECT',
'1 AS checkbox,',
'''<a href="''||apex_util.prepare_url(p_url=>''f?p=''||:app_id||'':466:''||:app_session||'':::466:''||''P466_SEARCH_SELECTION,P466_MILESTONE_SELECTION,P466_CARD_NUM,P466_SINGLE_REG_ID:''||:p51_search_selection||'',''||:p51_milestone_selection||'',''||:p51_card_num|'
||'|'',''||fb.vorschriftid)||''" title="Bewertung bearbeiten" class="single-edit-link">''||''<span class="fa fa-external-link" style="font-size: 16px; color: #007bff;"></span>''||''</a>'' AS row_edit_link,',
'fb.card_number,',
'fb.vorschriftid AS specific_reg_id,',
'fb.vorschriftid,',
'CASE WHEN length(listagg(DISTINCT CASE WHEN fb.alternative_vorschriftid IS NOT NULL THEN to_char(fb.alternative_vorschriftid) ELSE ''-'' END,'', '') WITHIN GROUP(ORDER BY fb.alternative_vorschriftid))>500 THEN substr(listagg(DISTINCT CASE WHEN fb.alterna'
||'tive_vorschriftid IS NOT NULL THEN to_char(fb.alternative_vorschriftid) ELSE ''-'' END,'', '') WITHIN GROUP(ORDER BY fb.alternative_vorschriftid),1,500)||''...'' ELSE listagg(DISTINCT CASE WHEN fb.alternative_vorschriftid IS NOT NULL THEN to_char(fb.altern'
||'ative_vorschriftid) ELSE ''-'' END,'', '') WITHIN GROUP(ORDER BY fb.alternative_vorschriftid) END AS alternative_vorschriftid,',
'CASE WHEN max(fb.manueller_eintrag)=10 THEN ''<a href="''||apex_util.prepare_url(p_url=>''f?p=''||:app_id||'':465:''||:app_session||'':::465:''||''P465_CARD_NUM,P465_MODE,P465_SEARCH_SELECTION,P465_MILESTONE_SELECTION,P465_LANDIDS,P465_SPECIFIC_REG_ID:''||fb.c'
||'ard_number||'',EDIT,''||fb.sucheid||'',''||fb.meilenstein||'',''||listagg(DISTINCT fb.landid,'';'') WITHIN GROUP(ORDER BY fb.landnummer)||'',''||fb.vorschriftid)||''" title="Bearbeiten (Manueller Eintrag)" class="edit-link"><span class="fa fa-pencil edit-icon" '
||unistr('style="font-size: 16px; color: #333;"></span></a>'' ELSE ''<span class="fa fa-pencil" style="color: #ccc; font-size: 16px;" title="Automatischer Eintrag - Bearbeiten nicht m\00F6glich"></span>'' END AS edit_action,'),
unistr('CASE WHEN max(fb.manueller_eintrag)=10 THEN ''<a href="javascript:confirmDeleteCard(''||fb.card_number||'', ''||fb.vorschriftid||'')" title="Manueller Eintrag - L\00F6schen ist m\00F6glich" class="delete-link"><span class="fa fa-trash delete-icon" style="color: #')
||unistr('bb0a31; font-size: 16px;"></span></a>'' ELSE ''<span class="fa fa-trash" style="color: #ccc; font-size: 16px;" title="Automatischer Eintrag - L\00F6schen nicht m\00F6glich"></span>'' END AS delete_action,'),
'CASE WHEN max(fb.manueller_eintrag)=10 THEN ''<span class="manual-entry-indicator" title="Manueller Eintrag"><i class="fa fa-user-plus" style="color: #bb0a31; font-size: 14px; margin-right: 5px;"></i><span>Manueller Eintrag</span></span>'' ELSE ''<span '
||'class="auto-entry-indicator" title="Automatischer Eintrag"><i class="fa fa-cog" style="color: #bb0a31; font-size: 14px; margin-right: 5px;"></i><span>Automatischer Eintrag</span></span>'' END AS manueller_eintrag,',
'CASE WHEN length(listagg(DISTINCT fb.landnummer,''; '') WITHIN GROUP(ORDER BY fb.landnummer))>500 THEN substr(listagg(DISTINCT fb.landnummer,''; '') WITHIN GROUP(ORDER BY fb.landnummer),1,500)||''...'' ELSE listagg(DISTINCT fb.landnummer,''; '') WITHIN GROUP'
||'(ORDER BY fb.landnummer) END AS b_nummer_liste,',
'CASE WHEN length(listagg(DISTINCT fb.landid,''; '') WITHIN GROUP(ORDER BY fb.landnummer))>500 THEN substr(listagg(DISTINCT fb.landid,''; '') WITHIN GROUP(ORDER BY fb.landnummer),1,500)||''...'' ELSE listagg(DISTINCT fb.landid,''; '') WITHIN GROUP(ORDER BY fb'
||'.landnummer) END AS landids,',
'CASE WHEN length(listagg(DISTINCT fb.landbezeichnung,''; '') WITHIN GROUP(ORDER BY fb.landnummer))>500 THEN substr(listagg(DISTINCT fb.landbezeichnung,''; '') WITHIN GROUP(ORDER BY fb.landnummer),1,500)||''...'' ELSE listagg(DISTINCT fb.landbezeichnung,''; '
||''') WITHIN GROUP(ORDER BY fb.landnummer) END AS land_namen_liste,',
unistr('CASE WHEN count(DISTINCT fb.landid)<cc.total_countries THEN ''<span class="fa fa-exclamation-triangle warning-icon" style="color: #ff6600; margin-right: 5px; font-size: 14px;" title="Nicht alle Themengebiete gelten in allen L\00E4ndern!"></span> '' ELSE ''''')
||' END||CASE WHEN length(listagg(DISTINCT fb.themabezeichnung,''; '') WITHIN GROUP(ORDER BY fb.themabezeichnung))>500 THEN substr(listagg(DISTINCT fb.themabezeichnung,''; '') WITHIN GROUP(ORDER BY fb.themabezeichnung),1,500)||''...'' ELSE listagg(DISTINCT fb'
||'.themabezeichnung,''; '') WITHIN GROUP(ORDER BY fb.themabezeichnung) END AS themabezeichnung,',
unistr('CASE WHEN count(DISTINCT fb.landid)<cc.total_countries THEN ''<span class="fa fa-exclamation-triangle warning-icon" style="color: #ff6600; margin-right: 5px; font-size: 14px;" title="Diese Vorschrift gilt nicht f\00FCr alle L\00E4nder in dieser Karte!"></span')
||'> '' ELSE '''' END||CASE WHEN max(nvl(bd.is_evaluated,0))=1 THEN ''<span class="fa fa-check-circle checkmark-icon" style="color: #27ae60; margin-right: 5px; font-size: 14px;" title="Diese Vorschrift wurde bereits bewertet!"></span> '' ELSE '''' END||''<a hre'
||'f="f?p=''||:app_id||'':25:''||:app_session||''::''||:debug||'':RP,25:P25_VORSCHRIFTID:''||fb.vorschriftid||''" target="_blank">''||max(CASE WHEN nvl(vd_main.anzeige_mit_dokumentendatum,0)=20 AND vd_main.dokumentendatum IS NOT NULL THEN coalesce(vd_main.vorsch'
||'rift_nummer,fb.vorschriftnummer)||''_''||to_char(vd_main.dokumentendatum,''DD.MM.YYYY'') ELSE coalesce(vd_main.vorschrift_nummer,fb.vorschriftnummer) END)||''</a>''||CASE WHEN max(nvl(crc.is_selected_elsewhere,0))=1 THEN '' <span class="fa fa-clipboard-list'
||unistr(' fam-check fam-is-success" style="margin-left: 5px;" title="Vorschrift wurde in einem anderen Markt schon ausgew\00E4hlt"></span>'' ELSE '''' END||CASE WHEN max(pmd.prev_kritikalitaet) IS NOT NULL THEN CASE WHEN NVL(MAX(rc.max_kritikalitaet), 0)>max(pmd.pre')
||'v_kritikalitaet) THEN '' <span class="fa fa-arrow-up" style="color: #fff; background-color: #e74c3c; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-left: 5px; font-size: 12px; padding: 3px;" title="Kriti'
||unistr('kalit\00E4t gestiegen"></span>'' WHEN NVL(MAX(rc.max_kritikalitaet), 0)<max(pmd.prev_kritikalitaet) THEN '' <span class="fa fa-arrow-down" style="color: #fff; background-color: #27ae60; border-radius: 50%; display: inline-flex; align-items: center; justify')
||unistr('-content: center; margin-left: 5px; font-size: 12px; padding: 3px;" title="Kritikalit\00E4t gesunken"></span>'' WHEN NVL(MAX(rc.max_kritikalitaet), 0)=max(pmd.prev_kritikalitaet) THEN '' <span class="fa fa-check-circle" style="color: #95a5a6; font-size: 14')
||unistr('px; vertical-align: middle;" title="Kritikalit\00E4t unver\00E4ndert"></span>'' ELSE '' <span class="fa fa-plus-circle" style="color: #27ae60; font-size: 14px; vertical-align: middle;" title="Neue Vorschrift"></span>'' END ELSE '''' END AS vorschriftennummer,'),
'CASE WHEN count(DISTINCT CASE WHEN fb.alternative_vorschriftid IS NOT NULL THEN fb.landid END)>0 AND count(DISTINCT CASE WHEN fb.alternative_vorschriftid IS NOT NULL THEN fb.landid END)<cc.total_countries THEN ''<span class="fa fa-exclamation-triangle'
||unistr(' warning-icon" style="color: #ff6600; margin-right: 5px; font-size: 14px;" title="Nicht alle Alternativen Vorschriften gelten in allen L\00E4ndern!"></span> '' ELSE '''' END||CASE WHEN length(listagg(DISTINCT CASE WHEN fb.alternative_vorschriftid IS NOT NUL')
||'L AND vd_alt.vorschrift_nummer IS NOT NULL THEN CASE WHEN nvl(vd_alt.anzeige_mit_dokumentendatum,0)=20 AND vd_alt.dokumentendatum IS NOT NULL THEN vd_alt.vorschrift_nummer||''_''||to_char(vd_alt.dokumentendatum,''DD.MM.YYYY'') ELSE vd_alt.vorschrift_numm'
||'er END ELSE NULL END,'', '') WITHIN GROUP(ORDER BY vd_alt.vorschrift_nummer))>500 THEN substr(listagg(DISTINCT CASE WHEN fb.alternative_vorschriftid IS NOT NULL AND vd_alt.vorschrift_nummer IS NOT NULL THEN CASE WHEN nvl(vd_alt.anzeige_mit_dokumentenda'
||'tum,0)=20 AND vd_alt.dokumentendatum IS NOT NULL THEN vd_alt.vorschrift_nummer||''_''||to_char(vd_alt.dokumentendatum,''DD.MM.YYYY'') ELSE vd_alt.vorschrift_nummer END ELSE NULL END,'', '') WITHIN GROUP(ORDER BY vd_alt.vorschrift_nummer),1,500)||''...'' ELSE'
||' listagg(DISTINCT CASE WHEN fb.alternative_vorschriftid IS NOT NULL AND vd_alt.vorschrift_nummer IS NOT NULL THEN CASE WHEN nvl(vd_alt.anzeige_mit_dokumentendatum,0)=20 AND vd_alt.dokumentendatum IS NOT NULL THEN vd_alt.vorschrift_nummer||''_''||to_cha'
||'r(vd_alt.dokumentendatum,''DD.MM.YYYY'') ELSE vd_alt.vorschrift_nummer END ELSE NULL END,'', '') WITHIN GROUP(ORDER BY vd_alt.vorschrift_nummer) END AS alternative_vorschriftennummer,',
'CASE WHEN length(listagg(DISTINCT nvl(vd_alt.publisher,vd_main.publisher),''; '') WITHIN GROUP(ORDER BY nvl(vd_alt.publisher,vd_main.publisher)))>500 THEN substr(listagg(DISTINCT nvl(vd_alt.publisher,vd_main.publisher),''; '') WITHIN GROUP(ORDER BY nvl(v'
||'d_alt.publisher,vd_main.publisher)),1,500)||''...'' ELSE listagg(DISTINCT nvl(vd_alt.publisher,vd_main.publisher),''; '') WITHIN GROUP(ORDER BY nvl(vd_alt.publisher,vd_main.publisher)) END AS publisher,',
'fb.sucheid AS search_id_hidden,',
'fb.meilenstein AS milestone_hidden,',
':p51_landids AS landids_hidden,',
'max(vd_main.rxswin) AS rxswin_relevant,',
'max(nvl(ld_main.lrsa,ld_alt.lrsa)) AS lrsa,',
'max(nvl(hd_main.homologationseigenschaften,hd_alt.homologationseigenschaften)) AS homologationseigenschaft,',
'max(nvl(sd_main.nachfolger_vorschrift,sd_alt.nachfolger_vorschrift)) AS nachfolger_vorschrift,',
'CASE WHEN listagg(DISTINCT rc.kritikalitaet_von_regelnummer,''; '') IS NOT NULL THEN listagg(DISTINCT rc.kritikalitaet_von_regelnummer,''; '')||CASE WHEN max(pmd.prev_kritikalitaet) IS NOT NULL THEN CASE WHEN NVL(MAX(rc.max_kritikalitaet), 0)>max(pmd.pre'
||'v_kritikalitaet) THEN '' <span class="fa fa-arrow-up" style="color: #fff; background-color: #e74c3c; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-left: 5px; font-size: 12px; padding: 3px;" title="Kriti'
||unistr('kalit\00E4t gestiegen"></span>'' WHEN NVL(MAX(rc.max_kritikalitaet), 0)<max(pmd.prev_kritikalitaet) THEN '' <span class="fa fa-arrow-down" style="color: #fff; background-color: #27ae60; border-radius: 50%; display: inline-flex; align-items: center; justify')
||unistr('-content: center; margin-left: 5px; font-size: 12px; padding: 3px;" title="Kritikalit\00E4t gesunken"></span>'' WHEN NVL(MAX(rc.max_kritikalitaet), 0)=max(pmd.prev_kritikalitaet) THEN '' <span class="fa fa-check-circle" style="color: #95a5a6; font-size: 14')
||unistr('px; vertical-align: middle;" title="Kritikalit\00E4t unver\00E4ndert"></span>'' ELSE '''' END ELSE '' <span class="fa fa-plus-circle" style="color: #27ae60; font-size: 14px; vertical-align: middle;" title="Neue Vorschrift"></span>'' END ELSE ''-'' END AS kritikalit')
||'aet_von_regelnummer,',
'CASE WHEN listagg(DISTINCT rc.ausgabe_text_von_regelnummer,''<br>'') IS NOT NULL THEN listagg(DISTINCT rc.ausgabe_text_von_regelnummer,''<br>'')||CASE WHEN max(pmd.prev_ausgabe_text) IS NOT NULL THEN CASE WHEN replace(listagg(DISTINCT rc.ausgabe_text_von'
||'_regelnummer,''<br>''),''<br>'','' | '')!=replace(max(pmd.prev_ausgabe_text),''<br>'','' | '') THEN '' <span class="fa fa-edit" style="color: #fff; background-color: #f39c12; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center'
||unistr('; margin-left: 5px; font-size: 12px; padding: 3px;" title="Ausgabe Text ge\00E4ndert"></span>'' ELSE '' <span class="fa fa-check-circle" style="color: #95a5a6; font-size: 14px; vertical-align: middle;" title="Ausgabe Text unver\00E4ndert"></span>'' END ELSE '' <')
||'span class="fa fa-plus-circle" style="color: #27ae60; font-size: 14px; vertical-align: middle;" title="Neuer Ausgabe Text"></span>'' END ELSE ''-'' END AS ausgabe_text_von_regelnummer,',
'max(bd.et_verwendung) AS et_verwendung,',
'max(bd.et_vorschlag_vorschrift) AS et_vorschlag_vorschrift,',
'max(bd.et_kommentar) AS et_kommentar,',
'-- CASE WHEN max(pmd.prev_kritikalitaet) IS NOT NULL THEN to_char(max(pmd.prev_kritikalitaet))||CASE WHEN NVL(MAX(rc.max_kritikalitaet), 0)>max(pmd.prev_kritikalitaet) THEN '' <span class="fa fa-arrow-up" style="color: #fff; background-color: #e74c3c;'
||unistr(' border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-left: 5px; font-size: 12px; padding: 3px; width: 16px; height: 16px;" title="Kritikalit\00E4t gestiegen"></span>'' WHEN NVL(MAX(rc.max_kritikalitaet), 0)<max(p')
||'md.prev_kritikalitaet) THEN '' <span class="fa fa-arrow-down" style="color: #fff; background-color: #27ae60; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-left: 5px; font-size: 12px; padding: 3px; width'
||unistr(': 16px; height: 16px;" title="Kritikalit\00E4t gesunken"></span>'' ELSE '' <span class="fa fa-check-circle" style="color: #95a5a6; font-size: 14px; vertical-align: middle;" title="Kritikalit\00E4t unver\00E4ndert"></span>'' END ELSE ''-'' END AS "Kritikalit\00E4t (M-1)",'),
'CASE WHEN fsc.is_first_search = 1 THEN ''-'' ELSE CASE WHEN max(pmd.prev_kritikalitaet) IS NOT NULL THEN to_char(max(pmd.prev_kritikalitaet))||CASE WHEN NVL(MAX(rc.max_kritikalitaet), 0)>max(pmd.prev_kritikalitaet) THEN '' <span class="fa fa-arrow-up" s'
||unistr('tyle="color: #fff; background-color: #e74c3c; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-left: 5px; font-size: 12px; padding: 3px; width: 16px; height: 16px;" title="Kritikalit\00E4t gestiegen"></span>''')
||' WHEN NVL(MAX(rc.max_kritikalitaet), 0)<max(pmd.prev_kritikalitaet) THEN '' <span class="fa fa-arrow-down" style="color: #fff; background-color: #27ae60; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-le'
||unistr('ft: 5px; font-size: 12px; padding: 3px; width: 16px; height: 16px;" title="Kritikalit\00E4t gesunken"></span>'' ELSE '' <span class="fa fa-check-circle" style="color: #95a5a6; font-size: 14px; vertical-align: middle;" title="Kritikalit\00E4t unver\00E4ndert"></spa')
||unistr('n>'' END ELSE ''-'' END END AS "Kritikalit\00E4t (M-1)",'),
'-- CASE WHEN max(pmd.prev_et_verwendung) IS NOT NULL THEN CASE max(pmd.prev_et_verwendung) WHEN ''nicht bewertet'' THEN ''<span style="color: #666; font-style: italic;">nicht bewertet</span>'' WHEN ''ja'' THEN ''<span style="color: #27ae60; font-weight: bol'
||'d;"><i class="fa fa-check"></i> ja</span>'' WHEN ''nein'' THEN ''<span style="color: #e74c3c; font-weight: bold;"><i class="fa fa-times"></i> nein</span>'' ELSE ''<span style="color: #666; font-style: italic;">nicht bewertet</span>'' END ELSE ''-'' END AS "ET'
||' Verwendung (M-1)",',
'CASE WHEN fsc.is_first_search = 1 THEN ''-'' ELSE CASE WHEN max(pmd.prev_et_verwendung) IS NOT NULL THEN CASE max(pmd.prev_et_verwendung) WHEN ''nicht bewertet'' THEN ''<span style="color: #666; font-style: italic;">nicht bewertet</span>'' WHEN ''ja'' THEN '''
||'<span style="color: #27ae60; font-weight: bold;"><i class="fa fa-check"></i> ja</span>'' WHEN ''nein'' THEN ''<span style="color: #e74c3c; font-weight: bold;"><i class="fa fa-times"></i> nein</span>'' ELSE ''<span style="color: #666; font-style: italic;">n'
||'icht bewertet</span>'' END ELSE ''-'' END END AS "ET Verwendung (M-1)",',
'-- nvl(max(pmd.prev_et_kommentar),''-'') AS "ET Kommentar (M-1)",',
'CASE WHEN fsc.is_first_search = 1 THEN ''-'' ELSE nvl(max(pmd.prev_et_kommentar),''-'') END AS "ET Kommentar (M-1)",',
unistr('-- CASE WHEN max(pmd.prev_data_status)=''no-prev-data'' OR max(pmd.prev_data_status) IS NULL THEN ''<span style="color: #27ae60; font-weight: bold;">Neu hinzugef\00FCgt</span>'' WHEN max(pmd.prev_kritikalitaet)!=NVL(MAX(rc.max_kritikalitaet), 0) THEN ''<span ')
||unistr('style="color: #f39c12; font-weight: bold;">Kritikalit\00E4t ge\00E4ndert</span>'' WHEN max(pmd.prev_et_verwendung)!=nvl(max(bd.et_verwendung),''nicht bewertet'') THEN ''<span style="color: #3498db; font-weight: bold;">Bewertung ge\00E4ndert</span>'' ELSE ''<span style')
||unistr('="color: #95a5a6;">Keine \00C4nderung</span>'' END AS "\00C4nderung zu M-1",'),
unistr('CASE WHEN fsc.is_first_search = 1 THEN ''-'' ELSE CASE WHEN max(pmd.prev_data_status)=''no-prev-data'' OR max(pmd.prev_data_status) IS NULL THEN ''<span style="color: #27ae60; font-weight: bold;">Neu hinzugef\00FCgt</span>'' WHEN max(pmd.prev_kritikalitaet)!=N')
||unistr('VL(MAX(rc.max_kritikalitaet), 0) THEN ''<span style="color: #f39c12; font-weight: bold;">Kritikalit\00E4t ge\00E4ndert</span>'' WHEN max(pmd.prev_et_verwendung)!=nvl(max(bd.et_verwendung),''nicht bewertet'') THEN ''<span style="color: #3498db; font-weight: bold;"')
||unistr('>Bewertung ge\00E4ndert</span>'' ELSE ''<span style="color: #95a5a6;">Keine \00C4nderung</span>'' END END AS "\00C4nderung zu M-1",'),
'CASE WHEN EXISTS(SELECT 1 FROM t_ms_suchergebniss ms_dup1 WHERE ms_dup1.vorschriftid=fb.vorschriftid AND ms_dup1.sucheid=fb.sucheid AND ms_dup1.meilenstein=fb.meilenstein AND ms_dup1.manueller_eintrag=10 AND EXISTS(SELECT 1 FROM t_ms_suchergebniss ms'
||'_dup2 WHERE ms_dup2.vorschriftid=ms_dup1.vorschriftid AND ms_dup2.sucheid=ms_dup1.sucheid AND ms_dup2.meilenstein=ms_dup1.meilenstein AND ms_dup2.landid=ms_dup1.landid AND ms_dup2.manueller_eintrag!=10)) THEN ''<span class="fa fa-ban" style="color: #e'
||unistr('74c3c;" title="Massenupdate blockiert"></span>'' ELSE ''<span class="fa fa-check" style="color: #28a745;" title="Massenupdate m\00F6glich"></span>'' END AS "Massenupdate Status"'),
'FROM filtered_base fb',
'CROSS JOIN country_coverage cc',
'CROSS JOIN first_search_check fsc',
'LEFT JOIN vorschrift_details vd_main ON vd_main.vorschriftid = fb.vorschriftid',
'LEFT JOIN vorschrift_details vd_alt ON vd_alt.vorschriftid = fb.alternative_vorschriftid',
'LEFT JOIN lrsa_data ld_main ON ld_main.vorschriftid = fb.vorschriftid',
'LEFT JOIN lrsa_data ld_alt ON ld_alt.vorschriftid = fb.alternative_vorschriftid',
'LEFT JOIN homolog_data hd_main ON hd_main.vorschriftid = fb.vorschriftid',
'LEFT JOIN homolog_data hd_alt ON hd_alt.vorschriftid = fb.alternative_vorschriftid',
'LEFT JOIN successor_data sd_main ON sd_main.vorgaenger_vorschriftid = fb.vorschriftid',
'LEFT JOIN successor_data sd_alt ON sd_alt.vorgaenger_vorschriftid = fb.alternative_vorschriftid',
'LEFT JOIN rule_criticality rc ON (rc.sucheid = fb.sucheid AND rc.meilenstein = fb.meilenstein AND rc.landid = fb.landid AND rc.specific_vorschrift_id = CASE WHEN fb.alternative_vorschriftid IS NOT NULL THEN fb.alternative_vorschriftid ELSE fb.vorschr'
||'iftid END)',
'LEFT JOIN bewertung_data bd ON (bd.sucheid = fb.sucheid AND bd.meilenstein = fb.meilenstein AND bd.card_number = fb.card_number AND bd.vorschriftid = CASE WHEN fb.alternative_vorschriftid IS NOT NULL THEN fb.alternative_vorschriftid ELSE fb.vorschrif'
||'tid END)',
'LEFT JOIN cross_reference_check crc ON crc.vorschriftid = CASE WHEN fb.alternative_vorschriftid IS NOT NULL THEN fb.alternative_vorschriftid ELSE fb.vorschriftid END',
'LEFT JOIN previous_milestone_data pmd ON (pmd.sucheid = fb.sucheid AND pmd.landid = fb.landid AND pmd.vorschriftid = CASE WHEN fb.alternative_vorschriftid IS NOT NULL THEN fb.alternative_vorschriftid ELSE fb.vorschriftid END)',
'WHERE (:P51_PUBLISHER_FILTER IS NULL OR NVL(vd_alt.publisher, vd_main.publisher) IN (SELECT TRIM(column_value) FROM TABLE(apex_string.split(:P51_PUBLISHER_FILTER, '':'')))) AND (:P51_SHOW_ONLY_UNPROCESSED = ''N'' OR (:P51_SHOW_ONLY_UNPROCESSED = ''Y'' AND '
||'NVL(bd.is_evaluated, 0) = 0))',
'-- GROUP BY fb.vorschriftid, fb.manueller_eintrag, fb.sucheid, fb.meilenstein, fb.vorschriftnummer, fb.card_number, cc.total_countries',
'GROUP BY fb.vorschriftid, fb.manueller_eintrag, fb.sucheid, fb.meilenstein, fb.vorschriftnummer, fb.card_number, cc.total_countries, fsc.is_first_search',
'HAVING (:P51_CRITICALITY_FILTER = ''ALL'' OR (:P51_CRITICALITY_FILTER = ''CHANGED'' AND MAX(pmd.prev_kritikalitaet) IS NOT NULL AND NVL(MAX(rc.max_kritikalitaet), 0) != MAX(pmd.prev_kritikalitaet)) OR (:P51_CRITICALITY_FILTER = ''INCREASED'' AND MAX(pmd.pr'
||'ev_kritikalitaet) IS NOT NULL AND NVL(MAX(rc.max_kritikalitaet), 0) > MAX(pmd.prev_kritikalitaet)) OR (:P51_CRITICALITY_FILTER = ''DECREASED'' AND MAX(pmd.prev_kritikalitaet) IS NOT NULL AND NVL(MAX(rc.max_kritikalitaet), 0) < MAX(pmd.prev_kritikalitae'
||'t)))',
'ORDER BY MAX(fb.manueller_eintrag) DESC, LISTAGG(DISTINCT fb.landnummer, ''; '') WITHIN GROUP (ORDER BY fb.landnummer), LISTAGG(DISTINCT fb.themabezeichnung, ''; '') WITHIN GROUP (ORDER BY fb.themabezeichnung);',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P51_LANDIDS,P51_SEARCH_SELECTION,P51_MILESTONE_SELECTION,P51_PUBLISHER_FILTER,P51_SHOW_ONLY_UNPROCESSED,P51_CRITICALITY_FILTER'
,p_plug_display_condition_type=>'NEVER'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'&P461_CARD_TITLE. - working 28 oct'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    ms.landnummer||'' - ''||ms.landbezeichnung AS Land,',
'    ms.vorschriftnummer as Vorschriftennummer,',
'    ms.vorschrifttitel as Vorschrifttitel,',
'    ms.status_vorschrift as Status,',
unistr('    ms.prognose_qualitaet as Prognose_Qualit\00E4t,'),
'    ms.sw_relevant as SW_Relevant,',
'    ms.risiko as Risiko',
'FROM T_MS_SUCHERGEBNISS ms',
'WHERE ms.sucheid = :P461_SEARCH_SELECTION ',
'AND ms.meilenstein = :P461_MILESTONE_SELECTION',
'AND ms.landid IN (',
'    SELECT TO_NUMBER(column_value)',
'    FROM TABLE(apex_string.split(:P461_LANDIDS, '':''))',
')',
'AND ms.vorschriftnummer IS NOT NULL',
'ORDER BY ',
'    Land,',
'    Vorschriftennummer'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1792552501130008813)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>5464764817029397048
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926696353677382016)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'<input type="checkbox" id="selectUnselectAll" title="Select/UnselectAll" value="all" />'
,p_column_html_expression=>'<input type="checkbox" value="#SPECIFIC_REG_ID#" />'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
,p_column_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'html exp ',
'',
'<input type="checkbox" value="#SPECIFIC_REG_ID#" />',
'',
'',
'<input type="checkbox" id="selectUnselectAll" title="Select/UnselectAll" value="all" />'))
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926695940218382010)
,p_db_column_name=>'ROW_EDIT_LINK'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926695601994382010)
,p_db_column_name=>'EDIT_ACTION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926695214183382009)
,p_db_column_name=>'CARD_NUMBER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Kartennummer'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926694741273382008)
,p_db_column_name=>'B_NUMMER_LISTE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'B Nummer Liste'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926694402889382007)
,p_db_column_name=>'LAND_NAMEN_LISTE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Land Namen Liste'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926693957440382006)
,p_db_column_name=>'THEMABEZEICHNUNG'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Themabezeichnung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926693536030382006)
,p_db_column_name=>'VORSCHRIFTENNUMMER'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926693170896382005)
,p_db_column_name=>'ALTERNATIVE_VORSCHRIFTENNUMMER'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Alternative Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926692750901382004)
,p_db_column_name=>'PUBLISHER'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Publisher'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926692372094382003)
,p_db_column_name=>'MANUELLER_EINTRAG'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Eintrag Typ'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P51_BEWERTUNG_ANSICHT = ''ET'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926691936895382001)
,p_db_column_name=>'DELETE_ACTION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926691557522382000)
,p_db_column_name=>'SPECIFIC_REG_ID'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Specific Vorschrift ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926691149045381999)
,p_db_column_name=>'SEARCH_ID_HIDDEN'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Search Id Hidden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926690790687381999)
,p_db_column_name=>'MILESTONE_HIDDEN'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Milestone Hidden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926690403130381998)
,p_db_column_name=>'LANDIDS_HIDDEN'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Landids Hidden'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926689932165381997)
,p_db_column_name=>'RXSWIN_RELEVANT'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'potentiell SUMS-Relevant'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(958135905312245351)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926689604501381996)
,p_db_column_name=>'LRSA'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'LRSA'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926689209011381995)
,p_db_column_name=>'HOMOLOGATIONSEIGENSCHAFT'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Homologationseigenschaft'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926688804410381993)
,p_db_column_name=>'ET_KOMMENTAR'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'ET Kommentar'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P51_BEWERTUNG_ANSICHT IN (''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_column_comment=>':P461_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926688403250381991)
,p_db_column_name=>'ET_VERWENDUNG'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'ET Verwendung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P51_BEWERTUNG_ANSICHT IN (''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_column_comment=>':P461_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926687990306381990)
,p_db_column_name=>'ET_VORSCHLAG_VORSCHRIFT'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'ET Vorschlag Vorschrift'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P51_BEWERTUNG_ANSICHT IN (''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_column_comment=>':P461_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926687546625381989)
,p_db_column_name=>'KRITIKALITAET_VON_REGELNUMMER'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Kritikalitaet Von Regelnummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926687206583381988)
,p_db_column_name=>'AUSGABE_TEXT_VON_REGELNUMMER'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Ausgabe Text von Regelnummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926686808590381987)
,p_db_column_name=>'LANDIDS'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Landids'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926686344394381986)
,p_db_column_name=>'NACHFOLGER_VORSCHRIFT'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Nachfolger Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926685960694381984)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Vorschrift ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926685606144381983)
,p_db_column_name=>'ALTERNATIVE_VORSCHRIFTID'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Alternative Vorschrift ID'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926685189185381983)
,p_db_column_name=>unistr('Kritikalit\00E4t (M-1)')
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>unistr('Kritikalit\00E4t (M-1)')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P51_BEWERTUNG_ANSICHT IN (''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926684764092381982)
,p_db_column_name=>'ET Verwendung (M-1)'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'ET Verwendung (M-1)'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P51_BEWERTUNG_ANSICHT IN (''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926684361304381981)
,p_db_column_name=>'ET Kommentar (M-1)'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'ET Kommentar (M-1)'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P51_BEWERTUNG_ANSICHT IN (''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926683935513381980)
,p_db_column_name=>unistr('\00C4nderung zu M-1')
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>unistr('\00C4nderung zu (M-1)')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926683601420381980)
,p_db_column_name=>'Massenupdate Status'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Massenupdate Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5061342789750967370)
,p_plug_name=>unistr('Kritikalit\00E4ts-Indikatoren')
,p_region_template_options=>'#DEFAULT#:margin-bottom-sm'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>80
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="criticality-legend" style="background: #e3f2fd; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #2196f3;">',
unistr('    <strong>Kritikalit\00E4ts-Indikatoren:</strong>'),
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-arrow-up" style="color: #fff; background-color: #e74c3c; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padding: 2px; width: 16px; height: 16px; vertical-align: middle;'
||'"></i> ',
'        Gestiegen',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-arrow-down" style="color: #fff; background-color: #27ae60; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padding: 2px; width: 16px; height: 16px; vertical-align: middl'
||'e;"></i> ',
'        Gesunken',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-check-circle" style="color: #95a5a6; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        Unver\00E4ndert'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-plus-circle" style="color: #27ae60; font-size: 14px; vertical-align: middle;"></i> ',
'        Neu',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-edit" style="color: #f39c12; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        Text ge\00E4ndert'),
'    </span>',
'</div>',
'',
'',
'',
'<!-- <div class="criticality-legend" style="background: #e3f2fd; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #2196f3;">',
unistr('    <strong>Kritikalit\00E4ts-Indikatoren:</strong>'),
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-arrow-up" style="color: #fff; background-color: #e74c3c; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padding: 2px; width: 16px; height: 16px; vertical-align: middle;'
||'"></i> ',
'        Gestiegen',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-arrow-down" style="color: #fff; background-color: #27ae60; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padding: 2px; width: 16px; height: 16px; vertical-align: middl'
||'e;"></i> ',
'        Gesunken',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-check-circle" style="color: #fff; background-color: #95a5a6; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padding: 2px; width: 16px; height: 16px; vertical-align: mid'
||'dle;"></i> ',
unistr('        Unver\00E4ndert'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-plus-circle" style="color: #fff; background-color: #3498db; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padding: 2px; width: 16px; height: 16px; vertical-align: midd'
||'le; "></i> ',
'        Neu',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-edit" style="color: #fff; background-color: #f39c12; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padding: 2px; width: 16px; height: 16px; vertical-align: middle;"></'
||'i> ',
unistr('        Text ge\00E4ndert'),
'    </span>',
'</div> -->',
'',
'',
''))
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5061713817063164937)
,p_plug_name=>'Warning Icons Legend'
,p_region_template_options=>'#DEFAULT#:margin-bottom-sm'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="warning-legend" style="background: #fff3cd; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #ffc107;">',
'    <strong>Warnungs-Indikatoren:</strong>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-exclamation-triangle" style="color: #ff6600; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        Nicht alle L\00E4nder/Themen abgedeckt'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-check-circle" style="color: #27ae60; font-size: 14px; vertical-align: middle;"></i> ',
'        Bereits bewertet',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-clipboard-list fam-check fam-is-success" style="color: #007bff; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        In anderem Markt ausgew\00E4hlt'),
'    </span>',
'</div>'))
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5061713960245164938)
,p_plug_name=>'Entry Type Legend'
,p_region_template_options=>'#DEFAULT#:margin-bottom-sm'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>100
,p_plug_grid_column_span=>4
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!-- <div class="entry-type-legend" style="background: #f8f9fa; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #bb0a31;">',
'    <strong>Eintrag-Typen:</strong>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-user-plus" style="color: #bb0a31; font-size: 14px; vertical-align: middle;"></i> ',
'        Manueller Eintrag',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-cog" style="color: #bb0a31; font-size: 14px; vertical-align: middle;"></i> ',
'        Automatischer Eintrag',
'    </span>',
'</div> -->',
'',
'',
'',
'<div class="entry-type-legend" style="background: #e8f5e9; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #4caf50;">',
'    <strong>Eintrag-Typen:</strong>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-user-plus" style="color: #bb0a31; font-size: 14px; vertical-align: middle;"></i> ',
'        Manueller Eintrag',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-cog" style="color: #bb0a31; font-size: 14px; vertical-align: middle;"></i> ',
'        Automatischer Eintrag',
'    </span>',
'</div>'))
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5061714087315164939)
,p_plug_name=>'Evaluation Status Legend'
,p_region_template_options=>'#DEFAULT#:margin-bottom-sm'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>110
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!-- <div class="evaluation-legend" style="background: #f8f9fa; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #6c757d;">',
'    <strong>Bewertungs-Status:</strong>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-check" style="color: #27ae60; font-weight: bold; vertical-align: middle;"></i> ',
'        <span style="color: #27ae60; font-weight: bold;">ja</span>',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-times" style="color: #e74c3c; font-weight: bold; vertical-align: middle;"></i> ',
'        <span style="color: #e74c3c; font-weight: bold;">nein</span>',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <span style="color: #666; font-style: italic;">nicht bewertet</span>',
'    </span>',
'</div> -->',
'',
'',
'<div class="evaluation-legend" style="background: #f3e5f5; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #9c27b0;">',
'    <strong>Bewertungs-Status:</strong>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-check" style="color: #27ae60; font-weight: bold; vertical-align: middle;"></i> ',
'        <span style="color: #27ae60; font-weight: bold;">ja</span>',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-times" style="color: #e74c3c; font-weight: bold; vertical-align: middle;"></i> ',
'        <span style="color: #e74c3c; font-weight: bold;">nein</span>',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <span style="color: #666; font-style: italic;">nicht bewertet</span>',
'    </span>',
'</div>'))
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5061714112189164940)
,p_plug_name=>'Change Summary Legend (for M-1 comparison)'
,p_region_template_options=>'#DEFAULT#:margin-bottom-sm'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>120
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!-- <div class="change-summary-legend" style="background: #f8f9fa; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #17a2b8;">',
unistr('    <strong>\00C4nderungs-Status zu M-1:</strong>'),
'    <span style="margin-left: 15px;">',
unistr('        <span style="color: #27ae60; font-weight: bold;">Neu hinzugef\00FCgt</span>'),
'    </span>',
'    <span style="margin-left: 15px;">',
unistr('        <span style="color: #f39c12; font-weight: bold;">Kritikalit\00E4t ge\00E4ndert</span>'),
'    </span>',
'    <span style="margin-left: 15px;">',
unistr('        <span style="color: #3498db; font-weight: bold;">Bewertung ge\00E4ndert</span>'),
'    </span>',
'    <span style="margin-left: 15px;">',
unistr('        <span style="color: #95a5a6;">Keine \00C4nderung</span>'),
'    </span>',
'</div> -->',
'',
'',
'<div class="change-summary-legend" style="background: #e0f2f1; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #009688;">',
unistr('    <strong>\00C4nderungs-Status zu M-1:</strong>'),
'    <span style="margin-left: 15px;">',
unistr('        <span style="color: #27ae60; font-weight: bold;">Neu hinzugef\00FCgt</span>'),
'    </span>',
'    <span style="margin-left: 15px;">',
unistr('        <span style="color: #f39c12; font-weight: bold;">Kritikalit\00E4t ge\00E4ndert</span>'),
'    </span>',
'    <span style="margin-left: 15px;">',
unistr('        <span style="color: #3498db; font-weight: bold;">Bewertung ge\00E4ndert</span>'),
'    </span>',
'    <span style="margin-left: 15px;">',
unistr('        <span style="color: #95a5a6;">Keine \00C4nderung</span>'),
'    </span>',
'</div>'))
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12591081239047263753)
,p_plug_name=>'&P51_CARD_TITLE.'
,p_region_name=>'R45756756756575'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>130
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT * FROM TABLE(',
'    PKG_REGULATION_REPORT.get_regulations_data(',
'        p_search_selection      => :P51_SEARCH_SELECTION,',
'        p_milestone_selection   => :P51_MILESTONE_SELECTION,',
'        p_card_num             => :P51_CARD_NUM,',
'        p_landids              => :P51_LANDIDS,',
'        p_postprozess_id       => :P51_POSTPROZESS_ID,',
'        p_benutzerid           => :G_BENUTZERID,',
'        p_publisher_filter     => :P51_PUBLISHER_FILTER,',
'        p_show_only_unprocessed => :P51_SHOW_ONLY_UNPROCESSED,',
'        p_criticality_filter   => :P51_CRITICALITY_FILTER,',
'        p_app_id               => :APP_ID,',
'        p_app_session          => :APP_SESSION,',
'        p_debug                => :DEBUG,',
'        p_sort_order           => :P51_SORT_ORDER',
'    )',
');'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P51_LANDIDS,P51_SEARCH_SELECTION,P51_MILESTONE_SELECTION,P51_PUBLISHER_FILTER,P51_SHOW_ONLY_UNPROCESSED,P51_CRITICALITY_FILTER,P51_SORT_ORDER'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'&P461_CARD_TITLE.'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(13637323735829525427)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>17309536051728913662
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926675191581381951)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>10
,p_column_identifier=>'AE'
,p_column_label=>'<input type="checkbox" id="selectUnselectAll" title="Select/UnselectAll" value="all" />'
,p_column_html_expression=>'<input type="checkbox" value="#SPECIFIC_REG_ID#" />'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
,p_column_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'html exp ',
'',
'<input type="checkbox" value="#SPECIFIC_REG_ID#" />',
'',
'',
'<input type="checkbox" id="selectUnselectAll" title="Select/UnselectAll" value="all" />'))
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926674790951381951)
,p_db_column_name=>'ROW_EDIT_LINK'
,p_display_order=>20
,p_column_identifier=>'AG'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926678742247381953)
,p_db_column_name=>'EDIT_ACTION'
,p_display_order=>30
,p_column_identifier=>'M'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926680402164381954)
,p_db_column_name=>'CARD_NUMBER'
,p_display_order=>40
,p_column_identifier=>'G'
,p_column_label=>'Kartennummer'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926673594310381950)
,p_db_column_name=>'B_NUMMER_LISTE'
,p_display_order=>50
,p_column_identifier=>'A'
,p_column_label=>'B Nummer Liste'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926673137940381950)
,p_db_column_name=>'LAND_NAMEN_LISTE'
,p_display_order=>60
,p_column_identifier=>'B'
,p_column_label=>'Land Namen Liste'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926672736316381949)
,p_db_column_name=>'THEMABEZEICHNUNG'
,p_display_order=>70
,p_column_identifier=>'C'
,p_column_label=>'Themabezeichnung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_static_id=>'THEMABEZEICHNUNG_COL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926672326844381949)
,p_db_column_name=>'VORSCHRIFTENNUMMER'
,p_display_order=>80
,p_column_identifier=>'D'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926681117101381955)
,p_db_column_name=>'ALTERNATIVE_VORSCHRIFTENNUMMER'
,p_display_order=>90
,p_column_identifier=>'E'
,p_column_label=>'Alternative Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926680778766381954)
,p_db_column_name=>'PUBLISHER'
,p_display_order=>100
,p_column_identifier=>'F'
,p_column_label=>'Publisher'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926679926544381954)
,p_db_column_name=>'MANUELLER_EINTRAG'
,p_display_order=>110
,p_column_identifier=>'I'
,p_column_label=>'Eintrag Typ'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P51_BEWERTUNG_ANSICHT = ''ET'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926679562273381954)
,p_db_column_name=>'DELETE_ACTION'
,p_display_order=>120
,p_column_identifier=>'J'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926679155602381954)
,p_db_column_name=>'SPECIFIC_REG_ID'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Specific Vorschrift ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926678339650381953)
,p_db_column_name=>'SEARCH_ID_HIDDEN'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Search Id Hidden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926677915978381952)
,p_db_column_name=>'MILESTONE_HIDDEN'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Milestone Hidden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926677583119381952)
,p_db_column_name=>'LANDIDS_HIDDEN'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Landids Hidden'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926677201836381952)
,p_db_column_name=>'LRSA'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'LRSA'
,p_column_type=>'STRING'
,p_static_id=>'LRSA_COL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926676785836381952)
,p_db_column_name=>'HOMOLOGATIONSEIGENSCHAFT'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Homologationseigenschaft'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_static_id=>'HOMOLOGATION_COL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926675539103381951)
,p_db_column_name=>'ET_KOMMENTAR'
,p_display_order=>220
,p_column_identifier=>'Y'
,p_column_label=>'ET Kommentar'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P51_BEWERTUNG_ANSICHT IN (''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_column_comment=>':P461_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926676336996381952)
,p_db_column_name=>'ET_VERWENDUNG'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'ET Verwendung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P51_BEWERTUNG_ANSICHT IN (''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_column_comment=>':P461_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926675922489381951)
,p_db_column_name=>'ET_VORSCHLAG_VORSCHRIFT'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'ET Vorschlag Vorschrift'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P51_BEWERTUNG_ANSICHT IN (''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_column_comment=>':P461_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926674364773381950)
,p_db_column_name=>'KRITIKALITAET_VON_REGELNUMMER'
,p_display_order=>300
,p_column_identifier=>'AI'
,p_column_label=>'Kritikalitaet Von Regelnummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926673938266381950)
,p_db_column_name=>'AUSGABE_TEXT_VON_REGELNUMMER'
,p_display_order=>310
,p_column_identifier=>'AJ'
,p_column_label=>'Ausgabe Text von Regelnummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_static_id=>'AUSGABETEXT_COL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926671986053381949)
,p_db_column_name=>'LANDIDS'
,p_display_order=>320
,p_column_identifier=>'AK'
,p_column_label=>'Landids'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926671594415381949)
,p_db_column_name=>'NACHFOLGER_VORSCHRIFT'
,p_display_order=>330
,p_column_identifier=>'AL'
,p_column_label=>'Nachfolger Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_static_id=>'NACHFOLGER_COL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926671175266381949)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>340
,p_column_identifier=>'AM'
,p_column_label=>'Vorschrift ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926670766011381949)
,p_db_column_name=>'ALTERNATIVE_VORSCHRIFTID'
,p_display_order=>350
,p_column_identifier=>'AO'
,p_column_label=>'Alternative Vorschrift ID'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926670341177381948)
,p_db_column_name=>unistr('Kritikalit\00E4t (M-1)')
,p_display_order=>360
,p_column_identifier=>'AP'
,p_column_label=>unistr('Kritikalit\00E4t (M-1)')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P51_BEWERTUNG_ANSICHT IN (''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926669958556381948)
,p_db_column_name=>'ET Verwendung (M-1)'
,p_display_order=>370
,p_column_identifier=>'AQ'
,p_column_label=>'ET Verwendung (M-1)'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P51_BEWERTUNG_ANSICHT IN (''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926669561117381948)
,p_db_column_name=>'ET Kommentar (M-1)'
,p_display_order=>380
,p_column_identifier=>'AR'
,p_column_label=>'ET Kommentar (M-1)'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P51_BEWERTUNG_ANSICHT IN (''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926669126134381948)
,p_db_column_name=>unistr('\00C4nderung zu M-1')
,p_display_order=>390
,p_column_identifier=>'AS'
,p_column_label=>unistr('\00C4nderung zu (M-1)')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926668766505381948)
,p_db_column_name=>'Massenupdate Status'
,p_display_order=>400
,p_column_identifier=>'AT'
,p_column_label=>'Massenupdate Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926668395716381947)
,p_db_column_name=>'RXSWIN_RELEVANT'
,p_display_order=>410
,p_column_identifier=>'AU'
,p_column_label=>'Rxswin Relevant'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926667936611381947)
,p_db_column_name=>unistr('Kritikalit\00E4t (Vorherige Suche)')
,p_display_order=>420
,p_column_identifier=>'AV'
,p_column_label=>unistr('Kritikalit\00E4t (vorherige Suche)')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P51_BEWERTUNG_ANSICHT IN (''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926667576288381947)
,p_db_column_name=>'ET Verwendung (Vorherige Suche)'
,p_display_order=>430
,p_column_identifier=>'AW'
,p_column_label=>'Et Verwendung (vorherige Suche)'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P51_BEWERTUNG_ANSICHT IN (''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926667190878381947)
,p_db_column_name=>'ET Kommentar (Vorherige Suche)'
,p_display_order=>440
,p_column_identifier=>'AX'
,p_column_label=>'Et Kommentar (vorherige Suche)'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P51_BEWERTUNG_ANSICHT IN (''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(926666758110381946)
,p_db_column_name=>unistr('\00C4nderung zu Vorheriger Suche')
,p_display_order=>450
,p_column_identifier=>'AY'
,p_column_label=>unistr('\00C4nderung Zu Vorheriger Suche')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(11531279208252841340)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5427309'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EDIT_ACTION:DELETE_ACTION:CHECKBOX:ROW_EDIT_LINK:CARD_NUMBER:VORSCHRIFTID:ALTERNATIVE_VORSCHRIFTID:B_NUMMER_LISTE:LAND_NAMEN_LISTE:THEMABEZEICHNUNG:VORSCHRIFTENNUMMER:ALTERNATIVE_VORSCHRIFTENNUMMER:PUBLISHER:LRSA:HOMOLOGATIONSEIGENSCHAFT:NACHFOLGER_V'
||unistr('ORSCHRIFT:KRITIKALITAET_VON_REGELNUMMER:Kritikalit\00E4t (M-1):AUSGABE_TEXT_VON_REGELNUMMER:\00C4nderung zu M-1:Massenupdate Status:ET_KOMMENTAR:ET Kommentar (M-1):ET_VERWENDUNG:ET Verwendung (M-1):ET_VORSCHLAG_VORSCHRIFT:ET Kommentar (Vorherige Suche):ET Ve')
||unistr('rwendung (Vorherige Suche):Kritikalit\00E4t (Vorherige Suche):\00C4nderung zu Vorheriger Suche:')
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14692818602427784783)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="header-actions" style="display: flex; align-items: center;">',
'    <!-- Status indicator -->',
'    <span id="detailPageStatus" class="status-indicator &P51_CARD_STATUS." ',
'          data-card="&P51_CARD_NUM." ',
'          onclick="cycleDetailStatus(&P51_CARD_NUM.)" ',
unistr('          title="Status \00E4ndern">'),
'        <!-- Status icon  -->',
'    </span>',
'    ',
'    ',
'</div>'))
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(926655288931381897)
,p_button_sequence=>50
,p_button_name=>'BACK_TO_OVERVIEW'
,p_button_static_id=>'B1681487548999'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--pillEnd:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Zur\00FCck zur \00DCbersicht')
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-long-arrow-left'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'f?p=&APP_ID.:460:&SESSION.::&DEBUG.:RP,460:P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION,P460_REFRESH_CARDS:&P461_SEARCH_SELECTION.,&P461_MILESTONE_SELECTION.,Y',
'',
'',
'f?p=&APP_ID.:460:&SESSION.::&DEBUG.:RP,460:P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION,P460_REFRESH_CARDS,P460_JUST_UPDATED_CARD,P460_JUST_UPDATED_STATUS:&P461_SEARCH_SELECTION.,&P461_MILESTONE_SELECTION.,Y,&P461_CARD_NUM.,&P461_CARD_STATUS.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(926666093322381934)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_button_name=>'SelectedFilterName'
,p_button_static_id=>'selectedfilter461'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('<b style=" font-size:14px">Ausgew\00E4hlter Filtername</b> <b><u><i><span style="color:#bb0a31; font-size:14px">&P51_FILTER_PROFILE.</span></i></u></b>')
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-user-check'
,p_button_comment=>'<b font-size:16px>Selected Filter Name</b> <b><u><i><span style="color:#bb0a31; font-size:16px">&P461_FILTER_PROFILE.</span></i></u></b>'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(926665680299381930)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_button_name=>'DownloadExcelReport'
,p_button_static_id=>'DownloadExcelReport1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Daten herunterladen f\00FCr Aller L\00E4nder Vorschriften')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-download-alt'
,p_button_comment=>'B3485834934459875'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(926665296291381929)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_button_name=>'DownloadExcelReport_1'
,p_button_static_id=>'DownloadExcelReport'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Daten herunterladen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-download-alt'
,p_button_comment=>'B3485834934459875'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(926664876516381929)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Fehlende Vorschrift hinzuf\00FCgen')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:465:&SESSION.::&DEBUG.:465:P465_MODE,P465_MANUAL_MODE,P465_SEARCH_SELECTION,P465_MILESTONE_SELECTION,P465_LANDIDS,P465_CARD_NUM,P465_RETURN_PAGE:CREATE,Y,&P51_SEARCH_SELECTION.,&P51_MILESTONE_SELECTION.,&P51_LANDIDS.,&P51_CARD_NUM.,461'
,p_icon_css_classes=>'fa-gears'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(926664444032381928)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_button_name=>'BTN_MASS_UPDATE'
,p_button_static_id=>'b_mass_update'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'Massenupdate'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:464:&SESSION.::&DEBUG.:464:P464_LOAD_FROM,P464_SEARCH_SELECTION,P464_MILESTONE_SELECTION,P464_CARD_NUM:"P51_SELECTED_ROWS",&P51_SEARCH_SELECTION.,&P51_MILESTONE_SELECTION.,&P51_CARD_NUM.'
,p_icon_css_classes=>'fa-user-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(926664084639381927)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_button_name=>'BTN_COPY_PERMALINK'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Permalink in Zwischenablage kopieren'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa fa-link'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(926663665587381927)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_button_name=>'VERGLEICHEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--warning:t-Button--iconLeft:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'Vergleichen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:471:&SESSION.::&DEBUG.:471:P471_SEARCH_1,P471_MILESTONE_1,P471_CARD_NUM:&P51_SEARCH_SELECTION.,&P51_MILESTONE_SELECTION.,&P51_CARD_NUM.'
,p_icon_css_classes=>'fa fa-code-fork fa-rotate-180'
,p_button_comment=>':G_BENUTZERID = 2000'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(926663229169381927)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_button_name=>'BTN_SHOW_LEGENDS2'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--pillEnd:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Legende anzeigen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(926662857538381927)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_button_name=>'BTN_SHOW_LEGENDS'
,p_button_static_id=>'B577439449482037513'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'Legende anzeigen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:475:&SESSION.::&DEBUG.:475:P475_CARD_NUM,P475_SEARCH_SELECTION,P475_MILESTONE_SELECTION,P475_SOURCE_PAGE:&P51_CARD_NUM.,&P51_SEARCH_SELECTION.,&P51_MILESTONE_SELECTION.,461'
,p_icon_css_classes=>'fa-info-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(926662496995381927)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_button_name=>'BTN_HISTORY'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('\00C4nderungshistorie anzeigen')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:467:&SESSION.::&DEBUG.:467:P467_CARD_NUM,P467_SEARCH_SELECTION,P467_MILESTONE_SELECTION:&P51_CARD_NUM.,&P51_SEARCH_SELECTION.,&P51_MILESTONE_SELECTION.'
,p_icon_css_classes=>'fa-history'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(926633442847381869)
,p_branch_name=>'Go To Page 465'
,p_branch_action=>'f?p=&APP_ID.:465:&SESSION.::&DEBUG.:465:P465_MODE,P465_MANUAL_MODE,P465_SEARCH_SELECTION,P465_MILESTONE_SELECTION,P465_LANDIDS,P465_CARD_NUM,P465_RETURN_PAGE:CREATE,Y,&P51_SEARCH_SELECTION.,&P51_MILESTONE_SELECTION.,&P51_LANDIDS.,&P51_CARD_NUM.,461'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926662080514381926)
,p_name=>'P51_CARD_TITLE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CASE ',
'        WHEN COUNT(*) = 1 THEN',
'            MAX(l.B_NUMMER || '' - '' || l.LAND)',
'        ELSE',
'            LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '') ',
'            WITHIN GROUP (ORDER BY l.B_NUMMER)',
'    END AS card_title',
'FROM t_land l',
'WHERE l.LANDID IN (',
'    SELECT TO_NUMBER(column_value)',
'    FROM TABLE(apex_string.split(:P51_LANDIDS, '';''))',
')'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926661633961381923)
,p_name=>'P51_CARD_STATUS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926661232124381922)
,p_name=>'P51_LANDIDS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926660901420381922)
,p_name=>'P51_CARD_NUM'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926660461348381922)
,p_name=>'P51_SEARCH_SELECTION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926660102548381922)
,p_name=>'P51_MILESTONE_SELECTION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926659658017381922)
,p_name=>'P51_STATUS_INDICATOR'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926659245120381922)
,p_name=>'P51_MSG_TIMEOUT'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926658842893381921)
,p_name=>'P51_CUSTOM_TITLE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926658474432381921)
,p_name=>'P51_SELECTED_ROWS'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926658034822381921)
,p_name=>'P51_PUBLISHER_FILTER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_prompt=>'Publisher'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    publisher as d,',
'    publisher as r',
'FROM (',
'    -- Publishers from alternative regulations',
'    SELECT tv_alt.publisher',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT OUTER JOIN t_vorschrift tv_alt ON (tv_alt.vorschriftid = ms.alternative_vorschriftid)',
'    WHERE ms.sucheid = :P51_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P51_MILESTONE_SELECTION',
'    AND ms.landid IN (',
'        SELECT TO_NUMBER(TRIM(column_value))',
'        FROM TABLE(apex_string.split(TRIM(:P51_LANDIDS), '';''))',
'    )',
'    AND tv_alt.publisher IS NOT NULL',
'    ',
'    UNION',
'    ',
'    -- Publishers from main regulations (for manual entries)',
'    SELECT tv_main.publisher',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT OUTER JOIN t_vorschrift tv_main ON (tv_main.vorschriftid = ms.vorschriftid)',
'    WHERE ms.sucheid = :P51_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P51_MILESTONE_SELECTION',
'    AND ms.landid IN (',
'        SELECT TO_NUMBER(TRIM(column_value))',
'        FROM TABLE(apex_string.split(TRIM(:P51_LANDIDS), '';''))',
'    )',
'    AND tv_main.publisher IS NOT NULL',
')',
'WHERE publisher IS NOT NULL',
'ORDER BY publisher'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Ausw\00E4hlen --')
,p_lov_cascade_parent_items=>'P51_SEARCH_SELECTION,P51_MILESTONE_SELECTION,P51_LANDIDS'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>25
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:margin-top-none'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    v.publisher as d,',
'    v.publisher as r',
'FROM T_MS_SUCHERGEBNISS ms',
'LEFT OUTER JOIN t_vorschrift tv ON (tv.vorschriftid = ms.alternative_vorschriftid)',
'LEFT OUTER JOIN t_vorschrift v ON (v.vorschriftid = ms.alternative_vorschriftid)',
'WHERE ms.sucheid = :P51_SEARCH_SELECTION ',
'AND ms.meilenstein = :P51_MILESTONE_SELECTION',
'AND ms.landid IN (',
'    SELECT TO_NUMBER(TRIM(column_value))',
'    FROM TABLE(apex_string.split(TRIM(:P51_LANDIDS), '';''))',
')',
'AND v.publisher IS NOT NULL',
'ORDER BY v.publisher'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926657640730381920)
,p_name=>'P51_BEWERTUNG_ANSICHT'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_item_default=>'ET'
,p_prompt=>'<b>Bewertung Ansicht</b>'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT display_value as d, return_value as r',
'FROM (',
'    SELECT ''ET-B Abstimmung'' as display_value, ''ET'' as return_value, 1 as sort_order FROM dual',
'    UNION ALL',
'    -- SELECT ''ET-A Vorschlag'', ''FB'', 2 FROM dual',
'    -- UNION ALL',
'    SELECT ''ET-Konfiguration'', ''ANDERE'', 3 FROM dual',
')',
'ORDER BY sort_order'))
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:margin-top-none:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT display_value as d, return_value as r',
'FROM (',
'    SELECT ''ET-B Abstimmung'' as display_value, ''ET'' as return_value, 1 as sort_order FROM dual',
'    UNION ALL',
'    SELECT ''ET-A Vorschlag'', ''FB'', 2 FROM dual',
'    UNION ALL',
'    SELECT ''ET-Konfiguration'', ''ANDERE'', 3 FROM dual',
')',
'ORDER BY sort_order'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926657282501381920)
,p_name=>'P51_SHOW_ONLY_UNPROCESSED'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_item_default=>'N'
,p_prompt=>'<b>Nur unbearbeitete anzeigen</b>'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'unchecked_value', 'N',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926656842540381919)
,p_name=>'P51_CRITICALITY_FILTER'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_item_default=>'ALL'
,p_prompt=>unistr('<b>Kritikalit\00E4ts-\00C4nderungen</b>')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT display_value as d, return_value as r',
'FROM (',
'    SELECT ''Alle anzeigen'' as display_value, ''ALL'' as return_value, 1 as sort_order FROM dual',
'    UNION ALL',
unistr('    SELECT ''Nur \00C4nderungen'', ''CHANGED'', 2 FROM dual'),
'    UNION ALL',
unistr('    SELECT ''Nur Erh\00F6hungen'', ''INCREASED'', 3 FROM dual'),
'    UNION ALL',
'    SELECT ''Nur Reduzierungen'', ''DECREASED'', 4 FROM dual',
')',
'ORDER BY sort_order'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '4',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926656463243381919)
,p_name=>'P51_POSTPROZESS_ID'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926656049596381919)
,p_name=>'P51_PERMALINK'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.host_url(''SCRIPT'') ||',
'apex_page.get_url(',
'    p_application => :APP_ALIAS,',
'    p_page => ''PRI'',',
'    p_items => ''P51_LANDIDS,P51_CARD_NUM,P51_SEARCH_SELECTION,P51_MILESTONE_SELECTION,P51_CARD_STATUS,P51_FILTER_PROFILE,P51_CUSTOM_TITLE'',',
'    p_values => :P51_LANDIDS || '','' || :P51_CARD_NUM || '','' || :P51_SEARCH_SELECTION || '','' || :P51_MILESTONE_SELECTION || '','' || :P51_CARD_STATUS || '','' || :P51_FILTER_PROFILE || '','' || :P51_CUSTOM_TITLE,',
'    p_session => null,',
'    p_clear_cache => ''461''',
')'))
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.host_url(''SCRIPT'') || apex_page.get_url(',
'    p_application => :APP_ALIAS',
'    , p_page => ''VORSCHRIFT''',
'    , p_items => ''P25_VORSCHRIFTID''',
'    , p_values => :P25_VORSCHRIFTID',
'    , p_session => null',
'    , p_clear_cache => ''25''',
')'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926655706167381918)
,p_name=>'P51_SORT_ORDER'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(12591081239047263753)
,p_item_default=>'ASC'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926654891988381896)
,p_name=>'P51_FILTER_PROFILE'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(926654460304381895)
,p_name=>'P51_SUCHE_ID'
,p_item_sequence=>60
,p_use_cache_before_default=>'NO'
,p_prompt=>'Suche Id'
,p_source=>'P51_SEARCH_SELECTION'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_grid_column=>10
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(926650456501381886)
,p_name=>'Dialog Titel'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926649986167381882)
,p_event_id=>wwv_flow_imp.id(926650456501381886)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(window.parent.document).find(''.ui-dialog-title'').text($v(''P51_CARD_TITLE''));'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(926649583332381881)
,p_name=>'Back to Overview'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(926655288931381897)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926649026733381881)
,p_event_id=>wwv_flow_imp.id(926649583332381881)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// // Prevent default button action',
'// this.browserEvent.preventDefault();',
'',
'// // Get the current status reliably from database',
'// apex.server.process(',
'//     ''GET_CURRENT_CARD_STATUS'',',
'//     {',
'//         x01: $v(''P51_CARD_NUM''),',
'//         x02: $v(''P51_SEARCH_SELECTION''),',
'//         x03: $v(''P51_MILESTONE_SELECTION'')',
'//     },',
'//     {',
'//         success: function(data) {',
'//             // Use database status or fallback to current page status',
'//             const currentStatus = data.status || $v(''P51_CARD_STATUS'') || ''not-started'';',
'            ',
'//             console.log(`Returning to overview with status: ${currentStatus}`);',
'            ',
'//             // Build the URL with reliable status',
'//             const url = ''f?p='' + $v(''pFlowId'') + '':460:'' + $v(''pInstance'') + ',
'//                 ''::'' + $v(''pDebug'') + '':RP,460:'' + ',
'//                 ''P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION,P460_REFRESH_CARDS,'' + ',
'//                 ''P460_JUST_UPDATED_CARD,P460_JUST_UPDATED_STATUS:'' + ',
'//                 $v(''P51_SEARCH_SELECTION'') + '','' + ',
'//                 $v(''P51_MILESTONE_SELECTION'') + '','' + ',
'//                 ''Y,'' + ',
'//                 $v(''P51_CARD_NUM'') + '','' + ',
'//                 currentStatus;',
'            ',
'//             // Navigate to the URL',
'//             apex.navigation.redirect(url);',
'//         },',
'//         error: function(xhr, status, error) {',
'//             console.error(''Error getting current status:'', error);',
'            ',
'//             // Fallback to using the page item directly',
'//             const currentStatus = $v(''P51_CARD_STATUS'') || ''not-started'';',
'            ',
'//             const url = ''f?p='' + $v(''pFlowId'') + '':460:'' + $v(''pInstance'') + ',
'//                 ''::'' + $v(''pDebug'') + '':RP,460:'' + ',
'//                 ''P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION,P460_REFRESH_CARDS,'' + ',
'//                 ''P460_JUST_UPDATED_CARD,P460_JUST_UPDATED_STATUS:'' + ',
'//                 $v(''P51_SEARCH_SELECTION'') + '','' + ',
'//                 $v(''P51_MILESTONE_SELECTION'') + '','' + ',
'//                 ''Y,'' + ',
'//                 $v(''P51_CARD_NUM'') + '','' + ',
'//                 currentStatus;',
'            ',
'//             apex.navigation.redirect(url);',
'//         },',
'//         dataType: ''json''',
'//     }',
'// );',
'',
'',
'',
'',
'// Get the current status directly from the page item',
'var currentStatus = apex.item(''P51_CARD_STATUS'').getValue();',
'',
'// Prevent default button action',
'this.browserEvent.preventDefault();',
'',
'// Build the URL manually',
'var url = ''f?p='' + $v(''pFlowId'') + '':460:'' + $v(''pInstance'') + ',
'          ''::'' + $v(''pDebug'') + '':RP,460:'' + ',
'          ''P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION,P460_REFRESH_CARDS,'' + ',
'          ''P460_JUST_UPDATED_CARD,P460_JUST_UPDATED_STATUS:'' + ',
'          $v(''P51_SEARCH_SELECTION'') + '','' + ',
'          $v(''P51_MILESTONE_SELECTION'') + '','' + ',
'          ''Y,'' + ',
'          $v(''P51_CARD_NUM'') + '','' + ',
'          currentStatus;',
'',
'// Navigate to the URL',
'apex.navigation.redirect(url);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(926648710974381880)
,p_name=>'Excel Report 2'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(926665296291381929)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926648145232381880)
,p_event_id=>wwv_flow_imp.id(926648710974381880)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'downloadCardData($v(''P51_LANDIDS''));'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(926647802365381880)
,p_name=>'Publisher Filter Changed'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P51_PUBLISHER_FILTER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926647302468381879)
,p_event_id=>wwv_flow_imp.id(926647802365381880)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12591081239047263753)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(926646874526381878)
,p_name=>'Rows Selector'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'td input'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#R45756756756575'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_da_event_comment=>'td input, th input'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926646318159381878)
,p_event_id=>wwv_flow_imp.id(926646874526381878)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var any_checked = $("#R45756756756575").find("td input:checked").length > 0;',
'',
'if (any_checked) {',
'    $("#b_mass_update").removeClass("apex_disabled");',
'} else {',
'    $("#b_mass_update").addClass("apex_disabled");',
'}',
'',
'$("#b_mass_update").prop(''disabled'', !any_checked);',
'',
'var sel_rows = apex.item(''P51_SELECTED_ROWS'');',
'sel_rows.setValue("");',
'$("#R45756756756575").find("td input:checked").each(function() {',
'  if(sel_rows.getValue().length > 0) {',
'    sel_rows.setValue(sel_rows.getValue() + ":");    ',
'  }',
'  sel_rows.setValue(sel_rows.getValue() + this.value);',
'});'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926645828336381878)
,p_event_id=>wwv_flow_imp.id(926646874526381878)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P51_SELECTED_ROWS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(926645515441381878)
,p_name=>'Dialog Closed - Page 465'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(12591081239047263753)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId == ''465'''
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926645041074381877)
,p_event_id=>wwv_flow_imp.id(926645515441381878)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12591081239047263753)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(926644683422381877)
,p_name=>'Dialog Closed - Page 466'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(12591081239047263753)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId == ''466'''
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926644169866381877)
,p_event_id=>wwv_flow_imp.id(926644683422381877)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12591081239047263753)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926643629416381876)
,p_event_id=>wwv_flow_imp.id(926644683422381877)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(926643257825381876)
,p_name=>'Massenupdate - Dialog Closed - Page 469'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(12591081239047263753)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId == ''469'''
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926642737417381876)
,p_event_id=>wwv_flow_imp.id(926643257825381876)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Check if dialog came from mass update pages',
'if (this.data && ( this.data.dialogPageId == ''469'')) {',
'    // Refresh the main report',
'    apex.region(''R45756756756575'').refresh();',
'    ',
'    // Show success message',
'    apex.message.showPageSuccess(''Massenupdate abgeschlossen. Daten wurden aktualisiert.'');',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926642279446381876)
,p_event_id=>wwv_flow_imp.id(926643257825381876)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12591081239047263753)
,p_attribute_01=>'N'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926641814312381875)
,p_event_id=>wwv_flow_imp.id(926643257825381876)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(926641410154381875)
,p_name=>'hide Massenupdate button'
,p_event_sequence=>90
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926640862744381874)
,p_event_id=>wwv_flow_imp.id(926641410154381875)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(926664444032381928)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(926640427326381874)
,p_name=>'copy permalink'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(926664084639381927)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926639965757381874)
,p_event_id=>wwv_flow_imp.id(926640427326381874)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'navigator.clipboard.writeText($v("P51_PERMALINK"));',
'// alert(''Der Permalink wurde in die Zwischenablage kopiert:\n\n'' + $v("P51_PERMALINK"));',
'apex.message.showPageSuccess(''Der Permalink wurde in die Zwischenablage kopiert'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(926639576837381874)
,p_name=>'Show / Hide Columns P51_BEWERTUNG_ANSICHT'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P51_BEWERTUNG_ANSICHT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926639093339381873)
,p_event_id=>wwv_flow_imp.id(926639576837381874)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P51_BEWERTUNG_ANSICHT'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926638604937381873)
,p_event_id=>wwv_flow_imp.id(926639576837381874)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Store switch value before refresh',
'var switchValue = $v(''P51_BEWERTUNG_ANSICHT'');',
'sessionStorage.setItem(''P51_SWITCH_VALUE'', switchValue);'))
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926638058191381873)
,p_event_id=>wwv_flow_imp.id(926639576837381874)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12591081239047263753)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(926637632812381873)
,p_name=>'Save Scroll Position'
,p_event_sequence=>120
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926637148257381872)
,p_event_id=>wwv_flow_imp.id(926637632812381873)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(document).on(''click'', ''a[href*=":466:"]'', function() {',
'    var currentPos = $(window).scrollTop();',
'    savepos = currentPos;',
'    localStorage.setItem("page461_scroll", currentPos);',
'    ',
'    $("#R45756756756575").find("tr.highlight").removeClass("highlight");',
'    $(this).closest("tr").addClass("highlight");',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(926636727910381872)
,p_name=>'Restore Scroll Position'
,p_event_sequence=>130
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(12591081239047263753)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926636215924381872)
,p_event_id=>wwv_flow_imp.id(926636727910381872)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'setTimeout(function() {',
'    var savedScroll = localStorage.getItem("page461_scroll");',
'    if (savedScroll !== null) {',
'        var scrollPos = parseInt(savedScroll);',
'        $(window).scrollTop(scrollPos);',
'    }',
'}, 150);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(926635869654381872)
,p_name=>'Refresh checkbox changes'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P51_SHOW_ONLY_UNPROCESSED'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926635408732381872)
,p_event_id=>wwv_flow_imp.id(926635869654381872)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12591081239047263753)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(926634970683381871)
,p_name=>'Show / Hide Columns P51_CRITICALITY_FILTER'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P51_CRITICALITY_FILTER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926634464715381871)
,p_event_id=>wwv_flow_imp.id(926634970683381871)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P51_CRITICALITY_FILTER'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(926633984154381871)
,p_event_id=>wwv_flow_imp.id(926634970683381871)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12591081239047263753)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(926654049399381894)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Custom XLSX Export - All Countries Result'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_context apex_exec.t_context;',
'    l_print_config    apex_data_export.t_print_config;',
'    l_export apex_data_export.t_export;',
'    l_name VARCHAR2(255);',
'    lTitle varchar2(250);',
'BEGIN',
'    -- Get user name',
'    SELECT b.nachname || '' '' || b.vorname',
'    INTO l_name',
'    FROM t_benutzer b',
'    WHERE benutzerid = :G_BENUTZERID;',
'    ',
'    -- Set title',
unistr('    lTitle := ''Aller L\00E4nder - Vorschriften'';'),
'    ',
'    -- Create query context',
'    l_context := apex_exec.open_query_context(',
'        p_location => apex_exec.c_location_local_db,',
'        p_sql_query => q''[',
'            SELECT DISTINCT ',
'                ms.landnummer||'' - ''||ms.landbezeichnung AS Land,',
'                ms.vorschrifttitel as Vorschrifttitel,',
'                ms.vorschriftnummer as Vorschriftennummer',
'                ',
'                -- ms.status_vorschrift as Status,',
unistr('                -- ms.prognose_qualitaet as Prognose_Qualit\00E4t,'),
'                -- ms.sw_relevant as SW_Relevant,',
'                -- ms.risiko as Risiko',
'            FROM T_MS_SUCHERGEBNISS ms',
'            WHERE ms.sucheid = :P51_SEARCH_SELECTION ',
'            AND ms.meilenstein = :P51_MILESTONE_SELECTION',
'            AND ms.landid IN (',
'                SELECT TO_NUMBER(column_value)',
'                FROM TABLE(apex_string.split(:P51_LANDIDS, '':''))',
'            )',
'            AND ms.vorschriftnummer IS NOT NULL',
'            ORDER BY ',
'                Land,',
'                Vorschriftennummer',
'        ]''',
'    );',
'    ',
'    -- Configure print settings',
'    l_print_config := apex_data_export.get_print_config(',
'        p_page_header => lTitle,',
'        p_header_font_family => ''Audi Type'',',
'        p_header_font_size => 10,',
'        p_body_font_family => ''Audi Type'',',
'        p_body_font_size => 10,',
'        p_border_width => 0.5,',
'        p_page_footer_font_family => ''Audi Type'',',
'        p_page_footer_font_size => 10,',
'        p_header_bg_color => ''#D0D0D0''',
'    );',
'',
'',
'',
'',
'        ',
'    -- Create export',
'    l_export := apex_data_export.export(',
'        p_context => l_context,',
'        p_print_config => l_print_config,',
'        p_format => apex_data_export.c_format_xlsx,',
unistr('        p_file_name => ''Aller L\00E4nder - Vorschriften'' || ''-'' || l_name || ''-'' || TO_CHAR(SYSDATE, ''DD.MM.YYYY HH24:MI:SS'') || ''.xlsx'''),
'    );',
'    ',
'    -- Close context and download',
'    apex_exec.close(l_context);',
'    apex_data_export.download(p_export => l_export);',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_exec.close(l_context);',
'        RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(926665680299381930)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2745558266500006341
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_context apex_exec.t_context;',
'    l_print_config    apex_data_export.t_print_config;',
'    l_export apex_data_export.t_export;',
'    l_name VARCHAR2(255);',
'    lTitle varchar2(250);',
'BEGIN',
'    -- Get user name',
'    SELECT b.nachname || '' '' || b.vorname',
'    INTO l_name',
'    FROM t_benutzer b',
'    WHERE benutzerid = :G_BENUTZERID;',
'',
'    -- Set title',
unistr('    lTitle := ''Aller L\00E4nder - Vorschriften'';'),
'',
'    -- Create query context',
'    l_context := apex_exec.open_query_context(',
'        p_location => apex_exec.c_location_local_db,',
'        p_sql_query => q''[',
'            WITH search_countries AS (',
'                SELECT ',
'                    DISTINCT sucheid,',
'                    to_number(COLUMN_VALUE) as landid',
'                FROM t_suche_json,',
'                TABLE(apex_string.split(',
'                    json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                    '':''',
'                ))',
'                WHERE BENUTZERID = ]'' || v(''G_BENUTZERID'') || q''[',
'            )',
'            SELECT DISTINCT',
'                ms.landnummer||'' - ''||ms.landbezeichnung AS Landbezeichnung,   ',
'                ms.vorschriftnummer as Vorschriftennummer',
'            FROM search_countries sc',
'            LEFT JOIN T_MS_SUCHERGEBNISS ms ON (',
'                ms.sucheid = sc.sucheid ',
'                AND ms.landid = sc.landid',
'                AND sc.landid NOT IN (',
'                    SELECT column_value ',
'                    FROM table(apex_string.split_numbers('']'' || v(''P460_FILTER_LAND'') || q''['', '':''))',
'                )',
'            )',
'            WHERE VORSCHRIFTID IS NOT NULL ',
'            GROUP BY ',
'                ms.vorschriftnummer,',
'                ms.VORSCHRIFTID,',
'                ms.landnummer,',
'                ms.landbezeichnung,',
'                sc.sucheid',
'            ORDER BY ',
'                Landbezeichnung,',
'                Vorschriftennummer',
'        ]''',
'    );',
'',
'    -- Configure print settings',
'    l_print_config := apex_data_export.get_print_config(',
'        p_page_header => lTitle,',
'        p_header_font_family => ''Audi Type'',',
'        p_header_font_size => 10,',
'        p_body_font_family => ''Audi Type'',',
'        p_body_font_size => 10,',
'        p_border_width => 0.5,',
'        p_page_footer_font_family => ''Audi Type'',',
'        p_page_footer_font_size => 10,',
'        p_header_bg_color => ''#D0D0D0''',
'    );',
'        ',
'    -- Create export',
'    l_export := apex_data_export.export(',
'        p_context => l_context,',
'        p_print_config => l_print_config,',
'        p_format => apex_data_export.c_format_xlsx,',
unistr('        p_file_name => ''Aller L\00E4nder - Vorschriften'' || ''-'' || l_name || ''-'' || TO_CHAR(SYSDATE, ''DD.MM.YYYY HH24:MI:SS'') || ''.xlsx'''),
'    );',
'',
'    -- Close context and download',
'    apex_exec.close(l_context);',
'    apex_data_export.download(p_export => l_export);',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_exec.close(l_context);',
'        RAISE;',
'END;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(926652514694381890)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'',
'  :P51_CARD_STATUS := :P51_CARD_STATUS;',
'  :P51_SEARCH_SELECTION := :P51_SEARCH_SELECTION;',
'  :P51_MILESTONE_SELECTION := :P51_MILESTONE_SELECTION;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2745559801205006345
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(926653659219381892)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UPDATE_CARD_STATUS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number       NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_status            VARCHAR2(20) := apex_application.g_x02;',
'    l_search_id         NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_milestone         NUMBER := TO_NUMBER(apex_application.g_x04);',
'    ',
'    l_json_clob         CLOB;',
'    l_milestone_count   PLS_INTEGER;',
'    l_inprogress_count  NUMBER;',
'    l_new_locked_value  NUMBER;',
'',
'BEGIN',
'    -- Step A: Update the status for the specific card',
'    MERGE INTO t_ms_card_status cs',
'    USING (SELECT :G_BENUTZERID as benutzerid, l_card_number as card_number, ',
'             l_search_id as sucheid, l_milestone as meilenstein FROM dual) src',
'    ON (cs.benutzerid = src.benutzerid AND cs.card_number = src.card_number ',
'        AND cs.sucheid = src.sucheid AND cs.meilenstein = src.meilenstein)',
'    WHEN MATCHED THEN',
'        UPDATE SET status = l_status, letzte_aenderung_datum = SYSDATE',
'    WHEN NOT MATCHED THEN',
'        INSERT (benutzerid, card_number, sucheid, meilenstein, status, erstelldatum, letzte_aenderung_datum)',
'        VALUES (src.benutzerid, src.card_number, src.sucheid, src.meilenstein, ',
'                l_status, SYSDATE, SYSDATE);',
'',
'    -- Step B: Determine what the new lock value should be',
'    IF l_status = ''in-progress'' THEN',
'        l_new_locked_value := 1;',
'    ELSE',
'        SELECT COUNT(*) INTO l_inprogress_count',
'        FROM t_ms_card_status',
'        WHERE sucheid = l_search_id',
'          AND meilenstein = l_milestone',
'          AND status = ''in-progress''',
'          AND benutzerid = :G_BENUTZERID;',
'          ',
'        IF l_inprogress_count = 0 THEN',
'            l_new_locked_value := 0;',
'        ELSE',
'            l_new_locked_value := 1;',
'        END IF;',
'    END IF;',
'',
'    -- Step C: Read and rebuild the JSON with the updated LOCKED value',
'    SELECT suchdaten INTO l_json_clob FROM t_suche_json WHERE sucheid = l_search_id;',
'    apex_json.parse(l_json_clob);',
'    apex_json.initialize_clob_output;',
'    apex_json.open_array;',
'    l_milestone_count := apex_json.get_count(p_path => ''.'');',
'    FOR i IN 1..l_milestone_count LOOP',
'        apex_json.open_object;',
'        apex_json.write(''MEILENSTEIN'',       apex_json.get_number(p_path => ''[%d].MEILENSTEIN'', p0 => i));',
'        apex_json.write(''LAENDER'',           apex_json.get_varchar2(p_path => ''[%d].LAENDER'', p0 => i));',
'        apex_json.write(''THEMEN'',            apex_json.get_varchar2(p_path => ''[%d].THEMEN'', p0 => i));',
'        apex_json.write(''LOW_RISK'',          apex_json.get_number(p_path => ''[%d].LOW_RISK'', p0 => i));',
'        apex_json.write(''HIGH_RISK'',         apex_json.get_number(p_path => ''[%d].HIGH_RISK'', p0 => i));',
'        apex_json.write(''CKD_FBU_MODE'',      apex_json.get_number(p_path => ''[%d].CKD_FBU_MODE'', p0 => i));',
'        apex_json.write(''DATUM_SOP'',         apex_json.get_varchar2(p_path => ''[%d].DATUM_SOP'', p0 => i));',
'        apex_json.write(''DATUM_EOP'',         apex_json.get_varchar2(p_path => ''[%d].DATUM_EOP'', p0 => i));',
'        apex_json.write(''DATUM_MEILENSTEIN'', apex_json.get_varchar2(p_path => ''[%d].DATUM_MEILENSTEIN'', p0 => i));',
'        apex_json.write(''SUCHTYP'',           apex_json.get_varchar2(p_path => ''[%d].SUCHTYP'', p0 => i));',
'        apex_json.write(''MJ_ANFANG'',         apex_json.get_varchar2(p_path => ''[%d].MJ_ANFANG'', p0 => i));',
'        apex_json.write(''MJ_ENDE'',           apex_json.get_varchar2(p_path => ''[%d].MJ_ENDE'', p0 => i));',
'        IF apex_json.get_number(p_path => ''[%d].MEILENSTEIN'', p0 => i) = l_milestone THEN',
'            apex_json.write(''LOCKED'', l_new_locked_value);',
'        ELSE',
'            apex_json.write(''LOCKED'', apex_json.get_number(p_path => ''[%d].LOCKED'', p0 => i));',
'        END IF;',
'        apex_json.close_object;',
'    END LOOP;',
'    apex_json.close_array;',
'    l_json_clob := apex_json.get_clob_output;',
'    apex_json.free_output;',
'',
'    -- Step D: Write the updated JSON back to the table',
'    UPDATE t_suche_json SET suchdaten = l_json_clob WHERE sucheid = l_search_id;',
'    COMMIT;',
'',
'    -- Step E: Return a success message',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
'    apex_json.write(''message'', ''Status updated successfully'');',
'    apex_json.close_object;',
'',
'    -- Print the JSON to the output buffer',
'    htp.p(apex_json.get_clob_output); ',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;',
'        -- Also print the JSON error message',
'        htp.p(apex_json.get_clob_output); ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2745558656680006343
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(926653258910381890)
,p_process_sequence=>30
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_CURRENT_CARD_STATUS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_search_id NUMBER := TO_NUMBER(apex_application.g_x02);',
'    l_milestone NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_status VARCHAR2(20) := ''not-started'';',
'BEGIN',
'    -- Get status from database',
'    BEGIN',
'        SELECT status INTO l_status',
'        FROM t_ms_card_status',
'        WHERE benutzerid = :G_BENUTZERID',
'        AND card_number = l_card_number',
'        AND sucheid = l_search_id',
'        AND meilenstein = l_milestone;',
'        ',
'',
'        apex_debug.info(''Status found for card %s: %s'', l_card_number, l_status);',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_status := ''not-started'';',
'            apex_debug.info(''No status found for card %s, using default: %s'', l_card_number, l_status);',
'    END;',
'    ',
'    -- Return as JSON',
'    apex_json.open_object;',
'    apex_json.write(''status'', l_status);',
'    apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2745559056989006345
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(926652872547381890)
,p_process_sequence=>40
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_CARD_TITLE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_result VARCHAR2(4000);',
'BEGIN',
'    SELECT',
'        CASE ',
'            WHEN COUNT(*) = 1 THEN',
'                MAX(l.B_NUMMER || '' - '' || l.LAND)',
'            ELSE',
'                LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '') ',
'                WITHIN GROUP (ORDER BY l.B_NUMMER)',
'        END',
'    INTO l_result',
'    FROM t_land l',
'    WHERE l.LANDID IN (',
'        SELECT TO_NUMBER(TRIM(column_value))',
'        FROM TABLE(apex_string.split(TRIM(apex_application.g_x01), '';''))',
'    );',
'    ',
'    apex_json.open_object;',
'    apex_json.write(''card_title'', l_result);',
'    apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2745559443352006345
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(926652072384381889)
,p_process_sequence=>50
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DOWNLOAD_CARD_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_query         CLOB;',
'    l_excel         BLOB;',
'    l_filename      VARCHAR2(4000);',
'    l_name          VARCHAR2(4000);',
'    lTitle          VARCHAR2(4000);',
'    l_landids       VARCHAR2(4000) := apex_application.g_x01;',
'    l_search_id     NUMBER := TO_NUMBER(apex_application.g_x02);',
'    l_milestone     NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_count         NUMBER;',
'BEGIN',
'    -- Get user name',
'    SELECT b.nachname || ''_'' || b.vorname',
'    INTO l_name',
'    FROM t_benutzer b',
'    WHERE benutzerid = :G_BENUTZERID;',
'    ',
'    -- Count the number of selected countries',
'    SELECT COUNT(*)',
'    INTO l_count',
'    FROM t_land l',
'    WHERE l.LANDID IN (',
'        SELECT TO_NUMBER(TRIM(column_value))',
'        FROM TABLE(apex_string.split(TRIM(l_landids), '';''))',
'    );',
'    ',
'    -- Determine title based on the number of countries selected',
'    IF l_count > 15 THEN',
unistr('        lTitle := ''L\00E4nder Vorschriften'';'),
'    ELSIF l_count >= 5 THEN',
'        SELECT LISTAGG(l.B_NUMMER, ''; '') WITHIN GROUP (ORDER BY l.B_NUMMER)',
'        INTO lTitle',
'        FROM t_land l',
'        WHERE l.LANDID IN (',
'            SELECT TO_NUMBER(TRIM(column_value))',
'            FROM TABLE(apex_string.split(TRIM(l_landids), '';''))',
'        );',
'    ELSE',
'        SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '') ',
'               WITHIN GROUP (ORDER BY l.B_NUMMER)',
'        INTO lTitle',
'        FROM t_land l',
'        WHERE l.LANDID IN (',
'            SELECT TO_NUMBER(TRIM(column_value))',
'            FROM TABLE(apex_string.split(TRIM(l_landids), '';''))',
'        );',
'    END IF;',
'    ',
'    -- Get SQL query using PCK_RI_FILTERED_SUCHE.page_461_excel_export function',
'    l_query := PCK_RI_FILTERED_SUCHE.page_461_excel_export(',
'        p_search_id => l_search_id,',
'        p_milestone => l_milestone,',
'        p_landids => l_landids,',
'        p_card_num => :P51_CARD_NUM,',
'        p_publisher_filter => :P51_PUBLISHER_FILTER,',
'        p_benutzerid => :G_BENUTZERID',
'    );',
'    ',
'    -- Generate Excel using the PCK_RI_FILTERED_SUCHE.page_461_excel_export function',
'    l_excel := emano_report.fMakeExcelsingleSheet_page461(',
'        aSheetName => ''Card Details'',',
'        aTitleName => lTitle || '' - Vorschriften'',',
'        aQuery     => l_query',
'    );',
'    ',
'    -- Set filename',
'    l_filename := REPLACE(REPLACE(REPLACE(REPLACE(',
'        lTitle || '' - Vorschriften'' || ''-'' || l_name || ''-'' || ',
'        TO_CHAR(SYSDATE, ''DD.MM.YYYY HH24:MI:SS'') || ''.xlsx'', ',
'        ''/'', ''_''), '':'', ''_''), ''"'', ''_''), CHR(10), ''_'');',
'    ',
'    -- Download file',
'    sys.htp.init;',
'    sys.owa_util.mime_header(''application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'', FALSE);',
'    sys.htp.p(''Content-Length: '' || DBMS_LOB.GETLENGTH(l_excel));',
'    sys.htp.p(''Content-Disposition: attachment; filename="'' || l_filename || ''"'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(l_excel);',
'    apex_application.stop_apex_engine;',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        htp.p(''Error generating Excel file: '' || SQLERRM);',
'        apex_debug.error(''Excel Download Error: '' || SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2745560243515006346
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(926651645784381889)
,p_process_sequence=>70
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_CARD_TITLE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_title VARCHAR2(200) := apex_application.g_x02;',
'    l_action VARCHAR2(20) := apex_application.g_x03;',
'    l_country_list CLOB;',
'    l_landids VARCHAR2(4000);',
'BEGIN',
'    -- Get the landids for this card to construct the original title',
'    BEGIN',
'        SELECT LISTAGG(landid, '':'') WITHIN GROUP (ORDER BY landid)',
'        INTO l_landids',
'        FROM t_ms_suche_split',
'        WHERE card_number = l_card_number',
'        AND ROWNUM = 1;',
'    ',
'        -- Get the original country list',
'        SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '') ',
'               WITHIN GROUP (ORDER BY l.B_NUMMER)',
'        INTO l_country_list',
'        FROM t_land l',
'        WHERE l.LANDID IN (',
'            SELECT TO_NUMBER(COLUMN_VALUE)',
'            FROM TABLE(apex_string.split(l_landids, '':''))',
'        );',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_country_list := '''';',
'    END;',
'    ',
'    -- Update title based on action',
'    IF l_action = ''RESET'' OR l_title IS NULL OR l_title = '''' THEN',
'        -- Reset to default - set to NULL',
'        UPDATE t_ms_suche_split',
'        SET custom_card_title = NULL',
'        WHERE card_number = l_card_number',
'        AND benutzerid = :G_BENUTZERID;',
'    ELSE',
'        -- Set to custom title',
'        UPDATE t_ms_suche_split',
'        SET custom_card_title = l_title',
'        WHERE card_number = l_card_number',
'        AND benutzerid = :G_BENUTZERID;',
'    END IF;',
'    ',
'    COMMIT;',
'    ',
'    -- JSON response',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
'    apex_json.write(''message'', ''Title updated successfully'');',
'    apex_json.write(''original_title'', l_country_list);',
'    apex_json.close_object;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Return error as JSON',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;     ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2745560670115006346
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(926651311997381888)
,p_process_sequence=>80
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_CARD_CUSTOM_TITLE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_custom_title VARCHAR2(200);',
'BEGIN',
'    -- Get the custom title for this card',
'    BEGIN',
'        SELECT custom_card_title ',
'        INTO l_custom_title',
'        FROM t_ms_suche_split',
'        WHERE card_number = l_card_number',
'        AND ROWNUM = 1',
'        AND custom_card_title IS NOT NULL;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_custom_title := NULL;',
'    END;',
'    ',
'    -- Return as JSON response',
'    apex_json.open_object;',
'    apex_json.write(''custom_title'', l_custom_title);',
'    apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2745561003902006347
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(926650880037381888)
,p_process_sequence=>110
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DELETE_MANUAL_ENTRY'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_search_id NUMBER := TO_NUMBER(apex_application.g_x02);',
'    l_milestone NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_specific_reg_id NUMBER := TO_NUMBER(apex_application.g_x04);',
'    l_count NUMBER;',
'BEGIN',
'    -- Check if it''s a manual entry',
'    SELECT COUNT(*)',
'    INTO l_count',
'    FROM T_MS_SUCHERGEBNISS ms',
'    WHERE ms.SUCHEID = l_search_id',
'    AND ms.MEILENSTEIN = l_milestone',
'    AND ms.MANUELLER_EINTRAG = 10',
'    AND CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END = l_specific_reg_id',
'    AND ms.LANDID IN (',
'        SELECT LANDID ',
'        FROM T_MS_SUCHE_SPLIT ',
'        WHERE CARD_NUMBER = l_card_number',
'        AND BENUTZERID = :G_BENUTZERID',
'    );',
'    ',
'    IF l_count = 0 THEN',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
unistr('        apex_json.write(''message'', ''Nur manuelle Eintr\00E4ge k\00F6nnen gel\00F6scht werden'');'),
'        apex_json.close_object;',
'        RETURN;',
'    END IF;',
'    ',
'    -- Delete only the specific regulation from T_MS_SUCHERGEBNISS',
'    DELETE FROM T_MS_SUCHERGEBNISS',
'    WHERE SUCHEID = l_search_id',
'    AND MEILENSTEIN = l_milestone',
'    AND MANUELLER_EINTRAG = 10',
'    AND CASE ',
'        WHEN ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ALTERNATIVE_VORSCHRIFTID',
'        ELSE VORSCHRIFTID',
'    END = l_specific_reg_id',
'    AND LANDID IN (',
'        SELECT LANDID ',
'        FROM T_MS_SUCHE_SPLIT ',
'        WHERE CARD_NUMBER = l_card_number',
'        AND BENUTZERID = :G_BENUTZERID',
'    );',
'    ',
'    -- Check if this was the last regulation for this card',
'    SELECT COUNT(*)',
'    INTO l_count',
'    FROM T_MS_SUCHERGEBNISS ms',
'    WHERE EXISTS (',
'        SELECT 1',
'        FROM T_MS_SUCHE_SPLIT split',
'        WHERE split.CARD_NUMBER = l_card_number',
'        AND split.BENUTZERID = :G_BENUTZERID',
'        AND split.SUCHEID = ms.SUCHEID',
'        AND split.MEILENSTEIN = ms.MEILENSTEIN',
'        AND split.LANDID = ms.LANDID',
'    );',
'    ',
'    -- If no more regulations for this card, delete the split records too',
'    IF l_count = 0 THEN',
'        DELETE FROM T_MS_SUCHE_SPLIT',
'        WHERE CARD_NUMBER = l_card_number',
'        AND BENUTZERID = :G_BENUTZERID;',
'    END IF;',
'    ',
'    COMMIT;',
'    ',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
unistr('    apex_json.write(''message'', ''Eintrag erfolgreich gel\00F6scht'');'),
'    apex_json.close_object;',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2745561435862006347
);
wwv_flow_imp.component_end;
end;
/
