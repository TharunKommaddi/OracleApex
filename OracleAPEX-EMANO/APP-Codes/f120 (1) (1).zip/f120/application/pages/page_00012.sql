prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'Button '
,p_alias=>'BUTTON'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Button '
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'600'
,p_dialog_width=>'800'
,p_dialog_resizable=>'Y'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(639744621714850301)
,p_plug_name=>unistr('Bemerkung Erf\00FCllungszeitpunkt')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1111698169479193121)
,p_plug_name=>unistr('Bemerkung Erf\00FCllungszeitpunkt')
,p_parent_plug_id=>wwv_flow_imp.id(639744621714850301)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>40
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_value clob;',
'begin',
'l_value := :P12_BEMERKUNG_EINSATZTERMIN;',
'return l_value;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P12_BEMERKUNG_EINSATZTERMIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(641412989695456569)
,p_name=>'P12_BEMERKUNG_EINSATZTERMIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(639744621714850301)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ',
'',
'    DBMS_LOB.SUBSTR(tl.BEMERKUNG_EINSATZTERMIN, 4000, 1) AS BEMERKUNG_EINSATZTERMIN',
'    --  HTF.ESCAPE_SC(DBMS_LOB.SUBSTR(tl.BEMERKUNG_EINSATZTERMIN, 4000, 1)) AS BEMERKUNG_EINSATZTERMIN',
'FROM ',
'    t_vorschrift tv',
'LEFT OUTER JOIN ',
'    t_vorschrift_ref_land tvrl ON (tv.vorschriftid = tvrl.vorschriftid)',
'LEFT OUTER JOIN ',
'    t_land tl ON (tvrl.landid = tl.landid)',
'LEFT JOIN ',
'    t_benutzer tb ON (tv.letzte_aenderung_benutzerid = tb.benutzerid)',
'WHERE ',
'    tv.vorschriftid = :P12_VORSCHRIFTID',
'GROUP BY ',
'    tv.vorschriftid,',
'',
'    DBMS_LOB.SUBSTR(tl.BEMERKUNG_EINSATZTERMIN, 4000, 1)'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(641412875706456568)
,p_name=>'P12_LAND_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(639744621714850301)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(639744459256850300)
,p_name=>'P12_VORSCHRIFTID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(639744621714850301)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(639758857238264991)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3032453458661123244
);
wwv_flow_imp.component_end;
end;
/
