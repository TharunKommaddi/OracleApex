prompt --application/pages/page_00915
begin
--   Manifest
--     PAGE: 00915
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>915
,p_name=>unistr('Audittypen bearbeiten/hinzuf\00FCgen')
,p_alias=>unistr('AUDITTYPEN-BEARBEITEN-HINZUF\00DCGEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Audittypen bearbeiten/hinzuf\00FCgen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>unistr('var htmldb_delete_message=''"M\00F6chten Sie den Audittyp l\00F6schen?"'';')
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3968246194117124226)
,p_plug_name=>'Audittyp'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_AUDIT_TYP'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_ajax_items_to_submit=>'P915_BEZEICHNUNG,P915_DAUER_GUELTIGKEIT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3968246944298124226)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(449042412157309007)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3968246944298124226)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(449041937160309005)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3968246944298124226)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>unistr('javascript:apex.confirm("M\00F6chten Sie den Audittyp l\00F6schen?",''DELETE'');')
,p_button_execute_validations=>'N'
,p_button_condition=>'P915_AUDIT_TYPID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(449041615296309004)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(3968246944298124226)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Speichern & Schlie\00DFen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1095211985462265230)
,p_name=>'P915_STATUS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(3968246194117124226)
,p_item_default=>'10'
,p_prompt=>'Status'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Aktiv'', ''Active'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Inaktiv'', ''Inactive'') AS display_value,',
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(949209518680439890)
,p_name=>'P915_BEZEICHNUNG_ENGLISCH'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(3968246194117124226)
,p_item_source_plug_id=>wwv_flow_imp.id(3968246194117124226)
,p_prompt=>'Bezeichnung Englisch'
,p_source=>'NAME_ENG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>100
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(473565128236995672)
,p_name=>'P915_AUDIT_TYPID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3968246194117124226)
,p_item_source_plug_id=>wwv_flow_imp.id(3968246194117124226)
,p_source=>'AUDIT_TYPID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(449043500274309017)
,p_name=>'P915_BEZEICHNUNG'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3968246194117124226)
,p_item_source_plug_id=>wwv_flow_imp.id(3968246194117124226)
,p_prompt=>'Bezeichnung'
,p_source=>'BEZEICHNUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(449043072774309017)
,p_name=>'P915_DAUER_GUELTIGKEIT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(3968246194117124226)
,p_item_source_plug_id=>wwv_flow_imp.id(3968246194117124226)
,p_prompt=>unistr('G\00FCltigkeit (Monate)')
,p_source=>'DAUER_GUELTIGKEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(449038402591308948)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(449042412157309007)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(449037920757308946)
,p_event_id=>wwv_flow_imp.id(449038402591308948)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(449039961762308952)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P915_AUDIT_TYPID is null then',
'    insert into T_AUDIT_TYP (BEZEICHNUNG, DAUER_GUELTIGKEIT, STATUS, LETZTE_AENDERUNG_DATUM, LETZTE_AENDERUNG_BENUTZER_ID)',
'    values (:P915_BEZEICHNUNG, :P915_DAUER_GUELTIGKEIT, :P915_STATUS, sysdate, PCK_RI.fGetUserId);',
'else',
'    update T_AUDIT_TYP',
'    set BEZEICHNUNG = :P915_BEZEICHNUNG,',
'    DAUER_GUELTIGKEIT = :P915_DAUER_GUELTIGKEIT,',
'    STATUS = :P915_STATUS,',
'    LETZTE_AENDERUNG_DATUM = sysdate,',
'    LETZTE_AENDERUNG_BENUTZER_ID = PCK_RI.fGetUserId',
'    where AUDIT_TYPID = :P915_AUDIT_TYPID;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(449041615296309004)
,p_process_success_message=>'Die Daten wurden gespeichert.'
,p_internal_uid=>3223172354137079283
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(449039598633308952)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'debug(''deleting audit_typid: '' || :P915_AUDIT_TYPID, :P915_BEZEICHNUNG);',
'delete from t_audit_typ',
'where audit_typid = :P915_AUDIT_TYPID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(449041937160309005)
,p_internal_uid=>3223172717266079283
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(449038814550308951)
,p_process_sequence=>120
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3223173501349079284
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(449040312472308953)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Initialize form Audittyp bearbeiten/hinzuf\00FCgen')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P915_AUDIT_TYPID is not null then',
'    select bezeichnung, dauer_gueltigkeit, name_eng',
'    into :P915_BEZEICHNUNG, :P915_DAUER_GUELTIGKEIT, :P915_BEZEICHNUNG_ENGLISCH',
'    from t_audit_typ',
'    where audit_typid = :P915_AUDIT_TYPID;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>3223172003427079282
);
wwv_flow_imp.component_end;
end;
/
