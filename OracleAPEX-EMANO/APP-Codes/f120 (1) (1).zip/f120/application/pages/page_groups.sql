prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 120
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(3653144357098713399)
,p_group_name=>'Alt/Backups'
);
wwv_flow_imp.component_end;
end;
/
