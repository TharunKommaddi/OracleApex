prompt --application/pages/page_00045
begin
--   Manifest
--     PAGE: 00045
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>45
,p_name=>unistr('Verkn\00FCpfungen')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Verkn\00FCpfungen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('var htmldb_delete_message=''"M\00F6chten SIe die Verkn\00FCpfung l\00F6schen?"'';'),
'',
'function show_notification(Msg){',
'    apex.message.showPageSuccess(Msg);',
'    $(''#t_Alert_Success'').attr(''style'',''background-color: #b0c4de;'');',
'    $(''.t-Alert-title'').attr(''style'',''color: black;font-weight: bold;'');',
'    $(''#t_Alert_Success div div.t-Alert-icon span'').removeClass(''t-Icon'').addClass(''fa fa-info-circle-o'');',
'}',
'',
'function fMakeRed() {',
'    $(''option:contains("(red)")'').addClass("red").each(function() {',
'        $(this).html($(this).html().replace("(red)",""));',
'    });',
'}',
'',
'',
'function regiontitle(){',
'var type; ',
'type = apex.item( "P45_AMENDMENTID" ).getValue();',
'if (type == ''20'' ){',
'apex.util.getTopApex().jQuery(".ui-dialog-content").dialog("option", "title", "Amendment Zuordnung")',
'}else{',
unistr('apex.util.getTopApex().jQuery(".ui-dialog-content").dialog("option", "title", "Verkn\00FCpfungen Zuordnung")'),
'} ',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'fMakeRed()',
'regiontitle()'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.notbold .apex-item-display-only {font-weight: normal !important}',
'',
'.shuttle_left .red { color: red !important; font-weight: bold }',
'.shuttle_right .red { color: red !important; font-weight: bold }',
'',
'',
'/* multi */',
'',
'.t-Form-fieldContainer--floatingLabel .t-Form-inputContainer  .apex-item-display-only {',
' ',
'    background-color: #f3f8fd !important;',
'}',
'',
'',
'/*single*/',
'/* ',
'span#P45_BEZIEHUNG_ART_DISPLAY {',
'',
'    background-color: #f3f8fd !important;',
'',
'} */'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'900'
,p_protection_level=>'C'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-GV-row.is-updated .a-GV-cell {',
'    background-color: var(--a-gv-updated-background-color, #f3f8fd);',
'}'))
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1068058170157307391)
,p_plug_name=>'&nbsp;'
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--stretchInputs:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(2707059584407204267)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_column=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2642103100972687185)
,p_plug_name=>unistr('Vorg\00E4nger-/Nachfolger-Vorschrift')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>9
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(869472665529647861)
,p_plug_name=>'Themen'
,p_parent_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- (:P45_ROWID is not null and :P45_BEZIEHUNG_ART != 102)',
'',
'-- 1000 = VKO role',
':P45_ROWID is not null',
'and',
'( (pck_ri.fIsUserInRolle(listRolleId => ''1000'') = 0) ',
'OR ',
'(:P45_BEZIEHUNG_ART != 102)',
')'))
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2642103811668687189)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2677608430239722042)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_button_name=>'SWAP'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Tauschen'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_value number;',
'begin',
'',
'if :P45_MASTER =20 then l_value :=0;',
'elsif  :P45_MASTER !=20 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0  then',
' l_value :=1;',
'else l_value :=0;',
'end if;',
'',
'if l_value =0 then return (false);',
'else return(true);',
'end if;',
'',
'end;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_button_comment=>'item ! = 20 bezeixhnung art'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2642104132538687189)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2642103811668687189)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2642103574360687189)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2642103811668687189)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P45_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2642103532357687189)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2642103811668687189)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P45_ROWID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1076790358037411703)
,p_name=>'P45_HOMOLOGATION_2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Homologation  mit h\00F6herer Serie m\00F6glich')
,p_source=>'HOMOLOGATION_SERIE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_display_when_type=>'NEVER'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- or (:P25_STRG_GETEX_ANZEIGE = 20 )',
'(',
'pck_ri.fIsUserInRolle(listRolleId => ''1000:1002'') > 0 -- Rolle VKO, Fachadm',
') = false',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Nein',
  'off_value', '0',
  'on_label', 'Ja',
  'on_value', '10',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1076790256784411702)
,p_name=>'P45_MAX_HOMOLOGATION'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Max Homologation'
,p_source=>'MAX_HOMOLOGATION_VORSCHRIFTID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 (NACHFOLGER_VORSCHRIFTID) as (',
'Select NACHFOLGER_VORSCHRIFTID',
'from t_vorschrift_ref_vorschrift',
'where beziehung_art = 10 and vorgaenger_vorschriftid = :P45_VORGAENGER_VORSCHRIFTID',
'union all',
'Select tvr.NACHFOLGER_VORSCHRIFTID',
'from cte1 t1',
'join t_vorschrift_ref_vorschrift tvr on (tvr.vorgaenger_vorschriftid = t1.nachfolger_vorschriftid)',
'where beziehung_art = 10',
'',
') Select  tv.VORSCHRIFT_NUMMER,t1.NACHFOLGER_VORSCHRIFTID',
'from cte1 t1',
'join t_vorschrift tv on (t1.NACHFOLGER_VORSCHRIFTID = tv.VORSCHRIFTID)'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P45_NACHFOLGER_VORSCHRIFTID,P45_VORGAENGER_VORSCHRIFTID'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_is_readonly boolean;',
'begin',
'',
'  -- Condition 1: Is the Master a Getex record?',
' if ( (:P45_MASTER in (20, 30)) OR  (pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1080'') = 0 ) ',
'      ) then',
'      --AND pck_ri.fIsUserInRolle(listRolleId => ''1080'') = 0 then',
'    l_is_readonly := true; -- Make it read-only',
'  else',
'    l_is_readonly := false; -- Make it editable',
'  end if;',
'',
'  return l_is_readonly;',
'',
'end;'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869475888844647893)
,p_name=>'P45_PRUEFUNG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(869472665529647861)
,p_prompt=>unistr('Pr\00FCfung durchgef\00FChrt')
,p_source=>'0'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', '1',
  'unchecked_value', '0',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(864666946673658762)
,p_name=>'P45_THEMEN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(869472665529647861)
,p_prompt=>'Themen &nbsp;  &P45_VOR_NAME.'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'     CASE WHEN vrvrt.STATUS_PRUEFUNG = 0 ',
'    then ''(red)'' end || ',
'     vtb.nummer || ''-'' ||vtb.bezeichnung as d,',
'   vtb.themaid  AS r',
'    FROM v_thema_baum vtb',
'    left outer join t_vorschrift_ref_vorschrift_ref_thema vrvrt ON (vrvrt.THEMAID = vtb.THEMAID and vrvrt.vorschrift_ref_vorschriftid = :P45_VORSCHRIFT_REF_VORSCHRIFTID)',
'    where vtb.gueltig=1  and   -- story 1384-',
'     vtb.themaid in (',
'        select themaid',
'        from t_vorschrift_ref_thema vrt',
'        where vorschriftid = :P45_VORGAENGER_VORSCHRIFTID',
'        and geloescht = 0',
'    )',
'',
'ORDER By thema_sortorder',
''))
,p_lov_cascade_parent_items=>'P45_VORGAENGER_VORSCHRIFTID,P45_VORSCHRIFT_REF_VORSCHRIFTID,P45_NACHFOLGER_VORSCHRIFTID'
,p_ajax_items_to_submit=>'P45_VORGAENGER_VORSCHRIFTID,P45_VORSCHRIFT_REF_VORSCHRIFTID,P45_THEMEN,P45_NACHFOLGER_VORSCHRIFTID'
,p_ajax_optimize_refresh=>'N'
,p_cHeight=>9
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(802047347052551792)
,p_name=>'P45_VORSCHRIFT_REF_VORSCHRIFTID'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_use_cache_before_default=>'NO'
,p_source=>'VORSCHRIFT_REF_VORSCHRIFTID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(682706273021316155)
,p_name=>'P45_AMENDMENTID'
,p_item_sequence=>50
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(660964415932909397)
,p_name=>'P45_HOMOLOGATION'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Homologation  mit h\00F6herer Serie m\00F6glich')
,p_source=>'HOMOLOGATION_SERIE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Ja;10,Nein;0'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_is_readonly boolean;',
'begin',
'',
'  -- Condition 1: Is the Master a Getex record?',
' if ( (:P45_MASTER in (20, 30)) OR ',
'       (pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1080'') = 0 ) OR ( :P45_ROWID is not null )',
'      ) ',
'      AND pck_ri.fIsUserInRolle(listRolleId => ''1080'') = 0 then',
'    l_is_readonly := true; -- Make it read-only',
'  else',
'    l_is_readonly := false; -- Make it editable',
'  end if;',
'',
'  return l_is_readonly;',
'',
'end;'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(660964168355909395)
,p_name=>'P45_MASTER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(337623044688617264)
,p_name=>'P45_BEZIEHUNG_HILFE_TXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1068058170157307391)
,p_prompt=>'New'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144103148820565)
,p_item_css_classes=>'notbold'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41969939067100243)
,p_name=>'P45_SHOW_HOMOLOGATION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2642106504039687198)
,p_name=>'P45_ROWID'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_use_cache_before_default=>'NO'
,p_source=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2642106898669687212)
,p_name=>'P45_VORGAENGER_VORSCHRIFTID'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Vorg\00E4nger')
,p_source=>'VORGAENGER_VORSCHRIFTID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_VORGAENGER_NACHFOLGER'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH cte_vorschriften_info AS (',
'    SELECT',
'        v.vorschriftid,',
'        v.vorschrift_nummer AS Vorschriftennummer,',
'        --v.vorschrift_bezeichnung  AS Titel,',
'        v.dokumentendatum AS Dokumentendatum,',
'       -- vrv.datum_in_kraft AS Inkraftsetzungsdatum',
'        to_char(vre.einsatzdatum, ''DD.MM.YYYY'') AS Inkraftsetzungsdatum',
'    FROM',
'        t_vorschrift v',
'    LEFT OUTER JOIN',
'        --t_vorschrift_ref_vorschrift vrv ON v.vorschriftid = vrv.VORGAENGER_VORSCHRIFTID --v.vorschriftid = vrv.VORSCHRIFT_REF_VORSCHRIFTID',
'        t_vorschrift_ref_einsatzdatum_typ vre ON (vre.vorschriftid = v.vorschriftid ',
'                                             and vre.einsatzdatum_typid = 1000 )',
')',
'',
'SELECT',
'    c.vorschriftid,',
'    c.Vorschriftennummer,',
'    --c.Titel,',
'    c.Dokumentendatum,',
'    c.Inkraftsetzungsdatum',
'FROM',
'    cte_vorschriften_info c',
'ORDER BY 1;',
''))
,p_cSize=>30
,p_colspan=>10
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_is_readonly boolean;',
'begin',
'',
'  -- Condition 1: Is the Master a Getex record?',
' if ( (:P45_MASTER in (20, 30)) OR ',
'       (pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1080'') = 0 ) OR ( :P45_ROWID is not null )',
'      ) ',
'      AND pck_ri.fIsUserInRolle(listRolleId => ''1080'') = 0 then',
'    l_is_readonly := true; -- Make it read-only',
'  else',
'    l_is_readonly := false; -- Make it editable',
'  end if;',
'',
'  return l_is_readonly;',
'',
'end;'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.vorschrift_nummer || '' - '' || v.vorschrift_bezeichnung , v.vorschriftid ',
'from t_vorschrift v',
'order by 1;'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2642107340261687219)
,p_name=>'P45_NACHFOLGER_VORSCHRIFTID'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Nachfolger'
,p_source=>'NACHFOLGER_VORSCHRIFTID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_VORGAENGER_NACHFOLGER'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH cte_vorschriften_info AS (',
'    SELECT',
'        v.vorschriftid,',
'        v.vorschrift_nummer AS Vorschriftennummer,',
'        --v.vorschrift_bezeichnung  AS Titel,',
'        v.dokumentendatum AS Dokumentendatum,',
'       -- vrv.datum_in_kraft AS Inkraftsetzungsdatum',
'        to_char(vre.einsatzdatum, ''DD.MM.YYYY'') AS Inkraftsetzungsdatum',
'    FROM',
'        t_vorschrift v',
'    LEFT OUTER JOIN',
'        --t_vorschrift_ref_vorschrift vrv ON v.vorschriftid = vrv.VORGAENGER_VORSCHRIFTID --v.vorschriftid = vrv.VORSCHRIFT_REF_VORSCHRIFTID',
'        t_vorschrift_ref_einsatzdatum_typ vre ON (vre.vorschriftid = v.vorschriftid ',
'                                             and vre.einsatzdatum_typid = 1000 )',
')',
'',
'SELECT',
'    c.vorschriftid,',
'    c.Vorschriftennummer,',
'    --c.Titel,',
'    c.Dokumentendatum,',
'    c.Inkraftsetzungsdatum',
'FROM',
'    cte_vorschriften_info c',
'ORDER BY 1;',
''))
,p_cSize=>30
,p_colspan=>10
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_is_readonly boolean;',
'begin',
'',
'  -- Condition 1: Is the Master a Getex record?',
'  -- Condition 2: Does the user NOT have the required role?',
'  if ( (:P45_MASTER in (20, 30)) OR ',
'       (pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1080'') = 0 ) OR ( :P45_ROWID is not null )',
'      ) ',
'      AND pck_ri.fIsUserInRolle(listRolleId => ''1080'') = 0 then',
'    l_is_readonly := true; -- Make it read-only',
'  else',
'    l_is_readonly := false; -- Make it editable',
'  end if;',
'',
'  return l_is_readonly;',
'',
'end;'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.vorschrift_nummer || '' - '' || v.vorschrift_bezeichnung , v.vorschriftid ',
'from t_vorschrift v',
'order by 1;',
'',
'',
'',
'(',
'pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0 -- Rolle VKO, Fachadm',
') = false  -read only '))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2642107678864687219)
,p_name=>'P45_BEZIEHUNG_ART'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Art der Beziehung'
,p_source=>'BEZIEHUNG_ART'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VORSCHRIFT_BEZIEHUNG_ART'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select BEZIEHUNG_ART as d,',
'       BEZIEHUNG_ARTID as r',
'  from T_BEZIEHUNG_ART',
'  where beziehung_artid != 30',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_is_readonly boolean;',
'begin',
'',
'  -- Condition 1: Is the Master a Getex record?',
'  -- Condition 2: Does the user NOT have the required role?',
' if ( (:P45_MASTER in (20, 30)) OR ',
'       (pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1080'') = 0 ) OR ( :P45_ROWID is not null )',
'      ) ',
'      AND pck_ri.fIsUserInRolle(listRolleId => ''1080'') = 0 then',
'    l_is_readonly := true; -- Make it read-only',
'  else',
'    l_is_readonly := false; -- Make it editable',
'  end if;',
'',
'  return l_is_readonly;',
'',
'end;'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2642108139878687219)
,p_name=>'P45_KOMMENTAR'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Kommentar'
,p_source=>'KOMMENTAR'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>1024
,p_cHeight=>4
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 1000 = VKO role',
':P45_ROWID is not null',
'and',
'pck_ri.fIsUserInRolle(listRolleId => ''1000:1080'') = 0'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2650735524666831480)
,p_name=>'P45_DATUM_IN_KRAFT'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('In Kraftsetzung aus verkn\00FCpfter Vorschrift')
,p_format_mask=>'DD.MM.YYYY'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vre.einsatzdatum',
'from t_vorschrift_ref_einsatzdatum_typ vre',
'',
'where vre.vorschriftid = :P45_NACHFOLGER_VORSCHRIFTID ',
'    and vre.einsatzdatum_typid = 1000'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_is_readonly boolean;',
'begin',
'',
'  -- Condition 1: Is the Master a Getex record?',
'  -- Condition 2: Does the user NOT have the required role?',
'  if (:P45_MASTER in (20, 30)) OR (pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') = 0',
'   OR :P45_ROWID is not null) then',
'    l_is_readonly := true; -- Make it read-only',
'  else',
'    l_is_readonly := false; -- Make it editable',
'  end if;',
'',
'  return l_is_readonly;',
'',
'end;'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_css_classes=>'apex_disabled'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2650735647983831481)
,p_name=>'P45_DATUM_NEUE_TYPEN'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Einsatztermin neue Typen'
,p_format_mask=>'DD.MM.YYYY'
,p_source=>'DATUM_NEUE_TYPEN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_is_readonly boolean;',
'begin',
'',
'  -- Condition 1: Is the Master a Getex record?',
'  -- Condition 2: Does the user NOT have the required role?',
' if ( (:P45_MASTER in (20, 30)) OR ',
'       (pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1080'') = 0 ) OR ( :P45_ROWID is not null )',
'      ) ',
'      AND pck_ri.fIsUserInRolle(listRolleId => ''1080'') = 0 then',
'    l_is_readonly := true; -- Make it read-only',
'  else',
'    l_is_readonly := false; -- Make it editable',
'  end if;',
'',
'  return l_is_readonly;',
'',
'end;'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2650735684426831482)
,p_name=>'P45_DATUM_ALLE_TYPEN'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Einsatztermin alle Typen'
,p_format_mask=>'DD.MM.YYYY'
,p_source=>'DATUM_ALLE_TYPEN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_is_readonly boolean;',
'begin',
'',
'  -- Condition 1: Is the Master a Getex record?',
' if ( (:P45_MASTER in (20, 30)) OR ',
'       (pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1080'') = 0 ) OR ( :P45_ROWID is not null )',
'      ) ',
'      AND pck_ri.fIsUserInRolle(listRolleId => ''1080'') = 0 then',
'    l_is_readonly := true; -- Make it read-only',
'  else',
'    l_is_readonly := false; -- Make it editable',
'  end if;',
'',
'  return l_is_readonly;',
'',
'end;'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2677607892390722037)
,p_name=>'P45_LABEL_VORGAENGER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2677608027337722038)
,p_name=>'P45_LABEL_NACHFOLGER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2677608684480722045)
,p_name=>'P45_SHOW_DATES'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2642103100972687185)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(2643271056886755341)
,p_validation_name=>'VALIDATE_VORGAENGER_NO_SELF_REFERENCE'
,p_validation_sequence=>10
,p_validation=>':P45_VORGAENGER_VORSCHRIFTID <> :P45_NACHFOLGER_VORSCHRIFTID'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Die Vorschrift kann nicht auf sich selbst verweisen.'
,p_associated_item=>wwv_flow_imp.id(2642106898669687212)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(2643271129642755342)
,p_validation_name=>'VALIDATE_NACHFOLGER_NO_SELF_REFERENCE'
,p_validation_sequence=>20
,p_validation=>':P45_VORGAENGER_VORSCHRIFTID <> :P45_NACHFOLGER_VORSCHRIFTID'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Die Vorschrift kann nicht auf sich selbst verweisen.'
,p_associated_item=>wwv_flow_imp.id(2642107340261687219)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(2643271380477755345)
,p_validation_name=>'VALIDATE_VORGAENGER_NO_CIRCULAR_REFERENCE'
,p_validation_sequence=>30
,p_validation=>'1=1'
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Die Vorschriften bilden einen Zirkelbezug.'
,p_associated_item=>wwv_flow_imp.id(2642106898669687212)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(2643271518394755346)
,p_validation_name=>'VALIDATE_NACHFOLGER_NO_CIRCULAR_REFERENCE'
,p_validation_sequence=>40
,p_validation=>'1=1'
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Die Vorschriften bilden einen Zirkelbezug.'
,p_associated_item=>wwv_flow_imp.id(2642107340261687219)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(2643271819668755349)
,p_validation_name=>'VALIDATE_VORGAENGER_UNIQUE'
,p_validation_sequence=>50
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'not exists (select 1 ',
'     from t_vorschrift_ref_vorschrift vrv',
'     WHERE vrv.vorgaenger_vorschriftid = :P45_VORGAENGER_VORSChRIFTID',
'     AND vrv.nachfolger_vorschriftid = :P45_NACHFOLGER_VORSChRIFTID',
'     AND vrv.beziehung_art = :P45_BEZIEHUNG_ART',
'     AND (:P45_ROWID is null OR vrv.rowid <> :P45_ROWID)',
')'))
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Diese Vorschriftenbeziehung existiert bereits.'
,p_associated_item=>wwv_flow_imp.id(2642106898669687212)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(2643271995144755351)
,p_validation_name=>'VALIDATE_NACHFOLGER_UNIQUE'
,p_validation_sequence=>60
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'not exists (select 1 ',
'     from t_vorschrift_ref_vorschrift vrv',
'     WHERE vrv.vorgaenger_vorschriftid = :P45_VORGAENGER_VORSChRIFTID',
'     AND vrv.nachfolger_vorschriftid = :P45_NACHFOLGER_VORSChRIFTID',
'     AND vrv.beziehung_art = :P45_BEZIEHUNG_ART',
'     AND (:P45_ROWID is null OR vrv.rowid <> :P45_ROWID)',
')'))
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Diese Vorschriftenbeziehung existiert bereits.'
,p_associated_item=>wwv_flow_imp.id(2642107340261687219)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(2643272109799755352)
,p_validation_name=>'VALIDATE_BEZIEHUNG_ART_UNIQUE'
,p_validation_sequence=>70
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'not exists (select 1 ',
'     from t_vorschrift_ref_vorschrift vrv',
'     WHERE vrv.vorgaenger_vorschriftid = :P45_VORGAENGER_VORSChRIFTID',
'     AND vrv.nachfolger_vorschriftid = :P45_NACHFOLGER_VORSChRIFTID',
'     AND vrv.beziehung_art = :P45_BEZIEHUNG_ART',
'     AND (:P45_ROWID is null OR vrv.rowid <> :P45_ROWID)',
')'))
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Diese Vorschriftenbeziehung existiert bereits.'
,p_associated_item=>wwv_flow_imp.id(2642107678864687219)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(943694003746276299)
,p_validation_name=>'VALIDATE_SUPPLEMENT_ONE_PARENT_ONLY'
,p_validation_sequence=>80
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P45_BEZIEHUNG_ART <> 30',
'or not exists(select 1',
'    from t_vorschrift_ref_vorschrift',
'    where nachfolger_vorschriftid = :P45_nachfolger_vorschriftid ',
'        and vorgaenger_vorschriftid <> :P45_VORGAENGER_VORSCHRIFTID',
'        and BEZIEHUNG_ART = 30',
')'))
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Das Supplement ist bereits einer anderen Vorschrift zugewiesen.'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2642104170465687189)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2642104132538687189)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2642105002179687193)
,p_event_id=>wwv_flow_imp.id(2642104170465687189)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2677608129049722039)
,p_name=>'Change Beziehung Art'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P45_BEZIEHUNG_ART,P45_NACHFOLGER_VORSCHRIFTID,P45_VORGAENGER_VORSCHRIFTID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(132810857072615792)
,p_event_id=>wwv_flow_imp.id(2677608129049722039)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(869472665529647861)
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P45_BEZIEHUNG_ART'
,p_client_condition_expression=>'102'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(802046534398551783)
,p_event_id=>wwv_flow_imp.id(2677608129049722039)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(869472665529647861)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P45_BEZIEHUNG_ART'
,p_client_condition_expression=>'102'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2677608240090722040)
,p_event_id=>wwv_flow_imp.id(2677608129049722039)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select benennung_vorschrift1, benennung_vorschrift2',
'into :P45_LABEL_VORGAENGER, :P45_LABEL_NACHFOLGER',
'from t_beziehung_art',
'where beziehung_artid = nvl(:P45_BEZIEHUNG_ART,10)'))
,p_attribute_02=>'P45_BEZIEHUNG_ART'
,p_attribute_03=>'P45_LABEL_NACHFOLGER,P45_LABEL_VORGAENGER'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2677608343281722041)
,p_event_id=>wwv_flow_imp.id(2677608129049722039)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''label#P45_VORGAENGER_VORSCHRIFTID_LABEL'').text($v(''P45_LABEL_VORGAENGER''));',
'$(''label#P45_NACHFOLGER_VORSCHRIFTID_LABEL'').text($v(''P45_LABEL_NACHFOLGER''));'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(337623028203617263)
,p_event_id=>wwv_flow_imp.id(2677608129049722039)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P45_BEZIEHUNG_HILFE_TXT'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
' declare ',
'  l_bez_art varchar2 (50);',
'  l_help_txt clob;',
'  lHelpID number;',
' begin',
'     if (:P45_BEZIEHUNG_ART is null) then ',
'        return '''';',
'     else',
'        lHelpID := case :P45_BEZIEHUNG_ART',
'            when 10 then 603 -- Successor/Predecessor',
'            when 40 then 605 -- Demands',
'            when 102 then 608 -- Equivalent',
'            when 60 then 607 -- Linked to',
'            when 50 then 606 -- Beendet',
'            when 20 then 604 -- Amendment',
'            when 200 then 609 -- Consolidates',
'        end;',
'',
'        select case emano_util.fGetLang',
'            when ''de'' then titel || '': '' || hilfetext',
'            when ''en'' then nvl(titel_englisch,titel) || '': '' || nvl(hilfetext_englisch,hilfetext)',
'            end',
'        into l_help_txt',
'        from t_hilfe',
'        where hilfeid = lHelpID;',
'          ',
'        return  l_help_txt;',
'',
'      end if;',
'  end;'))
,p_attribute_07=>'P45_BEZIEHUNG_ART'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2677608530057722043)
,p_name=>'Swap'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2677608430239722042)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2677608615527722044)
,p_event_id=>wwv_flow_imp.id(2677608530057722043)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var RV_N = $v(''P45_NACHFOLGER_VORSCHRIFTID'');',
'var DV_N = apex.item(''P45_NACHFOLGER_VORSCHRIFTID'').displayValueFor(RV_N);',
'var RV_V = $v(''P45_VORGAENGER_VORSCHRIFTID'');',
'var DV_V = apex.item(''P45_VORGAENGER_VORSCHRIFTID'').displayValueFor(RV_V);',
'',
'apex.item( "P45_NACHFOLGER_VORSCHRIFTID" ).setValue(RV_V,DV_V,true);',
'apex.item( "P45_VORGAENGER_VORSCHRIFTID" ).setValue(RV_N,DV_N,false);',
'',
'/*$s(''P45_NACHFOLGER_VORSCHRIFTID'',RV_V,DV_V);',
'$s(''P45_VORGAENGER_VORSCHRIFTID'',RV_N,DV_N);*/'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2677608823905722046)
,p_name=>unistr('Pr\00FCfe Anzeige Datumsangabe')
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P45_BEZIEHUNG_ART,P45_NACHFOLGER_VORSCHRIFTID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2677608950400722047)
,p_event_id=>wwv_flow_imp.id(2677608823905722046)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P45_SHOW_DATES'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lVorschriftBTyp number;',
'begin',
'    if (:P45_BEZIEHUNG_ART is null or :P45_BEZIEHUNG_ART != 40 or :P45_NACHFOLGER_VORSCHRIFTID is null) then',
'        return 0;',
'    /*else',
'        select vorschrift_typid into lVorschriftBTyp',
'        from t_vorschrift',
'        where vorschriftid = :P45_NACHFOLGER_VORSCHRIFTID;',
'        if (lVorschriftBTyp != 30) then',
'            return 0;',
'        end if;*/',
'    end if;',
'    return 1;',
'end;    '))
,p_attribute_07=>'P45_BEZIEHUNG_ART,P45_NACHFOLGER_VORSCHRIFTID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41970050642100244)
,p_event_id=>wwv_flow_imp.id(2677608823905722046)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P45_SHOW_HOMOLOGATION'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lVorschriftBTyp number;',
'begin',
'',
'    if (nvl(:P45_BEZIEHUNG_ART,0) in (40,102)) then',
'        return 1;',
'    else',
'        return 0;',
'    end if;',
'end;    '))
,p_attribute_07=>'P45_BEZIEHUNG_ART'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2677609031482722048)
,p_name=>'Anzeige Datumsangaben'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P45_SHOW_DATES,P45_NACHFOLGER_VORSCHRIFTID'
,p_condition_element=>'P45_SHOW_DATES'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2677609082467722049)
,p_event_id=>wwv_flow_imp.id(2677609031482722048)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P45_DATUM_IN_KRAFT,P45_DATUM_NEUE_TYPEN,P45_DATUM_ALLE_TYPEN,P45_HOMOLOGATION,P45_MAX_HOMOLOGATION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2677609224958722050)
,p_event_id=>wwv_flow_imp.id(2677609031482722048)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P45_DATUM_NEUE_TYPEN,P45_DATUM_ALLE_TYPEN,P45_HOMOLOGATION,P45_MAX_HOMOLOGATION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(895790082983594089)
,p_event_id=>wwv_flow_imp.id(2677609031482722048)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P45_DATUM_IN_KRAFT'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(vre.einsatzdatum, ''DD.MM.YYYY'')',
'from t_vorschrift_ref_einsatzdatum_typ vre',
'',
'where vre.vorschriftid = :P45_NACHFOLGER_VORSCHRIFTID ',
'    and vre.einsatzdatum_typid = 1000'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(895791340622594102)
,p_event_id=>wwv_flow_imp.id(2677609031482722048)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P45_DATUM_IN_KRAFT'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(vre.einsatzdatum, ''DD.MM.YYYY'')',
'from t_vorschrift_ref_einsatzdatum_typ vre',
'',
'where vre.vorschriftid = :P45_NACHFOLGER_VORSCHRIFTID ',
'    and vre.einsatzdatum_typid = 1000'))
,p_attribute_07=>'P45_NACHFOLGER_VORSCHRIFTID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41970159699100245)
,p_name=>'Anzeige Homologation'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P45_SHOW_HOMOLOGATION'
,p_condition_element=>'P45_SHOW_HOMOLOGATION'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(415927220329965303)
,p_event_id=>wwv_flow_imp.id(41970159699100245)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P45_HOMOLOGATION,P45_MAX_HOMOLOGATION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(415927110230965302)
,p_event_id=>wwv_flow_imp.id(41970159699100245)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P45_HOMOLOGATION,P45_MAX_HOMOLOGATION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(415926948629965301)
,p_event_id=>wwv_flow_imp.id(41970159699100245)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P45_DATUM_IN_KRAFT'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(vre.einsatzdatum, ''DD.MM.YYYY'')',
'from t_vorschrift_ref_einsatzdatum_typ vre',
'',
'where vre.vorschriftid = :P45_NACHFOLGER_VORSCHRIFTID ',
'    and vre.einsatzdatum_typid = 1000'))
,p_attribute_07=>'P45_NACHFOLGER_VORSCHRIFTID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41970250710100246)
,p_event_id=>wwv_flow_imp.id(41970159699100245)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P45_DATUM_IN_KRAFT'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(vre.einsatzdatum, ''DD.MM.YYYY'')',
'from t_vorschrift_ref_einsatzdatum_typ vre',
'',
'where vre.vorschriftid = :P45_NACHFOLGER_VORSCHRIFTID ',
'    and vre.einsatzdatum_typid = 1000'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1078790207059398563)
,p_name=>'Hide bez_Art_Hinweis'
,p_event_sequence=>70
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1078790125602398562)
,p_event_id=>wwv_flow_imp.id(1078790207059398563)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P45_BEZ_ART_HINWEIS'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(869475808490647892)
,p_name=>'SHOW/HIDE SHUTTLE'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P45_BEZIEHUNG_ART'
,p_condition_element=>'P45_BEZIEHUNG_ART'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'102'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869475711379647891)
,p_event_id=>wwv_flow_imp.id(869475808490647892)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(869472665529647861)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869475398253647888)
,p_event_id=>wwv_flow_imp.id(869475808490647892)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(869472665529647861)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(859094163499022563)
,p_name=>'Label setzen'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P45_LABEL_THEMEN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(859094104487022562)
,p_event_id=>wwv_flow_imp.id(859094163499022563)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P45_THEMEN'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var newLabel = ''Themen der Vorschrift '' + $v(''P45_NEW'');',
'$("label[for=P45_THEMEN]").html(newLabel)',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(802047102198551789)
,p_name=>'Update Shuttle Themen'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P45_THEMEN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(802047025032551788)
,p_event_id=>wwv_flow_imp.id(802047102198551789)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P45_THEMEN'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    select themaid',
'    from t_vorschrift_ref_thema vrt',
'    where vorschriftid = :P45_VORGAENGER_VORSCHRIFTID',
'    and geloescht = 0',
'',
'    intersect',
'',
'    select themaid',
'    from t_vorschrift_ref_thema vrt',
'    where vorschriftid = :P45_NACHFOLGER_VORSCHRIFTID',
'    and geloescht = 0',
')',
'select listagg(distinct themaid,'':'') within group (order by themaid)',
'from cte1    '))
,p_attribute_07=>'P45_VORGAENGER_VORSCHRIFTID,P45_NACHFOLGER_VORSCHRIFTID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(802046584879551784)
,p_event_id=>wwv_flow_imp.id(802047102198551789)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'fMakeRed()'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(988070060999880423)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Init_ROWID'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ( :P45_VORSCHRIFT_REF_VORSCHRIFTID is not null) then',
'select rowid into :P45_ROWID',
'from t_vorschrift_ref_vorschrift ',
'where VORSCHRIFT_REF_VORSCHRIFTID = :P45_VORSCHRIFT_REF_VORSCHRIFTID;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2684142254899507812
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2642108923306687222)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_VORSCHRIFT_REF_VORSCHRIFT'
,p_attribute_02=>'T_VORSCHRIFT_REF_VORSCHRIFT'
,p_attribute_03=>'P45_ROWID'
,p_attribute_04=>'ROWID'
,p_internal_uid=>6314321239206075457
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(869473862517647873)
,p_process_sequence=>30
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Loading_Topics_Shuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'select distinct themen into :P45_THEMEN',
'from (select listagg(vtb.themaid,'':'') within group(order by vtb.themaid) THEMEN',
'from ',
'    v_thema_baum vtb',
'',
'',
'--left outer ',
'join t_vorschrift_ref_vorschrift_ref_thema vrvrt ON vrvrt.THEMAID =  vtb.THEMAID',
'WHERE',
'    vtb.themaid IN (',
'        SELECT DISTINCT',
'            ( vrt.themaid )',
'        FROM',
'                 t_vorschrift_ref_thema vrt',
'            JOIN t_vorschrift_ref_vorschrift vrv ON vrt.vorschriftid = vrv.vorgaenger_vorschriftid',
'        WHERE',
'                vrv.beziehung_art = :P45_BEZIEHUNG_ART',
'                 and vrv.VORSCHRIFT_REF_VORSCHRIFTID = vrvrt.VORSCHRIFT_REF_VORSCHRIFTID',
'            AND vtb.themaid = vrt.themaid ',
'            --and vrt.VORSCHRIFTID = :P45_NACHFOLGER_VORSCHRIFTID',
'            and vrv.vorgaenger_vorschriftid = :P45_VORGAENGER_VORSCHRIFTID',
'    )',
'   and STATUS_VERKNUEPFUNG	=1',
');',
'',
'exception when no_data_found then  :P45_THEMEN :=null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2802738453381740362
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2642109266292687223)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Insert Row of T_VORSCHRIFT_REF_VORSCHRIFT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    insert into t_vorschrift_ref_vorschrift (',
'        VORGAENGER_VORSCHRIFTID, NACHFOLGER_VORSCHRIFTID, ',
'        BEZIEHUNG_ART, KOMMENTAR, ',
'        DATUM_IN_KRAFT, DATUM_NEUE_TYPEN, DATUM_ALLE_TYPEN, ',
'        HOMOLOGATION_SERIE, MAX_HOMOLOGATION_VORSCHRIFTID)',
'    values (:P45_VORGAENGER_VORSCHRIFTID, :P45_NACHFOLGER_VORSCHRIFTID,',
'            :P45_BEZIEHUNG_ART, :P45_KOMMENTAR,',
'            :P45_DATUM_IN_KRAFT, :P45_DATUM_NEUE_TYPEN, :P45_DATUM_ALLE_TYPEN,',
'            :P45_HOMOLOGATION, :P45_MAX_HOMOLOGATION)',
'    RETURNING ROWID INTO :P45_ROWID;',
'',
'    select vorschrift_ref_vorschriftid',
'    into :P45_VORSCHRIFT_REF_VORSCHRIFTID',
'    from t_vorschrift_ref_vorschrift',
'    where rowid = :P45_ROWID;',
'',
unistr('---- aenderung der Getex_attr f\00FCr beide voschriften'),
' update t_Vorschrift set letzte_aenderung_getex_attr = sysdate where Vorschriftid  in ( :P45_VORGAENGER_VORSCHRIFTID, :P45_NACHFOLGER_VORSCHRIFTID);',
'              -- and (letzte_aenderung_getex_attr is null  or letzte_aenderung_getex_attr <= sysdate - 0.0001 );',
' '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2642103532357687189)
,p_process_success_message=>unistr('Verkn\00FCpfung gespeichert.')
,p_internal_uid=>6314321582192075458
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(895790177485594090)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update Row of T_VORSCHRIFT_REF_VORSCHRIFT_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_changed number :=0;',
'    l_exists number :=0;',
'begin',
'-- nu  bei aktualisierung  der getex Attributen',
'    select count(*) into l_exists ',
'    from t_vorschrift_ref_vorschrift',
'    where VORGAENGER_VORSCHRIFTID = :P45_VORGAENGER_VORSCHRIFTID and NACHFOLGER_VORSCHRIFTID = :P45_NACHFOLGER_VORSCHRIFTID;',
unistr('      -- \00E4nderung einer von  verkn Vorschriften'),
'    if (l_exists = 0 ) then',
'        update t_Vorschrift set letzte_aenderung_getex_attr = sysdate where Vorschriftid  in ( :P45_VORGAENGER_VORSCHRIFTID, :P45_NACHFOLGER_VORSCHRIFTID);',
'    else ',
'        select count(*) into l_changed ',
'        from t_vorschrift_ref_vorschrift',
'        where VORGAENGER_VORSCHRIFTID = :P45_VORGAENGER_VORSCHRIFTID and NACHFOLGER_VORSCHRIFTID = :P45_NACHFOLGER_VORSCHRIFTID',
'        and (BEZIEHUNG_ART != :P45_BEZIEHUNG_ART  OR nvl(DATUM_NEUE_TYPEN, null) != nvl(:P45_DATUM_NEUE_TYPEN, null)',
'                        OR nvl(DATUM_ALLE_TYPEN, null) != nvl(:P45_DATUM_ALLE_TYPEN, null)',
'                        OR nvl(HOMOLOGATION_SERIE, null) != nvl(:P45_HOMOLOGATION, null)',
'        );',
'        if (l_changed = 1 ) then',
'             update t_Vorschrift set letzte_aenderung_getex_attr = sysdate where Vorschriftid  in ( :P45_VORGAENGER_VORSCHRIFTID, :P45_NACHFOLGER_VORSCHRIFTID);',
'        end if;',
'    end if;',
'',
'    update t_vorschrift_ref_vorschrift ',
'    set VORGAENGER_VORSCHRIFTID = :P45_VORGAENGER_VORSCHRIFTID,',
'        NACHFOLGER_VORSCHRIFTID = :P45_NACHFOLGER_VORSCHRIFTID, ',
'        BEZIEHUNG_ART = :P45_BEZIEHUNG_ART, ',
'        KOMMENTAR = :P45_KOMMENTAR, ',
'        DATUM_IN_KRAFT = :P45_DATUM_IN_KRAFT, ',
'        DATUM_NEUE_TYPEN = :P45_DATUM_NEUE_TYPEN, ',
'        DATUM_ALLE_TYPEN = :P45_DATUM_ALLE_TYPEN, ',
'        HOMOLOGATION_SERIE = :P45_HOMOLOGATION, ',
'        MAX_HOMOLOGATION_VORSCHRIFTID = :P45_MAX_HOMOLOGATION',
'    where rowid = :P45_ROWID;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2642103574360687189)
,p_process_success_message=>unistr('Verkn\00FCpfung gespeichert.')
,p_internal_uid=>2776422138413794145
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(802047299478551791)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Themen setzen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'merge into t_vorschrift_ref_vorschrift_ref_thema t',
'using (',
'    select column_value as themaid, :P45_VORSCHRIFT_REF_VORSCHRIFTID as vorschrift_ref_vorschriftid, :P45_PRUEFUNG as pruefung',
'    from apex_string.split_numbers(:P45_THEMEN,'':'')',
') u',
'on (t.vorschrift_ref_vorschriftid = u.vorschrift_ref_vorschriftid and t.themaid = u.themaid)',
'when matched then update set t.status_verknuepfung = 1, t.status_pruefung = case when u.pruefung = 1 then 1 else t.status_pruefung end, letzte_aenderung_datum = sysdate, letzte_aenderung_benutzerid = :G_BENUTZERID',
'when not matched then insert (',
'    vorschrift_ref_vorschriftid, themaid, status_verknuepfung,',
'    status_pruefung, letzte_aenderung_datum, letzte_aenderung_benutzerid',
') values (',
'    u.vorschrift_ref_vorschriftid, u.themaid, 1,',
'    1, sysdate, :G_BENUTZERID',
');',
'',
'-- Wenn nach links verschoben, dann status_verknuepfung = 0 setzen',
'update t_vorschrift_ref_vorschrift_ref_thema',
'set status_verknuepfung = 0',
'where vorschrift_ref_vorschriftid = :P45_VORSCHRIFT_REF_VORSCHRIFTID',
'and themaid not in (select column_value from apex_string.split_numbers(:P45_THEMEN,'':''));',
'',
unistr('-- Wenn Checkbox ausgew\00E4hlt, dann bei allen (egal ob zugeordnet oder nicht) den Pr\00FCfungs-Flag erledigen'),
'if (:P45_PRUEFUNG = 1) then',
'    update t_vorschrift_ref_vorschrift_ref_thema',
'    set status_pruefung = 1',
'    where vorschrift_ref_vorschriftid = :P45_VORSCHRIFT_REF_VORSCHRIFTID;',
'end if;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P45_BEZIEHUNG_ART'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'102'
,p_internal_uid=>2870165016420836444
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(806712388587495192)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\00C4nderungsdatum setzen')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_vorschrift',
'set letzte_aenderung_datum = sysdate',
'where vorschriftid in (:P45_NACHFOLGER_VORSCHRIFTID, :P45_VORGAENGER_VORSCHRIFTID);',
'-- UserID wird durch Trigger automatisch gesetzt'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2865499927311893043
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1016890239499243330)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Recalculate Cockpit and GETEX Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Recalculate for both linked regulations',
'    IF :P45_VORGAENGER_VORSCHRIFTID IS NOT NULL THEN',
'        PCK_RI_GETEX_CTRL.pRecalculateGetexAndCockpitData(:P45_VORGAENGER_VORSCHRIFTID);',
'    END IF;',
'    ',
'    IF :P45_NACHFOLGER_VORSCHRIFTID IS NOT NULL THEN',
'        PCK_RI_GETEX_CTRL.pRecalculateGetexAndCockpitData(:P45_NACHFOLGER_VORSCHRIFTID);',
'    END IF;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_debug.error(''Recalculation error: '' || SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2655322076400144905
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2642109726425687223)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6314322042325075458
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2642110107299687224)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>6314322423199075459
);
wwv_flow_imp.component_end;
end;
/
