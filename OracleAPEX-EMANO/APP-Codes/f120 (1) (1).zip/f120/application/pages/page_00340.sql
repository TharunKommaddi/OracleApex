prompt --application/pages/page_00340
begin
--   Manifest
--     PAGE: 00340
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>340
,p_name=>'Funktionen'
,p_step_title=>'Funktionen'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(215659786781308260)
,p_plug_name=>'Funktionen'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--',
'SELECT  xrowid,',
'  case  when status = emano_util.fLang(''in Bearbeitung'', ''in Progress'') then',
'  ''<span style="color:darkorange">'' ||BEZEICHNUNG || ''</span>''',
'    when (status = emano_util.fLang(''veraltet'', ''outdated'')  or  status = emano_util.fLang(''entfallen'', ''discontinued'') ) then',
'  ''<span style="color:darkred">'' ||BEZEICHNUNG || ''</span>''',
'   else bezeichnung end "BEZEICHNUNG",',
'  status,',
'  --BEZEICHNUNG, ',
'   KOMMENTAR, id_aus_excel,',
'  substr(m_path, 2) as parent',
'        FROM (',
'            SELECT f."ROWID" as xrowid, f.BEZEICHNUNG as "BEZEICHNUNG", f.KOMMENTAR as "KOMMENTAR", f.id_aus_excel id_aus_excel, f.status status,',
'            sys_connect_by_path(trim(fp.BEZEICHNUNG),''|'') m_path',
'            FROM T_FUNKTION f',
'            left outer join t_funktion fp on (f.parentid = fp.funktionid)',
'            CONNECT BY PRIOR f.funktionid = f.parentid',
'            START WITH f.parentid IS NULL',
'        )',
'',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_read_only_when_type=>'ALWAYS'
,p_prn_content_disposition=>'ATTACHMENT'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(215660150172308260)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'Keine Funktionen definiert.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:345:&SESSION.::&DEBUG.::P345_ROWID:#XROWID#'
,p_detail_link_text=>'<span class="fa fa-pencil" aria-hidden="true" alt="Bearbeiten" title="Bearbeiten"></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>215660150172308260
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(213988080888655418)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>11
,p_column_identifier=>'F'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(215660626614308263)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>21
,p_column_identifier=>'B'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(845321754244449703)
,p_db_column_name=>'PARENT'
,p_display_order=>51
,p_column_identifier=>'G'
,p_column_label=>'Parent'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(845321709833449702)
,p_db_column_name=>'XROWID'
,p_display_order=>61
,p_column_identifier=>'H'
,p_column_label=>'Xrowid'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(696643964807772697)
,p_db_column_name=>'ID_AUS_EXCEL'
,p_display_order=>71
,p_column_identifier=>'I'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(602814867365777403)
,p_db_column_name=>'STATUS'
,p_display_order=>81
,p_column_identifier=>'J'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(215665477629334246)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2156655'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BEZEICHNUNG:KOMMENTAR::PARENT:XROWID:ID_AUS_EXCEL:STATUS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(215662728094308266)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(215659786781308260)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:345:&SESSION.::&DEBUG.:345'
,p_button_condition_type=>'NEVER'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(696644054229772698)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(215659786781308260)
,p_button_name=>'BAUMANSICHT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Zur Baumansicht wechseln'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:341:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(215661833481308264)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(215659786781308260)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(215662343338308266)
,p_event_id=>wwv_flow_imp.id(215661833481308264)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(215659786781308260)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(215663172946308267)
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(215662728094308266)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(215663629734308267)
,p_event_id=>wwv_flow_imp.id(215663172946308267)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(215659786781308260)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
