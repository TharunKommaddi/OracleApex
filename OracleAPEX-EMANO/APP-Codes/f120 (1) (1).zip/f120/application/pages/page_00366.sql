prompt --application/pages/page_00366
begin
--   Manifest
--     PAGE: 00366
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>366
,p_name=>unistr('KPB w\00E4hlen')
,p_alias=>unistr('KPB-W\00C4HLEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('KPB w\00E4hlen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function loadKpbShuttle() {',
'    var shuttleName = ''P366_SELECTED_KPB'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n, i) {',
'        n.text = n.text.replace(/&\#x2F;/g, ''/'');',
'        //console.log(JSON.stringify(n));',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadKpbShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P366_KPB_FILTER''),',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                lLeft.length = 0;',
'                for (var i = 0; i < pData.length; i++) {',
'                    lLeft.options[i] = new Option(pData[i].d, pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
''))
,p_javascript_code_onload=>'$(''.t-ButtonRegion-col--left .t-ButtonRegion-buttons'').append('' <span onclick="redirect(261)" style="font-size:2.2em" class="fa fa-question-square-o"></span>'');'
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_dialog_height=>'400'
,p_dialog_chained=>'N'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(262269796229746186)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(262269905634746186)
,p_plug_name=>unistr('KPB w\00E4hlen')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(73537875744646624)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_imp.id(262269905634746186)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(262269972504746186)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(858076575183216991)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(262269972504746186)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(858076212803216990)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(262269972504746186)
,p_button_name=>'NEXT'
,p_button_static_id=>'b_next'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Weiter'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(858070738712216975)
,p_branch_name=>'Go To Page 367'
,p_branch_action=>'f?p=&APP_ID.:367:&SESSION.::&DEBUG.::P367_SOPEOPID,P367_KPBS_UEBERGABE:&P366_SOP_EOP_ID.,\&P366_SELECTED_KPB.\&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(858076212803216990)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(858078817011216994)
,p_name=>'P366_KPB_FILTER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(262269905634746186)
,p_prompt=>'Filter KPBs'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(858078353013216992)
,p_name=>'P366_SOP_EOP_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(262269905634746186)
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'U'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(858077999508216992)
,p_name=>'P366_DUMMY_TEXTFIELD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(262269905634746186)
,p_prompt=>'Dummy Textfield'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'style="display:none;"'
,p_field_template=>wwv_flow_imp.id(3414144103148820565)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Solange nur ein Textfeld auf einer Seite aktiv ist, ignoriert APEX den Schalter "Submit when Enter pressed!" und submitted immer bei Enter.',
'Ein verstecktes Textfeld hilft da mit zwei Textfeldern der Schalter wieder funktioniert.'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(858077543176216992)
,p_name=>'P366_SELECTED_KPB'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(262269905634746186)
,p_prompt=>unistr('Ausgew\00E4hlte KPBs')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct fp_kpb as d, kpb_id as r',
'',
'        /* auf Entwicklung: MV_X_FALKO',
'           auf Testumgebung: CARMAH_ADMIN',
'           auf Produmgebung: CARMAH2_ADMIN  */',
' from carmah_admin.t_falko_basis_projekt',
'---from MV_X_FALKO1 mv',
'',
'where :P366_KPB_FILTER is null',
'    or (upper(fp_kpb) like ''%'' || upper(:P366_KPB_FILTER) || ''%'')',
'    or (kpb_id) in (select column_value from apex_string.split(:P366_SELECTED_KPB,'':''))',
'order by fp_kpb asc;'))
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(858075357691216982)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(858076575183216991)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(858074932867216979)
,p_event_id=>wwv_flow_imp.id(858075357691216982)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(858074486026216979)
,p_name=>'Filter KPB Changed'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P366_KPB_FILTER,P366_SOP_EOP_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(858073941126216979)
,p_event_id=>wwv_flow_imp.id(858074486026216979)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'loadKpbShuttle();',
'return false;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(858073573325216979)
,p_name=>'Row Selector'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'td input '
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#VSIG'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(858073099370216978)
,p_event_id=>wwv_flow_imp.id(858073573325216979)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var any_checked = $("#VSIG").find("td input:checked").length > 0;',
'',
'if (any_checked) {',
'    $("#b_next").removeClass("apex_disabled");',
'} else {',
'    $("#b_next").addClass("apex_disabled");',
'}',
'',
'$("#b_next").prop(''disabled'', !any_checked);',
'',
'var sel_rows = apex.item(''P366_SELECTED_KPB'');',
'sel_rows.setValue("");',
'$("#VSIG").find("td input:checked").each(function() {',
'  if(sel_rows.getValue().length > 0) {',
'    sel_rows.setValue(sel_rows.getValue() + ":");    ',
'  }',
'  sel_rows.setValue(sel_rows.getValue() + this.value);',
'});',
'            ',
'apex.server.process(''DUMMY_PROCESS'', {',
'    pageItems: ''#P366_SELECTED_KPB''',
'},{dataType: "text"});',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(858072660724216977)
,p_name=>'All Selector'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'th input:checkbox'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#VSIG'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(858072162032216977)
,p_event_id=>wwv_flow_imp.id(858072660724216977)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' var check_all = $("#VSIG").find("th input:checked").is(":checked");',
'',
unistr('    // alle Zeilen ausw\00E4hlen/abw\00E4hlen'),
'    $("#VSIG").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'    // Button aktivieren/deaktivieren',
'    if (check_all) {',
'        $("#b_next").removeClass("apex_disabled");',
'    } else {',
'        $("#b_next").addClass("apex_disabled");',
'    }',
'',
'    $("#b_next").prop(''disabled'', !check_all);',
'    ',
unistr('    // alle ausgew\00E4hlten Zeilen-IDs in das Item P366_SELECTED_KPB'),
'    var sel_rows = apex.item(''P366_SELECTED_KPB'');',
'    sel_rows.setValue("");',
'    $("#VSIG").find("td input:checked").each(function() {',
'      if(sel_rows.getValue().length > 0) {',
'        sel_rows.setValue(sel_rows.getValue() + ":");    ',
'      }',
'      sel_rows.setValue(sel_rows.getValue() + this.value);',
'    });',
'    apex.server.process(''DUMMY_PROCESS'', {',
'        pageItems: ''#P366_SELECTED_KPB''',
'    },{dataType: ''text''});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(858071760556216977)
,p_name=>'Selected KPB Changed'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P366_SELECTED_KPB'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(858071274695216977)
,p_event_id=>wwv_flow_imp.id(858071760556216977)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Button aktivieren/deaktivieren',
'    if ($v(''P366_SELECTED_KPB'')) {',
'        $("#b_next").removeClass("apex_disabled");',
'        $("#b_next").prop(''disabled'', false);',
'    } else {',
'        $("#b_next").addClass("apex_disabled");',
'        $("#b_next").prop(''disabled'', true);',
'    }',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(858075763890216983)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadKpbShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lFilterText varchar2(2000) := apex_application.g_x02;',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    for l in (',
'        select distinct fp_kpb as d, kpb_id as r',
'',
'',
'        /* auf Entwicklung: MV_X_FALKO',
'           auf Testumgebung: CARMAH_ADMIN.t_falko_basis_projekt',
'           auf Produmgebung: CARMAH2_ADMIN.t_falko_basis_projekt */',
'',
'        from carmah_admin.t_falko_basis_projekt',
'      --   from MV_X_FALKO1',
'        where upper(fp_kpb) like ''%'' || upper(lFilterText) || ''%''',
'             and kpb_id not in (select column_value from table(apex_string.split(lSelected,'':'')))',
'        order by fp_kpb asc',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.r);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'    ',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2814136552009171252
);
wwv_flow_imp.component_end;
end;
/
