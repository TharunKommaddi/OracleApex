prompt --application/pages/page_00416
begin
--   Manifest
--     PAGE: 00416
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>416
,p_name=>unistr('Regulierungsverantwortlichen hinzuf\00FCgen / bearbeiten')
,p_alias=>'REGULIERUNGSVERANTWORTLICHENHINZUFUGENBEARBEITEN'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Regulierungsverantwortlichen hinzuf\00FCgen / bearbeiten')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(710663087092549887)
,p_plug_name=>unistr('Regulierungsverantwortlichen hinzuf\00FCgen / bearbeiten')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(710660758448549864)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(710661110622549867)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(710660758448549864)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(710661195300549868)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(710660758448549864)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P416_VORSCHRIFT_REF_VERANTWORTLICHERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(710661430516549870)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(710660758448549864)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P416_VORSCHRIFT_REF_VERANTWORTLICHERID'
,p_button_condition_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(710661324750549869)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(710660758448549864)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P416_VORSCHRIFT_REF_VERANTWORTLICHERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(710660375549549860)
,p_branch_name=>'Go To Page 415'
,p_branch_action=>'f?p=&APP_ID.:415:&SESSION.::&DEBUG.:415:P415_VERANTWORTLICHERID:&P416_VERANTWORTLICHERID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(710662978855549886)
,p_name=>'P416_REGULIERUNGSVERANTWORTLICHER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(710663087092549887)
,p_prompt=>'Regulierungsverantwortlicher'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'--v.vorschriftid vorschriftid,',
'listagg(vv.nachname || '', '' || vv.vorname, '';'') within group (order by vv.nachname) as verantwortlicher  ',
'    from t_verantwortlicher vv  where vv.verantwortlicherid = :P416_VERANTWORTLICHERID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'--v.vorschriftid vorschriftid,',
'listagg(vv.nachname || '', '' || vv.vorname, '';'') within group (order by vv.nachname) as verantwortlicher  ',
'    from t_vorschrift v',
'    join t_vorschrift_ref_verantwortlicher vrv on (vrv.vorschriftid = v.vorschriftid)',
'    join t_verantwortlicher vv on (vv.verantwortlicherid = vrv.verantwortlicherid)',
'    group by v.vorschriftid'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(710662872803549885)
,p_name=>'P416_IST_HAUPTVERANTWORTLICHER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(710663087092549887)
,p_item_default=>'10'
,p_prompt=>'Ist Hauptverantwortlicher'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Nebenverantwortlicher',
  'off_value', '20',
  'on_label', 'Hauptverantwortlicher',
  'on_value', '10',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(710662463957549881)
,p_name=>'P416_SWR_HAUPTUMSETZENDE_OE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(710663087092549887)
,p_prompt=>'Hauptumsetzende OE2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(710661623072549872)
,p_name=>'P416_VORSCHRIFTID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(710663087092549887)
,p_prompt=>'Vorschriften'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_VORSCHRIFT_DETAIL'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_read_only_when=>'P416_VORSCHRIFT_REF_VERANTWORTLICHERID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vorschriftid',
'from t_vorschrift_ref_verantwortlicher',
'where verantwortlicherid = :P415_VERANTWORTLICHERID'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(710661487256549871)
,p_name=>'P416_VORSCHRIFT_REF_VERANTWORTLICHERID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(710663087092549887)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(710660027418549856)
,p_name=>'P416_VERANTWORTLICHERID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(710663087092549887)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(710662372908549880)
,p_name=>'Populate SWR_HAUPTUMSETZENDE_OE'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P416_VORSCHRIFTID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(710662322782549879)
,p_event_id=>wwv_flow_imp.id(710662372908549880)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P416_SWR_HAUPTUMSETZENDE_OE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT SWR_HAUPTUMSETZENDE_OE',
'FROM T_VORSCHRIFT',
'WHERE VORSCHRIFTID = :P416_VORSCHRIFTID;',
''))
,p_attribute_07=>'P416_VORSCHRIFTID'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(710661005932549866)
,p_name=>'Cancel Dialog'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(710661110622549867)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(710660886678549865)
,p_event_id=>wwv_flow_imp.id(710661005932549866)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(710662107605549877)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process - Insert - Update'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'',
'    IF :P416_VORSCHRIFT_REF_VERANTWORTLICHERID IS NULL THEN',
'        -- Insert a new row',
'        INSERT INTO T_VORSCHRIFT_REF_VERANTWORTLICHER (',
'            ',
'            VORSCHRIFTID, ',
'            VERANTWORTLICHERID,',
'            IST_HAUPTVERANTWORTLICHER',
'        ) VALUES (',
'            ',
'            :P416_VORSCHRIFTID, ',
'            :P416_VERANTWORTLICHERID,',
'            :P416_IST_HAUPTVERANTWORTLICHER',
'        );',
'',
'    ELSE',
'        -- Update an existing row',
'        UPDATE T_VORSCHRIFT_REF_VERANTWORTLICHER',
'        SET ',
'            VORSCHRIFTID = :P416_VORSCHRIFTID, ',
'            VERANTWORTLICHERID = :P416_VERANTWORTLICHERID,',
'            IST_HAUPTVERANTWORTLICHER = :P416_IST_HAUPTVERANTWORTLICHER',
'        WHERE ',
'            VORSCHRIFT_REF_VERANTWORTLICHERID = :P416_VORSCHRIFT_REF_VERANTWORTLICHERID;',
'',
'    END IF;',
'',
'    -- Update related SWR_HAUPTUMSETZENDE_OE field in the T_VORSCHRIFT table',
'    UPDATE T_VORSCHRIFT',
'    SET ',
'        SWR_HAUPTUMSETZENDE_OE = :P416_SWR_HAUPTUMSETZENDE_OE',
'    WHERE ',
'        VORSCHRIFTID = :P416_VORSCHRIFTID;',
'        ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        RAISE;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Diese Vorschrift wurde dem Regulierungsverantwortlichen bereits zugeordnet.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2961550208293838358
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(708795913468753998)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process - Delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Delete  an existing row',
'    DELETE FROM T_VORSCHRIFT_REF_VERANTWORTLICHER',
'    WHERE ',
'        VORSCHRIFT_REF_VERANTWORTLICHERID = :P416_VORSCHRIFT_REF_VERANTWORTLICHERID;',
'       ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        RAISE;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(710661195300549868)
,p_internal_uid=>2963416402430634237
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(707239947967244790)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(710661195300549868)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2964972367932143445
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(707241223513273423)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2964971092386114812
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(708852293277279492)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Initialize'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  IF :P416_VORSCHRIFT_REF_VERANTWORTLICHERID IS NOT NULL THEN',
'    SELECT --vrv.VORSCHRIFT_REF_VERANTWORTLICHERID ,',
'          -- vv.nachname || '', '' || vv.vorname AS REGULIERUNGSVERANTWORTLICHER,',
'           vrv.VERANTWORTLICHERID,',
'           vo.vorschriftid, ',
'           vo.swr_hauptumsetzende_oe,',
'           vrv.ist_Hauptverantwortlicher',
'    INTO ',
'    --:P416_REGULIERUNGSVERANTWORTLICHER,',
'    :P416_VERANTWORTLICHERID,',
'    :P416_VORSCHRIFTID, ',
'    :P416_SWR_HAUPTUMSETZENDE_OE,',
'    :P416_IST_HAUPTVERANTWORTLICHER',
'    FROM t_vorschrift vo ',
'    JOIN t_vorschrift_ref_verantwortlicher vrv ON vrv.vorschriftid = vo.vorschriftid',
'  --  JOIN t_verantwortlicher vv ON vv.verantwortlicherid = vrv.verantwortlicherid',
'    WHERE vrv.VORSCHRIFT_REF_VERANTWORTLICHERID = :P416_VORSCHRIFT_REF_VERANTWORTLICHERID;',
'  END IF;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2963360022622108743
);
wwv_flow_imp.component_end;
end;
/
