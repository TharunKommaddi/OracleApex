prompt --application/pages/page_00023
begin
--   Manifest
--     PAGE: 00023
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>23
,p_name=>unistr('Bef\00FCllungsdefizite')
,p_alias=>unistr('BEF\00DCLLUNGSDEFIZITE')
,p_step_title=>unistr('Bef\00FCllungsdefizite')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#P21_SHORT'').detach().prependTo(''#VSIG div.a-IRR-buttons'').css(''margin-right'',''10px'').css(''margin-top'',''5px'');',
'$(''#VSIG div.a-IRR-buttons'').css(''display'',''flex'').css(''justify-content'',''flex-end'');',
'$(''#P21_SHORT_CONTAINER'').closest(''div.row'').remove();',
'',
'/* Click auf Checkbox in Tabellenheader: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'$(''#VSIG'').on(''click'', ''th input'', function() {',
'    var check_all = $("#VSIG").find("th input:checked").is(":checked");',
'',
unistr('    // alle Zeilen ausw\00E4hlen/abw\00E4hlen'),
'    $("#VSIG").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'    // Button aktivieren/deaktivieren',
'    if (check_all) {',
'        $("#b_MB").removeClass("apex_disabled");',
'    } else {',
'        $("#b_MB").addClass("apex_disabled");',
'    }',
'',
'    $("#b_MB").prop(''disabled'', !check_all);',
'    ',
unistr('    // alle ausgew\00E4hlten Zeilen-IDs in das Item P21_SELECTED_ROWS'),
'    var sel_rows = apex.item(''P21_SELECTED_ROWS'');',
'    sel_rows.setValue("");',
'    $("#VSIG").find("td input:checked").each(function() {',
'      if(sel_rows.getValue().length > 0) {',
'        sel_rows.setValue(sel_rows.getValue() + ":");    ',
'      }',
'      sel_rows.setValue(sel_rows.getValue() + this.value);',
'    });',
'    apex.server.process(''MY_PROCESS'', {',
'        pageItems: ''#P21_SELECTED_ROWS''',
'    },{dataType: ''text''});',
'    //alert (sel_rows.getValue());',
'});',
'',
'// Hilfe Button',
'$(''#VSIG_toolbar_controls'').append('' <span onclick="redirect(4)" style="font-size:2.7em" class="fa fa-question-square-o"></span>'');',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#VSIG .t-fht-tbody {max-height: calc(100vh - 260px)}',
'.t-Body-topButton {display: none !important}',
'.t-Body-content {padding-bottom: 3px !important}',
'.t-Body {margin-bottom: 3px !important}',
'.t-Body-contentInner {padding-bottom: 0px !important}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(753438451411719703)
,p_plug_name=>'Arbeitskreis'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3198971025187855852)
,p_plug_name=>'Vorschriften <span onclick="redirect(4)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'
,p_region_name=>'VSIG'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_typschild1 as (',
'    select distinct vrv.vorgaenger_vorschriftid vorschriftid ,l.typschild typschild',
'    from t_vorschrift v1',
'    left outer join t_vorschrift_ref_land vtl on (v1.vorschriftid = vtl.vorschriftid)',
'    join t_vorschrift_ref_vorschrift vrv on (vrv.nachfolger_vorschriftid = v1.vorschriftid and vrv.beziehung_art = 40)',
'    join T_LAND l on l.landid = vtl.landid',
'    where vtl.geloescht = 0',
'    union',
'    Select distinct ttl.vorschriftid, l.typschild typschild',
'    from T_VORSCHRIFT_REF_LAND ttl',
'    join T_LAND l on l.landid = ttl.landid',
'    where ttl.geloescht = 0',
'), cte_typschild2 as (',
'    select vorschriftid, listagg(typschild,'', '') within group (order by typschild) as liste_typschild',
'    from cte_typschild1',
'    group by vorschriftid',
')',
'',
'',
'select vs."ROWID" as xrowid,',
'1 as checkbox,',
'vs.vorschriftid,',
'vs.vorschriftid as link_netz,',
'"VORSCHRIFT_NUMMER",',
'"VORSCHRIFT_BEZEICHNUNG",',
'"VORSCHRIFT_TYPID",',
'"PROGNOSE_QUALITAET",',
'PCK_RI.fJiraTicketsToLinks("JIRA_TICKET") AS "JIRA_TICKET",',
'"VORSCHRIFT_FREIGABESTATUSID",',
'"BEMERKUNG",',
'PCK_RI.fCreateLinkIfUrl("LINK_ZUR_VORSCHRIFT_DMS") AS "LINK_ZUR_VORSCHRIFT_DMS",',
'nvl2("LINK_ZUR_VORSCHRIFT_GETEX", "LINK_ZUR_VORSCHRIFT_GETEX" || '' <a href="https://getex.wob.vw.vwg/web/guest/dokumente_suche" target="_blank">Getex 1.0 &ouml;ffnen</a>'', null) AS "LINK_ZUR_VORSCHRIFT_GETEX",',
'ts.liste_typschild as "TYPSCHILD",',
'    nvl2(ws.hilfetext, '' <span class="fa fa-info-circle" aria-hidden="true" onClick="javascript:apex.message.alert(''',
'         || apex_escape.js_literal(ws.hilfetext) || '');"></span> '', null) || PCK_RI.fCreateLinkIfUrl("WEBSITELINK") as "WEBSITLINK",',
'ws.hilfetext as WEBSITE_HILFETEXT,',
'k.bezeichnung as "KSU",',
'vs."LETZTE_AENDERUNG_DATUM",',
'nvl2(b.benutzerid, b.nachname || '', '' || b.vorname, null) letzte_aenderung_benutzer,',
'x.list_land,',
'ed.in_kraft,',
'etb.liste as etb_ak,',
'tg.liste as themengebiete,',
'vs.VORSCHRIFT_STATUSID,',
'vs.rxswin as rxswin_relevant,',
'  MJ_Phasein_start,',
' MJ_Phasein_end,',
'Alle_Fahrzeuge_FBU,',
'Alle_Fahrzeuge_CKD,',
'Neue_Typen_FBU,',
'Neue_Typen_CKD,',
'Neue_Typen,',
'Alle_Fahrzeuge,',
'EINSATZDATUM_MODELLID,',
'apex_util.host_url(''SCRIPT'') || apex_page.get_url(',
'    p_application => :APP_ALIAS',
'    , p_page => ''VORSCHRIFT''',
'    , p_items => ''P25_VORSCHRIFTID''',
'    , p_values => vs.vorschriftid',
'    , p_session => null',
'    , p_clear_cache => ''25''',
') as permalink,',
'antriebsart.liste antriebsart,',
'vs.COP_RELEVANT cop_relevant,',
'vs.technologie',
'',
'',
'from "#OWNER#"."T_VORSCHRIFT" vs',
'left outer join T_BENUTZER b on b.benutzerid = vs.letzte_aenderung_benutzerid',
'left outer join T_WEBSITE ws on ws.websiteid = vs.websiteid',
'left outer join T_KSU k on k.ksuid = vs.ksuid',
'left outer join cte_typschild2 ts on (vs.vorschriftid = ts.vorschriftid)',
'',
'outer apply (',
'    select einsatzdatum in_kraft',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1000',
'    fetch first 1 rows only',
') ed',
'outer apply (',
'    select listagg(b_nummer, '', '') within group(order by b_nummer) list_land',
'    from (',
'        select land.b_nummer',
'        from T_VORSCHRIFT_REF_LAND vtl ',
'        left outer join t_land land on land.landid = vtl.landid',
'        where vtl.vorschriftid = vs.vorschriftid and vtl.geloescht = 0',
'        ',
'        union',
'        ',
'        select l.b_nummer',
'        from t_vorschrift_ref_vorschrift vrv',
'        join t_vorschrift_ref_land rtl on (vrv.nachfolger_vorschriftid = rtl.vorschriftid)',
'        join t_land l on (rtl.landid = l.landid)',
'        where vorgaenger_vorschriftid = vs.vorschriftid and beziehung_art = 40 and rtl.geloescht = 0',
'        ',
'        ',
'            )',
') x',
'outer apply (',
'    select listagg(etb,'', '') within group (order by etb) liste',
'    from (',
'        select distinct ak.kurz etb',
'        from t_vorschrift_ref_et_b_ak ref',
'        join t_et_b_ak ak on (ak.et_b_akid = ref.et_b_akid)',
'        where ref.vorschriftid = vs.vorschriftid and ref.geloescht = 0        ',
'        ',
'       /* from t_vorschrift_ref_thema_ref_land vtl',
'        join t_thema t on (vtl.themaid = t.themaid)',
'        ',
'        join t_et_b_ak ak on (ak.et_b_akid = t.et_b_akid)',
'        where vtl.vorschriftid = vs.vorschriftid and vtl.geloescht = 0*/',
'    )',
') etb',
'',
'outer apply (',
'    select listagg(tg,'', '') within group (order by tg) liste',
'    from (',
'        select distinct t.nummer tg',
'        from t_vorschrift_ref_thema vtl',
'        join t_thema t on (vtl.themaid = t.themaid)',
'        where vtl.vorschriftid = vs.vorschriftid and vtl.geloescht = 0',
'    )',
') tg',
'',
'outer apply (',
'    select listagg(antriebsart,'', '') within group (order by antriebsart) liste',
'    from (',
'        select distinct aa.bezeichnung antriebsart',
'        from t_vorschrift_ref_thema vtl',
'        join t_thema_ref_antriebsart trf on (vtl.themaid = trf.themaid)',
'        join t_antriebsart aa on (aa.antriebsartid = trf.antriebsartid)',
'        where vtl.vorschriftid = vs.vorschriftid and vtl.geloescht = 0',
'    )',
') antriebsart',
'/*outer apply (',
'    select listagg(typschild, '', '') within group(order by typschild) liste',
'    from (',
'        select distinct l.typschild typschild',
'        from T_VORSCHRIFT_REF_THEMA_REF_LAND ttl',
'        join T_LAND l on l.landid = ttl.landid',
'        where ttl.vorschriftid = vs.vorschriftid and ttl.geloescht = 0',
'         with cte1 as (',
'              select vrv.vorgaenger_vorschriftid vorschriftid ,l.typschild typschild',
'                from t_vorschrift v1',
'                left outer join t_vorschrift_ref_thema_ref_land vtl on (v1.vorschriftid = vtl.vorschriftid)',
'                join t_vorschrift_ref_vorschrift vrv on (vrv.nachfolger_vorschriftid = v1.vorschriftid and vrv.beziehung_art = 40)',
'                join T_LAND l on l.landid = vtl.landid',
'                where vtl.geloescht = 0',
'                union all',
'               Select ttl.vorschriftid, l.typschild typschild',
'                    from T_VORSCHRIFT_REF_THEMA_REF_LAND ttl',
'                    join T_LAND l on l.landid = ttl.landid',
'                    where   ttl.geloescht = 0',
' )',
' ',
' select distinct typschild typschild',
'        from cte1 ttl',
'        where ttl.vorschriftid = vs.vorschriftid ',
'    )',
') ts*/',
'outer apply (',
'    select einsatzdatum Neue_Typen_CKD',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1020',
'    fetch first 1 rows only',
') ntc',
'outer apply (',
'    select einsatzdatum Alle_Fahrzeuge_CKD',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1021',
'    fetch first 1 rows only',
') afc',
'outer apply (',
'    select einsatzdatum Neue_Typen_FBU',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1022',
'    fetch first 1 rows only',
') ntc',
'outer apply (',
'    select einsatzdatum Alle_Fahrzeuge_FBU',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1023',
'    fetch first 1 rows only',
') afc',
'outer apply (',
'    select einsatzdatum MJ_Phasein_start',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1030',
'    fetch first 1 rows only',
') ntmj',
'outer apply (',
'    select einsatzdatum MJ_Phasein_end',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1031',
'    fetch first 1 rows only',
') afmj',
'outer apply (',
'    select einsatzdatum Neue_Typen',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1010',
'    fetch first 1 rows only',
') nt',
'outer apply (',
'    select einsatzdatum Alle_Fahrzeuge',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1011',
'    fetch first 1 rows only',
') af',
'',
'where vs.vorschrift_typid in (10, 30, 40) -- Supplements nicht anzeigen',
'and (vs.vorschrift_freigabestatusid = 20 or pck_ri.fIsLimitedUser = 0) and exists (Select 1 from t_H_vorschrift_ref_et_b_ak thref where thref.vorschriftid = vs.vorschriftid and thref.et_b_akid = :P23_ARBEITSKREIS)',
'  '))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P23_SHORT'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(3198971371535855852)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'Keine Vorschriften gefunden.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>1000
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV'
,p_enable_mail_download=>'N'
,p_detail_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:RP,25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_detail_link_text=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_detail_link_condition_type=>'EXPRESSION'
,p_detail_link_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 25,',
'                      accessMode => 100))'))
,p_detail_link_cond2=>'PLSQL'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>4311664308630990256
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753453692909765544)
,p_db_column_name=>'XROWID'
,p_display_order=>10
,p_column_identifier=>'T'
,p_column_label=>'Xrowid'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753454933688765547)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>20
,p_column_identifier=>'R'
,p_column_label=>'<input type="checkbox" value="all" />'
,p_column_html_expression=>'<input type="checkbox" value="#VORSCHRIFTID#" />'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753452895283765542)
,p_db_column_name=>'LINK_NETZ'
,p_display_order=>30
,p_column_identifier=>'W'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:RP,300:P300_VORSCHRIFTID:#LINK_NETZ#'
,p_column_linktext=>unistr('<span class="fa fa-network-hub" title="Vernetzungsansicht \00F6ffnen" alt="Vernetzungsansicht \00F6ffnen"></span>')
,p_column_link_attr=>'target="_blank"'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753462117849765559)
,p_db_column_name=>'PERMALINK'
,p_display_order=>40
,p_column_identifier=>'AM'
,p_column_label=>'<span title="Permalink">&nbsp;</span>'
,p_column_html_expression=>'<span class="fa fa-link" title="Permalink in Zwischenablage kopieren" alt="Permalink in Zwischenablage kopieren" onClick="javascript:navigator.clipboard.writeText(''#PERMALINK#'');alert(''Der Permalink wurde in die Zwischenablage kopiert:\n\n#PERMALINK#'
||''');"></span>'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753460127875765556)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>50
,p_column_identifier=>'B'
,p_column_label=>'Vorschriften&shy;nummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753459730207765556)
,p_db_column_name=>'VORSCHRIFT_BEZEICHNUNG'
,p_display_order=>60
,p_column_identifier=>'C'
,p_column_label=>'Titel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753455718808765549)
,p_db_column_name=>'VORSCHRIFT_TYPID'
,p_display_order=>70
,p_column_identifier=>'Q'
,p_column_label=>'Vorschrift Typ'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(2656545044559578040)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753459268474765555)
,p_db_column_name=>'PROGNOSE_QUALITAET'
,p_display_order=>80
,p_column_identifier=>'D'
,p_column_label=>unistr('Prognose Qualit\00E4t')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(958121403566083634)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753458912074765554)
,p_db_column_name=>'JIRA_TICKET'
,p_display_order=>90
,p_column_identifier=>'E'
,p_column_label=>'Jira-Tickets'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753460930909765558)
,p_db_column_name=>'VORSCHRIFT_STATUSID'
,p_display_order=>100
,p_column_identifier=>'AB'
,p_column_label=>'Status der Vorschrift'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(2490458092659806028)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753458462774765554)
,p_db_column_name=>'VORSCHRIFT_FREIGABESTATUSID'
,p_display_order=>110
,p_column_identifier=>'F'
,p_column_label=>'Interner Freigabe&shy;status'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(958129793570194302)
,p_rpt_show_filter_lov=>'1'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P23_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753458068830765553)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>120
,p_column_identifier=>'G'
,p_column_label=>'Bemerkung zur Vorschrift'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753452058250765541)
,p_db_column_name=>'ETB_AK'
,p_display_order=>130
,p_column_identifier=>'Y'
,p_column_label=>'ET-B AK'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753453331185765544)
,p_db_column_name=>'LIST_LAND'
,p_display_order=>140
,p_column_identifier=>'U'
,p_column_label=>unistr('L\00E4nder ')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753457286412765552)
,p_db_column_name=>'LINK_ZUR_VORSCHRIFT_GETEX'
,p_display_order=>160
,p_column_identifier=>'I'
,p_column_label=>'Getex 1.0 ID'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P23_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753456080180765549)
,p_db_column_name=>'WEBSITLINK'
,p_display_order=>170
,p_column_identifier=>'O'
,p_column_label=>'Link zu Web Site'
,p_column_html_expression=>'<span title="#WEBSITE_HILFETEXT#">#WEBSITLINK#</span>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P23_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753457727504765552)
,p_db_column_name=>'LINK_ZUR_VORSCHRIFT_DMS'
,p_display_order=>180
,p_column_identifier=>'H'
,p_column_label=>'Link zu DMS'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P23_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753456520547765550)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>190
,p_column_identifier=>'K'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P23_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753456910497765551)
,p_db_column_name=>'TYPSCHILD'
,p_display_order=>200
,p_column_identifier=>'J'
,p_column_label=>'Typschild'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P23_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753454461602765546)
,p_db_column_name=>'KSU'
,p_display_order=>210
,p_column_identifier=>'S'
,p_column_label=>'KSU'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P23_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753460494462765557)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>220
,p_column_identifier=>'M'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P23_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753455273219765548)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>230
,p_column_identifier=>'P'
,p_column_label=>'Vorschriftid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753454117584765545)
,p_db_column_name=>'WEBSITE_HILFETEXT'
,p_display_order=>240
,p_column_identifier=>'V'
,p_column_label=>'Website Hilfetext'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753452482252765541)
,p_db_column_name=>'IN_KRAFT'
,p_display_order=>250
,p_column_identifier=>'X'
,p_column_label=>'Datum Inkraftsetzung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753451699238765540)
,p_db_column_name=>'THEMENGEBIETE'
,p_display_order=>260
,p_column_identifier=>'AA'
,p_column_label=>'Themengebiete'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753461325569765558)
,p_db_column_name=>'RXSWIN_RELEVANT'
,p_display_order=>270
,p_column_identifier=>'AC'
,p_column_label=>'potentiell SW-Relevant'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(958135905312245351)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753465622078765581)
,p_db_column_name=>'MJ_PHASEIN_START'
,p_display_order=>280
,p_column_identifier=>'AD'
,p_column_label=>'Mj Phasein Start'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P23_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753465273108765565)
,p_db_column_name=>'MJ_PHASEIN_END'
,p_display_order=>290
,p_column_identifier=>'AE'
,p_column_label=>'Mj Phasein End'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P23_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753464871002765564)
,p_db_column_name=>'ALLE_FAHRZEUGE_FBU'
,p_display_order=>300
,p_column_identifier=>'AF'
,p_column_label=>'Alle Fahrzeuge FBU'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P23_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753464519735765564)
,p_db_column_name=>'ALLE_FAHRZEUGE_CKD'
,p_display_order=>310
,p_column_identifier=>'AG'
,p_column_label=>'Alle Fahrzeuge CKD'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P23_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753464096906765563)
,p_db_column_name=>'NEUE_TYPEN_FBU'
,p_display_order=>320
,p_column_identifier=>'AH'
,p_column_label=>'Neue Typen FBU'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P23_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753463724968765563)
,p_db_column_name=>'NEUE_TYPEN_CKD'
,p_display_order=>330
,p_column_identifier=>'AI'
,p_column_label=>'Neue Typen CKD'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P23_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753463279835765562)
,p_db_column_name=>'NEUE_TYPEN'
,p_display_order=>340
,p_column_identifier=>'AJ'
,p_column_label=>'Neue Typen'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P23_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753462863162765561)
,p_db_column_name=>'ALLE_FAHRZEUGE'
,p_display_order=>350
,p_column_identifier=>'AK'
,p_column_label=>'Alle Fahrzeuge'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P23_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753462478494765560)
,p_db_column_name=>'EINSATZDATUM_MODELLID'
,p_display_order=>360
,p_column_identifier=>'AL'
,p_column_label=>'Einsatzdatum Modell'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(1076773784946225404)
,p_rpt_show_filter_lov=>'1'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P23_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753461649399765559)
,p_db_column_name=>'ANTRIEBSART'
,p_display_order=>370
,p_column_identifier=>'AN'
,p_column_label=>'Antriebsart'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753451272641765540)
,p_db_column_name=>'COP_RELEVANT'
,p_display_order=>380
,p_column_identifier=>'AO'
,p_column_label=>'CoP Relevant'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(958149357559525013)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(753450881946765539)
,p_db_column_name=>'TECHNOLOGIE'
,p_display_order=>390
,p_column_identifier=>'AP'
,p_column_label=>'Technologie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(3198979074614861204)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3592424'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LINK_NETZ:PERMALINK:CHECKBOX:VORSCHRIFT_NUMMER:VORSCHRIFT_BEZEICHNUNG:BEMERKUNG:VORSCHRIFT_TYPID:IN_KRAFT:PROGNOSE_QUALITAET:VORSCHRIFT_STATUSID:ETB_AK:LIST_LAND:THEMENGEBIETE:ANTRIEBSART:RXSWIN_RELEVANT:LINK_ZUR_VORSCHRIFT_GETEX:VORSCHRIFT_FREIGABES'
||'TATUSID:JIRA_TICKET:LINK_ZUR_VORSCHRIFT_DMS:WEBSITLINK:NEUE_TYPEN:ALLE_FAHRZEUGE:MJ_PHASEIN_START:MJ_PHASEIN_END:NEUE_TYPEN_CKD:ALLE_FAHRZEUGE_CKD:NEUE_TYPEN_FBU:ALLE_FAHRZEUGE_FBU:EINSATZDATUM_MODELLID:TYPSCHILD:KSU:COP_RELEVANT:TECHNOLOGIE:LETZTE_A'
||'ENDERUNG_BENUTZER:LETZTE_AENDERUNG_DATUM:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3236245887622144729)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2707059584407204267)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(753449284251765524)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3198971025187855852)
,p_button_name=>'LAENDER_INFO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('L\00E4nder')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-info-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(753450136279765528)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3198971025187855852)
,p_button_name=>'MEHRFACHBEARBEITUNG'
,p_button_static_id=>'b_MB'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Mehrfachbearbeitung'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:140:&SESSION.::&DEBUG.:RP,140:P140_LOAD_FROM:"P23_SELECTED_ROWS"'
,p_button_css_classes=>'apex_disabled'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(753449651723765525)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(3198971025187855852)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(userId => PCK_RI.fGetUserId, ',
'                      pageId => :APP_PAGE_ID,',
'                      accessMode => 200))'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(753466327091765610)
,p_name=>'P23_SHORT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3236245887622144729)
,p_item_default=>'20'
,p_prompt=>'Anzeige'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(3414144103148820565)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Langversion',
  'off_value', '20',
  'on_label', 'Kurzversion',
  'on_value', '10',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(753448487346765523)
,p_name=>'P23_SELECTED_ROWS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(3198971025187855852)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(753438385970719702)
,p_name=>'P23_ARBEITSKREIS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(753438451411719703)
,p_prompt=>'Arbeitskreis'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_ARBEITSKREIS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' SELECT ',
'    ET_B_AKID, ',
'    kurz, ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN Bezeichnung',
'        ELSE name_eng',
'    END AS name',
'FROM T_ET_B_AK ',
'WHERE ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN Bezeichnung',
'        ELSE name_eng',
'    END NOT IN ',
'    (',
'        CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''Administratoren'' ELSE ''Administrators'' END,',
'        CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''Redaktionsteam'' ELSE ''Editorial Team'' END',
'    );',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'Y',
  'page_action_on_selection', 'SUBMIT')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(753447656553765506)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(3198971025187855852)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(753447223083765501)
,p_event_id=>wwv_flow_imp.id(753447656553765506)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3198971025187855852)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(753446777215765499)
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(753449651723765525)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(753446271636765499)
,p_event_id=>wwv_flow_imp.id(753446777215765499)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3198971025187855852)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(753445862841765499)
,p_name=>'Backup OPEN_MEHRFACHBEARBEITUNG_DIALOG'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(753450136279765528)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'NEVER'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(753445355684765498)
,p_event_id=>wwv_flow_imp.id(753445862841765499)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var sel_rows = apex.item(''P23_SELECTED_ROWS'');',
'sel_rows.setValue("");',
'$("#VSIG").find("td input:checked").each(function() {',
'  if(sel_rows.getValue().length > 0) {',
'    sel_rows.setValue(sel_rows.getValue() + ":");    ',
'  }',
'  sel_rows.setValue(sel_rows.getValue() + this.value);',
'});',
'            '))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(753444838737765498)
,p_event_id=>wwv_flow_imp.id(753445862841765499)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :P23_URL_MEHRFACHBEARBEITUNG := APEX_UTIL.PREPARE_URL (',
'        APEX_PAGE.GET_URL (',
'            p_page => 140,',
'            --p_triggering_element => ''#b_MB'',',
'            p_items => ''P140_SELECTED_VORSCHRIFTEN'',',
'            p_values => ''\'' || :P23_SELECTED_ROWS || ''\'',',
'            p_clear_cache => 140),',
'        p_triggering_element => ''$(''''body'''')'');',
'            ',
'END;',
'',
'',
''))
,p_attribute_02=>'P23_SELECTED_ROWS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(753444373037765498)
,p_event_id=>wwv_flow_imp.id(753445862841765499)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'eval($(''#P23_URL_MEHRFACHBEARBEITUNG'').val())',
' '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(753444030553765498)
,p_name=>'Mehrfachbearbeitung - Dialog Closed'
,p_event_sequence=>70
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'body'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(753443451971765497)
,p_event_id=>wwv_flow_imp.id(753444030553765498)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'alert(''TEST'');'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(753442948912765497)
,p_event_id=>wwv_flow_imp.id(753444030553765498)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3198971025187855852)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(753442621703765497)
,p_name=>'Change Variante'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P23_SHORT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(753442100581765497)
,p_event_id=>wwv_flow_imp.id(753442621703765497)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window.location=''f?p=&APP_ID.:20:&APP_SESSION.'''
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(753441708421765497)
,p_name=>'Zeilenselektor'
,p_event_sequence=>90
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'td input'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#VSIG'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(753441180595765494)
,p_event_id=>wwv_flow_imp.id(753441708421765497)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var any_checked = $("#VSIG").find("td input:checked").length > 0;',
'',
'if (any_checked) {',
'    $("#b_MB").removeClass("apex_disabled");',
'} else {',
'    $("#b_MB").addClass("apex_disabled");',
'}',
'',
'$("#b_MB").prop(''disabled'', !any_checked);',
'',
'var sel_rows = apex.item(''P23_SELECTED_ROWS'');',
'sel_rows.setValue("");',
'$("#VSIG").find("td input:checked").each(function() {',
'  if(sel_rows.getValue().length > 0) {',
'    sel_rows.setValue(sel_rows.getValue() + ":");    ',
'  }',
'  sel_rows.setValue(sel_rows.getValue() + this.value);',
'});',
'            '))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(753440653180765494)
,p_event_id=>wwv_flow_imp.id(753441708421765497)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P23_SELECTED_ROWS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(753440317640765494)
,p_name=>unistr('L\00E4nderinfo')
,p_event_sequence=>100
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'button#b_laender_info'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(753439826083765493)
,p_event_id=>wwv_flow_imp.id(753440317640765494)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'apex.server.process(',
'    ''prepare_laender'',                           ',
'    {',
'        x01: ''Mehrfachbearbeitung'',',
'        x02: $v(''P10_SELECTED_IDS'').replace(/:/g, "|")',
'    }, ',
'    {',
'        success: function (pData)',
'        {           ',
'            apex.navigation.redirect(pData);',
'        },',
'        dataType: "text"                     ',
'    }',
');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(753439389306765493)
,p_name=>unistr('Klick Button L\00E4nder Info')
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(753449284251765524)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(753438927551765493)
,p_event_id=>wwv_flow_imp.id(753439389306765493)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'javascript:window.open(''f?p=&APP_ID.:130:&SESSION.'',''_blank'');'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(753448076346765509)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'prepare_laender'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_url varchar2(2000);',
'    l_app number := v(''APP_ID'');',
'    l_session number := v(''APP_SESSION'');',
'',
'    --l_page_item VARCHAR2(2000) := case when apex_application.g_x01 = ''Einzelbearbeitung'' then ''P15_BEWERTUNG_ID'' when apex_application.g_x01 = ''Mehrfachbearbeitung'' then ''P15_SELECTED_IDS'' end;',
'BEGIN',
'    l_url := APEX_UTIL.PREPARE_URL(',
'        p_url => ''f?p='' || l_app || '':300:'' || l_session || ''::NO:300::'' || apex_application.g_x02,',
'        p_checksum_type => ''SESSION'');',
'    htp.p(l_url);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2918764239552622726
);
wwv_flow_imp.component_end;
end;
/
