prompt --application/pages/page_00423
begin
--   Manifest
--     PAGE: 00423
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>423
,p_name=>'Vorschriften REV notwendig ohne REV'
,p_alias=>'VORSCHRIFTEN-REV-NOTWENDIG-OHNE-REV'
,p_step_title=>'Vorschriften REV notwendig ohne REV'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'function delete_fun(){',
'    // alert(''TEST'');',
'    apex.submit(''DELETE'');',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var grid$ = apex.region("grid1").call("getCurrentView").view$;',
'grid$.grid("hideColumn","VERANTWORTLICHER_NEU_ID");',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-AlertMessage {',
'    padding-left: 20px;',
'    padding-right: 20px;',
'}',
'',
'.confirm_rev_changes {',
'    cursor:pointer;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3163689256060928895)
,p_plug_name=>unistr('Vorschriften mit REV \00C4nderungen')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3163689187577928894)
,p_plug_name=>'grid'
,p_region_name=>'grid1'
,p_parent_plug_id=>wwv_flow_imp.id(3163689256060928895)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rkv.rev_kontrolle_vorschrift_id, v.vorschrift_nummer, v.vorschriftid, va.verantwortlicherid,',
'va.nachname || '', '' || va.vorname || '' ('' || va.abteilung || '')'' as verantwortlicher,',
'rkv.status, null as verantwortlicher_neu_id, rkg.gruppe_name,',
unistr('case when bestaetigung = 0 then ''<span data-id="'' || rkv.rev_kontrolle_vorschrift_id || ''" title="\00C4nderungen best\00E4tigen" class="confirm_rev_changes fa fa-check"></span>'' else ''bestaetigt'' end as bestaetigen,'),
'case when rkv.neuer_verantwortlicherid is not null then vaneu.nachname || '', '' || vaneu.vorname || '' ('' || vaneu.abteilung || '')'' else null end as verantwortlicher_neu',
'from t_rev_kontrolle_vorschrift rkv',
'join t_rev_kontrolle rk on (rk.rev_kontrolle_id = rkv.rev_kontrolle_id)',
'join t_rev_kontrolle_gruppe rkg on (rk.rev_kontrolle_gruppe_id = rkg.rev_kontrolle_gruppe_id)',
'join t_verantwortlicher va on (rk.verantwortlicherid = va.verantwortlicherid)',
'left outer join t_vorschrift v on (rkv.vorschriftid = v.vorschriftid)',
'left outer join t_benutzer vaneu on (rkv.neuer_verantwortlicherid = vaneu.benutzerid)',
'',
'where (rkv.neuer_verantwortlicherid is not null or rkv.status = 20)',
'and rkv.bestaetigung = 0'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'grid'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3163688937612928892)
,p_name=>'VORSCHRIFT_NUMMER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFT_NUMMER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Vorschrift Nummer'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>1000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3163688911830928891)
,p_name=>'VORSCHRIFTID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFTID'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_LINK'
,p_heading=>'&nbsp;'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'CENTER'
,p_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:&VORSCHRIFTID.'
,p_link_text=>'<span class="fa fa-search"></span>'
,p_link_attributes=>'target="_blank"'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3163688771095928890)
,p_name=>'VERANTWORTLICHERID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VERANTWORTLICHERID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>70
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3163688641370928889)
,p_name=>'VERANTWORTLICHER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VERANTWORTLICHER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Verantwortlicher bisher'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>755
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3163688540082928888)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Status'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN')).to_clob
,p_lov_type=>'STATIC'
,p_lov_source=>unistr('STATIC:best\00E4tigt;10,abgelehnt;20')
,p_lov_display_extra=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3163688437849928887)
,p_name=>'VERANTWORTLICHER_NEU'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VERANTWORTLICHER_NEU'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Verantwortlicher neu'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>3285
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3163688359763928886)
,p_name=>'BESTAETIGEN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BESTAETIGEN'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('Best\00E4tigen')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'CENTER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1072844184951081031)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>30
,p_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1072844016775081030)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'Y',
  'hide_control', 'N',
  'show_select_all', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1072843820585081028)
,p_name=>'REV_KONTROLLE_VORSCHRIFT_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'REV_KONTROLLE_VORSCHRIFT_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1072842714307081016)
,p_name=>'VERANTWORTLICHER_NEU_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VERANTWORTLICHER_NEU_ID'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Verantwortlicher Neu Id'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>0
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1072842416674081014)
,p_name=>'GRUPPE_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'GRUPPE_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Kontrollgruppe'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(3163689022778928893)
,p_internal_uid=>508523293120459342
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>false
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_no_data_found_message=>unistr('Keine ausstehenden \00C4nderungen vorhanden.')
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(1072857580833126829)
,p_interactive_grid_id=>wwv_flow_imp.id(3163689022778928893)
,p_static_id=>'25993548'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(1072857401268126828)
,p_report_id=>wwv_flow_imp.id(1072857580833126829)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3672206469324355968)
,p_view_id=>wwv_flow_imp.id(1072857401268126828)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(1072842714307081016)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1072856841358126824)
,p_view_id=>wwv_flow_imp.id(1072857401268126828)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(3163688937612928892)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1072855976218126820)
,p_view_id=>wwv_flow_imp.id(1072857401268126828)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(3163688911830928891)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>40
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1072855091394126818)
,p_view_id=>wwv_flow_imp.id(1072857401268126828)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(3163688771095928890)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1072854137048126815)
,p_view_id=>wwv_flow_imp.id(1072857401268126828)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(3163688641370928889)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1072851667078106062)
,p_view_id=>wwv_flow_imp.id(1072857401268126828)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(3163688540082928888)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>458.85400000000004
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1072850765046106059)
,p_view_id=>wwv_flow_imp.id(1072857401268126828)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(3163688437849928887)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>380
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1072848069513089495)
,p_view_id=>wwv_flow_imp.id(1072857401268126828)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(3163688359763928886)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>119
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1072827347148986764)
,p_view_id=>wwv_flow_imp.id(1072857401268126828)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(1072844184951081031)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1072822737935983475)
,p_view_id=>wwv_flow_imp.id(1072857401268126828)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(1072843820585081028)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1072449062062366351)
,p_view_id=>wwv_flow_imp.id(1072857401268126828)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(1072842416674081014)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>188.771
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2865100684318695359)
,p_plug_name=>'Vorschriften REV notwendig ohne REV'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3166491649897984364)
,p_plug_name=>unistr('Vorschriften und Hauptumsetzende OE f\00FCr SW-Relevanz')
,p_region_name=>'ig_vorschr'
,p_parent_plug_id=>wwv_flow_imp.id(2865100684318695359)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    SELECT vrv.vorschriftid,',
'            LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 10 then (verant.vorname || '' '' ||verant.nachname) end, '', '') ',
'                within group (order by verant.nachname, verant.vorname) as Hauptverantwortliche_REV_Name,',
'            LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 20 then (verant.vorname || '' '' ||verant.nachname) end, '', '') ',
'                within group (order by verant.nachname, verant.vorname) as Stellvertreter_REV_Name,',
'            LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 20 then (verant.email) end, '', '') ',
'                within group (order by verant.nachname) as Stellvertreter_REV_Mail,',
'            LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 20 then (verant.abteilung) end, '', '') ',
'                within group (order by verant.nachname) as Stellvertreter_REV_Abteilung',
'    FROM t_vorschrift_ref_verantwortlicher vrv',
'    left outer join t_verantwortlicher verant ON verant.verantwortlicherid = vrv.verantwortlicherid',
'    group by vrv.vorschriftid',
'),',
'land_cte as (',
'    SELECT vrl.vorschriftid,',
'           LISTAGG(distinct l.land, '', '') within group (order by l.land) as land_name',
'    FROM t_vorschrift_ref_land vrl',
'    JOIN t_land l ON l.landid = vrl.landid',
'    WHERE vrl.geloescht = 0',
'    GROUP BY vrl.vorschriftid',
'),',
'arbeitskreis_cte as (',
'    SELECT vak.vorschriftid,',
'           LISTAGG(distinct ak.kurz, '', '' ON OVERFLOW TRUNCATE) within group (order by ak.kurz) as arbeitskreis_liste',
'    FROM t_vorschrift_ref_et_b_ak vak',
'    JOIN t_et_b_ak ak ON vak.et_b_akid = ak.et_b_akid',
'    WHERE vak.geloescht = 0',
'    GROUP BY vak.vorschriftid',
')',
'SELECT vor.vorschriftid, ',
'       vor.vorschrift_nummer,',
'       l.land_name as land_name,',
'       ak.arbeitskreis_liste as arbeitskreis_liste,',
'       verantw.Hauptverantwortliche_REV_Name,',
'       vor.swr_hauptumsetzende_oe,',
'       verantw.Stellvertreter_REV_Name,',
'       verantw.Stellvertreter_REV_Mail,',
'       verantw.Stellvertreter_REV_Abteilung,',
'       case when vor.rxswin = 10 then ''Ja'' end as RXSWIN,',
'       decode(vor.rev_notwendig,10,''Nicht bewertet'',20,''Ja'',30,''Nein'') as REV_NOTWENDIG',
'FROM t_vorschrift vor',
'LEFT OUTER JOIN cte1 verantw ON vor.vorschriftid = verantw.vorschriftid',
'LEFT OUTER JOIN land_cte l ON vor.vorschriftid = l.vorschriftid',
'LEFT OUTER JOIN arbeitskreis_cte ak ON vor.vorschriftid = ak.vorschriftid',
'WHERE rev_notwendig = 20',
'AND verantw.Hauptverantwortliche_REV_Name is null;'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Vorschriften und Hauptumsetzende OE f\00FCr SW-Relevanz')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    SELECT vrv.vorschriftid,',
'            LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 10 then (verant.vorname || '' '' ||verant.nachname) end, '', '') within group (order by verant.nachname, verant.vorname)as Hauptverantwortliche_REV_Name,',
'           -- LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 10 then (verant.email) end, '', '') within group (order by verant.nachname)as Hauptverantwortliche_REV_Mail,',
'           -- LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 10 then (verant.abteilung) end, '', '') within group (order by verant.nachname)as Hauptverantwortliche_REV_Abteilung,',
'            LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 20 then (verant.vorname || '' '' ||verant.nachname) end, '', '') within group (order by verant.nachname, verant.vorname)as Stellvertreter_REV_Name,',
'            LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 20 then (verant.email) end, '', '') within group (order by verant.nachname)as Stellvertreter_REV_Mail,',
'            LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 20 then (verant.abteilung) end, '', '') within group (order by verant.nachname)as Stellvertreter_REV_Abteilung',
'    FROM t_vorschrift_ref_verantwortlicher vrv',
'    left outer join t_verantwortlicher verant ON verant.verantwortlicherid = vrv.verantwortlicherid',
'    group by vrv.vorschriftid',
')',
'    SELECT  vor.vorschriftid, vor.vorschrift_nummer,',
'            verantw.Hauptverantwortliche_REV_Name,',
'          -- v erantw.Hauptverantwortliche_REV_Mail,',
'          -- verantw.Hauptverantwortliche_REV_Abteilung,',
'            vor.swr_hauptumsetzende_oe,',
'            verantw.Stellvertreter_REV_Name,',
'            verantw.Stellvertreter_REV_Mail,',
'            verantw.Stellvertreter_REV_Abteilung,',
'            case when vor.rxswin = 10 then ''Ja'' end as RXSWIN,',
'            decode(vor.rev_notwendig,10,''Nicht bewertet'',20,''Ja'',30,''Nein'') as REV_NOTWENDIG',
'    FROM t_vorschrift vor',
'        left outer JOIN cte1 verantw ON vor.vorschriftid = verantw.vorschriftid',
'        WHERE rev_notwendig = 20',
'        and verantw.Hauptverantwortliche_REV_Name is null;'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1094139944329624932)
,p_name=>'VORSCHRIFTID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFTID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1068992305196462188)
,p_name=>'LAND_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAND_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>unistr('L\00E4nder')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1068992213978462187)
,p_name=>'ARBEITSKREIS_LISTE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ARBEITSKREIS_LISTE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Arbeitskreise'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>170
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1977611072557243699)
,p_name=>'VORSCHRIFT_NUMMER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFT_NUMMER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Vorschrift Nummer'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1977611122021243700)
,p_name=>'HAUPTVERANTWORTLICHE_REV_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HAUPTVERANTWORTLICHE_REV_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'hauptverantw. REV'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1977611419483243703)
,p_name=>'SWR_HAUPTUMSETZENDE_OE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SWR_HAUPTUMSETZENDE_OE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'OE2 des REV'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1977611513081243704)
,p_name=>'STELLVERTRETER_REV_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STELLVERTRETER_REV_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'stellvertr. REV'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1977611634629243705)
,p_name=>'STELLVERTRETER_REV_MAIL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STELLVERTRETER_REV_MAIL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'stellvertr. REV<br/> E-Mail'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1977611736331243706)
,p_name=>'STELLVERTRETER_REV_ABTEILUNG'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STELLVERTRETER_REV_ABTEILUNG'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'stellvertr. REV<br/>Abteilung'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1977611841763243707)
,p_name=>'RXSWIN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RXSWIN'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'potentiell<br/>SUMS-relevant'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1977611912998243708)
,p_name=>'REV_NOTWENDIG'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'REV_NOTWENDIG'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'REV notwendig'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2450044323379660530)
,p_name=>'DETAILS'
,p_source_type=>'NONE'
,p_item_type=>'NATIVE_LINK'
,p_heading=>'&nbsp;'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'CENTER'
,p_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:&VORSCHRIFTID.'
,p_link_text=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_link_attributes=>'target="_blank"'
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(2450041514566660502)
,p_internal_uid=>6122253830466048737
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>false
,p_fixed_row_height=>false
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(2450050050148660880)
,p_interactive_grid_id=>wwv_flow_imp.id(2450041514566660502)
,p_static_id=>'4721577'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(2450050244056660881)
,p_report_id=>wwv_flow_imp.id(2450050050148660880)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3672211237122379555)
,p_view_id=>wwv_flow_imp.id(2450050244056660881)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(1068992305196462188)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3672210212959379549)
,p_view_id=>wwv_flow_imp.id(2450050244056660881)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(1068992213978462187)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1094120967980400664)
,p_view_id=>wwv_flow_imp.id(2450050244056660881)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(1094139944329624932)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1977915571277297748)
,p_view_id=>wwv_flow_imp.id(2450050244056660881)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(1977611072557243699)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>133
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1977916415276297751)
,p_view_id=>wwv_flow_imp.id(2450050244056660881)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(1977611122021243700)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>128
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1977919087052297759)
,p_view_id=>wwv_flow_imp.id(2450050244056660881)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(1977611419483243703)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>191
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1977920001885297762)
,p_view_id=>wwv_flow_imp.id(2450050244056660881)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(1977611513081243704)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>97
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1977920882558297765)
,p_view_id=>wwv_flow_imp.id(2450050244056660881)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(1977611634629243705)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>106
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1977921714699297767)
,p_view_id=>wwv_flow_imp.id(2450050244056660881)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(1977611736331243706)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>108
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1977922676429297771)
,p_view_id=>wwv_flow_imp.id(2450050244056660881)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(1977611841763243707)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>102
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1977923558671297774)
,p_view_id=>wwv_flow_imp.id(2450050244056660881)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(1977611912998243708)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>113
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(2450112223971348396)
,p_view_id=>wwv_flow_imp.id(2450050244056660881)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(2450044323379660530)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>40
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10251790351389058787)
,p_plug_name=>'Neuen Verantwortlichen zuordnen'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_plug_display_column=>8
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1072842997509081019)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3163689256060928895)
,p_button_name=>'SET_GRID1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Verantwortlichen setzen'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1072808940734761607)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10251790351389058787)
,p_button_name=>'SEARCH_LDAP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'In LDAP suchen'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:65:&SESSION.::&DEBUG.:65:P65_CAMEFROM:421'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1094410359936607996)
,p_name=>'P423_SELECTED_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3166491649897984364)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1072844229380081032)
,p_name=>'P423_CONFIRM_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3163689256060928895)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1072808169357761592)
,p_name=>'P423_NEUER_VERANTWORTLICHER_DISPLAY'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(10251790351389058787)
,p_prompt=>'Neuer Verantwortlicher'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1072807784209761587)
,p_name=>'P423_NEUER_VERANTWORTLICHER_ID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(10251790351389058787)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1094404361726607993)
,p_name=>'Change'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(3166491649897984364)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1094403837016607992)
,p_event_id=>wwv_flow_imp.id(1094404361726607993)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i, selectedIds = "",',
'model = this.data.model;',
'for ( i = 0; i < this.data.selectedRecords.length; i++ ) {',
'    selectedIds += model.getValue( this.data.selectedRecords[i], "VORSCHRIFTID") + ":";',
'}',
'$s("P423_SELECTED_ID", selectedIds);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3163688253381928885)
,p_name=>'confirm change'
,p_event_sequence=>80
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.confirm_rev_changes'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#grid1'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1072844486894081034)
,p_event_id=>wwv_flow_imp.id(3163688253381928885)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Damit werden die vom REV vorgenommenen \00C4nderungen best\00E4tigt.')
,p_attribute_02=>unistr('Daten \00FCbernehmen?')
,p_attribute_04=>'fa-question'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1072844336613081033)
,p_event_id=>wwv_flow_imp.id(3163688253381928885)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log($(this.triggeringElement).data("id"))',
'var id = $(this.triggeringElement).data("id");',
'$s("P423_CONFIRM_ID",id);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1072843647118081026)
,p_event_id=>wwv_flow_imp.id(3163688253381928885)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'pck_rev.pConfirmChanges(:P423_CONFIRM_ID);'
,p_attribute_02=>'P423_CONFIRM_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1072843517819081025)
,p_event_id=>wwv_flow_imp.id(3163688253381928885)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var model = apex.region("grid1").widget().interactiveGrid("getViews").grid.model;',
'var recordArray = [];',
'var record = model.getRecord($v(''P423_CONFIRM_ID''));',
'recordArray.push(record);',
'model.fetchRecords(recordArray);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1072784040443745890)
,p_name=>'Dialog closed'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1072808940734761607)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1072783631832745885)
,p_event_id=>wwv_flow_imp.id(1072784040443745890)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P423_NEUER_VERANTWORTLICHER_ID := pck_ri.fCreatePlaceHolderUser(:P65_GID_CHOSEN);',
'select nachname || '', '' || vorname || '' ('' || abteilung || '')'' into :P423_NEUER_VERANTWORTLICHER_DISPLAY',
'from t_benutzer',
'where benutzerid = :P423_NEUER_VERANTWORTLICHER_ID;'))
,p_attribute_02=>'P65_GID_CHOSEN'
,p_attribute_03=>'P423_NEUER_VERANTWORTLICHER_ID,P423_NEUER_VERANTWORTLICHER_DISPLAY'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1072842863727081018)
,p_name=>'set new rev'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1072842997509081019)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1072842808676081017)
,p_event_id=>wwv_flow_imp.id(1072842863727081018)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var model = apex.region("grid1").widget().interactiveGrid("getViews", "grid").model;',
'var records = apex.region("grid1").call("getViews").grid.getSelectedRecords();',
'var new_rev = $v(''P423_NEUER_VERANTWORTLICHER_DISPLAY'');',
'var new_revid = $v(''P423_NEUER_VERANTWORTLICHER_ID'');',
'for ( i = 0; i < records.length; i++ ) {',
'    model.setValue(records[i], "VERANTWORTLICHER_NEU", new_rev);',
'    model.setValue(records[i], "VERANTWORTLICHER_NEU_ID", new_revid);',
'}'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1072842533075081015)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(3163689187577928894)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'New'
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>'update t_rev_kontrolle_vorschrift set neuer_verantwortlicherid = :VERANTWORTLICHER_NEU_ID where rev_kontrolle_vorschrift_id = :REV_KONTROLLE_VORSCHRIFT_ID;'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2599369782824307220
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1094406560174607994)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Initialize form Regulierungsverantwortlichkeit bearbeiten'
,p_process_sql_clob=>'null;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2577805755724780241
);
wwv_flow_imp.component_end;
end;
/
