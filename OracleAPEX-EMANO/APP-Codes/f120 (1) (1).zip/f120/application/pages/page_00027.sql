prompt --application/pages/page_00027
begin
--   Manifest
--     PAGE: 00027
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>27
,p_name=>unistr('Qualit\00E4tscheck')
,p_alias=>unistr('QUALIT\00C4TSCHECK')
,p_step_title=>unistr('Qualit\00E4tscheck')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(829559198251399396)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    select ',
'        v.vorschriftid, ',
'        v.vorschrift_nummer, ',
'        v.vorschrift_bezeichnung, ',
'        v.prognose_qualitaetid, ',
'        v.vorschrift_statusid, ',
'        v.vorschrift_freigabestatusid,',
'        pck_ri_validation.fVal(v.vorschriftid) as fehler_liste,',
'        (select listagg(etb.kurz, '', '') within group(order by etb.kurz)',
'            from t_vorschrift_ref_et_b_ak ref, t_et_b_ak etb where ref.et_b_akid = etb.et_b_akid',
'            and ref.vorschriftid = v.vorschriftid) as AK_Kurzbezeichnung,',
'        (select b.NACHNAME || '', '' || b.VORNAME ',
'         from t_benutzer b ',
'         where b.BENUTZERID = v.LEAD_VKO_BENUTZERID) as lead_vko',
'        ',
'    from ',
'        t_vorschrift v',
')',
'select * ',
'from cte1 ',
'where fehler_liste is not null;',
'',
'',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'New'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(829559039554399395)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>283133897540735009
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(829559008540399394)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_column_linktext=>'<span class="fa fa-search"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(829558848140399393)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(829558729467399391)
,p_db_column_name=>'FEHLER_LISTE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fehler Liste'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(829558587547399390)
,p_db_column_name=>'VORSCHRIFT_BEZEICHNUNG'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Titel Englisch'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(829558454484399389)
,p_db_column_name=>'PROGNOSE_QUALITAETID'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('Prognosequalit\00E4t')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(958121403566083634)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(829558356697399388)
,p_db_column_name=>'VORSCHRIFT_STATUSID'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Status der Vorschrift'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(2490458092659806028)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(829558242122399387)
,p_db_column_name=>'VORSCHRIFT_FREIGABESTATUSID'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Interner DB Freigabestatus'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(958129793570194302)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(911277913867629677)
,p_db_column_name=>'AK_KURZBEZEICHNUNG'
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>'AK Kurzbezeichnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781399299274132170)
,p_db_column_name=>'LEAD_VKO'
,p_display_order=>90
,p_column_identifier=>'L'
,p_column_label=>'Lead-VKO'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(930972916740146011)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1817201'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'VORSCHRIFTID:VORSCHRIFT_NUMMER:FEHLER_LISTE:VORSCHRIFT_FREIGABESTATUSID:PROGNOSE_QUALITAETID:VORSCHRIFT_STATUSID:VORSCHRIFT_BEZEICHNUNG:AK_KURZBEZEICHNUNG:LEAD_VKO:'
);
wwv_flow_imp.component_end;
end;
/
