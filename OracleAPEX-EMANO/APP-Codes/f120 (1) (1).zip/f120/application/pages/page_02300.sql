prompt --application/pages/page_02300
begin
--   Manifest
--     PAGE: 02300
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>2300
,p_name=>'GETEX Fehlerhandling'
,p_alias=>'GETEX-ABARBEITUNGSLISTE'
,p_step_title=>'GETEX Fehlerhandling'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3170878890298169387)
,p_plug_name=>unistr('Gel\00F6schte GETEX-Eintr\00E4ge')
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_regind as (',
'              select vorschriftid, vorschrift_nummer, regindexid, Dokumentendatum',
'      from t_vorschrift where regindexid is not null',
'), cte_mfv as ( ',
'         select listagg(mfvid, '', '') within group (order by mfvid) as mfvids, vorschriftid',
'        -- select *',
'      from t_mfv_ref_vorschrift',
'      group by vorschriftid',
')  ',
'select --m.reg_id as link, m.reg_id,',
'ri.vorschriftid as link,',
' m.reg_num as getex_Vorschriftennummer, trunc(rev_doc_datum) as getex_dokumentendatum ,',
' ri.vorschrift_nummer, ri.Dokumentendatum regindex_dokumentendatum ,',
' rev_displayurl, mfv.mfvids,',
' m.loesch_datum, case when (m.loesch_datum < sysdate ) then ''Ja'' else ''nein'' end as geloescht',
'-- , k.kommentar,  cte1.liste_cluster as getex_cluster, cte2.liste_fzg_typen as getex_fzg_typen',
'from mv_getex_vorschrift m',
'join cte_regind ri on (ri.regindexid = m.reg_id)',
'left outer join cte_mfv mfv on (mfv.vorschriftid = ri.vorschriftid)',
'where ',
'  (m.loesch_datum is not null and m.loesch_datum < sysdate )',
' order by 2'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Gel\00F6schte GETEX-Eintr\00E4ge')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(3170878727357169386)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>501333588542218849
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3170878631554169385)
,p_db_column_name=>'LINK'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Link'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#LINK#'
,p_column_linktext=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1069009785671571928)
,p_db_column_name=>'LOESCH_DATUM'
,p_display_order=>20
,p_column_identifier=>'H'
,p_column_label=>unistr('L\00F6sch Datum')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1069009661207571927)
,p_db_column_name=>'GELOESCHT'
,p_display_order=>30
,p_column_identifier=>'I'
,p_column_label=>unistr('Gel\00F6scht')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1069010346793571934)
,p_db_column_name=>'GETEX_VORSCHRIFTENNUMMER'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Getex Vorschriftennummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1069010270152571933)
,p_db_column_name=>'GETEX_DOKUMENTENDATUM'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Getex Dokumentendatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1069010198269571932)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Vorschrift Nummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1069009820099571929)
,p_db_column_name=>'MFVIDS'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Mfvids'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1069010016849571931)
,p_db_column_name=>'REGINDEX_DOKUMENTENDATUM'
,p_display_order=>90
,p_column_identifier=>'E'
,p_column_label=>'Regindex Dokumentendatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1069009971420571930)
,p_db_column_name=>'REV_DISPLAYURL'
,p_display_order=>100
,p_column_identifier=>'F'
,p_column_label=>'Rev Displayurl'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1069002262641569031)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'26032101'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LINK:GETEX_VORSCHRIFTENNUMMER:GETEX_DOKUMENTENDATUM:VORSCHRIFT_NUMMER:REGINDEX_DOKUMENTENDATUM:LOESCH_DATUM:GELOESCHT:MFVIDS:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7539553884429432302)
,p_plug_name=>unistr('Ge\00E4nderte Vorschriften aus Getex 2 zur Pr\00FCfung und \00DCbernahme')
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with etb_cte as (',
'   select listagg(etb,'', '') within group (order by etb) liste,  vorschriftid',
'    from (',
'        select distinct ak.kurz etb, vtl.vorschriftid vorschriftid',
'        from t_vorschrift_ref_thema vtl',
'        join t_thema_ref_et_b_ak t on (vtl.themaid = t.themaid)',
'        join t_et_b_ak ak on (ak.et_b_akid = t.et_b_akid)',
'        where  vtl.geloescht = 0',
'    )',
'    group by vorschriftid',
'),',
'cte_act_g as ( -- alle Getex vorschriften , die activ in Verkn. sind ',
'           select distinct v.vorschriftid   -- gr.v_id , gr.reg_number --, gr.relationtype, gr.targetid ',
'            from  MV_getex_vorschrift_relation gr',
'            join t_vorschrift v on (v.regindexid is not null and v.regindexid = gr.v_id)',
'             where   gr.relationtype  in  (''EQUIVALENT_TO'', ''SUCCESSOR'',  ''CHANGES'', ''DEMANDS'', ''LINKED_TO'', ''CONSOLIDATES'') ',
'             and v.master in ( 20 , 30)',
'             order by v.vorschriftid ',
' ), ',
' cte_act_ri as ( -- alle active verkn. in Regindex, die vom GETEX gepflegt werden',
'          select distinct vrv.nachfolger_vorschriftid as vorschriftid',
'          from t_vorschrift_ref_vorschrift vrv',
'          join t_vorschrift v on (v.vorschriftid = vrv.nachfolger_vorschriftid)',
'          where  v.regindexid is not null ',
'          and v.master in ( 20 , 30)',
'          and v.regindexid in (select  reg_id  ',
'                             from mv_getex_vorschrift where nvl(loesch_datum, sysdate + 2) > sysdate )',
'           order by 1',
' )',
'--  cte_v_act as ( -- alle Getex vorschriften , die activ in Verkn. sind (exclusiv die Verkn. die als gegenpart von cte_v_pass)',
'--                select distinct v.vorschriftid   -- gr.v_id , gr.reg_number --, gr.relationtype, gr.targetid ',
' --               from  MV_getex_vorschrift_relation gr',
' --               full outer join t_vorschrift v on (v.regindexid is not null and v.regindexid = gr.v_id)',
'--                where (  gr.relationtype  in  (''EQUIVALENT_TO'', ''SUCCESSOR'',  ''CHANGES'', ''DEMANDS'',''LINKED_TO'', ''CONSOLIDATES'') ',
'--                       OR  (gr.relationtype is null and v.vorschriftid  in (',
'--                                                      select distinct nachfolger_vorschriftid from t_vorschrift_ref_vorschrift ) ) ',
'--                )',
'--                and v.master in ( 20 , 30)',
'--    ) ',
'    SELECT v.vorschriftid as link_abgl, ',
'       v.vorschriftID, v.vorschrift_nummer, v.DOKUMENTENDATUM, v.VORSCHRIFT_BEZEICHNUNG as VORSCHRIFT_BEZEICHNUNG, ',
'       gk.Kommentar as kommentar,',
'       v.Vorschrift_freigabeStatusid, v.VORSCHRIFT_STATUSID, v.EINSATZDATUM_MODELLID,',
'       v.Vorschrift_typid, -- CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN v.BEMERKUNG ELSE v.BEMERKUNG_ENGLISCH END BEMERKUNG, ',
'       v.LETZTE_AENDERUNG_DATUM ',
'       , nvl2(b.nachname, b.nachname||'',''|| b.vorname, ''system'') as letzter_benutzer,',
'       etb_cte.liste as arbeitskreise,',
'       case when (v.status_update_getex is null) then ''-''',
'            when v.status_update_getex  =10 then ''aktuell'' ',
'            when v.status_update_getex  =20 then ''nicht aktuell'' ',
'            when v.status_update_getex  =30 then  ''nicht in Getex''  end  as status_update_getex,',
'        v.LETZTE_AENDERUNG_GETEX_ATTR,',
'        v.MASTER,',
'        nvl2(lvko.nachname, lvko.nachname||'',''|| lvko.vorname, null) as Lead_VKO',
'    FROM T_Vorschrift v',
'    left outer join t_vorschrift_ref_vorschrift vrv on (v.vorschriftid = vrv.nachfolger_vorschriftid and beziehung_art = 30)    ',
'    left outer join t_vorschrift vp on (vrv.vorgaenger_vorschriftid = vp.vorschriftid and v.vorschrift_typid = 20) -- parent bei supplements    ',
'    left outer join T_BEnutzer b on (v.LETZTE_AENDERUNG_BENUTZERID = b.benutzerid)',
'    left outer join T_BEnutzer lvko on (nvl(vp.lead_vko_benutzerid, v.LEAD_VKO_BENUTZERID) = lvko.benutzerid)',
'    left outer join etb_cte on (etb_cte.vorschriftid = v.vorschriftid)',
'    left outer join T_getex_KOMMENTAR  gk on (v.regindexid is not null and gk.getex_key = v.regindexid)',
'   WHERE v.Vorschrift_freigabeStatusid not in (-1, 1) ',
'   and v.master in (20, 30)',
'   and (v.status_update_getex is not null and v.status_update_getex = 20)',
'   and ( --nvl(v.getex_vergleich_bitmaske, 0) != 16384 ',
'        ( bitand(nvl(v.getex_vergleich_bitmaske, 0), power(2,0)+ power(2,1)+ power(2,2)+ power(2,3)+ power(2,4)+ power(2,5)+ power(2,6)',
'           + power(2,7)+ power(2,8)+ power(2,9) + power(2,10)+ power(2,11)+ power(2,12)+power(2,13) ) >0',
'        )',
'       or  ',
'        (v.vorschriftid in (select vorschriftid from cte_act_g)',
'         or v.vorschriftid in (select vorschriftid from cte_act_ri) )',
unistr('    )    -- ''nicht relevant'' ausschlie\00DFen 1472, f. alle Rollen'),
'     AND (v.Vorschrift_FREIGABESTATUSID !=30 );  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'pck_ri.fIsUserInRolle(listRolleId => ''1100:1003:1000'') > 0'
,p_plug_display_when_cond2=>'PLSQL'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>'pck_ri.fIsUserInRolle(listRolleId => ''1003'') = 0'
,p_plug_read_only_when2=>'PLSQL'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'-- :P25_ROWID is not null and ',
'pck_ri.fIsUserInRolle(listRolleId => ''1100:1003'') > 0  -- 1100 = Rolle Getex Migration, 1003 = Fach admmin',
')'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(7539553995651432303)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'Keine daten gefunden'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_detail_link_text=>'<span class="fa fa-search" aria-hidden="true"></span>	'
,p_detail_link_condition_type=>'EXPRESSION'
,p_detail_link_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 25,',
'                      accessMode => 100))'))
,p_detail_link_cond2=>'PLSQL'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>11211766311550820538
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(994963938258067553)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Vorschriftid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(994959520694067546)
,p_db_column_name=>'LINK_ABGL'
,p_display_order=>20
,p_column_identifier=>'O'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:29:P29_VORSCHRIFTID,P29_MASTER:#VORSCHRIFTID#,#MASTER#'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-code-fork fa-rotate-180"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'( pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1100'') > 0 ) '
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(994963515966067553)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Vorschrift Nummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(994963125036067552)
,p_db_column_name=>'VORSCHRIFT_FREIGABESTATUSID'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Vorschrift Freigabestatus'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(958129793570194302)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(994962754025067551)
,p_db_column_name=>'VORSCHRIFT_STATUSID'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Vorschrift Status'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(2490458092659806028)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(994962322092067551)
,p_db_column_name=>'VORSCHRIFT_TYPID'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Vorschrift Typ'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(2656545044559578040)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(994961948219067550)
,p_db_column_name=>'LETZTER_BENUTZER'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(994961519294067550)
,p_db_column_name=>'ARBEITSKREISE'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Arbeitskreise'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(994961192575067549)
,p_db_column_name=>'VORSCHRIFT_BEZEICHNUNG'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Vorschrift Bezeichnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(994965197571067555)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>120
,p_column_identifier=>'S'
,p_column_label=>unistr('Gr\00FCnde f\00FCr\2018s nicht-Weiterschalten')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(994960726943067548)
,p_db_column_name=>'STATUS_UPDATE_GETEX'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Status Update Getex'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(994960362932067548)
,p_db_column_name=>'LETZTE_AENDERUNG_GETEX_ATTR'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>unistr('Letzte \00C4nderung Getex Attribute')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(994959967104067547)
,p_db_column_name=>'MASTER'
,p_display_order=>150
,p_column_identifier=>'N'
,p_column_label=>'Master'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(994959206307067546)
,p_db_column_name=>'LEAD_VKO'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Lead Vko'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(994965502826067561)
,p_db_column_name=>'EINSATZDATUM_MODELLID'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Einsatzdatum Modellid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(1076773784946225404)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(994964724137067554)
,p_db_column_name=>'DOKUMENTENDATUM'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Dokumentendatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(994964397488067554)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>190
,p_column_identifier=>'T'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(7553386560977425793)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2997930'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LINK_ABGL:VORSCHRIFT_NUMMER:DOKUMENTENDATUM:VORSCHRIFT_FREIGABESTATUSID:VORSCHRIFT_STATUSID:VORSCHRIFT_TYPID:EINSATZDATUM_MODELLID:LEAD_VKO:ARBEITSKREISE:VORSCHRIFT_BEZEICHNUNG:KOMMENTAR:STATUS_UPDATE_GETEX:LETZTE_AENDERUNG_GETEX_ATTR:LETZTE_AENDERUN'
||'G_DATUM:LETZTER_BENUTZER:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7626112359739086795)
,p_plug_name=>unistr('GETEX-Datens\00E4tze ohne RegIndex-Zuordnung')
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:is-expanded:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    select reg_id, listagg(distinct clust_name, '', '') within group (order by clust_name) liste_cluster',
'    from mv_getex_vorschrift_cluster',
'    where clust_name is not null',
'    group by reg_id',
'), cte2 as (',
'    select v_id as reg_id, listagg(fahrzeug_typ, '', '') within group (order by fahrzeug_typ) liste_fzg_typen',
'    from mv_getex_vorschrift_fz_typ',
'    where fahrzeug_typ is not null',
'    group by v_id',
')    ',
'select m.reg_id as link, m.reg_id, m.reg_num, trunc(rev_doc_datum) as rev_doc_datum, rev_displayurl, k.kommentar, cte1.liste_cluster as getex_cluster, cte2.liste_fzg_typen as getex_fzg_typen',
'from mv_getex_vorschrift m',
'left outer join cte1 on (m.reg_id = cte1.reg_id)',
'left outer join t_getex_kommentar k on (m.reg_id = k.getex_key)',
'left outer join cte2 on (m.reg_id = cte2.reg_id)',
'where (rev_regindexid is null or rev_regindexid not in (select vorschriftid from t_vorschrift))',
'and m.reg_id not in (select regindexid from t_vorschrift where regindexid is not null) ',
'and ( m.loesch_datum is null or m.loesch_datum > sysdate )',
'order by 2'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('GETEX-Datens\00E4tze ohne RegIndex-Zuordnung')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(7626112418318086796)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>11298324734217475031
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1098477117910754120)
,p_db_column_name=>'LINK'
,p_display_order=>10
,p_column_identifier=>'E'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:2305:&SESSION.::&DEBUG.:2305:P2305_GETEXKEY:#REG_ID#'
,p_column_linktext=>'<span class="fa fa-edit" title="Bearbeiten"></span>'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1098477542303754120)
,p_db_column_name=>'REV_DISPLAYURL'
,p_display_order=>20
,p_column_identifier=>'D'
,p_column_label=>'&nbsp;'
,p_column_link=>'#REV_DISPLAYURL#'
,p_column_linktext=>unistr('<span title="GETEX-Link \00F6ffnen" class="fa fa-globe"></span>')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1098478779568754122)
,p_db_column_name=>'REG_ID'
,p_display_order=>30
,p_column_identifier=>'A'
,p_column_label=>'GETEX ID'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1098478388174754121)
,p_db_column_name=>'REG_NUM'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1098477989911754121)
,p_db_column_name=>'REV_DOC_DATUM'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Dokumentendatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1098476756251754120)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1098476345695754120)
,p_db_column_name=>'GETEX_CLUSTER'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'GETEX Cluster'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1098475969343754120)
,p_db_column_name=>'GETEX_FZG_TYPEN'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'GETEX Fzg-Typen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(8235476501333435623)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'14326227'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LINK:REV_DISPLAYURL:REG_ID:REG_NUM:REV_DOC_DATUM:KOMMENTAR:GETEX_CLUSTER:GETEX_FZG_TYPEN:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8235550195497509281)
,p_plug_name=>unistr('\00DCbersicht Zuordnungen')
,p_region_name=>'ig_zuord'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:is-expanded:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    select x.reg_id, count(distinct rev_id) anzahl_revisionen',
'    from t_x_getex_import t,',
'    json_table(t.daten, ''$'' columns (',
'        reg_id varchar2(250) path ''$.id'',',
'        nested path ''$.revisions[*]'' columns (',
'            rev_id varchar2(250) path ''$.id''',
'        )',
'    )) x',
'    group by x.reg_id',
'),',
' cte_clu as (',
'    select reg_id, listagg(distinct clust_name, '', '') within group (order by clust_name) liste_cluster',
'    from mv_getex_vorschrift_cluster',
'    where clust_name is not null',
'    group by reg_id',
' ),',
' cte_ak as (',
'    select  v.vorschriftid,  listagg(distinct ak.kurz, '', '') within group (order by ak.kurz) liste_ak',
'    ',
'    from t_vorschrift v',
'        left outer join t_vorschrift_ref_thema vtl on (vtl.vorschriftid = v.vorschriftid and vtl.geloescht = 0)',
'        right outer join t_thema_ref_et_b_ak trak on (vtl.themaid = trak.themaid)',
'        left outer join t_et_b_ak ak on (ak.et_b_akid = trak.et_b_akid)',
'     group by v.vorschriftid',
' ),',
' cte_land as (',
'     select  vs.vorschriftid,  listagg(distinct l.B_nummer, '', '') within group (order by l.B_nummer) liste_land',
'    from t_vorschrift vs',
'        left outer join t_vorschrift_ref_land vrl on (vrl.vorschriftid = vs.vorschriftid and vrl.geloescht = 0)',
'        left outer join t_land l on (l.landid = vrl.landid )',
'         group by vs.vorschriftid',
' )',
'    select ''<a href="'' ||  case when  v.vorschriftID is not null then',
'                        apex_page.get_url(p_page => 29, p_items => ''P29_VORSCHRIFTID'', ',
'                                              p_values => v.VORSCHRIFTID, ',
'                                              p_clear_cache => 29)',
'                    else '' ''',
'                    end ',
'                    || ''"><span  class="fa fa-code-fork fa-rotate-180" aria-hidden="true" ></span></a>''  abgl_link, ',
'  ',
'    m.reg_id getexid,',
'    reg_displayurl getex_link, reg_num getex_vorschrift_nummer,',
'        m.rev_doc_datum getex_dokumentendatum,   gk.bearbeiterid as bearbeiter ,',
'        ''<span  class="fa fa-download" aria-hidden="true" ></span>'' as downl_link,',
'         v.vorschriftid, v.vorschrift_nummer, v.dokumentendatum, cte1.anzahl_revisionen,',
'        case emano_util.fIsUnequal(m.reg_num,v.vorschrift_nummer) when 1 then ''Ja'' else ''Nein'' end as unterschied_nummer, gk.kommentar,',
'        gk.status_diff,',
'        gk.eintrag_fehlerhaft ,',
'       case when m.reg_id is not null then ''U'' else null end as row_op,',
'        case when v.vorschriftid is not null then ''<a href="'' || apex_page.get_url(p_page => 25, p_items => ''P25_VORSCHRIFTID'', p_values => v.vorschriftid, p_clear_cache => 25) || ''" target="_blank"><span class="fa fa-link"></span></a>'' ',
'             else null end as link_regindex,',
'        -- case when nvl(v.master, 10) = 20 then ''Getex'' else ''Regindex'' end as Master,',
'        nvl(v.master,10) as master_value,',
'        case when (v.vorschriftid is  null ) then ''-''',
'             when (PCK_RI_GETEX_COMPARE.fCheckEquivDemandDiff(v.vorschriftid, 0) = 0 ) then ''Nein''',
'             else ''Ja'' end   as  Demand_diff,',
'             case when (v.vorschriftid is  null ) then ''-''',
'             when (PCK_RI_GETEX_COMPARE.fCheckEquivDemandDiff(v.vorschriftid, 1) = 0 ) then ''Nein''',
'             else ''Ja'' end   as  Equivalent_diff,',
unistr('     case when (m.loesch_datum < sysdate) then  ''Getex2 Vorschrift gel\00F6scht'' '),
'          when (v.status_update_getex is null) then ''-''',
'                 when v.status_update_getex  =10 then ''aktuell'' ',
'            when v.status_update_getex  =20 then ''nicht aktuell'' ',
'            when v.status_update_getex  =30 then  ''nicht in Getex''  end as abgleich_status,',
'        --  b.NachName|| '', '' ||b.vorname as Lead_VKO,',
'        CASE ',
'            WHEN b.nachname IS NOT NULL AND b.vorname IS NOT NULL ',
'            THEN b.nachname || '', '' || b.vorname',
'            WHEN b.nachname IS NOT NULL AND b.vorname IS NULL ',
'            THEN b.nachname',
'            WHEN b.nachname IS NULL AND b.vorname IS NOT NULL ',
'            THEN b.vorname',
'        ELSE NULL ',
'        END as Lead_VKO,',
'',
'         cte_clu.liste_cluster as getex_cluster,',
'         cte_ak.liste_ak, cte_land.liste_land,',
'         v.ATVW_DOK,',
'         v.CODEBEAMER_DOK',
'    from mv_getex_vorschrift m',
'    left outer join t_getex_kommentar gk on (m.reg_id = gk.getex_key)',
'    left outer join cte1 on (m.reg_id = cte1.reg_id)',
'    full outer join t_vorschrift v on (v.regindexid = m.reg_id)',
'    left outer join t_benutzer b on (b.benutzerid = v.Lead_VKO_benutzerid)',
'    left outer join cte_clu on (m.reg_id = cte_clu.reg_id)',
'    left outer join cte_ak on (cte_ak.vorschriftid = v.vorschriftid)',
'     left outer join cte_land on (cte_land.vorschriftid = v.vorschriftid)'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('\00DCbersicht Zuordnungen')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column_group(
 p_id=>wwv_flow_imp.id(8289761065425830764)
,p_heading=>'GETEX'
);
wwv_flow_imp_page.create_region_column_group(
 p_id=>wwv_flow_imp.id(8289761108028830765)
,p_heading=>'RegIndex'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1091922499028257334)
,p_name=>'MASTER_VALUE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MASTER_VALUE'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_RADIOGROUP'
,p_heading=>'Master'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>190
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Regindex'' as d, 10 as r ',
'from dual',
'union all ',
'select ''Getex'' as d, 20 as r ',
'from dual'))
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(988040950967483324)
,p_name=>'ATVW_DOK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ATVW_DOK'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'ATVW Dok'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>280
,p_value_alignment=>'RIGHT'
,p_group_id=>wwv_flow_imp.id(8289761108028830765)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(988040898321483323)
,p_name=>'CODEBEAMER_DOK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODEBEAMER_DOK'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Codebeamer Dok'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>290
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(8289761108028830765)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3341160759532176237)
,p_name=>'ABGL_LINK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ABGL_LINK'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_LINK'
,p_heading=>'Abgleich Link'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_escape_on_http_output=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3341160884064176238)
,p_name=>'STATUS_DIFF'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS_DIFF'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Status<br> Diff'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>170
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_is_required=>false
,p_lov_type=>'STATIC'
,p_lov_source=>unistr('STATIC:nicht gepr\00FCft;0,in Bearbeitung;10,abgeschlossen;20,Warten auf Lead VKO;30')
,p_lov_display_extra=>false
,p_lov_display_null=>true
,p_lov_null_text=>'unbekannt'
,p_lov_null_value=>'-2'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3341160898587176239)
,p_name=>'EINTRAG_FEHLERHAFT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EINTRAG_FEHLERHAFT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Eintrag<br>Fehlerhaft'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>180
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_is_required=>false
,p_lov_type=>'STATIC'
,p_lov_source=>'STATIC:Nein;0,Ja;1'
,p_lov_display_extra=>false
,p_lov_display_null=>true
,p_lov_null_text=>'unbekannt'
,p_lov_null_value=>'-2'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3341161145262176241)
,p_name=>'DEMAND_DIFF'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DEMAND_DIFF'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Demand<br> Diff'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>200
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3341161291280176242)
,p_name=>'EQUIVALENT_DIFF'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EQUIVALENT_DIFF'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Equivalent<br> Diff'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>210
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3341161833589176248)
,p_name=>'BEARBEITER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BEARBEITER'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Bearbeiter'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(8289761065425830764)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select Nachname|| '', '' || Vorname as d, b.benutzerid r',
'from t_Benutzer b',
'join t_benutzer_ref_rolle brr on (brr.benutzerid = b.benutzerid and rolleid=1200) -- Redaktionsteam',
'',
'order by Nachname|| '', '' || Vorname'))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3341161944039176249)
,p_name=>'DOWNL_LINK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DOWNL_LINK'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_LINK'
,p_heading=>'Download<br>JSON'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>220
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(8289761065425830764)
,p_use_group_for=>'BOTH'
,p_link_target=>'f?p=&APP_ID.:0:&SESSION.:APPLICATION_PROCESS=downloadGetexJson:&DEBUG.::G_GETEX_KEY:&GETEXID.'
,p_link_text=>'&DOWNL_LINK.'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_escape_on_http_output=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3341162314140176253)
,p_name=>'ABGLEICH_STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ABGLEICH_STATUS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Abgleich<br>Status'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>230
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3341162490496176254)
,p_name=>'LEAD_VKO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LEAD_VKO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Lead Vko'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>240
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(8289761108028830765)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3341162499906176255)
,p_name=>'GETEX_CLUSTER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'GETEX_CLUSTER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Getex Cluster'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>250
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(8289761065425830764)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3341162681603176256)
,p_name=>'LISTE_AK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LISTE_AK'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Arbeitskreise'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>260
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(8289761108028830765)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3341162742163176257)
,p_name=>'LISTE_LAND'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LISTE_LAND'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('L\00E4nder')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>270
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(8289761108028830765)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8235550397898509283)
,p_name=>'GETEXID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'GETEXID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'ID'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(8289761065425830764)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8235550521021509285)
,p_name=>'VORSCHRIFTID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFTID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'ID'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(8289761108028830765)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8235550948907509289)
,p_name=>'ANZAHL_REVISIONEN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ANZAHL_REVISIONEN'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Rev.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(8289761065425830764)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8235551092255509290)
,p_name=>'UNTERSCHIED_NUMMER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UNTERSCHIED_NUMMER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Unterschied<br> Nummer'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'STATIC'
,p_filter_lov_query=>'Ja,Nein'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8235552134549509301)
,p_name=>'KOMMENTAR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'KOMMENTAR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Kommentar'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(8289761065425830764)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>2000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8235552525756509305)
,p_name=>'ROW_OP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ROW_OP'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>140
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8235552611263509306)
,p_name=>'LINK_REGINDEX'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LINK_REGINDEX'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Link'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'CENTER'
,p_group_id=>wwv_flow_imp.id(8289761108028830765)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8289760515435830759)
,p_name=>'GETEX_LINK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'GETEX_LINK'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_LINK'
,p_heading=>'Link'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'CENTER'
,p_group_id=>wwv_flow_imp.id(8289761065425830764)
,p_use_group_for=>'BOTH'
,p_link_target=>'&GETEX_LINK.'
,p_link_text=>unistr('<span title="GETEX-Link \00F6ffnen" class="fa fa-globe"></span>')
,p_link_attributes=>'target="_blank"'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8289760675058830760)
,p_name=>'GETEX_VORSCHRIFT_NUMMER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'GETEX_VORSCHRIFT_NUMMER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Vorschrift Nummer'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(8289761065425830764)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8289760741536830761)
,p_name=>'GETEX_DOKUMENTENDATUM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'GETEX_DOKUMENTENDATUM'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Dokumentendatum'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_group_id=>wwv_flow_imp.id(8289761065425830764)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8289760877833830762)
,p_name=>'VORSCHRIFT_NUMMER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFT_NUMMER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Vorschrift Nummer'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(8289761108028830765)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8289760912552830763)
,p_name=>'DOKUMENTENDATUM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DOKUMENTENDATUM'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Dokumentendatum'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'RIGHT'
,p_group_id=>wwv_flow_imp.id(8289761108028830765)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(8235550301929509282)
,p_internal_uid=>11907762617828897517
,p_is_editable=>true
,p_edit_operations=>'u'
,p_edit_row_operations_column=>'ROW_OP'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>true
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>true
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(8261602680110824959)
,p_interactive_grid_id=>wwv_flow_imp.id(8235550301929509282)
,p_static_id=>'14587489'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(8261602841122824961)
,p_report_id=>wwv_flow_imp.id(8261602680110824959)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1091916425291257114)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>24
,p_column_id=>wwv_flow_imp.id(1091922499028257334)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>83
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(987649080924402181)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(988040950967483324)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>91
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(987648167826402168)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(988040898321483323)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>123
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3341169404985202100)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>21
,p_column_id=>wwv_flow_imp.id(3341160759532176237)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3341170292993202113)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>22
,p_column_id=>wwv_flow_imp.id(3341160884064176238)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3341171107760202120)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>23
,p_column_id=>wwv_flow_imp.id(3341160898587176239)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3341172970937202127)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>25
,p_column_id=>wwv_flow_imp.id(3341161145262176241)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3341173860272202129)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>26
,p_column_id=>wwv_flow_imp.id(3341161291280176242)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3341229868231146092)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(3341161833589176248)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3341658677105698294)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(3341161944039176249)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3342475409179822133)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>27
,p_column_id=>wwv_flow_imp.id(3341162314140176253)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3342476419501822143)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(3341162490496176254)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>72
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3342477407133822146)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(3341162499906176255)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3342478434232822149)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(3341162681603176256)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>76
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3342479407691822152)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(3341162742163176257)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>53
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(6802905843367104387)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(8235552611263509306)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>40
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(6802908766057102040)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(8235552525756509305)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(8261603304984824970)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(8235550397898509283)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>195
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(8261605085265824984)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(8235550521021509285)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>84
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(8289770147681834480)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(8289760515435830759)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>46
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(8289771026247834488)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(8289760675058830760)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(8289771965563834492)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(8289760741536830761)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>131
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(8289772894016834495)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(8289760877833830762)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(8289773733847834497)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(8289760912552830763)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>133
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(8300968943245449872)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(8235550948907509289)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>55
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(8301353309282941619)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>20
,p_column_id=>wwv_flow_imp.id(8235551092255509290)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>147
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(8450474707372995991)
,p_view_id=>wwv_flow_imp.id(8261602841122824961)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(8235552134549509301)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1068905648386951398)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(7626112359739086795)
,p_button_name=>'Actualise_MV'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Aktualisiere der Zwischenspeicherschicht '
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:2306:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1098475263547754105)
,p_name=>'P2300_NEUE_VORSCHRIFTID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(7626112359739086795)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1098461888058754086)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(7626112359739086795)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1098459891660754083)
,p_event_id=>wwv_flow_imp.id(1098461888058754086)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2300_NEUE_VORSCHRIFTID'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P2305_VORSCHRIFTID'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1098461362371754083)
,p_event_id=>wwv_flow_imp.id(1098461888058754086)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Die neue Vorschrift wurde angelegt.<br />',
unistr('<a href="https://apps1.web.audi.vwg/apexaudi-sp/apex-sp/f?p=REGINDEX:VORSCHRIFT::::25:P25_VORSCHRIFTID:&P2300_NEUE_VORSCHRIFTID." style="text-decoration: underline; text-decoration-style: dashed" target="_blank">Vorschrift \00F6ffnen</a>')))
,p_attribute_03=>'success'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P2300_NEUE_VORSCHRIFTID'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1098460866935754083)
,p_event_id=>wwv_flow_imp.id(1098461888058754086)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2300_NEUE_VORSCHRIFTID'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1098460360264754083)
,p_event_id=>wwv_flow_imp.id(1098461888058754086)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7626112359739086795)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1088390005424902441)
,p_name=>unistr('Dialog Closed Aenderungen zur Pr\00FCfung/\00DCbernahme Page')
,p_event_sequence=>20
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId && this.data.dialogPageId == 29'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1088389582174902428)
,p_event_id=>wwv_flow_imp.id(1088390005424902441)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8235550195497509281)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1098462284609754086)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(8235550195497509281)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Save Kommentar'
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'merge into t_getex_kommentar gk',
'using (',
'    select :KOMMENTAR as kommentar, :GETEXID as getex_key , :STATUS_DIFF as status_diff, :EINTRAG_FEHLERHAFT  as EINTRAG_FEHLERHAFT , ',
'    :BEARBEITER as Bearbeiter from dual',
') u',
'on (gk.getex_key = u.getex_key)',
'when matched then update set kommentar = :KOMMENTAR, kommentar_zeitpunkt = sysdate, status_diff = :STATUS_DIFF , ',
'                            eintrag_fehlerhaft =  :EINTRAG_FEHLERHAFT ,     bearbeiterid = :BEARBEITER',
'when not matched then insert (getex_key, kommentar, kommentar_zeitpunkt, status_diff, EINTRAG_FEHLERHAFT, BEARBEITERID )',
'values (u.getex_key, u.kommentar, sysdate, u.status_diff, u.EINTRAG_FEHLERHAFT, u.BEARBEITER);',
'',
'',
'',
'',
'-- Add Master update using primary key',
''))
,p_attribute_05=>'N'
,p_attribute_06=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2573750031289634149
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(988041558047483330)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(8235550195497509281)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save ATVW, Codebeamer'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_count NUMBER;',
'BEGIN',
'    SELECT COUNT(*) INTO v_count FROM t_vorschrift WHERE REGINDEXID = :GETEXID;',
'    ',
'    IF v_count > 0 THEN',
'        UPDATE t_vorschrift v',
'        SET ',
'            v.master = :MASTER_VALUE,',
'            v.ATVW_DOK = :ATVW_DOK,',
'            v.CODEBEAMER_DOK = :CODEBEAMER_DOK,',
'            v.letzte_aenderung_datum = SYSDATE,',
'            v.letzte_aenderung_benutzerid = :G_BENUTZERID',
'        WHERE v.REGINDEXID = :GETEXID;',
'        ',
'        -- debug(''SUCCESS'', ''Updated T_VORSCHRIFT for REGINDEXID: '' || :GETEXID);',
'    ELSE',
'        debug(''INFO'', ''REGINDEXID not in T_VORSCHRIFT, only updated T_GETEX_KOMMENTAR: '' || :GETEXID);',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2684170757851904905
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(988040805845483322)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'exec Abschlussbeladung'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- PCK_RI_GETEX_CTRL.pCreateImportJob;',
'null;',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1068905648386951398)
,p_internal_uid=>2684171510053904913
);
wwv_flow_imp.component_end;
end;
/
