prompt --application/pages/page_00471
begin
--   Manifest
--     PAGE: 00471
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>471
,p_name=>'Meilensteinvergleich'
,p_alias=>'MEILENSTEINVERGLEICH'
,p_page_mode=>'MODAL'
,p_step_title=>'Meilensteinvergleich'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function transferManualEntries() {',
'    const currentSearch = apex.item("P471_SEARCH_1").getValue();',
'    const currentMilestone = apex.item("P471_MILESTONE_1").getValue();',
'    const comparisonSearch = apex.item("P471_SEARCH_2").getValue();',
'    const comparisonMilestone = apex.item("P471_MILESTONE_2").getValue();',
'    ',
'    if (!currentSearch || !currentMilestone || !comparisonSearch || !comparisonMilestone) {',
'        apex.message.showErrors([{',
'            type: "error",',
'            location: "page",',
unistr('            message: "Bitte w\00E4hlen Sie zuerst beide Suchen und Meilensteine aus."'),
'        }]);',
'        return;',
'    }',
'',
'    // SAME-SEARCH ONLY: Comment out this block to enable cross-search transfers',
'    if (currentSearch !== comparisonSearch) {',
'        apex.message.showErrors([{',
'            type: "error", ',
'            location: "page",',
unistr('            message: "Manuelle Eintr\00E4ge k\00F6nnen nur zwischen Meilensteinen derselben Suche \00FCbertragen werden."'),
'        }]);',
'        return;',
'    }',
'    ',
'    apex.server.process("TRANSFER_MANUAL_ENTRIES", {',
'        x01: currentSearch,      // Target search',
'        x02: currentMilestone,   // Target milestone',
'        x03: comparisonMilestone, // Source milestone',
'        x04: comparisonSearch // Uncomment for cross-search support',
'    }, {',
'        dataType: "json",',
'        success: function(data) {',
'            if (data.status === "success") {',
'                apex.message.showPageSuccess(',
unistr('                    "Manuelle Eintr\00E4ge erfolgreich \00FCbertragen. " +'),
'                    (data.conflicts > 0 ? ',
unistr('                        `${data.conflicts} Konflikte erkannt, die manuell gel\00F6st werden m\00FCssen.` : "")'),
'                );',
'                apex.region("regulation-comparison").refresh();',
'            } else {',
'                apex.message.showErrors([{',
'                    type: "error",',
'                    location: "page",',
unistr('                    message: data.message || "Fehler beim \00DCbertragen der manuellen Eintr\00E4ge."'),
'                }]);',
'            }',
'        },',
'        error: function(xhr, status, error) {',
'            apex.message.showErrors([{',
'                type: "error",',
'                location: "page",',
unistr('                message: "Fehler beim \00DCbertragen: " + error'),
'            }]);',
'        }',
'    });',
'}',
'',
'// Cross-search validation and indicator',
'function validateCrossSearchComparison() {',
'    const search1 = apex.item(''P471_SEARCH_1'').getValue();',
'    const search2 = apex.item(''P471_SEARCH_2'').getValue();',
'    const milestone1 = apex.item(''P471_MILESTONE_1'').getValue();',
'    const milestone2 = apex.item(''P471_MILESTONE_2'').getValue();',
'    ',
'    // Remove existing indicator',
'    $(''.cross-search-indicator'').remove();',
'    ',
'    if (search1 && search2 && milestone1 && milestone2) {',
'        apex.server.process(''VALIDATE_CROSS_SEARCH'', {',
'            x01: search1,',
'            x02: milestone1,',
'            x03: search2,',
'            x04: milestone2',
'        }, {',
'            success: function(data) {',
'                showCrossSearchIndicator(data);',
'            },',
'            error: function(xhr, status, error) {',
'                console.error(''Cross-search validation error:'', error);',
'            },',
'            dataType: ''json''',
'        });',
'    }',
'}',
'',
'function showCrossSearchIndicator(data) {',
'    const indicator = document.createElement(''div'');',
'    indicator.className = ''cross-search-indicator'';',
'    indicator.style.cssText = ''padding: 12px; margin: 10px 0; border-radius: 6px; font-weight: bold; border-left: 4px solid;'';',
'    ',
'    let message = '''';',
'    let bgColor = '''';',
'    let borderColor = '''';',
'    ',
'    if (data.same_search === ''Y'') {',
'        message = `<i class="fa fa-info-circle"></i> <strong>Interne Suche:</strong> Vergleich innerhalb derselben Suche "${data.search1_name}"`;',
'        bgColor = ''#d4edda'';',
'        borderColor = ''#28a745'';',
'    } else {',
'        message = `<i class="fa fa-exchange"></i> <strong>Cross-Search Vergleich:</strong><br>`;',
'        message += `Suche 1: "${data.search1_name}"<br>`;',
'        message += `Suche 2: "${data.search2_name}"<br>`;',
'        ',
'        if (data.has_overlap === ''Y'') {',
unistr('            message += `<small><i class="fa fa-check-circle"></i> ${data.country_overlap} gemeinsame L\00E4nder, ${data.theme_overlap} gemeinsame Themen</small>`;'),
'            bgColor = ''#fff3cd'';',
'            borderColor = ''#ffc107'';',
'        } else {',
unistr('            message += `<small><i class="fa fa-exclamation-triangle"></i> Keine gemeinsamen L\00E4nder oder Themen - Vergleich kann eingeschr\00E4nkt sein</small>`;'),
'            bgColor = ''#f8d7da'';',
'            borderColor = ''#dc3545'';',
'        }',
'    }',
'    ',
'    indicator.innerHTML = message;',
'    indicator.style.backgroundColor = bgColor;',
'    indicator.style.borderColor = borderColor;',
'    ',
'    // Insert indicator before comparison region',
'    const comparisonRegion = document.querySelector(''#regulation-comparison'');',
'    if (comparisonRegion) {',
'        comparisonRegion.parentNode.insertBefore(indicator, comparisonRegion);',
'    }',
'}',
'',
'',
'',
'/*',
'',
'function updateColumnHeaders() {',
'    const search1 = apex.item("P471_SEARCH_1").getValue();',
'    const milestone1 = apex.item("P471_MILESTONE_1").getValue();',
'    const search2 = apex.item("P471_SEARCH_2").getValue();',
'    const milestone2 = apex.item("P471_MILESTONE_2").getValue();',
'    ',
'    if (search1 && milestone1 && search2 && milestone2) {',
'        // Get search names via AJAX call instead of relying on select options',
'        apex.server.process(''GET_SEARCH_NAMES'', {',
'            x01: search1,',
'            x02: search2',
'        }, {',
'            success: function(data) {',
'                setTimeout(function() {',
'                    updateHeadersWithNames(data.search1_name, data.search2_name);',
'                }, 500);',
'            },',
'            error: function() {',
'                // Fallback to IDs if AJAX fails',
'                setTimeout(function() {',
'                    updateHeadersWithNames(''Suche '' + search1, ''Suche '' + search2);',
'                }, 500);',
'            },',
'            dataType: "json"',
'        });',
'    }',
'    ',
'    function updateHeadersWithNames(search1Name, search2Name) {',
'        // Update main headers',
'        $(''#rMasterDataReport .a-IRR-headerLink'').each(function() {',
'            const $link = $(this);',
'            const headerText = $link.text().trim();',
'            ',
'            if (headerText === ''Suche 1'' || headerText.includes(''Suche ID '' + search1)) {',
'                $link.text(`${search1Name} (M${milestone1})`);',
'            } else if (headerText === ''Suche 2'' || headerText.includes(''Suche ID '' + search2)) {',
'                $link.text(`${search2Name} (M${milestone2})`);',
'            }',
'        });',
'        ',
'        // Update sticky headers',
'        $(''#rMasterDataReport .t-fht-thead .a-IRR-headerLink'').each(function() {',
'            const $link = $(this);',
'            const headerText = $link.text().trim();',
'            ',
'            if (headerText === ''Suche 1'' || headerText.includes(''Suche ID '' + search1)) {',
'                $link.text(`${search1Name} (M${milestone1})`);',
'            } else if (headerText === ''Suche 2'' || headerText.includes(''Suche ID '' + search2)) {',
'                $link.text(`${search2Name} (M${milestone2})`);',
'            }',
'        });',
'    }',
'}',
'*/',
'',
'function updateColumnHeaders() {',
'    const search1 = apex.item("P471_SEARCH_1").getValue();',
'    const milestone1 = apex.item("P471_MILESTONE_1").getValue();',
'    const search2 = apex.item("P471_SEARCH_2").getValue();',
'    const milestone2 = apex.item("P471_MILESTONE_2").getValue();',
'    ',
'    if (search1 && milestone1 && search2 && milestone2) {',
'        // Get search names via AJAX call instead of relying on select options',
'        apex.server.process(''GET_SEARCH_NAMES'', {',
'            x01: search1,',
'            x02: search2',
'        }, {',
'            success: function(data) {',
'                setTimeout(function() {',
'                    updateHeadersWithNames(data.search1_name, data.search2_name);',
'                }, 500);',
'            },',
'            error: function() {',
'                // Fallback to IDs if AJAX fails',
'                setTimeout(function() {',
'                    updateHeadersWithNames(''Suche '' + search1, ''Suche '' + search2);',
'                }, 500);',
'            },',
'            dataType: "json"',
'        });',
'    }',
'    ',
'   function updateHeadersWithNames(search1Name, search2Name) {',
'    // Update main headers',
'    $(''#rMasterDataReport .a-IRR-headerLink'').each(function() {',
'        const $link = $(this);',
'        const headerText = $link.text().trim();',
'        ',
'        if (headerText === ''Suche 1'' || headerText.includes(''Suche ID '' + search1)) {',
'            $link.text(`${search1Name} (M2)`);  // Changed: Aktueller = M2 (newer)',
'        } else if (headerText === ''Suche 2'' || headerText.includes(''Suche ID '' + search2)) {',
'            $link.text(`${search2Name} (M-1)`);  // Changed: Vergleichs = M-1 (older)',
'        }',
'    });',
'    ',
'    // Update sticky headers',
'    $(''#rMasterDataReport .t-fht-thead .a-IRR-headerLink'').each(function() {',
'        const $link = $(this);',
'        const headerText = $link.text().trim();',
'        ',
'        if (headerText === ''Suche 1'' || headerText.includes(''Suche ID '' + search1)) {',
'            $link.text(`${search1Name} (M2)`);  // Changed: Aktueller = M2 (newer)',
'        } else if (headerText === ''Suche 2'' || headerText.includes(''Suche ID '' + search2)) {',
'            $link.text(`${search2Name} (M-1)`);  // Changed: Vergleichs = M-1 (older)',
'        }',
'    });',
'}',
'}',
'',
'',
'',
'',
'',
'',
'',
'// Function to apply country change highlighting',
'function applyCountryChangeHighlighting() {',
'    setTimeout(function() {',
'        console.log(''Applying country change highlighting...'');',
'        ',
'        $(''#regulation-comparison .a-IRR-table tbody tr'').each(function() {',
'            var $row = $(this);',
'            ',
'            // Replace "AL" with your actual column identifier',
'            var cssClassCell = $row.find(''td[headers="AL"]'');',
'            ',
'            if (cssClassCell.length > 0) {',
'                var cssClass = cssClassCell.text().trim();',
'                console.log(''Found CSS class:'', cssClass);',
'                ',
'                if (cssClass && cssClass !== '''' && cssClass !== ''-'') {',
'                    $row.addClass(cssClass);',
'                    console.log(''Applied class'', cssClass, ''to row'');',
'                    cssClassCell.hide();',
'                }',
'            }',
'        });',
'    }, 800);',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'// Apply highlighting after page load and region refresh',
'$(document).ready(function() {',
'    applyCountryChangeHighlighting();',
'    // validateCrossSearchComparison();',
'    ',
'    // Validate when search or milestone selections change',
'    $(''#P471_SEARCH_1, #P471_SEARCH_2, #P471_MILESTONE_1, #P471_MILESTONE_2'').on(''change'', function() {',
'        setTimeout(validateCrossSearchComparison, 300);',
'    });',
'});',
'',
'// Re-apply after region refresh',
'$(document).on(''apexafterrefresh'', ''#regulation-comparison'', function() {',
'    applyCountryChangeHighlighting();',
'});',
'',
'',
'',
'// Hide reports on page load',
'$(document).ready(function() {',
'    $(''#rMasterDataReport'').hide();',
'    $(''#regulation-comparison'').hide();',
'    // $(''.cross-search-indicator'').hide();',
'    $(''#lStatusLegend'').hide();',
'    $(''#lWarningLegend'').hide();',
'    $(''#lEvaluationLegend'').hide();',
'    $(''#lMassUpdateLegend'').hide();',
'    $(''#lEntryTypeLegend'').hide();',
'    ',
'',
'});',
'',
'',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Country highlighting */',
'.country-added {',
'    background-color: #fff3cd !important;',
'    border-left: 3px solid #ffc107 !important;',
'}',
'',
'.country-removed {',
'    background-color: #f8d7da !important; ',
'    border-left: 3px solid #dc3545 !important;',
'}',
'',
'/* Duplicate warning styling */',
'.fa-exclamation-triangle[title*="doppelt"] {',
'    animation: pulse-warning 2s infinite;',
'}',
'',
'@keyframes pulse-warning {',
'    0% { opacity: 1; }',
'    50% { opacity: 0.6; }',
'    100% { opacity: 1; }',
'}',
'',
'',
'',
'/*',
'',
'=== Country change highlighting ',
'',
'*/',
'',
'/* Country change highlighting */',
'.country-row-added {',
'    background-color: #d4edda !important;',
'    border-left: 4px solid #28a745 !important;',
'}',
'',
'.country-row-removed {',
'    background-color: #f8d7da !important;',
'    border-left: 4px solid #dc3545 !important;',
'}',
'',
'.country-row-modified {',
'    background-color: #fff3cd !important;',
'    border-left: 4px solid #ffc107 !important;',
'}',
'',
'/* Hover effects */',
'.country-row-added:hover {',
'    background-color: #c3e6cb !important;',
'}',
'',
'.country-row-removed:hover {',
'    background-color: #f5c6cb !important;',
'}',
'',
'.country-row-modified:hover {',
'    background-color: #ffeaa7 !important;',
'}',
'',
'/*',
'',
'=== Country change highlighting ',
'',
'*/',
'',
'',
'',
'/* Hide reports and legends initially */',
'#rMasterDataReport,',
'#regulation-comparison,',
'#lStatusLegend,',
'#lWarningLegend,',
'#lEvaluationLegend,',
'#lMassUpdateLegend,',
'#lEntryTypeLegend {',
'    display: none;',
'}',
'',
'',
'',
'/* --- CSS to optimize column widths using Static IDs for report R45756756756575 --- */',
'',
'',
'/* Criticality change arrows */',
'.fa-arrow-up {',
'    animation: bounce-up 1.5s ease-in-out infinite;',
'}',
'',
'.fa-arrow-down {',
'    animation: bounce-down 1.5s ease-in-out infinite;',
'}',
'',
'.fa-trending-up {',
'    animation: pulse-trend 2s ease-in-out infinite;',
'}',
'',
'.fa-trending-down {',
'    animation: pulse-trend 2s ease-in-out infinite;',
'}',
'',
'/* Animations for criticality indicators */',
'@keyframes bounce-up {',
'    0%, 20%, 50%, 80%, 100% {',
'        transform: translateY(0);',
'    }',
'    40% {',
'        transform: translateY(-3px);',
'    }',
'    60% {',
'        transform: translateY(-2px);',
'    }',
'}',
'',
'@keyframes bounce-down {',
'    0%, 20%, 50%, 80%, 100% {',
'        transform: translateY(0);',
'    }',
'    40% {',
'        transform: translateY(3px);',
'    }',
'    60% {',
'        transform: translateY(2px);',
'    }',
'}',
'',
'@keyframes pulse-trend {',
'    0% {',
'        opacity: 1;',
'    }',
'    50% {',
'        opacity: 0.6;',
'    }',
'    100% {',
'        opacity: 1;',
'    }',
'}',
'',
'/* Hover effects for criticality indicators */',
'.fa-arrow-up:hover,',
'.fa-arrow-down:hover,',
'.fa-minus:hover,',
'.fa-plus-circle:hover,',
'.fa-trending-up:hover,',
'.fa-trending-down:hover {',
'    transform: scale(1.2);',
'    transition: transform 0.2s ease;',
'}',
'',
'',
'/* Criticality Change Arrows*/',
'',
'',
'',
'',
'',
'/* Make text and icons WHITE on row hover for specific columns */',
'',
unistr('/* Aktuelle Auswahl and Ausgew\00E4hlte Vorschrift (M-1) columns - icons and text */'),
'tr:hover span[style*="color: #27ae60"],     /* ja spans */',
'tr:hover span[style*="color: #e74c3c"],     /* nein spans */',
'tr:hover span[style*="color: #666"],        /* nicht bewertet spans */',
'tr:hover span[style*="color: #999"] {       /* dash spans */',
'    color: #ffffff !important;',
'}',
'',
'tr:hover span[style*="color: #27ae60"] i,   /* ja icons */',
'tr:hover span[style*="color: #e74c3c"] i,   /* nein icons */',
'tr:hover span[style*="color: #666"] i,      /* nicht bewertet icons */',
'tr:hover span[style*="color: #999"] i {     /* dash icons */',
'    color: #ffffff !important;',
'}',
'',
'/* Massenupdate Status column */',
'tr:hover .fa-ban,',
'tr:hover .fa-check {',
'    color: #ffffff !important;',
'}',
'',
'/* Eintrag Typ column - icons and text */',
'tr:hover .fa-user-plus,',
'tr:hover .fa-cog {',
'    color: #ffffff !important;',
'}',
'',
'tr:hover span[style*="color: #bb0a31"],     /* Manual entry spans */',
'tr:hover span[style*="color: #666"] {       /* Auto entry spans */',
'    color: #ffffff !important;',
'}',
'',
unistr('/* Kritikalit\00E4t (Vergleich) column - arrows and other icons */'),
'tr:hover .fa-arrow-up,',
'tr:hover .fa-arrow-down,',
'tr:hover .fa-check-circle,',
'tr:hover .fa-plus-circle {',
'    color: #ffffff !important;',
'}',
'',
'/* Duplikat Warnung column */',
'tr:hover .fa-exclamation-triangle {',
'    color: #ffffff !important;',
'}',
'',
'/* Status column icons */',
'tr:hover .fa-minus-circle,',
'tr:hover .fa-edit,',
'tr:hover .fa-exchange {',
'    color: #ffffff !important;',
'}',
'',
'/* Change indicator column */',
'tr:hover .fa-plus-circle,',
'tr:hover .fa-minus-circle,',
'tr:hover .fa-exclamation-circle {',
'    color: #ffffff !important;',
'}',
'',
'/* Keep Change Summary column BLACK on row hover */',
'tr:hover span[style*="background-color: #FFFF00"],     /* Yellow background spans */',
'tr:hover span[style*="background-color: #f5f5f5"] {    /* Gray background spans */',
'    color: #000000 !important;',
'}',
'',
'',
'',
'/* Status column - make text white on row hover */',
unistr('tr:hover span[style*="color: #3498db"],     /* Bewertung ge\00E4ndert spans */'),
unistr('tr:hover span[style*="color: #95a5a6"],     /* Unver\00E4ndert spans */'),
unistr('tr:hover span[style*="color: #f39c12"],     /* Text ge\00E4ndert spans */'),
unistr('tr:hover span[style*="color: #e74c3c"],     /* Kritikalit\00E4t spans */'),
'tr:hover span[style*="color: #27ae60"] {    /* Neu spans */',
'    color: #ffffff !important;',
'}',
'',
'',
'',
'/* Legend button - Info Blue styling */',
'',
'#B577439449482037513 {',
'    background-color: #2196F3 !important;',
'    border-color: #1976D2 !important;',
'    color: #ffffff !important;',
'    transition: all 0.3s ease;',
'}'))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(965945069527377228)
,p_plug_name=>'Stammdaten-Vergleichsergebnisse LIST AGG'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>120
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ',
'sop_comparison AS (',
'    SELECT ',
'        ''SOP'' as data_type,',
'        1 as sort_order,',
'        TO_CLOB(s1.datum_sop) as value_new,',
'        TO_CLOB(s2.datum_sop) as value_old,',
'        CASE ',
unistr('            WHEN NVL(s1.datum_sop, ''NULL'') != NVL(s2.datum_sop, ''NULL'') THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN NVL(s1.datum_sop, ''NULL'') != NVL(s2.datum_sop, ''NULL'') THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT jt.datum_sop',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            datum_sop VARCHAR2(20) PATH ''$.DATUM_SOP''',
'        )) jt',
'        WHERE tsj.sucheid = :P471_SEARCH_1',
'        AND jt.meilenstein = :P471_MILESTONE_1',
'    ) s1',
'    CROSS JOIN (',
'        SELECT jt.datum_sop',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            datum_sop VARCHAR2(20) PATH ''$.DATUM_SOP''',
'        )) jt',
'        WHERE tsj.sucheid = :P471_SEARCH_2',
'        AND jt.meilenstein = :P471_MILESTONE_2',
'    ) s2',
'),',
'eop_comparison AS (',
'    SELECT ',
'        ''EOP'' as data_type,',
'        2 as sort_order,',
'        TO_CLOB(s1.datum_eop) as value_new,',
'        TO_CLOB(s2.datum_eop) as value_old,',
'        CASE ',
unistr('            WHEN NVL(s1.datum_eop, ''NULL'') != NVL(s2.datum_eop, ''NULL'') THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN NVL(s1.datum_eop, ''NULL'') != NVL(s2.datum_eop, ''NULL'') THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT jt.datum_eop',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            datum_eop VARCHAR2(20) PATH ''$.DATUM_EOP''',
'        )) jt',
'        WHERE tsj.sucheid = :P471_SEARCH_1',
'        AND jt.meilenstein = :P471_MILESTONE_1',
'    ) s1',
'    CROSS JOIN (',
'        SELECT jt.datum_eop',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            datum_eop VARCHAR2(20) PATH ''$.DATUM_EOP''',
'        )) jt',
'        WHERE tsj.sucheid = :P471_SEARCH_2',
'        AND jt.meilenstein = :P471_MILESTONE_2',
'    ) s2',
'),',
'search_type_comparison AS (',
'    SELECT ',
'        ''Suchtyp'' as data_type,',
'        3 as sort_order,',
'        TO_CLOB(CASE s1.suchtyp ',
'            WHEN ''0'' THEN ''Neue Typen''',
'            WHEN ''10'' THEN ''Bestehender Typ''',
'            ELSE s1.suchtyp',
'        END) as value_new,',
'        TO_CLOB(CASE s2.suchtyp ',
'            WHEN ''0'' THEN ''Neue Typen''',
'            WHEN ''10'' THEN ''Bestehender Typ''',
'            ELSE s2.suchtyp',
'        END) as value_old,',
'        CASE ',
unistr('            WHEN NVL(s1.suchtyp, ''NULL'') != NVL(s2.suchtyp, ''NULL'') THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN NVL(s1.suchtyp, ''NULL'') != NVL(s2.suchtyp, ''NULL'') THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT jt.suchtyp',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            suchtyp VARCHAR2(20) PATH ''$.SUCHTYP''',
'        )) jt',
'        WHERE tsj.sucheid = :P471_SEARCH_1',
'        AND jt.meilenstein = :P471_MILESTONE_1',
'    ) s1',
'    CROSS JOIN (',
'        SELECT jt.suchtyp',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            suchtyp VARCHAR2(20) PATH ''$.SUCHTYP''',
'        )) jt',
'        WHERE tsj.sucheid = :P471_SEARCH_2',
'        AND jt.meilenstein = :P471_MILESTONE_2',
'    ) s2',
'),',
'countries_comparison AS (',
'    SELECT ',
unistr('        ''L\00E4nder/M\00E4rkte'' as data_type,'),
'        4 as sort_order,',
'        c1.countries_list as value_new,',
'        c2.countries_list as value_old,',
'        CASE ',
unistr('            WHEN DBMS_LOB.COMPARE(NVL(c1.countries_list, TO_CLOB(''NULL'')), NVL(c2.countries_list, TO_CLOB(''NULL''))) != 0 THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN DBMS_LOB.COMPARE(NVL(c1.countries_list, TO_CLOB(''NULL'')), NVL(c2.countries_list, TO_CLOB(''NULL''))) != 0 THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, l.b_nummer || ''-'' || l.land, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY l.b_nummer).GETCLOBVAL(), ''; '') as countries_list',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            laender VARCHAR2(4000) PATH ''$.LAENDER''',
'        )) jt,',
'        TABLE(apex_string.split(jt.laender, '':'')) countries,',
'        t_land l',
'        WHERE tsj.sucheid = :P471_SEARCH_1',
'        AND jt.meilenstein = :P471_MILESTONE_1',
'        AND l.landid = TO_NUMBER(countries.column_value)',
'    ) c1',
'    CROSS JOIN (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, l.b_nummer || ''-'' || l.land, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY l.b_nummer).GETCLOBVAL(), ''; '') as countries_list',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            laender VARCHAR2(4000) PATH ''$.LAENDER''',
'        )) jt,',
'        TABLE(apex_string.split(jt.laender, '':'')) countries,',
'        t_land l',
'        WHERE tsj.sucheid = :P471_SEARCH_2',
'        AND jt.meilenstein = :P471_MILESTONE_2',
'        AND l.landid = TO_NUMBER(countries.column_value)',
'    ) c2',
'),',
'themes_comparison AS (',
'    SELECT ',
'        ''Themabezeichnung'' as data_type,',
'        5 as sort_order,',
'        t1.themes_list as value_new,',
'        t2.themes_list as value_old,',
'        CASE ',
unistr('            WHEN DBMS_LOB.COMPARE(NVL(t1.themes_list, TO_CLOB(''NULL'')), NVL(t2.themes_list, TO_CLOB(''NULL''))) != 0 THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN DBMS_LOB.COMPARE(NVL(t1.themes_list, TO_CLOB(''NULL'')), NVL(t2.themes_list, TO_CLOB(''NULL''))) != 0 THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, t.bezeichnung, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY t.bezeichnung).GETCLOBVAL(), ''; '') as themes_list',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            themen VARCHAR2(4000) PATH ''$.THEMEN''',
'        )) jt,',
'        TABLE(apex_string.split(jt.themen, '':'')) themes,',
'        t_thema t',
'        WHERE tsj.sucheid = :P471_SEARCH_1',
'        AND jt.meilenstein = :P471_MILESTONE_1',
'        AND t.themaid = TO_NUMBER(themes.column_value)',
'    ) t1',
'    CROSS JOIN (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, t.bezeichnung, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY t.bezeichnung).GETCLOBVAL(), ''; '') as themes_list',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            themen VARCHAR2(4000) PATH ''$.THEMEN''',
'        )) jt,',
'        TABLE(apex_string.split(jt.themen, '':'')) themes,',
'        t_thema t',
'        WHERE tsj.sucheid = :P471_SEARCH_2',
'        AND jt.meilenstein = :P471_MILESTONE_2',
'        AND t.themaid = TO_NUMBER(themes.column_value)',
'    ) t2',
'),',
'kritikalitaet_comparison AS (',
'    SELECT ',
unistr('        ''Kritikalit\00E4t'' as data_type,'),
'        6 as sort_order,',
'        k1.kritikalitaet as value_new,',
'        k2.kritikalitaet as value_old,',
'        CASE ',
unistr('            WHEN DBMS_LOB.COMPARE(NVL(k1.kritikalitaet, TO_CLOB(''NULL'')), NVL(k2.kritikalitaet, TO_CLOB(''NULL''))) != 0 THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN DBMS_LOB.COMPARE(NVL(k1.kritikalitaet, TO_CLOB(''NULL'')), NVL(k2.kritikalitaet, TO_CLOB(''NULL''))) != 0 THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, mat.ausgabe_text, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY mat.ausgabe_text).GETCLOBVAL(), ''; '') as kritikalitaet',
'        FROM (',
'            SELECT DISTINCT mat.ausgabe_text',
'            FROM t_ms_suchergebniss ms',
'            LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'            LEFT JOIN t_ms_parameter_ref_ausgabe pra ON p.ms_parameterid = pra.ms_parameterid',
'            LEFT JOIN t_ms_ausgabe_text mat ON pra.ms_ausgabe_textid = mat.ms_ausgabe_textid',
'            WHERE ms.sucheid = :P471_SEARCH_1 AND ms.meilenstein = :P471_MILESTONE_1',
'            AND p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1',
'        ) mat',
'    ) k1',
'    CROSS JOIN (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, mat.ausgabe_text, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY mat.ausgabe_text).GETCLOBVAL(), ''; '') as kritikalitaet',
'        FROM (',
'            SELECT DISTINCT mat.ausgabe_text',
'            FROM t_ms_suchergebniss ms',
'            LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'            LEFT JOIN t_ms_parameter_ref_ausgabe pra ON p.ms_parameterid = pra.ms_parameterid',
'            LEFT JOIN t_ms_ausgabe_text mat ON pra.ms_ausgabe_textid = mat.ms_ausgabe_textid',
'            WHERE ms.sucheid = :P471_SEARCH_2 AND ms.meilenstein = :P471_MILESTONE_2',
'            AND p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1',
'        ) mat',
'    ) k2',
'),',
'publisher_comparison AS (',
'    SELECT ',
'        ''Publisher'' as data_type,',
'        7 as sort_order,',
'        p1.publishers as value_new,',
'        p2.publishers as value_old,',
'        CASE ',
unistr('            WHEN DBMS_LOB.COMPARE(NVL(p1.publishers, TO_CLOB(''NULL'')), NVL(p2.publishers, TO_CLOB(''NULL''))) != 0 THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN DBMS_LOB.COMPARE(NVL(p1.publishers, TO_CLOB(''NULL'')), NVL(p2.publishers, TO_CLOB(''NULL''))) != 0 THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, v.publisher, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY v.publisher).GETCLOBVAL(), ''; '') as publishers',
'        FROM (',
'            SELECT DISTINCT v.publisher',
'            FROM t_ms_suchergebniss ms',
'            LEFT JOIN t_vorschrift v ON ms.vorschriftid = v.vorschriftid',
'            LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'            WHERE ms.sucheid = :P471_SEARCH_1 AND ms.meilenstein = :P471_MILESTONE_1',
'            AND p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1',
'',
'        ) v',
'    ) p1',
'    CROSS JOIN (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, v.publisher, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY v.publisher).GETCLOBVAL(), ''; '') as publishers',
'        FROM (',
'            SELECT DISTINCT v.publisher',
'            FROM t_ms_suchergebniss ms',
'            LEFT JOIN t_vorschrift v ON ms.vorschriftid = v.vorschriftid',
'            LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'            WHERE ms.sucheid = :P471_SEARCH_2 AND ms.meilenstein = :P471_MILESTONE_2',
'            AND p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1',
'',
'        ) v',
'    ) p2',
'),',
'lrsa_comparison AS (',
'    SELECT ',
'        ''LRSA'' as data_type,',
'        8 as sort_order,',
'        l1.lrsa_values as value_new,',
'        l2.lrsa_values as value_old,',
'        CASE ',
unistr('            WHEN DBMS_LOB.COMPARE(NVL(l1.lrsa_values, TO_CLOB(''NULL'')), NVL(l2.lrsa_values, TO_CLOB(''NULL''))) != 0 THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN DBMS_LOB.COMPARE(NVL(l1.lrsa_values, TO_CLOB(''NULL'')), NVL(l2.lrsa_values, TO_CLOB(''NULL''))) != 0 THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, l.lrsa_nummer || '' - '' || l.bezeichnung, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY l.bezeichnung).GETCLOBVAL(), ''; '') as lrsa_values',
'        FROM (',
'            SELECT DISTINCT l.lrsa_nummer, l.bezeichnung',
'            FROM t_ms_suchergebniss ms',
'            LEFT JOIN t_vorschrift_ref_thema vrt ON ms.vorschriftid = vrt.vorschriftid',
'            LEFT JOIN t_thema_ref_lrsa ref ON vrt.themaid = ref.themaid',
'            LEFT JOIN t_lrsa l ON l.lrsa_id = ref.lrsaid',
'            LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'            WHERE ms.sucheid = :P471_SEARCH_1 AND ms.meilenstein = :P471_MILESTONE_1',
'            AND vrt.geloescht = 0',
'            AND p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1',
'        ) l',
'    ) l1',
'    CROSS JOIN (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, l.lrsa_nummer || '' - '' || l.bezeichnung, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY l.bezeichnung).GETCLOBVAL(), ''; '') as lrsa_values',
'        FROM (',
'            SELECT DISTINCT l.lrsa_nummer, l.bezeichnung',
'            FROM t_ms_suchergebniss ms',
'            LEFT JOIN t_vorschrift_ref_thema vrt ON ms.vorschriftid = vrt.vorschriftid',
'            LEFT JOIN t_thema_ref_lrsa ref ON vrt.themaid = ref.themaid',
'            LEFT JOIN t_lrsa l ON l.lrsa_id = ref.lrsaid',
'            LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'            WHERE ms.sucheid = :P471_SEARCH_2 AND ms.meilenstein = :P471_MILESTONE_2',
'            AND vrt.geloescht = 0',
'            AND p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1',
'',
'        ) l',
'    ) l2',
'),',
'evaluation_comparison AS (',
'    SELECT ',
'        ''ET Verwendung'' as data_type,',
'        9 as sort_order,',
'        e1.evaluations as value_new,',
'        e2.evaluations as value_old,',
'        CASE ',
unistr('            WHEN DBMS_LOB.COMPARE(NVL(e1.evaluations, TO_CLOB(''NULL'')), NVL(e2.evaluations, TO_CLOB(''NULL''))) != 0 THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN DBMS_LOB.COMPARE(NVL(e1.evaluations, TO_CLOB(''NULL'')), NVL(e2.evaluations, TO_CLOB(''NULL''))) != 0 THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, bew.et_verwendung, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY bew.et_verwendung).GETCLOBVAL(), ''; '') as evaluations',
'        FROM (',
'            SELECT DISTINCT bew.et_verwendung',
'            FROM t_ms_bewertung bew',
'            WHERE bew.sucheid = :P471_SEARCH_1 AND bew.meilenstein = :P471_MILESTONE_1',
'            AND (bew.benutzerid = :G_BENUTZERID ',
'                 OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                            WHERE brr.benutzerid = :G_BENUTZERID ',
'                            AND brr.rolleid = 1001))',
'        ) bew',
'    ) e1',
'    CROSS JOIN (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, bew.et_verwendung, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY bew.et_verwendung).GETCLOBVAL(), ''; '') as evaluations',
'        FROM (',
'            SELECT DISTINCT bew.et_verwendung',
'            FROM t_ms_bewertung bew',
'            WHERE bew.sucheid = :P471_SEARCH_2 AND bew.meilenstein = :P471_MILESTONE_2',
'            AND (bew.benutzerid = :G_BENUTZERID ',
'                 OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                            WHERE brr.benutzerid = :G_BENUTZERID ',
'                            AND brr.rolleid = 1001))',
'        ) bew',
'    ) e2',
'),',
'et_kommentar_comparison AS (',
'    SELECT ',
'        ''ET Kommentar'' as data_type,',
'        10 as sort_order,',
'        TO_CLOB(k1.kommentare) as value_new,',
'        TO_CLOB(k2.kommentare) as value_old,',
'        CASE ',
unistr('            WHEN NVL(k1.kommentare, ''NULL'') != NVL(k2.kommentare, ''NULL'') THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN NVL(k1.kommentare, ''NULL'') != NVL(k2.kommentare, ''NULL'') THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT COUNT(DISTINCT bew.et_kommentar) || '' eindeutige Kommentare'' as kommentare',
'        FROM t_ms_bewertung bew',
'        WHERE bew.sucheid = :P471_SEARCH_1 AND bew.meilenstein = :P471_MILESTONE_1',
'        AND bew.et_kommentar IS NOT NULL',
'        AND (bew.benutzerid = :G_BENUTZERID ',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001))',
'    ) k1',
'    CROSS JOIN (',
'        SELECT COUNT(DISTINCT bew.et_kommentar) || '' eindeutige Kommentare'' as kommentare',
'        FROM t_ms_bewertung bew',
'        WHERE bew.sucheid = :P471_SEARCH_2 AND bew.meilenstein = :P471_MILESTONE_2',
'        AND bew.et_kommentar IS NOT NULL',
'        AND (bew.benutzerid = :G_BENUTZERID ',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001))',
'    ) k2',
'),',
'all_comparisons AS (',
'    SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM sop_comparison',
'    UNION ALL SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM eop_comparison',
'    UNION ALL SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM search_type_comparison',
'    UNION ALL SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM countries_comparison',
'    UNION ALL SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM themes_comparison',
'    UNION ALL SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM kritikalitaet_comparison',
'    UNION ALL SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM publisher_comparison',
'    UNION ALL SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM lrsa_comparison',
'    UNION ALL SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM evaluation_comparison',
'    UNION ALL SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM et_kommentar_comparison',
')',
'',
'SELECT ',
'    data_type as "Data Type",',
'    status_icon || '' '' || change_status as "Status",',
'    CASE ',
'        WHEN DBMS_LOB.GETLENGTH(value_old) > 2000 THEN SUBSTR(DBMS_LOB.SUBSTR(value_old, 2000, 1), 1, 1997) || ''...''',
'        ELSE NVL(DBMS_LOB.SUBSTR(value_old, 2000, 1), ''-'')',
'    END as "Suche 2",',
'    CASE ',
'        WHEN DBMS_LOB.GETLENGTH(value_new) > 2000 THEN SUBSTR(DBMS_LOB.SUBSTR(value_new, 2000, 1), 1, 1997) || ''...''',
'        ELSE NVL(DBMS_LOB.SUBSTR(value_new, 2000, 1), ''-'')',
'    END as "Suche 1", ',
'    CASE ',
unistr('        WHEN change_status = ''Ge\00E4ndert'' THEN'),
'            ''<span style="background-color: #FFFF00; color: #000000; font-weight: bold;">'' ||',
'            CASE ',
'                WHEN DBMS_LOB.GETLENGTH(value_old) > 500 THEN SUBSTR(DBMS_LOB.SUBSTR(value_old, 500, 1), 1, 497) || ''...''',
'                ELSE NVL(DBMS_LOB.SUBSTR(value_old, 500, 1), ''NULL'')',
unistr('            END || '' \2192 '' || '),
'            CASE ',
'                WHEN DBMS_LOB.GETLENGTH(value_new) > 500 THEN SUBSTR(DBMS_LOB.SUBSTR(value_new, 500, 1), 1, 497) || ''...''',
'                ELSE NVL(DBMS_LOB.SUBSTR(value_new, 500, 1), ''NULL'')',
'            END || ''</span>''',
'        ELSE ',
unistr('            ''<span style="background-color: #f5f5f5; color: #666;">Keine \00C4nderung</span>'''),
'    END as "Change Summary"',
'FROM all_comparisons',
'WHERE (:P471_SEARCH_1 IS NOT NULL AND :P471_MILESTONE_1 IS NOT NULL ',
'       AND :P471_SEARCH_2 IS NOT NULL AND :P471_MILESTONE_2 IS NOT NULL)',
unistr('       AND (:P471_SHOW_ALL_CHANGES = ''Y'' OR change_status = ''Ge\00E4ndert'')'),
'ORDER BY sort_order'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P471_SEARCH_1,P471_MILESTONE_1,P471_SEARCH_2,P471_MILESTONE_2,P471_SHOW_ALL_CHANGES'
,p_plug_display_condition_type=>'NEVER'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Stammdaten-Vergleichsergebnisse LIST AGG'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(965944927120377227)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>2706267388779011008
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(965944852800377226)
,p_db_column_name=>'Data Type'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Datentyp'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(965944753897377225)
,p_db_column_name=>'Change Summary'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('\00C4nderungs\00FCbersicht')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(965944626361377224)
,p_db_column_name=>'Status'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(965944550090377223)
,p_db_column_name=>'Suche 2'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Suche 2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(965944480306377222)
,p_db_column_name=>'Suche 1'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Suche 1'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(964025404764894223)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'27081870'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'Data Type:Change Summary:Status:Suche 2:Suche 1'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(951937564930316300)
,p_plug_name=>'Detaillierter Vorschriftenvergleich - withotu group by  - 27.11.2025'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>190
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH regulation_comparison AS (',
'    SELECT ',
'        COALESCE(m1.vorschriftid, m2.vorschriftid) as vorschriftid,',
'        COALESCE(m1.vorschriftnummer, m2.vorschriftnummer) as vorschriftnummer,',
'        COALESCE(m1.landbezeichnung, m2.landbezeichnung) as land,',
'        m1.kritikalitaet as new_criticality,',
'        m2.kritikalitaet as old_criticality,',
'        -- change detection',
'        CASE ',
'            WHEN m1.vorschriftid IS NULL THEN ''entfall''',
'            WHEN m2.vorschriftid IS NULL THEN ''neu'' ',
unistr('            WHEN NVL(m1.kritikalitaet,0) > NVL(m2.kritikalitaet,0) THEN ''kritikalit\00E4t_erh\00F6ht'''),
unistr('            WHEN NVL(m1.kritikalitaet,0) < NVL(m2.kritikalitaet,0) THEN ''kritikalit\00E4t_reduziert'''),
unistr('            WHEN m1.ausgabe_text != m2.ausgabe_text THEN ''text_ge\00E4ndert'''),
unistr('            WHEN m1.et_verwendung != m2.et_verwendung THEN ''bewertung_ge\00E4ndert'''),
'            ELSE ''equal''',
'        END as change_type,',
'        -- visual indicators with detailed tooltips',
'       CASE ',
'            WHEN m1.vorschriftid IS NULL THEN ',
'                ''<span style="color: #e74c3c; font-weight: bold;"><i class="fa fa-minus-circle" title="Vorschrift entfernt in '' || COALESCE(m1.landbezeichnung, m2.landbezeichnung) || ''"></i> Entfall</span>''',
'            WHEN m2.vorschriftid IS NULL THEN ',
unistr('                ''<span style="color: #27ae60; font-weight: bold;"><i class="fa fa-plus-circle" title="Neue Vorschrift hinzugef\00FCgt in '' || COALESCE(m1.landbezeichnung, m2.landbezeichnung) || ''"></i> Neu</span>'''),
'            WHEN NVL(m1.kritikalitaet,0) > NVL(m2.kritikalitaet,0) THEN ',
'                ''<span style="color: #e74c3c; font-weight: bold;"><i class="fa fa-arrow-up" style="color: #fff; background-color: #e74c3c; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; paddin'
||unistr('g: 2px; width: 16px; height: 16px; vertical-align: middle;" title="Kritikalit\00E4t ge\00E4ndert: '' || NVL(m2.kritikalitaet,0) || '' \2192 '' || NVL(m1.kritikalitaet,0) || ''"></i> Kritikalit\00E4t \2197 ('' || '),
unistr('                NVL(m2.kritikalitaet,0) || '' \2192 '' || NVL(m1.kritikalitaet,0) || '')</span>'''),
'            WHEN NVL(m1.kritikalitaet,0) < NVL(m2.kritikalitaet,0) THEN ',
'                ''<span style="color: #27ae60; font-weight: bold;"><i class="fa fa-arrow-down" style="color: #fff; background-color: #27ae60; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padd'
||unistr('ing: 2px; width: 16px; height: 16px; vertical-align: middle;" title="Kritikalit\00E4t ge\00E4ndert: '' || NVL(m2.kritikalitaet,0) || '' \2192 '' || NVL(m1.kritikalitaet,0) || ''"></i> Kritikalit\00E4t \2198 ('' || '),
unistr('                NVL(m2.kritikalitaet,0) || '' \2192 '' || NVL(m1.kritikalitaet,0) || '')</span>'''),
'            WHEN m1.ausgabe_text != m2.ausgabe_text THEN',
unistr('                ''<span style="color: #f39c12; font-weight: bold;"><i class="fa fa-edit" title="Ausgabe Text wurde ge\00E4ndert"></i> Text ge\00E4ndert</span>'''),
'            WHEN m1.et_verwendung != m2.et_verwendung THEN',
unistr('                ''<span style="color: #3498db; font-weight: bold;"><i class="fa fa-exchange" title="ET Verwendung ge\00E4ndert: '' || COALESCE(m2.et_verwendung, ''nicht bewertet'') || '' \2192 '' || COALESCE(m1.et_verwendung, ''nicht bewertet'') || ''"></i> Bewertung')
||unistr(' ge\00E4ndert</span>'''),
unistr('            ELSE ''<span style="color: #95a5a6;"><i class="fa fa-check-circle" title="Keine \00C4nderung"></i> Unver\00E4ndert</span>'''),
'        END as status_display,',
'        -- row CSS class',
'        CASE ',
'            WHEN m1.vorschriftid IS NULL THEN ''country-row-removed''',
'            WHEN m2.vorschriftid IS NULL THEN ''country-row-added'' ',
'            WHEN NVL(m1.kritikalitaet,0) != NVL(m2.kritikalitaet,0) THEN ''country-row-modified''',
'            WHEN m1.ausgabe_text != m2.ausgabe_text THEN ''country-row-modified''',
'            WHEN m1.et_verwendung != m2.et_verwendung THEN ''country-row-modified''',
'            ELSE ''''',
'        END as row_css_class,',
'        -- change indicator with detailed info',
'        CASE ',
'            WHEN m1.vorschriftid IS NULL THEN ',
'                ''<span class="fa fa-minus-circle" style="color: #dc3545; margin-right: 5px; font-size: 16px;" '' ||',
'                ''title="Vorschrift entfernt in '' || COALESCE(m1.landbezeichnung, m2.landbezeichnung) || ''"></span>''',
'            WHEN m2.vorschriftid IS NULL THEN ',
'                ''<span class="fa fa-plus-circle" style="color: #28a745; margin-right: 5px; font-size: 16px;" '' ||',
unistr('                ''title="Neue Vorschrift hinzugef\00FCgt in '' || COALESCE(m1.landbezeichnung, m2.landbezeichnung) || ''"></span>'''),
'            WHEN NVL(m1.kritikalitaet,0) != NVL(m2.kritikalitaet,0) THEN ',
'                ''<span class="fa fa-exclamation-circle" style="color: #ffc107; margin-right: 5px; font-size: 16px;" '' ||',
unistr('                ''title="Kritikalit\00E4t ge\00E4ndert: '' || NVL(m2.kritikalitaet,0) || '' \2192 '' || NVL(m1.kritikalitaet,0) || ''"></span>'''),
'            WHEN m1.ausgabe_text != m2.ausgabe_text THEN',
'                ''<span class="fa fa-edit" style="color: #17a2b8; margin-right: 5px; font-size: 16px;" '' ||',
unistr('                ''title="Ausgabe Text wurde ge\00E4ndert"></span>'''),
'            WHEN m1.et_verwendung != m2.et_verwendung THEN',
'                ''<span class="fa fa-exchange" style="color: #6f42c1; margin-right: 5px; font-size: 16px;" '' ||',
unistr('                ''title="ET Verwendung ge\00E4ndert: '' || COALESCE(m2.et_verwendung, ''nicht bewertet'') || '' \2192 '' || COALESCE(m1.et_verwendung, ''nicht bewertet'') || ''"></span>'''),
'            ELSE ',
'                ''<span class="fa fa-check-circle" style="color: #28a745; margin-right: 5px; font-size: 16px;" '' ||',
unistr('                ''title="Keine \00C4nderung"></span>'''),
'        END as country_change_indicator,',
'        -- mass update blocking logic',
'        CASE ',
'            WHEN EXISTS (',
'                -- Check for composition conflicts',
'                SELECT 1 FROM t_ms_suchergebniss ms_comp',
'                WHERE ms_comp.vorschriftid = COALESCE(m1.vorschriftid, m2.vorschriftid)',
'                AND ms_comp.sucheid = :P471_SEARCH_1',
'                AND ms_comp.meilenstein = :P471_MILESTONE_1',
'                AND ms_comp.manueller_eintrag = 10',
'                AND NOT EXISTS (',
'                    SELECT 1 FROM t_ms_suchergebniss ms_theme',
'                    WHERE ms_theme.vorschriftid = ms_comp.vorschriftid',
'                    AND ms_theme.sucheid = ms_comp.sucheid',
'                    AND ms_theme.meilenstein = ms_comp.meilenstein',
'                    AND ms_theme.themabezeichnung = ms_comp.themabezeichnung',
'                    AND ms_theme.landid != ms_comp.landid',
'                )',
'            ) THEN 1',
'            ELSE 0',
'        END as has_mass_update_conflict,',
'        -- Get additional data from milestones',
'        m1.ausgabe_text,',
'        m2.ausgabe_text as prev_ausgabe_text,',
'        m1.et_verwendung,',
'        m2.et_verwendung as prev_et_verwendung,',
'        m1.et_kommentar,',
'        m2.et_kommentar as prev_et_kommentar,',
'        m1.manueller_eintrag,',
'        m2.manueller_eintrag as prev_manueller_eintrag',
'    FROM (',
'        -- Current milestone regulations with extended data',
'        SELECT ',
'            ms.vorschriftid, ',
'            ms.vorschriftnummer, ',
'            ms.landbezeichnung, ',
'            ms.manueller_eintrag,',
'            COALESCE(mat.kritikalitaet, 0) as kritikalitaet,',
'            mat.ausgabe_text,',
'            bew.et_verwendung,',
'            bew.et_kommentar',
'        FROM t_ms_suchergebniss ms',
'        LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'        LEFT JOIN t_ms_parameter_ref_ausgabe pra ON p.ms_parameterid = pra.ms_parameterid',
'        LEFT JOIN t_ms_ausgabe_text mat ON pra.ms_ausgabe_textid = mat.ms_ausgabe_textid',
'        LEFT JOIN t_ms_bewertung bew ON (',
'            bew.sucheid = ms.sucheid ',
'            AND bew.meilenstein = ms.meilenstein',
'            AND bew.vorschriftid = ms.vorschriftid',
'            AND (bew.benutzerid = :G_BENUTZERID ',
'                 OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                            WHERE brr.benutzerid = :G_BENUTZERID ',
'                            AND brr.rolleid = 1001))',
'        )',
'        WHERE ms.sucheid = :P471_SEARCH_1 AND ms.meilenstein = :P471_MILESTONE_1',
'        AND p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1',
'    ) m1',
'    FULL OUTER JOIN (',
'        -- Previous milestone regulations with extended data',
'        SELECT ',
'            ms.vorschriftid, ',
'            ms.vorschriftnummer, ',
'            ms.landbezeichnung,',
'            ms.manueller_eintrag,',
'            COALESCE(mat.kritikalitaet, 0) as kritikalitaet,',
'            mat.ausgabe_text,',
'            bew.et_verwendung,',
'            bew.et_kommentar',
'        FROM t_ms_suchergebniss ms',
'        LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'        LEFT JOIN t_ms_parameter_ref_ausgabe pra ON p.ms_parameterid = pra.ms_parameterid  ',
'        LEFT JOIN t_ms_ausgabe_text mat ON pra.ms_ausgabe_textid = mat.ms_ausgabe_textid',
'        LEFT JOIN t_ms_bewertung bew ON (',
'            bew.sucheid = ms.sucheid ',
'            AND bew.meilenstein = ms.meilenstein',
'            AND bew.vorschriftid = ms.vorschriftid',
'            AND (bew.benutzerid = :G_BENUTZERID ',
'                 OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                            WHERE brr.benutzerid = :G_BENUTZERID ',
'                            AND brr.rolleid = 1001))',
'        )',
'        WHERE ms.sucheid = :P471_SEARCH_2 AND ms.meilenstein = :P471_MILESTONE_2',
'        AND p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1',
'    ) m2 ON m1.vorschriftid = m2.vorschriftid',
')',
'SELECT ',
unistr('    country_change_indicator as "\00C4nderung",'),
'    land as "Land",',
'    ',
'    -- regulation number with clickable link',
'    ''<a href="f?p='' || :APP_ID || '':25:'' || :APP_SESSION || ''::'' || :DEBUG || ',
'    '':RP,25:P25_VORSCHRIFTID:'' || vorschriftid || ''" target="_blank" style="text-decoration: none;">'' ||',
'    vorschriftnummer || ''</a>'' as "Vorschriftennummer",',
'    ',
'    status_display as "Status",',
'    ',
'    -- criticality display with arrows',
'    CASE ',
'        WHEN old_criticality IS NOT NULL AND new_criticality IS NOT NULL THEN',
'            NVL(TO_CHAR(old_criticality), ''-'') || ',
'            CASE ',
'                WHEN new_criticality > old_criticality THEN ',
'                    '' <i class="fa fa-arrow-up" style="color: #fff; background-color: #e74c3c; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padding: 2px; width: 16px; height: 16px; vertical-'
||unistr('align: middle;" title="Kritikalit\00E4t gestiegen: '' || old_criticality || '' \2192 '' || new_criticality || ''"></i> '''),
'                WHEN new_criticality < old_criticality THEN ',
'                    '' <i class="fa fa-arrow-down" style="color: #fff; background-color: #27ae60; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padding: 2px; width: 16px; height: 16px; vertica'
||unistr('l-align: middle;" title="Kritikalit\00E4t gesunken: '' || old_criticality || '' \2192 '' || new_criticality || ''"></i> '''),
'                ELSE ',
unistr('                    '' <i class="fa fa-check-circle" style="color: #95a5a6;" title="Kritikalit\00E4t unver\00E4ndert: '' || old_criticality || ''"></i> '''),
'            END ||',
'            NVL(TO_CHAR(new_criticality), ''-'')',
'        WHEN new_criticality IS NOT NULL THEN',
unistr('            ''<span style="color: #27ae60; font-weight: bold;" title="Neue Vorschrift mit Kritikalit\00E4t '' || new_criticality || ''">Neu: '' || TO_CHAR(new_criticality) || ''</span>'''),
'        WHEN old_criticality IS NOT NULL THEN',
unistr('            ''<span style="color: #e74c3c; font-weight: bold;" title="Vorschrift entfernt, hatte Kritikalit\00E4t '' || old_criticality || ''">Entfallen: '' || TO_CHAR(old_criticality) || ''</span>'''),
'        ELSE ''-''',
unistr('    END as "Kritikalit\00E4t (Vergleich)",'),
'    ',
'    -- Show what was selected in previous milestone (Ticket requirement)',
'    CASE ',
'        WHEN prev_et_verwendung IS NOT NULL THEN',
'            CASE prev_et_verwendung',
'                WHEN ''ja'' THEN ''<span style="color: #27ae60;"><i class="fa fa-check"></i> ja</span>''',
'                WHEN ''nein'' THEN ''<span style="color: #e74c3c;"><i class="fa fa-times"></i> nein</span>''',
'                ELSE ''<span style="color: #666;">nicht bewertet</span>''',
'            END',
'        ELSE ''<span style="color: #999;">-</span>''',
unistr('    END as "Ausgew\00E4hlte Vorschrift (M-1)",'),
'    ',
'    -- Show current selection',
'    CASE ',
'        WHEN et_verwendung IS NOT NULL THEN',
'            CASE et_verwendung',
'                WHEN ''ja'' THEN ''<span style="color: #27ae60;"><i class="fa fa-check"></i> ja</span>''',
'                WHEN ''nein'' THEN ''<span style="color: #e74c3c;"><i class="fa fa-times"></i> nein</span>''',
'                ELSE ''<span style="color: #666;">nicht bewertet</span>''',
'            END',
'        ELSE ''<span style="color: #999;">-</span>''',
'    END as "Aktuelle Auswahl",',
'    ',
'    -- duplicate detection with detailed tooltip',
'    CASE ',
'        WHEN EXISTS (',
'            SELECT 1 FROM t_ms_suchergebniss ms_dup1',
'            WHERE ms_dup1.vorschriftid = regulation_comparison.vorschriftid',
'            AND ms_dup1.sucheid = :P471_SEARCH_1 ',
'            AND ms_dup1.meilenstein = :P471_MILESTONE_1',
'            AND ms_dup1.manueller_eintrag = 10  -- Manual entry',
'            AND EXISTS (',
'                SELECT 1 FROM t_ms_suchergebniss ms_dup2',
'                WHERE ms_dup2.vorschriftid = ms_dup1.vorschriftid',
'                AND ms_dup2.sucheid = :P471_SEARCH_1',
'                AND ms_dup2.meilenstein = :P471_MILESTONE_1',
'                AND ms_dup2.manueller_eintrag != 10  -- Automatic entry',
'            )',
'        ) THEN ''<span class="fa fa-exclamation-triangle" style="color: #e74c3c; font-size: 16px; animation: pulse 2s infinite;" '' ||',
'                ''title="Vorschrift doppelt im PRI vorhanden! Manueller und automatischer Eintrag existieren."></span>''',
'        ELSE ''''',
'    END as "Duplikat Warnung",',
'    ',
'    -- Mass update status (Ticket requirement)',
'    CASE ',
'        WHEN has_mass_update_conflict = 1 THEN',
'            ''<span class="fa fa-ban" style="color: #e74c3c; font-size: 16px;" '' ||',
'            ''title="Massenupdate blockiert - Themen-Komposition Konflikt"></span>''',
'        ELSE',
'            ''<span class="fa fa-check" style="color: #28a745; font-size: 16px;" '' ||',
unistr('            ''title="Massenupdate m\00F6glich"></span>'''),
'    END as "Massenupdate Status",',
'    ',
'    -- Entry type indicator',
'    CASE ',
'        WHEN manueller_eintrag = 10 OR prev_manueller_eintrag = 10 THEN',
'            ''<span style="color: #bb0a31;"><i class="fa fa-user-plus"></i> Manuell</span>''',
'        ELSE',
'            ''<span style="color: #666;"><i class="fa fa-cog"></i> Automatisch</span>''',
'    END as "Eintrag Typ",',
'    ',
'    -- Diff summary for milestone -1 (Key ticket requirement)',
'    CASE ',
'        WHEN change_type = ''neu'' THEN ',
'            ''<span style="background-color: #d4edda; color: #155724; padding: 2px 6px; border-radius: 3px; font-size: 11px;">NEU</span>''',
'        WHEN change_type = ''entfall'' THEN ',
'            ''<span style="background-color: #f8d7da; color: #721c24; padding: 2px 6px; border-radius: 3px; font-size: 11px;">ENTFALL</span>''',
unistr('        WHEN change_type = ''kritikalit\00E4t_erh\00F6ht'' THEN '),
unistr('            ''<span style="background-color: #f8d7da; color: #721c24; padding: 2px 6px; border-radius: 3px; font-size: 11px;">KRIT\2197</span>'''),
unistr('        WHEN change_type = ''kritikalit\00E4t_reduziert'' THEN '),
unistr('            ''<span style="background-color: #d4edda; color: #155724; padding: 2px 6px; border-radius: 3px; font-size: 11px;">KRIT\2198</span>'''),
unistr('        WHEN change_type = ''text_ge\00E4ndert'' THEN '),
'            ''<span style="background-color: #fff3cd; color: #856404; padding: 2px 6px; border-radius: 3px; font-size: 11px;">TEXT</span>''',
unistr('        WHEN change_type = ''bewertung_ge\00E4ndert'' THEN '),
'            ''<span style="background-color: #d1ecf1; color: #0c5460; padding: 2px 6px; border-radius: 3px; font-size: 11px;">BEWERTET</span>''',
'        ELSE ',
'            ''<span style="background-color: #e2e3e5; color: #383d41; padding: 2px 6px; border-radius: 3px; font-size: 11px;">GLEICH</span>''',
'    END as "Diff Meilenstein -1",',
'    ',
'    row_css_class',
'FROM regulation_comparison',
'',
'ORDER BY ',
'    CASE change_type',
'        WHEN ''neu'' THEN 1',
'        WHEN ''entfall'' THEN 2  ',
unistr('        WHEN ''kritikalit\00E4t_erh\00F6ht'' THEN 3'),
unistr('        WHEN ''kritikalit\00E4t_reduziert'' THEN 4'),
unistr('        WHEN ''text_ge\00E4ndert'' THEN 5'),
unistr('        WHEN ''bewertung_ge\00E4ndert'' THEN 6'),
'        ELSE 7',
'    END,',
'    land, ',
'    vorschriftnummer'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P471_SEARCH_1,P471_MILESTONE_1,P471_SEARCH_2,P471_MILESTONE_2'
,p_plug_display_condition_type=>'NEVER'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detaillierter Vorschriftenvergleich - withotu group by  - 27.11.2025'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(951937436075316299)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>2720274879824071936
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(951937399460316298)
,p_db_column_name=>'Land'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(951937217104316297)
,p_db_column_name=>'Vorschriftennummer'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(951937141258316296)
,p_db_column_name=>'Status'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(951937075410316295)
,p_db_column_name=>unistr('\00C4nderung')
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('\00C4nderung')
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(951937003108316294)
,p_db_column_name=>'ROW_CSS_CLASS'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Row Css Class'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(951936825277316293)
,p_db_column_name=>unistr('Kritikalit\00E4t (Vergleich)')
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('Kritikalit\00E4t (vergleich)')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(951936808025316292)
,p_db_column_name=>unistr('Ausgew\00E4hlte Vorschrift (M-1)')
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('Ausgew\00E4hlte Vorschrift (m-1)')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(951936649503316291)
,p_db_column_name=>'Aktuelle Auswahl'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Aktuelle Auswahl'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(951936525234316290)
,p_db_column_name=>'Duplikat Warnung'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Duplikat Warnung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(951936507192316289)
,p_db_column_name=>'Massenupdate Status'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Massenupdate Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(951936328427316288)
,p_db_column_name=>'Eintrag Typ'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Eintrag Typ'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(951936304833316287)
,p_db_column_name=>'Diff Meilenstein -1'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Diff Meilenstein -1'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2314681557365574022)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2315151947834179724)
,p_plug_name=>'Stammdaten-Vergleichsergebnisse'
,p_region_name=>'rMasterDataReport'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>110
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ',
'sop_comparison AS (',
'    SELECT ',
'        ''SOP'' as data_type,',
'        1 as sort_order,',
'        TO_CLOB(s1.datum_sop) as value_new,',
'        TO_CLOB(s2.datum_sop) as value_old,',
'        CASE ',
unistr('            WHEN NVL(s1.datum_sop, ''NULL'') != NVL(s2.datum_sop, ''NULL'') THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN NVL(s1.datum_sop, ''NULL'') != NVL(s2.datum_sop, ''NULL'') THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT jt.datum_sop',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            datum_sop VARCHAR2(20) PATH ''$.DATUM_SOP''',
'        )) jt',
'        WHERE tsj.sucheid = :P471_SEARCH_1',
'        AND jt.meilenstein = :P471_MILESTONE_1',
'    ) s1',
'    CROSS JOIN (',
'        SELECT jt.datum_sop',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            datum_sop VARCHAR2(20) PATH ''$.DATUM_SOP''',
'        )) jt',
'        WHERE tsj.sucheid = :P471_SEARCH_2',
'        AND jt.meilenstein = :P471_MILESTONE_2',
'    ) s2',
'),',
'eop_comparison AS (',
'    SELECT ',
'        ''EOP'' as data_type,',
'        2 as sort_order,',
'        TO_CLOB(s1.datum_eop) as value_new,',
'        TO_CLOB(s2.datum_eop) as value_old,',
'        CASE ',
unistr('            WHEN NVL(s1.datum_eop, ''NULL'') != NVL(s2.datum_eop, ''NULL'') THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN NVL(s1.datum_eop, ''NULL'') != NVL(s2.datum_eop, ''NULL'') THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT jt.datum_eop',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            datum_eop VARCHAR2(20) PATH ''$.DATUM_EOP''',
'        )) jt',
'        WHERE tsj.sucheid = :P471_SEARCH_1',
'        AND jt.meilenstein = :P471_MILESTONE_1',
'    ) s1',
'    CROSS JOIN (',
'        SELECT jt.datum_eop',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            datum_eop VARCHAR2(20) PATH ''$.DATUM_EOP''',
'        )) jt',
'        WHERE tsj.sucheid = :P471_SEARCH_2',
'        AND jt.meilenstein = :P471_MILESTONE_2',
'    ) s2',
'),',
'search_type_comparison AS (',
'    SELECT ',
'        ''Suchtyp'' as data_type,',
'        3 as sort_order,',
'        TO_CLOB(CASE s1.suchtyp ',
'            WHEN ''0'' THEN ''Neue Typen''',
'            WHEN ''10'' THEN ''Bestehender Typ''',
'            ELSE s1.suchtyp',
'        END) as value_new,',
'        TO_CLOB(CASE s2.suchtyp ',
'            WHEN ''0'' THEN ''Neue Typen''',
'            WHEN ''10'' THEN ''Bestehender Typ''',
'            ELSE s2.suchtyp',
'        END) as value_old,',
'        CASE ',
unistr('            WHEN NVL(s1.suchtyp, ''NULL'') != NVL(s2.suchtyp, ''NULL'') THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN NVL(s1.suchtyp, ''NULL'') != NVL(s2.suchtyp, ''NULL'') THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT jt.suchtyp',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            suchtyp VARCHAR2(20) PATH ''$.SUCHTYP''',
'        )) jt',
'        WHERE tsj.sucheid = :P471_SEARCH_1',
'        AND jt.meilenstein = :P471_MILESTONE_1',
'    ) s1',
'    CROSS JOIN (',
'        SELECT jt.suchtyp',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            suchtyp VARCHAR2(20) PATH ''$.SUCHTYP''',
'        )) jt',
'        WHERE tsj.sucheid = :P471_SEARCH_2',
'        AND jt.meilenstein = :P471_MILESTONE_2',
'    ) s2',
'),',
'countries_comparison AS (',
'    SELECT ',
unistr('        ''L\00E4nder/M\00E4rkte'' as data_type,'),
'        4 as sort_order,',
'        c1.countries_list as value_new,',
'        c2.countries_list as value_old,',
'        CASE ',
unistr('            WHEN DBMS_LOB.COMPARE(NVL(c1.countries_list, TO_CLOB(''NULL'')), NVL(c2.countries_list, TO_CLOB(''NULL''))) != 0 THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN DBMS_LOB.COMPARE(NVL(c1.countries_list, TO_CLOB(''NULL'')), NVL(c2.countries_list, TO_CLOB(''NULL''))) != 0 THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, l.b_nummer || ''-'' || l.land, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY l.b_nummer).GETCLOBVAL(), ''; '') as countries_list',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            laender VARCHAR2(4000) PATH ''$.LAENDER''',
'        )) jt,',
'        TABLE(apex_string.split(jt.laender, '':'')) countries,',
'        t_land l',
'        WHERE tsj.sucheid = :P471_SEARCH_1',
'        AND jt.meilenstein = :P471_MILESTONE_1',
'        AND l.landid = TO_NUMBER(countries.column_value)',
'    ) c1',
'    CROSS JOIN (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, l.b_nummer || ''-'' || l.land, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY l.b_nummer).GETCLOBVAL(), ''; '') as countries_list',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            laender VARCHAR2(4000) PATH ''$.LAENDER''',
'        )) jt,',
'        TABLE(apex_string.split(jt.laender, '':'')) countries,',
'        t_land l',
'        WHERE tsj.sucheid = :P471_SEARCH_2',
'        AND jt.meilenstein = :P471_MILESTONE_2',
'        AND l.landid = TO_NUMBER(countries.column_value)',
'    ) c2',
'),',
'themes_comparison AS (',
'    SELECT ',
'        ''Themabezeichnung'' as data_type,',
'        5 as sort_order,',
'        t1.themes_list as value_new,',
'        t2.themes_list as value_old,',
'        CASE ',
unistr('            WHEN DBMS_LOB.COMPARE(NVL(t1.themes_list, TO_CLOB(''NULL'')), NVL(t2.themes_list, TO_CLOB(''NULL''))) != 0 THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN DBMS_LOB.COMPARE(NVL(t1.themes_list, TO_CLOB(''NULL'')), NVL(t2.themes_list, TO_CLOB(''NULL''))) != 0 THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, t.bezeichnung, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY t.bezeichnung).GETCLOBVAL(), ''; '') as themes_list',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            themen VARCHAR2(4000) PATH ''$.THEMEN''',
'        )) jt,',
'        TABLE(apex_string.split(jt.themen, '':'')) themes,',
'        t_thema t',
'        WHERE tsj.sucheid = :P471_SEARCH_1',
'        AND jt.meilenstein = :P471_MILESTONE_1',
'        AND t.themaid = TO_NUMBER(themes.column_value)',
'    ) t1',
'    CROSS JOIN (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, t.bezeichnung, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY t.bezeichnung).GETCLOBVAL(), ''; '') as themes_list',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            themen VARCHAR2(4000) PATH ''$.THEMEN''',
'        )) jt,',
'        TABLE(apex_string.split(jt.themen, '':'')) themes,',
'        t_thema t',
'        WHERE tsj.sucheid = :P471_SEARCH_2',
'        AND jt.meilenstein = :P471_MILESTONE_2',
'        AND t.themaid = TO_NUMBER(themes.column_value)',
'    ) t2',
'),',
'kritikalitaet_comparison AS (',
'    SELECT ',
unistr('        ''Kritikalit\00E4t'' as data_type,'),
'        6 as sort_order,',
'        k1.kritikalitaet as value_new,',
'        k2.kritikalitaet as value_old,',
'        CASE ',
unistr('            WHEN DBMS_LOB.COMPARE(NVL(k1.kritikalitaet, TO_CLOB(''NULL'')), NVL(k2.kritikalitaet, TO_CLOB(''NULL''))) != 0 THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN DBMS_LOB.COMPARE(NVL(k1.kritikalitaet, TO_CLOB(''NULL'')), NVL(k2.kritikalitaet, TO_CLOB(''NULL''))) != 0 THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, mat.ausgabe_text, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY mat.ausgabe_text).GETCLOBVAL(), ''; '') as kritikalitaet',
'        FROM (',
'            SELECT DISTINCT mat.ausgabe_text',
'            FROM t_ms_suchergebniss ms',
'            LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'            LEFT JOIN t_ms_parameter_ref_ausgabe pra ON p.ms_parameterid = pra.ms_parameterid',
'            LEFT JOIN t_ms_ausgabe_text mat ON pra.ms_ausgabe_textid = mat.ms_ausgabe_textid',
'            WHERE ms.sucheid = :P471_SEARCH_1 AND ms.meilenstein = :P471_MILESTONE_1',
'            -- FIX: Allow Manual Entries (10) or Report Flag (1)',
'            AND (p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1 OR ms.MANUELLER_EINTRAG = 10)  ',
'        ) mat',
'    ) k1',
'    CROSS JOIN (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, mat.ausgabe_text, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY mat.ausgabe_text).GETCLOBVAL(), ''; '') as kritikalitaet',
'        FROM (',
'            SELECT DISTINCT mat.ausgabe_text',
'            FROM t_ms_suchergebniss ms',
'            LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'            LEFT JOIN t_ms_parameter_ref_ausgabe pra ON p.ms_parameterid = pra.ms_parameterid',
'            LEFT JOIN t_ms_ausgabe_text mat ON pra.ms_ausgabe_textid = mat.ms_ausgabe_textid',
'            WHERE ms.sucheid = :P471_SEARCH_2 AND ms.meilenstein = :P471_MILESTONE_2',
'            -- FIX: Allow Manual Entries (10) or Report Flag (1)',
'            AND (p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1 OR ms.MANUELLER_EINTRAG = 10)',
'        ) mat',
'    ) k2',
'),',
'publisher_comparison AS (',
'    SELECT ',
'        ''Publisher'' as data_type,',
'        7 as sort_order,',
'        p1.publishers as value_new,',
'        p2.publishers as value_old,',
'        CASE ',
unistr('            WHEN DBMS_LOB.COMPARE(NVL(p1.publishers, TO_CLOB(''NULL'')), NVL(p2.publishers, TO_CLOB(''NULL''))) != 0 THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN DBMS_LOB.COMPARE(NVL(p1.publishers, TO_CLOB(''NULL'')), NVL(p2.publishers, TO_CLOB(''NULL''))) != 0 THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, v.publisher, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY v.publisher).GETCLOBVAL(), ''; '') as publishers',
'        FROM (',
'            SELECT DISTINCT v.publisher',
'            FROM t_ms_suchergebniss ms',
'            LEFT JOIN t_vorschrift v ON ms.vorschriftid = v.vorschriftid',
'            LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'            WHERE ms.sucheid = :P471_SEARCH_1 AND ms.meilenstein = :P471_MILESTONE_1',
'            -- FIX: Allow Manual Entries (10) or Report Flag (1)',
'            AND (p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1 OR ms.MANUELLER_EINTRAG = 10)',
'        ) v',
'    ) p1',
'    CROSS JOIN (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, v.publisher, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY v.publisher).GETCLOBVAL(), ''; '') as publishers',
'        FROM (',
'            SELECT DISTINCT v.publisher',
'            FROM t_ms_suchergebniss ms',
'            LEFT JOIN t_vorschrift v ON ms.vorschriftid = v.vorschriftid',
'            LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'            WHERE ms.sucheid = :P471_SEARCH_2 AND ms.meilenstein = :P471_MILESTONE_2',
'            -- FIX: Allow Manual Entries (10) or Report Flag (1)',
'            AND (p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1 OR ms.MANUELLER_EINTRAG = 10)',
'        ) v',
'    ) p2',
'),',
'lrsa_comparison AS (',
'    SELECT ',
'        ''LRSA'' as data_type,',
'        8 as sort_order,',
'        l1.lrsa_values as value_new,',
'        l2.lrsa_values as value_old,',
'        CASE ',
unistr('            WHEN DBMS_LOB.COMPARE(NVL(l1.lrsa_values, TO_CLOB(''NULL'')), NVL(l2.lrsa_values, TO_CLOB(''NULL''))) != 0 THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN DBMS_LOB.COMPARE(NVL(l1.lrsa_values, TO_CLOB(''NULL'')), NVL(l2.lrsa_values, TO_CLOB(''NULL''))) != 0 THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, l.lrsa_nummer || '' - '' || l.bezeichnung, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY l.bezeichnung).GETCLOBVAL(), ''; '') as lrsa_values',
'        FROM (',
'            SELECT DISTINCT l.lrsa_nummer, l.bezeichnung',
'            FROM t_ms_suchergebniss ms',
'            LEFT JOIN t_vorschrift_ref_thema vrt ON ms.vorschriftid = vrt.vorschriftid',
'            LEFT JOIN t_thema_ref_lrsa ref ON vrt.themaid = ref.themaid',
'            LEFT JOIN t_lrsa l ON l.lrsa_id = ref.lrsaid',
'            LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'            WHERE ms.sucheid = :P471_SEARCH_1 AND ms.meilenstein = :P471_MILESTONE_1',
'            AND vrt.geloescht = 0',
'            -- FIX: Allow Manual Entries (10) or Report Flag (1)',
'            AND (p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1 OR ms.MANUELLER_EINTRAG = 10)',
'        ) l',
'    ) l1',
'    CROSS JOIN (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, l.lrsa_nummer || '' - '' || l.bezeichnung, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY l.bezeichnung).GETCLOBVAL(), ''; '') as lrsa_values',
'        FROM (',
'            SELECT DISTINCT l.lrsa_nummer, l.bezeichnung',
'            FROM t_ms_suchergebniss ms',
'            LEFT JOIN t_vorschrift_ref_thema vrt ON ms.vorschriftid = vrt.vorschriftid',
'            LEFT JOIN t_thema_ref_lrsa ref ON vrt.themaid = ref.themaid',
'            LEFT JOIN t_lrsa l ON l.lrsa_id = ref.lrsaid',
'            LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'            WHERE ms.sucheid = :P471_SEARCH_2 AND ms.meilenstein = :P471_MILESTONE_2',
'            AND vrt.geloescht = 0',
'            -- FIX: Allow Manual Entries (10) or Report Flag (1)',
'            AND (p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1 OR ms.MANUELLER_EINTRAG = 10)',
'        ) l',
'    ) l2',
'),',
'evaluation_comparison AS (',
'    SELECT ',
'        ''ET Verwendung'' as data_type,',
'        9 as sort_order,',
'        e1.evaluations as value_new,',
'        e2.evaluations as value_old,',
'        CASE ',
unistr('            WHEN DBMS_LOB.COMPARE(NVL(e1.evaluations, TO_CLOB(''NULL'')), NVL(e2.evaluations, TO_CLOB(''NULL''))) != 0 THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN DBMS_LOB.COMPARE(NVL(e1.evaluations, TO_CLOB(''NULL'')), NVL(e2.evaluations, TO_CLOB(''NULL''))) != 0 THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, bew.et_verwendung, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY bew.et_verwendung).GETCLOBVAL(), ''; '') as evaluations',
'        FROM (',
'            SELECT DISTINCT bew.et_verwendung',
'            FROM t_ms_bewertung bew',
'            WHERE bew.sucheid = :P471_SEARCH_1 AND bew.meilenstein = :P471_MILESTONE_1',
'            AND (bew.benutzerid = :G_BENUTZERID ',
'                 OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                            WHERE brr.benutzerid = :G_BENUTZERID ',
'                            AND brr.rolleid = 1001))',
'        ) bew',
'    ) e1',
'    CROSS JOIN (',
'        SELECT RTRIM(XMLAGG(XMLELEMENT(E, bew.et_verwendung, ''; '').EXTRACT(''//text()'') ',
'            ORDER BY bew.et_verwendung).GETCLOBVAL(), ''; '') as evaluations',
'        FROM (',
'            SELECT DISTINCT bew.et_verwendung',
'            FROM t_ms_bewertung bew',
'            WHERE bew.sucheid = :P471_SEARCH_2 AND bew.meilenstein = :P471_MILESTONE_2',
'            AND (bew.benutzerid = :G_BENUTZERID ',
'                 OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                            WHERE brr.benutzerid = :G_BENUTZERID ',
'                            AND brr.rolleid = 1001))',
'        ) bew',
'    ) e2',
'),',
'et_kommentar_comparison AS (',
'    SELECT ',
'        ''ET Kommentar'' as data_type,',
'        10 as sort_order,',
'        TO_CLOB(k1.kommentare) as value_new,',
'        TO_CLOB(k2.kommentare) as value_old,',
'        CASE ',
unistr('            WHEN NVL(k1.kommentare, ''NULL'') != NVL(k2.kommentare, ''NULL'') THEN ''Ge\00E4ndert'''),
unistr('            ELSE ''Unver\00E4ndert'''),
'        END as change_status,',
'        CASE ',
'            WHEN NVL(k1.kommentare, ''NULL'') != NVL(k2.kommentare, ''NULL'') THEN',
'                ''<span class="fa fa-exclamation-triangle" style="color: #f39c12;"></span>''',
'            ELSE ''<span class="fa fa-check" style="color: #27ae60;"></span>''',
'        END as status_icon',
'    FROM (',
'        SELECT COUNT(DISTINCT bew.et_kommentar) || '' eindeutige Kommentare'' as kommentare',
'        FROM t_ms_bewertung bew',
'        WHERE bew.sucheid = :P471_SEARCH_1 AND bew.meilenstein = :P471_MILESTONE_1',
'        AND bew.et_kommentar IS NOT NULL',
'        AND (bew.benutzerid = :G_BENUTZERID ',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001))',
'    ) k1',
'    CROSS JOIN (',
'        SELECT COUNT(DISTINCT bew.et_kommentar) || '' eindeutige Kommentare'' as kommentare',
'        FROM t_ms_bewertung bew',
'        WHERE bew.sucheid = :P471_SEARCH_2 AND bew.meilenstein = :P471_MILESTONE_2',
'        AND bew.et_kommentar IS NOT NULL',
'        AND (bew.benutzerid = :G_BENUTZERID ',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001))',
'    ) k2',
'),',
'all_comparisons AS (',
'    SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM sop_comparison',
'    UNION ALL SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM eop_comparison',
'    UNION ALL SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM search_type_comparison',
'    UNION ALL SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM countries_comparison',
'    UNION ALL SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM themes_comparison',
'    UNION ALL SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM kritikalitaet_comparison',
'    UNION ALL SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM publisher_comparison',
'    UNION ALL SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM lrsa_comparison',
'    UNION ALL SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM evaluation_comparison',
'    UNION ALL SELECT data_type, sort_order, status_icon, change_status, value_old, value_new FROM et_kommentar_comparison',
')',
'',
'SELECT ',
'    data_type as "Data Type",',
'    status_icon || '' '' || change_status as "Status",',
'    CASE ',
'        WHEN DBMS_LOB.GETLENGTH(value_old) > 2000 THEN SUBSTR(DBMS_LOB.SUBSTR(value_old, 2000, 1), 1, 1997) || ''...''',
'        ELSE NVL(DBMS_LOB.SUBSTR(value_old, 2000, 1), ''-'')',
'    END as "Suche 2",',
'    CASE ',
'        WHEN DBMS_LOB.GETLENGTH(value_new) > 2000 THEN SUBSTR(DBMS_LOB.SUBSTR(value_new, 2000, 1), 1, 1997) || ''...''',
'        ELSE NVL(DBMS_LOB.SUBSTR(value_new, 2000, 1), ''-'')',
'    END as "Suche 1", ',
'    CASE ',
unistr('        WHEN change_status = ''Ge\00E4ndert'' THEN'),
'            ''<span style="background-color: #FFFF00; color: #000000; font-weight: bold;">'' ||',
'            CASE ',
'                WHEN DBMS_LOB.GETLENGTH(value_old) > 500 THEN SUBSTR(DBMS_LOB.SUBSTR(value_old, 500, 1), 1, 497) || ''...''',
'                ELSE NVL(DBMS_LOB.SUBSTR(value_old, 500, 1), ''NULL'')',
unistr('            END || '' \2192 '' || '),
'            CASE ',
'                WHEN DBMS_LOB.GETLENGTH(value_new) > 500 THEN SUBSTR(DBMS_LOB.SUBSTR(value_new, 500, 1), 1, 497) || ''...''',
'                ELSE NVL(DBMS_LOB.SUBSTR(value_new, 500, 1), ''NULL'')',
'            END || ''</span>''',
'        ELSE ',
unistr('            ''<span style="background-color: #f5f5f5; color: #666;">Keine \00C4nderung</span>'''),
'    END as "Change Summary"',
'FROM all_comparisons',
'WHERE (:P471_SEARCH_1 IS NOT NULL AND :P471_MILESTONE_1 IS NOT NULL ',
'       AND :P471_SEARCH_2 IS NOT NULL AND :P471_MILESTONE_2 IS NOT NULL)',
unistr('       AND (:P471_SHOW_ALL_CHANGES = ''Y'' OR change_status = ''Ge\00E4ndert'')'),
'ORDER BY sort_order'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P471_SEARCH_1,P471_MILESTONE_1,P471_SEARCH_2,P471_MILESTONE_2,P471_SHOW_ALL_CHANGES'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Stammdaten-Vergleichsergebnisse'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2315355703431748698)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>5987568019331136933
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964195089613474672)
,p_db_column_name=>'Data Type'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Datentyp'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964193981380474670)
,p_db_column_name=>'Suche 2'
,p_display_order=>30
,p_column_identifier=>'J'
,p_column_label=>'Suche 2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964193522811474669)
,p_db_column_name=>'Suche 1'
,p_display_order=>40
,p_column_identifier=>'K'
,p_column_label=>'Suche 1'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964194331987474671)
,p_db_column_name=>'Change Summary'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>unistr('\00C4nderungs\00FCbersicht')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964194772397474671)
,p_db_column_name=>'Status'
,p_display_order=>70
,p_column_identifier=>'B'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2315405119704813172)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5718956'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'Data Type:Suche 2:Suche 1:Change Summary:Status:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2315356949875748711)
,p_plug_name=>'Vergleich'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2315149473716179699)
,p_plug_name=>'Aktueller Meilenstein'
,p_parent_plug_id=>wwv_flow_imp.id(2315356949875748711)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2315149539779179700)
,p_plug_name=>'Vergleichs-Meilenstein'
,p_parent_plug_id=>wwv_flow_imp.id(2315356949875748711)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2315357799294748719)
,p_plug_name=>'Detaillierter Vorschriftenvergleich'
,p_region_name=>'regulation-comparison'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>180
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ',
'-- Step 1: Aggregate themes/topics FIRST, before joining',
'current_milestone_data AS (',
'    SELECT ',
'        ms.vorschriftid, ',
'        ms.vorschriftnummer, ',
'        ms.landbezeichnung,',
'        -- Aggregate themes into one value per regulation+country',
'        LISTAGG(DISTINCT ms.themabezeichnung, ''; '') WITHIN GROUP (ORDER BY ms.themabezeichnung) as all_themes,',
'        MAX(ms.manueller_eintrag) as manueller_eintrag,',
'        MAX(COALESCE(mat.kritikalitaet, 0)) as kritikalitaet,',
'        MAX(mat.ausgabe_text) as ausgabe_text,',
'        MAX(bew.et_verwendung) as et_verwendung,',
'        MAX(bew.et_kommentar) as et_kommentar',
'    FROM t_ms_suchergebniss ms',
'    LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'    LEFT JOIN t_ms_parameter_ref_ausgabe pra ON p.ms_parameterid = pra.ms_parameterid',
'    LEFT JOIN t_ms_ausgabe_text mat ON pra.ms_ausgabe_textid = mat.ms_ausgabe_textid',
'    LEFT JOIN t_ms_bewertung bew ON (',
'        bew.sucheid = ms.sucheid ',
'        AND bew.meilenstein = ms.meilenstein',
'        AND bew.vorschriftid = ms.vorschriftid',
'        AND (bew.benutzerid = :G_BENUTZERID ',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001))',
'    )',
'    WHERE ms.sucheid = :P471_SEARCH_1 ',
'    AND ms.meilenstein = :P471_MILESTONE_1',
'    AND p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1',
'    -- GROUP BY to consolidate multiple themes',
'    GROUP BY ',
'        ms.vorschriftid, ',
'        ms.vorschriftnummer, ',
'        ms.landbezeichnung',
'),',
'previous_milestone_data AS (',
'    SELECT ',
'        ms.vorschriftid, ',
'        ms.vorschriftnummer, ',
'        ms.landbezeichnung,',
'        -- Aggregate themes into one value per regulation+country',
'        LISTAGG(DISTINCT ms.themabezeichnung, ''; '') WITHIN GROUP (ORDER BY ms.themabezeichnung) as all_themes,',
'        MAX(ms.manueller_eintrag) as manueller_eintrag,',
'        MAX(COALESCE(mat.kritikalitaet, 0)) as kritikalitaet,',
'        MAX(mat.ausgabe_text) as ausgabe_text,',
'        MAX(bew.et_verwendung) as et_verwendung,',
'        MAX(bew.et_kommentar) as et_kommentar',
'    FROM t_ms_suchergebniss ms',
'    LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'    LEFT JOIN t_ms_parameter_ref_ausgabe pra ON p.ms_parameterid = pra.ms_parameterid  ',
'    LEFT JOIN t_ms_ausgabe_text mat ON pra.ms_ausgabe_textid = mat.ms_ausgabe_textid',
'    LEFT JOIN t_ms_bewertung bew ON (',
'        bew.sucheid = ms.sucheid ',
'        AND bew.meilenstein = ms.meilenstein',
'        AND bew.vorschriftid = ms.vorschriftid',
'        AND (bew.benutzerid = :G_BENUTZERID ',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001))',
'    )',
'    WHERE ms.sucheid = :P471_SEARCH_2 ',
'    AND ms.meilenstein = :P471_MILESTONE_2',
'    AND p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1',
'    -- GROUP BY to consolidate multiple themes',
'    GROUP BY ',
'        ms.vorschriftid, ',
'        ms.vorschriftnummer, ',
'        ms.landbezeichnung',
'),',
'regulation_comparison AS (',
'    SELECT ',
'        COALESCE(m1.vorschriftid, m2.vorschriftid) as vorschriftid,',
'        COALESCE(m1.vorschriftnummer, m2.vorschriftnummer) as vorschriftnummer,',
'        COALESCE(m1.landbezeichnung, m2.landbezeichnung) as land,',
'        m1.kritikalitaet as new_criticality,',
'        m2.kritikalitaet as old_criticality,',
'        -- change detection',
'        CASE ',
'            WHEN m1.vorschriftid IS NULL THEN ''entfall''',
'            WHEN m2.vorschriftid IS NULL THEN ''neu'' ',
unistr('            WHEN NVL(m1.kritikalitaet,0) > NVL(m2.kritikalitaet,0) THEN ''kritikalit\00E4t_erh\00F6ht'''),
unistr('            WHEN NVL(m1.kritikalitaet,0) < NVL(m2.kritikalitaet,0) THEN ''kritikalit\00E4t_reduziert'''),
unistr('            WHEN m1.ausgabe_text != m2.ausgabe_text THEN ''text_ge\00E4ndert'''),
unistr('            WHEN m1.et_verwendung != m2.et_verwendung THEN ''bewertung_ge\00E4ndert'''),
'            ELSE ''equal''',
'        END as change_type,',
'        -- visual indicators with detailed tooltips',
'       CASE ',
'            WHEN m1.vorschriftid IS NULL THEN ',
'                ''<span style="color: #e74c3c; font-weight: bold;"><i class="fa fa-minus-circle" title="Vorschrift entfernt in '' || COALESCE(m1.landbezeichnung, m2.landbezeichnung) || ''"></i> Entfall</span>''',
'            WHEN m2.vorschriftid IS NULL THEN ',
unistr('                ''<span style="color: #27ae60; font-weight: bold;"><i class="fa fa-plus-circle" title="Neue Vorschrift hinzugef\00FCgt in '' || COALESCE(m1.landbezeichnung, m2.landbezeichnung) || ''"></i> Neu</span>'''),
'            WHEN NVL(m1.kritikalitaet,0) > NVL(m2.kritikalitaet,0) THEN ',
'                ''<span style="color: #e74c3c; font-weight: bold;"><i class="fa fa-arrow-up" style="color: #fff; background-color: #e74c3c; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; paddin'
||unistr('g: 2px; width: 16px; height: 16px; vertical-align: middle;" title="Kritikalit\00E4t ge\00E4ndert: '' || NVL(m2.kritikalitaet,0) || '' \2192 '' || NVL(m1.kritikalitaet,0) || ''"></i> Kritikalit\00E4t \2197 ('' || '),
unistr('                NVL(m2.kritikalitaet,0) || '' \2192 '' || NVL(m1.kritikalitaet,0) || '')</span>'''),
'            WHEN NVL(m1.kritikalitaet,0) < NVL(m2.kritikalitaet,0) THEN ',
'                ''<span style="color: #27ae60; font-weight: bold;"><i class="fa fa-arrow-down" style="color: #fff; background-color: #27ae60; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padd'
||unistr('ing: 2px; width: 16px; height: 16px; vertical-align: middle;" title="Kritikalit\00E4t ge\00E4ndert: '' || NVL(m2.kritikalitaet,0) || '' \2192 '' || NVL(m1.kritikalitaet,0) || ''"></i> Kritikalit\00E4t \2198 ('' || '),
unistr('                NVL(m2.kritikalitaet,0) || '' \2192 '' || NVL(m1.kritikalitaet,0) || '')</span>'''),
'            WHEN m1.ausgabe_text != m2.ausgabe_text THEN',
unistr('                ''<span style="color: #f39c12; font-weight: bold;"><i class="fa fa-edit" title="Ausgabe Text wurde ge\00E4ndert"></i> Text ge\00E4ndert</span>'''),
'            WHEN m1.et_verwendung != m2.et_verwendung THEN',
unistr('                ''<span style="color: #3498db; font-weight: bold;"><i class="fa fa-exchange" title="ET Verwendung ge\00E4ndert: '' || COALESCE(m2.et_verwendung, ''nicht bewertet'') || '' \2192 '' || COALESCE(m1.et_verwendung, ''nicht bewertet'') || ''"></i> Bewertung')
||unistr(' ge\00E4ndert</span>'''),
unistr('            ELSE ''<span style="color: #95a5a6;"><i class="fa fa-check-circle" title="Keine \00C4nderung"></i> Unver\00E4ndert</span>'''),
'        END as status_display,',
'        -- row CSS class',
'        CASE ',
'            WHEN m1.vorschriftid IS NULL THEN ''country-row-removed''',
'            WHEN m2.vorschriftid IS NULL THEN ''country-row-added'' ',
'            WHEN NVL(m1.kritikalitaet,0) != NVL(m2.kritikalitaet,0) THEN ''country-row-modified''',
'            WHEN m1.ausgabe_text != m2.ausgabe_text THEN ''country-row-modified''',
'            WHEN m1.et_verwendung != m2.et_verwendung THEN ''country-row-modified''',
'            ELSE ''''',
'        END as row_css_class,',
'        -- change indicator with detailed info',
'        CASE ',
'            WHEN m1.vorschriftid IS NULL THEN ',
'                ''<span class="fa fa-minus-circle" style="color: #dc3545; margin-right: 5px; font-size: 16px;" '' ||',
'                ''title="Vorschrift entfernt in '' || COALESCE(m1.landbezeichnung, m2.landbezeichnung) || ''"></span>''',
'            WHEN m2.vorschriftid IS NULL THEN ',
'                ''<span class="fa fa-plus-circle" style="color: #28a745; margin-right: 5px; font-size: 16px;" '' ||',
unistr('                ''title="Neue Vorschrift hinzugef\00FCgt in '' || COALESCE(m1.landbezeichnung, m2.landbezeichnung) || ''"></span>'''),
'            WHEN NVL(m1.kritikalitaet,0) != NVL(m2.kritikalitaet,0) THEN ',
'                ''<span class="fa fa-exclamation-circle" style="color: #ffc107; margin-right: 5px; font-size: 16px;" '' ||',
unistr('                ''title="Kritikalit\00E4t ge\00E4ndert: '' || NVL(m2.kritikalitaet,0) || '' \2192 '' || NVL(m1.kritikalitaet,0) || ''"></span>'''),
'            WHEN m1.ausgabe_text != m2.ausgabe_text THEN',
'                ''<span class="fa fa-edit" style="color: #17a2b8; margin-right: 5px; font-size: 16px;" '' ||',
unistr('                ''title="Ausgabe Text wurde ge\00E4ndert"></span>'''),
'            WHEN m1.et_verwendung != m2.et_verwendung THEN',
'                ''<span class="fa fa-exchange" style="color: #6f42c1; margin-right: 5px; font-size: 16px;" '' ||',
unistr('                ''title="ET Verwendung ge\00E4ndert: '' || COALESCE(m2.et_verwendung, ''nicht bewertet'') || '' \2192 '' || COALESCE(m1.et_verwendung, ''nicht bewertet'') || ''"></span>'''),
'            ELSE ',
'                ''<span class="fa fa-check-circle" style="color: #28a745; margin-right: 5px; font-size: 16px;" '' ||',
unistr('                ''title="Keine \00C4nderung"></span>'''),
'        END as country_change_indicator,',
'        -- mass update blocking logic',
'        CASE ',
'            WHEN EXISTS (',
'                SELECT 1 FROM t_ms_suchergebniss ms_comp',
'                WHERE ms_comp.vorschriftid = COALESCE(m1.vorschriftid, m2.vorschriftid)',
'                AND ms_comp.sucheid = :P471_SEARCH_1',
'                AND ms_comp.meilenstein = :P471_MILESTONE_1',
'                AND ms_comp.manueller_eintrag = 10',
'                AND NOT EXISTS (',
'                    SELECT 1 FROM t_ms_suchergebniss ms_theme',
'                    WHERE ms_theme.vorschriftid = ms_comp.vorschriftid',
'                    AND ms_theme.sucheid = ms_comp.sucheid',
'                    AND ms_theme.meilenstein = ms_comp.meilenstein',
'                    AND ms_theme.themabezeichnung = ms_comp.themabezeichnung',
'                    AND ms_theme.landid != ms_comp.landid',
'                )',
'            ) THEN 1',
'            ELSE 0',
'        END as has_mass_update_conflict,',
'        -- Get additional data from milestones',
'        m1.ausgabe_text,',
'        m2.ausgabe_text as prev_ausgabe_text,',
'        m1.et_verwendung,',
'        m2.et_verwendung as prev_et_verwendung,',
'        m1.et_kommentar,',
'        m2.et_kommentar as prev_et_kommentar,',
'        m1.manueller_eintrag,',
'        m2.manueller_eintrag as prev_manueller_eintrag,',
'        m1.all_themes as current_themes,',
'        m2.all_themes as previous_themes',
'    FROM current_milestone_data m1',
'    FULL OUTER JOIN previous_milestone_data m2 ',
'        ON m1.vorschriftid = m2.vorschriftid ',
'        AND m1.landbezeichnung = m2.landbezeichnung',
')',
'SELECT ',
unistr('    country_change_indicator as "\00C4nderung",'),
'    land as "Land",',
'    ',
'    -- regulation number with clickable link',
'    ''<a href="f?p='' || :APP_ID || '':25:'' || :APP_SESSION || ''::'' || :DEBUG || ',
'    '':RP,25:P25_VORSCHRIFTID:'' || vorschriftid || ''" target="_blank" style="text-decoration: none;">'' ||',
'    vorschriftnummer || ''</a>'' as "Vorschriftennummer",',
'    ',
'    status_display as "Status",',
'    ',
'    -- criticality display with arrows',
'    CASE ',
'        WHEN old_criticality IS NOT NULL AND new_criticality IS NOT NULL THEN',
'            NVL(TO_CHAR(old_criticality), ''-'') || ',
'            CASE ',
'                WHEN new_criticality > old_criticality THEN ',
'                    '' <i class="fa fa-arrow-up" style="color: #fff; background-color: #e74c3c; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padding: 2px; width: 16px; height: 16px; vertical-'
||unistr('align: middle;" title="Kritikalit\00E4t gestiegen: '' || old_criticality || '' \2192 '' || new_criticality || ''"></i> '''),
'                WHEN new_criticality < old_criticality THEN ',
'                    '' <i class="fa fa-arrow-down" style="color: #fff; background-color: #27ae60; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padding: 2px; width: 16px; height: 16px; vertica'
||unistr('l-align: middle;" title="Kritikalit\00E4t gesunken: '' || old_criticality || '' \2192 '' || new_criticality || ''"></i> '''),
'                ELSE ',
unistr('                    '' <i class="fa fa-check-circle" style="color: #95a5a6;" title="Kritikalit\00E4t unver\00E4ndert: '' || old_criticality || ''"></i> '''),
'            END ||',
'            NVL(TO_CHAR(new_criticality), ''-'')',
'        WHEN new_criticality IS NOT NULL THEN',
unistr('            ''<span style="color: #27ae60; font-weight: bold;" title="Neue Vorschrift mit Kritikalit\00E4t '' || new_criticality || ''">Neu: '' || TO_CHAR(new_criticality) || ''</span>'''),
'        WHEN old_criticality IS NOT NULL THEN',
unistr('            ''<span style="color: #e74c3c; font-weight: bold;" title="Vorschrift entfernt, hatte Kritikalit\00E4t '' || old_criticality || ''">Entfallen: '' || TO_CHAR(old_criticality) || ''</span>'''),
'        ELSE ''-''',
unistr('    END as "Kritikalit\00E4t (Vergleich)",'),
'    ',
'    -- Show what was selected in previous milestone (M-1)',
'    CASE ',
'        WHEN prev_et_verwendung IS NOT NULL THEN',
'            CASE prev_et_verwendung',
'                WHEN ''ja'' THEN ''<span style="color: #27ae60;"><i class="fa fa-check"></i> ja</span>''',
'                WHEN ''nein'' THEN ''<span style="color: #e74c3c;"><i class="fa fa-times"></i> nein</span>''',
'                ELSE ''<span style="color: #666;">nicht bewertet</span>''',
'            END',
'        ELSE ''<span style="color: #999;">-</span>''',
unistr('    END as "Ausgew\00E4hlte Vorschrift (M-1)",'),
'    ',
'    -- Show current selection',
'    CASE ',
'        WHEN et_verwendung IS NOT NULL THEN',
'            CASE et_verwendung',
'                WHEN ''ja'' THEN ''<span style="color: #27ae60;"><i class="fa fa-check"></i> ja</span>''',
'                WHEN ''nein'' THEN ''<span style="color: #e74c3c;"><i class="fa fa-times"></i> nein</span>''',
'                ELSE ''<span style="color: #666;">nicht bewertet</span>''',
'            END',
'        ELSE ''<span style="color: #999;">-</span>''',
'    END as "Aktuelle Auswahl",',
'    ',
'    -- duplicate detection with detailed tooltip',
'    CASE ',
'        WHEN EXISTS (',
'            SELECT 1 FROM t_ms_suchergebniss ms_dup1',
'            WHERE ms_dup1.vorschriftid = regulation_comparison.vorschriftid',
'            AND ms_dup1.sucheid = :P471_SEARCH_1 ',
'            AND ms_dup1.meilenstein = :P471_MILESTONE_1',
'            AND ms_dup1.manueller_eintrag = 10  -- Manual entry',
'            AND EXISTS (',
'                SELECT 1 FROM t_ms_suchergebniss ms_dup2',
'                WHERE ms_dup2.vorschriftid = ms_dup1.vorschriftid',
'                AND ms_dup2.sucheid = :P471_SEARCH_1',
'                AND ms_dup2.meilenstein = :P471_MILESTONE_1',
'                AND ms_dup2.manueller_eintrag != 10  -- Automatic entry',
'            )',
'        ) THEN ''<span class="fa fa-exclamation-triangle" style="color: #e74c3c; font-size: 16px; animation: pulse 2s infinite;" '' ||',
'                ''title="Vorschrift doppelt im PRI vorhanden! Manueller und automatischer Eintrag existieren."></span>''',
'        ELSE ''''',
'    END as "Duplikat Warnung",',
'    ',
'    -- Mass update status',
'    CASE ',
'        WHEN has_mass_update_conflict = 1 THEN',
'            ''<span class="fa fa-ban" style="color: #e74c3c; font-size: 16px;" '' ||',
'            ''title="Massenupdate blockiert - Themen-Komposition Konflikt"></span>''',
'        ELSE',
'            ''<span class="fa fa-check" style="color: #28a745; font-size: 16px;" '' ||',
unistr('            ''title="Massenupdate m\00F6glich"></span>'''),
'    END as "Massenupdate Status",',
'    ',
'    -- Entry type indicator',
'    CASE ',
'        WHEN manueller_eintrag = 10 OR prev_manueller_eintrag = 10 THEN',
'            ''<span style="color: #bb0a31;"><i class="fa fa-user-plus"></i> Manuell</span>''',
'        ELSE',
'            ''<span style="color: #666;"><i class="fa fa-cog"></i> Automatisch</span>''',
'    END as "Eintrag Typ",',
'    ',
'    -- Diff summary for milestone -1',
'    CASE ',
'        WHEN change_type = ''neu'' THEN ',
'            ''<span style="background-color: #d4edda; color: #155724; padding: 2px 6px; border-radius: 3px; font-size: 11px;">NEU</span>''',
'        WHEN change_type = ''entfall'' THEN ',
'            ''<span style="background-color: #f8d7da; color: #721c24; padding: 2px 6px; border-radius: 3px; font-size: 11px;">ENTFALL</span>''',
unistr('        WHEN change_type = ''kritikalit\00E4t_erh\00F6ht'' THEN '),
unistr('            ''<span style="background-color: #f8d7da; color: #721c24; padding: 2px 6px; border-radius: 3px; font-size: 11px;">KRIT\2197</span>'''),
unistr('        WHEN change_type = ''kritikalit\00E4t_reduziert'' THEN '),
unistr('            ''<span style="background-color: #d4edda; color: #155724; padding: 2px 6px; border-radius: 3px; font-size: 11px;">KRIT\2198</span>'''),
unistr('        WHEN change_type = ''text_ge\00E4ndert'' THEN '),
'            ''<span style="background-color: #fff3cd; color: #856404; padding: 2px 6px; border-radius: 3px; font-size: 11px;">TEXT</span>''',
unistr('        WHEN change_type = ''bewertung_ge\00E4ndert'' THEN '),
'            ''<span style="background-color: #d1ecf1; color: #0c5460; padding: 2px 6px; border-radius: 3px; font-size: 11px;">BEWERTET</span>''',
'        ELSE ',
'            ''<span style="background-color: #e2e3e5; color: #383d41; padding: 2px 6px; border-radius: 3px; font-size: 11px;">GLEICH</span>''',
'    END as "Diff Meilenstein -1",',
'    ',
'    row_css_class',
'FROM regulation_comparison',
'',
'ORDER BY ',
'    CASE change_type',
'        WHEN ''neu'' THEN 1',
'        WHEN ''entfall'' THEN 2  ',
unistr('        WHEN ''kritikalit\00E4t_erh\00F6ht'' THEN 3'),
unistr('        WHEN ''kritikalit\00E4t_reduziert'' THEN 4'),
unistr('        WHEN ''text_ge\00E4ndert'' THEN 5'),
unistr('        WHEN ''bewertung_ge\00E4ndert'' THEN 6'),
'        ELSE 7',
'    END,',
'    land, ',
'    vorschriftnummer'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P471_SEARCH_1,P471_MILESTONE_1,P471_SEARCH_2,P471_MILESTONE_2'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detaillierter Vorschriftenvergleich'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2315357851363748720)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>5987570167263136955
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964188853162474660)
,p_db_column_name=>'Land'
,p_display_order=>30
,p_column_identifier=>'F'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964188434545474659)
,p_db_column_name=>'Vorschriftennummer'
,p_display_order=>40
,p_column_identifier=>'AB'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964188093167474658)
,p_db_column_name=>'Status'
,p_display_order=>50
,p_column_identifier=>'AC'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964187643137474658)
,p_db_column_name=>unistr('\00C4nderung')
,p_display_order=>90
,p_column_identifier=>'AK'
,p_column_label=>unistr('\00C4nderung')
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964187267610474657)
,p_db_column_name=>'ROW_CSS_CLASS'
,p_display_order=>100
,p_column_identifier=>'AL'
,p_column_label=>'Row Css Class'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964186848342474657)
,p_db_column_name=>unistr('Kritikalit\00E4t (Vergleich)')
,p_display_order=>110
,p_column_identifier=>'AM'
,p_column_label=>unistr('Kritikalit\00E4t (vergleich)')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964186450726474656)
,p_db_column_name=>unistr('Ausgew\00E4hlte Vorschrift (M-1)')
,p_display_order=>120
,p_column_identifier=>'AN'
,p_column_label=>unistr('Ausgew\00E4hlte Vorschrift (m-1)')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964186114317474655)
,p_db_column_name=>'Aktuelle Auswahl'
,p_display_order=>130
,p_column_identifier=>'AO'
,p_column_label=>'Aktuelle Auswahl'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964185673866474655)
,p_db_column_name=>'Duplikat Warnung'
,p_display_order=>140
,p_column_identifier=>'AP'
,p_column_label=>'Duplikat Warnung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964185247258474654)
,p_db_column_name=>'Massenupdate Status'
,p_display_order=>150
,p_column_identifier=>'AQ'
,p_column_label=>'Massenupdate Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964184829638474654)
,p_db_column_name=>'Eintrag Typ'
,p_display_order=>160
,p_column_identifier=>'AR'
,p_column_label=>'Eintrag Typ'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964184492497474653)
,p_db_column_name=>'Diff Meilenstein -1'
,p_display_order=>170
,p_column_identifier=>'AS'
,p_column_label=>'Diff Meilenstein -1'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2315469031233329803)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5719595'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('Land:Vorschriftennummer:Status:\00C4nderung:Aktuelle Auswahl:Ausgew\00E4hlte Vorschrift (M-1):Diff Meilenstein -1:Duplikat Warnung:Eintrag Typ:Kritikalit\00E4t (Vergleich):Massenupdate Status:')
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2316269344223162422)
,p_plug_name=>'Eintrag-Typen'
,p_region_name=>'lEntryTypeLegend'
,p_region_template_options=>'#DEFAULT#:margin-bottom-sm'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>150
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="entry-type-legend" style="background: #e8f5e9; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #4caf50;">',
'    <strong>Eintrag-Typen:</strong>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-user-plus" style="color: #bb0a31; font-size: 14px; vertical-align: middle;"></i> ',
'        Manueller Eintrag',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-cog" style="color: #bb0a31; font-size: 14px; vertical-align: middle;"></i> ',
'        Automatischer Eintrag',
'    </span>',
'</div>'))
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2316269492034162423)
,p_plug_name=>'Warnungs-Indikatoren'
,p_region_name=>'lWarningLegend'
,p_region_template_options=>'#DEFAULT#:margin-bottom-sm'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>140
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="warning-legend" style="background: #fff3cd; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #ffc107;">',
'    <strong>Warnungs-Indikatoren:</strong>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-exclamation-circle" style="color: #ffc107; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        Kritikalit\00E4t ge\00E4ndert'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-exclamation-triangle" style="color: #e74c3c; font-size: 14px; vertical-align: middle;"></i> ',
'        Duplikat vorhanden',
'    </span>',
'</div>'))
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2316269536039162424)
,p_plug_name=>'Bewertungs-Status'
,p_region_name=>'lEvaluationLegend'
,p_region_template_options=>'#DEFAULT#:margin-bottom-sm'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>160
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="evaluation-legend" style="background: #f3e5f5; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #9c27b0;">',
'    <strong>Bewertungs-Status:</strong>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-check" style="color: #27ae60; font-weight: bold; vertical-align: middle;"></i> ',
'        <span style="color: #27ae60; font-weight: bold;">ja</span>',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-times" style="color: #e74c3c; font-weight: bold; vertical-align: middle;"></i> ',
'        <span style="color: #e74c3c; font-weight: bold;">nein</span>',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <span style="color: #666; font-style: italic;">nicht bewertet</span>',
'    </span>',
'</div>'))
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2316269684537162425)
,p_plug_name=>'Massenupdate-Status'
,p_region_name=>'lMassUpdateLegend'
,p_region_template_options=>'#DEFAULT#:margin-bottom-sm'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>170
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="mass-update-legend" style="background: #fce4ec; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #e91e63;">',
'    <strong>Massenupdate-Status:</strong>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-check" style="color: #28a745; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        Massenupdate m\00F6glich'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-ban" style="color: #e74c3c; font-size: 14px; vertical-align: middle;"></i> ',
'        Massenupdate blockiert',
'    </span>',
'</div>'))
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2889261808213923514)
,p_plug_name=>'Status-Indikatoren'
,p_region_name=>'lStatusLegend'
,p_region_template_options=>'#DEFAULT#:margin-bottom-sm'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>130
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="status-legend" style="background: #e3f2fd; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #2196f3;">',
'    <strong>Status-Indikatoren:</strong>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-minus-circle" style="color: #e74c3c; font-size: 14px; vertical-align: middle;"></i> ',
'        Entfall',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-plus-circle" style="color: #27ae60; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        Neu hinzugef\00FCgt'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-arrow-up" style="color: #fff; background-color: #e74c3c; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padding: 2px; width: 16px; height: 16px; vertical-align: middle;'
||'"></i> ',
unistr('        Kritikalit\00E4t gestiegen'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-arrow-down" style="color: #fff; background-color: #27ae60; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padding: 2px; width: 16px; height: 16px; vertical-align: middl'
||'e;"></i> ',
unistr('        Kritikalit\00E4t gesunken'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-edit" style="color: #f39c12; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        Text ge\00E4ndert'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-exchange" style="color: #3498db; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        Bewertung ge\00E4ndert'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-check-circle" style="color: #95a5a6; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        Unver\00E4ndert'),
'    </span>',
'</div>',
'',
'',
'',
'',
'<!-- <div class="criticality-legend" style="background: #e3f2fd; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #2196f3;">',
unistr('    <strong>Kritikalit\00E4ts-Indikatoren:</strong>'),
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-arrow-up" style="color: #fff; background-color: #e74c3c; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padding: 2px; width: 16px; height: 16px; vertical-align: middle;'
||'"></i> ',
'        Gestiegen',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-arrow-down" style="color: #fff; background-color: #27ae60; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padding: 2px; width: 16px; height: 16px; vertical-align: middl'
||'e;"></i> ',
'        Gesunken',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-check-circle" style="color: #95a5a6; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        Unver\00E4ndert'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-plus-circle" style="color: #27ae60; font-size: 14px; vertical-align: middle;"></i> ',
'        Neu',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-edit" style="color: #f39c12; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        Text ge\00E4ndert'),
'    </span>',
'</div> -->',
''))
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964195731652474675)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2314681557365574022)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964192125494474665)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2315356949875748711)
,p_button_name=>'BTN_MASTER_DATA_COMPARISON'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Stammdaten vergleichen'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa fa-database'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964191787872474664)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2315356949875748711)
,p_button_name=>'BTN_TRANSFER_MANUAL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('Manuelle Eintr\00E4ge \00FCbertragen')
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa fa-arrow-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964183739421474652)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2315357799294748719)
,p_button_name=>'BTN_SHOW_LEGENDS'
,p_button_static_id=>'B577439449482037513'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'Legende anzeigen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:475:&SESSION.::&DEBUG.:475:P475_SEARCH_SELECTION,P475_MILESTONE_SELECTION,P475_CARD_NUM,P475_SOURCE_PAGE:&P471_SEARCH_1.,&P471_MILESTONE_1.,&P471_CARD_NUM.,471'
,p_icon_css_classes=>'fa-info-circle-o'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(964168560598474639)
,p_branch_name=>'Return to Page 461'
,p_branch_action=>'f?p=&APP_ID.:461:&SESSION.::&DEBUG.:461:P461_SEARCH_SELECTION,P461_MILESTONE_SELECTION:&P471_SEARCH_1.,&P470_MILESTONE_1.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964192864133474667)
,p_name=>'P471_SHOW_ALL_CHANGES'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2315151947834179724)
,p_item_default=>'N'
,p_prompt=>'Anzeige'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Alle Daten',
  'off_value', 'Y',
  'on_label', unistr('Nur ge\00E4nderte Daten'),
  'on_value', 'N',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964191018239474664)
,p_name=>'P471_SEARCH_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2315149473716179699)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'lov ',
'',
'SELECT',
'    tsj.bezeichnung AS d,',
'    tsj.sucheid AS r',
'FROM',
'    t_suche_json tsj',
'WHERE',
'    tsj.manuelle_speicherung > 0',
'    AND (',
'        tsj.benutzerid = :G_BENUTZERID OR',
'        EXISTS (',
'            SELECT 1',
'            FROM t_benutzer_ref_rolle brr',
'            WHERE brr.benutzerid = :G_BENUTZERID AND brr.rolleid = 1001',
'        )',
'    )',
'ORDER BY',
'    tsj.zeitpunkt DESC'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964190696466474663)
,p_name=>'P471_MILESTONE_1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2315149473716179699)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH json_data AS (',
'    SELECT suchdaten',
'    FROM t_suche_json',
'    WHERE sucheid = :P471_SEARCH_1',
')',
'SELECT',
'    ''Meilenstein '' || j.meilenstein as d,',
'    j.meilenstein as r',
'FROM',
'    json_data,',
'    JSON_TABLE(',
'        suchdaten,',
'        ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN''',
'        )',
'    ) j',
'WHERE',
'    j.meilenstein IS NOT NULL',
'ORDER BY',
'    j.meilenstein DESC'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964189977361474663)
,p_name=>'P471_SEARCH_2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2315149539779179700)
,p_prompt=>'Vergleichsmeilenstein (Suche)'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    tsj.bezeichnung AS d,',
'    tsj.sucheid AS r',
'FROM',
'    t_suche_json tsj',
'WHERE',
'    tsj.manuelle_speicherung > 0',
'    AND (',
'        tsj.benutzerid = :G_BENUTZERID OR',
'        EXISTS (',
'            SELECT 1',
'            FROM t_benutzer_ref_rolle brr',
'            WHERE brr.benutzerid = :G_BENUTZERID AND brr.rolleid = 1001',
'        )',
'    )',
'ORDER BY',
'    tsj.zeitpunkt DESC'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- ausw\00E4hlen --')
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964189604123474662)
,p_name=>'P471_MILESTONE_2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2315149539779179700)
,p_prompt=>'Meilenstein'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH json_data AS (',
'    SELECT suchdaten',
'    FROM t_suche_json',
'    WHERE sucheid = :P471_SEARCH_2',
')',
'SELECT',
'    ''Meilenstein '' || j.meilenstein as d,',
'    j.meilenstein as r',
'FROM',
'    json_data,',
'    JSON_TABLE(',
'        suchdaten,',
'        ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN''',
'        )',
'    ) j',
'WHERE',
'    j.meilenstein IS NOT NULL',
'ORDER BY',
'    j.meilenstein DESC'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- ausw\00E4hlen --')
,p_lov_cascade_parent_items=>'P471_SEARCH_2'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964181902250474648)
,p_name=>'P471_CARD_NUM'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(951938257209316307)
,p_name=>'P471_SEARCH_1_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2315149473716179699)
,p_prompt=>'Aktueller Meilenstein (Suche)'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'readonly="readonly" style="background-color:#f0f0f0;"'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(951938193997316306)
,p_name=>'P471_MILESTONE_1_NAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2315149473716179699)
,p_prompt=>'Meilenstein'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'readonly="readonly" style="background-color:#f0f0f0;"'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964179108439474644)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(964195731652474675)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964178598189474644)
,p_event_id=>wwv_flow_imp.id(964179108439474644)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964178131426474644)
,p_name=>'Refresh Master Data Comparison Results Report'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(964192125494474665)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(apex.item("P471_SEARCH_1").getValue() !== '''' && ',
' apex.item("P471_MILESTONE_1").getValue() !== '''' && ',
' apex.item("P471_SEARCH_2").getValue() !== '''' && ',
' apex.item("P471_MILESTONE_2").getValue() !== '''')'))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964177713090474643)
,p_event_id=>wwv_flow_imp.id(964178131426474644)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2315151947834179724)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964177187565474643)
,p_event_id=>wwv_flow_imp.id(964178131426474644)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2315357799294748719)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964176687406474643)
,p_event_id=>wwv_flow_imp.id(964178131426474644)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2315357799294748719)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964176186712474642)
,p_event_id=>wwv_flow_imp.id(964178131426474644)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2315151947834179724)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964175710849474642)
,p_event_id=>wwv_flow_imp.id(964178131426474644)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Show all legend regions',
'   $(''#lStatusLegend, #lWarningLegend, #lEvaluationLegend, #lMassUpdateLegend, #lEntryTypeLegend'').show();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964175122024474642)
,p_event_id=>wwv_flow_imp.id(964178131426474644)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2315151947834179724)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964174617399474642)
,p_event_id=>wwv_flow_imp.id(964178131426474644)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2315357799294748719)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964174164977474642)
,p_event_id=>wwv_flow_imp.id(964178131426474644)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Validate cross-search after refresh',
'validateCrossSearchComparison();',
'updateColumnHeaders();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964173804644474641)
,p_name=>'Show / Hide Report'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(964192125494474665)
,p_condition_element=>'P471_MILESTONE_2'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964173276196474641)
,p_event_id=>wwv_flow_imp.id(964173804644474641)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2315151947834179724)
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964172723122474641)
,p_event_id=>wwv_flow_imp.id(964173804644474641)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2315151947834179724)
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964172327291474641)
,p_name=>'Enable/Disable Master Data Button'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P471_SEARCH_1,P471_MILESTONE_1,P471_SEARCH_2,P471_MILESTONE_2'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(apex.item("P471_SEARCH_1").getValue() !== '''' && ',
' apex.item("P471_MILESTONE_1").getValue() !== '''' && ',
' apex.item("P471_SEARCH_2").getValue() !== '''' && ',
' apex.item("P471_MILESTONE_2").getValue() !== '''')'))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964171896071474640)
,p_event_id=>wwv_flow_imp.id(964172327291474641)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(964192125494474665)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964171323527474640)
,p_event_id=>wwv_flow_imp.id(964172327291474641)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(964192125494474665)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964170936118474640)
,p_name=>'Refresh when Change P471_SHOW_ALL_CHANGES'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P471_SHOW_ALL_CHANGES'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964170494451474640)
,p_event_id=>wwv_flow_imp.id(964170936118474640)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2315151947834179724)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964170010359474640)
,p_event_id=>wwv_flow_imp.id(964170936118474640)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Wait for refresh to complete, then update headers',
'   setTimeout(function() {',
'       updateColumnHeaders();',
'   }, 200);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964169527678474639)
,p_name=>'Transfer Manual Entries'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(964191787872474664)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964169037958474639)
,p_event_id=>wwv_flow_imp.id(964169527678474639)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'transferManualEntries();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964181470955474648)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Search 1 and Milestone 1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- 1. Set current values from Page 461 into Hidden ID items (for logic)',
'    :P471_SEARCH_1 := :P461_SEARCH_SELECTION;',
'    :P471_MILESTONE_1 := :P461_MILESTONE_SELECTION;',
'    :P471_CARD_NUM := :P461_CARD_NUM;',
'    ',
'    -- 2. Populate the Visible Text Fields (for the User to see)',
'    -- Get Search Name',
'    BEGIN',
'        SELECT bezeichnung ',
'        INTO :P471_SEARCH_1_NAME',
'        FROM t_suche_json ',
'        WHERE sucheid = :P471_SEARCH_1;',
'    EXCEPTION ',
'        WHEN NO_DATA_FOUND THEN ',
'            :P471_SEARCH_1_NAME := ''Suche '' || :P471_SEARCH_1;',
'    END;',
'',
'    -- Get Milestone Name',
'    :P471_MILESTONE_1_NAME := ''Meilenstein '' || :P471_MILESTONE_1;',
'',
'    -- 3. Set comparison search to same search by default',
'    :P471_SEARCH_2 := :P461_SEARCH_SELECTION;',
'    ',
'    -- 4. Milestone comparison logic - focus on M-1',
'    IF :P471_MILESTONE_1 IS NOT NULL AND :P471_SEARCH_2 IS NOT NULL THEN',
'        DECLARE',
'            l_current_milestone NUMBER := TO_NUMBER(:P471_MILESTONE_1);',
'            l_target_milestone NUMBER := l_current_milestone - 1; -- Always try M-1 first',
'            l_milestone_exists NUMBER := 0;',
'        BEGIN',
'            -- Check if M-1 exists in the data',
'            SELECT COUNT(*)',
'            INTO l_milestone_exists',
'            FROM t_suche_json tsj,',
'            JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'                meilenstein NUMBER PATH ''$.MEILENSTEIN''',
'            )) j',
'            WHERE tsj.sucheid = :P471_SEARCH_2',
'            AND j.meilenstein = l_target_milestone;',
'            ',
'            -- If M-1 exists, use it (this is the main requirement)',
'            IF l_milestone_exists > 0 THEN',
'                :P471_MILESTONE_2 := l_target_milestone;',
'            ELSE',
'                -- If M-1 doesn''t exist, leave P471_MILESTONE_2 as NULL',
'                -- This forces user to manually select what they want to compare',
'                :P471_MILESTONE_2 := NULL;',
'                ',
'                -- Log',
'                apex_debug.info(''Milestone M-1 (%s) not found for search %s. User must manually select comparison milestone.'', ',
'                               l_target_milestone, :P471_SEARCH_2);',
'            END IF;',
'            ',
'            -- Auto-transfer card configuration ONLY if we found M-1',
'            IF :P471_MILESTONE_2 IS NOT NULL THEN',
'                DECLARE',
'                    l_current_search NUMBER := TO_NUMBER(:P471_SEARCH_1);',
'                    l_current_milestone_num NUMBER := TO_NUMBER(:P471_MILESTONE_1);',
'                    l_previous_milestone NUMBER := TO_NUMBER(:P471_MILESTONE_2);',
'                    l_transferred_count NUMBER := 0;',
'                BEGIN',
'                    -- Transfer card configuration from M-1 to current milestone',
'                    INSERT INTO t_ms_suche_split (',
'                        sucheid, meilenstein, landid, card_number, benutzerid, ',
'                        letzte_aenderung_datum',
'                    )',
'                    SELECT ',
'                        l_current_search, l_current_milestone_num, landid, card_number, benutzerid,',
'                        SYSDATE',
'                    FROM t_ms_suche_split',
'                    WHERE sucheid = l_current_search',
'                    AND meilenstein = l_previous_milestone',
'                    AND NOT EXISTS (',
'                        SELECT 1 FROM t_ms_suche_split s2',
'                        WHERE s2.sucheid = l_current_search',
'                        AND s2.meilenstein = l_current_milestone_num',
'                        AND s2.landid = t_ms_suche_split.landid',
'                        AND s2.card_number = t_ms_suche_split.card_number',
'                    );',
'                    ',
'                    l_transferred_count := SQL%ROWCOUNT;',
'                    COMMIT;',
'                    ',
'                    apex_debug.info(''Card configuration transfer: %s records transferred from M%s to M%s'', ',
'                                   l_transferred_count, l_previous_milestone, l_current_milestone_num);',
'                EXCEPTION',
'                    WHEN OTHERS THEN',
'                        apex_debug.error(''Card configuration transfer failed: %s'', SQLERRM);',
'                        -- Continue execution ',
'                END;',
'            END IF;',
'            ',
'        EXCEPTION',
'            WHEN OTHERS THEN',
'                apex_debug.error(''Error in milestone selection logic: %s'', SQLERRM);',
'                -- Leave P471_MILESTONE_2 as NULL - user must select manually',
'                :P471_MILESTONE_2 := NULL;',
'        END;',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2708030844943913587
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(951938070448316305)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Search 1 and Milestone 1_BAckup'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Set current milestone values from Page 461',
'    :P471_SEARCH_1 := :P461_SEARCH_SELECTION;',
'    :P471_MILESTONE_1 := :P461_MILESTONE_SELECTION;',
'    :P471_CARD_NUM := :P461_CARD_NUM;',
'    ',
'    -- Enhanced milestone selection logic - stay within same search',
'    IF :P471_SEARCH_1 IS NOT NULL THEN',
'        DECLARE',
'            l_current_milestone NUMBER := TO_NUMBER(:P471_MILESTONE_1);',
'            l_target_milestone NUMBER;',
'            l_target_search NUMBER;',
'            l_milestone_exists NUMBER := 0;',
'        BEGIN',
'            -- Always try same search first (this is the main requirement)',
'            l_target_search := TO_NUMBER(:P471_SEARCH_1);',
'            l_target_milestone := l_current_milestone - 1;',
'            ',
'            -- Check if M-1 exists in same search',
'            SELECT COUNT(*)',
'            INTO l_milestone_exists',
'            FROM t_suche_json tsj,',
'            JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'                meilenstein NUMBER PATH ''$.MEILENSTEIN''',
'            )) j',
'            WHERE tsj.sucheid = l_target_search',
'            AND j.meilenstein = l_target_milestone;',
'            ',
'            IF l_milestone_exists > 0 THEN',
'                -- M-1 exists in same search - use it',
'                :P471_SEARCH_2 := l_target_search;',
'                :P471_MILESTONE_2 := l_target_milestone;',
'                apex_debug.info(''Using same search %s, milestone M-1: %s'', l_target_search, l_target_milestone);',
'                ',
'                -- Transfer card configuration for same-search comparison',
'                DECLARE',
'                    l_current_search NUMBER := TO_NUMBER(:P471_SEARCH_1);',
'                    l_current_milestone_num NUMBER := TO_NUMBER(:P471_MILESTONE_1);',
'                    l_previous_milestone NUMBER := TO_NUMBER(:P471_MILESTONE_2);',
'                    l_transferred_count NUMBER := 0;',
'                BEGIN',
'                    INSERT INTO t_ms_suche_split (',
'                        sucheid, meilenstein, landid, card_number, benutzerid, ',
'                        letzte_aenderung_datum',
'                    )',
'                    SELECT ',
'                        l_current_search, l_current_milestone_num, landid, card_number, benutzerid,',
'                        SYSDATE',
'                    FROM t_ms_suche_split',
'                    WHERE sucheid = l_current_search',
'                    AND meilenstein = l_previous_milestone',
'                    AND NOT EXISTS (',
'                        SELECT 1 FROM t_ms_suche_split s2',
'                        WHERE s2.sucheid = l_current_search',
'                        AND s2.meilenstein = l_current_milestone_num',
'                        AND s2.landid = t_ms_suche_split.landid',
'                        AND s2.card_number = t_ms_suche_split.card_number',
'                    );',
'                    ',
'                    l_transferred_count := SQL%ROWCOUNT;',
'                    COMMIT;',
'                    apex_debug.info(''Card configuration transfer: %s records transferred'', l_transferred_count);',
'                EXCEPTION',
'                    WHEN OTHERS THEN',
'                        apex_debug.error(''Card configuration transfer failed: %s'', SQLERRM);',
'                END;',
'            ELSE',
'                -- M-1 doesn''t exist in same search - stay with same search but NULL milestone',
'                -- This allows user to manually select any available milestone',
'                :P471_SEARCH_2 := l_target_search;  -- SAME search, not different',
'                :P471_MILESTONE_2 := NULL;          -- Let user choose milestone',
'                apex_debug.info(''M-1 does not exist. Keeping same search %s, milestone set to NULL for manual selection'', l_target_search);',
'            END IF;',
'            ',
'        EXCEPTION',
'            WHEN OTHERS THEN',
'                apex_debug.error(''Error in milestone selection logic: %s'', SQLERRM);',
'                -- Fallback: same search, NULL milestone',
'                :P471_SEARCH_2 := :P471_SEARCH_1;',
'                :P471_MILESTONE_2 := NULL;',
'        END;',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2720274245451071930
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964179869357474645)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Search 1 and Milestone 1_2'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Set current milestone values from Page 461',
'    :P471_SEARCH_1 := :P461_SEARCH_SELECTION;',
'    :P471_MILESTONE_1 := :P461_MILESTONE_SELECTION;',
'    :P471_CARD_NUM := :P461_CARD_NUM;',
'    ',
'    -- Set comparison search to same search by default',
'    :P471_SEARCH_2 := :P461_SEARCH_SELECTION;',
'    ',
'    -- Milestone comparison logic - focus on M-1',
'    IF :P471_MILESTONE_1 IS NOT NULL AND :P471_SEARCH_2 IS NOT NULL THEN',
'        DECLARE',
'            l_current_milestone NUMBER := TO_NUMBER(:P471_MILESTONE_1);',
'            l_target_milestone NUMBER := l_current_milestone - 1; -- Always try M-1 first',
'            l_milestone_exists NUMBER := 0;',
'        BEGIN',
'            -- Check if M-1 exists in the data',
'            SELECT COUNT(*)',
'            INTO l_milestone_exists',
'            FROM t_suche_json tsj,',
'            JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'                meilenstein NUMBER PATH ''$.MEILENSTEIN''',
'            )) j',
'            WHERE tsj.sucheid = :P471_SEARCH_2',
'            AND j.meilenstein = l_target_milestone;',
'            ',
'            -- If M-1 exists, use it (this is the main requirement)',
'            IF l_milestone_exists > 0 THEN',
'                :P471_MILESTONE_2 := l_target_milestone;',
'            ELSE',
'                -- If M-1 doesn''t exist, leave P471_MILESTONE_2 as NULL',
'                -- This forces user to manually select what they want to compare',
'                :P471_MILESTONE_2 := NULL;',
'                ',
'                -- Log',
'                apex_debug.info(''Milestone M-1 (%s) not found for search %s. User must manually select comparison milestone.'', ',
'                               l_target_milestone, :P471_SEARCH_2);',
'            END IF;',
'            ',
'            -- Auto-transfer card configuration ONLY if we found M-1',
'            IF :P471_MILESTONE_2 IS NOT NULL THEN',
'                DECLARE',
'                    l_current_search NUMBER := TO_NUMBER(:P471_SEARCH_1);',
'                    l_current_milestone_num NUMBER := TO_NUMBER(:P471_MILESTONE_1);',
'                    l_previous_milestone NUMBER := TO_NUMBER(:P471_MILESTONE_2);',
'                    l_transferred_count NUMBER := 0;',
'                BEGIN',
'                    -- Transfer card configuration from M-1 to current milestone',
'                    INSERT INTO t_ms_suche_split (',
'                        sucheid, meilenstein, landid, card_number, benutzerid, ',
'                        letzte_aenderung_datum',
'                    )',
'                    SELECT ',
'                        l_current_search, l_current_milestone_num, landid, card_number, benutzerid,',
'                        SYSDATE',
'                    FROM t_ms_suche_split',
'                    WHERE sucheid = l_current_search',
'                    AND meilenstein = l_previous_milestone',
'                    AND NOT EXISTS (',
'                        SELECT 1 FROM t_ms_suche_split s2',
'                        WHERE s2.sucheid = l_current_search',
'                        AND s2.meilenstein = l_current_milestone_num',
'                        AND s2.landid = t_ms_suche_split.landid',
'                        AND s2.card_number = t_ms_suche_split.card_number',
'                    );',
'                    ',
'                    l_transferred_count := SQL%ROWCOUNT;',
'                    COMMIT;',
'                    ',
'                    apex_debug.info(''Card configuration transfer: %s records transferred from M%s to M%s'', ',
'                                   l_transferred_count, l_previous_milestone, l_current_milestone_num);',
'                EXCEPTION',
'                    WHEN OTHERS THEN',
'                        apex_debug.error(''Card configuration transfer failed: %s'', SQLERRM);',
'                        -- Continue execution ',
'                END;',
'            END IF;',
'            ',
'        EXCEPTION',
'            WHEN OTHERS THEN',
'                apex_debug.error(''Error in milestone selection logic: %s'', SQLERRM);',
'                -- Leave P471_MILESTONE_2 as NULL - user must select manually',
'                :P471_MILESTONE_2 := NULL;',
'        END;',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2708032446541913590
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964181034717474647)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'TRANSFER_MANUAL_ENTRIES'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_current_search NUMBER := TO_NUMBER(apex_application.g_x01);    -- Target search',
'    l_current_milestone NUMBER := TO_NUMBER(apex_application.g_x02); -- Target milestone',
'    l_previous_milestone NUMBER := TO_NUMBER(apex_application.g_x03); -- Source milestone',
'    l_source_search NUMBER := TO_NUMBER(apex_application.g_x04);     -- Source search (NEW)',
'    l_transferred_count NUMBER := 0;',
'    l_conflict_count NUMBER := 0;',
'BEGIN',
'    FOR manual_entry IN (',
'        SELECT DISTINCT',
'            ms.vorschriftid,',
'            ms.landid,',
'            ms.themabezeichnung,',
'            ms.vorschriftnummer,',
'            ms.regelnummer,',
'            bew.et_verwendung,',
'            bew.et_vorschlag_vorschrift,',
'            bew.et_kommentar',
'        FROM t_ms_suchergebniss ms',
'        LEFT JOIN t_ms_bewertung bew ON (',
'            bew.sucheid = ms.sucheid',
'            AND bew.meilenstein = ms.meilenstein',
'            AND bew.vorschriftid = CASE ',
'                WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'                ELSE ms.vorschriftid',
'            END',
'            AND (bew.benutzerid = :G_BENUTZERID ',
'                 OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                            WHERE brr.benutzerid = :G_BENUTZERID ',
'                            AND brr.rolleid = 1001))',
'        )',
'        WHERE ms.sucheid = l_source_search        -- Use source search parameter',
'        AND ms.meilenstein = l_previous_milestone -- Use source milestone parameter',
'        AND ms.manueller_eintrag = 10',
'    ) LOOP',
'        DECLARE',
'            l_exists NUMBER := 0;',
'        BEGIN',
'            SELECT COUNT(*)',
'            INTO l_exists',
'            FROM t_ms_suchergebniss',
'            WHERE sucheid = l_current_search      -- Target search',
'            AND meilenstein = l_current_milestone -- Target milestone',
'            AND vorschriftid = manual_entry.vorschriftid',
'            AND landid = manual_entry.landid;',
'            ',
'            IF l_exists > 0 THEN',
'                l_conflict_count := l_conflict_count + 1;',
'            ELSE',
'                INSERT INTO t_ms_suchergebniss (',
'                    sucheid, meilenstein, landid, vorschriftid,',
'                    themabezeichnung, vorschriftnummer, regelnummer,',
'                    manueller_eintrag, ',
'                    letzte_aenderung_datum',
'                ) VALUES (',
'                    l_current_search, l_current_milestone, manual_entry.landid, manual_entry.vorschriftid,',
'                    manual_entry.themabezeichnung, manual_entry.vorschriftnummer, manual_entry.regelnummer,',
'                    10, ',
'                    SYSDATE',
'                );',
'                ',
'                IF manual_entry.et_verwendung IS NOT NULL THEN',
'                    INSERT INTO t_ms_bewertung (',
'                        benutzerid, sucheid, meilenstein, vorschriftid,',
'                        et_verwendung, et_vorschlag_vorschrift, et_kommentar,',
'                        letzte_aenderung_datum',
'                    ) VALUES (',
'                        :G_BENUTZERID, l_current_search, l_current_milestone, manual_entry.vorschriftid,',
'                        manual_entry.et_verwendung, manual_entry.et_vorschlag_vorschrift, ',
unistr('                        ''\00DCbertragen aus Suche '' || l_source_search || '' Meilenstein '' || l_previous_milestone || '': '' || manual_entry.et_kommentar,'),
'                        SYSDATE',
'                    );',
'                END IF;',
'                ',
'                l_transferred_count := l_transferred_count + 1;',
'            END IF;',
'        END;',
'    END LOOP;',
'    ',
'    COMMIT;',
'    ',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
unistr('    apex_json.write(''message'', l_transferred_count || '' manuelle Eintr\00E4ge \00FCbertragen'');'),
'    apex_json.write(''transferred'', l_transferred_count);',
'    apex_json.write(''conflicts'', l_conflict_count);',
'    apex_json.close_object;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
unistr('        apex_json.write(''message'', ''Fehler beim \00DCbertragen: '' || SQLERRM);'),
'        apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2708031281181913588
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964180654023474646)
,p_process_sequence=>30
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'TRANSFER_CARD_CONFIG'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'DECLARE',
'    l_current_search NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_current_milestone NUMBER := TO_NUMBER(apex_application.g_x02);',
'    l_previous_milestone NUMBER := l_current_milestone - 1;',
'    l_transferred_count NUMBER := 0;',
'BEGIN',
'    -- Transfer card configuration from previous milestone',
'    INSERT INTO t_ms_suche_split (',
'        sucheid, meilenstein, landid, card_number, benutzerid, ',
'        letzte_aenderung_datum',
'    )',
'    SELECT ',
'        l_current_search, l_current_milestone, landid, card_number, benutzerid,',
'        SYSDATE',
'    FROM t_ms_suche_split',
'    WHERE sucheid = l_current_search',
'    AND meilenstein = l_previous_milestone',
'    AND NOT EXISTS (',
'        SELECT 1 FROM t_ms_suche_split s2',
'        WHERE s2.sucheid = l_current_search',
'        AND s2.meilenstein = l_current_milestone',
'        AND s2.landid = t_ms_suche_split.landid',
'        AND s2.card_number = t_ms_suche_split.card_number',
'    );',
'    ',
'    l_transferred_count := SQL%ROWCOUNT;',
'    COMMIT;',
'    ',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
'    apex_json.write(''transferred'', l_transferred_count);',
'    apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2708031661875913589
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964180255956474646)
,p_process_sequence=>40
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'VALIDATE_CROSS_SEARCH'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_search1 NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_milestone1 NUMBER := TO_NUMBER(apex_application.g_x02);',
'    l_search2 NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_milestone2 NUMBER := TO_NUMBER(apex_application.g_x04);',
'    ',
'    l_search1_countries VARCHAR2(4000);',
'    l_search2_countries VARCHAR2(4000);',
'    l_search1_themes VARCHAR2(4000);',
'    l_search2_themes VARCHAR2(4000);',
'    l_search1_name VARCHAR2(500);',
'    l_search2_name VARCHAR2(500);',
'    l_country_overlap NUMBER := 0;',
'    l_theme_overlap NUMBER := 0;',
'BEGIN',
'    -- Get search names',
'    SELECT bezeichnung INTO l_search1_name ',
'    FROM t_suche_json WHERE sucheid = l_search1;',
'    ',
'    SELECT bezeichnung INTO l_search2_name ',
'    FROM t_suche_json WHERE sucheid = l_search2;',
'    ',
'    -- Get countries from both searches',
'    BEGIN',
'        SELECT j.laender INTO l_search1_countries',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            laender VARCHAR2(4000) PATH ''$.LAENDER''',
'        )) j',
'        WHERE tsj.sucheid = l_search1',
'        AND j.meilenstein = l_milestone1',
'        AND ROWNUM = 1;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN l_search1_countries := '''';',
'    END;',
'    ',
'    BEGIN',
'        SELECT j.laender INTO l_search2_countries',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            laender VARCHAR2(4000) PATH ''$.LAENDER''',
'        )) j',
'        WHERE tsj.sucheid = l_search2',
'        AND j.meilenstein = l_milestone2',
'        AND ROWNUM = 1;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN l_search2_countries := '''';',
'    END;',
'    ',
'    -- Get themes from both searches',
'    BEGIN',
'        SELECT j.themen INTO l_search1_themes',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            themen VARCHAR2(4000) PATH ''$.THEMEN''',
'        )) j',
'        WHERE tsj.sucheid = l_search1',
'        AND j.meilenstein = l_milestone1',
'        AND ROWNUM = 1;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN l_search1_themes := '''';',
'    END;',
'    ',
'    BEGIN',
'        SELECT j.themen INTO l_search2_themes',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            themen VARCHAR2(4000) PATH ''$.THEMEN''',
'        )) j',
'        WHERE tsj.sucheid = l_search2',
'        AND j.meilenstein = l_milestone2',
'        AND ROWNUM = 1;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN l_search2_themes := '''';',
'    END;',
'    ',
'    -- Calculate overlaps',
'    SELECT COUNT(*) INTO l_country_overlap',
'    FROM (',
'        SELECT column_value FROM TABLE(apex_string.split(l_search1_countries, '':''))',
'        INTERSECT',
'        SELECT column_value FROM TABLE(apex_string.split(l_search2_countries, '':''))',
'    );',
'    ',
'    SELECT COUNT(*) INTO l_theme_overlap',
'    FROM (',
'        SELECT column_value FROM TABLE(apex_string.split(l_search1_themes, '':''))',
'        INTERSECT',
'        SELECT column_value FROM TABLE(apex_string.split(l_search2_themes, '':''))',
'    );',
'    ',
'    -- Return validation results',
'    apex_json.open_object;',
'    apex_json.write(''same_search'', CASE WHEN l_search1 = l_search2 THEN ''Y'' ELSE ''N'' END);',
'    apex_json.write(''search1_name'', l_search1_name);',
'    apex_json.write(''search2_name'', l_search2_name);',
'    apex_json.write(''same_countries'', CASE WHEN l_search1_countries = l_search2_countries THEN ''Y'' ELSE ''N'' END);',
'    apex_json.write(''same_themes'', CASE WHEN l_search1_themes = l_search2_themes THEN ''Y'' ELSE ''N'' END);',
'    apex_json.write(''country_overlap'', l_country_overlap);',
'    apex_json.write(''theme_overlap'', l_theme_overlap);',
'    apex_json.write(''has_overlap'', CASE WHEN l_country_overlap > 0 OR l_theme_overlap > 0 THEN ''Y'' ELSE ''N'' END);',
'    apex_json.close_object;',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2708032059942913589
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964179483760474644)
,p_process_sequence=>50
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_SEARCH_NAMES'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_search1_id NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_search2_id NUMBER := TO_NUMBER(apex_application.g_x02);',
'    l_search1_name VARCHAR2(500);',
'    l_search2_name VARCHAR2(500);',
'BEGIN',
'    -- Get search names',
'    SELECT bezeichnung INTO l_search1_name ',
'    FROM t_suche_json ',
'    WHERE sucheid = l_search1_id;',
'    ',
'    SELECT bezeichnung INTO l_search2_name ',
'    FROM t_suche_json ',
'    WHERE sucheid = l_search2_id;',
'    ',
'    -- Return JSON response',
'    apex_json.open_object;',
'    apex_json.write(''search1_name'', l_search1_name);',
'    apex_json.write(''search2_name'', l_search2_name);',
'    apex_json.close_object;',
'    ',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        apex_json.open_object;',
'        apex_json.write(''search1_name'', ''Suche '' || l_search1_id);',
'        apex_json.write(''search2_name'', ''Suche '' || l_search2_id);',
'        apex_json.close_object;',
'    WHEN OTHERS THEN',
'        apex_json.open_object;',
'        apex_json.write(''error'', SQLERRM);',
'        apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2708032832138913591
);
wwv_flow_imp.component_end;
end;
/
