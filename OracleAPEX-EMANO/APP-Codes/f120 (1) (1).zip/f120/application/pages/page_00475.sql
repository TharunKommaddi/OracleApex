prompt --application/pages/page_00475
begin
--   Manifest
--     PAGE: 00475
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>475
,p_name=>'Legende'
,p_alias=>'LEGENDE'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Legende'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Page 475 - Legend Page Styling */',
'',
'/* Header icon - make it bigger */',
'.fa-info-circle {',
'    font-size: 32px !important;',
'    vertical-align: middle;',
'}',
'',
'/* Legend sections styling */',
'.status-legend,',
'.warning-legend,',
'.evaluation-legend,',
'.entry-type-legend,',
'.mass-update-legend,',
'.change-summary-legend {',
'    box-shadow: 0 2px 4px rgba(0,0,0,0.1);',
'    transition: transform 0.2s, box-shadow 0.2s;',
'    animation: fadeIn 0.3s ease-in;',
'}',
'',
'.status-legend:hover,',
'.warning-legend:hover,',
'.evaluation-legend:hover,',
'.entry-type-legend:hover,',
'.mass-update-legend:hover,',
'.change-summary-legend:hover {',
'    transform: translateY(-2px);',
'    box-shadow: 0 4px 8px rgba(0,0,0,0.15);',
'}',
'',
'@keyframes fadeIn {',
'    from {',
'        opacity: 0;',
'        transform: translateY(10px);',
'    }',
'    to {',
'        opacity: 1;',
'        transform: translateY(0);',
'    }',
'}',
'',
'/* Criticality arrow animations - SAME AS PAGE 461 */',
'.fa-arrow-up {',
'    animation: bounce-up 1.5s ease-in-out infinite;',
'}',
'',
'.fa-arrow-down {',
'    animation: bounce-down 1.5s ease-in-out infinite;',
'}',
'',
'.fa-trending-up {',
'    animation: pulse-trend 2s ease-in-out infinite;',
'}',
'',
'.fa-trending-down {',
'    animation: pulse-trend 2s ease-in-out infinite;',
'}',
'',
'/* Animations for criticality indicators */',
'@keyframes bounce-up {',
'    0%, 20%, 50%, 80%, 100% {',
'        transform: translateY(0);',
'    }',
'    40% {',
'        transform: translateY(-3px);',
'    }',
'    60% {',
'        transform: translateY(-2px);',
'    }',
'}',
'',
'@keyframes bounce-down {',
'    0%, 20%, 50%, 80%, 100% {',
'        transform: translateY(0);',
'    }',
'    40% {',
'        transform: translateY(3px);',
'    }',
'    60% {',
'        transform: translateY(2px);',
'    }',
'}',
'',
'@keyframes pulse-trend {',
'    0% {',
'        opacity: 1;',
'    }',
'    50% {',
'        opacity: 0.6;',
'    }',
'    100% {',
'        opacity: 1;',
'    }',
'}',
'',
'/* Hover effects for criticality indicators */',
'.fa-arrow-up:hover,',
'.fa-arrow-down:hover,',
'.fa-minus:hover,',
'.fa-plus-circle:hover,',
'.fa-trending-up:hover,',
'.fa-trending-down:hover {',
'    transform: scale(1.2);',
'    transition: transform 0.2s ease;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'600'
,p_dialog_width=>'900'
,p_dialog_resizable=>'Y'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2320981989253906179)
,p_plug_name=>'Status-Indikatoren'
,p_region_template_options=>'#DEFAULT#:margin-top-md:margin-bottom-sm'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="status-legend" style="background: #e3f2fd; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #2196f3; margin-bottom: 10px;">',
'    <strong>Status-Indikatoren:</strong>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-minus-circle" style="color: #e74c3c; font-size: 14px; vertical-align: middle;"></i> ',
'        Entfall',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-plus-circle" style="color: #27ae60; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        Neu hinzugef\00FCgt'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-arrow-up" style="color: #fff; background-color: #e74c3c; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padding: 2px; width: 16px; height: 16px; vertical-align: middle;'
||'"></i> ',
unistr('        Kritikalit\00E4t gestiegen'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-arrow-down" style="color: #fff; background-color: #27ae60; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 10px; padding: 2px; width: 16px; height: 16px; vertical-align: middl'
||'e;"></i> ',
unistr('        Kritikalit\00E4t gesunken'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-edit" style="color: #f39c12; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        Text ge\00E4ndert'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-exchange" style="color: #3498db; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        Bewertung ge\00E4ndert'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-check-circle" style="color: #95a5a6; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        Unver\00E4ndert'),
'    </span>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2320982126011906180)
,p_plug_name=>'Warnungs-Indikatoren'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="warning-legend" style="background: #fff3cd; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #ffc107; margin-bottom: 10px;">',
'    <strong>Warnungs-Indikatoren:</strong>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-exclamation-triangle" style="color: #ff6600; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        Nicht alle L\00E4nder/Themen abgedeckt'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-check-circle" style="color: #27ae60; font-size: 14px; vertical-align: middle;"></i> ',
'        Bereits bewertet',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-clipboard-list fam-check fam-is-success" style="color: #007bff; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        In anderem Markt ausgew\00E4hlt'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-exclamation-circle" style="color: #ffc107; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        Kritikalit\00E4t ge\00E4ndert'),
'    </span>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2320982165751906181)
,p_plug_name=>'Bewertungs-Status'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="evaluation-legend" style="background: #f3e5f5; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #9c27b0; margin-bottom: 10px;">',
'    <strong>Bewertungs-Status:</strong>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-check" style="color: #27ae60; font-weight: bold; vertical-align: middle;"></i> ',
'        <span style="color: #27ae60; font-weight: bold;">ja</span>',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-times" style="color: #e74c3c; font-weight: bold; vertical-align: middle;"></i> ',
'        <span style="color: #e74c3c; font-weight: bold;">nein</span>',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <span style="color: #666; font-style: italic;">nicht bewertet</span>',
'    </span>',
'</div>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2320982252571906182)
,p_plug_name=>'Eintrag-Typen'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="entry-type-legend" style="background: #e8f5e9; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #4caf50; margin-bottom: 10px;">',
'    <strong>Eintrag-Typen:</strong>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-user-plus" style="color: #bb0a31; font-size: 14px; vertical-align: middle;"></i> ',
'        Manueller Eintrag',
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-cog" style="color: #bb0a31; font-size: 14px; vertical-align: middle;"></i> ',
'        Automatischer Eintrag',
'    </span>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2320982435874906183)
,p_plug_name=>'Massenupdate-Status'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>110
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="mass-update-legend" style="background: #fce4ec; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #e91e63; margin-bottom: 10px;">',
'    <strong>Massenupdate-Status:</strong>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-check" style="color: #28a745; font-size: 14px; vertical-align: middle;"></i> ',
unistr('        Massenupdate m\00F6glich'),
'    </span>',
'    <span style="margin-left: 15px;">',
'        <i class="fa fa-ban" style="color: #e74c3c; font-size: 14px; vertical-align: middle;"></i> ',
'        Massenupdate blockiert',
'    </span>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2320982532981906184)
,p_plug_name=>unistr('\00C4nderungs-Status')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>120
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="change-summary-legend" style="background: #e0f2f1; padding: 10px; border-radius: 4px; font-size: 12px; border-left: 4px solid #009688; margin-bottom: 10px;">',
unistr('    <strong>\00C4nderungs-Status zu M-1:</strong>'),
'    <span style="margin-left: 15px;">',
unistr('        <span style="color: #27ae60; font-weight: bold;">Neu hinzugef\00FCgt</span>'),
'    </span>',
'    <span style="margin-left: 15px;">',
unistr('        <span style="color: #f39c12; font-weight: bold;">Kritikalit\00E4t ge\00E4ndert</span>'),
'    </span>',
'    <span style="margin-left: 15px;">',
unistr('        <span style="color: #3498db; font-weight: bold;">Bewertung ge\00E4ndert</span>'),
'    </span>',
'    <span style="margin-left: 15px;">',
unistr('        <span style="color: #95a5a6;">Keine \00C4nderung</span>'),
'    </span>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2320983402187906193)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div style="text-align: center; padding: 20px 0; border-bottom: 2px solid #bb0a31;">',
'    <h1 style="color: #bb0a31; margin: 0;">',
'        <i class="fa fa-info-circle" style="margin-right: 10px; font-size: 36px; vertical-align: middle;"></i>',
'        Legende - Symbole und Indikatoren',
'    </h1>',
'    <p style="color: #666; margin: 10px 0 0 0; font-size: 14px;">',
unistr('        Erkl\00E4rung aller Symbole und Statusanzeigen'),
'    </p>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964159838510471374)
,p_name=>'P475_SEARCH_SELECTION'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964159500467471374)
,p_name=>'P475_MILESTONE_SELECTION'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964159106864471374)
,p_name=>'P475_CARD_NUM'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964158670323471374)
,p_name=>'P475_SOURCE_PAGE'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
