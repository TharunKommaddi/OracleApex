prompt --application/pages/page_00980
begin
--   Manifest
--     PAGE: 00980
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>980
,p_name=>'Nicht zugeordnete Importeure'
,p_alias=>'NICHT-ZUGEORDNETE-IMPORTEURE'
,p_step_title=>'Nicht zugeordnete Importeure'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.hover-underline:hover {',
'    text-decoration: underline !important;',
'}',
'',
'/* For sort widget rows and embedded spans */',
'.a-IRR-sortWidget-rows a.a-IRR-sortWidget-row,',
'.a-IRR-sortWidget-rows a.a-IRR-sortWidget-row span,',
'.a-IRR-sortWidget-rows [data-return-value],',
'.a-IRR-sortWidget-rows .hover-underline,',
'.a-IRR-sortWidget-rows .custom-white-text,',
'.a-IRR-sortWidget-rows .custom-white-text span {',
'    color: white !important;',
'}',
'',
'/* For the clickable functionality */',
'.a-IRR-sortWidget-row {',
'    cursor: pointer !important;',
'}',
'',
'/* For hover effects */',
'.a-IRR-sortWidget-row:hover,',
'.hover-underline:hover {',
'    background: rgba(255,255,255,0.1) !important;',
'    color: white !important;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1095211883214265229)
,p_plug_name=>'Nicht zugeordnete Importeure'
,p_region_name=>'IR_1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    kc.KONZERN_CLUSTERID,',
'    kc.BEZEICHNUNG as cluster_name,',
'',
'    LISTAGG(DISTINCT',
'        ''<a href="'' || APEX_PAGE.GET_URL(',
'            p_page => 925,',
'            p_request => ''NO'',',
'            p_items => ''P925_IMPORTEURID'',',
'            p_values => i.IMPORTEURID',
'        ) || ''" class="hover-underline" style="text-decoration: none; " target="_self"><span>'' || i.BEZEICHNUNG || ''</span></a>'',',
'        ''<br>''',
'        ON OVERFLOW TRUNCATE ''...'' WITH COUNT',
'    ) WITHIN GROUP (ORDER BY i.BEZEICHNUNG) as unassigned_importers,',
'',
'    COUNT(DISTINCT i.IMPORTEURID) as unassigned_count',
'    FROM ',
'        t_konzern_cluster kc',
'    JOIN ',
'        t_importeur_ref_konzern_cluster irc ON kc.KONZERN_CLUSTERID = irc.KONZERN_CLUSTERID',
'    JOIN ',
'        t_importeur i ON irc.IMPORTEURID = i.IMPORTEURID',
'    WHERE ',
'        NOT EXISTS (',
'            SELECT 1 ',
'            FROM t_ansprechpartner_ref_konzern_cluster tark',
'            JOIN T_ANSPRECHPARTNER ta ON ta.ANSPRECHPARTNERID = tark.ANSPRECHPARTNERID',
'            WHERE ta.IMPORTEURID = i.IMPORTEURID',
'            AND tark.KONZERN_CLUSTERID = kc.KONZERN_CLUSTERID',
'            AND R_VKO = 10',
'        )',
'    AND i.is_deleted = 0',
'    GROUP BY ',
'        kc.KONZERN_CLUSTERID,',
'        kc.BEZEICHNUNG',
'    ORDER BY ',
'        kc.BEZEICHNUNG',
'',
'',
'',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Nicht zugeordnete Importeure'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1095211708887265227)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>2577000607012123008
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1095211563667265226)
,p_db_column_name=>'KONZERN_CLUSTERID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Konzern Clusterid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1095211428735265225)
,p_db_column_name=>'CLUSTER_NAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cluster Bezeichnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1095211370720265224)
,p_db_column_name=>'UNASSIGNED_IMPORTERS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Nicht zugeordnete Importeure'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1095211224405265223)
,p_db_column_name=>'UNASSIGNED_COUNT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Anzahl nicht zugeordnet'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1095190863539147781)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'25770215'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'KONZERN_CLUSTERID:CLUSTER_NAME:UNASSIGNED_IMPORTERS:UNASSIGNED_COUNT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1094031835928457126)
,p_plug_name=>'Abfluss Diagram'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
'<style>',
'.mermaid {',
'    padding: 10rem;',
'    border-radius: 8px;',
'    box-shadow: 0 2px 4px rgba(0,0,0,0.1);',
'    margin: 1rem 0;',
'    overflow: auto;',
'    max-width: 100%;',
'    background-color: white;',
'}',
'',
'.mermaid svg {',
'    max-width: 100%;',
'    height: auto;',
'}',
'',
'@media (max-width: 768px) {',
'    .mermaid {',
'        font-size: 14px;',
'    }',
'}',
'</style>',
'',
'',
'<div id="flowchart-container"></div>',
'',
'',
'<script src="https://cdn.jsdelivr.net/npm/mermaid@10.6.1/dist/mermaid.min.js"></script>',
'',
'',
'<script>',
'document.addEventListener(''DOMContentLoaded'', function() {',
'',
'   ',
'    mermaid.initialize({',
'        startOnLoad: true,',
'        theme: ''default'',',
'        securityLevel: ''loose'',',
'        flowchart: {',
'            curve: ''basis'',',
'            padding: 20,',
'            htmlLabels: true,',
'            useMaxWidth: true',
'        }',
'    });',
'',
'',
'    const diagram = `flowchart TD',
'    Start(["Start Status Check"]) --> IndivCheck{"Check Individual Statuses"}',
'    IndivCheck -- Schulung --> SchulungCheck{"Check Schulung"}',
'    IndivCheck -- Audit --> AuditCheck{"Check Audit"}',
'    IndivCheck -- Ansprechpartner --> AnsprechCheck{"Check Ansprechpartner"}',
'    SchulungCheck -- No Records --> SchulungNull["NULL"]',
'    SchulungCheck -- Has Records --> IsRepeated{"Is Repeated?"}',
'    IsRepeated -- Yes --> SchulungGrey["GREY"]',
'    IsRepeated -- No --> CheckType{"Check Type Status"}',
'    CheckType -- Inactive --> SchulungGrey',
'    CheckType -- Active --> CheckConditions{"Check Date & Status"}',
'    CheckConditions -- Future Date OR Valid & Completed --> SchulungGreen["LIMEGREEN"]',
'    CheckConditions -- Past & Not Done OR Expired --> SchulungRed["RED"]',
'    AuditCheck -- No Records --> AuditNull["NULL"]',
'    AuditCheck -- Has Records --> AuditRepeated{"Is Repeated?"}',
'    AuditRepeated -- Yes --> AuditGrey["GREY"]',
'    AuditRepeated -- No --> AuditType{"Check Type Status"}',
'    AuditType -- Inactive --> AuditGrey',
'    AuditType -- Active --> AuditConditions{"Check Date & Status"}',
'    AuditConditions -- Future Date OR Valid & Status Inactive --> AuditGreen["LIMEGREEN"]',
'    AuditConditions -- Past & Not Inactive OR Expired --> AuditRed["RED"]',
'    AnsprechCheck -- No Records --> AnsprechRed["RED"]',
'    AnsprechCheck -- Has Records --> ClusterCheck{"Check Clusters"}',
'    ClusterCheck -- Any Unassigned --> AnsprechRed',
'    ClusterCheck -- All Assigned --> AnsprechGreen["LIMEGREEN"]',
'    ',
'    SchulungRed --> Gesamtstatus{"Calculate Gesamtstatus"}',
'    SchulungGreen --> Gesamtstatus',
'    SchulungGrey --> Gesamtstatus',
'    SchulungNull --> Gesamtstatus',
'    AuditRed --> Gesamtstatus',
'    AuditGreen --> Gesamtstatus',
'    AuditGrey --> Gesamtstatus',
'    AuditNull --> Gesamtstatus',
'    AnsprechRed --> Gesamtstatus',
'    AnsprechGreen --> Gesamtstatus',
'    Gesamtstatus -- Any RED exists --> GesamtRed["RED"]',
'    Gesamtstatus -- Any GREEN, No RED --> GesamtGreen["LIMEGREEN"]',
'    Gesamtstatus -- All GREY/NULL --> GesamtGrey["GREY"]',
'    GesamtRed --> End(["End Status Check"])',
'    GesamtGreen --> End',
'    GesamtGrey --> End',
'',
'    classDef green fill:limegreen,color:white',
'    classDef red fill:red,color:white',
'    classDef grey fill:#BBBBBB,color:black',
'    classDef null fill:white,stroke-dasharray: 5 5',
'',
'    class SchulungNull,AuditNull null',
'    class SchulungGrey,AuditGrey,GesamtGrey grey',
'    class SchulungGreen,AuditGreen,AnsprechGreen,GesamtGreen green',
'    class SchulungRed,AuditRed,AnsprechRed,GesamtRed red`;',
'',
'    ',
'    const container = document.createElement(''div'');',
'    container.className = ''mermaid'';',
'    container.textContent = diagram;',
'    ',
'    ',
'    document.getElementById(''flowchart-container'').appendChild(container);',
'    ',
'   ',
'    mermaid.contentLoaded();',
'});',
'',
'',
'function refreshFlowchart() {',
'    const container = document.querySelector(''.mermaid'');',
'    if (container) {',
'        container.parentNode.removeChild(container);',
'        const newContainer = document.createElement(''div'');',
'        newContainer.className = ''mermaid'';',
'        newContainer.textContent = diagram;',
'        document.getElementById(''flowchart-container'').appendChild(newContainer);',
'        mermaid.contentLoaded();',
'    }',
'}',
'</script>',
'',
''))
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1095211144612265222)
,p_name=>'Refresh Report After 925 Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1095211883214265229)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1095211077484265221)
,p_event_id=>wwv_flow_imp.id(1095211144612265222)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1095211883214265229)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
