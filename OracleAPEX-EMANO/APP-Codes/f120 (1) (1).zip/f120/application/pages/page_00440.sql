prompt --application/pages/page_00440
begin
--   Manifest
--     PAGE: 00440
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>440
,p_name=>'Fachbereichreport Funktionen'
,p_alias=>'FACHBEREICHREPORT-FUNKTIONEN'
,p_step_title=>'Fachbereichreport Funktionen'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(602625370512642598)
,p_plug_name=>'Fachbereichreport Funktionen <span onclick="redirect(4)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with funk as (    SELECT  bezeichnung',
'    , funktionid',
'    --, connect_by_root bezeichnung as parent',
'    , sys_connect_by_path(bezeichnung, '' |'')  full_path, id_aus_excel as sys42_Funktionsid',
'   FROM t_funktion        ',
'  start with parentid is null',
'  CONNECT BY PRIOR funktionid = parentid',
')',
'',
'select vrf."ROWID" as xrowid',
' --, 1 as checkbox',
'  , 1 as details',
'  , vrf.vorschriftid as "VORSCHRIFTID"',
' , vrf.vorschriftid as link_netz',
' , vs.vorschrift_nummer as "VORSCHRIFT_NUMMER"',
' , vs.DOKUMENTENDATUM',
' , vs.vorschrift_bezeichnung as "TITEL"',
' , DECODE(vs.Homologationsrelevant, 10, emano_util.fLang(''ja'', ''yes''), 0, emano_util.fLang(''nein'', ''no''), emano_util.fLang(''nein'', ''no'')) as "HOMOLOGATIONSRELEVANT"',
' , DECODE(vs.CoP_Relevant, 10, emano_util.fLang(''ja'', ''yes''), 0, emano_util.fLang(''nein'', ''no''), emano_util.fLang(''nein'', ''no'')) AS "COP_RELEVANT"',
' , vs.vorschrift_StatusID as "STATUS"',
' , apex_util.host_url(''SCRIPT'') || apex_page.get_url(',
'    p_application => :APP_ALIAS',
'    , p_page => ''VORSCHRIFT''',
'    , p_items => ''P25_VORSCHRIFTID''',
'    , p_values => vrf.vorschriftid',
'    , p_session => null',
'    , p_clear_cache => ''25''',
'   ) as permalink   ',
' , x.list_land',
' , fu.bezeichnung as Funktion',
' , fu.full_path as Pfad',
' , themengebiete.list_themengebiet as THEMA_NUMMER',
' , themengebiete_text.list_themengebiet_text as THEMA_BEZEICHNUNG,',
' fu.sys42_Funktionsid',
' ',
'  from T_VORSCHRIFT_REF_FUNKTION vrf',
'  join T_Vorschrift vs on (vs.vorschriftid = vrf.vorschriftid)',
'  --join T_FUNKTION f on (f.funktionid  = vrf.funktionid)',
'  join funk fu on (fu.funktionid = vrf.funktionid)',
'  outer apply (',
'    select listagg(b_nummer, '', '') within group(order by b_nummer) list_land',
'     from (',
'        select land.b_nummer',
'        from T_VORSCHRIFT_REF_LAND vl ',
'        left outer join t_land land on land.landid = vl.landid',
'        where vl.vorschriftid = vs.vorschriftid and vl.geloescht = 0',
'        ',
'        union',
'        ',
'        select l.b_nummer',
'        from t_vorschrift_ref_vorschrift vrv',
'        join t_vorschrift_ref_land rl on (vrv.nachfolger_vorschriftid = rl.vorschriftid)',
'        join t_land l on (rl.landid = l.landid)',
'        where vorgaenger_vorschriftid = vs.vorschriftid and beziehung_art = 40 and rl.geloescht = 0',
'         ',
'         union',
'               -- equivalent',
'        select  distinct l.b_nummer ',
'        from t_vorschrift_ref_vorschrift vrv',
'        join t_vorschrift_ref_land rl on (vrv.nachfolger_vorschriftid = rl.vorschriftid)',
'        join t_land l on (rl.landid = l.landid)',
'        where vorgaenger_vorschriftid = vs.vorschriftid ',
'        and vrv.beziehung_art = 102 and rl.geloescht = 0',
'         union ',
'         select distinct l.b_nummer ',
'        from t_vorschrift_ref_vorschrift vrv',
'        join t_vorschrift_ref_land rl on (vrv.vorgaenger_vorschriftid = rl.vorschriftid)',
'        join t_land l on (rl.landid = l.landid)',
'        where nachfolger_vorschriftid = vs.vorschriftid ',
'         and beziehung_art = 102 and rl.geloescht = 0',
'    )',
' ) x',
'',
'  outer apply (',
'    select listagg(tg,'', '' ON OVERFLOW TRUNCATE) within group (order by tg) list_themengebiet',
'    from (',
'        select distinct t.nummer tg',
'        from t_vorschrift_ref_thema vt',
'        join t_thema t on (vt.themaid = t.themaid)',
'        where vt.vorschriftid = vs.vorschriftid and vt.geloescht = 0',
'    )',
'  ) themengebiete',
'  ',
'  outer apply (',
'    select listagg(tg,'', '' ON OVERFLOW TRUNCATE) within group (order by tg_n) list_themengebiet_text',
'    from (',
'        select distinct CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN t.bezeichnung',
'        ELSE t.name_eng',
'    END as tg, t.nummer as tg_n',
'        from t_vorschrift_ref_thema vt',
'        join t_thema t on (vt.themaid = t.themaid)',
'        where vt.vorschriftid = vs.vorschriftid and vt.geloescht = 0',
'    )',
'  ) themengebiete_text',
';'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Fachbereichreport Funktionen <span onclick="redirect(4)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(602625277256642598)
,p_name=>'Fachbereichreport Funktionen'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>510067659838491806
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(602624968479642554)
,p_db_column_name=>'XROWID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Xrowid'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(602813725019777391)
,p_db_column_name=>'DETAILS'
,p_display_order=>11
,p_column_identifier=>'Q'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_column_linktext=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_column_link_attr=>'target="_blank"'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(2652734704667593954)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(602624147585642526)
,p_db_column_name=>'LINK_NETZ'
,p_display_order=>21
,p_column_identifier=>'C'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:RP,:P300_VORSCHRIFTID:#VORSCHRIFTID##VORSCHRIFT_REF_FUNKTIONID#'
,p_column_linktext=>unistr('<span class="fa fa-network-hub" title="Vernetzungsansicht \00F6ffnen" alt="Vernetzungsansicht \00F6ffnen"></span>')
,p_column_link_attr=>'target ="_blank"'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(602814010895777394)
,p_db_column_name=>'PERMALINK'
,p_display_order=>31
,p_column_identifier=>'N'
,p_column_label=>'<span title="Permalink">&nbsp;</span> '
,p_column_html_expression=>'<span class="fa fa-link" title="Permalink in Zwischenablage kopieren" alt="Permalink in Zwischenablage kopieren" onClick="javascript:navigator.clipboard.writeText(''#PERMALINK#'');alert(''Der Permalink wurde in die Zwischenablage kopiert:\n\n#PERMALINK#'
||''');"></span>'
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(602623764729642526)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>41
,p_column_identifier=>'D'
,p_column_label=>'Vorschrift Nummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(602813874188777393)
,p_db_column_name=>'TITEL'
,p_display_order=>51
,p_column_identifier=>'O'
,p_column_label=>'Titel'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(602814117129777395)
,p_db_column_name=>'STATUS'
,p_display_order=>91
,p_column_identifier=>'M'
,p_column_label=>'Status'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(2490458092659806028)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(602813769398777392)
,p_db_column_name=>'LIST_LAND'
,p_display_order=>101
,p_column_identifier=>'P'
,p_column_label=>'List Land'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(602813548870777390)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>111
,p_column_identifier=>'R'
,p_column_label=>'Vorschriftid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_static_id=>'col_item _of_vorschriftid'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(602813183316777386)
,p_db_column_name=>'FUNKTION'
,p_display_order=>121
,p_column_identifier=>'S'
,p_column_label=>'Funktion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(602813062161777385)
,p_db_column_name=>'PFAD'
,p_display_order=>131
,p_column_identifier=>'T'
,p_column_label=>'Pfad'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(602812945649777384)
,p_db_column_name=>'THEMA_NUMMER'
,p_display_order=>141
,p_column_identifier=>'U'
,p_column_label=>'Thema Nummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(602812860777777383)
,p_db_column_name=>'THEMA_BEZEICHNUNG'
,p_display_order=>151
,p_column_identifier=>'V'
,p_column_label=>'Thema Bezeichnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(591079261326850456)
,p_db_column_name=>'HOMOLOGATIONSRELEVANT'
,p_display_order=>161
,p_column_identifier=>'W'
,p_column_label=>'Homologationsrelevant'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(591079168179850455)
,p_db_column_name=>'COP_RELEVANT'
,p_display_order=>171
,p_column_identifier=>'X'
,p_column_label=>'Cop Relevant'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(52743828034209298)
,p_db_column_name=>'SYS42_FUNKTIONSID'
,p_display_order=>181
,p_column_identifier=>'Y'
,p_column_label=>'Sys42 Funktionsid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1094032228978457130)
,p_db_column_name=>'DOKUMENTENDATUM'
,p_display_order=>191
,p_column_identifier=>'Z'
,p_column_label=>'Dokumentendatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(602621618495631569)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5100714'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DETAILS:LINK_NETZ:PERMALINK:VORSCHRIFT_NUMMER:DOKUMENTENDATUM:TITEL:STATUS:HOMOLOGATIONSRELEVANT:COP_RELEVANT:LIST_LAND:FUNKTION:PFAD:THEMA_NUMMER:THEMA_BEZEICHNUNG:SYS42_FUNKTIONSID:'
);
wwv_flow_imp.component_end;
end;
/
