prompt --application/pages/page_00515
begin
--   Manifest
--     PAGE: 00515
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>515
,p_name=>unistr('Konzern Cluster bearbeiten / hinzuf\00FCgen')
,p_alias=>'KONZERN-CLUSTER-BEARBEITEN'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Konzern Cluster bearbeiten / hinzuf\00FCgen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'function loadLaenderShuttle() {',
'    var shuttleName = ''P515_FILTER_BLAND'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadLaenderShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P515_FILTER_LAENDERGRUPPE''),',
'          x03: $v(''P515_FILTER_BLAND_PRE''),',
'          //x04: $v(''P125_INCLUDE_INACT_BESTAND'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(863793346857403946)
,p_plug_name=>'Konzern Cluster bearbeiten'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_KONZERN_CLUSTER'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(303790871009961767)
,p_plug_name=>unistr('Inaktive L\00E4nder')
,p_parent_plug_id=>wwv_flow_imp.id(863793346857403946)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>unistr('F\00FCr L\00E4nder, die hier ausgew\00E4hlt werden, gilt der Cluster als inaktiv.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(377366748403978243)
,p_name=>'VKO / KVKO'
,p_parent_plug_id=>wwv_flow_imp.id(863793346857403946)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    select distinct b.rowid as browid, b.benutzerid, b.nachname || '', '' || b.vorname || '' ('' || b.abteilung || '')'' as name, konzern_clusterid, r.rolleid, rolle',
'    from t_benutzer b',
'    join t_benutzer_ref_rolle brr on (b.benutzerid = brr.benutzerid)',
'    join t_benutzer_ref_konzern_cluster brkc on (b.benutzerid = brkc.benutzerid)',
'    join t_rolle r on (brr.rolleid = r.rolleid)',
'    where brr.rolleid in (1000,1060) and konzern_clusterid = :P515_KONZERN_CLUSTERID -- VKO und KVKO',
')',
'select browid, name, listagg(rolle, '', '') within group (order by rolle) as liste_rollen',
'from cte1',
'group by name, browid'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P515_KONZERN_CLUSTERID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Keine VKO / KVKO zugeordnet.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(781400785330132185)
,p_query_column_id=>1
,p_column_alias=>'BROWID'
,p_column_display_sequence=>10
,p_column_link=>'f?p=&APP_ID.:55:&SESSION.::&DEBUG.:55:P55_ROWID:#BROWID#'
,p_column_linktext=>'<span class="fa fa-search"></span>'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(377366817897978244)
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(781400869142132186)
,p_query_column_id=>3
,p_column_alias=>'LISTE_ROLLEN'
,p_column_display_sequence=>30
,p_column_heading=>'Rolle(n)'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(863790941572403889)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(863790620048403888)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(863790941572403889)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(843925913562351387)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(377366748403978243)
,p_button_name=>'BENUTZERVERWALTUNG'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Benutzerverwaltung'
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.:50::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(863788970355403877)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(863790941572403889)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>unistr('javascript:apex.confirm(''M\00F6chten Sie den Konzern Cluster l\00F6schen?'',''DELETE'');')
,p_button_execute_validations=>'N'
,p_button_condition=>'P515_KONZERN_CLUSTERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(863788613878403877)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(863790941572403889)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P515_KONZERN_CLUSTERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(863788167122403877)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(863790941572403889)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P515_KONZERN_CLUSTERID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1065521043854676101)
,p_name=>'P515_SAMMEL_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(863793346857403946)
,p_item_source_plug_id=>wwv_flow_imp.id(863793346857403946)
,p_prompt=>'Sammel E-Mail Adresse'
,p_source=>'SAMMEL_EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>200
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'EMAIL',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1065520944670676100)
,p_name=>'P515_NUMMER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(863793346857403946)
,p_item_source_plug_id=>wwv_flow_imp.id(863793346857403946)
,p_prompt=>'Nummer'
,p_source=>'NUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>200
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1044453591852701050)
,p_name=>'P515_FILTER_LAENDERGRUPPE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(303790871009961767)
,p_prompt=>unistr('Vorfilter L\00E4ndergruppe')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select laendergruppe, laendergruppeid',
'from t_laendergruppe where laendergruppeid != 1220',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- alle -'
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1044453140041701047)
,p_name=>'P515_FILTER_BLAND_PRE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(303790871009961767)
,p_prompt=>unistr('Vorfilter L\00E4nder')
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" onclick="loadLaenderShuttle()"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>7
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1044452806541701046)
,p_name=>'P515_FILTER_BLAND'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(303790871009961767)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('L\00E4nder')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(landid, '':'') within group (order by landid) ',
'from T_konzern_cluster_ref_LAND kcrl',
'where kcrl.konzern_clusterID = :P515_konzern_clusterID;'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b_nummer || '' - '' || CASE ',
'    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'    ELSE land_eng',
'END as d, landid',
'from t_land l',
'where (:P515_FILTER_LAENDERGRUPPE is null or landid in (select landid from t_land_ref_laendergruppe where laendergruppeid = :P515_FILTER_LAENDERGRUPPE))',
'    and status_datenstand <> 0',
'order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'')'))
,p_cHeight=>5
,p_tag_css_classes=>'margin-bottom-none padding-bottom-none'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_css_classes=>'margin-bottom-none padding-bottom-none'
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(863792969311403942)
,p_name=>'P515_KONZERN_CLUSTERID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(863793346857403946)
,p_item_source_plug_id=>wwv_flow_imp.id(863793346857403946)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Konzern Clusterid'
,p_source=>'KONZERN_CLUSTERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(863792562160403909)
,p_name=>'P515_BEZEICHNUNG'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(863793346857403946)
,p_item_source_plug_id=>wwv_flow_imp.id(863793346857403946)
,p_prompt=>'Bezeichnung'
,p_source=>'BEZEICHNUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>200
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(863792250135403893)
,p_name=>'P515_BESCHREIBUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(863793346857403946)
,p_item_source_plug_id=>wwv_flow_imp.id(863793346857403946)
,p_prompt=>'Beschreibung'
,p_source=>'BESCHREIBUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>400
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(863790464622403888)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(863790620048403888)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(863789707711403881)
,p_event_id=>wwv_flow_imp.id(863790464622403888)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1044443637537619106)
,p_name=>'Change Laender Filter'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P515_FILTER_LAENDERGRUPPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1044443277903619101)
,p_event_id=>wwv_flow_imp.id(1044443637537619106)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1044442889536617268)
,p_name=>unistr('enter im l\00E4ndervorfilter')
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P515_FILTER_BLAND_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1044442509481617268)
,p_event_id=>wwv_flow_imp.id(1044442889536617268)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(863763065548305698)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Delete Verkn\00FCpfte Daten')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from t_ansprechpartner_ref_konzern_cluster where konzern_clusterid = :P515_KONZERN_CLUSTERID;',
'delete from t_konzern_cluster_ref_et_b_ak where konzern_clusterid = :P515_KONZERN_CLUSTERID;',
'delete from t_konzern_cluster_ref_land where konzern_clusterid = :P515_KONZERN_CLUSTERID;',
'delete from t_benutzer_ref_konzern_cluster where konzern_clusterid = :P515_KONZERN_CLUSTERID;',
'delete from t_importeur_ref_konzern_cluster where konzern_clusterid = :P515_KONZERN_CLUSTERID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(863788970355403877)
,p_internal_uid=>2808449250351082537
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(863787423644403874)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(863793346857403946)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Konzern Cluster bearbeiten'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2808424892254984361
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1065520688205676097)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('L\00E4nderverkn\00FCpfungen')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_konzern_clusterid number;',
'begin',
'    l_konzern_clusterid := :P515_KONZERN_CLUSTERID;',
'    -- neue Konzern_Cluster einfuegen',
'    merge into t_konzern_cluster_ref_LAND dest',
'    using (select l_konzern_clusterid as konzern_clusterid, column_value as landid from table(APEX_STRING.split_numbers(:P515_FILTER_BLAND, '':''))) src',
'    on (src.konzern_clusterid = dest.konzern_clusterid ',
'       and src.landid = dest.landid)',
'    when not matched then',
'    insert (konzern_clusterid, landid)',
'    values (src.konzern_clusterid, src.landid);',
'    ',
'    -- entfernte laender loeschen',
'    delete from t_konzern_cluster_ref_land nrl',
'     where nrl.konzern_clusterid = l_konzern_clusterid',
'       and nrl.landid not in (select column_value from table(APEX_STRING.split_numbers(:P515_FILTER_BLAND, '':'')));',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2606691627693712138
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(863786941767403873)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2808425374131984362
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(863787761606403874)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(863793346857403946)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Konzern Cluster bearbeiten'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2808424554292984361
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1065520753336676098)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLaenderShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lLaendergruppe varchar2(2000) := apex_application.g_x02;',
'    lTextfilter varchar2(2000) := apex_application.g_x03;',
'    --include_Land_inaktDaten number := apex_application.g_x04; -- visible with switsch (ON) for VKO & FachAdm',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    for l in (',
'        select b_nummer || '' - '' || CASE ',
'    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'    ELSE land_eng',
'END as d, landid',
'        from t_land',
'        where landid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))        ',
'        and (',
'            lLaendergruppe is null',
'            or landid in (',
'                select landid from t_land_ref_laendergruppe where laendergruppeid in (',
'                    select column_value from table(apex_string.split_numbers(lLaendergruppe,'':''))',
'                )',
'            )',
'        )',
'        and (',
'            lTextfilter is null',
'            or instr(upper(b_nummer),upper(lTextFilter)) != 0',
'            or instr(upper(land),upper(lTextFilter)) != 0',
'        )',
'        and status_datenstand <> 0',
'        order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'')        ',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.landid);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'    ',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2606691562562712137
);
wwv_flow_imp.component_end;
end;
/
