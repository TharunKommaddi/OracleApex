prompt --application/pages/page_00135
begin
--   Manifest
--     PAGE: 00135
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>135
,p_name=>unistr('Land bearbeiten / hinzuf\00FCgen')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Land bearbeiten / hinzuf\00FCgen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'',
'function loadThemenShuttle() {',
'    var shuttleName = ''P135_FILTER_THEMEN'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'       var lText = $v(''P135_FILTER_THEMEN_PRE'');',
'    var lArbeitskreis = $v(''P135_FILTER_THEMEN_PRE_AK'');',
'    var lCluster = $v(''P135_FILTER_THEMEN_PRE_CLUSTER'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    ',
'    apex.server.process(',
'        ''loadThemenShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: lText,',
'          x03: lArbeitskreis,',
'          x04: lCluster',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'function addItemToShuttle(aShuttle, aID, aDisplay) {',
'    var lLeft = $(''#'' + aShuttle + ''_LEFT'');',
'    var lRight = $(''#'' + aShuttle + ''_RIGHT'');',
'    lLeft.find(''option[value='' + aID + '']'').remove();',
'    lRight.append(''<option value="'' + aID + ''">'' + aDisplay + ''</option>'');',
'}',
'',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1300'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(640021615752615603)
,p_plug_name=>'BOX Vorfilter Themen'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>5
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(639844006791069403)
,p_plug_name=>'BOX Filter Themen'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(442911007483880864)
,p_name=>unistr('L\00E4nderansprechpartner')
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    b.benutzerid, ',
'    landid, ',
'    2 as link, ',
'    nachname || '', '' || vorname as ansprechpartner, ',
'    CASE ',
'        WHEN haupt_ansprechpartner = 10 THEN emano_util.fLang(''ja'', ''yes'') ',
'        ELSE emano_util.fLang(''nein'', ''no'') ',
'    END AS hauptansprechpartner,',
'    benutzer_ref_landid',
'FROM ',
'    t_benutzer b',
'JOIN ',
'    t_benutzer_ref_land bl ON b.benutzerid = bl.benutzerid',
'WHERE ',
'    landid = :p135_landid;',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P135_LANDID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(442910880381880863)
,p_query_column_id=>1
,p_column_alias=>'BENUTZERID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(442910011436880854)
,p_query_column_id=>2
,p_column_alias=>'LANDID'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(442910802947880862)
,p_query_column_id=>3
,p_column_alias=>'LINK'
,p_column_display_sequence=>2
,p_column_link=>'f?p=&APP_ID.:56:&SESSION.::&DEBUG.:56:P56_BENUTZER,P56_CAME_FROM,P56_LANDID,P56_BENUTZER_REF_LANDID:#BENUTZERID#,135,#LANDID#,#BENUTZER_REF_LANDID#'
,p_column_linktext=>'<span aria-label="Eintrag bearbeiten"><span class="fa fa-edit" aria-hidden="true" title="Eintrag bearbeiten"></span></span>'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(429933823817891603)
,p_query_column_id=>4
,p_column_alias=>'ANSPRECHPARTNER'
,p_column_display_sequence=>4
,p_column_heading=>'Ansprechpartner'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(429933645166891602)
,p_query_column_id=>5
,p_column_alias=>'HAUPTANSPRECHPARTNER'
,p_column_display_sequence=>5
,p_column_heading=>'Hauptansprechpartner'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(409556416191286701)
,p_query_column_id=>6
,p_column_alias=>'BENUTZER_REF_LANDID'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(442910479922880859)
,p_name=>'Importeure'
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select i.importeurid, landid, 2 as link, bezeichnung',
'from t_importeur i',
'join t_importeur_ref_land il on il.importeurid = i.importeurid',
'where landid = :p135_landid and i.is_deleted = 0'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P135_LANDID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(442910421380880858)
,p_query_column_id=>1
,p_column_alias=>'IMPORTEURID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(442910238113880857)
,p_query_column_id=>2
,p_column_alias=>'LANDID'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(442910233124880856)
,p_query_column_id=>3
,p_column_alias=>'LINK'
,p_column_display_sequence=>3
,p_column_link=>'f?p=&APP_ID.:925:&SESSION.::&DEBUG.::P925_IMPORTEURID,P925_CAME_FROM:#IMPORTEURID#,135'
,p_column_linktext=>'<span aria-label="Eintrag bearbeiten"><span class="fa fa-edit" aria-hidden="true" title="Eintrag bearbeiten"></span></span>'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(442910037627880855)
,p_query_column_id=>4
,p_column_alias=>'BEZEICHNUNG'
,p_column_display_sequence=>4
,p_column_heading=>'Bezeichnung'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77843722343706023)
,p_plug_name=>'Trennlinie'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>40
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<hr>',
unistr('Themengebietseinschr\00E4nkungen f\00FCr Export "Statement of Completeness":')))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2663050098054110273)
,p_plug_name=>'Form on T_LAND'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2663050865604110274)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2663051201816110275)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2663050865604110274)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2663050691422110274)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2663050865604110274)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(429933395476891599)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(442911007483880864)
,p_button_name=>'P135_CREATE_ANSPRECHPARTNER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Ansprechpartner hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:56:&SESSION.::&DEBUG.:56:P56_CAME_FROM,P56_LANDID:135,&P135_LANDID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(380764958015058794)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(442910479922880859)
,p_button_name=>'ADD_IMPORTEUR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Importeur zuordnen'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:970:&SESSION.::&DEBUG.:970:P970_LANDID:&P135_LANDID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(429933239698891598)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(442910479922880859)
,p_button_name=>'P135_CREATE_IMPORTEUR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Importeur hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:925:&SESSION.::&DEBUG.:925:P925_CAME_FROM,P925_LANDID:135,&P135_LANDID.'
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2663050604118110274)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2663050865604110274)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P135_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2663050474446110274)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2663050865604110274)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P135_ROWID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1003882308469808386)
,p_name=>'P135_BESONDERHEITEN_MARKT'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Besonderheiten Markt Deutsch'
,p_source=>'BESONDERHEITEN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>400
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(962881440739665182)
,p_name=>'P135_BESONDERHEITEN_MARKT_ENGLISCH'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Besonderheiten Markt Englisch'
,p_source=>'BESONDERHEITENMARKT_ENGLISCH'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>400
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(949210065851439896)
,p_name=>'P135_KONTINENT_ENGLISCH'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Kontinent Englisch'
,p_source=>'CONTINENT_ENG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct ',
'       CASE ',
'           WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN kontinent ',
'           ELSE continent_eng ',
'       END as kontinent_display',
'from t_land',
'order by ',
'       CASE ',
'           WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN kontinent ',
'           ELSE continent_eng ',
'       END asc;',
''))
,p_cSize=>20
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual',
'where :FSP_LANGUAGE_PREFERENCE = ''en'''))
,p_display_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'fetch_on_type', 'N',
  'match_type', 'CONTAINS_IGNORE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(949208380069439879)
,p_name=>'P135_EINSATZDATUM_MODELLID_ENGLISH'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Date of use Model English'
,p_source=>'EINSATZDATUM_MODELLID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select modell_eng, einsatzdatum_modellid',
'from t_einsatzdatum_modell',
'order by 2 asc'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual',
'where :FSP_LANGUAGE_PREFERENCE = ''en''',
''))
,p_display_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(949207652302439872)
,p_name=>'P135_LAND_ENGLISH'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Country English'
,p_source=>'LAND_ENG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(896552265548355363)
,p_name=>'P135_ISO_CODE_2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>'ISO Code 2 stellig'
,p_source=>'ISO_CODE_2'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>2
,p_cMaxlength=>2
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(896552179840355362)
,p_name=>'P135_ISO_CODE_3'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>'ISO Code 3 stellig'
,p_source=>'ISO_CODE_3'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>3
,p_cMaxlength=>3
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(896552132173355361)
,p_name=>'P135_ISO_ENGLISCH'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Land Name ISO Englisch'
,p_source=>'ISO_ENGLISCH'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>100
,p_cMaxlength=>400
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(896551998629355360)
,p_name=>'P135_KONTINENT'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Kontinent'
,p_source=>'KONTINENT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct kontinent ',
'from t_land',
'order by kontinent asc'))
,p_cSize=>20
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual',
'where :FSP_LANGUAGE_PREFERENCE = ''de'''))
,p_display_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'fetch_on_type', 'N',
  'match_type', 'CONTAINS_IGNORE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(896551747730355358)
,p_name=>'P135_STATUS_DATENSTAND'
,p_is_required=>true
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>'Umsetzungsstatus Datenbestand'
,p_source=>'STATUS_DATENSTAND'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''aktiv'', ''active'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''inaktiv'', ''inactive'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;'))
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(682182118817328099)
,p_name=>'P135_BEDEUTUNG_EINSATZTERMIN'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Bedeutung Erf\00FCllungszeitpunkt')
,p_source=>'BEDEUTUNG_EINSATZTERMIN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_css_classes=>'ck-word-count-container'
,p_item_template_options=>'#DEFAULT#'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function initializeCKEditor(options) {',
'    options.executeOnInitialization = function(editor) {',
'        const plugin = editor.plugins.get(''WordCount'');',
'        editor.sourceElement.parentElement.parentElement.appendChild(plugin.wordCountContainer);',
'        // Add a class to the word count container for styling',
'        plugin.wordCountContainer.classList.add(''ck-word-count-container'');',
'    };',
'    return options;',
'}',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_custom_html', 'N',
  'format', 'HTML',
  'min_height', '180',
  'toolbar', 'FULL',
  'toolbar_style', 'MULTILINE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options) {',
'    options.executeOnInitialization = function(editor) {',
'        const plugin = editor.plugins.get(''WordCount'');',
'        editor.sourceElement.parentElement.parentElement.appendChild(plugin.wordCountContainer);',
'    };',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(682181940825328098)
,p_name=>'P135_BEMERKUNG_ZUM_EINSATZTERMIN'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Bemerkung zum Erf\00FCllungszeitpunkt')
,p_source=>'BEMERKUNG_EINSATZTERMIN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_css_classes=>'ck-word-count-container'
,p_item_template_options=>'#DEFAULT#'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'function initializeCKEditor(options) {',
'    options.executeOnInitialization = function(editor) {',
'        const plugin = editor.plugins.get(''WordCount'');',
'        editor.sourceElement.parentElement.parentElement.appendChild(plugin.wordCountContainer);',
'    };',
'    return options;',
'}',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_custom_html', 'N',
  'format', 'HTML',
  'min_height', '180',
  'toolbar', 'FULL',
  'toolbar_style', 'MULTILINE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(641415375868456593)
,p_name=>'P135_SUMS_RELEVANT'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Sums Relevant'
,p_source=>'SUMS_RELEVANT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''ja'', ''yes'') AS display_value,',
'        10 AS return_value,',
'        10 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nein'', ''no'') AS display_value,',
'        20 AS return_value,',
'        20 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht bewertet'', ''not evaluated'') AS display_value,',
'        30 AS return_value,',
'        30 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
'',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- ausw\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''ja'', ''yes'') AS display_value,',
'        ''ja'' AS return_value,',
'        10 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nein'', ''no'') AS display_value,',
'        ''nein'' AS return_value,',
'        20 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht bewertet'', ''not evaluated'') AS display_value,',
'        ''nicht bewertet'' AS return_value,',
'        30 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
'*/'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(641414910279456588)
,p_name=>'P135_SUMS_RELEVANT_ALERT'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_source=>'select SUMS_RELEVANT from T_LAND where LANDID =:P135_LANDID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''ja'', ''yes'') AS display_value,',
'        ''ja'' AS return_value,',
'        10 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nein'', ''no'') AS display_value,',
'        ''nein'' AS return_value,',
'        20 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht bewertet'', ''not evaluated'') AS display_value,',
'        ''nicht bewertet'' AS return_value,',
'        30 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
'*/'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(640021528603615602)
,p_name=>'P135_FILTER_THEMEN_PRE_AK'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(640021615752615603)
,p_prompt=>'Arbeitskreis Vorfilter'
,p_source=>'-1'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct kurz || '' '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END as d, et_b_akid as r',
'from t_et_b_ak where CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END not in (emano_util.fLang(''Administratoren'', ''Administrators''), emano_util.fLang(''Redaktionsteam'', ''Editorial Team''))',
'order by 1',
'   ',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- alle -'
,p_lov_null_value=>'-1'
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(640021425919615601)
,p_name=>'P135_FILTER_THEMEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(639844006791069403)
,p_prompt=>'Filter Themen'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung ',
'        ELSE name_eng',
'        END as d, themaid as r ',
'from v_thema_baum',
'where nvl(gueltig, 0) =1',
'order by thema_sortorder'))
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(639843671589069400)
,p_name=>'P135_THEMEN_CHILDREN_TO_ADD'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(639843197148069395)
,p_name=>'P135_FILTER_PROFILE'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(639834648402001777)
,p_name=>'P135_FILTER_THEMEN_PRE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(640021615752615603)
,p_prompt=>'Vorfilter Themengebiete'
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" onclick="loadThemenShuttle()"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>4
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(638960254875046203)
,p_name=>'P135_FILTER_THEMEN_PRE_CLUSTER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(640021615752615603)
,p_prompt=>'Cluster Vorfilter'
,p_source=>'-1'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  c.BEZEICHNUNG, c.konzern_clusterid from T_Konzern_cluster c ',
'order by  c.BEZEICHNUNG;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-alle-'
,p_lov_null_value=>'-1'
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(337807177399290264)
,p_name=>'P135_PRIO'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Prio'
,p_source=>'PRIO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:1;1,2;2,3;3,4;4,5;5,6;6'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- nicht festgelegt -'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2659997210647113569)
,p_name=>'P135_FLAGGE_URL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl2(landid, apex_page.get_url(p_page => 0, p_items => ''G_LANDID'', p_values => landid, p_request => ''APPLICATION_PROCESS=getFlag''), null)',
'from t_land ',
'where rowid = :P135_ROWID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663053651544110296)
,p_name=>'P135_ROWID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Rowid'
,p_source=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663053993380110323)
,p_name=>'P135_LANDID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_source=>'LANDID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P135_LANDID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663054337814110329)
,p_name=>'P135_B_NUMMER'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>'B-Nummer'
,p_source=>'B_NUMMER'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>80
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663054710379110330)
,p_name=>'P135_LAND'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Land German'
,p_source=>'LAND'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>400
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663055159211110331)
,p_name=>'P135_FLAGGE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Flagge'
,p_source=>'FLAGGE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>60
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'content_disposition', 'attachment',
  'display_as', 'NATIVE',
  'display_download_link', 'Y',
  'storage_type', 'DB_COLUMN')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663055559053110334)
,p_name=>'P135_EINSATZDATUM_MODELLID'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Einsatzdatum Modell'
,p_source=>'EINSATZDATUM_MODELLID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select modell, einsatzdatum_modellid',
'from t_einsatzdatum_modell',
'order by 2 asc'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual',
'where :FSP_LANGUAGE_PREFERENCE = ''de''',
''))
,p_display_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663055884594110334)
,p_name=>'P135_STARTDATUM_TYP'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_item_default=>'10'
,p_prompt=>'Art des Startdatums'
,p_source=>'STARTDATUM_TYP'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_STARTDATUM_TYP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''SOP'', ''SOP'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Markteinf\00FChrung (ME)'', ''Market Introduction (MI)'') AS display_value,'),
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2679000793651443340)
,p_name=>'P135_BETAFLAG'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>'Beta'
,p_source=>'BETAFLAG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2679000953554443341)
,p_name=>'P135_TYPSCHILD'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(2663050098054110273)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Typschild'
,p_source=>'TYPSCHILD'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>200
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(894384942169630078)
,p_validation_name=>'Validate duplikate'
,p_validation_sequence=>10
,p_validation=>'not exists (select * from t_land where trim(b_nummer) = trim(:P135_B_NUMMER) )'
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'b_Nummer existiert bereits!'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(2663050474446110274)
,p_associated_item=>wwv_flow_imp.id(2663054337814110329)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(894384926821630077)
,p_validation_name=>'Validate Landbezeichnung'
,p_validation_sequence=>20
,p_validation=>'not exists (select * from t_land where trim(land) = trim(:P135_LAND) )'
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Ein Land mit gleichem Namen existiert bereits.'
,p_when_button_pressed=>wwv_flow_imp.id(2663050474446110274)
,p_associated_item=>wwv_flow_imp.id(2663054710379110330)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(658639439640621093)
,p_validation_name=>'Validate ob Subland'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'   l_cnt number := 0;',
'begin  ',
unistr('    -- pr\00FCfe ob iSO_CODE_3 in mapping Tabelle vorkommt (mapping_typ = 2) =>  bereits gemappt auf eine Landid'),
unistr('    -- wenn Ja, dann darf dieses Land nicht in die l\00E4nder stammdaten aufgenommen werden'),
'    if (PCK_RI_GETEX_CTRL.fSubcountryCheck = 1) then',
'        select count(*) into  l_cnt FROM T_land_MAPPING_GETEX WHERE  MAPPING_TEXT = :P135_ISO_CODE_3 ;',
'        return (l_cnt = 0);',
'    end if;',
'',
' return (l_cnt = 0);',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('ISO_CODE ist bereits f\00FCr Sub-Land verwendet')
,p_validation_condition=>'SAVE,CREATE'
,p_validation_condition_type=>'REQUEST_IN_CONDITION'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2663051325704110275)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2663051201816110275)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2663052096538110283)
,p_event_id=>wwv_flow_imp.id(2663051325704110275)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(640021279363615600)
,p_name=>'Change value'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P135_FILTER_THEMEN_PRE_AK'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(640021198368615599)
,p_event_id=>wwv_flow_imp.id(640021279363615600)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadThemenShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(639843860276069402)
,p_name=>'enter im Themensuchfeld'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P135_FILTER_THEMEN_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(639843768842069401)
,p_event_id=>wwv_flow_imp.id(639843860276069402)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadThemenShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(639843376040069397)
,p_name=>'Add childThemen'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P135_FILTER_THEMEN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(639843291531069396)
,p_event_id=>wwv_flow_imp.id(639843376040069397)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lThemenliste apex_t_number := apex_string.split_numbers(:P135_FILTER_THEMEN,'':'');',
'begin    ',
'',
'    apex_json.initialize_clob_output;',
'    apex_json.open_array;    ',
'',
unistr('    -- Jedes bereits ausgew\00E4hlte Thema durchgehen und dessen Kinder selektieren'),
'    for i in 1 .. lThemenliste.count loop',
'        for childthemen in (',
'            select themaid, nummer || '' - '' || bezeichnung as d',
'            from t_thema',
'            connect by parentid = prior themaid',
'            start with parentid = lThemenliste(i)',
'        ) loop',
'            -- Wenn das entsprechende Kind noch nicht im Shuttle ist, dann ',
unistr('            -- zu einer Hinzuf\00FCgungs-Liste addieren'),
'            if (childthemen.themaid not member of lThemenliste) then',
'                apex_json.open_object;',
'                apex_json.write(''id'',childthemen.themaid);',
'                apex_json.write(''display'',childthemen.d);',
'                apex_json.close_object;',
'            end if;',
'        end loop;',
'    ',
'    end loop;',
unistr('    -- Hinzuf\00FCgungs-Liste ist hidden item'),
unistr('    -- Direktes Hinzuf\00FCgen w\00FCrde zu einem Refresh der Scrollbalken des Items f\00FChren'),
'    apex_json.close_array;',
'    :P135_THEMEN_CHILDREN_TO_ADD := apex_json.get_clob_output;',
'    apex_json.free_output;',
'end;    '))
,p_attribute_02=>'P135_FILTER_THEMEN'
,p_attribute_03=>'P135_THEMEN_CHILDREN_TO_ADD'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(639842795842069391)
,p_event_id=>wwv_flow_imp.id(639843376040069397)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var items = JSON.parse($v(''P135_THEMEN_CHILDREN_TO_ADD''));',
'',
unistr('// alle Items im Shuttle hinzuf\00FCgen'),
'for (item of items) {',
'    if (item) addItemToShuttle(''P135_FILTER_THEMEN'',item.id,item.display);',
'} '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(638960188777046202)
,p_name=>'Change Cluster Filter'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P135_FILTER_THEMEN_PRE_CLUSTER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(638960135439046201)
,p_event_id=>wwv_flow_imp.id(638960188777046202)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadThemenShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(429932096921891586)
,p_name=>'Create - P56 closed'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(429933395476891599)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(429931955384891585)
,p_event_id=>wwv_flow_imp.id(429932096921891586)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(442911007483880864)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(429931702504891582)
,p_name=>'Create - P925 closed'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(380764958015058794)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(429931593644891581)
,p_event_id=>wwv_flow_imp.id(429931702504891582)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(442910479922880859)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(429930915437891574)
,p_name=>'Edit - P56 closed'
,p_event_sequence=>90
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(442911007483880864)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(429930823718891573)
,p_event_id=>wwv_flow_imp.id(429930915437891574)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(442911007483880864)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(429930057058891566)
,p_name=>'Edit - P925 closed'
,p_event_sequence=>100
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(442910479922880859)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(429930015371891565)
,p_event_id=>wwv_flow_imp.id(429930057058891566)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(442910479922880859)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(641415104624456590)
,p_name=>'Alert'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P135_SUMS_RELEVANT'
,p_condition_element=>'P135_SUMS_RELEVANT_ALERT'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'10'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(641414973149456589)
,p_event_id=>wwv_flow_imp.id(641415104624456590)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>unistr('Dies zu speichern k\00F6nnte dazu f\00FChren, dass einige Vorschriften f\00FCr das Potentiell SUMS-relevante Element auf "nicht relevant" gesetzt werden!')
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P135_SUMS_RELEVANT'
,p_client_condition_expression=>'10'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2663058549867110337)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_LAND'
,p_attribute_02=>'T_LAND'
,p_attribute_03=>'P135_ROWID'
,p_attribute_04=>'ROWID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6335270865766498572
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(639842712333069390)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Themen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(distinct themaid, '':'') within group (order by Themaid)',
'into :P135_FILTER_THEMEN FROM T_LAND_statement_of_completeness',
'where Landid=:P135_LANDID;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>3032369603566318845
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2663058885105110339)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of T_LAND'
,p_attribute_02=>'T_LAND'
,p_attribute_03=>'P135_ROWID'
,p_attribute_04=>'ROWID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>6335271201004498574
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(639842618596069389)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*insert into T_LAND_STATEMENT_OF_COMPLETENESS (LANDID, THEMAID) ',
'select :P135_LANDID, column_value from table (apex_string.split_numbers(:P135_FILTER_THEMEN, '':'') );*/',
'--save themen zum Land  ',
'declare ',
'   count_del number :=0;',
'begin',
' --select count(column_value) into count_del  from table (apex_string.split_numbers(:P135_FILTER_THEMEN, '':''));',
' --debug(''count_del: '', count_del);',
' --debug(''P135_FILTER_THEMEN: '', :P135_FILTER_THEMEN);',
'  DELETE from T_LAND_STATEMENT_OF_COMPLETENESS ',
'   where LANDID = :P135_LANDID',
'     AND THEMAID not in ( select column_value from table (apex_string.split_numbers(:P135_FILTER_THEMEN, '':'')));',
'',
'  insert into T_LAND_STATEMENT_OF_COMPLETENESS (landid, themaid)',
'       select :P135_LANDID , column_value  ',
'         from table (apex_string.split_numbers(:P135_FILTER_THEMEN, '':'') );',
'      ',
'end;',
'      '))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Fehler bei der Zuweisung von Themengebieten!'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3032369697303318846
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(641413659672456576)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PROCEDURE - UPDATE_VORSCHRIFT_RXSWIN'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'if :P135_SUMS_RELEVANT  !=10 then ',
'    PCK_RI_HISTORY.UPDATE_VORSCHRIFT_RXSWIN(P_LANDID =>:P135_LANDID);',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>3030798656226931659
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2663059340701110339)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2663050691422110274)
,p_internal_uid=>6335271656600498574
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2663059738099110339)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>6335272053998498574
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(639843055635069394)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadThemenShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lText varchar2(2000) := apex_application.g_x02;',
'    lArbeitskreise varchar2(2000) := apex_application.g_x03;',
'    lcluster varchar2(2000) := apex_application.g_x04;',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    --debug(''selected'', lSelected);',
'    --debug(''lText'', lText);',
'    --debug(''lArbeitskreise'', lArbeitskreise);',
'    for l in (',
'        select nummer || '' - '' || bezeichnung as d, themaid as r',
'        from v_thema_baum',
'        where upper(nummer || '' - '' || bezeichnung) like ''%'' || upper(lText) || ''%''',
'        and  themaid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))      ',
'        and',
'        (',
'            lArbeitskreise = ''-1'' or themaid  in (Select themaid from t_thema_ref_et_b_ak tre where et_b_akid in (',
'                select column_value from table(apex_string.split(lArbeitskreise,'':'')))',
'            )',
'        )',
'        and',
'        (',
'            lCluster = ''-1'' or themaid  in (Select distinct themaid from t_thema_ref_cluster  where konzern_clusterid in (',
'                select column_value from table(apex_string.split(lCluster,'':'')))',
'            )',
'        )',
'        group by nummer, bezeichnung, themaid, thema_sortorder order by thema_sortorder     ',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.r);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'    ',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3032369260264318841
);
wwv_flow_imp.component_end;
end;
/
