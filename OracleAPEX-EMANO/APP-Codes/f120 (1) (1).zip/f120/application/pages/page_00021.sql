prompt --application/pages/page_00021
begin
--   Manifest
--     PAGE: 00021
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>21
,p_name=>'Vorschriften'
,p_alias=>'VORSCHRIFTEN-LANG'
,p_step_title=>'Vorschriften'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#P21_FLAG_KF_LABEL'').hide(); ',
'$(''#P21_SHORT_LABEL'').hide();',
'$(''#P21_SUPPLEMENTS_LABEL'').hide();',
'',
'$(''#P21_FLAG_KF'').detach().prependTo(''#VSIG div.a-IRR-buttons'')',
'  .css(''margin-right'', ''10px'')',
'  .css(''margin-top'', ''-1px'');',
'',
'$(''#P21_SUPPLEMENTS'').detach().insertAfter(''#P21_FLAG_KF'')',
'  .css(''margin-right'', ''10px'')',
'  .css(''margin-top'', ''-1px'');',
'',
'',
'$(''#P21_SHORT'').detach().insertAfter(''#P21_SUPPLEMENTS'')',
'  .css(''margin-right'', ''10px'')',
'  .css(''margin-top'', ''-1px'');',
'',
'$(''#P21_STATUS_BEZ_CONTAINER'').detach()',
'  .insertBefore(''#Create_button'')',
'  .css({',
'    ''display'': ''inline-block'', ',
'    ''visibility'': ''visible'', ',
'    ''margin-right'': ''10px'', ',
'    ''margin-top'': ''-1px'', ',
'    ''text-align'': ''right''',
'  });',
'',
'$(''#P21_STATUS_BEZ'').css({',
'  ''font-weight'': ''normal'',',
'  ''font-size'': ''14px'',',
'  ''color'': ''#c94645'',',
'  ''width'': ''auto !important''',
'});',
'',
unistr('$("label[for=''P21_FLAG_KF_Y'']").attr(''title'',''Blendet Vorschriften, die durch letztg\00FCltige Fassungen ersetzt worden sind, ein'');'),
unistr('$("label[for=''P21_FLAG_KF_N'']").attr(''title'',''Blendet Vorschriften, die durch letztg\00FCltige Fassungen ersetzt worden sind, aus'');'),
'',
'$(''#VSIG div.a-IRR-buttons'').css({',
'  ''display'': ''flex'',',
'  ''justify-content'': ''flex-end'',',
'  ''align-items'': ''center''',
'});',
'',
'$(''#P21_SHORT_CONTAINER'').closest(''div.row'').remove();',
'',
'',
'',
'',
'/* Click auf Checkbox in Tabellenheader: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'$(''#VSIG'').on(''click'', ''th input'', function() {',
'    var check_all = $("#VSIG").find("th input:checked").is(":checked");',
'',
unistr('    // alle Zeilen ausw\00E4hlen/abw\00E4hlen'),
'    $("#VSIG").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'    // Button aktivieren/deaktivieren',
'    if (check_all) {',
'        $("#b_MB").removeClass("apex_disabled");',
'    } else {',
'        $("#b_MB").addClass("apex_disabled");',
'    }',
'',
'    $("#b_MB").prop(''disabled'', !check_all);',
'    ',
unistr('    // alle ausgew\00E4hlten Zeilen-IDs in das Item P21_SELECTED_ROWS'),
'    var sel_rows = apex.item(''P21_SELECTED_ROWS'');',
'    sel_rows.setValue("");',
'    $("#VSIG").find("td input:checked").each(function() {',
'      if(sel_rows.getValue().length > 0) {',
'        sel_rows.setValue(sel_rows.getValue() + ":");    ',
'      }',
'      sel_rows.setValue(sel_rows.getValue() + this.value);',
'    });',
'    apex.server.process(''MY_PROCESS'', {',
'        pageItems: ''#P21_SELECTED_ROWS''',
'    },{dataType: ''text''});',
'    //alert (sel_rows.getValue());',
'});',
'',
'// Hilfe Button',
'$(''#VSIG_toolbar_controls'').append('' <span onclick="redirect(4)" style="font-size:2.7em" class="fa fa-question-square-o"></span>'');',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#VSIG .t-fht-tbody {max-height: calc(100vh - 260px)}',
'.t-Body-topButton {display: none !important}',
'.t-Body-content {padding-bottom: 3px !important}',
'.t-Body {margin-bottom: 3px !important}',
'.t-Body-contentInner {padding-bottom: 0px !important}',
'',
'#VSIG_filter_type > .a-IRR-radioIconList-item:nth-child(3) {',
'    display: none;',
'}',
'',
'',
'.apex-item-display-only, ',
'.t-Form-itemWrapper ',
'.t-Form-itemWrapper input ',
'{',
'    order: 3;',
'    color: #bb0a31 !important;',
'    width: 225px !important;',
'}',
'',
'',
'/* #P21_STATUS_BEZ_CONTAINER',
'{',
'    position: absolute; ',
'    right: 20px;',
'}  */',
'',
'',
'',
'',
'',
'button#Create_button {',
'    margin-bottom: 10px !important; ',
'',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(644902555929644167)
,p_plug_name=>'Vorschriften <span onclick="redirect(4)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_typschild1 as (',
'    select distinct vrv.vorgaenger_vorschriftid vorschriftid ,l.typschild typschild',
'    from t_vorschrift v1',
'     left outer join t_vorschrift_ref_land vrl on (v1.vorschriftid = vrl.vorschriftid)',
'    join t_vorschrift_ref_vorschrift vrv on (vrv.nachfolger_vorschriftid = v1.vorschriftid and vrv.beziehung_art = 40)',
'    join T_LAND l on l.landid = vrl.landid',
'    where vrl.geloescht = 0 ',
'    union',
'    Select distinct trl.vorschriftid, l.typschild typschild',
'    from T_VORSCHRIFT_REF_LAND trl',
'    join T_LAND l on l.landid = trl.landid',
'    where trl.geloescht = 0',
'), cte_typschild2 as (',
'    select vorschriftid, listagg(typschild,'', '') within group (order by typschild) as liste_typschild',
'    from cte_typschild1',
'    group by vorschriftid',
')',
'',
',r as (',
'  select v.vorschriftid vorschriftid, ',
'  listagg(CASE WHEN vrv.IST_HAUPTVERANTWORTLICHER = 10 THEN ',
'  ''<span style="text-decoration: underline;">'' || vv.nachname || '', '' || vv.vorname || ''</span>''',
'  ELSE vv.nachname || '', '' || vv.vorname END, ''; '') WITHIN GROUP (ORDER BY vv.nachname) as verantwortlicher  ',
'from t_vorschrift v',
'join t_vorschrift_ref_verantwortlicher vrv on vrv.vorschriftid = v.vorschriftid',
'join t_verantwortlicher vv on vv.verantwortlicherid = vrv.verantwortlicherid',
'group by v.vorschriftid',
'),',
'',
'konzerntickets as (',
'    select tv.vorschriftid, listagg(''<a href="'' || link || ''" target="_blank">'' || ticketnr || ''</a>'','', '') within group (order by ticketnr) tickets',
'    from t_konzern_jira_ticket t',
'    join t_konzern_jira_ticket_ref_vorschrift tv on (t.konzern_jira_ticketid = tv.konzern_jira_ticketid)',
'    group by tv.vorschriftid',
')',
'',
'select vs."ROWID" as xrowid,',
'''<a href="'' ||',
'            apex_page.get_url(p_page => 25, p_items => ''P25_VORSCHRIFTID'', p_values => vs.vorschriftid, p_clear_cache => 25)',
'            || ''" target="detail_s"><span alt="Anzeigen" title="Anzeigen" class="fa fa-search"></span></a> '' detail_s,',
'1 as checkbox,',
'vs.vorschriftid,',
'vs.vorschriftid as link_netz,',
'"VORSCHRIFT_NUMMER",',
'"VORSCHRIFT_BEZEICHNUNG",',
'"VORSCHRIFT_TYPID",',
'vs.prognose_qualitaetid as "PROGNOSE_QUALITAET",',
'--PCK_RI.fJiraTicketsToLinks("JIRA_TICKET") AS "JIRA_TICKET",',
'"VORSCHRIFT_FREIGABESTATUSID",',
'"BEMERKUNG",',
'PCK_RI.fCreateLinkIfUrl("LINK_ZUR_VORSCHRIFT_DMS") AS "LINK_ZUR_VORSCHRIFT_DMS",',
'nvl2("LINK_ZUR_VORSCHRIFT_GETEX", "LINK_ZUR_VORSCHRIFT_GETEX" || '' <a href="https://getex.wob.vw.vwg/web/guest/dokumente_suche" target="_blank">Getex 1.0 &ouml;ffnen</a>'', null) AS "LINK_ZUR_VORSCHRIFT_GETEX",',
'mfv.liste_mfv as "MfV ID",',
'ts.liste_typschild as "TYPSCHILD",',
'    nvl2(ws.hilfetext, '' <span class="fa fa-info-circle" aria-hidden="true" onClick="javascript:apex.message.alert(''',
'         || apex_escape.js_literal(ws.hilfetext) || '');"></span> '', null) || PCK_RI.fCreateLinkIfUrl("WEBSITELINK") as "WEBSITLINK",',
'ws.hilfetext as WEBSITE_HILFETEXT,',
'k.bezeichnung as "KSU",',
'vs."LETZTE_AENDERUNG_DATUM",',
'nvl2(b.benutzerid, b.nachname || '', '' || b.vorname, null) letzte_aenderung_benutzer,',
'x.list_land,',
'ed.in_kraft,',
'etb.liste as etb_ak,',
'tg.liste as themengebiete,',
'vs.VORSCHRIFT_STATUSID,',
'vs.rxswin as rxswin_relevant,',
'  case when (nvl(vs.without_norm_validation, 0) = 0 ) then ''Nein'' ',
'          else ''Ja'' end  "Keine Norm Validierung",',
'r.verantwortlicher,',
'MJ_Phasein_start,',
'MJ_Phasein_end,',
'Alle_Fahrzeuge_FBU,',
'Alle_Fahrzeuge_CKD,',
'Neue_Typen_FBU,',
'Neue_Typen_CKD,',
'Neue_Typen,',
'Alle_Fahrzeuge,',
'EINSATZDATUM_MODELLID,',
'apex_util.host_url(''SCRIPT'') || apex_page.get_url(',
'    p_application => :APP_ALIAS',
'    , p_page => ''VORSCHRIFT''',
'    , p_items => ''P25_VORSCHRIFTID''',
'    , p_values => vs.vorschriftid',
'    , p_session => null',
'    , p_clear_cache => ''25''',
') as permalink,',
'antriebsart.liste antriebsart,',
'vs.COP_RELEVANT cop_relevant,',
'vs.technologie,',
'-- vs.inhaltlich_sachlich_geprueft,',
'vs.swr_hauptumsetzende_oe,',
'kt.tickets,',
'n.bezeichnung as notation,',
'case vs.vorschrift_typid when 20 then fks.liste else fk.liste end liste,',
'nvl2(vs.lead_VKO_Benutzerid, b2.nachname ||'', '' || b2.vorname, '''') as Lead_VKO,',
'case when (vs.status_update_getex is null) then ''-''',
'                 when vs.status_update_getex  =10 then ''aktuell'' ',
'            when vs.status_update_getex  =20 then ''nicht aktuell'' ',
'            when vs.status_update_getex  =30 then  ''nicht in Getex''  end  as status_update_getex',
'',
'',
'from "#OWNER#"."T_VORSCHRIFT" vs',
'left outer join konzerntickets kt on (vs.vorschriftid = kt.vorschriftid)',
' left join r on (r.vorschriftid = vs.vorschriftid)',
'--  left outer join t_vorschrift_ref_verantwortlicher vrv on (vrv.vorschriftid = r.vorschriftid)',
'left outer join T_BENUTZER b on b.benutzerid = vs.letzte_aenderung_benutzerid',
'left outer join T_BENUTZER b2 on b2.benutzerid = vs.lead_VKO_Benutzerid',
'left outer join T_WEBSITE ws on ws.websiteid = vs.websiteid',
'left outer join T_KSU k on k.ksuid = vs.ksuid',
'left outer join cte_typschild2 ts on (vs.vorschriftid = ts.vorschriftid)',
'left outer join t_norm n on (vs.normid = n.normid)',
'',
'outer apply (',
'    select einsatzdatum in_kraft',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1000',
'    fetch first 1 rows only',
') ed',
'outer apply (',
'         select listagg(concat( b_nummer, case when mod(r_n,8)=0 then '', '' else '','' end ), '''') list_land  ',
'          from',
'          (  select b_nummer, row_number() over (order by b_nummer) as r_n',
'             from (',
'                select distinct land.b_nummer b_nummer',
'                from T_VORSCHRIFT_REF_LAND vtl ',
'                left outer join t_land land on land.landid = vtl.landid',
'                where vtl.vorschriftid = vs.vorschriftid and vtl.geloescht = 0',
'                ',
'                union',
'                  -- demands',
'                select distinct l.b_nummer b_nummer',
'                from t_vorschrift_ref_vorschrift vrv',
'                join t_vorschrift_ref_land rtl on (vrv.nachfolger_vorschriftid = rtl.vorschriftid)',
'                join t_land l on (rtl.landid = l.landid)',
'                where vorgaenger_vorschriftid = vs.vorschriftid and beziehung_art = 40 and rtl.geloescht = 0',
'                ',
'                 union',
'                  -- equivalent',
'                select  distinct l.b_nummer b_nummer ',
'                from t_vorschrift_ref_vorschrift vrv',
'                join t_vorschrift_ref_land rtl on (vrv.nachfolger_vorschriftid = rtl.vorschriftid)',
'                join t_land l on (rtl.landid = l.landid)',
'                where vorgaenger_vorschriftid = vs.vorschriftid ',
'                and vrv.beziehung_art = 102 and rtl.geloescht = 0',
'             ) ',
'          )',
' ) x',
'',
'outer apply (',
'    select listagg(etb,'', '') within group (order by etb) liste',
'    from (',
'        ',
'        select distinct ak.kurz etb',
'        from t_vorschrift_ref_et_b_ak t',
'        join t_et_b_ak ak on (ak.et_b_akid = t.et_b_akid)',
'        where t.vorschriftid = vs.vorschriftid and t.geloescht = 0',
'    )',
') etb',
'',
'outer apply (',
'    select listagg(tg,'', '') within group (order by tg) liste',
'    from (',
'        select distinct t.nummer tg',
'        from t_vorschrift_ref_thema vtl',
'        join t_thema t on (vtl.themaid = t.themaid)',
'        where vtl.vorschriftid = vs.vorschriftid and vtl.geloescht = 0',
'    )',
') tg',
'',
'outer apply (',
'   select listagg(distinct mfv,'', '') within group (order by mfv) as liste_mfv',
'   from(',
'       select  m.mfv_name  mfv',
'         from T_MFV_Ref_Vorschrift mrv  --on (mrv.Vorschriftid = v.Vorschriftid)',
'         join t_MFV m on (m.MFVid = mrv.MFVid)',
'        where mrv.vorschriftid = vs.vorschriftid ',
'    )',
') mfv',
'',
'outer apply (',
'    select listagg(antriebsart,'', '') within group (order by antriebsart) liste',
'    from (',
'        select distinct aa.bezeichnung antriebsart',
'        from t_vorschrift_ref_thema vtl',
'        join t_thema_ref_antriebsart trf on (vtl.themaid = trf.themaid)',
'        join t_antriebsart aa on (aa.antriebsartid = trf.antriebsartid)',
'        where vtl.vorschriftid = vs.vorschriftid and vtl.geloescht = 0',
'    )',
') antriebsart',
'',
' /*',
' select distinct typschild typschild',
'        from cte1 ttl',
'        where ttl.vorschriftid = vs.vorschriftid ',
'    )',
') ts*/',
'outer apply (',
'    select einsatzdatum Neue_Typen_CKD',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1020',
'    fetch first 1 rows only',
') ntc',
'outer apply (',
'    select einsatzdatum Alle_Fahrzeuge_CKD',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1021',
'    fetch first 1 rows only',
') afc',
'outer apply (',
'    select einsatzdatum Neue_Typen_FBU',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1022',
'    fetch first 1 rows only',
') ntc',
'outer apply (',
'    select einsatzdatum Alle_Fahrzeuge_FBU',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1023',
'    fetch first 1 rows only',
') afc',
'outer apply (',
'    select einsatzdatum MJ_Phasein_start',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1030',
'    fetch first 1 rows only',
') ntmj',
'outer apply (',
'    select einsatzdatum MJ_Phasein_end',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1031',
'    fetch first 1 rows only',
') afmj',
'outer apply (',
'    select einsatzdatum Neue_Typen',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1010',
'    fetch first 1 rows only',
') nt',
'outer apply (',
'    select einsatzdatum Alle_Fahrzeuge',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1011',
'    fetch first 1 rows only',
') af',
'',
'outer apply (',
'    select listagg(bezeichnung,''; '') within group (order by bezeichnung) liste',
'    from t_vorschrift_ref_fahrzeugklasse vrf',
'    join t_fahrzeugklasse f on (vrf.fahrzeugklasseid = f.fahrzeugklasseid)',
'    where vrf.vorschriftid = vs.vorschriftid',
') fk',
'',
'outer apply (',
'    select listagg(bezeichnung,''; '') within group (order by bezeichnung) liste',
'    from t_vorschrift_ref_fahrzeugklasse vrf',
'    join t_fahrzeugklasse f on (vrf.fahrzeugklasseid = f.fahrzeugklasseid)',
'    where vrf.vorschriftid = (',
'        select vrv.vorgaenger_vorschriftid',
'        from t_vorschrift_ref_vorschrift vrv',
'        where vrv.nachfolger_vorschriftid = vs.vorschriftid',
'        and vrv.BEZIEHUNG_ART = 30',
'        fetch first row only',
'    )',
') fks',
'',
'',
'where (vs.vorschrift_typid in (10, 30, 40) -- Supplements nicht anzeigen',
'       or vs.vorschrift_typid in (select case when (:P21_SUPPLEMENTS = 20) then 20 else 0 end from dual)',
'       )',
'and (',
unistr('    (vs.vorschrift_freigabestatusid = 10 and pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002:1040:1006'') > 0) -- Wenn Status "in Bearbeitung" dann sichtbar f\00FCr Fachadmin, VKO, VEX, ZVEX, KFEX, GBEX'),
unistr('    or vs.vorschrift_freigabestatusid = 20 -- Wenn Status "freigegeben", dann sichtbar f\00FCr alle'),
unistr('    or (vs.vorschrift_freigabestatusid = 30 and pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0) -- Wenn Status "nicht relevant", dann sichtbar f\00FCr Fachadmin, VKO, VEX, ZVEX'),
'    or (vs.vorschrift_freigabestatusid is null and vs.vorschrift_typid = 20) -- Supplements haben keinen Status',
')',
'  '))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P21_SHORT,P21_SUPPLEMENTS'
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(644902441248644166)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'Keine Vorschriften gefunden.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>1000
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV'
,p_enable_mail_download=>'N'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>467790495846490238
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644902372196644165)
,p_db_column_name=>'XROWID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Xrowid'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644902271499644164)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'<input type="checkbox" value="all" />'
,p_column_html_expression=>'<input type="checkbox" value="#VORSCHRIFTID#" />'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_rpt_show_filter_lov=>'N'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644902186522644163)
,p_db_column_name=>'LINK_NETZ'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:RP,300:P300_VORSCHRIFTID:#LINK_NETZ#'
,p_column_linktext=>unistr('<span class="fa fa-network-hub" title="Vernetzungsansicht \00F6ffnen" alt="Vernetzungsansicht \00F6ffnen"></span>')
,p_column_link_attr=>'target="_blank"'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644702101311644162)
,p_db_column_name=>'PERMALINK'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'<span title="Permalink">&nbsp;</span>'
,p_column_html_expression=>'<span class="fa fa-link" title="Permalink in Zwischenablage kopieren" alt="Permalink in Zwischenablage kopieren" onClick="javascript:navigator.clipboard.writeText(''#PERMALINK#'');alert(''Der Permalink wurde in die Zwischenablage kopiert:\n\n#PERMALINK#'
||''');"></span>'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644702008900644161)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Vorschriftid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644701912882644160)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Vorschriften&shy;nummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644701740809644159)
,p_db_column_name=>'VORSCHRIFT_BEZEICHNUNG'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Titel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644701661080644158)
,p_db_column_name=>'VORSCHRIFT_TYPID'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Vorschrift Typ'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(2656545044559578040)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644701579107644157)
,p_db_column_name=>'PROGNOSE_QUALITAET'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('Prognose Qualit\00E4t')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(958121403566083634)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644701488920644156)
,p_db_column_name=>'VORSCHRIFT_STATUSID'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Status der Vorschrift'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(2490458092659806028)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644701399914644155)
,p_db_column_name=>'VORSCHRIFT_FREIGABESTATUSID'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Interner Freigabe&shy;status'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(958129793570194302)
,p_rpt_show_filter_lov=>'1'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644701280963644154)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Bemerkung zur Vorschrift'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643891119067305803)
,p_db_column_name=>'ETB_AK'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'ET-B AK'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643890946212305802)
,p_db_column_name=>'LIST_LAND'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>unistr('L\00E4nder ')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643890902295305801)
,p_db_column_name=>'LINK_ZUR_VORSCHRIFT_GETEX'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Getex 1.0 ID'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643890835301305800)
,p_db_column_name=>'WEBSITLINK'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Link zu Web Site'
,p_column_html_expression=>'<span title="#WEBSITE_HILFETEXT#">#WEBSITLINK#</span>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643890674948305799)
,p_db_column_name=>'LINK_ZUR_VORSCHRIFT_DMS'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Link zu DMS'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643890551436305798)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643890484450305797)
,p_db_column_name=>'TYPSCHILD'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Typschild'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643890418894305796)
,p_db_column_name=>'KSU'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'KSU'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643890252464305795)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643890193699305794)
,p_db_column_name=>'WEBSITE_HILFETEXT'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Website Hilfetext'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643890065198305793)
,p_db_column_name=>'IN_KRAFT'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Datum Inkraftsetzung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643890029097305792)
,p_db_column_name=>'THEMENGEBIETE'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Themengebiete'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643889877803305791)
,p_db_column_name=>'RXSWIN_RELEVANT'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'potentiell SUMS-Relevant'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(958135905312245351)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643889761699305790)
,p_db_column_name=>'SWR_HAUPTUMSETZENDE_OE'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Hauptumsetzende OE2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643889696463305789)
,p_db_column_name=>'MJ_PHASEIN_START'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Mj Phasein Start'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643889618625305788)
,p_db_column_name=>'MJ_PHASEIN_END'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Mj Phasein End'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643889471591305787)
,p_db_column_name=>'ALLE_FAHRZEUGE_FBU'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Alle Fahrzeuge FBU'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643889392269305786)
,p_db_column_name=>'ALLE_FAHRZEUGE_CKD'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Alle Fahrzeuge CKD'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643889323409305785)
,p_db_column_name=>'NEUE_TYPEN_FBU'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Neue Typen FBU'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643889207048305784)
,p_db_column_name=>'NEUE_TYPEN_CKD'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Neue Typen CKD'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643889048401305783)
,p_db_column_name=>'NEUE_TYPEN'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Neue Typen'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643889023887305782)
,p_db_column_name=>'ALLE_FAHRZEUGE'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Alle Fahrzeuge'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643888841834305781)
,p_db_column_name=>'EINSATZDATUM_MODELLID'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Einsatzdatum Modell'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(1076773784946225404)
,p_rpt_show_filter_lov=>'1'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643888790354305780)
,p_db_column_name=>'ANTRIEBSART'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Antriebsart'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643888709714305779)
,p_db_column_name=>'COP_RELEVANT'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'CoP Relevant'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(958149357559525013)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643888589318305778)
,p_db_column_name=>'TECHNOLOGIE'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Technologie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643888456755305777)
,p_db_column_name=>'VERANTWORTLICHER'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Regulierungs&shy;verantwortliche'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643888367526305776)
,p_db_column_name=>'MfV ID'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Mfv Id'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643888317708305775)
,p_db_column_name=>'Keine Norm Validierung'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Keine Norm Validierung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643888223514305774)
,p_db_column_name=>'TICKETS'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Konzerntickets'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643888128494305773)
,p_db_column_name=>'NOTATION'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Notation'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643888026129305772)
,p_db_column_name=>'LISTE'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Fahrzeugart'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643887841506305771)
,p_db_column_name=>'LEAD_VKO'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Lead VKO'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643887779022305770)
,p_db_column_name=>'DETAIL_S'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643887667791305769)
,p_db_column_name=>'STATUS_UPDATE_GETEX'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Status Update Getex'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'pck_ri.fIsUserInRolle(listRolleId => ''1100:1003'') > 0'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2839745020692487120)
,p_plug_name=>'Vorschriften <span onclick="redirect(4)" style="font-size:1.5em" class="fa fa-question-square-o"></span> : Letzte Aktualisierung - <b><u> &P21_REFRESH_DATE_TIME.</u></b> '
,p_region_name=>'VSIG'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    MVLVR.XROWID,',
'    ''<a href="'' || apex_page.get_url(p_page => 25, p_items => ''P25_VORSCHRIFTID'', p_values => MVLVR.vorschriftid, p_clear_cache => 25)',
'    || ''" target="detail_s"><span alt="Anzeigen" title="Anzeigen" class="fa fa-search"></span></a> '' AS DETAIL_S,',
'    MVLVR.CHECKBOX,',
'    MVLVR.VORSCHRIFTID,',
'    MVLVR.LINK_NETZ,',
'    MVLVR.VORSCHRIFT_NUMMER,',
'    MVLVR.VORSCHRIFT_BEZEICHNUNG,',
'    MVLVR.VORSCHRIFT_TYPID,',
'    MVLVR.PROGNOSE_QUALITAET,',
'    MVLVR.VORSCHRIFT_FREIGABESTATUSID,',
'    MVLVR.BEMERKUNG,',
'    MVLVR.LINK_ZUR_VORSCHRIFT_DMS,',
'    nvl2(MVLVR.LINK_ZUR_VORSCHRIFT_GETEX, MVLVR.LINK_ZUR_VORSCHRIFT_GETEX || '' <a href="https://getex.wob.vw.vwg/web/guest/dokumente_suche" target="_blank">Getex 1.0 &ouml;ffnen</a>'', null) AS LINK_ZUR_VORSCHRIFT_GETEX,',
'    MVLVR.MFV_ID,',
'    MVLVR.TYPSCHILD,',
'    MVLVR.WEBSITLINK,',
'    MVLVR.WEBSITE_HILFETEXT,',
'    MVLVR.KSU,',
'    MVLVR.LETZTE_AENDERUNG_DATUM,',
'    MVLVR.LETZTE_AENDERUNG_BENUTZER,',
'    MVLVR.LIST_LAND,',
'    MVLVR.IN_KRAFT,',
'    MVLVR.ETB_AK,',
'    MVLVR.THEMENGEBIETE,',
'    MVLVR.VORSCHRIFT_STATUSID,',
'    MVLVR.RXSWIN_RELEVANT,',
'    MVLVR.KEINE_NORM_VALIDIERUNG,',
'    -- MVLVR.VERANTWORTLICHER,  -- ticket 1751',
'    MVLVR.MJ_PHASEIN_START,',
'    -- MVLVR.MJ_PHASEIN_END,',
'    MVLVR.ALLE_FAHRZEUGE_FBU,',
'    MVLVR.ALLE_FAHRZEUGE_CKD,',
'    MVLVR.NEUE_TYPEN_FBU,',
'    MVLVR.NEUE_TYPEN_CKD,',
'    MVLVR.NEUE_TYPEN,',
'    MVLVR.ALLE_FAHRZEUGE,',
'    MVLVR.EINSATZDATUM_MODELLID,',
'    apex_util.host_url(''SCRIPT'') || apex_page.get_url(',
'        p_page => ''VORSCHRIFT'',',
'        p_items => ''P25_VORSCHRIFTID'',',
'        p_values => MVLVR.vorschriftid,',
'        p_clear_cache => ''25''',
'    ) AS PERMALINK,',
'    MVLVR.ANTRIEBSART,',
'    MVLVR.COP_RELEVANT,',
'    MVLVR.TECHNOLOGIE,',
'    MVLVR.SWR_HAUPTUMSETZENDE_OE,',
'    MVLVR.TICKETS,',
'    MVLVR.NOTATION,',
'    MVLVR.LISTE,',
'    MVLVR.LEAD_VKO,',
'    MVLVR.STATUS_UPDATE_GETEX,',
'    MVLVR.REV_NOTWENDIG,',
'    MVLVR.DOKUMENTENDATUM,',
'    case MVLVR.FLAG_KONSOLIDIERTE_FASSUNGEN when 1 then ',
unistr('    ''<span title="Es existiert eine letztg\00FCltige Fassung, in welche diese \00C4nderungsvorschrift enthalten ist" class="fa fa-flag"></span>'' '),
'    else null end as flag_konsolidierte_fassungen',
'',
'FROM MV_VORSCHRIFTEN_LANG_VERSION_REPORT MVLVR',
'WHERE (MVLVR.vorschrift_typid IN (10, 30, 40) -- Supplements nicht anzeigen',
'       OR MVLVR.vorschrift_typid IN (SELECT CASE WHEN (:P21_SUPPLEMENTS = 20) THEN 20 ELSE 0 END FROM DUAL)',
'      )',
'  AND (',
unistr('    (MVLVR.vorschrift_freigabestatusid = 10 AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002:1040:1006'') > 0) -- Wenn Status "in Bearbeitung" dann sichtbar f\00FCr Fachadmin, VKO, VEX, ZVEX, KFEX, GBEX'),
unistr('    OR MVLVR.vorschrift_freigabestatusid = 20 -- Wenn Status "freigegeben", dann sichtbar f\00FCr alle'),
unistr('    OR (MVLVR.vorschrift_freigabestatusid = 30 AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0) -- Wenn Status "nicht relevant", dann sichtbar f\00FCr Fachadmin, VKO, VEX, ZVEX'),
'    OR (MVLVR.vorschrift_freigabestatusid IS NULL AND MVLVR.vorschrift_typid = 20) -- Supplements haben keinen Status',
'  )',
'',
'AND (MVLVR.flag_konsolidierte_fassungen = 0 OR :P21_FLAG_KF = 1)'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P21_SHORT,P21_SUPPLEMENTS,P21_FLAG_KF'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2839745367040487120)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'Keine Vorschriften gefunden.'
,p_oracle_text_index_column=>'VORSCHRIFT_NUMMER'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>1000
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV'
,p_enable_mail_download=>'N'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>3952438304135621524
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914480743988914071)
,p_db_column_name=>'XROWID'
,p_display_order=>10
,p_column_identifier=>'T'
,p_column_label=>'Xrowid'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914482011609914073)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>20
,p_column_identifier=>'R'
,p_column_label=>'<input type="checkbox" value="all" />'
,p_column_html_expression=>'<input type="checkbox" value="#VORSCHRIFTID#" />'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_rpt_show_filter_lov=>'N'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 1003 = Fachadmin, 1000 = VKO, 1200 = Redaktionsteam',
'pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1200'') > 0'))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914479948548914065)
,p_db_column_name=>'LINK_NETZ'
,p_display_order=>30
,p_column_identifier=>'W'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:RP,300:P300_VORSCHRIFTID:#LINK_NETZ#'
,p_column_linktext=>unistr('<span class="fa fa-network-hub" title="Vernetzungsansicht \00F6ffnen" alt="Vernetzungsansicht \00F6ffnen"></span>')
,p_column_link_attr=>'target="_blank"'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914489146224914107)
,p_db_column_name=>'PERMALINK'
,p_display_order=>40
,p_column_identifier=>'AM'
,p_column_label=>'<span title="Permalink">&nbsp;</span>'
,p_column_html_expression=>'<span class="fa fa-link" title="Permalink in Zwischenablage kopieren" alt="Permalink in Zwischenablage kopieren" onClick="javascript:navigator.clipboard.writeText(''#PERMALINK#'');alert(''Der Permalink wurde in die Zwischenablage kopiert:\n\n#PERMALINK#'
||''');"></span>'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914482364362914074)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>50
,p_column_identifier=>'P'
,p_column_label=>'Vorschriften ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914487196704914090)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>60
,p_column_identifier=>'B'
,p_column_label=>'Vorschriften&shy;nummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914486817112914089)
,p_db_column_name=>'VORSCHRIFT_BEZEICHNUNG'
,p_display_order=>70
,p_column_identifier=>'C'
,p_column_label=>'Titel'
,p_column_html_expression=>'<span style="display:block; width:200px"> #VORSCHRIFT_BEZEICHNUNG#</span>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914482809356914075)
,p_db_column_name=>'VORSCHRIFT_TYPID'
,p_display_order=>80
,p_column_identifier=>'Q'
,p_column_label=>'Vorschrift Typ'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(2656545044559578040)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914486372709914088)
,p_db_column_name=>'PROGNOSE_QUALITAET'
,p_display_order=>90
,p_column_identifier=>'D'
,p_column_label=>unistr('Prognose Qualit\00E4t')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(958121403566083634)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914487973595914092)
,p_db_column_name=>'VORSCHRIFT_STATUSID'
,p_display_order=>100
,p_column_identifier=>'AB'
,p_column_label=>'Status der Vorschrift'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(2490458092659806028)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914485558719914081)
,p_db_column_name=>'VORSCHRIFT_FREIGABESTATUSID'
,p_display_order=>110
,p_column_identifier=>'F'
,p_column_label=>'Interner Freigabe&shy;status'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(958129793570194302)
,p_rpt_show_filter_lov=>'1'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914485233339914079)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>120
,p_column_identifier=>'G'
,p_column_label=>'Bemerkung zur Vorschrift'
,p_column_html_expression=>'<span style="display:block; width:300px"> #BEMERKUNG#</span>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914479163590914064)
,p_db_column_name=>'ETB_AK'
,p_display_order=>130
,p_column_identifier=>'Y'
,p_column_label=>'ET-B AK'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914480382422914068)
,p_db_column_name=>'LIST_LAND'
,p_display_order=>140
,p_column_identifier=>'U'
,p_column_label=>unistr('L\00E4nder ')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914484346278914078)
,p_db_column_name=>'LINK_ZUR_VORSCHRIFT_GETEX'
,p_display_order=>150
,p_column_identifier=>'I'
,p_column_label=>'Getex 1.0 ID'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914483159398914075)
,p_db_column_name=>'WEBSITLINK'
,p_display_order=>160
,p_column_identifier=>'O'
,p_column_label=>'Link zu Web Site'
,p_column_html_expression=>'<span title="#WEBSITE_HILFETEXT#">#WEBSITLINK#</span>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914484822990914078)
,p_db_column_name=>'LINK_ZUR_VORSCHRIFT_DMS'
,p_display_order=>170
,p_column_identifier=>'H'
,p_column_label=>'Link zu DMS'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914483563446914076)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>180
,p_column_identifier=>'K'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914483938361914077)
,p_db_column_name=>'TYPSCHILD'
,p_display_order=>190
,p_column_identifier=>'J'
,p_column_label=>'Typschild'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914481542830914073)
,p_db_column_name=>'KSU'
,p_display_order=>200
,p_column_identifier=>'S'
,p_column_label=>'KSU'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914487541950914091)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>210
,p_column_identifier=>'M'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914481201654914071)
,p_db_column_name=>'WEBSITE_HILFETEXT'
,p_display_order=>230
,p_column_identifier=>'V'
,p_column_label=>'Website Hilfetext'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914479626056914064)
,p_db_column_name=>'IN_KRAFT'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Datum Inkraftsetzung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914478372841914063)
,p_db_column_name=>'THEMENGEBIETE'
,p_display_order=>250
,p_column_identifier=>'AA'
,p_column_label=>'Themengebiete'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914488362938914097)
,p_db_column_name=>'RXSWIN_RELEVANT'
,p_display_order=>260
,p_column_identifier=>'AC'
,p_column_label=>'potentiell SUMS-Relevant'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(958135905312245351)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(394300813474385588)
,p_db_column_name=>'SWR_HAUPTUMSETZENDE_OE'
,p_display_order=>270
,p_column_identifier=>'BA'
,p_column_label=>'Hauptumsetzende OE2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914492650234914160)
,p_db_column_name=>'MJ_PHASEIN_START'
,p_display_order=>280
,p_column_identifier=>'AD'
,p_column_label=>'Einsatzzeitpunkt'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914491965495914115)
,p_db_column_name=>'ALLE_FAHRZEUGE_FBU'
,p_display_order=>300
,p_column_identifier=>'AF'
,p_column_label=>'Alle Fahrzeuge FBU'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914491552747914113)
,p_db_column_name=>'ALLE_FAHRZEUGE_CKD'
,p_display_order=>310
,p_column_identifier=>'AG'
,p_column_label=>'Alle Fahrzeuge CKD'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914491205444914112)
,p_db_column_name=>'NEUE_TYPEN_FBU'
,p_display_order=>320
,p_column_identifier=>'AH'
,p_column_label=>'Neue Typen FBU'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914490805021914111)
,p_db_column_name=>'NEUE_TYPEN_CKD'
,p_display_order=>330
,p_column_identifier=>'AI'
,p_column_label=>'Neue Typen CKD'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914490359379914110)
,p_db_column_name=>'NEUE_TYPEN'
,p_display_order=>340
,p_column_identifier=>'AJ'
,p_column_label=>'Neue Typen'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914489954838914110)
,p_db_column_name=>'ALLE_FAHRZEUGE'
,p_display_order=>350
,p_column_identifier=>'AK'
,p_column_label=>'Alle Fahrzeuge'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914489606255914108)
,p_db_column_name=>'EINSATZDATUM_MODELLID'
,p_display_order=>360
,p_column_identifier=>'AL'
,p_column_label=>'Einsatzdatum Modell'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(1076773784946225404)
,p_rpt_show_filter_lov=>'1'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_SHORT'
,p_display_condition2=>'20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914488815700914105)
,p_db_column_name=>'ANTRIEBSART'
,p_display_order=>370
,p_column_identifier=>'AN'
,p_column_label=>'Antriebsart'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(895790004878594088)
,p_db_column_name=>'COP_RELEVANT'
,p_display_order=>380
,p_column_identifier=>'AO'
,p_column_label=>'CoP Relevant'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(958149357559525013)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(773132223068399300)
,p_db_column_name=>'TECHNOLOGIE'
,p_display_order=>390
,p_column_identifier=>'AP'
,p_column_label=>'Technologie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(929098794307280202)
,p_db_column_name=>'TICKETS'
,p_display_order=>430
,p_column_identifier=>'BE'
,p_column_label=>'Konzerntickets'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(929098716012280201)
,p_db_column_name=>'NOTATION'
,p_display_order=>440
,p_column_identifier=>'BF'
,p_column_label=>'Notation'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(929098609923280200)
,p_db_column_name=>'LISTE'
,p_display_order=>450
,p_column_identifier=>'BG'
,p_column_label=>'Fahrzeugart'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781398895102132166)
,p_db_column_name=>'LEAD_VKO'
,p_display_order=>460
,p_column_identifier=>'BH'
,p_column_label=>'Lead VKO'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(894385061168630079)
,p_db_column_name=>'DETAIL_S'
,p_display_order=>470
,p_column_identifier=>'BI'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1376714630969615198)
,p_db_column_name=>'STATUS_UPDATE_GETEX'
,p_display_order=>480
,p_column_identifier=>'BJ'
,p_column_label=>'Status Update Getex'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643887599310305768)
,p_db_column_name=>'MFV_ID'
,p_display_order=>490
,p_column_identifier=>'BK'
,p_column_label=>'Mfv Id'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643887499228305767)
,p_db_column_name=>'KEINE_NORM_VALIDIERUNG'
,p_display_order=>500
,p_column_identifier=>'BL'
,p_column_label=>'Keine Norm Validierung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(643887373144305766)
,p_db_column_name=>'REV_NOTWENDIG'
,p_display_order=>510
,p_column_identifier=>'BM'
,p_column_label=>'Rev Notwendig'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1111697863568193118)
,p_db_column_name=>'DOKUMENTENDATUM'
,p_display_order=>520
,p_column_identifier=>'BN'
,p_column_label=>'Dokumentendatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1043565363841189811)
,p_db_column_name=>'FLAG_KONSOLIDIERTE_FASSUNGEN'
,p_display_order=>530
,p_column_identifier=>'BO'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P21_FLAG_KF'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2839753070119492472)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1982149'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DETAIL_S:LINK_NETZ:PERMALINK:CHECKBOX:FLAG_KONSOLIDIERTE_FASSUNGEN:VORSCHRIFTID:VORSCHRIFT_NUMMER:DOKUMENTENDATUM:VORSCHRIFT_BEZEICHNUNG:BEMERKUNG:VORSCHRIFT_TYPID:IN_KRAFT:PROGNOSE_QUALITAET:VORSCHRIFT_STATUSID:ETB_AK:LIST_LAND:THEMENGEBIETE:ANTRIEB'
||'SART:RXSWIN_RELEVANT:SWR_HAUPTUMSETZENDE_OE:LINK_ZUR_VORSCHRIFT_GETEX:VORSCHRIFT_FREIGABESTATUSID:LINK_ZUR_VORSCHRIFT_DMS:WEBSITLINK:NEUE_TYPEN:ALLE_FAHRZEUGE:MJ_PHASEIN_START:NEUE_TYPEN_CKD:ALLE_FAHRZEUGE_CKD:NEUE_TYPEN_FBU:ALLE_FAHRZEUGE_FBU:EINSAT'
||'ZDATUM_MODELLID:TYPSCHILD:KSU:COP_RELEVANT:TECHNOLOGIE:LETZTE_AENDERUNG_BENUTZER:LETZTE_AENDERUNG_DATUM:LISTE:LEAD_VKO:TICKETS:STATUS_UPDATE_GETEX:REV_NOTWENDIG'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2877019883126775997)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2707059584407204267)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(914477268560914007)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2839745020692487120)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:31:P31_VORSCHRIFT_FREIGABESTATUSID:1'
,p_button_condition=>'pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(914476887951914004)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2839745020692487120)
,p_button_name=>'LAENDER_INFO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('L\00E4nder')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-info-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(914477611724914016)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2839745020692487120)
,p_button_name=>'MEHRFACHBEARBEITUNG'
,p_button_static_id=>'b_MB'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Mehrfachbearbeitung'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:140:&SESSION.::&DEBUG.:RP,140:P140_LOAD_FROM:"P21_SELECTED_ROWS"'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 1003 = Fachadmin, 1000 = VKO, 1200 = Redaktionsteam',
'pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1200'') > 0'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_css_classes=>'apex_disabled'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(643871749354300526)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2839745020692487120)
,p_button_name=>'Refresh'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Auffrischen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1043290835623753910)
,p_name=>'P21_FLAG_KF'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2877019883126775997)
,p_prompt=>'Flag konsolidierte Fassung vorhanden'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Wenn Benutzer VKO oder VEX ist, soll Schalter default auf einblenden',
'-- stehen, sonst auf ausblenden',
'if (pck_ri.fIsUserInRolle(listRolleId => ''1000:1002'') > 0) then',
'    return 1;',
'else',
'    return 0;',
'end if;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Normalansicht',
  'off_value', '0',
  'on_label', 'Detailansicht',
  'on_value', '1',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(914493271967914227)
,p_name=>'P21_SHORT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2877019883126775997)
,p_item_default=>'20'
,p_prompt=>'Anzeige'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(3414144103148820565)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Langversion',
  'off_value', '20',
  'on_label', 'Kurzversion',
  'on_value', '10',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(914476504230914004)
,p_name=>'P21_URL_MEHRFACHBEARBEITUNG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2839745020692487120)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(914476065056914003)
,p_name=>'P21_SELECTED_ROWS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2839745020692487120)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(643871473698298050)
,p_name=>'P21_REFRESH_DATE_TIME'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(2839745020692487120)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'  TO_CHAR(LAST_REFRESH_DATE, ''DD.MM.YYYY HH24:MI'') AS REFRESH_DATE_TIME ',
'FROM USER_MVIEWS',
'WHERE MVIEW_NAME = ''MV_VORSCHRIFTEN_LANG_VERSION_REPORT'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(643871226050295318)
,p_name=>'P21_STATUS_BEZ'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2839745020692487120)
,p_use_cache_before_default=>'NO'
,p_prompt=>'&nbsp;'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(643870915621293651)
,p_name=>'P21_HIDDEN_REFRESH_ITEM'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(2839745020692487120)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(634271232330201387)
,p_name=>'P21_SUPPLEMENTS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2877019883126775997)
,p_item_default=>'10'
,p_prompt=>'Supplenments'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(3414144103148820565)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'ohne Supplements',
  'off_value', '10',
  'on_label', 'mit Supplements',
  'on_value', '20',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(914475334147913955)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2839745020692487120)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(914474794600913946)
,p_event_id=>wwv_flow_imp.id(914475334147913955)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2839745020692487120)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(914474386157913940)
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(914477268560914007)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(914473907052913940)
,p_event_id=>wwv_flow_imp.id(914474386157913940)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2839745020692487120)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(914473454851913939)
,p_name=>'Backup OPEN_MEHRFACHBEARBEITUNG_DIALOG'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(914477611724914016)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'NEVER'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(914472964445913939)
,p_event_id=>wwv_flow_imp.id(914473454851913939)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var sel_rows = apex.item(''P21_SELECTED_ROWS'');',
'sel_rows.setValue("");',
'$("#VSIG").find("td input:checked").each(function() {',
'  if(sel_rows.getValue().length > 0) {',
'    sel_rows.setValue(sel_rows.getValue() + ":");    ',
'  }',
'  sel_rows.setValue(sel_rows.getValue() + this.value);',
'});',
'            '))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(914472507076913938)
,p_event_id=>wwv_flow_imp.id(914473454851913939)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :P21_URL_MEHRFACHBEARBEITUNG := APEX_UTIL.PREPARE_URL (',
'        APEX_PAGE.GET_URL (',
'            p_page => 140,',
'            --p_triggering_element => ''#b_MB'',',
'            p_items => ''P140_SELECTED_VORSCHRIFTEN'',',
'            p_values => ''\'' || :P21_SELECTED_ROWS || ''\'',',
'            p_clear_cache => 140),',
'        p_triggering_element => ''$(''''body'''')'');',
'            ',
'END;',
'',
'',
''))
,p_attribute_02=>'P21_SELECTED_ROWS'
,p_attribute_03=>'P21_URL_MEHRFACHBEARBEITUNG'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(914471991309913938)
,p_event_id=>wwv_flow_imp.id(914473454851913939)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'eval($(''#P21_URL_MEHRFACHBEARBEITUNG'').val())',
' '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(914471565217913938)
,p_name=>'Mehrfachbearbeitung - Dialog Closed'
,p_event_sequence=>70
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'body'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(914471108187913938)
,p_event_id=>wwv_flow_imp.id(914471565217913938)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'alert(''TEST'');'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(914470544402913937)
,p_event_id=>wwv_flow_imp.id(914471565217913938)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2839745020692487120)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(914470203083913937)
,p_name=>'Change Variante'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P21_SHORT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(914469715883913937)
,p_event_id=>wwv_flow_imp.id(914470203083913937)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window.location=''f?p=&APP_ID.:20:&APP_SESSION.'''
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(914469332991913937)
,p_name=>'Zeilenselektor'
,p_event_sequence=>90
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'td input'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#VSIG'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(914468751131913936)
,p_event_id=>wwv_flow_imp.id(914469332991913937)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var any_checked = $("#VSIG").find("td input:checked").length > 0;',
'',
'if (any_checked) {',
'    $("#b_MB").removeClass("apex_disabled");',
'} else {',
'    $("#b_MB").addClass("apex_disabled");',
'}',
'',
'$("#b_MB").prop(''disabled'', !any_checked);',
'',
'var sel_rows = apex.item(''P21_SELECTED_ROWS'');',
'sel_rows.setValue("");',
'$("#VSIG").find("td input:checked").each(function() {',
'  if(sel_rows.getValue().length > 0) {',
'    sel_rows.setValue(sel_rows.getValue() + ":");    ',
'  }',
'  sel_rows.setValue(sel_rows.getValue() + this.value);',
'});',
'            '))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(914468321936913936)
,p_event_id=>wwv_flow_imp.id(914469332991913937)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P21_SELECTED_ROWS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(914467890488913936)
,p_name=>unistr('L\00E4nderinfo')
,p_event_sequence=>100
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'button#b_laender_info'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(914467436488913936)
,p_event_id=>wwv_flow_imp.id(914467890488913936)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'apex.server.process(',
'    ''prepare_laender'',                           ',
'    {',
'        x01: ''Mehrfachbearbeitung'',',
'        x02: $v(''P10_SELECTED_IDS'').replace(/:/g, "|")',
'    }, ',
'    {',
'        success: function (pData)',
'        {           ',
'            apex.navigation.redirect(pData);',
'        },',
'        dataType: "text"                     ',
'    }',
');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(914466993555913935)
,p_name=>unistr('Klick Button L\00E4nder Info')
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(914476887951914004)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(914466441726913935)
,p_event_id=>wwv_flow_imp.id(914466993555913935)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'javascript:window.open(''f?p=&APP_ID.:130:&SESSION.'',''_blank'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(634294388186589900)
,p_name=>'switch supplements'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P21_SUPPLEMENTS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(634294309706589899)
,p_event_id=>wwv_flow_imp.id(634294388186589900)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2839745020692487120)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(643870718964292137)
,p_name=>'NEW VERSION'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P21_HIDDEN_REFRESH_ITEM'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(643870247576292100)
,p_event_id=>wwv_flow_imp.id(643870718964292137)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_count number;',
'l_value varchar2(100);',
'begin',
'begin',
'SELECT count(*) into l_count',
'FROM USER_MVIEWS',
'WHERE MVIEW_NAME = ''MV_VORSCHRIFTEN_LANG_VERSION_REPORT''',
'--and LAST_REFRESH_DATE> :P21_REFRESH_DATE_TIME;',
'and TO_char(LAST_REFRESH_DATE, ''DD.MM.YYYY HH24:MI'') >:P21_REFRESH_DATE_TIME;',
'exception when no_data_found then l_count :=0;',
'end;',
'if l_count >0 then ',
unistr('l_value:=''Neue Version Verf\00FCgbar!'';'),
'',
'else',
'l_value :=null;',
'end if;',
':P21_STATUS_BEZ:= l_value;',
'--:P21_STATUS_BEZ :=null;',
'--end if;',
'end;'))
,p_attribute_02=>'P21_REFRESH_DATE_TIME'
,p_attribute_03=>'P21_STATUS_BEZ'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(643869933036290556)
,p_name=>'change refresh item'
,p_event_sequence=>140
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(643869448816290556)
,p_event_id=>wwv_flow_imp.id(643869933036290556)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'setInterval( ()=> { $s(''P21_HIDDEN_REFRESH_ITEM'', ''refresh'') }, 4000 );',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(643869078963289819)
,p_name=>'change item position'
,p_event_sequence=>150
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(643868726061289819)
,p_event_id=>wwv_flow_imp.id(643869078963289819)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#ir_region_toolbar'').append($(''#P21_STATUS_BEZ_CONTAINER'')); // to set position',
'$(''#P21_STATUS_BEZ_LABEL'').css(''display'', ''block''); // make item label as block',
'$(''#P21_STATUS_BEZ_LABEL'').css(''white-space'', ''nowrap''); // disable wrapping'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1043290654926752682)
,p_name=>'Switch Filter'
,p_event_sequence=>160
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P21_FLAG_KF'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1043290286511752662)
,p_event_id=>wwv_flow_imp.id(1043290654926752682)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2839745020692487120)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(643868310163288048)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Refresh_MV_VORSCHRIFTEN_LANG_VERSION_REPORT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  DBMS_MVIEW.REFRESH(''MV_VORSCHRIFTEN_LANG_VERSION_REPORT'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(643871749354300526)
,p_internal_uid=>3028344005736100187
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3095363022445678207)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Aktualisiere Ora Text Suche Indexe'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    CTX_DDL.SYNC_INDEX(''MV_VORSCHRIFTEN_EXTENDED_IDX'');',
'    ',
'    CTX_DDL.SYNC_INDEX(''MV_VORSCHRIFT_BEZEICHNUNG_IDX'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(643871749354300526)
,p_internal_uid=>576849293453710028
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(914475673895913958)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'prepare_laender'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_url varchar2(2000);',
'    l_app number := v(''APP_ID'');',
'    l_session number := v(''APP_SESSION'');',
'',
'    --l_page_item VARCHAR2(2000) := case when apex_application.g_x01 = ''Einzelbearbeitung'' then ''P15_BEWERTUNG_ID'' when apex_application.g_x01 = ''Mehrfachbearbeitung'' then ''P15_SELECTED_IDS'' end;',
'BEGIN',
'    l_url := APEX_UTIL.PREPARE_URL(',
'        p_url => ''f?p='' || l_app || '':300:'' || l_session || ''::NO:300::'' || apex_application.g_x02,',
'        p_checksum_type => ''SESSION'');',
'    htp.p(l_url);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2757736642003474277
);
wwv_flow_imp.component_end;
end;
/
