prompt --application/pages/page_00540
begin
--   Manifest
--     PAGE: 00540
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>540
,p_name=>'Vorschrift kopieren'
,p_alias=>unistr('VORSCHRIFT-W\00C4HLEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Vorschrift w\00E4hlen')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_dialog_height=>'400'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(712759649897977963)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(712760182011977984)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(628092646063742864)
,p_plug_name=>'Select Region '
,p_parent_plug_id=>wwv_flow_imp.id(712759649897977963)
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(3414125760146820548)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'SESSION')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(712759631018977963)
,p_plug_name=>'Alte Vorschrift '
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(712759524318977963)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(632210142562546188)
,p_plug_name=>'Neue Vorschrift'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>6
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(712757193167977951)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(712759524318977963)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(712756859220977951)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(712759524318977963)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Einsatzdatum'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(712755299245977946)
,p_branch_name=>'Go To Page 544'
,p_branch_action=>'f?p=&APP_ID.:544:&SESSION.::&DEBUG.:25::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(712756859220977951)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(929252802549458773)
,p_name=>'P540_NEW_PROGNOSE_QUALITAET'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_item_default=>'0'
,p_prompt=>unistr('Prognosequalit\00E4t Einsatztermine')
,p_source=>'0'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_VORSCHRIFT_PROGNOSE_QUALITAET'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''offen'', ''open'') AS display_value,',
'        0 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''sicher'', ''secure'') AS display_value,',
'        10 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'    ',
'    UNION ALL',
'    ',
'    SELECT ',
unistr('        emano_util.fLang(''absch\00E4tzbar'', ''estimable'') AS display_value,'),
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_cSize=>30
,p_colspan=>6
,p_grid_column=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(929252637804458772)
,p_name=>'P540_PROGNOSE_QUALITAET'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Prognosequalit\00E4t Einsatztermine')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select   case v.prognose_qualitaetid',
'    WHEN 0 THEN emano_util.fLang(''offen'', ''open'') ',
'    WHEN 10 THEN emano_util.fLang(''sicher'', ''sure'')',
unistr('        WHEN 20 THEN emano_util.fLang(''absch\00E4tzbar'', ''evaluable'')'),
unistr('        WHEN 30 THEN emano_util.fLang(''best\00E4tigt (In Kraft)'', ''confirmed (enacted)'')'),
'        ELSE emano_util.fLang(''undefined'', ''undefined'') end "STATUS_DESCRIPTION"',
'from t_vorschrift v where v.vorschriftid = :P540_SOURCE_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(929252579248458771)
,p_name=>'P540_NEW_VORSCHRIFT_STATUS'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_item_default=>'20'
,p_prompt=>'Status der Vorschrift'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VORSCHRIFT_STATUS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select Status as d,',
'       Vorschrift_statusid as r',
'  from T_vorschrift_status',
' order by 1'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(929252536582458770)
,p_name=>'P540_VORSCHRIFT_STATUS'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Status der Vorschrift'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select   case v.vorschrift_statusid ',
'     ',
'    WHEN 20 THEN emano_util.fLang(''Entwurf'', ''draft'')',
'        WHEN 30 THEN emano_util.fLang(''Final Dokument'', ''final document'')',
'        WHEN 40 THEN emano_util.fLang(''In Kraft'', ''enacted'')',
'        ELSE emano_util.fLang(''undefined'', ''undefined'') end "VORSCHRIFT_STATUS_DESCRIPTION"',
'from t_vorschrift v where v.vorschriftid = :P540_SOURCE_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(894384745233630076)
,p_name=>'P540_NEW_PARENT_VORSCHRIFT_NUM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_prompt=>unistr('\00DCbergeordnete Vorschrift')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.vorschrift_nummer ',
'  from t_vorschrift v',
'join t_vorschrift_ref_vorschrift vrv on (vrv.nachfolger_vorschriftid =:P540_SOURCE_VORSCHRIFTID)',
'where vorgaenger_vorschriftid = v.vorschriftid and  vrv.beziehung_art = 30 and 20 = ',
'(select vorschrift_typid from t_vorschrift where vorschriftid= :P540_SOURCE_VORSCHRIFTID  )'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>7
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(894384726925630075)
,p_name=>'P540_NEW_PARENT_VORSCHRITID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vrv.vorgaenger_vorschriftid',
'  from  t_vorschrift_ref_vorschrift vrv ',
'where vrv.nachfolger_vorschriftid =:P540_SOURCE_VORSCHRIFTID and  vrv.beziehung_art = 30 and 20 = ',
'(select vorschrift_typid from t_vorschrift where vorschriftid= :P540_SOURCE_VORSCHRIFTID  )'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(712757859946977953)
,p_name=>'P540_SOURCE_VORSCHRIFTID'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_prompt=>'Quell-Vorschrift'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_VORSCHRIFT_DETAIL'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(712757529815977951)
,p_name=>'P540_VORSCHRIFTNUMMER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(710775637663878502)
,p_name=>'P540_SOURCE_VORSCHRIFT_NUMMER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vorschrift_nummer',
'from t_vorschrift',
'where vorschriftid = :P540_SOURCE_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(710775616993878501)
,p_name=>'P540_VORSCHRIFT_TYPID'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Vorschrift Typ'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  vt.vorschrift_typid r',
'from t_vorschrift v',
'join t_vorschrift_typ vt on (vt.vorschrift_typid = v.vorschrift_typid)',
'where v.vorschriftid = :P540_SOURCE_VORSCHRIFTID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung ',
'        ELSE name_eng',
'    END AS d, ',
' vorschrift_typid r  from T_vorschrift_typ'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(710775473517878500)
,p_name=>'P540_EINSATZDATUM_MODELLID'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Einsatz DATUM Modell'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct m.modell ',
'from t_vorschrift v',
'join t_vorschrift_ref_einsatzdatum_typ vrt on (vrt.vorschriftid = v.vorschriftid)',
'join t_einsatzdatum_typ t on (t.einsatzdatum_typid = vrt.einsatzdatum_typid)',
'join t_einsatzdatum_modell m on (m.einsatzdatum_modellid = t.einsatzdatum_modellid)',
'where v.vorschriftid = :P540_SOURCE_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(710775413314878499)
,p_name=>'P540_VORSCHRIFT_BEZEICHNUNG'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Titel (\00DCberschrift)')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select VORSCHRIFT_BEZEICHNUNG ',
'from t_vorschrift',
'where vorschriftid = :P540_SOURCE_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(710775261895878498)
,p_name=>'P540_FREIGABESTATUS'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Interner DB Freigabestatus'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select   case v.VORSCHRIFT_FREIGABESTATUSID  ',
'    WHEN 10 THEN emano_util.fLang(''in Bearbeitung'', ''in progress'')',
'        WHEN 20 THEN emano_util.fLang(''sichtbar in Regulation index DB'', ''visible in Regulation index DB'')',
'        WHEN 30 THEN emano_util.fLang(''nicht Relevant'', ''not relevant'')',
'        ELSE emano_util.fLang(''undefined'', ''undefined'') end "STATUS_DESCRIPTION"',
'from t_vorschrift v where v.vorschriftid = :P540_SOURCE_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(710771810853878463)
,p_name=>'P540_NEW_VORSCHRIFTID'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(697948890482655403)
,p_name=>'P540_VORSCHRIFT_NOTATION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Vorschrift Notation'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select n.bezeichnung ',
'from t_vorschrift v',
'join t_norm n on (n.normid = v.normid)',
'where v.vorschriftid = :P540_SOURCE_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung, normid',
'from t_norm n where n.normid not in (1016)',
'order by 1'))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_inline_help_text=>unistr('Bitte w\00E4hlen Sie eine Notation')
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(697948559923655400)
,p_name=>'P540_NOTATION_BEISPIEL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(697948163421655396)
,p_name=>'P540_RXSWIN'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_use_cache_before_default=>'NO'
,p_prompt=>'potentiell SW-Relevant'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE NVL(rxswin,0) ',
'        WHEN 10 THEN emano_util.fLang(''Ja'', ''Yes'')',
unistr('        WHEN 20 THEN emano_util.fLang(''nicht gepr\00FCft'', ''Not checked'')'),
'        ELSE emano_util.fLang(''Nein'', ''No'')',
'    END AS translated_value',
'FROM t_vorschrift',
'WHERE vorschriftid = :P540_SOURCE_VORSCHRIFTID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(697948089778655395)
,p_name=>'P540_HOMOLOGATIONSRELEVANT'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_use_cache_before_default=>'NO'
,p_prompt=>' Homologationsrelevant'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE NVL(homologationsrelevant,0) ',
'        WHEN 10 THEN emano_util.fLang(''Ja'', ''Yes'')',
unistr('        WHEN 20 THEN emano_util.fLang(''Nicht gepr\00FCft'', ''Not checked'')'),
'        ELSE emano_util.fLang(''Nein'', ''No'')',
'    END AS translated_value',
'FROM t_vorschrift',
'WHERE vorschriftid = :P540_SOURCE_VORSCHRIFTID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(632210060312546187)
,p_name=>'P540_NEW_VORSCHRIFT_NOTATION'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_prompt=>'Vorschrift Notation'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.normid',
'from t_vorschrift v',
'--join t_norm n on (n.normid = v.normid)',
'where v.vorschriftid = :P540_SOURCE_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_NOTATION'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_la as (',
'    select ',
'        normid,',
'        nvl(listagg(trim(la.b_nummer), '', '') within group (order by la.b_nummer),null) as laender_nummer,',
'        nvl(listagg(trim(CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN la.LAND ELSE la.LAND_ENG END), '', '') within group (order by la.LAND),null) as laender_name',
'    from t_norm_ref_land nrl',
'    left outer join t_land la on nrl.landid = la.landid',
'    group by normid',
')',
'select ',
'    n.normid, ',
'    n.bezeichnung "BEZEICHNUNG",',
'    cte_la.laender_nummer "B_NUMMER",',
'    cte_la.laender_name "LAND"',
'from "#OWNER#"."T_NORM" n',
'left outer join cte_la on cte_la.normid = n.normid',
'where n.normid not in (1016)',
'order by n.BEZEICHNUNG asc;'))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_inline_help_text=>unistr('Bitte w\00E4hlen Sie eine Notation')
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(632209652453546183)
,p_name=>'P540_NEW_VORSCHRIFTNUMMER'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_prompt=>'Vorschriftennummer'
,p_placeholder=>'&P540_SOURCE_VORSCHRIFT_NUMMER.'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(632209627011546182)
,p_name=>'P540_NEW_WITHOUT_NORM_VALIDATION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_prompt=>'Notation nicht validieren'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  (case WHEN (:P540_NEW_VORSCHRIFT_NOTATION is not null and :P540_NEW_VORSCHRIFT_NOTATION != 1016)  then 0 ',
'else 1 end) as cb from dual;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC(,):&nbsp;1'
,p_grid_label_column_span=>4
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('W\00E4hle die Checkbox, wenn die ausgew\00E4hlte Notation nicht validiert werden soll.'),
unistr('In diesem Fall wird automatisch eine Benachrichtigung f\00FCr die Fachadministratoren erstellt.')))
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(632208921229546175)
,p_name=>'P540_NEW_VORSCHRIFT_TYPID'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_prompt=>'Vorschrift Typ'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vorschrift_typid ',
'from t_vorschrift',
'where vorschriftid = :P540_SOURCE_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VORSCHRIFT_TYP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung ',
'        ELSE name_eng',
'    END AS d,',
'    vorschrift_typid AS r',
'FROM t_vorschrift_typ',
'ORDER BY 2;',
''))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(632208776571546174)
,p_name=>'P540_NEW_EINSATZDATUM_MODELLID'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_prompt=>'Einsatz DATUM Modell'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select einsatzdatum_modellid ',
'from t_vorschrift',
'where vorschriftid = :P540_SOURCE_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_EINSATZDATUM_MODELL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT EINSATZDATUM_MODELLID, CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN MODELL ELSE MODELL_ENG END FROM T_EINSATZDATUM_MODELL;',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(632208525186546171)
,p_name=>'P540_NEW_VORSCHRIFT_BEZEICHNUNG'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_prompt=>unistr('Titel (\00DCberschrift)')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(632208418792546170)
,p_name=>'P540_NEW_FREIGABE_STATUS'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_item_default=>'10'
,p_prompt=>'Interner DB Freigabestatus'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>'STATIC:Import;10'
,p_colspan=>5
,p_grid_column=>1
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(632208177267546168)
,p_name=>'P540_NEW_RXSWIN'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_item_default=>'20'
,p_prompt=>'potentiell SW-Relevant'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order ',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''nicht gepr\00FCft'', ''Not checked'') AS display_value,'),
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_protection_level=>'B'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(632207870870546165)
,p_name=>'P540_NEW_FAHRZEUGKLASSE'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_prompt=>'Fahrzeugklasse'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(fahrzeugklasseid, '':'')',
'from t_vorschrift_ref_fahrzeugklasse',
'where vorschriftid = :P540_SOURCE_VORSCHRIFTID;'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung d, fahrzeugklasseid r',
'from t_fahrzeugklasse',
'order by bezeichnung asc'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628999107141491991)
,p_name=>'P540_FAHRZEUGKLASSE'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fahrzeugklasse'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(fk.bezeichnung,  '', '') within group (order by fk.bezeichnung) ',
'from t_vorschrift_ref_fahrzeugklasse vrf',
'join t_fahrzeugklasse fk on (fk.fahrzeugklasseid = vrf.fahrzeugklasseid)',
'where vrf.vorschriftid = :P540_SOURCE_VORSCHRIFTID;'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628093538599742873)
,p_name=>'P540_BEMERKUNG'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_prompt=>'Bemerkung zur Vorschrift'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.bemerkung  ',
'from t_vorschrift v',
'where v.vorschriftid = :P540_SOURCE_VORSCHRIFTID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628093356948742871)
,p_name=>'P540_KSU'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_item_default=>'1020'
,p_prompt=>'KSU'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select k.bezeichnung ',
'from t_ksu k where k.ksuid = (select ksuid from t_Vorschrift where vorschriftid=:P540_SOURCE_VORSCHRIFTID);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select k.bezeichnung, k.ksuid',
'from t_ksu k',
'order by k.bezeichnung'))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628093281378742870)
,p_name=>'P540_TECHNOLOGIE'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Technologie'
,p_source=>'TECHNOLOGIE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628093205790742869)
,p_name=>'P540_VERANTWORTLICHE'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Regulierungsverantwortliche'
,p_post_element_text=>'&nbsp;<span onclick="redirect(322)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(nachname || '', '' || vorname || '' ('' || abteilung || '')'', '', '') within group (order by nachname)',
'    from t_vorschrift_ref_verantwortlicher vrv',
'    left outer join t_verantwortlicher v on (vrv.verantwortlicherid = v.verantwortlicherid)',
'    where vrv.vorschriftid = :P540_SOURCE_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628093113653742868)
,p_name=>'P540_STICHWOERTER'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_prompt=>'Stichwoerter'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(sw.stext,  '', '') within group (order by sw.stext)',
'    from t_vorschrift_ref_schlagwort vrs',
'    join t_schlagwort sw on (sw.schlagwortid = vrs.schlagwortid)',
'   where vrs.vorschriftid = :P540_SOURCE_VORSCHRIFTID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628092998639742867)
,p_name=>'P540_WEBSITEID'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Webseite'
,p_source=>'NEW_WEBSITEID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT w.WEBSITE_NAME, w.WEBSITEID',
'FROM T_WEBSITE w',
'ORDER BY 1',
''))
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628092867216742866)
,p_name=>'P540_LINK_ZUR_VORSCHRIFT_GETEX'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Getex 1.0 ID'
,p_post_element_text=>unistr('<a style="margin-left: 5px; margin-top: 5px" href="https://getex.wob.vw.vwg/web/guest/dokumente_suche" target="_blank"><button class="t-Button" type="button">Getex 1.0 \00F6ffnen</button></a>')
,p_source=>'NEW_LINK_ZUR_VORSCHRIFT_GETEX'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(617625785328928242)
,p_name=>'P540_NEW_BEMERKUNG'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_item_default=>'P540_NEW_BEMERKUNG'
,p_item_default_type=>'ITEM'
,p_prompt=>'Bemerkung zur Vorschrift'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>1024
,p_cHeight=>2
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(617625244540893008)
,p_name=>'P540_NEW_LINK_ZUR_VORSCHRIFT_DMS'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_item_default=>'P540_NEW_LINK_ZUR_VORSCHRIFT_DMS_RO'
,p_item_default_type=>'ITEM'
,p_prompt=>'Link zu DMS (Ein Link pro Zeile)'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>1024
,p_cHeight=>2
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>'&nbsp;'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(617624948847881113)
,p_name=>'P540_NEW_LINK_REQMAN'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_item_default=>'P540_NEW_LINK_REQMAN'
,p_item_default_type=>'ITEM'
,p_prompt=>'Link zu ReqMan (Ein Link pro  Zeile)'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>1024
,p_cHeight=>2
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>'&nbsp;'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(617624708868872288)
,p_name=>'P540_NEW_LINK_ZUR_VORSCHRIFT_GETEX'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_item_default=>'P540_NEW_LINK_ZUR_VORSCHRIFT_GETEX'
,p_item_default_type=>'ITEM'
,p_prompt=>'Getex 1.0 ID'
,p_post_element_text=>unistr('<a style="margin-left: 5px; margin-top: 5px" href="https://getex.wob.vw.vwg/web/guest/dokumente_suche" target="_blank"><button class="t-Button" type="button">Getex 1.0 \00F6ffnen</button></a>')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>20
,p_cMaxlength=>1024
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(617624429652863761)
,p_name=>'P540_NEW_WEBSITEID'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Webseite'
,p_source=>'NEW_WEBSITEID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT w.WEBSITE_NAME, w.WEBSITEID',
'FROM T_WEBSITE w',
'ORDER BY 1',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(617624130334860633)
,p_name=>'P540_NEW_WEBSITELINK'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_item_default=>'P540_NEW_WEBSITELINK'
,p_item_default_type=>'ITEM'
,p_prompt=>'Link zu Web Site'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>200
,p_cMaxlength=>800
,p_tag_css_classes=>'style="text-decoration: underline; text-decoration-style: dashed"'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(617623746813856169)
,p_name=>'P540_NEW_KSU'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1020'
,p_prompt=>'KSU'
,p_source=>'KSUID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select k.bezeichnung, k.ksuid',
'from t_ksu k',
'order by k.bezeichnung'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(617623515444823256)
,p_name=>'P540_NEW_TECHNOLOGIE'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_item_default=>'P540_NEW_TECHNOLOGIE'
,p_item_default_type=>'ITEM'
,p_prompt=>'Technologie'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DISTINCT technologie from T_VORSCHRIFT',
'order by technologie;'))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'fetch_on_type', 'N',
  'match_type', 'CONTAINS_IGNORE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(617623207684817556)
,p_name=>'P540_NEW_VERANTWORTLICHE'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(nachname || '', '' || vorname || '' ('' || abteilung || '')'', '', '') within group (order by nachname)',
'    from t_vorschrift_ref_verantwortlicher vrv',
'    left outer join t_verantwortlicher v on (vrv.verantwortlicherid = v.verantwortlicherid)',
'    where vrv.vorschriftid = :P540_SOURCE_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(617622914925811705)
,p_name=>'P540_NEW_STICHWOERTER'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(sw.stext,  '', '') within group (order by sw.stext)',
'    from t_vorschrift_ref_schlagwort vrs',
'    join t_schlagwort sw on (sw.schlagwortid = vrs.schlagwortid)',
'   where vrs.vorschriftid = :P540_SOURCE_VORSCHRIFTID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(617611227955767793)
,p_name=>'P540_LINK_ZUR_VORSCHRIFT_DMS_RO'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu DMS'
,p_format_mask=>'<span style="text-decoration-line: underline"></span>'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PCK_RI.fCreateLinkIfUrl(v.link_zur_vorschrift_dms, 80)',
'from t_vorschrift v',
'where v.vorschriftid = :P540_SOURCE_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="text-decoration: underline; text-decoration-style: dashed"'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(617610910289763010)
,p_name=>'P540_LINK_REQMAN_RO'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu REQMAN'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PCK_RI.fCreateLinkIfUrl(v.link_reqman, 80)',
'from t_vorschrift v',
'where v.vorschriftid = :P540_SOURCE_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="text-decoration: underline; text-decoration-style: dashed"'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(617610594234758345)
,p_name=>'P540_WEBSITELINK_RO'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(712759631018977963)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu Web Site'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  pck_ri.fcreateLinkIfUrl(websitelink)',
'from t_vorschrift v',
'where v.vorschriftid = :P540_SOURCE_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="text-decoration: underline; text-decoration-style: dashed"'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(394298743168385568)
,p_name=>'P540_NEW_HOMOLOGATIONSRELEVANT'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(632210142562546188)
,p_item_default=>'20'
,p_prompt=>'Homologationsrelevant'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order ',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''nicht gepr\00FCft'', ''Not checked'') AS display_value,'),
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_protection_level=>'B'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(632208938115546176)
,p_validation_name=>'V_NEW_VORSCHRIFTNUMMER_UNIQUE'
,p_validation_sequence=>40
,p_validation=>'select 1 from t_vorschrift where trim(vorschrift_nummer) = trim(:P540_NEW_VORSCHRIFTNUMMER)'
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Die Vorschrift Nummer existiert bereits.'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(712756859220977951)
,p_associated_item=>wwv_flow_imp.id(632209652453546183)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(712756797613977950)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(712757193167977951)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(712755970415977947)
,p_event_id=>wwv_flow_imp.id(712756797613977950)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(710773585752878481)
,p_name=>'copy nachfolger changed'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P540_COPY_NACHFOLGER'
,p_condition_element=>'P540_COPY_NACHFOLGER'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Y'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(710772876882878474)
,p_event_id=>wwv_flow_imp.id(710773585752878481)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P540_COPY_ALL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(710772829046878473)
,p_event_id=>wwv_flow_imp.id(710773585752878481)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P540_COPY_ALL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(710772480342878470)
,p_name=>'VORSCHRIFT_CHANGED'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P540_SOURCE_VORSCHRIFTID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(710772122530878466)
,p_event_id=>wwv_flow_imp.id(710772480342878470)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P540_SOURCE_VORSCHRIFTID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(710772388024878469)
,p_event_id=>wwv_flow_imp.id(710772480342878470)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P540_VORSCHRIFT_BEZEICHNUNG,P540_SOURCE_VORSCHRIFT_NUMMER'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(710771371518878459)
,p_name=>'copy all changed'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P540_COPY_ALL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(697948456437655399)
,p_name=>'Notation changed'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P540_VORSCHRIFT_NOTATION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(697948362364655398)
,p_event_id=>wwv_flow_imp.id(697948456437655399)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P540_NOTATION_BEISPIEL'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select replace(beispiel, chr(13),''; '') from t_norm where normid =  nvl(:P540_VORSCHRIFT_NOTATION, 1016)'
,p_attribute_07=>'P540_VORSCHRIFT_NOTATION'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(697948253466655397)
,p_event_id=>wwv_flow_imp.id(697948456437655399)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#P540_VORSCHRIFT_NOTATION_inline_help'').html(''Beispiel(e): '' + $v(''P540_NOTATION_BEISPIEL''));'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(667018863396692899)
,p_event_id=>wwv_flow_imp.id(697948456437655399)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P540_WITHOUT_NORM_VALIDATION'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'($v(''P540_VORSCHRIFT_NOTATION'') != null)?0:1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(632209517326546181)
,p_name=>'new_notation changed'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P540_NEW_VORSCHRIFT_NOTATION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(632209428508546180)
,p_event_id=>wwv_flow_imp.id(632209517326546181)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P540_NOTATION_BEISPIEL'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select replace(beispiel, chr(13),''; '') from t_norm where normid =  nvl(:P540_NEW_VORSCHRIFT_NOTATION, 1016)'
,p_attribute_07=>'P540_NEW_VORSCHRIFT_NOTATION'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(632209264141546179)
,p_event_id=>wwv_flow_imp.id(632209517326546181)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#P540_NEW_VORSCHRIFT_NOTATION_inline_help'').html(''Beispiel(e): '' + $v(''P540_NOTATION_BEISPIEL''));',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(632208654274546173)
,p_name=>'Change norm Validation'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P540_NEW_WITHOUT_NORM_VALIDATION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(632208556698546172)
,p_event_id=>wwv_flow_imp.id(632208654274546173)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P540_NEW_WITHOUT_NORM_VALIDATION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(894384539002630074)
,p_name=>'Anzeigen'
,p_event_sequence=>110
,p_condition_element=>'P540_NEW_PARENT_VORSCHRITID'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(894384507113630073)
,p_event_id=>wwv_flow_imp.id(894384539002630074)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P540_NEW_PARENT_VORSCHRIFT_NUM'
);
wwv_flow_imp.component_end;
end;
/
