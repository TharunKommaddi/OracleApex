prompt --application/pages/page_00041
begin
--   Manifest
--     PAGE: 00041
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>41
,p_name=>'25 Bacup - 30.07.2025'
,p_alias=>'25-BACUP-30-07-2025'
,p_step_title=>'25 Bacup - 30.07.2025'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'/* Click auf Checkbox in Tabellenheader: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'$(''#report-verknuepfungen'').on(''click'', ''th input'', function() {',
'    var check_all = $("#report-verknuepfungen").find("th input:checked").is(":checked");',
'',
'    $("#report-verknuepfungen").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'    if (check_all) {',
'        $("#DELETE_VERKNUEPFUNG").removeClass("apex_disabled");',
'    } else {',
'        $("#DELETE_VERKNUEPFUNG").addClass("apex_disabled");',
'    }',
'',
'    $("#DELETE_VERKNUEPFUNG").prop(''disabled'', !check_all);',
'});',
'',
'/* Click auf Checkbox in Tabellenzeile: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'',
'$(''#report-verknuepfungen'').on(''click'', ''td input'', function() {',
'    var any_checked = $("#report-verknuepfungen").find("td input:checked").length > 0;',
'',
'    if (any_checked) {',
'        $("#DELETE_VERKNUEPFUNG").removeClass("apex_disabled");',
'    } else {',
'        $("#DELETE_VERKNUEPFUNG").addClass("apex_disabled");',
'    }',
'',
'    $("#DELETE_VERKNUEPFUNG").prop(''disabled'', !any_checked);',
'});',
'',
'/* report amendments   ------------------------*/ ',
'$(''#report-amendments'').on(''click'', ''th input'', function() {',
'    var check_all_a = $("#report-amendments").find("th input:checked").is(":checked");',
'',
'    $("#report-amendments").find("td input").each(function() {',
'        this.checked = check_all_a;',
'    });',
'',
'    if (check_all_a) {',
'        $("#DELETE_AMENDMENT").removeClass("apex_disabled");',
'    } else {',
'        $("#DELETE_AMENDMENT").addClass("apex_disabled");',
'    }',
'',
'    $("#DELETE_AMENDMENT").prop(''disabled'', !check_all_a);',
'});',
'',
'/* Click auf Checkbox in Tabellenzeile: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'',
'$(''#report-amendments'').on(''click'', ''td input'', function() {',
'    var any_checked_a = $("#report-amendments").find("td input:checked").length > 0;',
'',
'    if (any_checked_a) {',
'        $("#DELETE_AMENDMENT").removeClass("apex_disabled");',
'    } else {',
'        $("#DELETE_AMENDMENT").addClass("apex_disabled");',
'    }',
'',
'    $("#DELETE_AMENDMENT").prop(''disabled'', !any_checked_a);',
'});',
'',
'',
'function initializeDateTooltips() {',
'    apex.jQuery(".date-tooltip").tooltip({',
'        show: { effect: "fade", delay: 100 },',
'        hide: { effect: "fade", delay: 100 },',
'        track: true,',
'        position: { ',
'            my: "left+10 top+25",',
'            at: "right bottom",',
'            collision: "flipfit"',
'        }',
'    });',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'initializeDateTooltips()',
'',
'',
'',
'$(''#rKerndaten .t-Region-title'').append('' <span onclick="redirect(5)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rEinsatzdaten .t-Region-title'').append('' <span onclick="redirect(6)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rVerknuepfungen .t-Region-title'').append('' <span onclick="redirect(7)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rAnsprechpartner .t-Region-title'').append('' <span onclick="redirect(1109)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rSupplements .t-Region-title'').append('' <span onclick="redirect(1110)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rAmendments .t-Region-title'').append('' <span onclick="redirect(1112)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rErweiterteInfos .t-Region-title'').append('' <span onclick="redirect(1111)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rLaenderThemen .t-Region-title'').append('' <span onclick="redirect(8)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rLaender .t-Region-title'').append('' <span onclick="redirect(30)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rThemen .t-Region-title'').append('' <span onclick="redirect(31)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rMfVs .t-Region-title'').append('' <span onclick="redirect(141)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rVerlinkteNormen .t-Region-title'').append('' <span onclick="redirect(142)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rFunktionen .t-Region-title'').append('' <span onclick="redirect(361)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'',
'',
'// Icons im Region Display Selector',
'$(''#rEinsatzdaten_tab span'').replaceWith(''<span><i class="fa fa-calendar" alt="Einsatzdaten" title="Einsatzdaten" aria-hidden="true"></i></span>'');',
unistr('$(''#rVerknuepfungen_tab span'').replaceWith(''<span><i class="fa fa-link" alt="Verkn\00FCpfungen" title="Verkn\00FCpfungen" aria-hidden="true"></i></span>'');'),
'$(''#rAnsprechpartner_tab span'').replaceWith(''<span><i class="fa fa-user" alt="Ansprechpartner" title="Ansprechpartner" aria-hidden="true"></i></span>'');',
'$(''#rSupplements_tab span'').replaceWith(''<span><i class="fa fa-file-plus" alt="UN-R Supplements" title="UN-R Supplements" aria-hidden="true"></i></span>'');',
'',
' ',
'',
'',
'',
'// var $container = $(''<div>'').css({',
'//     ''display'': ''flex'',',
'//     ''align-items'': ''center'',',
'//     ''gap'': ''20px'',',
'//     ''margin-right'': ''20px''',
'// });',
'',
'// var $datumGroup = $(''<div>'').css({',
'//     ''display'': ''flex'',',
'//     ''align-items'': ''center'',',
'//     ''gap'': ''5px''',
'// });',
'',
'// var $phaseGroup = $(''<div>'').css({',
'//     ''display'': ''flex'',',
'//     ''align-items'': ''center'',',
'//     ''gap'': ''5px''',
'// });',
'',
'// var $datumLabel = $(''#P25_DATUM_ANGABE_AS_MJ_LABEL'').clone().css({',
'//     ''white-space'': ''nowrap'',',
'//     ''margin'': ''0''',
'// });',
'',
'// var $datumInput = $(''#P25_DATUM_ANGABE_AS_MJ'').clone(true);',
'',
'// var $phaseLabel = $(''#P25_PHASEIN_ENTHALTEN_LABEL'').clone().css({',
'//     ''white-space'': ''nowrap'',',
'//     ''margin'': ''0''',
'// });',
'',
'// var $phaseInput = $(''#P25_PHASEIN_ENTHALTEN'').clone(true);',
'',
'// $datumGroup.append($datumLabel).append($datumInput);',
'// $phaseGroup.append($phaseLabel).append($phaseInput);',
'',
'// $container.append($datumGroup).append($phaseGroup);',
'',
'// $(''#rThemen .t-Region-headerItems--buttons'').before($container);',
'',
'// $(''#P25_DATUM_ANGABE_AS_MJ_CONTAINER'').closest(''.row'').hide();',
'// $(''#P25_PHASEIN_ENTHALTEN_CONTAINER'').closest(''.row'').hide();',
'',
'// $(''#rThemen .t-Region-header'').css({',
'//     ''display'': ''flex'',',
'//     ''flex-wrap'': ''wrap'',',
'//     ''align-items'': ''center''',
'// });',
'',
'',
'// apex.jQuery(document).ready(function() {',
'//     apex.jQuery(''.EDIT_ENABLE'').on(''click'', function() {',
'//         console.log(''1. Edit button clicked'');',
'        ',
'//         var item = apex.item(''P25_DATUM_ANGABE_AS_MJ'');',
'//         console.log(''2. Item value:'', item.getValue());',
'//         console.log(''3. Item enabled:'', !item.isDisabled());',
'        ',
'//         apex.message.setThemeHooks({',
'//             beforeShow: function(msg) {',
'//                 console.log(''4. Error:'', msg);',
'//             }',
'//         });',
'//     });',
'// });',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'$(document).ready(function() {',
'   function applyMerging() {',
'       var $report = $(''#R482915162223535309''); ',
'       ',
'       if (!$report.length) {',
'           return;',
'       }',
'',
'       $report.find(''.t-Report-report'').each(function() {',
'           $(this).find(''tbody tr'').css(''background-color'', ''transparent'');',
'           $(this).find(''tbody tr:even'').css(''background-color'', ''#f0f0f0'');',
'           ',
'           $(this).find(''.t-Report-cell, .t-Report-colHead'').css({ ',
'               ''border'': ''1px solid #e6e6e6''',
'           });',
'           ',
'           const dateColumns = [',
'               ''Einsatztermin alle Fahrzeuge'',',
'               ''Einsatztermin neue Typen'',',
unistr('               ''Datum Au\00DFer Kraft FBU'','),
unistr('               ''Datum Au\00DFer Kraft CKD'','),
'               ''Neue Typen CKD'',',
'               ''Alle Fahrzeuge CKD'',',
'               ''Neue Typen FBU'',',
'               ''Alle Fahrzeuge FBU'',',
'               ''Einsatzzeitpunkt'',',
'               ''MJ Phasein end'',',
'               ''Modelljahr''',
'           ];',
'           ',
'           var columnIndices = {};',
'           var i = 1;',
'           ',
'           $(this).find(''th'').each(function() {',
'               var headerText = $(this).text().trim();',
'               if (dateColumns.includes(headerText)) {',
'                   columnIndices[headerText] = i;',
'               }',
'               i++;',
'           });',
'',
'           var rowData = [];',
'           $(this).find(''tbody tr'').each(function() {',
'               var cells = $(this).find(''td'');',
'               var rowCells = {};',
'               ',
'               Object.keys(columnIndices).forEach(function(columnName) {',
'                   rowCells[columnName] = cells.eq(columnIndices[columnName] - 1);',
'               });',
'               ',
'               rowData.push(rowCells);',
'           });',
'',
'           var mergedCellsMap = new Map();',
'           var mergedRowMap = new Map();',
'',
'           Object.keys(columnIndices).forEach(function(columnName) {',
'               var firstInstance = null;',
'               var currentValue = null;',
'               var currentRowspan = 1;',
'               var startRowIndex = 0;',
'',
'               rowData.forEach(function(row, index) {',
'                   var cell = row[columnName];',
'                   if (!cell || !cell.length) return;',
'                   ',
'                   var cleanText = cell.text().replace(/[*\s]/g, '''').trim();',
'                   var originalHtml = cell.html();',
'',
'                   if (!cleanText || cleanText === '''') {',
'                       firstInstance = null;',
'                       currentValue = null;',
'                       currentRowspan = 1;',
'                       return;',
'                   }',
'',
'                   if (firstInstance === null) {',
'                       firstInstance = cell;',
'                       currentValue = cleanText;',
'                       startRowIndex = index;',
'                       firstInstance.css({',
'                           ''text-align'': ''center'',',
'                           ''vertical-align'': ''middle'',',
'                           ''background-color'': index % 2 === 0 ? ''#f0f0f0'' : ''transparent''',
'                       });',
'                   } else if (cleanText === currentValue) {',
'                       cell.remove();',
'                       currentRowspan++;',
'                       firstInstance.attr(''rowspan'', currentRowspan);',
'                       ',
'                       if (!mergedCellsMap.has(firstInstance[0])) {',
'                           mergedCellsMap.set(firstInstance[0], {',
'                               startRow: startRowIndex,',
'                               rowspan: currentRowspan,',
'                               cells: []',
'                           });',
'                       }',
'                       mergedCellsMap.get(firstInstance[0]).cells.push(firstInstance[0]);',
'',
'                       for(let i = startRowIndex; i < startRowIndex + currentRowspan; i++) {',
'                           if (!mergedRowMap.has(i)) {',
'                               mergedRowMap.set(i, new Set());',
'                           }',
'                           mergedRowMap.get(i).add(firstInstance[0]);',
'                       }',
'                       ',
'                       if (originalHtml.includes(''*'') && !firstInstance.html().includes(''*'')) {',
'                           firstInstance.html(originalHtml);',
'                       }',
'                       firstInstance.css({',
'                           ''border-bottom'': ''1px solid #e6e6e6'',',
'                           ''text-align'': ''center'',',
'                           ''vertical-align'': ''middle'',',
'                           ''background-color'': ''#e6f3ff''',
'                       });',
'                   } else {',
'                       firstInstance = cell;',
'                       currentValue = cleanText;',
'                       currentRowspan = 1;',
'                       startRowIndex = index;',
'                       firstInstance.css({',
'                           ''text-align'': ''center'',',
'                           ''vertical-align'': ''middle'',',
'                           ''background-color'': index % 2 === 0 ? ''#f0f0f0'' : ''transparent''',
'                       });',
'                   }',
'               });',
'           });',
'',
'           $report.find(''tbody tr'').off(''mouseenter mouseleave'');',
'',
'           var $rows = $(this).find(''tbody tr'');',
'           ',
'           $rows.hover(',
'               function() {',
'                   var $currentRow = $(this);',
'                   var rowIndex = $rows.index($currentRow);',
'                   ',
'                   $currentRow.find(''td'').each(function() {',
'                       var $td = $(this);',
'                       if (!$td.attr(''rowspan'')) {',
'                           $td.css({',
'                               ''background-color'': ''#bb0a31'',',
'                               ''color'': ''white''',
'                           });',
'                           ',
'                           $td.find(''.status-asterisk'').css(''color'', ''white'');',
'                       }',
'                   });',
'                   ',
'                   if (mergedRowMap.has(rowIndex)) {',
'                       mergedRowMap.get(rowIndex).forEach(function(cell) {',
'                           var $cell = $(cell);',
'                           $cell.css({',
'                               ''background-color'': ''#bb0a31'',',
'                               ''color'': ''white''',
'                           });',
'                           ',
'                           $cell.find(''.status-asterisk'').css(''color'', ''white'');',
'                       });',
'                   }',
'',
'                   mergedCellsMap.forEach(function(info, cell) {',
'                       if (rowIndex >= info.startRow && rowIndex < (info.startRow + info.rowspan)) {',
'                           var $cell = $(cell);',
'                           $cell.css({',
'                               ''background-color'': ''#bb0a31'',',
'                               ''color'': ''white''',
'                           });',
'                           ',
'                           $cell.find(''.status-asterisk'').css(''color'', ''white'');',
'                       }',
'                   });',
'               },',
'               function() {',
'                   var $currentRow = $(this);',
'                   var rowIndex = $rows.index($currentRow);',
'                   var isEvenRow = rowIndex % 2 === 0;',
'                   ',
'                   $currentRow.find(''td:not([rowspan])'').each(function() {',
'                       var $td = $(this);',
'                       $td.css({',
'                           ''background-color'': isEvenRow ? ''#f0f0f0'' : ''transparent'',',
'                           ''color'': ''inherit''',
'                       });',
'                      ',
'                       $td.find(''.status-asterisk'').css(''color'', ''red'');',
'                   });',
'                   ',
'                   if (mergedRowMap.has(rowIndex)) {',
'                       mergedRowMap.get(rowIndex).forEach(function(cell) {',
'                           var $cell = $(cell);',
'                           $cell.css({',
'                               ''background-color'': ''#e6f3ff'',',
'                               ''color'': ''inherit''',
'                           });',
'                          ',
'                           $cell.find(''.status-asterisk'').css(''color'', ''red'');',
'                       });',
'                   }',
'',
'                   mergedCellsMap.forEach(function(info, cell) {',
'                       if (rowIndex >= info.startRow && rowIndex < (info.startRow + info.rowspan)) {',
'                           var $cell = $(cell);',
'                           $cell.css({',
'                               ''background-color'': ''#e6f3ff'',',
'                               ''color'': ''inherit''',
'                           });',
'                          ',
'                           $cell.find(''.status-asterisk'').css(''color'', ''red'');',
'                       }',
'                   });',
'               }',
'           );',
'       });',
'   }',
'',
'   applyMerging();',
'',
'   apex.jQuery("#R482915162223535309").on("apexafterrefresh", function() {',
'    //    location.reload();',
'       applyMerging();',
'   });',
'});',
'',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#t_Body_content_offset {',
'    height: 90px !important;',
'}',
'',
'div#ig_einsatzdaten div.a-GV-footer {',
'    display: none',
'}',
'',
'div#ig_einsatzdaten tr.is-selected .a-GV-cell {',
'    background-color: white !important; ',
'    color: rgb(64, 64, 64) !important;',
'}',
'',
'',
'#P25_LINK_ZUR_VORSCHRIFT_DMS_inline_help {',
'    white-space: pre-wrap',
'}',
'',
'#P25_LINK_ZUR_VORSCHRIFT_DMS_inline_help a {',
'    text-decoration: underline',
'}',
'',
'div#ig_einsatzdaten td.is-readonly {',
'    white-space: pre-wrap;',
'}',
'',
'.red_noasc{',
'    color: red !important;',
'}',
'',
'#P25_NORMID_inline_help a {',
'    text-decoration: underline;',
'    text-decoration-style: dashed;',
'}',
'',
'',
'.getexlogo::after {',
'    content: ''GETEX'';',
'    position: absolute;',
'    right: 20px;',
'    color: #0000ff82;',
'    margin-right: 15px;',
'    font-weight: bold;',
'    top: 5px;',
'    font-size: 20px;',
'    font-family: ''Audi Type Extended'';',
'}',
'',
'',
'',
'.getexlogo.t-Region-header::after {',
'    margin-right: 50px;',
'}',
'',
'',
'',
'.status-asterisk {',
'    color: red;',
'}',
'/* ',
'tr:hover .status-asterisk {',
'    color: white;',
'}',
' */',
'',
'',
'',
'.fa-asterisk:hover {',
'   color: lightgreen !important;',
'}',
'',
'',
'/* ',
'.date-tooltip {',
'    cursor: help;',
'} */',
'',
'',
'',
'',
'',
'',
'',
'/* No Data Found CSS for Reports*/',
'.no-data-message {',
'    background-color: #f5f5f5;',
'    color: #333333;',
'    padding: 8px 12px;',
'    font-family: ''Segoe UI'', Arial, sans-serif;',
'    border-left: 3px solid #bb0a31; /*#4CAF50;*/',
'    margin: 10px 0;',
'    font-size: 13px;',
'    line-height: 1.4;    ',
'}',
'',
'.highlight {',
'    color: #d60c38; /*#e6b800;*/',
'',
'}',
'',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// var $container=$(''<div>'').css({''display'':''flex'',''align-items'':''center'',''margin-right'':''10px'',''gap'':''20px''});',
'// var $datumGroup=$(''<span>'').css({''display'':''flex'',''align-items'':''center''});',
'// $(''#P25_DATUM_ANGABE_AS_MJ_LABEL'').detach().appendTo($datumGroup).css({''margin-right'':''5px'',''white-space'':''nowrap''});',
'// $(''#P25_DATUM_ANGABE_AS_MJ'').detach().appendTo($datumGroup);',
'// var $phaseGroup=$(''<span>'').css({''display'':''flex'',''align-items'':''center''});',
'// $(''#P25_PHASEIN_ENTHALTEN_LABEL'').detach().appendTo($phaseGroup).css({''margin-right'':''5px'',''white-space'':''nowrap''});',
'// $(''#P25_PHASEIN_ENTHALTEN'').detach().appendTo($phaseGroup);',
'// $container.append($datumGroup).append($phaseGroup);',
'// $(''#B487779934025970930'').parent().before($container);',
'// $(''#P25_DATUM_ANGABE_AS_MJ_CONTAINER'').closest(''div.row'').remove();',
'// $(''#P25_PHASEIN_ENTHALTEN_CONTAINER'').closest(''div.row'').remove();',
'// $(''#rThemen .t-Region-headerItems--buttons'').css({''display'':''flex'',''align-items'':''center''});',
'',
''))
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4735611384750451042)
,p_plug_name=>'Amendments'
,p_region_name=>'rAmendments'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'((:P41_ROWID is not null or :P41_Vorschriftid is not null)',
'  and :P41_VORSCHRIFT_TYPID not in (20, 50)',
'  --and instr(UPPER(:P41_VORSCHRIFT_NUMMER), ''UN-R'') = 0 ',
')'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1665395461716173247)
,p_name=>'REPORT_AMENDMENTS'
,p_parent_plug_id=>wwv_flow_imp.id(4735611384750451042)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vrv.rowid,',
'    vv.vorschrift_nummer || '' - '' || vv.vorschrift_bezeichnung as vorgaenger_vorschrift,',
'    nv.vorschrift_nummer || '' - '' || nv.vorschrift_bezeichnung as nachfolger_vorschrift,',
'    vrv.beziehung_art,',
'    (select vret.einsatzdatum',
'        from t_vorschrift_ref_einsatzdatum_typ  vret',
'        where (nv.vorschriftid = vret.vorschriftid)',
'        and vret.einsatzdatum_typid = 1000) as DATUM_IN_KRAFT,',
'    vrv.kommentar,',
'    vrv.letzte_aenderung_datum,',
'    b.nachname || '', '' || b.vorname,',
'    nv.rowid as sup_rowid,',
'     nv.vorschriftid as sup_vorschriftid,',
'    nvl(vorgaenger_vorschriftid,vrv.nachfolger_vorschriftid) as vorgaenger_vorschriftid,',
'    vrv.nachfolger_vorschriftid,',
'    (select listagg(mfv.mfv_name, '', '')',
'        from t_mfv_ref_vorschrift mrv ',
'        left outer join t_mfv mfv on mfv.mfvid = mrv.mfvid',
'        where mrv.vorschriftid = nv.vorschriftid) as MFV',
'from t_vorschrift_ref_vorschrift vrv',
'left outer join t_benutzer b on b.benutzerid = vrv.letzte_aenderung_benutzerid',
'join t_vorschrift vv on vv.vorschriftid = vrv.vorgaenger_vorschriftid and (vrv.BEZIEHUNG_ART IN ( 30))-- Beziehung Suplemtnt/Amendment',
'join t_vorschrift nv on nv.vorschriftid = vrv.nachfolger_vorschriftid and (vrv.BEZIEHUNG_ART IN ( 30))-- Beziehung Suplemtnt/Amendment',
'--left outer join t_mfv_ref_vorschrift mrv on mrv.vorschriftid = :P41_VORSCHRIFTID',
'--left outer join t_mfv mfv on mfv.mfvid = mrv.mfvid',
'',
'where ((vrv.vorgaenger_vorschriftid = :P41_VORSCHRIFTID)--and nv.vorschrift_typid = 20) -- Supplement UN-R ',
'    or (vrv.nachfolger_vorschriftid = :P41_VORSCHRIFTID)) --and vv.vorschrift_typid = 20)) -- Supplement UN-R',
'    ',
'order by 1 ',
''))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P41_VORSCHRIFTID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Keine Amendments zugeordnet.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993807767254220580)
,p_query_column_id=>1
,p_column_alias=>'ROWID'
,p_column_display_sequence=>110
,p_column_heading=>'Rowid'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993810950422220582)
,p_query_column_id=>2
,p_column_alias=>'VORGAENGER_VORSCHRIFT'
,p_column_display_sequence=>30
,p_column_heading=>'Vorschrift'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993810589279220582)
,p_query_column_id=>3
,p_column_alias=>'NACHFOLGER_VORSCHRIFT'
,p_column_display_sequence=>40
,p_column_heading=>'Verlinkte Vorschrift'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993810158027220581)
,p_query_column_id=>4
,p_column_alias=>'BEZIEHUNG_ART'
,p_column_display_sequence=>50
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993809738182220581)
,p_query_column_id=>5
,p_column_alias=>'DATUM_IN_KRAFT'
,p_column_display_sequence=>60
,p_column_heading=>unistr('In Kraftsetzung aus verkn\00FCpfter Vorschrift')
,p_column_format=>'DD.MM.YYYY'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993809372323220581)
,p_query_column_id=>6
,p_column_alias=>'KOMMENTAR'
,p_column_display_sequence=>70
,p_column_heading=>'Kommentar'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993809009628220581)
,p_query_column_id=>7
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>80
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993807363988220580)
,p_query_column_id=>8
,p_column_alias=>'B.NACHNAME||'',''||B.VORNAME'
,p_column_display_sequence=>120
,p_column_heading=>'B.nachname||&#x27;,&#x27;||b.vorname'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993806943091220580)
,p_query_column_id=>9
,p_column_alias=>'SUP_ROWID'
,p_column_display_sequence=>130
,p_column_heading=>'Sup Rowid'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993806593964220579)
,p_query_column_id=>10
,p_column_alias=>'SUP_VORSCHRIFTID'
,p_column_display_sequence=>140
,p_column_heading=>'Sup Vorschriftid'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993808583825220580)
,p_query_column_id=>11
,p_column_alias=>'VORGAENGER_VORSCHRIFTID'
,p_column_display_sequence=>90
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993811410687220583)
,p_query_column_id=>12
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>20
,p_column_heading=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#NACHFOLGER_VORSCHRIFTID#'
,p_column_linktext=>unistr('<span class="fa fa-search" alt="\00D6ffnen" title="\00D6ffnen"  />')
,p_column_link_attr=>'target="_blank"'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993808204650220580)
,p_query_column_id=>12
,p_column_alias=>'NACHFOLGER_VORSCHRIFTID'
,p_column_display_sequence=>100
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993811795320220584)
,p_query_column_id=>13
,p_column_alias=>'DERIVED$02'
,p_column_display_sequence=>10
,p_column_heading=>'<input type="checkbox" value="all" />'
,p_column_html_expression=>'<input type="checkbox" value="#ROW_ID#" />'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P41_STRG_GETEX_ANZEIGE != 20) AND :P41_ROWID IS NOT NULL',
'AND (',
' ',
'    -- 1003=Fachadmin, 1000=VKO, 1200=Redaktionsteam, 1080=Inaktive Funktionen',
'    (pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1200:1080'') > 0 AND :P41_MASTER NOT IN (20, 30))',
'    OR ',
'    -- 1002=VEX can edit NON-GETEX records with status restriction',
'    (pck_ri.fIsUserInRolle(listRolleId => ''1002'') > 0 ',
'     AND :P41_VORSCHRIFT_FREIGABESTATUSID IN (10,30) ',
'     AND :P41_MASTER NOT IN (20, 30))',
')'))
,p_display_when_condition2=>'PLSQL'
,p_report_column_required_role=>wwv_flow_imp.id(2746799753426360144)
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993806118266220579)
,p_query_column_id=>13
,p_column_alias=>'MFV'
,p_column_display_sequence=>150
,p_column_heading=>'Mfv'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(4735611537074451043)
,p_name=>'REPORT_AMENDMENTS'
,p_region_name=>'report-amendments'
,p_parent_plug_id=>wwv_flow_imp.id(4735611384750451042)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vrv.rowid as ROW_ID,',
'    vv.vorschrift_nummer || nvl2(vv.vorschrift_bezeichnung,'' - '', '' '' ) || vv.vorschrift_bezeichnung as vorgaenger_vorschrift,',
'    nv.vorschrift_nummer ||  nvl2(nv.vorschrift_bezeichnung,'' - '', '' '' )  || nv.vorschrift_bezeichnung as nachfolger_vorschrift,',
'    vrv.beziehung_art,',
'    (select vret.einsatzdatum',
'        from t_vorschrift_ref_einsatzdatum_typ  vret',
'        where (nv.vorschriftid = vret.vorschriftid)',
'        and vret.einsatzdatum_typid = 1000) as DATUM_IN_KRAFT,',
'    vrv.kommentar,',
'    vrv.letzte_aenderung_datum,',
'    b.nachname || '', '' || b.vorname as Letzte_aenderung_Benutzer,',
'    nv.rowid as amnd_rowid,',
'    nvl(vorgaenger_vorschriftid,vrv.nachfolger_vorschriftid) as vorgaenger_vorschriftid,',
'    vrv.nachfolger_vorschriftid',
'from t_vorschrift_ref_vorschrift vrv',
'left outer join t_benutzer b on b.benutzerid = vrv.letzte_aenderung_benutzerid',
'join t_vorschrift vv on vv.vorschriftid = vrv.vorgaenger_vorschriftid and (vrv.BEZIEHUNG_ART IN (20))-- Beziehung Amendment',
'join t_vorschrift nv on nv.vorschriftid = vrv.nachfolger_vorschriftid and (vrv.BEZIEHUNG_ART IN (20))-- Beziehung Amendment',
'',
'where  (vrv.vorgaenger_vorschriftid = :P41_VORSCHRIFTID)     ',
'      --  or (vrv.nachfolger_vorschriftid = :P41_VORSCHRIFTID)     ',
'    ',
'order by 1 ',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P41_VORSCHRIFTID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Keine Amendments zugeordnet.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993805494982220578)
,p_query_column_id=>1
,p_column_alias=>'ROW_ID'
,p_column_display_sequence=>20
,p_column_heading=>'Row Id'
,p_column_link=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.:45:P45_ROWID,P45_MASTER:#ROW_ID#,&P25_STRG_GETEX_ANZEIGE.'
,p_column_linktext=>'<span class="fa fa-pencil" alt="Bearbeiten" title="Bearbeiten"  />'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- FOR AMENDMENTS BUTTONS (non-UN-R documents only)',
'',
'-- (:P41_STRG_GETEX_ANZEIGE != 20)  -- Not in GETEX display mode',
'-- AND ',
':P41_ROWID IS NOT NULL  -- Record must exist',
'AND (',
'    -- Section 1: Basic editing (Status -1 OR 1)',
'    -- Only Fachadmin and VKO for status -1 and 1',
unistr('    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (-1, 1)  -- -1=Neue Vorschrift aus GETEX, 1=Grundbef\00FCllung'),
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0 ) -- 1003=Fachadmin, 1000=VKO',
'    --  AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
'    OR',
'    -- Section 2: GETEX scenarios (Status 10,20,30)',
'    -- Fachadmin, VKO, and VEX for status 10,20,30',
'    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (10, 20, 30)  -- 10=in Bearbeitung, 20=Freigegeben, 30=nicht relevant',
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0 ) -- 1003=Fachadmin, 1000=VKO, 1002=VEX',
'    --  AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
')'))
,p_display_when_condition2=>'PLSQL'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993801877721220576)
,p_query_column_id=>2
,p_column_alias=>'VORGAENGER_VORSCHRIFT'
,p_column_display_sequence=>40
,p_column_heading=>'Vorschrift'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993801461082220576)
,p_query_column_id=>3
,p_column_alias=>'NACHFOLGER_VORSCHRIFT'
,p_column_display_sequence=>50
,p_column_heading=>'Verlinkte Vorschrift'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993801061222220576)
,p_query_column_id=>4
,p_column_alias=>'BEZIEHUNG_ART'
,p_column_display_sequence=>60
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993800642493220576)
,p_query_column_id=>5
,p_column_alias=>'DATUM_IN_KRAFT'
,p_column_display_sequence=>70
,p_column_heading=>unistr('In Kraftsetzung aus verkn\00FCpfter Vorschrift')
,p_column_format=>'DD.MM.YYYY'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993804222557220577)
,p_query_column_id=>6
,p_column_alias=>'KOMMENTAR'
,p_column_display_sequence=>80
,p_column_heading=>'Kommentar'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993803890465220577)
,p_query_column_id=>7
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>90
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993805039295220578)
,p_query_column_id=>8
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZER'
,p_column_display_sequence=>100
,p_column_heading=>'Letzte Aenderung Benutzer'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993804631489220578)
,p_query_column_id=>9
,p_column_alias=>'AMND_ROWID'
,p_column_display_sequence=>110
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993803503291220577)
,p_query_column_id=>10
,p_column_alias=>'VORGAENGER_VORSCHRIFTID'
,p_column_display_sequence=>120
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993803019723220577)
,p_query_column_id=>11
,p_column_alias=>'NACHFOLGER_VORSCHRIFTID'
,p_column_display_sequence=>130
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993802636156220577)
,p_query_column_id=>12
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>30
,p_column_heading=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#NACHFOLGER_VORSCHRIFTID#'
,p_column_linktext=>unistr('<span class="fa fa-search" alt="\00D6ffnen" title="\00D6ffnen"  />')
,p_column_link_attr=>'target="_blank"'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993802313610220577)
,p_query_column_id=>13
,p_column_alias=>'DERIVED$02'
,p_column_display_sequence=>10
,p_column_heading=>'<input type="checkbox" value="all" />'
,p_column_html_expression=>'<input type="checkbox" value="#ROW_ID#" />'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- FOR AMENDMENTS BUTTONS (non-UN-R documents only)',
'',
'(:P41_STRG_GETEX_ANZEIGE != 20)  -- Not in GETEX display mode',
'AND :P41_ROWID IS NOT NULL  -- Record must exist',
'AND (',
'    -- Section 1: Basic editing (Status -1 OR 1)',
'    -- Only Fachadmin and VKO for status -1 and 1',
unistr('    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (-1, 1)  -- -1=Neue Vorschrift aus GETEX, 1=Grundbef\00FCllung'),
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0  -- 1003=Fachadmin, 1000=VKO',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
'    OR',
'    -- Section 2: GETEX scenarios (Status 10,20,30)',
'    -- Fachadmin, VKO, and VEX for status 10,20,30',
'    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (10, 20, 30)  -- 10=in Bearbeitung, 20=Freigegeben, 30=nicht relevant',
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0  -- 1003=Fachadmin, 1000=VKO, 1002=VEX',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
')'))
,p_display_when_condition2=>'PLSQL'
,p_report_column_required_role=>wwv_flow_imp.id(2746799753426360144)
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4795247179829439559)
,p_plug_name=>'Themen'
,p_region_name=>'rThemen'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
' -- and :P41_VORSCHRIFT_TYPID <> 20) -- supplements',
' (:P41_ROWID is not null or :P41_Vorschriftid is not null)'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(6882830392011217049)
,p_name=>'Themen'
,p_region_name=>'R482915162223535309'
,p_parent_plug_id=>wwv_flow_imp.id(4795247179829439559)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  sqlqry clob;',
'  lVorschriftID number := :P41_VORSCHRIFTID;',
'  lColList clob;',
'  l_columns clob;',
'  l_modelyear_col clob;  -- New variable for conditional Model Year column',
'BEGIN',
'    -- Get dynamic columns for PIVOT ',
'    SELECT LISTAGG('''''''' || EINSATZDATUM_TYP || '''''' AS "'' || EINSATZDATUM_TYP || ''"'', '', '') ',
'    WITHIN GROUP (ORDER BY sortorder) into lColList',
'    FROM (',
'      SELECT DISTINCT EINSATZDATUM_TYP, sortorder',
'      FROM T_EINSATZDATUM_TYP edt',
'      JOIN T_VORSCHRIFT_REF_THEMA_REF_EINSATZDATUM_TYP vte ON edt.EINSATZDATUM_TYPID = vte.EINSATZDATUM_TYPID',
'      WHERE vte.VORSCHRIFTID = lVorschriftID ',
'      AND vte.einsatzdatum_typid != 1031',
'      AND (',
'           (:P41_VORSCHRIFT_TYPID IN (10, 30, 40) AND edt.einsatzdatum_modellid = :P41_EINSATZDATUM_MODELLID)',
'          )',
'    );',
'',
'    -- Get column names for final SELECT',
'    WITH cols AS (',
'      SELECT DISTINCT '',"'' || EINSATZDATUM_TYP || ''"'' as col_name, sortorder',
'      FROM T_EINSATZDATUM_TYP edt',
'      JOIN T_VORSCHRIFT_REF_THEMA_REF_EINSATZDATUM_TYP vte ON edt.EINSATZDATUM_TYPID = vte.EINSATZDATUM_TYPID',
'      WHERE vte.VORSCHRIFTID = lVorschriftID ',
'      AND vte.einsatzdatum_typid != 1031',
'      AND (',
'          (:P41_VORSCHRIFT_TYPID IN (10, 30, 40) AND edt.einsatzdatum_modellid = :P41_EINSATZDATUM_MODELLID)',
'          )',
'    )',
'    SELECT LISTAGG(col_name) WITHIN GROUP (ORDER BY sortorder) INTO l_columns',
'    FROM cols;',
'',
'    ',
'    IF l_columns IS NULL THEN',
'        l_columns := '''';',
'    END IF;',
'',
'    -- Set Model Year column based on MODELLID',
'    IF :P41_EINSATZDATUM_MODELLID = 30 THEN',
'        l_modelyear_col := '',MODELLJAHR as "Modelljahr"'';',
'    ELSE',
'        l_modelyear_col := '''';',
'    END IF;',
'',
'    sqlqry := ''WITH base_data AS (',
'    SELECT ',
'        ',
'                ''''<a href='''' || ''''"'''' || APEX_PAGE.GET_URL (',
'                    p_clear_cache => 104,',
'                    p_page => 104,',
'                    p_items => ''''P104_THEMAID'''' || '''',P104_VORSCHRIFTID,P104_OPEN_TO_DELETE,'''' || ''''P104_THEMA_READ_ONLY'''',',
'                    p_values => vt.themaid || '''','''' || :P41_VORSCHRIFTID || '''',1,0''''',
'                ) || ''''"'''' || ''''"><span class="fa fa-trash" alt="'''' ',
unistr('                || emano_util.fLang(''''L\00F6schen'''', ''''Delete'''') '),
'                || ''''" title="'''' ',
unistr('                || emano_util.fLang(''''L\00F6schen'''', ''''Delete'''') '),
'                || ''''"></span></a>'''' ',
'            ',
'      AS " ",',
'',
'        CASE ',
'            WHEN PCK_RI.fIsAuthorized01(pck_ri.fGetUserid, 25, 200) = 1  ',
'            THEN ''''<a href='''' || ''''"'''' || APEX_PAGE.GET_URL (',
'                p_clear_cache => 104,',
'                p_page => 104,',
'                p_items => ''''P104_THEMAID'''' || '''',P104_VORSCHRIFTID,P104_THEMA_READ_ONLY'''',',
'                p_values => vt.themaid || '''','''' || vrt.vorschriftid || '''','''' || 0',
'            ) || ''''"'''' || ''''"><span class="fa fa-pencil" alt="'''' ',
'            || emano_util.fLang(''''Bearbeiten'''', ''''Edit'''') ',
'            || ''''" title="'''' ',
'            || emano_util.fLang(''''Bearbeiten'''', ''''Edit'''') ',
'            || ''''"></span></a>'''' || '''' ''''',
'            ELSE NULL ',
'        END AS "&#160;",',
'        ',
'        vt.thema_sortorder as SORT_ORDER,',
'        vt.nummer as "Nummer",',
'        CASE ',
'            WHEN :FSP_LANGUAGE_PREFERENCE = ''''de'''' THEN concat(vt.bezeichnung, case when (nvl(vt.gueltig,0)=0) then '''' <b>(in GETEX inaktiv )</b>''''  else '''' '''' end )',
'            ELSE concat(vt.name_eng, case when (nvl(vt.gueltig,0)=0) then  '''' ( in GETEX inactive)''''  else '''' '''' end )',
'        END AS "Thema",',
'',
'        CASE ',
'            WHEN :FSP_LANGUAGE_PREFERENCE = ''''de'''' THEN vrt.bemerkung',
'            ELSE vrt.bemerkung_englisch',
'        END AS "Kommentar",',
'        ',
'        vrt.letzte_aenderung_datum as AENDERUNG_DATUM_TEMP,',
'        CASE ',
'            WHEN b.nachname IS NOT NULL AND b.vorname IS NOT NULL ',
'                THEN b.nachname || '''', '''' || b.vorname',
'            WHEN b.nachname IS NOT NULL AND b.vorname IS NULL ',
'                THEN b.nachname',
'            WHEN b.nachname IS NULL AND b.vorname IS NOT NULL ',
'                THEN b.vorname',
'            ELSE NULL ',
'        END as AENDERUNG_BENUTZER_TEMP,',
'        ',
'        edt.EINSATZDATUM_TYP as TYP,',
'        TO_CHAR(vte.EINSATZDATUM, ''''DD.MM.YYYY'''') || CASE ',
'            WHEN vte.EINSATZDATUM = vrte.EINSATZDATUM and vte.EINSATZDATUM_TYPID = vrte.EINSATZDATUM_TYPID',
unistr('            THEN '''' <span class="date-tooltip" title="F\00FCr Berechnung im Cockpit verwendet"><sup><span class="fa fa-asterisk status-asterisk" style="font-size:13px;"></span></sup></span>'''''),
'            ELSE ''''''''  ',
'        END as DATUM,',
'        ',
'        CASE ',
'            WHEN :P41_EINSATZDATUM_MODELLID = 30 AND :P41_DATUM_ANGABE_AS_MJ = 1 THEN EXTRACT(YEAR FROM vte.MODELJAHR)',
'            ELSE NULL',
'        END as MODELLJAHR',
'        ',
'    FROM t_vorschrift_ref_thema vrt',
'    LEFT OUTER JOIN v_thema_baum vt ON (vrt.themaid = vt.themaid) ',
'    LEFT OUTER JOIN T_VORSCHRIFT_REF_THEMA_REF_EINSATZDATUM_TYP vte ON (vrt.themaid = vte.themaid and vte.VORSCHRIFTID=vrt.VORSCHRIFTID) ',
'    LEFT OUTER JOIN T_VORSCHRIFT_REF_EINSATZDATUM_TYP vrte ON (vrte.EINSATZDATUM_TYPID = vte.EINSATZDATUM_TYPID and vrte.VORSCHRIFTID=vte.VORSCHRIFTID) ',
'    LEFT OUTER JOIN T_EINSATZDATUM_TYP edt ON (vte.einsatzdatum_typid = edt.einsatzdatum_typid)',
'    LEFT JOIN t_benutzer b ON (b.benutzerid = vrt.letzte_aenderung_benutzerid)',
'    WHERE vrt.vorschriftid = '' || lVorschriftID || '' ',
'    AND vrt.geloescht != 1',
'    ),',
'    pivot_data AS (',
'        SELECT *',
'        FROM base_data',
'        PIVOT (',
'            MAX(DATUM)',
'            FOR TYP IN ('' || lColList || '')',
'        )',
'    )',
'    SELECT ',
'        " ",',
'        "&#160;",',
'        SORT_ORDER,',
'        "Nummer",',
'        "Thema",',
'        "Kommentar"'' || ',
'        l_columns || ',
'        l_modelyear_col || '',',
unistr('        AENDERUNG_BENUTZER_TEMP as "\00C4nderungsbenutzer",'),
unistr('        AENDERUNG_DATUM_TEMP as "\00C4nderungsdatum"'),
'        ',
'    FROM pivot_data',
'    ORDER BY sort_order'';',
'',
'   RETURN sqlqry;',
'   ',
'END;'))
,p_optimizer_hint=>'WITH_PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_read_only_when=>'(:P41_STRG_GETEX_ANZEIGE = 20)'
,p_read_only_when2=>'PLSQL'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P41_VORSCHRIFTID,P41_EINSATZDATUM_MODELLID,P41_DATUM_ANGABE_AS_MJ'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_plug_query_max_columns=>20
,p_query_headings_type=>'QUERY_COLUMNS'
,p_query_num_rows=>100000
,p_query_options=>'GENERIC_REPORT_COLUMNS'
,p_query_no_data_found=>'Noch keine Themen zugeordnet.'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993794024398220567)
,p_query_column_id=>1
,p_column_alias=>'COL01'
,p_column_display_sequence=>20
,p_column_heading=>'Delete'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- FOR THEMEN ADD/EDIT/DELETE BUTTONS',
'(:P41_STRG_GETEX_ANZEIGE != 20)  -- Not in GETEX display mode',
'AND :P41_ROWID IS NOT NULL  -- Record must exist',
'AND (',
'    -- Section 1: Basic editing (Status -1 OR 1)',
'    -- Only Fachadmin and VKO for status -1 and 1',
unistr('    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (-1, 1)  -- -1=Neue Vorschrift aus GETEX, 1=Grundbef\00FCllung'),
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0  -- 1003=Fachadmin, 1000=VKO',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
'    OR',
'    -- Section 2: GETEX scenarios (Status 10,20,30)',
'    -- Fachadmin, VKO, and VEX for status 10,20,30',
'    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (10, 20, 30)  -- 10=in Bearbeitung, 20=Freigegeben, 30=nicht relevant',
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0  -- 1003=Fachadmin, 1000=VKO, 1002=VEX',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
')'))
,p_display_when_condition2=>'PLSQL'
,p_report_column_required_role=>wwv_flow_imp.id(2746799753426360144)
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993793700793220566)
,p_query_column_id=>2
,p_column_alias=>'COL02'
,p_column_display_sequence=>10
,p_column_heading=>'Edit'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- FOR THEMEN ADD/EDIT/DELETE BUTTONS',
'-- (:P41_STRG_GETEX_ANZEIGE != 20)  -- Not in GETEX display mode',
'-- AND ',
':P41_ROWID IS NOT NULL  -- Record must exist',
'AND (',
'    -- Section 1: Basic editing (Status -1 OR 1)',
'    -- Only Fachadmin and VKO for status -1 and 1',
unistr('    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (-1, 1)  -- -1=Neue Vorschrift aus GETEX, 1=Grundbef\00FCllung'),
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0  ) -- 1003=Fachadmin, 1000=VKO',
'    --  AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
'    OR',
'    -- Section 2: GETEX scenarios (Status 10,20,30)',
'    -- Fachadmin, VKO, and VEX for status 10,20,30',
'    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (10, 20, 30)  -- 10=in Bearbeitung, 20=Freigegeben, 30=nicht relevant',
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0  ) -- 1003=Fachadmin, 1000=VKO, 1002=VEX',
'    --  AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
')'))
,p_display_when_condition2=>'PLSQL'
,p_report_column_required_role=>wwv_flow_imp.id(2746799753426360144)
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_column_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P25_STRG_GETEX_ANZEIGE !=20) server  (:P25_STRG_GETEX_ANZEIGE !=20)',
'',
'f useer has wriete accecss edit mode '))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993793229833220566)
,p_query_column_id=>3
,p_column_alias=>'COL03'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993792940047220565)
,p_query_column_id=>4
,p_column_alias=>'COL04'
,p_column_display_sequence=>50
,p_column_heading=>'Nummer'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993792579900220565)
,p_query_column_id=>5
,p_column_alias=>'COL05'
,p_column_display_sequence=>60
,p_column_heading=>'Thema'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993792138813220564)
,p_query_column_id=>6
,p_column_alias=>'COL06'
,p_column_display_sequence=>70
,p_column_heading=>'Kommentar'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993791772618220564)
,p_query_column_id=>7
,p_column_alias=>'COL07'
,p_column_display_sequence=>80
,p_column_heading=>unistr('\00C4nderungsdatum')
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993791401126220564)
,p_query_column_id=>8
,p_column_alias=>'COL08'
,p_column_display_sequence=>90
,p_column_heading=>unistr('\00C4nderungsbenutzer')
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993790979954220563)
,p_query_column_id=>9
,p_column_alias=>'COL09'
,p_column_display_sequence=>100
,p_column_heading=>'Col09'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993790534255220563)
,p_query_column_id=>10
,p_column_alias=>'COL10'
,p_column_display_sequence=>110
,p_column_heading=>'Col10'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993790208640220562)
,p_query_column_id=>11
,p_column_alias=>'COL11'
,p_column_display_sequence=>120
,p_column_heading=>'Col11'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993789745866220562)
,p_query_column_id=>12
,p_column_alias=>'COL12'
,p_column_display_sequence=>130
,p_column_heading=>'Col12'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993797271232220571)
,p_query_column_id=>13
,p_column_alias=>'COL13'
,p_column_display_sequence=>140
,p_column_heading=>'Col13'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993796880751220570)
,p_query_column_id=>14
,p_column_alias=>'COL14'
,p_column_display_sequence=>150
,p_column_heading=>'Col14'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993796508598220570)
,p_query_column_id=>15
,p_column_alias=>'COL15'
,p_column_display_sequence=>160
,p_column_heading=>'Col15'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993796071490220569)
,p_query_column_id=>16
,p_column_alias=>'COL16'
,p_column_display_sequence=>170
,p_column_heading=>'Col16'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993794491046220568)
,p_query_column_id=>17
,p_column_alias=>'COL17'
,p_column_display_sequence=>180
,p_column_heading=>'Col17'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993795620630220569)
,p_query_column_id=>18
,p_column_alias=>'COL18'
,p_column_display_sequence=>190
,p_column_heading=>'Col18'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993795239888220568)
,p_query_column_id=>19
,p_column_alias=>'COL19'
,p_column_display_sequence=>200
,p_column_heading=>'Col19'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993794834482220568)
,p_query_column_id=>20
,p_column_alias=>'COL20'
,p_column_display_sequence=>210
,p_column_heading=>'Col20'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8485846085285317681)
,p_plug_name=>unistr('L\00E4nder')
,p_region_name=>'rLaender'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>140
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'((:P41_ROWID is not null or :P41_Vorschriftid is not null)',
'  and :P41_VORSCHRIFT_TYPID <> 20)'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(8485846318646317683)
,p_name=>unistr('L\00E4nder Tabelle')
,p_parent_plug_id=>wwv_flow_imp.id(8485846085285317681)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'vrl.vorschriftid as "Vorschrift ID",',
'la.landid,',
'''<a href=''||''"''||APEX_PAGE.GET_URL ( ',
'        p_clear_cache => 103,',
'        p_page   => 103,  ',
'        p_items  =>   ''P103_LANDID''  ||'',P103_VORSCHRIFTID,P103_OPEN_TO_DELETE,''||''P103_LAND_READ_ONLY'', ',
'        p_values => la.landid||'',''||:P41_VORSCHRIFTID ||'',1,0''  )||''"''|| ''"><span class="fa fa-trash" alt="'' ',
unistr('                                                                                                           || emano_util.fLang(''L\00F6schen'', ''Delete'') '),
'                                                                                                           || ''" title="'' ',
unistr('                                                                                                           || emano_util.fLang(''L\00F6schen'', ''Delete'') '),
'                                                                                                           || ''"></span></a>'' AS Delete_link,',
'',
'case when PCK_RI.fIsAuthorized01(pck_ri.fGetUserid,25,200) = 1 ---and (:P41_EDIT_MODE = 1) ',
'     then ''<a href=''||''"''||APEX_PAGE.GET_URL (      ',
'                                       p_clear_cache => 103,',
'                                       p_page   => 103,  ',
'                                       p_items  =>  ''P103_LANDID''   ',
'                                       ||'',P103_VORSCHRIFTID,P103_LAND_READ_ONLY'', ',
'                                       p_values => vrl.landid||'',''||vorschriftid ||'',''|| 0 ) ||',
'                     ''"''|| ''><span class="fa fa-pencil" alt="'' ',
'                                                                    || emano_util.fLang(''Bearbeiten'', ''Edit'') ',
'                                                                    || ''" title="'' ',
'                                                                    || emano_util.fLang(''Bearbeiten'', ''Edit'') ',
'                                                                    || ''"></span></a>'' || '' '' ',
'                                                                    ELSE NULL END AS Edit_link,',
'',
'la.b_nummer || '' - '' ||  ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN la.Land',
'        ELSE la.Land_eng ',
'    END AS Land,',
'  nvl2(FLAGGE, ''<img width=20 src="'' || apex_page.get_url(p_page => 0, p_items => ''G_LANDID'', p_values => la.landid, p_request => ''APPLICATION_PROCESS=getFlag'') || ''" />'', null)',
'   AS FLAGGE_URL,',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN vrl.bemerkung',
'        ELSE vrl.BEMERKUNG_ENGLISCH',
'    END as Kommentar,',
'     -- TO_DATE(vrl.letzte_aenderung_datum, ''DD.MM.YYYY HH24:MI:SS'') AS Aenderungsdatum,',
'    vrl.letzte_aenderung_datum AS Aenderungsdatum,',
'    CASE ',
'    WHEN b.nachname IS NOT NULL AND b.vorname IS NOT NULL ',
'        THEN b.nachname || '', '' || b.vorname',
'    WHEN b.nachname IS NOT NULL AND b.vorname IS NULL ',
'        THEN b.nachname',
'    WHEN b.nachname IS NULL AND b.vorname IS NOT NULL ',
'        THEN b.vorname',
'    ELSE NULL ',
'END as Aenderungsbenutzer,',
'     CASE la.SUMS_RELEVANT',
'        WHEN 10 THEN ''ja''',
'        WHEN 20 THEN ''nein''',
'        WHEN 30 THEN ''nicht bewertet''',
'    END AS SUMS_RELEVANT',
'from t_vorschrift_ref_land vrl',
'left outer join t_land la on (vrl.landid = la.landid)',
'left join t_benutzer b on (b.benutzerid = vrl.letzte_aenderung_benutzerid)',
'where vrl.vorschriftid = :P41_VORSCHRIFTID and vrl.geloescht !=1'))
,p_read_only_when_type=>'EXPRESSION'
,p_read_only_when=>' (:P41_STRG_GETEX_ANZEIGE = 20 )'
,p_read_only_when2=>'PLSQL'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P41_VORSCHRIFTID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>200
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('Noch keine L\00E4nder zugeordnet.')
,p_query_num_rows_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>'--and nvl(:P25_EDIT_MODE, 0) = 1)'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993775435172220544)
,p_query_column_id=>1
,p_column_alias=>'Vorschrift ID'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993775047168220544)
,p_query_column_id=>2
,p_column_alias=>'LANDID'
,p_column_display_sequence=>50
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993774639165220543)
,p_query_column_id=>3
,p_column_alias=>'DELETE_LINK'
,p_column_display_sequence=>20
,p_column_heading=>'&nbsp;'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- FOR L\00C4NDER ADD/EDIT/DELETE BUTTONS'),
'(:P41_STRG_GETEX_ANZEIGE != 20)  -- Not in GETEX display mode',
'AND :P41_ROWID IS NOT NULL  -- Record must exist',
'AND (',
'    -- Section 1: Basic editing (Status -1 OR 1)',
'    -- Only Fachadmin and VKO for status -1 and 1',
unistr('    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (-1, 1)  -- -1=Neue Vorschrift aus GETEX, 1=Grundbef\00FCllung'),
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0  -- 1003=Fachadmin, 1000=VKO',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
'    OR',
'    -- Section 2: GETEX scenarios (Status 10,20,30)',
'    -- Fachadmin, VKO, and VEX for status 10,20,30',
'    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (10, 20, 30)  -- 10=in Bearbeitung, 20=Freigegeben, 30=nicht relevant',
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0  -- 1003=Fachadmin, 1000=VKO, 1002=VEX',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
')'))
,p_display_when_condition2=>'PLSQL'
,p_report_column_required_role=>wwv_flow_imp.id(2652734963787598041)
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993774284604220543)
,p_query_column_id=>4
,p_column_alias=>'EDIT_LINK'
,p_column_display_sequence=>10
,p_column_heading=>'&nbsp;'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- FOR L\00C4NDER ADD/EDIT/DELETE BUTTONS'),
'(:P41_STRG_GETEX_ANZEIGE != 20)  -- Not in GETEX display mode',
'AND :P41_ROWID IS NOT NULL  -- Record must exist',
'AND (',
'    -- Section 1: Basic editing (Status -1 OR 1)',
'    -- Only Fachadmin and VKO for status -1 and 1',
unistr('    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (-1, 1)  -- -1=Neue Vorschrift aus GETEX, 1=Grundbef\00FCllung'),
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0  -- 1003=Fachadmin, 1000=VKO',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
'    OR',
'    -- Section 2: GETEX scenarios (Status 10,20,30)',
'    -- Fachadmin, VKO, and VEX for status 10,20,30',
'    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (10, 20, 30)  -- 10=in Bearbeitung, 20=Freigegeben, 30=nicht relevant',
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0  -- 1003=Fachadmin, 1000=VKO, 1002=VEX',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
')'))
,p_display_when_condition2=>'PLSQL'
,p_report_column_required_role=>wwv_flow_imp.id(2652734963787598041)
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993773910018220543)
,p_query_column_id=>5
,p_column_alias=>'LAND'
,p_column_display_sequence=>70
,p_column_heading=>'Land'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993773442907220542)
,p_query_column_id=>6
,p_column_alias=>'FLAGGE_URL'
,p_column_display_sequence=>60
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993773047473220542)
,p_query_column_id=>7
,p_column_alias=>'KOMMENTAR'
,p_column_display_sequence=>80
,p_column_heading=>'Kommentar'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993772666305220542)
,p_query_column_id=>8
,p_column_alias=>'AENDERUNGSDATUM'
,p_column_display_sequence=>100
,p_column_heading=>unistr('\00C4nderungsdatum')
,p_column_format=>'DD.MM.YYYY HH24:MI:SS'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993772306841220541)
,p_query_column_id=>9
,p_column_alias=>'AENDERUNGSBENUTZER'
,p_column_display_sequence=>90
,p_column_heading=>unistr('\00C4nderungsbenutzer')
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993771862179220541)
,p_query_column_id=>10
,p_column_alias=>'SUMS_RELEVANT'
,p_column_display_sequence=>110
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(8667574484668266049)
,p_name=>'Erweiterte Infos'
,p_region_name=>'rErweiterteInfos'
,p_template=>wwv_flow_imp.id(3414119964980820545)
,p_display_sequence=>120
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Cards--animColorFill:t-Cards--3cols:t-Cards--basic'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select distinct',
'    tt.nummer|| '' ''|| CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN tt.Bezeichnung',
'        ELSE tt.name_eng',
'    END as CARD_TITLE,',
'    emano_util.fLang(''Antriebsart(en): '', ''Drive type(s): '') || nvl(aa2.liste, emano_util.fLang(''<i>keine</i>'', ''<i>none</i>'' )) || ''<br />'' ||',
'    emano_util.fLang(''Cluster: '', ''Cluster: '') ||  kc.liste ||    ''<br />'' ||',
'    emano_util.fLang(''Arbeitskreis(e): '', ''Working group(s): '') || nvl(ak2.liste, emano_util.fLang(''<i>keine</i>'', ''<i>none</i>'' )) as CARD_TEXT,',
'    null as CARD_LINK, null as CARD_SUBTEXT,',
'    v.thema_sortorder',
'from t_thema tt',
'join v_thema_baum v on (tt.themaid = v.themaid)',
'join t_vorschrift_ref_thema vr on (tt.themaid = vr.themaid and vr.geloescht != 1)',
' left outer join t_thema_ref_antriebsart trf on (tt.themaid = trf.themaid)',
'outer apply (',
'    select LISTAGG(CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN aa.bezeichnung ELSE aa.name_eng END, '', '') WITHIN GROUP (ORDER BY CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN aa.bezeichnung ELSE aa.name_eng END) AS liste',
'    from t_thema_ref_antriebsart tra',
'    join t_vorschrift_ref_antriebsart vra on (tra.antriebsartid = vra.antriebsartid and vra.geloescht = 0)',
'    join t_antriebsart aa on (vra.antriebsartid = aa.antriebsartid)',
'    where tra.themaid = tt.themaid and vra.vorschriftid = vr.vorschriftid',
') aa2',
'outer apply (',
'    select LISTAGG(CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ak.bezeichnung ELSE ak.name_eng END || '' '' || ak.kurz, '', '') WITHIN GROUP (ORDER BY ak.kurz) AS liste',
'    from t_thema_ref_et_b_ak tra',
'    join t_vorschrift_ref_et_b_ak vra on (tra.et_b_akid = vra.et_b_akid and vra.geloescht = 0)',
'    join t_et_b_ak ak on (vra.et_b_akid = ak.et_b_akid)',
'    where tra.themaid = tt.themaid and vra.vorschriftid = vr.vorschriftid',
') ak2',
'outer apply (',
'    select listagg(distinct kc.bezeichnung,'', '') within group (order by kc.bezeichnung) liste',
'    from t_thema_ref_cluster trc',
'    join t_konzern_cluster kc on (trc.konzern_clusterid = kc.konzern_clusterid)',
'    where trc.themaid = tt.themaid',
') kc',
'left  join t_antriebsart aa on (aa.antriebsartid = trf.antriebsartid)',
'left join t_et_b_ak ak on (ak.et_b_akid = tt.et_b_akid)',
'where vr.vorschriftid = :P41_Vorschriftid',
'order by v.thema_sortorder'))
,p_display_when_condition=>'(:P41_ROWID is not null or :P41_Vorschriftid is not null)'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414129911996820551)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Der Vorschrift sind keine eigenen Themen zugeordnet.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993788650662220559)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>2
,p_column_heading=>'Card Title'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993788223960220559)
,p_query_column_id=>2
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>1
,p_column_heading=>'Card Text'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993787895139220559)
,p_query_column_id=>3
,p_column_alias=>'CARD_LINK'
,p_column_display_sequence=>14
,p_column_heading=>'Card Link'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993787421625220558)
,p_query_column_id=>4
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>3
,p_column_heading=>'Card Subtext'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993789105511220560)
,p_query_column_id=>5
,p_column_alias=>'THEMA_SORTORDER'
,p_column_display_sequence=>4
,p_column_heading=>'Thema Sortorder'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8988778703008303772)
,p_plug_name=>'Ansprechpartner'
,p_region_name=>'rAnsprechpartner'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'(:P41_ROWID is not null or :P41_VORSCHRIFTID is not null)'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(8988778826434303773)
,p_name=>'REPORT_ANSPRECHPARTNER'
,p_parent_plug_id=>wwv_flow_imp.id(8988778703008303772)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with vko_land as (',
unistr('    -- F\00FCr jeden VKO ermitteln, f\00FCr welche L\00E4nder er zust\00E4ndig ist'),
'    select distinct  arb.benutzerid benutzerid, arb.et_b_akid et_b_akid, nvl(arb.Land_independent,0) land_independent, avrl.landid, arb.lead_vko, ET_B_AK_REF_BENUTZERID',
'    from T_ET_B_AK_REF_BENUTZER arb',
'    left outer join t_et_b_ak_vko_ref_land avrl on (avrl.et_b_ak_vkoid = arb.ET_B_AK_REF_BENUTZERID)',
'), v_land as (',
unistr('    -- L\00E4nder, die der Vorschrift zugeordnet sind'),
'    Select distinct vrtl.vorschriftid vorschriftid, vrtl.landid',
'    from T_VORSCHRIFT_REF_LAND  vrtl',
'    where vrtl.geloescht = 0 and vrtl.vorschriftid = :P41_VORSCHRIFTID',
'), vko_themen as (',
'    -- Die zugeordneten Themen der VKOs ermitteln',
'    select arb.benutzerid, arb.et_b_ak_ref_benutzerid, case when avrt.themaid is null then 1 else 0 end as themen_unabhaengig, avrt.themaid',
'    from t_et_b_ak_ref_benutzer arb',
'    left outer join t_et_b_ak_vko_ref_thema avrt on (avrt.et_b_ak_vkoid = arb.et_b_ak_ref_benutzerid)',
'), vko_themen2 as (',
'    -- Die Themen der VKOs mit den Themen der Vorschrift abgleichen',
'    select distinct v1.benutzerid, v1.et_b_ak_ref_benutzerid',
'    from vko_themen v1',
'    join t_vorschrift_ref_thema vrt on (v1.themaid = vrt.themaid or v1.themen_unabhaengig = 1)',
'    where vrt.vorschriftid = nvl(:P41_PARENT_VORSCHRIFTID, :P41_VORSCHRIFTID) and vrt.geloescht = 0',
'),',
'cte_vex as (',
'    select',
'        t1.benutzerid, -- VEX',
'        t3.themaid,',
'        case when t3.themaid is null then 1 else 0 end as thema_alle,',
'        t1.et_b_akid et_b_akid, t1.rolleid rolleid',
'    from t_et_b_ak_ref_thema_benutzer t1',
'    left outer join t_et_b_ak_ref_thema_benutzer_ref_et_b_ak_ref_thema t2 on (t1.et_b_ak_ref_thema_benutzerid = t2.et_b_ak_ref_thema_benutzerid)',
'    left outer join t_thema_ref_et_b_ak t3 on (t2.thema_ref_et_b_akid = t3.thema_ref_et_b_akid)',
')',
'',
'select ',
'    distinct ''VKO'' as TYP, b.Nachname ||'', ''||b.Vorname || '' (''||b.Abteilung || '')'' as Bezeichnung,',
'    CASE WHEN vl.Lead_VKO = 1 THEN emano_util.fLang(''Ja'', ''Yes'') ELSE emano_util.fLang(''Nein'', ''No'')END AS AK_Leiter,',
'    case when (nvl(vl.Land_independent, 0) =1 ) then emano_util.fLang(''Ja'', ''Yes'') ',
'         else (select listagg(tl.B_nummer, '', '') within group (order by tl.B_nummer)  ',
'                from v_land l --t_land l ',
'                join t_land tl on (l.landid = tl.landid)',
'                join t_et_b_ak_vko_ref_land avrl on (avrl.landid = l.landid and avrl.et_b_ak_vkoid = vl.ET_B_AK_REF_BENUTZERID)',
'         ) ',
'    end as Land_independent, b.email E_Mail, ak.bezeichnung Arbeitskreis',
'FROM T_VORSCHRIFT_REF_ET_B_AK vra',
'join t_et_b_ak ak on (vra.et_b_akid = ak.et_b_akid)',
'left outer join v_land l on (vra.vorschriftid = l.vorschriftid)',
'left outer join vko_land vl on (vra.et_b_akid = vl.et_b_akid and (vl.land_independent = 1 or l.landid = vl.landid))',
'--left join vko_themen2 t2 on (t2.benutzerid = vl.benutzerid)',
'left outer join t_benutzer b on (vl.benutzerid = b.benutzerid)',
'where vra.vorschriftid = nvl(:P41_PARENT_VORSCHRIFTID, :P41_VORSCHRIFTID) and vra.geloescht = 0 and vl.benutzerid is not null',
'and vl.benutzerid in (select benutzerid from vko_themen2)',
'',
'',
'  UNION all',
'  /*',
'   select distinct ''Regulierungsverantwortliche'' TYP, v.Nachname ||'', ''||v.Vorname || '' (''||v.Abteilung || '')'' as Bezeichnung,',
'       '''' AK_Leiter, '''' Land_independent, ',
'             '''' E_Mail, '''' Arbeitskreis',
'    FROM T_VORSCHRIFT_REF_verantwortlicher  vrv',
'    join  t_verantwortlicher v on (v.verantwortlicherid = vrv.verantwortlicherid)',
'  WHERE vrv.VORSCHRIFTID = nvl(:P41_PARENT_VORSCHRIFTID, :P41_VORSCHRIFTID)',
'  */',
'',
'  /*',
'listagg(CASE WHEN vrv.IST_HAUPTVERANTWORTLICHER = 10 THEN ',
'  ''<span style="text-decoration: underline;">'' || vv.nachname || '', '' || vv.vorname || ''</span>''',
'  ELSE vv.nachname || '', '' || vv.vorname END, ''; '') WITHIN GROUP (ORDER BY vv.nachname) as verantwortlicher  ',
' */',
'',
'   SELECT DISTINCT ',
'  ''Regulierungsverantwortliche'' AS TYP, ',
'  CASE ',
'    WHEN vrv.IST_HAUPTVERANTWORTLICHER = 10 ',
'    THEN ''<span style="text-decoration: underline;">'' || v.Nachname || '', '' || v.Vorname || ''</span>'' ',
'    ELSE v.Nachname || '', '' || v.Vorname ',
'  END || '' ('' || v.Abteilung || '')'' AS Bezeichnung,',
'  '''' AS AK_Leiter, ',
'  '''' AS Land_independent, ',
'  '''' AS E_Mail, ',
'  '''' AS Arbeitskreis',
'FROM T_VORSCHRIFT_REF_VERANTWORTLICHER vrv',
'JOIN t_verantwortlicher v ON v.verantwortlicherid = vrv.verantwortlicherid',
'WHERE vrv.VORSCHRIFTID = NVL(:P41_PARENT_VORSCHRIFTID, :P41_VORSCHRIFTID)',
'',
'',
'  UNION ALL',
'  ',
'  select distinct --cv.benutzerid',
'    case brr.rolleid when  1002 then ''VEX'' ',
'                      when  1006 then ''FbEx'' ',
'                      else '''' end  TYP, ',
'   b.Nachname ||'', '' || b.Vorname || '' ('' || b.Abteilung || '')'' as Bezeichnung,',
'       '''' as AK_Leiter, '''' as Land_independent,  b.email as E_Mail0,',
'       CASE ',
'           WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ak.bezeichnung ',
'           ELSE ak.name_eng ',
'       END as Arbeitskreis',
'       ',
'from t_vorschrift_ref_et_b_ak vak',
unistr('join t_vorschrift_ref_thema vrt on (vak.vorschriftid = vrt.vorschriftid)    -- alle ak der Vorschrift die mit themen der Vorschriften verkn\00FCpft sind '),
'join cte_vex cv on (vak.et_b_akid = cv.et_b_akid ',
unistr('                    and (vrt.themaid = cv.themaid or cv.thema_alle = 1)) -- zusatzbedingung AK von VEX  mit themen von VEX  OR themenunabh\00E4ngig'),
'join  t_benutzer b on (b.benutzerid = cv.benutzerid and b.Status=10 )  -- active',
'    join T_BENUTZER_REF_ROLLE brr on (brr.benutzerid = b.benutzerid and brr.rolleid in (1002, 1006) and brr.rolleid = cv.rolleid )',
'    join T_ET_B_AK ak on (ak.ET_B_AKID = cv.ET_B_AKID  )',
'where vak.vorschriftid = nvl(:P41_PARENT_VORSCHRIFTID, :P41_VORSCHRIFTID) and vak.geloescht = 0 and vrt.geloescht = 0',
'order by 1,2;',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P41_VORSCHRIFTID_PARENT'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>30
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Keine Ansprechpartner zugeordnet.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993784885265220555)
,p_query_column_id=>1
,p_column_alias=>'TYP'
,p_column_display_sequence=>1
,p_column_heading=>'Typ'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993784499429220554)
,p_query_column_id=>2
,p_column_alias=>'BEZEICHNUNG'
,p_column_display_sequence=>2
,p_column_heading=>'Bezeichnung'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993784044203220553)
,p_query_column_id=>3
,p_column_alias=>'AK_LEITER'
,p_column_display_sequence=>5
,p_column_heading=>'AK Leiter'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993783621407220553)
,p_query_column_id=>4
,p_column_alias=>'LAND_INDEPENDENT'
,p_column_display_sequence=>3
,p_column_heading=>unistr('L\00E4nderunabh\00E4ngig')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993783305171220552)
,p_query_column_id=>5
,p_column_alias=>'E_MAIL'
,p_column_display_sequence=>6
,p_column_heading=>'E-Mail'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993782852553220552)
,p_query_column_id=>6
,p_column_alias=>'ARBEITSKREIS'
,p_column_display_sequence=>4
,p_column_heading=>'Arbeitskreis'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9230682580765558546)
,p_plug_name=>unistr('Konzernaktivit\00E4ten')
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'(:P41_ROWID is not null or :P41_VORSCHRIFTID is not null)'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(9230682740139558547)
,p_name=>'Konzern JIRA Tickets'
,p_parent_plug_id=>wwv_flow_imp.id(9230682580765558546)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  TicketNr, ',
'        PCK_RI.fCreateLinkIfUrl("LINK", 250) as Link',
'  from t_Konzern_Jira_ticket kj',
'  join T_KONZERN_JIRA_TICKET_REF_VORSCHRIFT krv on (krv.KONZERN_JIRA_TICKETID = kj.KONZERN_JIRA_TICKETID )',
' WHERE krv.vorschriftid = :P41_VORSCHRIFTID'))
,p_display_when_condition=>'exists (select 1 from T_Benutzer_ref_rolle where rolleid in (1000, 1003, 1002) and benutzerid = pck_ri.fgetUserId);'
,p_display_when_cond2=>'SQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Keine Tickets zugeordnet'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993781874594220550)
,p_query_column_id=>1
,p_column_alias=>'TICKETNR'
,p_column_display_sequence=>1
,p_column_heading=>'Ticketnummer'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993781510304220550)
,p_query_column_id=>2
,p_column_alias=>'LINK'
,p_column_display_sequence=>2
,p_column_heading=>'Link'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9767890902596280476)
,p_plug_name=>'Funktionen FuKa (System42)'
,p_region_name=>'rFunktionen'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>130
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'(:P41_ROWID is not null or :P41_Vorschriftid is not null)'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(9767891049642280477)
,p_name=>'Funktionen Tabelle'
,p_parent_plug_id=>wwv_flow_imp.id(9767890902596280476)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  case when f.status = emano_util.fLang(''veraltet'', ''outdated'') then',
'              ''<span style="color:darkred;">'' ||f.bezeichnung || ''</span>''',
'           when f.status = emano_util.fLang(''in Bearbeitung'', ''in progress'') then',
'             ''<span style="color:darkorange;">'' ||f.bezeichnung || ''</span>''',
'           else f.bezeichnung',
'           end "BEZEICHNUNG",',
'         f.beschreibung, f.objekttyp,',
'    --    vrf.LETZTE_AENDERUNG_DATUM, ',
'    case when :FSP_LANGUAGE_PREFERENCE = ''de'' then to_char(vrf.LETZTE_AENDERUNG_DATUM, ''DD.MM.YYYY HH24:MI'') else to_char(vrf.LETZTE_AENDERUNG_DATUM, ''MM/DD/YYYY HH24:MI'') end LETZTE_AENDERUNG_DATUM,',
'        f.status,',
'       nvl2(vrf.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) as LETZTE_AENDERUNG_BENUTZERID,',
'       f.id_aus_excel',
'from T_VORSCHRIFT_REF_FUNKTION vrf',
'inner join t_funktion f on (f.funktionid = vrf.funktionid)',
'left outer join t_benutzer b on (b.benutzerid = vrf.LETZTE_AENDERUNG_BENUTZERID)',
'where vrf.vorschriftid = :P41_VORSCHRIFTID',
'and vrf.geloescht = 0'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'Keine Funktionen zugeordnet.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993779672607220548)
,p_query_column_id=>1
,p_column_alias=>'BEZEICHNUNG'
,p_column_display_sequence=>1
,p_column_heading=>'Bezeichnung'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993779275167220548)
,p_query_column_id=>2
,p_column_alias=>'BESCHREIBUNG'
,p_column_display_sequence=>3
,p_column_heading=>'Beschreibung'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993778898351220547)
,p_query_column_id=>3
,p_column_alias=>'OBJEKTTYP'
,p_column_display_sequence=>5
,p_column_heading=>'Objekttyp'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993778466763220547)
,p_query_column_id=>4
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>6
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993778043890220547)
,p_query_column_id=>5
,p_column_alias=>'STATUS'
,p_column_display_sequence=>4
,p_column_heading=>'Status'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993777693483220547)
,p_query_column_id=>6
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZERID'
,p_column_display_sequence=>7
,p_column_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993777235118220547)
,p_query_column_id=>7
,p_column_alias=>'ID_AUS_EXCEL'
,p_column_display_sequence=>2
,p_column_heading=>'ID Function42'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12195436989792892158)
,p_plug_name=>'Kerndaten'
,p_region_name=>'rKerndaten'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--PCK_RI.fIsAuthorized(pck_ri.fGetUserid,25,200) = false',
'false'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12196866706953287320)
,p_plug_name=>unistr('Verkn\00FCpfte Vorschriften')
,p_region_name=>'rVerknuepfungen'
,p_region_template_options=>'#DEFAULT#:is-expanded:i-h480:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'( ( (:P41_ROWID is not null or :P41_Vorschriftid is not null)',
'     and :P41_VORSCHRIFT_TYPID <> 20 ',
'  )',
'  --  or (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
')'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12196866778328287321)
,p_plug_name=>'REPORT_VERKNUEPFUNGEN'
,p_region_name=>'report-verknuepfungen'
,p_parent_plug_id=>wwv_flow_imp.id(12196866706953287320)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ctl_b_nummern AS (',
'    SELECT vorschriftid, LISTAGG(b_nummer, '', '') WITHIN GROUP (ORDER BY b_nummer) AS b_nummern',
'    FROM (',
'        SELECT DISTINCT vrtrl.vorschriftid, l.b_nummer',
'        FROM t_vorschrift_ref_land vrtrl',
'        JOIN t_land l ON l.landid = vrtrl.landid',
'        WHERE vrtrl.geloescht = 0',
'    )',
'    GROUP BY vorschriftid',
'), cte1 as (',
unistr('        /* Alle Verkn\00FCpfungen selektieren, f\00FCr Analysezwecke mit den Vorschriftennummern'),
unistr('           Nur Vorg\00E4nger-Nachfolger-Verkn\00FCpfungen */'),
'        select v1.vorschriftid v_id, v1.vorschrift_nummer v_nr, v2.vorschriftid n_id, v2.vorschrift_nummer n_nr',
'        from t_vorschrift_ref_vorschrift vrv',
'        join t_vorschrift v1 on (vrv.vorgaenger_vorschriftid = v1.vorschriftid)',
'        join t_vorschrift v2 on (vrv.nachfolger_vorschriftid = v2.vorschriftid)',
'        where vrv.beziehung_art = 40',
'          and (nvl(vrv.max_homologation_vorschriftid, 0) != vrv.vorgaenger_vorschriftid )-- deckelung',
unistr('   ), cte_ved as ( -- Vorschriften mit Au\00DFerkraftdatum <= sysdate ( d\00FCrfen nicht in die Kette )'),
'          select distinct vorschriftid, einsatzdatum_typid, einsatzdatum',
'          from t_vorschrift_ref_einsatzdatum_typ ',
'          where einsatzdatum_typid   in (1041, 1063, 1061)     --121',
'           and einsatzdatum <= sysdate                       --52',
'        order by Vorschriftid',
'  ), cte2 as (',
unistr('    /* Ausgehend von jeder Vorschrift rekursiv zu den Vorg\00E4ngern gehen, soweit es geht */'),
'    select  cte1.v_id, cte1.n_id, sys_connect_by_path(v_id,'':'') pfad --, level xlevel --, connect_by_root v_id as root_v_id --, connect_by_isleaf leaf',
'    from cte1 where  cte1.v_id not in (select vorschriftid from cte_ved)',
'    connect by prior n_id =  v_id',
'    START WITH  v_id =  :P41_VORSCHRIFTID  --2738    --2765 --10700 --30207 --436',
unistr('  ) , cte_land as (  -- vorschr mit l\00E4nder'),
'        select --vorschriftid, ',
'        listagg(distinct ',
'        ''<a href="'' ||  apex_page.get_url(p_page => 172, p_items => ''P172_B_NUMMER'', p_values => l.b_nummer, p_clear_cache => 172) ',
'            || ''" target="_blank"><span title="Anzeigen Demand-Vorschriften mit '' || l.b_nummer ||''" " class="fa fa-search"></span></a> ''|| l.b_nummer  ',
'        , '', '' on overflow truncate ) within group (order by l.b_nummer) as land_lst ',
'        from t_vorschrift_ref_land vr-- where vorschriftid   in  (  285, 289, 303, 309, 315, 401 ) --1307 ',
'        join t_land l on ( l.landid = vr.landid)',
'        where geloescht = 0 ',
'        and vorschriftid in ( select n_id from cte2 ) ',
'        --group by vorschriftid',
' )',
'SELECT',
'    vrv.rowid AS xrowid,',
'    vrv.rowid AS checkbox,',
'',
unistr('    -- Vorg\00E4nger (Predecessor) - Link + Number + Conditional Date'),
'    CASE WHEN vv.vorschriftid != :P41_VORSCHRIFTID THEN',
'        ''<a href="'' ||',
'            apex_page.get_url(p_page => 25, p_items => ''P41_VORSCHRIFTID'', p_values => vv.vorschriftid, p_clear_cache => 25) ',
'            || ''" target="_blank"><span alt="Anzeigen" title="Anzeigen" class="fa fa-search"></span></a> '' ||',
'        ''<a href="'' ||',
'            apex_page.get_url(p_page => 300, p_items => ''P300_VORSCHRIFTID'', p_values => vv.vorschriftid, p_clear_cache => 300)',
unistr('            || ''" target="_blank"><span alt="Vernetzungsansicht \00F6ffnen" title="Vernetzungsansicht \00F6ffnen" class="fa fa-network-hub"></span></a> '''),
'    END ||',
'    vv.vorschrift_nummer || -- Number',
'    case -- Conditional Date Display based on P41_ERW_LAND_ANZEIGE',
'      when (vv.dokumentendatum is not null and :P41_ERW_LAND_ANZEIGE = ''Ja'')',
'      then '' - '' || TO_CHAR(vv.dokumentendatum, ''DD.MM.YYYY'') -- Added formatting',
'      else '''' -- Display only number if condition not met or date is null',
'    end',
'    AS vorgaenger_vorschrift,',
'',
'    -- Nachfolger (Successor) - Link + Number + Conditional Date',
'    CASE WHEN nv.vorschriftid != :P41_VORSCHRIFTID THEN',
'        ''<a href="'' ||',
'            apex_page.get_url(p_page => 25, p_items => ''P41_VORSCHRIFTID'', p_values => nv.vorschriftid, p_clear_cache => 25) ',
'            || ''" target="_blank"><span alt="Anzeigen" title="Anzeigen" class="fa fa-search"></span></a> '' ||',
'        ''<a href="'' ||',
'            apex_page.get_url(p_page => 300, p_items => ''P300_VORSCHRIFTID'', p_values => nv.vorschriftid, p_clear_cache => 300)',
unistr('            || ''" target="_blank"><span alt="Vernetzungsansicht \00F6ffnen" title="Vernetzungsansicht \00F6ffnen" class="fa fa-network-hub"></span></a> '''),
'    END ||',
'    nv.vorschrift_nummer || -- Number',
'    case -- Conditional Date Display based on P41_ERW_LAND_ANZEIGE',
'      when (nv.dokumentendatum is not null and :P41_ERW_LAND_ANZEIGE = ''Ja'')',
'      then '' - '' || TO_CHAR(nv.dokumentendatum, ''DD.MM.YYYY'') -- Added formatting',
'      else '''' -- Display only number if condition not met or date is null',
'    end',
'    AS nachfolger_vorschrift,',
'',
'    vrv.beziehung_art,',
'    (SELECT vret.einsatzdatum',
'        FROM t_vorschrift_ref_einsatzdatum_typ vret',
'        WHERE vret.vorschriftid = CASE WHEN vrv.vorgaenger_vorschriftid = :P41_VORSCHRIFTID THEN vrv.nachfolger_vorschriftid ELSE vrv.vorgaenger_vorschriftid END',
'          AND vret.einsatzdatum_typid = 1000',
'    ) AS datum_in_kraft_verlinkt,',
'    vrv.datum_neue_typen,',
'    vrv.datum_alle_typen,',
'    CASE vrv.homologation_serie',
'        WHEN 10 THEN ''Ja''',
'        WHEN 0 THEN ''Nein''',
'        ELSE NULL',
'    END AS homologation_serie_display,',
'    case when  (vrv.beziehung_art = 40 AND vrv.vorgaenger_vorschriftid = :P41_VORSCHRIFTID ) and length((select land_lst from cte_land)) is not null then ',
unistr('                    ''Die Vorschrift kann als h\00F6here UN-R Serie optional angewendet werden in den folgenden L\00E4ndern'''),
'               else vrv.kommentar end as kommentar,',
'    vrv.kommentar_englisch,',
'    CASE',
'        WHEN (vrv.beziehung_art = 40 AND vv.vorschriftid != :P41_VORSCHRIFTID AND vv.vorschrift_typid = 30) THEN',
'             (SELECT bn.b_nummern FROM ctl_b_nummern bn WHERE bn.vorschriftid = vv.vorschriftid)',
'        WHEN (vrv.beziehung_art = 40 AND nv.vorschriftid != :P41_VORSCHRIFTID AND nv.vorschrift_typid = 30) OR',
'             (vrv.beziehung_art = 102 AND nv.vorschrift_typid = 10) THEN',
'             (SELECT bn.b_nummern FROM ctl_b_nummern bn WHERE bn.vorschriftid = nv.vorschriftid)',
'        ELSE NULL',
'    END AS b_nummern,',
'    -- 1585 demands demand',
'    CASE',
'        WHEN (vrv.beziehung_art = 40 AND vrv.vorgaenger_vorschriftid = :P41_VORSCHRIFTID ) THEN',
'             (select land_lst from cte_land)',
'         ELSE NULL ',
'    END as Land_list_DEM_DEM,',
'    --',
'    vrv.letzte_aenderung_datum,',
'    mref.vorschrift_nummer AS max_ref,',
'    nvl2(vrv.letzte_aenderung_benutzerid,',
'    CASE',
'        WHEN b.nachname IS NOT NULL AND b.vorname IS NOT NULL',
'        THEN b.nachname || '', '' || b.vorname',
'        WHEN b.nachname IS NOT NULL AND b.vorname IS NULL',
'        THEN b.nachname',
'        WHEN b.nachname IS NULL AND b.vorname IS NOT NULL',
'        THEN b.vorname',
'        ELSE NULL',
'    END,',
'    null) AS letzte_aenderung_benutzer',
'FROM',
'    t_vorschrift_ref_vorschrift vrv',
'LEFT OUTER JOIN t_benutzer b ON b.benutzerid = vrv.letzte_aenderung_benutzerid',
'JOIN t_vorschrift vv ON vv.vorschriftid = vrv.vorgaenger_vorschriftid',
'JOIN t_vorschrift nv ON nv.vorschriftid = vrv.nachfolger_vorschriftid',
'LEFT OUTER JOIN t_vorschrift mref ON vrv.max_homologation_vorschriftid = mref.vorschriftid',
'WHERE',
'   ( (vrv.vorgaenger_vorschriftid = :P41_VORSCHRIFTID AND vrv.beziehung_art != 20) -- Exclude Amendments (Type 20)',
'    OR vrv.nachfolger_vorschriftid = :P41_VORSCHRIFTID)',
'    AND (vrv.beziehung_art NOT IN (30)) -- Exclude Supplements (Type 30)',
'ORDER BY 1'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P41_VORSCHRIFTID'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>' (:P41_STRG_GETEX_ANZEIGE = 20 )'
,p_plug_read_only_when2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'REPORT_VERKNUEPFUNGEN'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    -- Original (excluding supplements):',
'and (vrv.BEZIEHUNG_ART NOT IN (30) and (20 not in (vv.vorschrift_typid, nv.vorschrift_typid)))',
'',
'-- Modified (including supplements):',
'and (vrv.BEZIEHUNG_ART IN (30, 40, 102) -- Include supplement type 30 along with other valid types',
'     or (vv.vorschrift_typid IN (20, 30) -- Include both supplement and regular types',
'         or nv.vorschrift_typid IN (20, 30)))',
'',
'',
'',
'',
'         --and nvl(:P25_EDIT_MODE, 0) = 1)'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(4851090277994292513)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>unistr('Es gibt keine Verkn\00FCpfungen f\00FCr diese Vorschrift.')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>8523302593893680748
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(993748478708220510)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>10
,p_column_identifier=>'L'
,p_column_label=>'<input type="checkbox" value="all" />'
,p_column_html_expression=>'<input type="checkbox" value="#XROWID#" />'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'OTHER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_rpt_show_filter_lov=>'N'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- FOR VERKN\00DCPFUNGEN'),
'(:P41_STRG_GETEX_ANZEIGE != 20)  -- Not in GETEX display mode',
'AND :P41_ROWID IS NOT NULL  -- Record must exist',
'AND (',
'    -- Section 1: Basic editing (Status -1 OR 1)',
'    -- Only Fachadmin and VKO for status -1 and 1',
unistr('    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (-1, 1)  -- -1=Neue Vorschrift aus GETEX, 1=Grundbef\00FCllung'),
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0  -- 1003=Fachadmin, 1000=VKO',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
'    OR',
'    -- Section 2: GETEX scenarios (Status 10,20,30)',
'    -- Fachadmin, VKO, and VEX for status 10,20,30',
'    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (10, 20, 30)  -- 10=in Bearbeitung, 20=Freigegeben, 30=nicht relevant',
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0  -- 1003=Fachadmin, 1000=VKO, 1002=VEX',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
')'))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(2746799753426360144)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(993752880744220515)
,p_db_column_name=>'XROWID'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.:45:P45_ROWID,P45_MASTER:#XROWID#,&P25_STRG_GETEX_ANZEIGE.'
,p_column_linktext=>'<span class="fa fa-pencil" alt="Bearbeiten" title="Bearbeiten"></span>'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_column_alignment=>'CENTER'
,p_rpt_show_filter_lov=>'N'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- FOR VERKN\00DCPFUNGEN'),
'-- (:P41_STRG_GETEX_ANZEIGE != 20)  -- Not in GETEX display mode',
'-- AND ',
':P41_ROWID IS NOT NULL  -- Record must exist',
'AND (',
'    -- Section 1: Basic editing (Status -1 OR 1)',
'    -- Only Fachadmin and VKO for status -1 and 1',
unistr('    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (-1, 1)  -- -1=Neue Vorschrift aus GETEX, 1=Grundbef\00FCllung'),
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0 )-- 1003=Fachadmin, 1000=VKO',
'    --  AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
'    OR',
'    -- Section 2: GETEX scenarios (Status 10,20,30)',
'    -- Fachadmin, VKO, and VEX for status 10,20,30',
'    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (10, 20, 30)  -- 10=in Bearbeitung, 20=Freigegeben, 30=nicht relevant',
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0 ) -- 1003=Fachadmin, 1000=VKO, 1002=VEX',
'    --  AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
')'))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(993751616657220514)
,p_db_column_name=>'BEZIEHUNG_ART'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Art der Beziehung'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(2655378917409322525)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(993748028281220510)
,p_db_column_name=>'DATUM_IN_KRAFT_VERLINKT'
,p_display_order=>50
,p_column_identifier=>'M'
,p_column_label=>unistr('In Kraftsetzung aus verkn\00FCpfter Vorschrift')
,p_column_type=>'DATE'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(993751263075220513)
,p_db_column_name=>'DATUM_NEUE_TYPEN'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Einsatztermin neue Typen'
,p_column_type=>'DATE'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(993750908599220513)
,p_db_column_name=>'DATUM_ALLE_TYPEN'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Einsatztermin alle Fahrzeuge'
,p_column_type=>'DATE'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(993750460387220513)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(993749665768220512)
,p_db_column_name=>'B_NUMMERN'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('L\00E4nder')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(993749270813220511)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(993747294233220509)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>110
,p_column_identifier=>'O'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(993747632929220510)
,p_db_column_name=>'HOMOLOGATION_SERIE_DISPLAY'
,p_display_order=>120
,p_column_identifier=>'N'
,p_column_label=>unistr('Homologation mit h\00F6herer Serie m\00F6glich')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(993748839957220511)
,p_db_column_name=>'MAX_REF'
,p_display_order=>130
,p_column_identifier=>'K'
,p_column_label=>'Maximale Homologationsvorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(993750091632220512)
,p_db_column_name=>'KOMMENTAR_ENGLISCH'
,p_display_order=>140
,p_column_identifier=>'H'
,p_column_label=>'Kommentar Englisch'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(993752467292220515)
,p_db_column_name=>'VORGAENGER_VORSCHRIFT'
,p_display_order=>150
,p_column_identifier=>'B'
,p_column_label=>'Vorgaenger Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(993752067721220514)
,p_db_column_name=>'NACHFOLGER_VORSCHRIFT'
,p_display_order=>160
,p_column_identifier=>'C'
,p_column_label=>'Nachfolger Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(993753276619220517)
,p_db_column_name=>'LAND_LIST_DEM_DEM'
,p_display_order=>170
,p_column_identifier=>'P'
,p_column_label=>'Land List Dem Dem'
,p_column_html_expression=>'<span title="My tooltip text">#LAND_LIST_DEM_DEM#</span>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(4851123535033425411)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5375933'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'CHECKBOX:NACHFOLGER_VORSCHRIFT:VORGAENGER_VORSCHRIFT:BEZIEHUNG_ART:DATUM_IN_KRAFT_VERLINKT:DATUM_NEUE_TYPEN:DATUM_ALLE_TYPEN:KOMMENTAR:B_NUMMERN:LETZTE_AENDERUNG_DATUM:LETZTE_AENDERUNG_BENUTZER:HOMOLOGATION_SERIE_DISPLAY:MAX_REF:KOMMENTAR_ENGLISCH:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12202881112625828884)
,p_plug_name=>'MfVs'
,p_region_name=>'rMfVs'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>110
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'((:P41_ROWID is not null or :P41_Vorschriftid is not null)',
'--  and :P41_VORSCHRIFT_TYPID <> 20',
')'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(4809356465692035924)
,p_name=>'MfV - Information'
,p_region_name=>'p41_mfv_report_information'
,p_parent_plug_id=>wwv_flow_imp.id(12202881112625828884)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ex as (  select i.mfvid as mfvid, ',
'    listagg(a.kurz,'', '') within group (order by a.kurz) as ak_liste',
'    from t_mfv_ref_et_b_ak i',
'    join t_et_b_ak a on (i.et_b_akid = a.et_b_akid) group by i.mfvid',
' ),',
'teil as ( select listagg( t.teil || ''. ''||t.bezeichnung, '', '') within group (order by t.teil || ''. ''||t.bezeichnung) as teil_bez_list,',
'                                 mrt.mfvid mfvid',
'                from t_mfv_ref_mfv_teil mrt',
'                join t_mfv_teil t on (t.mfv_teilID = mrt.mfv_teilid)',
'                 group by mrt.mfvid',
' ) ',
'  ',
'select mrv.rowid as Information_row_id , ',
'm.MFVID as row_key_2,',
'       case when ( --(:P41_EDIT_MODE is not null and :P41_EDIT_MODE = 1 ) ',
'                        m.DMS_DOKUMENTENSTATUS != 30  ',
'                   and nvl(m.GUELTIGKEITSDATUM, sysdate) < sysdate ) ',
'              then',
unistr('                    ''<span style="cursor:pointer;" text-align:center;" class="setzegueltigkeit fa fa-check" data-id="'' || m.mfvid || ''"><small><br>'' || emano_util.fLang(''G\00FCltigkeit'', ''Validity'') || ''<br>'' || emano_util.fLang(''best\00E4tigen'', ''confirm'') ')
||'|| ''<small></span>'' ',
'                else',
'                    ''#'' end as link,',
'       m.MFVID,',
'       m.mfv_name,',
'       teil.teil_bez_list AS "MFV_TEIL",',
'       case when length(m.mfv_thema ) > 64 then substr(m.mfv_thema,0,64)||''...'' else m.mfv_thema  end as mfv_thema,',
'       SCHLAGWORTE,',
'       VORSCHRIFTENVERANTWORTLICHER AS "VORSCHRIFTENVERANTWORTLICHER",',
'       ex.ak_liste  as Arbeitskreis_liste,',
'       BETEILIGTE_OES,',
'       PCK_RI.fCreateLinkIfUrl("LINK_MFV_DMS") AS "LINK_MFV_DMS",',
'       case when (m.JIRA_Status is null or m.JIRA_Status=0) then ',
'                                                            emano_util.fLang(''offen'', ''open'') ',
'                                                        when (m.JIRA_Status =10) then ',
'                                                            emano_util.fLang(''geschlossen'', ''closed'') ',
'                                                        when (m.JIRA_Status =20) then    ',
'                                                        emano_util.fLang(''ohne MfV beendet'', ''closed without notification'')  ',
'                                                        else ',
'                                                            emano_util.fLang(''offen'', ''open'') ',
'                                                        end as JIRA_STATUS,',
'       m.DMS_DOKUMENTENSTATUS as "DMS_DOKUMENTENSTATUS",',
'       m.LETZTE_AENDERUNG_DATUM,',
'       -- Removed GUELTIGKEITSDATUM as per requirements',
'       nvl2(m.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) AS "LETZTE_AENDERUNG_BENUTZER",',
'       PCK_RI.fJiraTicketsToLinks(m.JIRA_TICKET) AS "JIRA_TICKET"',
'from T_MFV m',
'join T_MFV_REF_VORSCHRIFT mrv on mrv.mfvid = m.mfvid',
'join t_mfv_ref_mfv_teil mrt on mrt.mfvid = m.mfvid',
'join t_mfv_teil t on t.mfv_teilid = mrt.mfv_teilid',
'left join teil on (teil.mfvid = m.mfvid)',
'left outer join T_BENUTZER b on b.BENUTZERID = m.LETZTE_AENDERUNG_BENUTZERID',
'left outer join ex  on (ex.mfvid = m.mfvid)',
'where  ( mrv.vorschriftid = :P41_VORSCHRIFTID ',
'       -- MfVs  aus konsolidierten Vorschriften  anzeigen',
'        OR mrv.vorschriftid in ( select vorgaenger_vorschriftid from t_vorschrift_ref_vorschrift where  nachfolger_vorschriftid = :P41_VORSCHRIFTID and beziehung_art = 200 )',
'       )',
'and t.teil in (1,3)  -- Filter for Information and Action Items',
'',
'-- and not exists (',
'--     -- Exclude if has Interpretation type',
'--     select 1 ',
'--     from t_mfv_ref_mfv_teil mrt2 ',
'--     join t_mfv_teil t2 on t2.mfv_teilid = mrt2.mfv_teilid',
'--     where mrt2.mfvid = m.mfvid ',
'--     and t2.teil = 2',
'-- )',
'',
'',
'and  ( ',
'    (  :P41_STATUS_OPTION = 100 and m.jira_status in (0, 10) )  -- alle MFV: show only geschlossen and offen',
'     or',
'    ( m.jira_status = 10 and :P41_STATUS_OPTION = 10 )  -- geschlossen',
'    or ',
'    ( m.jira_status = 20 and :P41_STATUS_OPTION = 20 )  -- ohne MFV beendet',
'    or ',
'    ( m.jira_status = 0 and :P41_STATUS_OPTION = 0  )   -- offen',
'    )'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P41_VORSCHRIFTID,P41_STATUS_OPTION'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'<div class="no-data-message">',
'    Keine MfVs-Informationen und Handlungsbedarf zugeordnet.',
'</div>'))
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993740803513220492)
,p_query_column_id=>1
,p_column_alias=>'INFORMATION_ROW_ID'
,p_column_display_sequence=>10
,p_column_link=>'f?p=&APP_ID.:85:&SESSION.::&DEBUG.:RP,85:P85_ROWID:#INFORMATION_ROW_ID#'
,p_column_linktext=>'<span class="fa fa-pencil" alt="Bearbeiten" title="Bearbeiten"  />'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993740408612220492)
,p_query_column_id=>2
,p_column_alias=>'ROW_KEY_2'
,p_column_display_sequence=>180
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993740012798220492)
,p_query_column_id=>3
,p_column_alias=>'LINK'
,p_column_display_sequence=>150
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P41_ROWID is not null',
'',
'and (',
unistr('    pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1200:1080'') > 0 -- Wenn Fachadmin/VKO/Redaktionsteam/Inaktive Funktionen, dann Bearbeitung immer m\00F6glich'),
'    or (pck_ri.fIsUserInRolle(listRolleId => ''1002'') > 0 and :P41_VORSCHRIFT_FREIGABESTATUSID in (10,30)))'))
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993739584621220491)
,p_query_column_id=>4
,p_column_alias=>'MFVID'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993739118229220491)
,p_query_column_id=>5
,p_column_alias=>'MFV_NAME'
,p_column_display_sequence=>40
,p_column_heading=>'MfV Name'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993738717355220491)
,p_query_column_id=>6
,p_column_alias=>'MFV_TEIL'
,p_column_display_sequence=>50
,p_column_heading=>'MfV Teil'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993738344514220490)
,p_query_column_id=>7
,p_column_alias=>'MFV_THEMA'
,p_column_display_sequence=>60
,p_column_heading=>'Thema der MfV'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993737933526220490)
,p_query_column_id=>8
,p_column_alias=>'SCHLAGWORTE'
,p_column_display_sequence=>70
,p_column_heading=>'Schlagworte'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993743921566220495)
,p_query_column_id=>9
,p_column_alias=>'VORSCHRIFTENVERANTWORTLICHER'
,p_column_display_sequence=>160
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993743584120220495)
,p_query_column_id=>10
,p_column_alias=>'ARBEITSKREIS_LISTE'
,p_column_display_sequence=>80
,p_column_heading=>'ET Arbeitskreise'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993743183699220495)
,p_query_column_id=>11
,p_column_alias=>'BETEILIGTE_OES'
,p_column_display_sequence=>90
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993742781457220494)
,p_query_column_id=>12
,p_column_alias=>'LINK_MFV_DMS'
,p_column_display_sequence=>100
,p_column_heading=>'Link zur Ablage DMS'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993742369403220494)
,p_query_column_id=>13
,p_column_alias=>'JIRA_STATUS'
,p_column_display_sequence=>110
,p_column_heading=>'Jira Status'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993741975503220493)
,p_query_column_id=>14
,p_column_alias=>'DMS_DOKUMENTENSTATUS'
,p_column_display_sequence=>120
,p_column_heading=>'MfV Dokumentenstatus'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(958148833580521269)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993741554158220493)
,p_query_column_id=>15
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>130
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993741187215220493)
,p_query_column_id=>16
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZER'
,p_column_display_sequence=>140
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993737564789220490)
,p_query_column_id=>17
,p_column_alias=>'JIRA_TICKET'
,p_column_display_sequence=>170
,p_column_heading=>'Jira Ticket'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(4809358265795035942)
,p_name=>'MfV -  Interpretation'
,p_region_name=>'p41_mfv_report_interpretation'
,p_parent_plug_id=>wwv_flow_imp.id(12202881112625828884)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:margin-top-sm'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ex as (  select i.mfvid as mfvid, ',
'    listagg(a.kurz,'', '') within group (order by a.kurz) as ak_liste',
'    from t_mfv_ref_et_b_ak i',
'    join t_et_b_ak a on (i.et_b_akid = a.et_b_akid) group by i.mfvid',
' ),',
'teil as ( select listagg( t.teil || ''. ''||t.bezeichnung, '', '') within group (order by t.teil || ''. ''||t.bezeichnung) as teil_bez_list,',
'                                 mrt.mfvid mfvid',
'                from t_mfv_ref_mfv_teil mrt',
'                join t_mfv_teil t on (t.mfv_teilID = mrt.mfv_teilid)',
'                 group by mrt.mfvid',
' ) ',
'  ',
'select mrv.rowid as Interpretation_row_id, ',
' m.MFVID as row_key_1,  ',
'       case when ( ',
'          --(:P41_EDIT_MODE is not null and :P41_EDIT_MODE = 1 ) ',
'                      m.DMS_DOKUMENTENSTATUS != 30  ',
'                   and nvl(m.GUELTIGKEITSDATUM, sysdate) < sysdate ) ',
'              then',
unistr('                    ''<span style="cursor:pointer;" text-align:center;" class="setzegueltigkeit fa fa-check" data-id="'' || m.mfvid || ''"><small><br>'' || emano_util.fLang(''G\00FCltigkeit'', ''Validity'') || ''<br>'' || emano_util.fLang(''best\00E4tigen'', ''confirm'') ')
||'|| ''<small></span>'' ',
'                else',
'                    ''#'' end as link,',
'       m.MFVID,',
'       m.mfv_name,',
'       teil.teil_bez_list AS "MFV_TEIL",',
'       case when length(m.mfv_thema ) > 64 then substr(m.mfv_thema,0,64)||''...'' else m.mfv_thema  end as mfv_thema,',
'       SCHLAGWORTE,',
'       VORSCHRIFTENVERANTWORTLICHER AS "VORSCHRIFTENVERANTWORTLICHER",',
'       ex.ak_liste  as Arbeitskreis_liste,',
'       BETEILIGTE_OES,',
'       PCK_RI.fCreateLinkIfUrl("LINK_MFV_DMS") AS "LINK_MFV_DMS",',
'       case when (m.JIRA_Status is null or m.JIRA_Status=0) then ',
'                                                            emano_util.fLang(''offen'', ''open'') ',
'                                                        when (m.JIRA_Status =10) then ',
'                                                            emano_util.fLang(''geschlossen'', ''closed'') ',
'                                                        when (m.JIRA_Status =20) then    ',
'                                                        emano_util.fLang(''ohne MfV beendet'', ''closed without notification'')  ',
'                                                        else ',
'                                                            emano_util.fLang(''offen'', ''open'') ',
'                                                        end as JIRA_STATUS,',
'       m.DMS_DOKUMENTENSTATUS as "DMS_DOKUMENTENSTATUS",',
'       m.LETZTE_AENDERUNG_DATUM,',
'       m.GUELTIGKEITSDATUM,  -- Keeping validity date for Interpretations',
'       nvl2(m.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) AS "LETZTE_AENDERUNG_BENUTZER",',
'       PCK_RI.fJiraTicketsToLinks(m.JIRA_TICKET) AS "JIRA_TICKET"',
'from T_MFV m',
'join T_MFV_REF_VORSCHRIFT mrv on mrv.mfvid = m.mfvid',
'join t_mfv_ref_mfv_teil mrt on mrt.mfvid = m.mfvid',
'join t_mfv_teil t on t.mfv_teilid = mrt.mfv_teilid',
'left join teil on (teil.mfvid = m.mfvid)',
'left outer join T_BENUTZER b on b.BENUTZERID = m.LETZTE_AENDERUNG_BENUTZERID',
'left outer join ex  on (ex.mfvid = m.mfvid)',
'where (mrv.vorschriftid = :P41_VORSCHRIFTID ',
'       -- MfVs  aus konsolidierten Vorschriften  anzeigen',
'            OR mrv.vorschriftid in ( select vorgaenger_vorschriftid from t_vorschrift_ref_vorschrift where  nachfolger_vorschriftid = :P41_VORSCHRIFTID and beziehung_art = 200 )',
'      )',
'and t.teil = 2  -- Filter for Interpretations only',
'-- and not exists (',
'--     -- Exclude if has other types',
'--     select 1 ',
'--     from t_mfv_ref_mfv_teil mrt2 ',
'--     join t_mfv_teil t2 on t2.mfv_teilid = mrt2.mfv_teilid',
'--     where mrt2.mfvid = m.mfvid ',
'--     and t2.teil != 2',
'-- )',
'',
'-- and  ( ',
'--     (  :P41_STATUS_OPTION = 100  )',
'--      or',
'--     ( m.jira_status= 10  and :P41_STATUS_OPTION = 10 )',
'--     or ',
'--     (m.jira_status = 20 AND :P41_STATUS_OPTION = 20)',
'--     or ',
'--     ( m.jira_status= 0  and :P41_STATUS_OPTION = 0  )',
'--     )',
'',
'and  ( ',
'    (  :P41_STATUS_OPTION = 100 and m.jira_status in (0, 10) )  -- alle MFV: show only geschlossen and offen',
'     or',
'    ( m.jira_status = 10 and :P41_STATUS_OPTION = 10 )  -- geschlossen',
'    or ',
'    ( m.jira_status = 20 and :P41_STATUS_OPTION = 20 )  -- ohne MFV beendet',
'    or ',
'    ( m.jira_status = 0 and :P41_STATUS_OPTION = 0  )   -- offen',
'    )'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P41_VORSCHRIFTID,P41_STATUS_OPTION'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="no-data-message">',
'    Keine MfVs-Interpretationen zugeordnet.',
'</div>'))
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993736895262220488)
,p_query_column_id=>1
,p_column_alias=>'INTERPRETATION_ROW_ID'
,p_column_display_sequence=>10
,p_column_link=>'f?p=&APP_ID.:85:&SESSION.::&DEBUG.:RP,85:P85_ROWID:#INTERPRETATION_ROW_ID#'
,p_column_linktext=>'<span class="fa fa-pencil" alt="Bearbeiten" title="Bearbeiten"  />'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'NEVER'
,p_report_column_required_role=>wwv_flow_imp.id(662353434878766250)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993736446357220488)
,p_query_column_id=>2
,p_column_alias=>'ROW_KEY_1'
,p_column_display_sequence=>190
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993736055538220487)
,p_query_column_id=>3
,p_column_alias=>'LINK'
,p_column_display_sequence=>160
,p_column_heading=>unistr('Best\00E4tige G\00FCltigkeit')
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P41_ROWID is not null',
'',
'and (',
unistr('    pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1200:1080'') > 0 -- Wenn Fachadmin/VKO/Redaktionsteam/Inaktive Funktionen, dann Bearbeitung immer m\00F6glich'),
'    or (pck_ri.fIsUserInRolle(listRolleId => ''1002'') > 0 and :P41_VORSCHRIFT_FREIGABESTATUSID in (10,30)))'))
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993735619916220487)
,p_query_column_id=>4
,p_column_alias=>'MFVID'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993735307470220487)
,p_query_column_id=>5
,p_column_alias=>'MFV_NAME'
,p_column_display_sequence=>40
,p_column_heading=>'MfV Name'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993734874149220486)
,p_query_column_id=>6
,p_column_alias=>'MFV_TEIL'
,p_column_display_sequence=>50
,p_column_heading=>'MfV Teil'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993734436742220486)
,p_query_column_id=>7
,p_column_alias=>'MFV_THEMA'
,p_column_display_sequence=>60
,p_column_heading=>'Thema der MfV'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993734065324220485)
,p_query_column_id=>8
,p_column_alias=>'SCHLAGWORTE'
,p_column_display_sequence=>70
,p_column_heading=>'Schlagworte'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993733618598220484)
,p_query_column_id=>9
,p_column_alias=>'VORSCHRIFTENVERANTWORTLICHER'
,p_column_display_sequence=>170
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993733300735220484)
,p_query_column_id=>10
,p_column_alias=>'ARBEITSKREIS_LISTE'
,p_column_display_sequence=>80
,p_column_heading=>'ET Arbeitskreise'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993732815982220483)
,p_query_column_id=>11
,p_column_alias=>'BETEILIGTE_OES'
,p_column_display_sequence=>90
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993732455900220483)
,p_query_column_id=>12
,p_column_alias=>'LINK_MFV_DMS'
,p_column_display_sequence=>100
,p_column_heading=>'Link zur Ablage DMS'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993732044660220483)
,p_query_column_id=>13
,p_column_alias=>'JIRA_STATUS'
,p_column_display_sequence=>110
,p_column_heading=>'Jira Status'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993731644566220482)
,p_query_column_id=>14
,p_column_alias=>'DMS_DOKUMENTENSTATUS'
,p_column_display_sequence=>120
,p_column_heading=>'MfV Dokumentenstatus'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(958148833580521269)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993731221644220482)
,p_query_column_id=>15
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>130
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993730902912220481)
,p_query_column_id=>16
,p_column_alias=>'GUELTIGKEITSDATUM'
,p_column_display_sequence=>150
,p_column_heading=>unistr('G\00FCltigkeitsdatum')
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993730470120220481)
,p_query_column_id=>17
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZER'
,p_column_display_sequence=>140
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993730109603220480)
,p_query_column_id=>18
,p_column_alias=>'JIRA_TICKET'
,p_column_display_sequence=>180
,p_column_heading=>'Jira Ticket'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12209198265507314708)
,p_plug_name=>'Einsatzdaten'
,p_region_name=>'rEinsatzdaten'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'( ( (:P41_ROWID is not null or :P41_VORSCHRIFTID is not null)',
'     --and :P41_VORSCHRIFT_TYPID <> 20 ',
'  ) ',
')'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4784807438928660216)
,p_plug_name=>'Alert T_LAND'
,p_parent_plug_id=>wwv_flow_imp.id(12209198265507314708)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:t-Alert--removeHeading:margin-bottom-sm'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'( pck_ri.fIsUserInRolle(listRolleId => ''1080'')>0)'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(4782336065985811050)
,p_name=>'T_LAND'
,p_parent_plug_id=>wwv_flow_imp.id(4784807438928660216)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    tv.vorschriftid,',
'    LISTAGG(tl.LANDID, '', '' ON OVERFLOW TRUNCATE) WITHIN GROUP (ORDER BY tl.LAND) AS LANDIDS,',
'    LISTAGG(tl.LAND, '', '' ON OVERFLOW TRUNCATE) WITHIN GROUP (ORDER BY tl.LAND) AS LAENDER,',
'    DBMS_LOB.SUBSTR(tl.BEDEUTUNG_EINSATZTERMIN, 4000, 1) AS BEDEUTUNG_EINSATZTERMIN,',
'    DBMS_LOB.SUBSTR(tl.BEMERKUNG_EINSATZTERMIN, 4000, 1) AS BEMERKUNG_EINSATZTERMIN',
'    -- CASE ',
'    --     WHEN DBMS_LOB.SUBSTR(tl.BEMERKUNG_EINSATZTERMIN, 4000, 1) IS NOT NULL THEN',
'    --         ''<a href="#" onclick="apex.navigation.redirect(''''f?p=&APP_ID.:12:&APP_SESSION.::NO::P12_VORSCHRIFTID:'''' || tv.vorschriftid);">'' ||',
'    --         ''<span class="fa fa-info-circle" aria-hidden="true"></span></a>''',
'    --     ELSE',
'    --         NULL',
'    -- END AS BEMERKUNG_EINSATZTERMIN',
'FROM ',
'    t_vorschrift tv',
'LEFT OUTER JOIN ',
'    t_vorschrift_ref_land tvrl ON (tv.vorschriftid = tvrl.vorschriftid)',
'LEFT OUTER JOIN ',
'    t_land tl ON (tvrl.landid = tl.landid)',
'LEFT JOIN ',
'    t_benutzer tb ON (tv.letzte_aenderung_benutzerid = tb.benutzerid)',
'WHERE ',
'    tv.vorschriftid = :P41_VORSCHRIFTID AND tvrl.geloescht != 1',
'GROUP BY ',
'    tv.vorschriftid,',
'    DBMS_LOB.SUBSTR(tl.BEDEUTUNG_EINSATZTERMIN, 4000, 1),',
'    DBMS_LOB.SUBSTR(tl.BEMERKUNG_EINSATZTERMIN, 4000, 1)',
'ORDER BY ',
'    DBMS_LOB.SUBSTR(tl.BEDEUTUNG_EINSATZTERMIN, 4000, 1),',
'    DBMS_LOB.SUBSTR(tl.BEMERKUNG_EINSATZTERMIN, 4000, 1)'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P41_VORSCHRIFTID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>unistr('Noch keine L\00E4nder zugeordnet.')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- sql ',
'',
'  select',
'      tv.vorschriftid,',
'      tl.LANDID,',
'      ',
'      tl.LAND,',
'      tl.BEDEUTUNG_EINSATZTERMIN,',
'      tl.BEMERKUNG_EINSATZTERMIN',
'',
'  from t_vorschrift tv',
'  left outer join t_vorschrift_ref_land tvrl on (tv.vorschriftid = tvrl.vorschriftid)',
'  left outer join t_land tl on (tvrl.landid = tl.landid)',
'  left join t_benutzer tb on (tv.letzte_aenderung_benutzerid = tb.benutzerid)',
'  where tv.vorschriftid = :P25_VORSCHRIFTID;;',
'',
'',
'-- rows retuned ',
'',
'--server side    ',
'',
'',
' select landid from (select',
'      count(tl.landid) landid ,tv.vorschriftid',
'  from t_vorschrift tv',
'  left outer join t_vorschrift_ref_land tvrl on (tv.vorschriftid = tvrl.vorschriftid)',
'  left outer join t_land tl on (tvrl.landid = tl.landid)',
'  left join t_benutzer tb on (tv.letzte_aenderung_benutzerid = tb.benutzerid)',
'  where tv.vorschriftid = :P25_VORSCHRIFTID',
'  group by tv.vorschriftid',
'  having count(*)>1)',
'',
'  ',
'',
'  --- udpated querey ',
'',
'  SELECT ',
'    tv.vorschriftid,',
'    LISTAGG(tl.LANDID, '', '' ON OVERFLOW TRUNCATE) WITHIN GROUP (ORDER BY tl.LAND) AS LANDIDS,',
'    LISTAGG(tl.LAND, '', '' ON OVERFLOW TRUNCATE) WITHIN GROUP (ORDER BY tl.LAND) AS LAENDER,',
'    DBMS_LOB.SUBSTR(tl.BEDEUTUNG_EINSATZTERMIN, 4000, 1) AS BEDEUTUNG_EINSATZTERMIN,',
'    DBMS_LOB.SUBSTR(tl.BEMERKUNG_EINSATZTERMIN, 4000, 1) AS BEMERKUNG_EINSATZTERMIN',
'FROM ',
'    t_vorschrift tv',
'LEFT OUTER JOIN ',
'    t_vorschrift_ref_land tvrl ON (tv.vorschriftid = tvrl.vorschriftid)',
'LEFT OUTER JOIN ',
'    t_land tl ON (tvrl.landid = tl.landid)',
'LEFT JOIN ',
'    t_benutzer tb ON (tv.letzte_aenderung_benutzerid = tb.benutzerid)',
'WHERE ',
'    tv.vorschriftid = :P25_VORSCHRIFTID',
'GROUP BY ',
'    tv.vorschriftid,',
'    DBMS_LOB.SUBSTR(tl.BEDEUTUNG_EINSATZTERMIN, 4000, 1),',
'    DBMS_LOB.SUBSTR(tl.BEMERKUNG_EINSATZTERMIN, 4000, 1)',
'-- ORDER BY ',
'--     DBMS_LOB.SUBSTR(tl.BEDEUTUNG_EINSATZTERMIN, 4000, 1),',
'--     DBMS_LOB.SUBSTR(tl.BEMERKUNG_EINSATZTERMIN, 4000, 1)',
'',
'',
'-- server P25_VORSCHRIFT_STATUSID',
'',
' select landid from (select',
'      count(tl.landid) landid ,tv.vorschriftid',
'  from t_vorschrift tv',
'  left outer join t_vorschrift_ref_land tvrl on (tv.vorschriftid = tvrl.vorschriftid)',
'  left outer join t_land tl on (tvrl.landid = tl.landid)',
'  left join t_benutzer tb on (tv.letzte_aenderung_benutzerid = tb.benutzerid)',
'  where tv.vorschriftid = :P25_VORSCHRIFTID',
'  group by tv.vorschriftid',
'  having count(*)>1)',
'',
'  '))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993727994330220477)
,p_query_column_id=>1
,p_column_alias=>'VORSCHRIFTID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993727516401220477)
,p_query_column_id=>2
,p_column_alias=>'LANDIDS'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993727185875220477)
,p_query_column_id=>3
,p_column_alias=>'LAENDER'
,p_column_display_sequence=>30
,p_column_heading=>unistr('L\00E4nder')
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select landid from (select',
'      count(tl.landid) landid ,tv.vorschriftid',
'  from t_vorschrift tv',
'  left outer join t_vorschrift_ref_land tvrl on (tv.vorschriftid = tvrl.vorschriftid)',
'  left outer join t_land tl on (tvrl.landid = tl.landid)',
'  left join t_benutzer tb on (tv.letzte_aenderung_benutzerid = tb.benutzerid)',
'  where tv.vorschriftid = :P41_VORSCHRIFTID AND tvrl.geloescht != 1',
'  group by tv.vorschriftid',
'  having count(*)>1)'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993726746928220477)
,p_query_column_id=>4
,p_column_alias=>'BEDEUTUNG_EINSATZTERMIN'
,p_column_display_sequence=>40
,p_column_heading=>unistr('Bedeutung Erf\00FCllungszeitpunkt')
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993726360359220477)
,p_query_column_id=>5
,p_column_alias=>'BEMERKUNG_EINSATZTERMIN'
,p_column_display_sequence=>60
,p_column_heading=>unistr('<span onclick="redirect(841)" style="font-size:2em; vertical-align:middle;" class="fa fa-info-square-o"  title="Informationen zum Erf\00FCllungszeitpunkt" ></span> &nbsp; Bemerkung Erf\00FCllungszeitpunkt')
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_column_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<span class="fa fa-info-circle" aria-hidden="true" title="Bemerkung Erf\00FCllungszeitpunkt" alt="Bemerkung Erf\00FCllungszeitpunkt"></span>'),
'',
'',
'LINK',
'',
'PAGE 12',
'',
'',
'P12_VORSCHRIFTID    #VORSCHRIFTID#',
'P12_BEMERKUNG_EINSATZTERMIN #BEMERKUNG_EINSATZTERMIN#'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8504911947226012642)
,p_plug_name=>'Hinweis'
,p_parent_plug_id=>wwv_flow_imp.id(12209198265507314708)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:t-Alert--removeHeading:margin-bottom-sm'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as(',
unistr('    Select emano_util.fLang(''Achtung,  f\00FCr neue typen darf diese Vorschrift nicht mehr verwendet werden'','),
'                          ''Attention, this regulation must not be used for new types'')',
'    as hinweis',
'     from  T_VORSCHRIFT_REF_EINSATZDATUM_TYP vre',
'   join T_vorschrift_ref_vorschrift vrv on (vrv.nachfolger_vorschriftid = vre.vorschriftid)',
'  where vrv.beziehung_art in (10) and vrv.vorgaenger_vorschriftid = :P41_VORSCHRIFTID',
'  and vre.einsatzdatum_typid in (1010, 1020) and vre.einsatzdatum < sysdate',
')',
'select ''<span style="color:red">'' || hinweis ||''</span>'' a --, hinweis b',
'from  cte1',
'  fetch first 1 rows only'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12209198452279314709)
,p_plug_name=>'GRID_EINSATZDATEN'
,p_region_name=>'ig_einsatzdaten'
,p_parent_plug_id=>wwv_flow_imp.id(12209198265507314708)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select edt.EINSATZDATUM_TYP,',
'  vredt.VORSCHRIFT_REF_EINSATZDATUM_TYPID,',
'  :P41_VORSCHRIFTID as vorschriftid,',
'  edt.EINSATZDATUM_TYPID,',
'  nvl(to_char(to_date(vredt.einsatzdatum,''dd.mm.yy''), ''dd.mm.yyyy''), null) einsatzdatum,',
'  case when (:P41_DATUM_ANGABE_AS_MJ = 1 and edt.EINSATZDATUM_TYPID in ( 1041,1030,1031)) ',
'      then nvl2(vredt.Modeljahr, to_char(to_date(vredt.Modeljahr,''dd.mm.yy''), ''YYYY''), null)',
'      else null end Modeljahr,',
'  vredt.einsatzdatum_text,',
'  vredt.einsatzdatum_text_englisch,',
'  vredt.letzte_aenderung_datum,',
'--   nvl2(vredt.letzte_aenderung_benutzerid, b.Nachname || '', '' || b.vorname, null) as LETZTE_AENDERUNG_BENUTZER,',
'nvl2(vredt.letzte_aenderung_benutzerid,',
'    CASE ',
'        WHEN b.nachname IS NOT NULL AND b.vorname IS NOT NULL ',
'            THEN b.nachname || '', '' || b.vorname',
'        WHEN b.nachname IS NOT NULL AND b.vorname IS NULL ',
'            THEN b.nachname',
'        WHEN b.nachname IS NULL AND b.vorname IS NOT NULL ',
'            THEN b.vorname',
'        ELSE NULL ',
'    END,',
'    null) as LETZTE_AENDERUNG_BENUTZER,',
'',
'  MANUELLE_EINTRAGUNG, edt.SORTORDER as SORTORDER',
'',
'--   fk.BEZEICHNUNG as FAHRZEUGKLASSE,',
'--   vredt.FAHRZEUGKLASSEID',
'from T_EINSATZDATUM_TYP edt',
'left outer join T_VORSCHRIFT_REF_EINSATZDATUM_TYP vredt on (vredt.einsatzdatum_typid = edt.einsatzdatum_typid',
'                                                              AND ',
'                                                              (vredt.vorschriftid is null ',
'                                                                   OR vredt.vorschriftid = :P41_VORSCHRIFTID)',
'                                                           )',
'left outer join T_BENUTZER b on b.benutzerid = vredt.letzte_aenderung_benutzerid',
'-- left outer join T_FAHRZEUGKLASSE fk on fk.FAHRZEUGKLASSEID = vredt.FAHRZEUGKLASSEID',
'-- left outer join t_vorschrift_ref_fahrzeugklasse tvrf on  fk.fahrzeugklasseid = tvrf.fahrzeugklasseid',
'where  ( ',
unistr('    -- regul\00E4re datumsangaben'),
'    edt.einsatzdatum_typid = 1000 -- in kraft immer anzeigen',
'    or (edt.einsatzdatum_typid in (1060,1063,1020,1021,1022,1023) and :P41_EINSATZDATUM_MODELLID = 20) -- ckd/fbu',
unistr('    or (edt.einsatzdatum_typid = 1041 and :P41_EINSATZDATUM_MODELLID in (10,30)) -- au\00DFer kraft'),
'    or (edt.einsatzdatum_typid = 1030 and :P41_EINSATZDATUM_MODELLID = 30) -- Einsatzzeitpunkt',
'    or (edt.einsatzdatum_typid in (1010,1011) and :P41_EINSATZDATUM_MODELLID = 10)',
')',
'-- mit rolle inaktive Funktionen alle anzeigen',
'or (pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0',
'    and edt.einsatzdatum_typid in (1010, 1011, 1020, 1021, 1022, 1023, 1030)',
')'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P41_VORSCHRIFTID,P41_DATUM_ANGABE_AS_MJ,P41_EINSATZDATUM_MODELLID,P41_FAHRZEUGKLASSE_NAME'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'(',
'  (  pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'                            pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1080'') > 0) -- Rolle VKO, Fachadm',
') = false',
''))
,p_plug_read_only_when2=>'PLSQL'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Old where clause',
'where (',
'        (edt.einsatzdatum_modellid is null and  :P25_EINSATZDATUM_MODELLID != 20)',
'       OR (:P25_VORSCHRIFT_TYPID IN (10, 30, 40) AND edt.einsatzdatum_modellid = :P25_EINSATZDATUM_MODELLID)',
'       or (:P25_EINSATZDATUM_MODELLID = 20 and edt.EINSATZDATUM_TYPID = 1000)',
'      )',
'and edt.einsatzdatum_typid in (1000,1041,1063,1060)',
'*/',
'',
'-- where (edt.EINSATZDATUM_TYPID in (1000, 1041)',
'',
'',
'-- where (',
'--         (edt.einsatzdatum_modellid is null and  :P25_EINSATZDATUM_MODELLID != 20)',
'--        OR (:P25_VORSCHRIFT_TYPID IN (10, 30, 40) AND edt.einsatzdatum_modellid = :P25_EINSATZDATUM_MODELLID)',
'--        or (:P25_EINSATZDATUM_MODELLID = 20 and edt.EINSATZDATUM_TYPID = 1000)',
'--       OR ((pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0)  and edt.einsatzdatum_modellid = :P25_EINSATZDATUM_MODELLID) ---11/dec./2024 chnaegd by 2000 User',
'-- )',
'-- and edt.einsatzdatum_typid in (1000,1041,1063,1060)',
'',
'',
'',
'-- where ( ',
'--     edt.EINSATZDATUM_TYPID in (1000, 1041)',
'--        OR ((pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0)  and edt.einsatzdatum_modellid = :P25_EINSATZDATUM_MODELLID)  working alse noddied 11 12 2024 13:18 pm',
'--        )',
'',
'',
'',
''))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(4851089992404292510)
,p_name=>'Edit'
,p_source_type=>'NONE'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_LINK'
,p_heading=>'&nbsp;'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>10
,p_value_alignment=>'CENTER'
,p_link_target=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:37:P37_VORSCHRIFTID,P37_EINSATZDATUM_MODELLID,P37_EINSATZDATUM_TYPID,P37_DATUM_ANGABE_AS_MJ:&P25_VORSCHRIFTID.,&P25_EINSATZDATUM_MODELLID.,&EINSATZDATUM_TYPID.,&P25_DATUM_ANGABE_AS_MJ.'
,p_link_text=>'<span class="fa fa-pencil" alt="Bearbeiten" title="Bearbeiten"></span>'
,p_link_attributes=>' class="t-Button t-Button--icon t-Button--small"'
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- FOR EINSATZDATEN EDIT BUTTONS',
'-- (:P41_STRG_GETEX_ANZEIGE != 20)  -- Not in GETEX display mode',
'-- AND ',
':P41_ROWID IS NOT NULL  -- Record must exist',
'AND (',
'    -- Section 1: Basic editing (Status -1 OR 1)',
'    -- Only Fachadmin and VKO for status -1 and 1',
unistr('    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (-1, 1)  -- -1=Neue Vorschrift aus GETEX, 1=Grundbef\00FCllung'),
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0 ) -- 1003=Fachadmin, 1000=VKO',
'    --  AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
'    OR',
'    -- Section 2: GETEX scenarios (Status 10,20,30)',
'    -- Fachadmin, VKO, and VEX for status 10,20,30',
'    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (10, 20, 30)  -- 10=in Bearbeitung, 20=Freigegeben, 30=nicht relevant',
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0  )-- 1003=Fachadmin, 1000=VKO, 1002=VEX',
'    --  AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
')'))
,p_display_condition2=>'PLSQL'
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8489515823031922442)
,p_name=>'MANUELLE_EINTRAGUNG'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MANUELLE_EINTRAGUNG'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'10'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8573723732424798971)
,p_name=>'SORTORDER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SORTORDER'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>120
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8591019468554959857)
,p_name=>'EINSATZDATUM_TEXT_ENGLISCH'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EINSATZDATUM_TEXT_ENGLISCH'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Einsatzdatum Text Englisch'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9196281063651431467)
,p_name=>'MODELJAHR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MODELJAHR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Modelljahr'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_format_mask=>'YYYY'
,p_item_width=>4
,p_is_required=>false
,p_max_length=>4
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>true
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P41_EINSATZDATUM_MODELLID'
,p_display_condition2=>'30'
,p_column_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'begin',
'',
'-- Nur bearbeitbar wenn',
'if (:EINSATZDATUM_TYPID = (1030) -- Einsatzzeitpunkt',
'    and nvl(:P25_STRG_GETEX_ANZEIGE,10) = 10 -- Master RegIndex',
'    and nvl(:P25_EDIT_MODE,0) = 1  -- Edit Modus',
'    and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0 -- Rechte',
'    and nvl(:P25_DATUM_ANGABE_AS_MJ,0) = 1) then -- Modelljahresschalter',
'',
'    return false;',
'',
'    else',
'',
'    return true;',
'end if;',
'',
'',
'end;',
'',
'',
'FUN BODY FOR EAHC ROW RAEAD ONLY - 14.05.2025, 13:37PM '))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12209198813326314713)
,p_name=>'EINSATZDATUM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EINSATZDATUM'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER'
,p_heading=>'Datum'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
,p_format_mask=>'dd.mm.yyyy'
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_static_id=>'ig_einsatzdaten_datum'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_column_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'FUN BODY FOR EAHC ROW RAEAD ONLY - 14.05.2025, 13:37PM ',
'',
'',
'',
'',
'begin',
'',
'    -- Wenn Editmodus, Rolle VKO und eins der Datum-Ausser-Kraft-Angaben => dann bearbeitbar',
'    if (nvl(:P25_EDIT_MODE,0) = 1 and pck_ri.fIsUserInRolle(listRolleId => ''1000'') > 0 and :EINSATZDATUM_TYPID in (1041,1060,1063)) then',
'        return false;',
'    end if;',
'',
'    -- First check if edit mode is on and user has role 1080 (inaktive Funktionen)',
'    if ((nvl(:P25_EDIT_MODE,0) = 0) or pck_ri.fIsUserInRolle(listRolleId => ''1080'') = 0) then',
'        -- If edit mode is off OR user doesn''t have role 1080, then read only',
'        return true;',
'    end if;',
'',
'    -- If MJ switch is off, everything is editable',
'    if nvl(:P25_DATUM_ANGABE_AS_MJ,0) = 0 then',
'        return false;',
'    -- If MJ switch is on and it''s deployment date type, make read-only',
'    elsif nvl(:P25_DATUM_ANGABE_AS_MJ,0) = 1 and :EINSATZDATUM_TYPID = 1030 then',
'        return true;',
'    -- If MJ switch is on but not deployment date type, keep editable',
'    elsif nvl(:P25_DATUM_ANGABE_AS_MJ,0) = 1 and :EINSATZDATUM_TYPID != 1030 then',
'        return false;',
'    else',
unistr('        debug(''Ung\00FCltiger Else - Zweig!'');'),
'        raise CASE_NOT_FOUND;',
'    end if;',
'end;'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12209198858976314714)
,p_name=>'EINSATZDATUM_TEXT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EINSATZDATUM_TEXT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Bemerkung Datum'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_column_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'FUN BODY FOR EAHC ROW RAEAD ONLY - 14.05.2025, 13:37PM ',
'',
'',
'declare',
'begin',
'',
'    if (nvl(:P25_EDIT_MODE,0) = 1 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0) then',
'        return false;',
'    else',
'        return true;',
'    end if;',
'',
'end;'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12209199048047314715)
,p_name=>'LETZTE_AENDERUNG_DATUM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LETZTE_AENDERUNG_DATUM'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('Letzte \00C4nderung Datum')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_format_mask=>'DD.MM.YYYY HH24:Mi'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12209199067050314716)
,p_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LETZTE_AENDERUNG_BENUTZER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>3202
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12209199630013314721)
,p_name=>'EINSATZDATUM_TYP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EINSATZDATUM_TYP'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Einsatzdatum'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>true
,p_max_length=>160
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12209199665442314722)
,p_name=>'VORSCHRIFT_REF_EINSATZDATUM_TYPID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFT_REF_EINSATZDATUM_TYPID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12209199845032314723)
,p_name=>'EINSATZDATUM_TYPID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EINSATZDATUM_TYPID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>90
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12209476880529824689)
,p_name=>'VORSCHRIFTID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFTID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>100
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(12209198537081314710)
,p_internal_uid=>15881410852980702945
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>false
,p_no_data_found_message=>'Es wurden noch keine Einsatzdaten zugeordnet.'
,p_show_toolbar=>false
,p_toolbar_buttons=>null
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>true
,p_fixed_header=>'NONE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(12209295160058010777)
,p_interactive_grid_id=>wwv_flow_imp.id(12209198537081314710)
,p_static_id=>'1577401'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(12209295320796010777)
,p_report_id=>wwv_flow_imp.id(12209295160058010777)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(4851095930229312394)
,p_view_id=>wwv_flow_imp.id(12209295320796010777)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(4851089992404292510)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>53
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(8489521798232935646)
,p_view_id=>wwv_flow_imp.id(12209295320796010777)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(8489515823031922442)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(8579938114771006501)
,p_view_id=>wwv_flow_imp.id(12209295320796010777)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(8573723732424798971)
,p_is_visible=>true
,p_is_frozen=>false
,p_sort_order=>1
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(8598948682344726132)
,p_view_id=>wwv_flow_imp.id(12209295320796010777)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(8591019468554959857)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(9201251602740325244)
,p_view_id=>wwv_flow_imp.id(12209295320796010777)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(9196281063651431467)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12209296819448010783)
,p_view_id=>wwv_flow_imp.id(12209295320796010777)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(12209198813326314713)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12209297288848010784)
,p_view_id=>wwv_flow_imp.id(12209295320796010777)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(12209198858976314714)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12209297823796010786)
,p_view_id=>wwv_flow_imp.id(12209295320796010777)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(12209199048047314715)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12209298329569010787)
,p_view_id=>wwv_flow_imp.id(12209295320796010777)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(12209199067050314716)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12209352713131495365)
,p_view_id=>wwv_flow_imp.id(12209295320796010777)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(12209199630013314721)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12209428237680960552)
,p_view_id=>wwv_flow_imp.id(12209295320796010777)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(12209199665442314722)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12209457900431239918)
,p_view_id=>wwv_flow_imp.id(12209295320796010777)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(12209199845032314723)
,p_is_visible=>true
,p_is_frozen=>false
,p_sort_order=>1
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(12209484864914861232)
,p_view_id=>wwv_flow_imp.id(12209295320796010777)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(12209476880529824689)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12209478358027824704)
,p_plug_name=>'UN-R Supplements'
,p_region_name=>'rSupplements'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'((:P41_ROWID is not null or :P41_Vorschriftid is not null)',
'  and :P41_VORSCHRIFT_TYPID <> 20)'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(12209478632577824706)
,p_name=>'REPORT_SUPPLEMENTS'
,p_parent_plug_id=>wwv_flow_imp.id(12209478358027824704)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vrv.rowid,',
'    vv.vorschrift_nummer || '' - '' || vv.vorschrift_bezeichnung as vorgaenger_vorschrift,',
'    nv.vorschrift_nummer || '' - '' || nv.vorschrift_bezeichnung as nachfolger_vorschrift,',
'    vrv.beziehung_art,',
'    (select vret.einsatzdatum',
'        from t_vorschrift_ref_einsatzdatum_typ  vret',
'        where (nv.vorschriftid = vret.vorschriftid)',
'        and vret.einsatzdatum_typid = 1000) as DATUM_IN_KRAFT,',
'    vrv.kommentar,',
'    vrv.letzte_aenderung_datum,',
'    b.nachname || '', '' || b.vorname,',
'    nv.rowid as sup_rowid,',
'    nv.vorschriftid as sup_vorschriftid,',
'    nvl(vorgaenger_vorschriftid,vrv.nachfolger_vorschriftid) as vorgaenger_vorschriftid,',
'    vrv.nachfolger_vorschriftid,',
'    (select listagg(mfv.mfv_name, '', '')',
'        from t_mfv_ref_vorschrift mrv ',
'        left outer join t_mfv mfv on mfv.mfvid = mrv.mfvid',
'        where mrv.vorschriftid = nv.vorschriftid) as MFV',
'from t_vorschrift_ref_vorschrift vrv',
'left outer join t_benutzer b on b.benutzerid = vrv.letzte_aenderung_benutzerid',
'join t_vorschrift vv on vv.vorschriftid = vrv.vorgaenger_vorschriftid and (vrv.BEZIEHUNG_ART IN ( 30))-- Beziehung Suplemtnt/Amendment',
'join t_vorschrift nv on nv.vorschriftid = vrv.nachfolger_vorschriftid and (vrv.BEZIEHUNG_ART IN ( 30))-- Beziehung Suplemtnt/Amendment',
'--left outer join t_mfv_ref_vorschrift mrv on mrv.vorschriftid = :P41_VORSCHRIFTID',
'--left outer join t_mfv mfv on mfv.mfvid = mrv.mfvid',
'',
'where ((vrv.vorgaenger_vorschriftid = :P41_VORSCHRIFTID)--and nv.vorschrift_typid = 20) -- Supplement UN-R ',
'    or (vrv.nachfolger_vorschriftid = :P41_VORSCHRIFTID)) --and vv.vorschrift_typid = 20)) -- Supplement UN-R',
'    ',
'order by 1 ',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P41_VORSCHRIFTID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'Keine Supplements zugeordnet.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993717758373220447)
,p_query_column_id=>1
,p_column_alias=>'ROWID'
,p_column_display_sequence=>1
,p_column_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.::P31_VORSCHRIFTID:#SUP_VORSCHRIFTID#'
,p_column_linktext=>'<span class="fa fa-pencil" alt="Bearbeiten" title="Bearbeiten"  />'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'-- FOR UN-SUPPLEMENTS BUTTONS (UN-R documents only)',
'instr(UPPER(:P41_VORSCHRIFT_NUMMER), ''UN-R'') > 0  -- Only for UN-R documents',
'AND (:P41_STRG_GETEX_ANZEIGE != 20)  -- Not in GETEX display mode',
'AND :P41_ROWID IS NOT NULL  -- Record must exist',
'AND (',
'    -- Section 1: Basic editing (Status -1 OR 1)',
'    -- Only Fachadmin and VKO for status -1 and 1',
unistr('    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (-1, 1)  -- -1=Neue Vorschrift aus GETEX, 1=Grundbef\00FCllung'),
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0  -- 1003=Fachadmin, 1000=VKO',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
'    OR',
'    -- Section 2: GETEX scenarios (Status 10,20,30)',
'    -- Fachadmin, VKO, and VEX for status 10,20,30',
'    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (10, 20, 30)  -- 10=in Bearbeitung, 20=Freigegeben, 30=nicht relevant',
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0  -- 1003=Fachadmin, 1000=VKO, 1002=VEX',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
')'))
,p_display_when_condition2=>'PLSQL'
,p_report_column_required_role=>wwv_flow_imp.id(2652734963787598041)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993717410241220446)
,p_query_column_id=>2
,p_column_alias=>'VORGAENGER_VORSCHRIFT'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993716972094220446)
,p_query_column_id=>3
,p_column_alias=>'NACHFOLGER_VORSCHRIFT'
,p_column_display_sequence=>4
,p_column_heading=>'Supplement'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993716580772220446)
,p_query_column_id=>4
,p_column_alias=>'BEZIEHUNG_ART'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993716177547220446)
,p_query_column_id=>5
,p_column_alias=>'DATUM_IN_KRAFT'
,p_column_display_sequence=>6
,p_column_heading=>'In Kraftsetzung'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993715771250220446)
,p_query_column_id=>6
,p_column_alias=>'KOMMENTAR'
,p_column_display_sequence=>7
,p_column_heading=>'Kommentar'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993715370963220445)
,p_query_column_id=>7
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>9
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_column_format=>'DD.MM.YYYY HH24:Mi'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993714920625220445)
,p_query_column_id=>8
,p_column_alias=>'B.NACHNAME||'',''||B.VORNAME'
,p_column_display_sequence=>10
,p_column_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993714574364220445)
,p_query_column_id=>9
,p_column_alias=>'SUP_ROWID'
,p_column_display_sequence=>11
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993718167855220447)
,p_query_column_id=>10
,p_column_alias=>'SUP_VORSCHRIFTID'
,p_column_display_sequence=>41
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993714192211220445)
,p_query_column_id=>11
,p_column_alias=>'VORGAENGER_VORSCHRIFTID'
,p_column_display_sequence=>21
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993713794032220445)
,p_query_column_id=>11
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>2
,p_column_heading=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:RP,:P25_ROWID,P25_VORSCHRIFTID_PARENT:#SUP_ROWID#,#VORGAENGER_VORSCHRIFTID#'
,p_column_linktext=>unistr('<span class="fa fa-search" alt="Bearbeiten" title="\00D6ffnen"  />')
,p_column_link_attr=>'    target="_blank"'
,p_column_alignment=>'CENTER'
,p_report_column_required_role=>wwv_flow_imp.id(2746799753426360144)
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993713319530220444)
,p_query_column_id=>12
,p_column_alias=>'NACHFOLGER_VORSCHRIFTID'
,p_column_display_sequence=>31
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(993713015670220444)
,p_query_column_id=>13
,p_column_alias=>'MFV'
,p_column_display_sequence=>8
,p_column_heading=>'MfVs'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12209628832361971682)
,p_plug_name=>'Breadcrumb'
,p_region_name=>'vorschriftTabs'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>wwv_flow_imp.id(3414122116128820546)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_header=>'Vorschrift bearbeiten '
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'SESSION')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12210115467836033382)
,p_plug_name=>'&nbsp;'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="visibility:hidden"'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>150
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_source=>unistr('Die weiteren Daten k\00F6nnen nach der ersten Speicherung eingetragen werden.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993786334152220557)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(8988778703008303772)
,p_button_name=>'BTN_EDIT_LEAD_VKO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Bearbeiten'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:32:P32_VORSCHRIFTID,P32_VORSCHRIFT_TYPID:&P41_VORSCHRIFTID.,&P41_VORSCHRIFT_TYPID.'
,p_button_condition=>'RETURN pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0 AND :P41_VORSCHRIFT_TYPID IN (10,30,40);'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-edit'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993776539450220546)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8485846085285317681)
,p_button_name=>'ADD_LAND'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00E4nder zuordnen')
,p_button_position=>'COPY'
,p_button_redirect_url=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.:RP,103:P103_NEW_CREATE,P103_EDIT_LAENDER,P103_VORSCHRIFTID:1,1,&P41_VORSCHRIFTID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- FOR L\00C4NDER ADD/EDIT/DELETE BUTTONS'),
'(:P41_STRG_GETEX_ANZEIGE != 20)  -- Not in GETEX display mode',
'AND :P41_ROWID IS NOT NULL  -- Record must exist',
'AND (',
'    -- Section 1: Basic editing (Status -1 OR 1)',
'    -- Only Fachadmin and VKO for status -1 and 1',
unistr('    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (-1, 1)  -- -1=Neue Vorschrift aus GETEX, 1=Grundbef\00FCllung'),
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0  -- 1003=Fachadmin, 1000=VKO',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
'    OR',
'    -- Section 2: GETEX scenarios (Status 10,20,30)',
'    -- Fachadmin, VKO, and VEX for status 10,20,30',
'    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (10, 20, 30)  -- 10=in Bearbeitung, 20=Freigegeben, 30=nicht relevant',
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0  -- 1003=Fachadmin, 1000=VKO, 1002=VEX',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993799116107220573)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4795247179829439559)
,p_button_name=>'ADD_THEMA_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Themen zuordnen'
,p_button_position=>'COPY'
,p_button_redirect_url=>'f?p=&APP_ID.:104:&SESSION.::&DEBUG.:RP,104:P104_NEW_CREATE,P104_EDIT_THEMEN,P104_VORSCHRIFTID:1,1,&P41_VORSCHRIFTID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- FOR THEMEN ADD/EDIT/DELETE BUTTONS',
'(:P41_STRG_GETEX_ANZEIGE != 20)  -- Not in GETEX display mode',
'AND :P41_ROWID IS NOT NULL  -- Record must exist',
'AND (',
'    -- Section 1: Basic editing (Status -1 OR 1)',
'    -- Only Fachadmin and VKO for status -1 and 1',
unistr('    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (-1, 1)  -- -1=Neue Vorschrift aus GETEX, 1=Grundbef\00FCllung'),
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0  -- 1003=Fachadmin, 1000=VKO',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
'    OR',
'    -- Section 2: GETEX scenarios (Status 10,20,30)',
'    -- Fachadmin, VKO, and VEX for status 10,20,30',
'    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (10, 20, 30)  -- 10=in Bearbeitung, 20=Freigegeben, 30=nicht relevant',
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0  -- 1003=Fachadmin, 1000=VKO, 1002=VEX',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_button_comment=>'(:P25_STRG_GETEX_ANZEIGE != 20)'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993813311745220609)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4735611384750451042)
,p_button_name=>'DELETE_AMENDMENT'
,p_button_static_id=>'DELETE_AMENDMENT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Markierte Amendments l\00F6schen')
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- FOR AMENDMENTS BUTTONS (non-UN-R documents only)',
'',
'(:P41_STRG_GETEX_ANZEIGE != 20)  -- Not in GETEX display mode',
'AND :P41_ROWID IS NOT NULL  -- Record must exist',
'AND (',
'    -- Section 1: Basic editing (Status -1 OR 1)',
'    -- Only Fachadmin and VKO for status -1 and 1',
unistr('    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (-1, 1)  -- -1=Neue Vorschrift aus GETEX, 1=Grundbef\00FCllung'),
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0  -- 1003=Fachadmin, 1000=VKO',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
'    OR',
'    -- Section 2: GETEX scenarios (Status 10,20,30)',
'    -- Fachadmin, VKO, and VEX for status 10,20,30',
'    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (10, 20, 30)  -- 10=in Bearbeitung, 20=Freigegeben, 30=nicht relevant',
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0  -- 1003=Fachadmin, 1000=VKO, 1002=VEX',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_css_classes=>'apex_disabled'
,p_icon_css_classes=>'fa-trash-o'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993787044768220558)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8667574484668266049)
,p_button_name=>'EDIT_VERKNUEPFTE_DATEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Bearbeiten'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:225:&SESSION.::&DEBUG.:225:P225_VORSCHRIFTID:&P41_VORSCHRIFTID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 225, accessMode => 100) and :P41_ROWID is not null ',
'',
'and (',
unistr('    pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1200:1080'') > 0 -- Wenn Fachadmin/VKO/Redaktionsteam/Inaktive Funktionen, dann Bearbeitung immer m\00F6glich'),
'    or (pck_ri.fIsUserInRolle(listRolleId => ''1002'') > 0 and :P41_VORSCHRIFT_FREIGABESTATUSID in (10,30)))'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-pencil'
,p_button_comment=>'--and (:P25_EDIT_MODE = 1)'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993780805823220549)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9767890902596280476)
,p_button_name=>'BTN_FUKA_COPY_ASSIST'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Kopierassistent'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:470:&SESSION.::&DEBUG.:470,472,474:P470_ZIEL_VORSCHRIFTID:&P41_VORSCHRIFTID.'
,p_button_condition=>'pck_ri.fIsUserInRolle(listRolleId => ''1003:1002:1006'') > 0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(pck_ri.fIsAuthorized(pageId => 470, accessMode => 200)) ',
'',
'and :P25_ROWID is not null ',
'',
'and (',
unistr('    pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1200:1080'') > 0 -- Wenn Fachadmin/VKO/Redaktionsteam/Inaktive Funktionen, dann Bearbeitung immer m\00F6glich'),
'    or (pck_ri.fIsUserInRolle(listRolleId => ''1002'') > 0 and :P25_VORSCHRIFT_FREIGABESTATUSID in (10,30)))'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993754718764220529)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(12196866706953287320)
,p_button_name=>'DELETE_VERKNUEPFUNG'
,p_button_static_id=>'DELETE_VERKNUEPFUNG'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Markierte Verkn\00FCpfungen l\00F6schen')
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- FOR VERKN\00DCPFUNGEN'),
'(:P41_STRG_GETEX_ANZEIGE != 20)  -- Not in GETEX display mode',
'AND :P41_ROWID IS NOT NULL  -- Record must exist',
'AND (',
'    -- Section 1: Basic editing (Status -1 OR 1)',
'    -- Only Fachadmin and VKO for status -1 and 1',
unistr('    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (-1, 1)  -- -1=Neue Vorschrift aus GETEX, 1=Grundbef\00FCllung'),
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0  -- 1003=Fachadmin, 1000=VKO',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
'    OR',
'    -- Section 2: GETEX scenarios (Status 10,20,30)',
'    -- Fachadmin, VKO, and VEX for status 10,20,30',
'    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (10, 20, 30)  -- 10=in Bearbeitung, 20=Freigegeben, 30=nicht relevant',
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0  -- 1003=Fachadmin, 1000=VKO, 1002=VEX',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_css_classes=>'apex_disabled'
,p_icon_css_classes=>'fa-trash-o'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993745492876220497)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(12202881112625828884)
,p_button_name=>'ADD_MFV'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:85:&SESSION.::&DEBUG.:85:P85_VORSCHRIFTID,P85_CAME_FROM:&P41_VORSCHRIFTID.,25'
,p_icon_css_classes=>'fa-plus-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993718859429220448)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(12209478358027824704)
,p_button_name=>'CREATE_SUPPLEMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:31:P31_PARENT_VORSCHRIFTID,P31_VORSCHRIFT_TYPID:&P41_VORSCHRIFTID.,20'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'-- FOR UN-SUPPLEMENTS BUTTONS (UN-R documents only)',
'instr(UPPER(:P41_VORSCHRIFT_NUMMER), ''UN-R'') > 0  -- Only for UN-R documents',
'AND (:P41_STRG_GETEX_ANZEIGE != 20)  -- Not in GETEX display mode',
'AND :P41_ROWID IS NOT NULL  -- Record must exist',
'AND (',
'    -- Section 1: Basic editing (Status -1 OR 1)',
'    -- Only Fachadmin and VKO for status -1 and 1',
unistr('    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (-1, 1)  -- -1=Neue Vorschrift aus GETEX, 1=Grundbef\00FCllung'),
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0  -- 1003=Fachadmin, 1000=VKO',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
'    OR',
'    -- Section 2: GETEX scenarios (Status 10,20,30)',
'    -- Fachadmin, VKO, and VEX for status 10,20,30',
'    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (10, 20, 30)  -- 10=in Bearbeitung, 20=Freigegeben, 30=nicht relevant',
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0  -- 1003=Fachadmin, 1000=VKO, 1002=VEX',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-plus-circle-o'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993812906912220607)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4735611384750451042)
,p_button_name=>'CREATE_AMENDMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.:45:P45_VORGAENGER_VORSCHRIFTID,P45_BEZIEHUNG_ART,P45_AMENDMENTID,P45_MASTER:&P41_VORSCHRIFTID.,20,20,&P41_STRG_GETEX_ANZEIGE.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- FOR AMENDMENTS BUTTONS (non-UN-R documents only)',
'instr(UPPER(:P41_VORSCHRIFT_NUMMER), ''UN-R'') = 0  -- Only for non-UN-R documents',
'AND (:P41_STRG_GETEX_ANZEIGE != 20)  -- Not in GETEX display mode',
'AND :P41_ROWID IS NOT NULL  -- Record must exist',
'AND (',
'    -- Section 1: Basic editing (Status -1 OR 1)',
'    -- Only Fachadmin and VKO for status -1 and 1',
unistr('    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (-1, 1)  -- -1=Neue Vorschrift aus GETEX, 1=Grundbef\00FCllung'),
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0  -- 1003=Fachadmin, 1000=VKO',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
'    OR',
'    -- Section 2: GETEX scenarios (Status 10,20,30)',
'    -- Fachadmin, VKO, and VEX for status 10,20,30',
'    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (10, 20, 30)  -- 10=in Bearbeitung, 20=Freigegeben, 30=nicht relevant',
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0  -- 1003=Fachadmin, 1000=VKO, 1002=VEX',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-plus-circle-o'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993780376477220549)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(9767890902596280476)
,p_button_name=>'BTN_MANAGE_FUNKTIONEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Funktionen zuordnen'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:343:&SESSION.::&DEBUG.:RP,343:P343_CAME_FROM,P343_VORSCHRIFTID:25,&P41_VORSCHRIFTID.'
,p_button_condition=>'pck_ri.fIsUserInRolle(listRolleId => ''1003:1002:1006'') > 0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-pencil'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 343, accessMode => 200) and :P25_ROWID is not null ',
'',
'and (',
unistr('    pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1200:1080'') > 0 -- Wenn Fachadmin/VKO/Redaktionsteam/Inaktive Funktionen, dann Bearbeitung immer m\00F6glich'),
'    or (pck_ri.fIsUserInRolle(listRolleId => ''1002'') > 0 and :P25_VORSCHRIFT_FREIGABESTATUSID in (10,30)))'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993776209112220545)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(8485846085285317681)
,p_button_name=>'BTN_H_LAND'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('\00C4nderungshistorie Land')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:356:&SESSION.::&DEBUG.::P356_VORSCHRIFTID:&P41_VORSCHRIFTID.'
,p_button_condition=>'pck_ri.fIsAuthorized(pageId => 356, accessMode => 100)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-history'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993771194448220540)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_button_name=>'GETEX'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('\00C4nderungen zur Pr\00FCfung/\00DCbernahme')
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:29:P29_VORSCHRIFTID:&P41_VORSCHRIFTID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'    :P41_IMPORT_STATUS = 20',
'    and :P41_ROWID is not null',
'    and pck_ri.fIsUserInRolle(listRolleId => ''1003:1100:1200:1000'') > 0  -- 1003 = Fachadmin, 1100 =  Getex Migration ;   1200- Redaktionsteam 1000 -VKO',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_cattributes=>unistr('title="In Getex 2 wurden Daten ge\00E4ndert - mit dem Assistenten k\00F6nnen diese ge\00E4nderten Daten in RegIndex \00FCbernommen werden."')
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
':P25_IMPORT_STATUS = 20 and --:P25_MASTER in ( 20, 30) and',
':P25_ROWID is not null',
'and pck_ri.fIsUserInRolle(listRolleId => ''1100:1003:1000'') > 0  -- 1100 = Rolle Getex Migration, 1003 = Fach admmin, 1000 = VKO',
')'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993754408572220528)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(12196866706953287320)
,p_button_name=>'CREATE_VERKNUEPFUNG'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.:RP,45:P45_VORGAENGER_VORSCHRIFTID,P45_MASTER:&P41_VORSCHRIFTID.,&P41_STRG_GETEX_ANZEIGE.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- FOR VERKN\00DCPFUNGEN'),
'(:P41_STRG_GETEX_ANZEIGE != 20)  -- Not in GETEX display mode',
'AND :P41_ROWID IS NOT NULL  -- Record must exist',
'AND (',
'    -- Section 1: Basic editing (Status -1 OR 1)',
'    -- Only Fachadmin and VKO for status -1 and 1',
unistr('    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (-1, 1)  -- -1=Neue Vorschrift aus GETEX, 1=Grundbef\00FCllung'),
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0  -- 1003=Fachadmin, 1000=VKO',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
'    OR',
'    -- Section 2: GETEX scenarios (Status 10,20,30)',
'    -- Fachadmin, VKO, and VEX for status 10,20,30',
'    (:P41_VORSCHRIFT_FREIGABESTATUSID IN (10, 20, 30)  -- 10=in Bearbeitung, 20=Freigegeben, 30=nicht relevant',
'     AND pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0  -- 1003=Fachadmin, 1000=VKO, 1002=VEX',
'     AND :P41_MASTER NOT IN (20, 30))  -- 20=GETEX, 30=GETEX+automatische',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-plus-circle-o'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993745074837220497)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(12202881112625828884)
,p_button_name=>'BTN_H_MFV'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('\00C4nderungshistorie MfVs')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:353:&SESSION.::&DEBUG.::P353_VORSCHRIFTID:&P41_VORSCHRIFTID.'
,p_button_condition=>'pck_ri.fIsAuthorized(pageId => 353, accessMode => 100)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-history'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993728954401220479)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(12209198265507314708)
,p_button_name=>'BTN_H_EINSATZDATEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('\00C4nderungshistorie Einsatzdaten')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:351:&SESSION.::&DEBUG.::P351_VORSCHRIFTID:&P41_VORSCHRIFTID.'
,p_button_condition=>'pck_ri.fIsAuthorized(pageId => 351, accessMode => 100)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-history'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993812479632220607)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(4735611384750451042)
,p_button_name=>'BTN_H_AMENDMENTS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('\00C4nderungshistorie Amendments')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:352:&SESSION.::&DEBUG.::P352_VORSCHRIFTID,P352_AMENDMENTID:&P41_VORSCHRIFTID.,20'
,p_button_condition=>'pck_ri.fIsAuthorized(pageId => 352, accessMode => 100)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-history'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993799567999220573)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(4795247179829439559)
,p_button_name=>'BTN_H_THEMA_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('\00C4nderungshistorie Thema')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:357:&SESSION.::&DEBUG.::P357_VORSCHRIFTID:&P41_VORSCHRIFTID.'
,p_button_condition=>'pck_ri.fIsAuthorized(pageId => 357, accessMode => 100)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-history'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993753979572220528)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(12196866706953287320)
,p_button_name=>'BTN_H_VERKNUEPFUNGEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('\00C4nderungshistorie Einsatzdaten')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:352:&SESSION.::&DEBUG.::P352_VORSCHRIFTID:&P41_VORSCHRIFTID.'
,p_button_condition=>'pck_ri.fIsAuthorized(pageId => 352, accessMode => 100)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-history'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993770736378220540)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_button_name=>'BTN_CREATE_MESSAGE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Erstelle Benachrichtigung'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:617:&SESSION.::&DEBUG.:617:P617_VORSCHRIFTID:&P41_VORSCHRIFTID.'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P41_VORSCHRIFTID is not null and (PCK_RI.fIsAuthorized(pageId => 617,',
'                      accessMode => 100))'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993770344369220540)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_button_name=>'BTN_COPY_PERMALINK'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Permalink in Zwischenablage kopieren'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P41_VORSCHRIFTID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993769972234220540)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_button_name=>'JIRA_TICKET_ASSIST'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Jira Ticket Assistent'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:581:&SESSION.::&DEBUG.:570, 571, 572,573, 574,581:P572_VORSCHRIFTEN_SEL:&P41_VORSCHRIFTID.'
,p_button_condition=>':P41_VORSCHRIFT_FREIGABESTATUSID >1 and :P41_VORSCHRIFTID is not null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993769530526220539)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_button_name=>'BTN_KERNDATEN_BEARBEITEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Kerndaten bearbeiten'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:31:P31_VORSCHRIFTID,P31_ROWID:&P41_VORSCHRIFTID.,&P41_ROWID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'    :P41_ROWID IS NOT NULL ',
'    AND :P41_VORSCHRIFTID IS NOT NULL',
'    AND (',
'        -- Fachadmin (1003), VKO (1000) - Has L&B for all statuses',
'        (pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0)',
'        OR',
'        -- VEX (1002), PRI User (1001) - Has L&B only for "in Bearbeitung" and "nicht relevant"',
'        (pck_ri.fIsUserInRolle(listRolleId => ''1002'') > 0 ',
'         AND :P41_VORSCHRIFT_FREIGABESTATUSID IN (10, 20,30)) -- 10 = "in Bearbeitung", 30 = "nicht relevant"',
'    )',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-edit'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
':G_BENUTZERID = 15643',
'',
'',
'(',
'((:P25_ROWID is not null or :P25_Vorschriftid is not null) and (pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) ',
'                            or pck_ri.fIsUserInRolle(listRolleId => ''1002:1200'') > 0)) -- Rolle VEX, ZVEX',
')'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993769145765220539)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_button_name=>'BTN_H_COREDATA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('\00C4nderungshistorie Kerndaten')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:350:&SESSION.::&DEBUG.:RP,350:P350_VORSCHRIFTID:&P41_VORSCHRIFTID.'
,p_button_condition=>'pck_ri.fIsAuthorized(pageId => 350, accessMode => 100)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-history'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993712274061220444)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(12209628832361971682)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Zur\00FCck zur Vorschriftenliste')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:::'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993711832782220444)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(12209628832361971682)
,p_button_name=>'CHANGE_FREIGABE_STATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Freigabe Status \00E4ndern')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
':P41_ROWID is not null',
'and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0  -- Rolle VKO/Fachadmin',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993711431097220443)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(12209628832361971682)
,p_button_name=>'COPY'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Vorschrift kopieren'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:540:&SESSION.::&DEBUG.:540, 544, 541, 542, 545:P540_SOURCE_VORSCHRIFTID:&P41_VORSCHRIFTID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
':P41_ROWID is not null and pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-copy'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993711047310220443)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(12209628832361971682)
,p_button_name=>'LNK_NETZ'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Baumansicht'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa fa-network-hub'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993710652125220443)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(12209628832361971682)
,p_button_name=>'DELETE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'(pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0 and :P41_VORSCHRIFTID is not null)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-trash-o'
,p_database_action=>'DELETE'
,p_button_comment=>','
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(993710260303220443)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(12209628832361971682)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P41_ROWID is NULL and :P41_VORSCHRIFTID is null)',
'and ( pck_ri.fIsUserInRolle(listRolleId => ''1080'')>0 )'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(993664708401220406)
,p_branch_name=>'redirect to Freigabestatus Dialog'
,p_branch_action=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:28:P28_VORSCHRIFTID:&P41_VORSCHRIFTID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(993711832782220444)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(993663492319220405)
,p_branch_name=>'redirect to_parent- create'
,p_branch_action=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:41:P41_VORSCHRIFTID,P41_PROCESS_FROM:&P41_PARENT_VORSCHRIFTID.,1&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(993710260303220443)
,p_branch_sequence=>30
,p_branch_condition_type=>'ITEM_IS_NOT_NULL'
,p_branch_condition=>'P41_PROCESS_FROM'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(993664243614220406)
,p_branch_name=>unistr('Branch ung\00FCltige VorschriftID')
,p_branch_action=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
,p_branch_condition_type=>'NOT_EXISTS'
,p_branch_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from t_vorschrift vs',
'where (vs.vorschriftid = :P41_VORSCHRIFTID or (:P41_VORSCHRIFTID is null and :P41_ROWID is null))',
'and (',
'    ',
'       (vs.vorschrift_freigabestatusid = -1 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0) -- Wenn Status "Imported", dann VKO/Fachadmin',
unistr('    or (vs.vorschrift_freigabestatusid = 1 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0) -- Wenn Status "Grundbef\00FCllung", dann VKO/Fachadmin'),
unistr('    or (vs.vorschrift_freigabestatusid = 10 and pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002:1040:1006'') > 0) -- Wenn Status "in Bearbeitung" dann sichtbar f\00FCr Fachadmin, VKO, VEX, ZVEX, KFEX, GBEX'),
unistr('    or (vs.vorschrift_freigabestatusid = 20) -- Wenn Status "freigegeben", dann sichtbar f\00FCr alle'),
unistr('    or (vs.vorschrift_freigabestatusid = 30 and pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0) -- Wenn Status "nicht relevant", dann sichtbar f\00FCr Fachadmin, VKO, VEX, ZVEX'),
')'))
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(993663913938220406)
,p_branch_name=>'REDIRECT_AFTER_DELETE'
,p_branch_action=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:RP,20,25::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'REQUEST_EQUALS_CONDITION'
,p_branch_condition=>'DELETE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993800268816220575)
,p_name=>'P41_SELECTED_AMENDM_ROWS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4735611537074451043)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993798803411220573)
,p_name=>'P41_FAHRZEUGKLASSE_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4795247179829439559)
,p_prompt=>unistr('Einsatztermine f\00FCr Fahrzeugklasse Typ')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT f.BEZEICHNUNG as display_value, ',
'       f.FAHRZEUGKLASSEID  as return_value',
'    --    FAHRZEUGKLASSEID',
'',
'from t_vorschrift_ref_fahrzeugklasse v ',
'join t_fahrzeugklasse f ON f.fahrzeugklasseid = v.fahrzeugklasseid',
'where v.vorschriftid = :P41_VORSCHRIFTID'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Select  --'
,p_lov_cascade_parent_items=>'P41_VORSCHRIFT_ID'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993798355164220573)
,p_name=>'P41_DATUM_ANGABE_AS_MJ'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4795247179829439559)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Datumsformat Modelljahr ?'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mj_schalter_status from t_vorschrift ',
'where vorschriftid = :P41_vorschriftID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>'STATIC2:Ja;1,Nein;0'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P41_ROWID is not null',
'',
'and (',
unistr('    pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1200:1080'') > 0 -- Wenn Fachadmin/VKO/Redaktionsteam/Inaktive Funktionen, dann Bearbeitung immer m\00F6glich'),
'    or (pck_ri.fIsUserInRolle(listRolleId => ''1002'') > 0 and :P41_VORSCHRIFT_FREIGABESTATUSID in (10,30))) and :P41_EINSATZDATUM_MODELLID = 30'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'read only item ! = value edit mode  1 ',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993797989014220572)
,p_name=>'P41_PHASEIN_ENTHALTEN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(4795247179829439559)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Sind Phase in''s enthalten?'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'',
'case when ',
'',
'phasein_enthalten',
'',
' = 1 then ''Ja'' else ''Nein'' end',
'from t_vorschrift ',
'where vorschriftid = :P41_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>'STATIC2:Ja;1,Nein;0'
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P41_ROWID is not null',
'',
'and (',
unistr('    pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1200:1080'') > 0 -- Wenn Fachadmin/VKO/Redaktionsteam/Inaktive Funktionen, dann Bearbeitung immer m\00F6glich'),
'    or (pck_ri.fIsUserInRolle(listRolleId => ''1002'') > 0 and :P41_VORSCHRIFT_FREIGABESTATUSID in (10,30))) and :P41_EINSATZDATUM_MODELLID = 30'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993786010759220557)
,p_name=>'P41_LEAD_VKO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8988778703008303772)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Lead VKO'
,p_source=>'LEAD_VKO_BENUTZERID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b.Nachname ||'', ''||b.Vorname || '' (''||b.Abteilung || '')'' as d, b.benutzerid r ',
'from t_benutzer b',
'-- order by 1'))
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_display_when=>':P41_VORSCHRIFT_TYPID in (10,30,40)'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_protection_level=>'B'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993785516921220556)
,p_name=>'P41_LEAD_VKO_PARENT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(8988778703008303772)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Lead VKO'
,p_source=>'select lead_vko_benutzerid from t_vorschrift where vorschriftid = :P41_PARENT_VORSCHRIFTID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b.Nachname ||'', ''||b.Vorname || '' (''||b.Abteilung || '')'' as d, b.benutzerid r ',
'from t_benutzer b',
'-- order by 1'))
,p_display_when=>':P41_VORSCHRIFT_TYPID in (20)'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_protection_level=>'B'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993768800844220539)
,p_name=>'P41_IMPORT_STATUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_item_default=>'30'
,p_prompt=>'Getex Aktualisierung'
,p_source=>'select status_update_getex from t_vorschrift where vorschriftid = :P41_VORSCHRIFTID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_IMPORT_STATUS_GETZEX'
,p_lov=>'.'||wwv_flow_imp.id(799385323802234434)||'.'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Server-Side Condition for Visibility',
'-- Show for Fachadmin, ',
'-- Fachadmin, Getex Migration, VKO',
'pck_ri.fIsUserInRolle(listRolleId => ''1003:1100:1000'') > 0'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993768401625220538)
,p_name=>'P41_MASTER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_item_default=>'10'
,p_prompt=>unistr('Master f\00FCr diese Vorschrift')
,p_source=>'MASTER'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_T_VORSCHRIFT.MASTER'
,p_lov=>'.'||wwv_flow_imp.id(1019194795775238322)||'.'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--read only on 20.02.2024',
'',
'(',
'  (  --pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'                            pck_ri.fIsUserInRolle(listRolleId => ''1000:1002:1003'') > 0) -- Rolle VKO, VEX, ZVEX, Fachadm',
') = false',
'    or (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
'',
'',
'',
'--- server side ',
'',
'-- Server-Side Condition for Visibility',
'-- Show for Fachadmin, VKO, and GETEX-Migration',
'--pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1100'') > 0',
'',
'',
'',
'',
'-- read only on 21.02.2024',
'(',
'  (  --pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'                            pck_ri.fIsUserInRolle(listRolleId => ''1000:1002:1003:1100'') > 0) -- Rolle VKO, VEX, ZVEX, Fachadm',
') = false',
'    or (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
'',
'',
'',
'',
'---- server side 9 augu fridat 9:39 am ',
'',
'-- Server-Side Condition for Visibility',
'-- Show for Fachadmin only,',
'pck_ri.fIsUserInRolle(listRolleId => ''1002:1003:1200:1000:1100'') > 0',
'',
'',
'read only ',
'',
'',
'  (',
'  ( pck_ri.fIsUserInRolle(listRolleId => ''1003:1200'') > 0) -- Fachadmin, Redaktionsteam',
') = false',
'',
'    or (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
'    or (:P41_IMPORT_STATUS = 30 )  ',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993767986415220538)
,p_name=>'P41_FLAG_KONSOLIDIERTE_FASSUNGEN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>'Flag konsolidierte Fassung vorhanden'
,p_source=>'FLAG_KONSOLIDIERTE_FASSUNGEN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT emano_util.fLang(''Ja'', ''Yes'') as d, ',
'''1'' as r ',
'FROM dual',
'',
'UNION ALL',
'',
'SELECT emano_util.fLang(''Nein'', ''No'') as d, ',
'''0'' as r ',
'FROM dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT d, r',
'FROM (',
'    SELECT emano_util.fLang(''Nein'', ''No'') d, ''0'' r ',
'    FROM dual',
'    UNION ALL',
'    SELECT emano_util.fLang(''Ja'', ''Yes'') d, ''1'' r ',
'    FROM dual',
'    WHERE :P2005_DOC_TYP = ''CHANGE_REGULATION''',
')',
'ORDER BY r;'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993767585516220538)
,p_name=>'P41_VORSCHRIFT_TYPID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Vorschrift Typ'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1100)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'VORSCHRIFT_TYPID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_VORSCHRIFT_TYP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung ',
'        ELSE name_eng',
'    END AS d,',
'    vorschrift_typid AS r',
'FROM t_vorschrift_typ',
'ORDER BY 2;',
''))
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- (pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0) =false',
'--     or (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
'--  and  (:P41_STRG_GETEX_ANZEIGE = 20)',
'',
'',
'(pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
') or (:P41_STRG_GETEX_ANZEIGE = 20 )',
'',
'',
'read only  -  13.05.2025',
'',
'(',
'  (  pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'            ( pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0',
'                 OR ( pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0 and :P41_VORSCHRIFTID is null) -- on "create"  f. Rolle Inaktive F.',
'            )',
'                            ) -- Rolle VKO, Fachadm',
') = false',
'--   or ',
'-- (  ',
'--    (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
'-- )',
'',
'or (:P41_STRG_GETEX_ANZEIGE = 20 )'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993767204895220538)
,p_name=>'P41_EINSATZDATUM_MODELLID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Einsatz DATUM Modell'
,p_source=>'EINSATZDATUM_MODELLID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN MODELL',
'        ELSE MODELL_ENG',
'    END AS MODELL, ',
'    EINSATZDATUM_MODELLID',
'FROM T_EINSATZDATUM_MODELL ',
'ORDER BY 2;',
''))
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_grid_column=>7
,p_display_when=>'P41_VORSCHRIFT_TYPID'
,p_display_when2=>'20'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'read only  -  13.05.2025',
'',
'',
'(pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
') or (:P41_STRG_GETEX_ANZEIGE = 20 )'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993766761771220537)
,p_name=>'P41_PARENT_VORSCHRIFTID'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('\00DCbergeordnete Vorschrift')
,p_post_element_text=>unistr('<a alt="\005C\00DCbergeordnete Vorschrift \005C00F6ffnen" title="\005C\00DCbergeordnete Vorschrift \005C00F6ffnen" style="margin-left: 5px" class="a-Button a-Button--icon" href="f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P41_VORSCHRIFTID:&P41_PARENT_VORSCHRIFTID." target="_blank')
||'"><span class="fa fa-search"></span></a>'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vrv.vorgaenger_vorschriftid',
'from t_vorschrift_ref_vorschrift vrv',
'where vrv.nachfolger_vorschriftid = :P41_VORSCHRIFTID',
'and vrv.BEZIEHUNG_ART = (case when :P41_VORSCHRIFT_TYPID = 20 then 30 else 20 end)',
'and :P41_VORSCHRIFT_TYPID = 20 -- parents gibts nur bei Supplements',
'fetch first row only'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select VORSCHRIFT_NUMMER || '' - '' || VORSCHRIFT_BEZEICHNUNG d,',
'       VORSCHRIFTID as r',
'  from T_VORSCHRIFT where vorschrift_typid !=20  -- supplement is not allowed as parent',
'  and (:P41_VORSCHRIFT_NUMMER is null  or VORSCHRIFT_NUMMER != :P41_VORSCHRIFT_NUMMER)',
' order by 1'))
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_grid_column=>7
,p_display_when=>'P41_VORSCHRIFT_TYPID'
,p_display_when2=>'20'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'read only  -  13.05.2025',
'',
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
'',
'',
'',
unistr('<a alt="\00DCbergeordnete Vorschrift \00F6ffnen" title="\00DCbergeordnete Vorschrift \00F6ffnen" style="margin-left: 5px" class="a-Button a-Button--icon" href="#" target="_blank" id="bLinkParent"><span class="fa fa-search"></span></a>'),
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993766325171220537)
,p_name=>'P41_VORSCHRIFT_NUMMER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Vorschriftennummer'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1102)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'VORSCHRIFT_NUMMER'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'read only  -  13.05.2025',
'(pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
') or (:P41_STRG_GETEX_ANZEIGE = 20 )'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993765983588220537)
,p_name=>'P41_DOKUMENTENDATUM'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Dokumentendatum'
,p_source=>'DOKUMENTENDATUM'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_display_when=>'P41_VORSCHRIFTID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993765612876220537)
,p_name=>'P41_TITEL_KURZ'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Title Kurz'
,p_source=>'TITEL_KURZ'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'( --pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'   -- or (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
'  --) or (:P41_STRG_GETEX_ANZEIGE = 20 )',
'true',
')'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993765150757220537)
,p_name=>'P41_VORSCHRIFT_BEZEICHNUNG'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Title English (\00DCberschrift)')
,p_source=>'VORSCHRIFT_BEZEICHNUNG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'read only  -  13.05.2025',
'',
'',
'(pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
') or (:P41_STRG_GETEX_ANZEIGE = 20 )'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993764719765220536)
,p_name=>'P41_PROGNOSE_QUALITAETID'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Prognosequalit\00E4t Einsatztermine')
,p_post_element_text=>'&nbsp;<span onclick="redirect(1103)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'PROGNOSE_QUALITAETID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_VORSCHRIFT_PROGNOSE_QUALITAET'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''offen'', ''open'') AS display_value,',
'        0 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''sicher'', ''secure'') AS display_value,',
'        10 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'    ',
'    UNION ALL',
'    ',
'    SELECT ',
unistr('        emano_util.fLang(''absch\00E4tzbar'', ''estimable'') AS display_value,'),
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'--   or ',
'-- (  ',
'--    (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
'-- )',
'',
'',
'',
'',
'-- read only  -  13.05.2025',
'',
'',
'(',
'   (  --pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'          (  pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0',
'             OR ( pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0 and :P41_VORSCHRIFTID is null) -- on "create"  f. Rolle Inaktive F.',
'            )',
'   ) -- Rolle VKO, Fachadm',
') = false',
'  or ',
'(  ',
'   (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
')',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993764369573220536)
,p_name=>'P41_FAHRZEUGKLASSE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fahrzeugart'
,p_post_element_text=>'&nbsp;<span onclick="redirect(400)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(f.bezeichnung, '':'') ',
'from t_vorschrift_ref_fahrzeugklasse v ',
'join t_fahrzeugklasse f ON f.fahrzeugklasseid = v.fahrzeugklasseid',
'where v.vorschriftid = :P41_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'nvl(:P41_VORSCHRIFT_TYPID,10) != 20'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'read only  -  13.05.2025',
'',
'(pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'  or   (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
') ',
'or (:P41_STRG_GETEX_ANZEIGE = 20 )',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993763917209220536)
,p_name=>'P41_FAHRZEUGKLASSE_SUPP'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_prompt=>'Fahrzeugklassen'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(fk.bezeichnung, '', '')',
'from t_vorschrift_ref_fahrzeugklasse vrf',
'join t_fahrzeugklasse fk on (fk.fahrzeugklasseid = vrf.fahrzeugklasseid)',
'where vorschriftid = :P41_PARENT_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P41_VORSCHRIFT_TYPID'
,p_display_when2=>'20'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993763592135220536)
,p_name=>'P41_VORSCHRIFT_FREIGABESTATUSID'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1'
,p_prompt=>'Interner DB Freigabestatus'
,p_post_element_text=>'&nbsp;<span onclick="redirect(281)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_source=>'VORSCHRIFT_FREIGABESTATUSID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_VORSCHRIFT_FREIGABE_STATUS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vorschrift_freigabestatusid as actual_value, emano_util.fLang(name_deutsch,name_englisch) as display_value',
'from t_vorschrift_freigabestatus',
'order by 1'))
,p_display_when=>':P41_VORSCHRIFT_TYPID IN (10,30,40)'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993763184763220536)
,p_name=>'P41_VORSCHRIFT_STATUSID'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_item_default=>'20'
,p_prompt=>'Status der Vorschrift'
,p_post_element_text=>'&nbsp;<span onclick="redirect(181)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'VORSCHRIFT_STATUSID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select status, vorschrift_statusid',
'from t_vorschrift_status',
'order by 2'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
'read only  -  13.05.2025',
'(pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
') or (:P41_STRG_GETEX_ANZEIGE = 20 )'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993762786713220535)
,p_name=>'P41_RXSWIN'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_item_default=>'20'
,p_prompt=>'Potentiell SUMS-relevant'
,p_post_element_text=>'&nbsp;<span onclick="redirect(184)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_source=>'RXSWIN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Nicht gepr\00FCft'', ''Not checked'') AS display_value,'),
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_colspan=>2
,p_grid_column=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'expression ',
'(',
'  ( -- pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'                            pck_ri.fIsUserInRolle(listRolleId => ''1000:1002:1003'') > 0) -- Rolle VKO, VEX, ZVEX, Fachadm',
') = false',
'    or (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
'',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993762326147220535)
,p_name=>'P41_SWR_HAUPTUMSETZENDE_OE'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>'OE2 des REV'
,p_post_element_text=>'&nbsp;<span onclick="redirect(461)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_source=>'SWR_HAUPTUMSETZENDE_OE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct swr_hauptumsetzende_oe ',
'  from t_vorschrift',
' where swr_hauptumsetzende_oe is not null'))
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_grid_column=>3
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993761970392220535)
,p_name=>'P41_COP_RELEVANT'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_item_default=>'20'
,p_prompt=>'CoP Relevant'
,p_post_element_text=>'&nbsp;<span onclick="redirect(201)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_source=>'COP_RELEVANT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Nicht gepr\00FCft'', ''Not checked'') AS display_value,'),
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993761560386220535)
,p_name=>'P41_HOMOLOGATIONSRELEVANT'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Homologationsrelevant'
,p_post_element_text=>'&nbsp;<span onclick="redirect(282)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_source=>'HOMOLOGATIONSRELEVANT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Nicht gepr\00FCft'', ''Not checked'') AS display_value,'),
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>'20'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993761126264220534)
,p_name=>'P41_HOMOLOGATIONSEIGENSCHAFTEN'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Homologationseigenschaften'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    select distinct e.EIGENSCHAFT_KENNUNG || ''-'' || et.kuerzel || ''-'' || e.eigenschaft as eigenschaft',
'    from t_vorschrift_ref_thema vtl',
'    join carmah2_admin.t_eigenschaft_ref_regindexthemen err on (vtl.themaid = err.regindex_themen_id)',
'    join carmah2_admin.t_eigenschaft e on (err.eigenschaft_id = e.eigenschaft_id)',
'    join carmah2_admin.t_eigenschaft_typ et on (e.eigenschaft_typ_id = et.eigenschaft_typ_id)',
'    where vtl.vorschriftid = :P41_VORSCHRIFTID and geloescht = 0',
')',
'select listagg(eigenschaft,'', '') within group (order by eigenschaft)',
'from cte1',
'',
'',
'',
'--e.EIGENSCHAFT_KENNUNG || ''-'' || et.kuerzel || ''-'' || e.eigenschaft'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_display_when=>'P41_HOMOLOGATIONSRELEVANT'
,p_display_when2=>'10'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993760741149220534)
,p_name=>'P41_REV_NOTWENDIG'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_item_default=>'10'
,p_prompt=>'REV Notwendig'
,p_post_element_text=>'&nbsp;<span onclick="redirect(202)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_source=>'REV_NOTWENDIG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_REV_NOTWENDIG'
,p_lov=>'.'||wwv_flow_imp.id(646432047862271176)||'.'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993760332898220534)
,p_name=>'P41_BEMERKUNG'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Bemerkung zur Vorschrift'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1104)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'BEMERKUNG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993759937299220534)
,p_name=>'P41_BEMERKUNG_ENGLISCH'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Bemerkung zur Vorschrift English'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1104)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'BEMERKUNG_ENGLISCH'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993759597505220534)
,p_name=>'P41_GETEX_URL'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Zum Dokument (GETEX2-URL)'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pck_ri.fcreateLinkIfUrl(url_getex_vorschrift, 512)',
'from t_vorschrift ',
'where vorschriftid = :P41_VORSCHRIFTID ',
'/*select pck_ri.fcreateLinkIfUrl(rev_DisplayURL, 160)',
'from mv_getex_vorschrift ',
'--where rev_regindexid  =:P41_VORSCHRIFTID;',
'where reg_id = (select regindexid from t_vorschrift where vorschriftid = :P41_VORSCHRIFTID);*/'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="text-decoration: underline; text-decoration-style: dashed"'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993759185999220533)
,p_name=>'P41_LINK_ZUR_VORSCHRIFT_DMS'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu DMS (Ein Link pro Zeile)'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1105)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'LINK_ZUR_VORSCHRIFT_DMS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>'&nbsp;'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'--     or (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
'--     or :P41_STRG_GETEX_ANZEIGE = 20',
'',
'(',
'  (  pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'                            pck_ri.fIsUserInRolle(listRolleId => ''1000'') > 0) -- Rolle VKO',
') = false',
'  or ',
'(  ',
'   (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
')',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993758727099220533)
,p_name=>'P41_LINK_REQMAN_RO'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu REQMAN'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1107)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PCK_RI.fCreateLinkIfUrl(v.link_reqman, 80)',
'from t_vorschrift v',
'where v.vorschriftid = :P41_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="text-decoration: underline; text-decoration-style: dashed"'
,p_display_when=>'false'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'N')).to_clob
,p_item_comment=>'resd only - tem is null - edit mode '
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993758357605220533)
,p_name=>'P41_WEBSITELINK'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu Web Site'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1108)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'WEBSITELINK'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT w.WEBSITE_NAME, w.WEBSITEID',
'FROM T_WEBSITE w',
'ORDER BY 1',
''))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
'    or :P41_STRG_GETEX_ANZEIGE = 20',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993758012787220533)
,p_name=>'P41_KSU'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1020'
,p_prompt=>'KSU'
,p_source=>'KSUID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN k.bezeichnung',
'        ELSE k.name_eng',
'    END AS bezeichnung, ',
'    k.ksuid',
'FROM t_ksu k',
'ORDER BY ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN k.bezeichnung',
'        ELSE k.name_eng',
'    END;',
''))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993757570068220532)
,p_name=>'P41_TYPSCHILD'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_prompt=>'Typschild'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(typschild, '', '') within group(order by typschild)',
'from (',
'    select distinct l.typschild',
'    from T_VORSCHRIFT_REF_LAND ttl',
'    inner join T_LAND l on l.landid = ttl.landid',
'    where ttl.vorschriftid = :P41_VORSCHRIFTID and ttl.geloescht = 0',
');'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Rolle inakt. Funktionen',
'(pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0) = true AND ( :P41_VORSCHRIFT_TYPID IN (10,30,40))'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>unistr('Nur f\00FCr Administratoren sichtbar')
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993756632107220530)
,p_name=>'P41_TECHNOLOGIE'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Technologie'
,p_source=>'TECHNOLOGIE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct technologie from t_vorschrift',
'order by technologie'))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Rolle inaktive Funktionen',
'(pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0) = true',
'',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'  (  pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'                            pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0) -- Rolle Fachadm',
') = false',
'    or (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
'-- (pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0)',
'',
'',
'',
'read only ',
'',
'',
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P41_EDIT_MODE is null or :P41_EDIT_MODE <> 1)',
'',
'',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993756238035220530)
,p_name=>'P41_STICHWOERTER'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_prompt=>unistr('Stichw\00F6rter')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(sw.stext,  '', '') within group (order by sw.stext)',
'    from t_vorschrift_ref_schlagwort vrs',
'    join t_schlagwort sw on (sw.schlagwortid = vrs.schlagwortid)',
'   where vrs.vorschriftid = :P41_VORSCHRIFTID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993755833684220529)
,p_name=>'P41_INHALTLICH_SACHLICH_GEPRUEFT'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('inhaltlich sachlich gepr\00FCft')
,p_source=>'INHALTLICH_SACHLICH_GEPRUEFT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_INHALTLICH_SACHLICH_GEPRUEFT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
unistr('        emano_util.fLang(''nicht gepr\00FCft'', ''not checked'') AS display_value,'),
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''n.i.O gepr\00FCft'', ''checked n.i.O'') AS display_value,'),
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''i.O gepr\00FCft'', ''checked i.O'') AS display_value,'),
'        30 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_display_when=>'pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993755486153220529)
,p_name=>'P41_DOCUMENT_TYPE'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_imp.id(12195436989792892158)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Document Type'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select emano_util.flang(dt.text_deutsch, dt.text_englisch)',
'from t_vorschrift v',
'join t_document_type dt on (v.document_typeid = dt.document_typeid)',
'where v.vorschriftid = :P41_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P41_VORSCHRIFTID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993746610179220498)
,p_name=>'P41_SELECTED_ROWS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12196866778328287321)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993746161124220497)
,p_name=>'P41_ERW_LAND_ANZEIGE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(12196866778328287321)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_lnd_erweit as (',
'  select distinct gvl.v_id, v.vorschriftid ',
'  from mv_getex_vorschrift_land gvl      ',
'  join T_land la on (la.iso_code_3 = gvl.iso_code3 and la.cockpit_erw_anzeige > 0) ',
'  join t_vorschrift v on (v.regindexid is not null and v.regindexid = gvl.v_id) ',
'  where nvl(la.cockpit_erw_anzeige, 0) > 0',
'  and v.vorschriftid = :P41_VORSCHRIFTID ',
')',
'select case when (select count(vorschriftid) from cte_lnd_erweit) > 0',
'            then ''Ja''',
'            else ''No''',
'       end as co',
'from dual;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993744646893220496)
,p_name=>'P41_STATUS_OPTION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12202881112625828884)
,p_use_cache_before_default=>'NO'
,p_item_default=>'10'
,p_prompt=>'Jira Status'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''alle MfVs'', ''all MfVs'') AS display_value, ',
'        100 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''geschlossen'', ''closed'') AS display_value,',
'        10 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''offen'', ''open'') AS display_value,',
'        0 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''ohne MfV beendet'', ''without MfV terminated'') AS display_value,',
'        20 AS actual_value,',
'        4 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '4',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993729665343220480)
,p_name=>'P41_SET_GUELTIG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4809358265795035942)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993725619309220476)
,p_name=>'P41_HINWEIS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8504911947226012642)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*with cte1 as(',
unistr('    Select  emano_util.fLang(''Keine automatische Berechnung des Au\00DFer Kraft Datums, da dieses manuell bef\00FCllt wurde'', '),
'    ''No automatic calculation of the out-of-force date, as this was filled manually'')',
'    as hinweis',
'     from  T_VORSCHRIFT_REF_EINSATZDATUM_TYP vredt',
'where vredt.vorschriftid = :P41_VORSCHRIFTID and  vredt.EINSATZDATUM_TYPID in (1041,1060,1063)',
'  and (MANUELLE_EINTRAGUNG = 10 and einsatzdatum is not null)',
'union all',
' Select  hinweis',
'     from  T_VORSCHRIFT_REF_EINSATZDATUM_TYP vredt',
'where vredt.vorschriftid = :P41_VORSCHRIFTID and  vredt.EINSATZDATUM_TYPID in (1041,1060,1063)',
'  and MANUELLE_EINTRAGUNG = 20 and hinweis is not null',
')',
'*/',
'',
'with cte1 as(',
unistr('    Select emano_util.fLang(''Achtung,  f\00FCr neue typen darf diese Vorschrift nicht mehr verwendet werden'','),
'                          ''Attention, this regulation must not be used for new types'')',
'    as hinweis',
'     from  T_VORSCHRIFT_REF_EINSATZDATUM_TYP vre',
'   join T_vorschrift_ref_vorschrift vrv on (vrv.nachfolger_vorschriftid = vre.vorschriftid)',
'  where vrv.beziehung_art in (10) and vrv.vorgaenger_vorschriftid = :P41_VORSCHRIFTID',
'  and vre.einsatzdatum_typid in (1010, 1020) and vre.einsatzdatum < sysdate',
')',
'select ''<span style="color:red">'' || hinweis ||''</span>'' a --, hinweis b',
'from  cte1',
'  fetch first 1 rows only'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993709828328220443)
,p_name=>'P41_X_JIRA_URL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12209628832361971682)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993709418221220442)
,p_name=>'P41_PERMALINK'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12209628832361971682)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.host_url(''SCRIPT'') || apex_page.get_url(',
'    p_application => :APP_ALIAS',
'    , p_page => ''VORSCHRIFT''',
'    , p_items => ''P41_VORSCHRIFTID''',
'    , p_values => :P41_VORSCHRIFTID',
'    , p_session => null',
'    , p_clear_cache => ''25''',
')'))
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993709051817220442)
,p_name=>'P41_LINK'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12209628832361971682)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993708655390220442)
,p_name=>'P41_ROWID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12209628832361971682)
,p_use_cache_before_default=>'NO'
,p_source=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993708259384220442)
,p_name=>'P41_FAHRZEUGKLASSE1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12209628832361971682)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(fahrzeugklasseid, '':'')',
'from t_vorschrift_ref_fahrzeugklasse',
'where vorschriftid = :P41_VORSCHRIFTID'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993707866034220442)
,p_name=>'P41_VORSCHRIFTID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12209628832361971682)
,p_use_cache_before_default=>'NO'
,p_source=>'VORSCHRIFTID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993707447087220441)
,p_name=>'P41_VORSCHRIFTID_PARENT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12209628832361971682)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993707058921220441)
,p_name=>'P41_STRG_GETEX_ANZEIGE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12209628832361971682)
,p_use_cache_before_default=>'NO'
,p_item_default=>'10'
,p_source=>unistr('case  when (:P41_MASTER in (20, 30) /* Master GETEX oder GETEX mit \00DCbernahme */)  then 20 /* Logo anzeigen */ else 10 /* Logo nicht anzeigen */ end')
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993706681727220441)
,p_name=>'P41_PROCESS_FROM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12209628832361971682)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993706255349220441)
,p_name=>'P41_GETEX_KEY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(12209628832361971682)
,p_use_cache_before_default=>'NO'
,p_source=>'REGINDEXID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>':P41_VORSCHRIFTID is not null or :P41_ROWID is not null'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(993705895930220441)
,p_name=>'P41_EDIT_MODE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(12209628832361971682)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'if :P41_ROWID is null then',
'    return 1;',
'else',
'    return null;',
'end if;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993702607452220424)
,p_name=>'DIALOG_VERKNUEPFUNGEN_CLOSED'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(12196866706953287320)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993702032406220423)
,p_event_id=>wwv_flow_imp.id(993702607452220424)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993701633208220423)
,p_name=>'DIALOG_MFV_CLOSED'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(12202881112625828884)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993701134305220423)
,p_event_id=>wwv_flow_imp.id(993701633208220423)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'refresh report MfV -  Interpretation'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4809358265795035942)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993700665115220423)
,p_event_id=>wwv_flow_imp.id(993701633208220423)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'refresh report MfV - Information'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4809356465692035924)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993700238907220423)
,p_name=>'DELETE_VORSCHRIFT'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(993710652125220443)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993699742532220422)
,p_event_id=>wwv_flow_imp.id(993700238907220423)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('M\00F6chten Sie die Vorschrift ''&P41_VORSCHRIFT_NUMMER.'' mit allen verkn\00FCpften Daten, Historie und Benachrichtigungen endg\00FCltig l\00F6schen?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993699312136220422)
,p_event_id=>wwv_flow_imp.id(993700238907220423)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lResult boolean;',
'begin',
'   -- delete  Vorschriftid dependences',
'    --update t_benachrichtigung set vorschriftid =null where vorschriftid = P41_VORSCHRIFTID;',
'    --or',
'    --delete from T_BENACHRICHTIGUNG_kommentar where BENACHRICHTIGUNGID in (select BENACHRICHTIGUNGID from t_benachrichtigung  where vorschriftid = :P41_VORSCHRIFTID);',
'    --delete from t_benachrichtigung  where vorschriftid = :P41_VORSCHRIFTID;',
'    --',
'    lResult := PCK_RI.fDeleteVorschrift(:P41_VORSCHRIFTID);',
'    if(lResult) then',
unistr('      pck_ri_benachrichtigung.pBenachrichtigung( null,  ''1400'', ''Vorschrift "'' || :P41_VORSCHRIFT_NUMMER || ''", id:''|| :P41_VORSCHRIFTID || '' ist gel\00F6scht.'', aGrund =>90, '),
'      aLoeschmarker =>0, aBenutzerid => PCK_RI.fGetUserId());',
'    end if;',
'    ',
'   pck_ri_cockpit_refresh.pTriggerRefresh;',
'end;'))
,p_attribute_02=>'P41_VORSCHRIFTID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993698803937220422)
,p_event_id=>wwv_flow_imp.id(993700238907220423)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('apex.message.showPageSuccess(''Die Vorschrift wurde gel\00F6scht.'');'),
'',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993698241789220422)
,p_event_id=>wwv_flow_imp.id(993700238907220423)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'DELETE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993697906647220422)
,p_name=>'DELETE_SELECTED_VERKNUEPFUNGEN'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(993754718764220529)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993696865082220421)
,p_event_id=>wwv_flow_imp.id(993697906647220422)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('M\00F6chten Sie die ausgew\00E4hlten Verkn\00FCpfungen l\00F6schen?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993696355801220421)
,p_event_id=>wwv_flow_imp.id(993697906647220422)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var sel_rows = $("#P41_SELECTED_ROWS");',
'sel_rows.val("");',
'$("#report-verknuepfungen").find("td input:checked").each(function() {',
'  // alert(this.value);',
'  if(sel_rows.val().length > 0) {',
'    sel_rows.val(sel_rows.val() + "|");    ',
'  }',
'  sel_rows.val(sel_rows.val() + this.value);',
'  //sel_rows.val(sel_rows.val().push(this.value));',
'  //alert(sel_rows.val());',
'});',
'            '))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993695885842220421)
,p_event_id=>wwv_flow_imp.id(993697906647220422)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  lStartIdx binary_integer;',
'  lCurIdx   binary_integer;',
'  lCurValue varchar2(1000);',
'begin',
'',
'   --debug ('' sel_rows:P41_SELECTED_ROWS= ''|| :P41_SELECTED_ROWS);',
unistr('    -- aenderung der Getex_attr f\00FCr beide voschriften'),
'    -- select vorschrift_ref_vorschriftid from t_vorschrift_ref_vorschrift where ROWID in (select  column_value from apex_string.split(:P41_SELECTED_ROWS,''|'') x)',
'    update t_vorschrift set letzte_aenderung_getex_attr = sysdate ',
'    where Vorschriftid  in (',
'        select  vorgaenger_vorschriftid from t_vorschrift_ref_vorschrift',
'        where vorschrift_ref_vorschriftid  in ( select vorschrift_ref_vorschriftid from t_vorschrift_ref_vorschrift vrv',
'                                                join table (apex_string.split(:P41_SELECTED_ROWS,''|'') ) x on (x.column_value =vrv.rowid) )',
'         union ',
'          select  nachfolger_vorschriftid from t_vorschrift_ref_vorschrift',
'        where vorschrift_ref_vorschriftid  in ( select vorschrift_ref_vorschriftid from t_vorschrift_ref_vorschrift vrv',
'                                                join table (apex_string.split(:P41_SELECTED_ROWS,''|'') ) x on (x.column_value =vrv.rowid) )',
'     );    ',
'     ',
'    for cur in (',
'        select vrv.vorschrift_ref_vorschriftid',
'        from apex_string.split(:P41_SELECTED_ROWS,''|'') x',
'        join t_vorschrift_ref_vorschrift vrv on (x.column_value = vrv.rowid)',
'    )',
'    loop',
'        delete from t_vorschrift_ref_vorschrift_ref_thema where vorschrift_ref_vorschriftid = cur.vorschrift_ref_vorschriftid;',
'        delete from t_vorschrift_ref_vorschrift where vorschrift_ref_vorschriftid = cur.vorschrift_ref_vorschriftid;',
'    end loop;',
'',
'',
' /* lStartIdx := 0;',
'  lCurIdx   := instr(:P41_SELECTED_ROWS, ''|''); ',
'',
'  while(lCurIdx > 0) loop',
'    lCurValue := substr(:P41_SELECTED_ROWS, lStartIdx+1, lCurIdx - lStartIdx - 1);',
'',
'    -- call proc here',
'    delete from t_vorschrift_ref_vorschrift_ref_thema where vorschrift_ref_vorschriftid in (',
'        select vorschrift_ref_vorschriftid from t_vorschrift_ref_vorschrift where rowid = lCurValue',
'    );',
'    delete from t_vorschrift_ref_vorschrift where rowid = lCurValue;',
'',
'    lStartIdx := lCurIdx;',
'    lCurIdx := instr(:P41_SELECTED_ROWS, ''|'', lStartIdx + 1);  ',
'  end loop;',
'',
'  -- Call proc here for last part (or in case of single element)',
'  lCurValue := substr(:P41_SELECTED_ROWS, lStartIdx+1);',
'  delete from t_vorschrift_ref_vorschrift where rowid = lCurValue;*/',
'',
'end;'))
,p_attribute_02=>'P41_SELECTED_ROWS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993695394444220421)
,p_event_id=>wwv_flow_imp.id(993697906647220422)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993697326789220421)
,p_event_id=>wwv_flow_imp.id(993697906647220422)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12196866778328287321)
,p_attribute_01=>'N'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993694938545220420)
,p_name=>'DIALOG_FUNKTIONEN_CLOSED'
,p_event_sequence=>210
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(9767890902596280476)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993694494341220420)
,p_event_id=>wwv_flow_imp.id(993694938545220420)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9767891049642280477)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993694100220220420)
,p_name=>'copy permalink'
,p_event_sequence=>220
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(993770344369220540)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993693596355220420)
,p_event_id=>wwv_flow_imp.id(993694100220220420)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'navigator.clipboard.writeText($v("P41_PERMALINK"));',
'alert(''Der Permalink wurde in die Zwischenablage kopiert:\n\n'' + $v("P41_PERMALINK"));'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993693120464220420)
,p_name=>'Dialog Funktionszuordnung closed'
,p_event_sequence=>280
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(993780376477220549)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993692622331220419)
,p_event_id=>wwv_flow_imp.id(993693120464220420)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9767890902596280476)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993692249542220419)
,p_name=>unistr('Dialog verkn\00FCpfte Daten closed')
,p_event_sequence=>330
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(993787044768220558)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993691811058220419)
,p_event_id=>wwv_flow_imp.id(993692249542220419)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P41_VORSCHRIFTID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993691248518220418)
,p_event_id=>wwv_flow_imp.id(993692249542220419)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8667574484668266049)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993690885566220418)
,p_name=>'Show_Netz'
,p_event_sequence=>340
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(993711047310220443)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993690384554220418)
,p_event_id=>wwv_flow_imp.id(993690885566220418)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'javascript:window.open(''f?p=&APP_ID.:300:&APP_SESSION.::&DEBUG.:300:P300_VORSCHRIFTID:''+$v("P41_VORSCHRIFTID") +'''',''_blank'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993689921243220418)
,p_name=>unistr('Set G\00FCltigkeitsdatum')
,p_event_sequence=>360
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.setzegueltigkeit'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993689441869220418)
,p_event_id=>wwv_flow_imp.id(993689921243220418)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var mfvid = $(this.triggeringElement).attr(''data-id'');',
'$s(''P41_SET_GUELTIG'',mfvid);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993688916458220418)
,p_event_id=>wwv_flow_imp.id(993689921243220418)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_mfv set gueltigkeitsdatum = sysdate + 2*365 where mfvid = :P41_SET_GUELTIG;',
''))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993688491893220417)
,p_event_id=>wwv_flow_imp.id(993689921243220418)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// apex.jQuery("#p41_mfv_report").trigger("apexrefresh");',
'',
'apex.jQuery("#p41_mfv_report_interpretation").trigger("apexrefresh");',
'',
'apex.jQuery("#p41_mfv_report_information").trigger("apexrefresh");',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993688027761220417)
,p_name=>'Hide Create Message Button'
,p_event_sequence=>380
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NOT_EXISTS'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from t_benutzer_ref_rolle where benutzerid=:G_BENUTZERID',
'AND rolleid in (1003,1000 )'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993687549389220417)
,p_event_id=>wwv_flow_imp.id(993688027761220417)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(993770736378220540)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993687139693220417)
,p_name=>'Hide Jira ticket assist Button'
,p_event_sequence=>390
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NOT_EXISTS'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from t_benutzer_ref_rolle where benutzerid=:G_BENUTZERID',
'AND rolleid in (1003,1000 )'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993686699827220416)
,p_event_id=>wwv_flow_imp.id(993687139693220417)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(993769972234220540)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993686288211220416)
,p_name=>'Change Value'
,p_event_sequence=>470
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P41_DATUM_ANGABE_AS_MJ'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993685765931220416)
,p_event_id=>wwv_flow_imp.id(993686288211220416)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update  t_vorschrift set  mj_schalter_status = :P41_DATUM_ANGABE_AS_MJ',
'where vorschriftid = :P41_vorschriftID;'))
,p_attribute_02=>'P41_VORSCHRIFTID,P41_DATUM_ANGABE_AS_MJ'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993685279601220416)
,p_event_id=>wwv_flow_imp.id(993686288211220416)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993684910314220415)
,p_name=>'change'
,p_event_sequence=>500
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P41_STATUS_OPTION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993684348257220415)
,p_event_id=>wwv_flow_imp.id(993684910314220415)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P41_STATUS_OPTION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993683910252220415)
,p_event_id=>wwv_flow_imp.id(993684910314220415)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4809358265795035942)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993683326527220415)
,p_event_id=>wwv_flow_imp.id(993684910314220415)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4809356465692035924)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993683009209220415)
,p_name=>'DIALOG_LAENDER_CLOSED'
,p_event_sequence=>510
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(8485846085285317681)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993682418278220414)
,p_event_id=>wwv_flow_imp.id(993683009209220415)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993681999654220414)
,p_event_id=>wwv_flow_imp.id(993683009209220415)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8667574484668266049)
,p_attribute_01=>'N'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993681484319220414)
,p_event_id=>wwv_flow_imp.id(993683009209220415)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9767891049642280477)
,p_attribute_01=>'N'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993680918441220414)
,p_event_id=>wwv_flow_imp.id(993683009209220415)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8988778826434303773)
,p_attribute_01=>'N'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993680493491220414)
,p_event_id=>wwv_flow_imp.id(993683009209220415)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P41_RXSWIN'
,p_attribute_01=>'N'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993680092683220414)
,p_name=>'DIALOG_THEMEN_CLOSED_N_1'
,p_event_sequence=>530
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(4795247179829439559)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993679610964220413)
,p_event_id=>wwv_flow_imp.id(993680092683220414)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993679103300220413)
,p_event_id=>wwv_flow_imp.id(993680092683220414)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8667574484668266049)
,p_attribute_01=>'N'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993678592942220413)
,p_event_id=>wwv_flow_imp.id(993680092683220414)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9767891049642280477)
,p_attribute_01=>'N'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993678055458220413)
,p_event_id=>wwv_flow_imp.id(993680092683220414)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8988778826434303773)
,p_attribute_01=>'N'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993677626504220413)
,p_name=>'Dialog Closed'
,p_event_sequence=>540
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(12195436989792892158)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993677175468220413)
,p_event_id=>wwv_flow_imp.id(993677626504220413)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12195436989792892158)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993676790608220412)
,p_name=>'dialog_Freigabestatus_closed'
,p_event_sequence=>550
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId && this.data.dialogPageId == 28'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993676263657220412)
,p_event_id=>wwv_flow_imp.id(993676790608220412)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.page.submit(''REFRESH'');',
''))
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993675824270220412)
,p_name=>unistr('Dialog Closed Aenderungen zur Pr\00FCfung/\00DCbernahme Page')
,p_event_sequence=>560
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId && this.data.dialogPageId == 29'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993675400509220412)
,p_event_id=>wwv_flow_imp.id(993675824270220412)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.page.submit(''REFRESH'');',
''))
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993674928790220412)
,p_name=>'SET GETEX Logo'
,p_event_sequence=>600
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'( (20 = :P41_STRG_GETEX_ANZEIGE ) ',
'--and (:P41_EDIT_MODE is not null) and (1 =:P41_EDIT_MODE )',
')'))
,p_display_when_cond2=>'PLSQL'
,p_da_event_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'( (20 = :P25_STRG_GETEX_ANZEIGE ) ',
'--and (:P25_EDIT_MODE is not null) and (1 =:P25_EDIT_MODE )',
')'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993674508551220411)
,p_event_id=>wwv_flow_imp.id(993674928790220412)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'#rEinsatzdaten .t-Region-header,#rLaender .t-Region-header'
,p_attribute_01=>'getexlogo'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993703925431220428)
,p_name=>'SET GETEX Logo_1'
,p_event_sequence=>610
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NEVER'
,p_da_event_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'( (20 = :P25_STRG_GETEX_ANZEIGE ) ',
'--and (:P25_EDIT_MODE is not null) and (1 =:P25_EDIT_MODE )',
')'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993703446244220425)
,p_event_id=>wwv_flow_imp.id(993703925431220428)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'#P41_EINSATZDATUM_MODELLID_DISPLAY,#P41_VORSCHRIFT_TYPID_DISPLAY,#P41_FAHRZEUGKLASSE_DISPLAY,#P41_VORSCHRIFT_STATUSID_DISPLAY,#rEinsatzdaten .t-Region-header,#rLaender .t-Region-header'
,p_attribute_01=>'getexlogo'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993702972217220424)
,p_event_id=>wwv_flow_imp.id(993703925431220428)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'#P41_VORSCHRIFT_NUMMER_DISPLAY,#P41_VORSCHRIFT_BEZEICHNUNG_DISPLAY,#P41_TITEL_KURZ_DISPLAY'
,p_attribute_01=>'getexlogo'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993674024919220411)
,p_name=>'DELETE_SEL_AMENDMENTS'
,p_event_sequence=>620
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(993813311745220609)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993673105370220411)
,p_event_id=>wwv_flow_imp.id(993674024919220411)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('M\00F6chten Sie die ausgew\00E4hlten Verkn\00FCpfungen l\00F6schen?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993672530255220411)
,p_event_id=>wwv_flow_imp.id(993674024919220411)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var sel_rows_a = $("#P41_SELECTED_AMENDM_ROWS");',
'sel_rows_a.val("");',
'$("#report-amendments").find("td input:checked").each(function() {',
'  // alert(this.value);',
'  if(sel_rows_a.val().length > 0) {',
'    sel_rows_a.val(sel_rows_a.val() + "|");    ',
'  }',
'  sel_rows_a.val(sel_rows_a.val() + this.value);',
' // alert(sel_rows_a.val());',
'});'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993672047591220411)
,p_event_id=>wwv_flow_imp.id(993674024919220411)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'   -- debug (''P41_SELECTED_AMENDM_ROWS='' || :P41_SELECTED_AMENDM_ROWS);',
unistr('    -- aenderung der Getex_attr f\00FCr beide voschriften  '),
'    update t_vorschrift set letzte_aenderung_getex_attr = sysdate ',
'    where Vorschriftid  in (',
'        select  vorgaenger_vorschriftid from t_vorschrift_ref_vorschrift',
'        where vorschrift_ref_vorschriftid  in  --(select  column_value from apex_string.split(:P41_SELECTED_AMENDM_ROWS,''|'') x)',
'                                             ( select vorschrift_ref_vorschriftid from t_vorschrift_ref_vorschrift vrv',
'                                                join table (apex_string.split(:P41_SELECTED_AMENDM_ROWS,''|'') ) x on (x.column_value = vrv.rowid) )',
'         union ',
'          select  nachfolger_vorschriftid from t_vorschrift_ref_vorschrift',
'        where vorschrift_ref_vorschriftid  in ( select vorschrift_ref_vorschriftid from t_vorschrift_ref_vorschrift vrv',
'                                                join table (apex_string.split(:P41_SELECTED_AMENDM_ROWS,''|'') ) x on (x.column_value = vrv.rowid) )',
'    );',
'    ',
'     for x in (',
'        select vrv.vorschrift_ref_vorschriftid',
'        from apex_string.split(:P41_SELECTED_AMENDM_ROWS,''|'') x',
'        join t_vorschrift_ref_vorschrift vrv on (x.column_value = vrv.rowid)',
'    )',
'    loop',
'        delete from t_vorschrift_ref_vorschrift_ref_thema where vorschrift_ref_vorschriftid = x.vorschrift_ref_vorschriftid;',
'        delete from t_vorschrift_ref_vorschrift where vorschrift_ref_vorschriftid = x.vorschrift_ref_vorschriftid;',
'    end loop;',
'   ',
'    ',
'end;'))
,p_attribute_02=>'P41_SELECTED_AMENDM_ROWS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993671517526220410)
,p_event_id=>wwv_flow_imp.id(993674024919220411)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993673588467220411)
,p_event_id=>wwv_flow_imp.id(993674024919220411)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4735611537074451043)
,p_attribute_01=>'N'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993671201967220410)
,p_name=>'DIALOG_AMENDMENT_CLOSED'
,p_event_sequence=>630
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(4735611384750451042)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993670659611220410)
,p_event_id=>wwv_flow_imp.id(993671201967220410)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4735611537074451043)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993670275411220410)
,p_name=>'New_1'
,p_event_sequence=>640
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(4782336065985811050)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993669776156220410)
,p_event_id=>wwv_flow_imp.id(993670275411220410)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4782336065985811050)
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function showBemerkung(landId, bemerkung) {',
'  apex.navigation.redirect(''f?p=&APP_ID.:DETAILS_PAGE:&SESSION.::NO::P_LANDID,P_BEMERKUNG:'' + landId + '','' + encodeURIComponent(bemerkung));',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993669380559220410)
,p_name=>'Dialog Closed From Page 32 - Edit Lead VKO'
,p_event_sequence=>650
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId && this.data.dialogPageId == 32'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993668852704220409)
,p_event_id=>wwv_flow_imp.id(993669380559220410)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'EVENT_SOURCE'
,p_attribute_01=>'apex.page.submit("REFRESH");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993668418009220409)
,p_name=>'Dialog Closed From Page 31 - Kerndaten Bearbeiter'
,p_event_sequence=>660
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId && this.data.dialogPageId == 31'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993667987030220409)
,p_event_id=>wwv_flow_imp.id(993668418009220409)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993667455491220409)
,p_event_id=>wwv_flow_imp.id(993668418009220409)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(993769530526220539)
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.page.submit("REFRESH");',
'',
'// $(''#b_REFRESH'').click();'))
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993667035675220409)
,p_name=>'Dialog Closed From Page 37 - Edit Einsatzdaten'
,p_event_sequence=>670
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(12209198452279314709)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993666548198220408)
,p_event_id=>wwv_flow_imp.id(993667035675220409)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993666070753220408)
,p_event_id=>wwv_flow_imp.id(993667035675220409)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12209198452279314709)
,p_attribute_01=>'N'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(993665692347220408)
,p_name=>'Refresh for Fahrzeugklasse'
,p_event_sequence=>680
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P41_FAHRZEUGKLASSE_NAME'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(993665161566220407)
,p_event_id=>wwv_flow_imp.id(993665692347220408)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12209198452279314709)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(993704808017220430)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_VORSCHRIFT'
,p_attribute_02=>'T_VORSCHRIFT'
,p_attribute_03=>'P41_ROWID'
,p_attribute_04=>'ROWID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2678507507882167805
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(993704360083220429)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load ROWID'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--evaluate P615_VORSCHRIFTID  if it''s set use it ',
'if (:P41_ROWID is null and :P41_VORSCHRIFTID is not null)',
'then',
'   select rowid into :P41_ROWID from t_vorschrift where vorschriftid = :P41_VORSCHRIFTID;',
'elsif (:P41_ROWID is not null and :P41_VORSCHRIFTID is  null) then',
'   select vorschriftid into :P41_VORSCHRIFTID from t_vorschrift where  rowid= :P41_ROWID ;',
'',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P41_VORSCHRIFTID is not null or :P41_ROWID is not null'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'SQL'
,p_internal_uid=>2678507955816167806
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(993705171046220430)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Daten laden'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- Permalink in Item speichern beim \00D6ffnen der Seite  '),
':P41_PERMALINK := apex_util.host_url(''SCRIPT'') || apex_page.get_url(',
'    p_application => :APP_ALIAS',
'    , p_page => ''VORSCHRIFT''',
'    , p_items => ''P41_VORSCHRIFTID''',
'    , p_values => :P41_VORSCHRIFTID',
'    , p_session => null',
'    , p_clear_cache => ''25''',
');',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2678507144853167805
);
wwv_flow_imp.component_end;
end;
/
