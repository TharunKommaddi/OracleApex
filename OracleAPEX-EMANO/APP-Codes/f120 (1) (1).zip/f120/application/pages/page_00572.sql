prompt --application/pages/page_00572
begin
--   Manifest
--     PAGE: 00572
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>572
,p_name=>'Vorschriften'
,p_alias=>'VORSCHRIFTEN1'
,p_page_mode=>'MODAL'
,p_step_title=>'Vorschriften'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'450'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13052325951027051317)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(637561291400734979)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13052326000501051317)
,p_plug_name=>'Vorschriften'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(916342375304945403)
,p_plug_name=>'&nbsp;'
,p_parent_plug_id=>wwv_flow_imp.id(13052326000501051317)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>110
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="t-Alert t-Alert--warning t-Alert--horizontal t-Alert--defaultIcons">',
'    <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon"><span class="t-Icon"></span></div>',
'        <div class="t-Alert-content">',
'            <div class="t-Alert-header"><h2 class="t-Alert-title">Klonmodus aktiv</h2></div>',
unistr('            <div class="t-Alert-body">Die Vorschriftenauswahl wurde aus Ticket &P581_CLONE_SOURCE_TICKET. \00FCbernommen und ist schreibgesch\00FCtzt.</div>'),
'        </div>',
'    </div>',
'</div>'))
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P581_IS_CLONE'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13052326144554051317)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1006026606445062500)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(13052326144554051317)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1006026126645062500)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(13052326144554051317)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Zusammenfassung'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1006025813523062499)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(13052326144554051317)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1006021149666062497)
,p_branch_name=>'Go To Page 573'
,p_branch_action=>'f?p=&APP_ID.:574:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1006026126645062500)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1006021557914062497)
,p_branch_action=>'f?p=&APP_ID.:571:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1006025813523062499)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006030063294062502)
,p_name=>'P572_MASTER_VORSCHRIFTID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(13052326000501051317)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Hauptvorschrift f\00FCr MfV (Jira-Datengrundlage)')
,p_source=>'P25_VORSCHRIFTID'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vorschrift_nummer, vorschriftid',
'from t_vorschrift'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006029637968062501)
,p_name=>'P572_OLD_VORSCHRIFTEN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(13052326000501051317)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (Select vorschrift_nummer',
'    from t_vorschrift_ref_vorschrift tvrv',
'    join t_vorschrift tv on (tvrv.VORGAENGER_VORSCHRIFTID = tv.vorschriftid)',
'    where  beziehung_art = 10 and nachfolger_vorschriftid =:P572_MASTER_VORSCHRIFTID',
'    )',
'    Select nvl(listagg(vorschrift_nummer, '', '') ,',
unistr('        emano_util.fLang(''Es wurde keine Vorschrift in RegIndex als Vorg\00E4nger hinterlegt'', ''No rule has been registered in RegIndex as a predecessor'')) as mesage'),
'        ',
'    from cte1'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>unistr('Verlinkte Vorg\00E4ngervorschrift')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P570_MFV_TYP'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006029256487062501)
,p_name=>'P572_SEL_VORSCHRIFTID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(13052326000501051317)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006028879806062501)
,p_name=>'P572_FOR_ONE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(13052326000501051317)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_result NUMBER;',
'BEGIN',
'    -- If cloning, get value from source ticket',
'    IF :P581_IS_CLONE = 1 AND :P581_CLONE_SOURCE_TICKET IS NOT NULL THEN',
'        -- Check if source ticket has multiple regulations',
'        SELECT CASE WHEN COUNT(*) > 1 THEN 0 ELSE 1 END',
'        INTO l_result',
'        FROM t_mfv_ref_vorschrift tmrv',
'        JOIN t_mfv tm ON (tmrv.mfvid = tm.mfvid)',
'        WHERE tm.jira_ticket = :P581_CLONE_SOURCE_TICKET;',
'    ELSE',
'        l_result := 1; -- Default: single regulation',
'    END IF;',
'    ',
'    RETURN l_result;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        RETURN 1;',
'END;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>unistr('<span Style="font-size:14px"><b>M\00F6chtest Du nur f\00FCr eine Vorschrift die MfV erstellen?</b></span>')
,p_display_as=>'NATIVE_YES_NO'
,p_grid_label_column_span=>2
,p_read_only_when=>'P581_IS_CLONE'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:margin-top-lg'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Nein',
  'off_value', '0',
  'on_label', 'Ja',
  'on_value', '1',
  'use_defaults', 'N')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- deafult 1',
'1'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006028442758062501)
,p_name=>'P572_SELECT_SLAVE_DISP'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(13052326000501051317)
,p_item_default=>unistr('<b>Bitte w\00E4hlen Sie ihre zus\00E4tzlichen Vorschriften f\00FCr die MfV aus dem Dropdown</b>')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006028050851062501)
,p_name=>'P572_VORSCHRIFTEN_SEL'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(13052326000501051317)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_result VARCHAR2(4000);',
'BEGIN',
'    -- If cloning, get additional regulations from source ticket',
'    IF :P581_IS_CLONE = 1 AND :P581_CLONE_SOURCE_TICKET IS NOT NULL THEN',
'        SELECT LISTAGG(tmrv.vorschriftid, '':'') WITHIN GROUP (ORDER BY tmrv.vorschriftid)',
'        INTO l_result',
'        FROM t_mfv_ref_vorschrift tmrv',
'        JOIN t_mfv tm ON (tmrv.mfvid = tm.mfvid)',
'        WHERE tm.jira_ticket = :P581_CLONE_SOURCE_TICKET',
'          AND tmrv.vorschriftid != :P572_MASTER_VORSCHRIFTID;',
'    ELSE',
'        l_result := NULL;',
'    END IF;',
'    ',
'    RETURN l_result;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        RETURN NULL;',
'END;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Betroffene Vorschriften'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CASE WHEN p.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND v.DOKUMENTENDATUM IS NOT NULL',
'            THEN v.VORSCHRIFT_NUMMER || ''_'' || TO_CHAR(v.DOKUMENTENDATUM, ''DD.MM.YYYY'') || '' - '' || v.VORSCHRIFT_BEZEICHNUNG',
'            ELSE v.VORSCHRIFT_NUMMER || '' - '' || v.VORSCHRIFT_BEZEICHNUNG ',
'       END as d,',
'       v.VORSCHRIFTID as r',
'FROM T_VORSCHRIFT v',
'LEFT JOIN T_PUBLISHER p ON v.PUBLISHERID = p.PUBLISHERID  ',
'WHERE v.VORSCHRIFTID != :P572_MASTER_VORSCHRIFTID',
'ORDER BY 1'))
,p_lov_cascade_parent_items=>'P572_MASTER_VORSCHRIFTID'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_read_only_when=>'P581_IS_CLONE'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'11 july ',
'',
'select VORSCHRIFT_NUMMER || '' - '' || VORSCHRIFT_BEZEICHNUNG d,',
'       VORSCHRIFTID as r',
'  from T_VORSCHRIFT where vorschriftid != :P572_MASTER_VORSCHRIFTID',
' order by 1',
'',
'',
' -- 05.02.2026 -defau;lt nothings i sthere '))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006027647900062500)
,p_name=>'P572_EIN_VORSCHRIFT'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(13052326000501051317)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006027237411062500)
,p_name=>'P572_HINWEIS'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(13052326000501051317)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT emano_util.fLang(',
'    ''Sie haben die Vorschrift '' || ',
'    (SELECT vorschrift_nummer FROM t_vorschrift WHERE vorschriftid = :P572_MASTER_VORSCHRIFTID) || ',
unistr('    '' als Hauptvorschrift f\00FCr Ihre MfV gew\00E4hlt.'' || CHR(10) || CHR(13) ||'),
unistr('    ''Wenn Sie diese Vorschrift nicht als Hauptvorschrift verwenden m\00F6chten, m\00FCssen Sie den Ticket-Assistenten abbrechen! Bitte suchen Sie anschlie\00DFend Ihre Hauptvorschrift und starten Sie den Assistenten neu!'','),
'    ''You have selected the regulation '' || ',
'    (SELECT vorschrift_nummer FROM t_vorschrift WHERE vorschriftid = :P572_MASTER_VORSCHRIFTID) || ',
'    '' as the main regulation for your MfV.'' || CHR(10) || CHR(13) ||',
'    ''If you do not want to use this regulation as the main regulation, you must cancel the ticket assistant! Please then search for your main regulation and restart the assistant!''',
') AS message',
'FROM dual;',
''))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Hinweis'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'Y',
  'character_counter', 'N',
  'resizable', 'N',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1006025278818062499)
,p_validation_name=>'Slave Not Empty'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'case when (:P572_VORSCHRIFTEN_SEL IS NULL OR LENGTH(:P572_VORSCHRIFTEN_SEL)  =0)',
'   THEN false',
'   else true end'))
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Mindestens 1 Vorschrift muss gew\00E4hlt werden')
,p_validation_condition=>'P572_FOR_ONE'
,p_validation_condition2=>'0'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(1006026126645062500)
,p_associated_item=>wwv_flow_imp.id(1006028050851062501)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1006024996039062499)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1006026606445062500)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006024499342062499)
,p_event_id=>wwv_flow_imp.id(1006024996039062499)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1006024061720062498)
,p_name=>'Change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P572_FOR_ONE'
,p_condition_element=>'P572_FOR_ONE'
,p_triggering_condition_type=>'NOT_EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006023518515062498)
,p_event_id=>wwv_flow_imp.id(1006024061720062498)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P572_VORSCHRIFTEN_SEL'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$s(''P572_VORSCHRIFTEN_SEL'',null)'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006023078894062498)
,p_event_id=>wwv_flow_imp.id(1006024061720062498)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P572_VORSCHRIFTEN_SEL'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$s(''P572_VORSCHRIFTEN_SEL'',null)'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006022553100062497)
,p_event_id=>wwv_flow_imp.id(1006024061720062498)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P572_HINWEIS,P572_SELECT_SLAVE_DISP,P572_VORSCHRIFTEN_SEL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006022078473062497)
,p_event_id=>wwv_flow_imp.id(1006024061720062498)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P572_HINWEIS,P572_SELECT_SLAVE_DISP,P572_VORSCHRIFTEN_SEL'
);
wwv_flow_imp.component_end;
end;
/
