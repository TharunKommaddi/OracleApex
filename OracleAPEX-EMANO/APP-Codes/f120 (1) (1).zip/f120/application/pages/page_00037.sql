prompt --application/pages/page_00037
begin
--   Manifest
--     PAGE: 00037
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>37
,p_name=>'Einsatzdaten bearbeiten'
,p_alias=>'EINSATZDATEN-BEARBEITEN'
,p_page_mode=>'MODAL'
,p_step_title=>'Einsatzdaten bearbeiten'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* dialog title */',
'/* .getexlogo::after {',
'    content: ''GETEX'';',
'    position: absolute;',
'    right: 20px;',
'    color: #0000ff82;',
'    font-weight: bold;',
'    top: 15px;',
'    font-size: 20px;',
'    font-family: ''Audi Type Extended'';',
'}',
'',
'.ui-dialog-title.getexlogo::after {',
'    top: 0;',
'    right: 50px;',
'} */'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_dialog_width=>'900'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19586454172225946775)
,p_plug_name=>'Buttons'
,p_region_name=>'rEinsatzdaten'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>80
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1019089463343189536)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(19586454172225946775)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1019089881782189537)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(19586454172225946775)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3095365701599678233)
,p_name=>'P37_FAHRZEUGKLASSE_NAME'
,p_item_sequence=>60
,p_use_cache_before_default=>'NO'
,p_prompt=>'FahrzeugTyp'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung ',
'from T_Fahrzeugklasse ',
'where fahrzeugklasseid = :P37_FAHRZEUGKLASSEID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019089104611189536)
,p_name=>'P37_VORSCHRIFTID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019088627514189535)
,p_name=>'P37_EINSATZDATUM_TYPID'
,p_item_sequence=>70
,p_prompt=>'Einsatzdatum Typ'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT einsatzdatum_typ AS d, ',
'       einsatzdatum_typid AS r',
'FROM t_einsatzdatum_typ',
'ORDER BY sortorder'))
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT einsatzdatum_typ AS d, ',
'       einsatzdatum_typid AS r',
'FROM t_einsatzdatum_typ',
'ORDER BY sortorder'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019088306150189535)
,p_name=>'P37_VORSCHRIFT_NUMMER'
,p_item_sequence=>80
,p_prompt=>'Vorschrift Nummer'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019087826362189534)
,p_name=>'P37_PUBLISHER'
,p_item_sequence=>90
,p_use_cache_before_default=>'NO'
,p_prompt=>'Publisher'
,p_source=>'SELECT publisher FROM t_vorschrift WHERE vorschriftid = :P37_VORSCHRIFTID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019087501248189534)
,p_name=>'P37_EINSATZDATUM_MODELLID'
,p_item_sequence=>100
,p_prompt=>'EINSATZDATUM_MODELLID'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019087034513189534)
,p_name=>'P37_DATUM_ANGABE_AS_MJ'
,p_item_sequence=>110
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>'Datumsformat Modelljahr ?'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mj_schalter_status from t_vorschrift ',
'where vorschriftid = :P37_vorschriftID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Ja;1,Nein;0'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'read only item ! = value edit mode  1 ',
'',
'',
'',
'',
'',
'declare',
'l_value number;',
'begin',
'',
'if :P34_STRG_GETEX_ANZEIGE =20 then l_value :=0;',
'elsif :P34_STRG_GETEX_ANZEIGE !=20 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0  then',
' l_value :=1;',
'else l_value :=0;',
'end if;',
'',
'if l_value =0 then return (true);',
'else return(false);',
'end if;',
'',
'end;',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019086683668189533)
,p_name=>'P37_MODELJAHR'
,p_item_sequence=>120
,p_prompt=>'Modelljahr'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- :P37_DATUM_ANGABE_AS_MJ = 0 OR ',
'',
'',
':P37_EINSATZDATUM_TYPID NOT IN (1030, 1031, 1041) OR pck_ri.fIsUserInRolle(listRolleId => 1080) = 0'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- :P37_DATUM_ANGABE_AS_MJ = 0 OR ',
'',
':P37_EINSATZDATUM_TYPID NOT IN (1030, 1031, 1041) OR pck_ri.fIsUserInRolle(listRolleId => 1080) = 0'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019086271259189533)
,p_name=>'P37_EINSATZDATUM'
,p_item_sequence=>130
,p_prompt=>'Einsatzdatum'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- :P37_DATUM_ANGABE_AS_MJ = 1 ',
'-- OR ',
'',
'',
'(:P37_MASTER IN (20, 30)) OR',
'(:P37_EINSATZDATUM_TYPID = 1041 AND pck_ri.fIsUserInRolle(listRolleId => ''1000:1080'') = 0) ',
'OR (:P37_EINSATZDATUM_TYPID != 1041 AND pck_ri.fIsUserInRolle(listRolleId => ''1080'') = 0)'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019085838650189533)
,p_name=>'P37_EINSATZDATUM_TEXT'
,p_item_sequence=>140
,p_prompt=>'Bemerkung Datum'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 1000 = VKO role, 1003 = Fachadmin role',
'pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') = 0'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019085514588189533)
,p_name=>'P37_MANUELLE_EINTRAGUNG'
,p_item_sequence=>150
,p_item_default=>'10'
,p_prompt=>'Manuelle Eintragung'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Ja;10,Nein;0'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P37_MASTER IN (20, 30))',
'OR',
'(pck_ri.fIsUserInRolle(listRolleId => ''1080'') = 0)'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019085091065189533)
,p_name=>'P37_LETZTE_AENDERUNG_DATUM'
,p_item_sequence=>160
,p_prompt=>unistr('Letzte \00C4nderung Datum')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019084681753189532)
,p_name=>'P37_LETZTE_AENDERUNG_BENUTZER'
,p_item_sequence=>170
,p_prompt=>unistr('Letzte \00C4nderung Benutzer')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019016058843583091)
,p_name=>'P37_FAHRZEUGKLASSEID'
,p_item_sequence=>50
,p_use_cache_before_default=>'NO'
,p_item_default=>'1024'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(997483189964919434)
,p_name=>'P37_MASTER'
,p_item_sequence=>40
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT MASTER',
'FROM t_vorschrift',
'WHERE vorschriftid = :P37_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1019082710430189529)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1019089463343189536)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1019082198406189529)
,p_event_id=>wwv_flow_imp.id(1019082710430189529)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1019081786640189528)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P37_EINSATZDATUM_TYPID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1019081273654189528)
,p_event_id=>wwv_flow_imp.id(1019081786640189528)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Get the selected date type ID',
'var dateTypeId = $v("P37_EINSATZDATUM_TYPID");',
'',
unistr('// If it''s the Au\00DFerkraftsetzungsdatum (1041)'),
'if (dateTypeId == "1041") {',
'  // Make an AJAX call to check if user has VKO role',
'  apex.server.process(',
'    "Check_If_Has_VKO_Role",',
'    {},',
'    {',
'      success: function(pData) {',
'        if (pData.hasVKORole !== true) {',
'          // Show error and reset the selection',
unistr('          apex.message.alert("Sie haben nicht die Berechtigung, das Au\00DFerkraftsetzungsdatum zu bearbeiten.");'),
'          apex.item("P37_EINSATZDATUM_TYPID").setValue(null);',
'          apex.item("P37_EINSATZDATUM").setValue(null);',
'          apex.item("P37_EINSATZDATUM_TEXT").setValue(null);',
'          apex.item("P37_MANUELLE_EINTRAGUNG").setValue(10);',
'        }',
'      }',
'    }',
'  );',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1019080808579189528)
,p_event_id=>wwv_flow_imp.id(1019081786640189528)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  SELECT TO_CHAR(einsatzdatum, ''DD.MM.YYYY''),',
'         einsatzdatum_text,',
'         manuelle_eintragung',
'  INTO :P37_EINSATZDATUM,',
'       :P37_EINSATZDATUM_TEXT,',
'       :P37_MANUELLE_EINTRAGUNG',
'  FROM T_VORSCHRIFT_REF_EINSATZDATUM_TYP',
'  WHERE vorschriftid = :P37_VORSCHRIFTID',
'    AND einsatzdatum_typid = :P37_EINSATZDATUM_TYPID;',
'EXCEPTION',
'  WHEN NO_DATA_FOUND THEN',
'    :P37_EINSATZDATUM := NULL;',
'    :P37_EINSATZDATUM_TEXT := NULL;',
'    :P37_MANUELLE_EINTRAGUNG := 10;',
'END;'))
,p_attribute_02=>'P37_VORSCHRIFTID,P37_EINSATZDATUM_TYPID'
,p_attribute_03=>'P37_EINSATZDATUM,P37_EINSATZDATUM_TEXT,P37_MANUELLE_EINTRAGUNG'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1019080272187189528)
,p_event_id=>wwv_flow_imp.id(1019081786640189528)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'wokring withtou vko'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  SELECT TO_CHAR(einsatzdatum, ''DD.MM.YYYY''),',
'         einsatzdatum_text,',
'         manuelle_eintragung',
'  INTO :P37_EINSATZDATUM,',
'       :P37_EINSATZDATUM_TEXT,',
'       :P37_MANUELLE_EINTRAGUNG',
'  FROM T_VORSCHRIFT_REF_EINSATZDATUM_TYP',
'  WHERE vorschriftid = :P37_VORSCHRIFTID',
'    AND einsatzdatum_typid = :P37_EINSATZDATUM_TYPID;',
'EXCEPTION',
'  WHEN NO_DATA_FOUND THEN',
'    :P37_EINSATZDATUM := NULL;',
'    :P37_EINSATZDATUM_TEXT := NULL;',
'    :P37_MANUELLE_EINTRAGUNG := 10;',
'END;'))
,p_attribute_02=>'P37_VORSCHRIFTID,P37_EINSATZDATUM_TYPID'
,p_attribute_03=>'P37_EINSATZDATUM,P37_EINSATZDATUM_TEXT,P37_MANUELLE_EINTRAGUNG'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1019079830476189527)
,p_name=>'Change Value'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P37_DATUM_ANGABE_AS_MJ'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1019079361296189527)
,p_event_id=>wwv_flow_imp.id(1019079830476189527)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1019078987198189527)
,p_name=>'SET GETEX Logo'
,p_event_sequence=>50
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NEVER'
,p_da_event_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'( (20 = :P34_STRG_GETEX_ANZEIGE ) ',
'and (:P34_EDIT_MODE is not null) and (1 =:P34_EDIT_MODE )',
')'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1019078488142189526)
,p_event_id=>wwv_flow_imp.id(1019078987198189527)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'.ui-dialog-title'
,p_attribute_01=>'getexlogo'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1013004293781994333)
,p_name=>'Set Initial Field Visibility'
,p_event_sequence=>60
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// 1030 = Einsatzzeitpunkt',
'$v("P37_EINSATZDATUM_TYPID") == "1030" && $v("P37_DATUM_ANGABE_AS_MJ") == "1"',
''))
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013004176647994332)
,p_event_id=>wwv_flow_imp.id(1013004293781994333)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P37_MODELJAHR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013003909676994329)
,p_event_id=>wwv_flow_imp.id(1013004293781994333)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P37_EINSATZDATUM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013004060574994331)
,p_event_id=>wwv_flow_imp.id(1013004293781994333)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P37_MODELJAHR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013003954682994330)
,p_event_id=>wwv_flow_imp.id(1013004293781994333)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P37_EINSATZDATUM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1019083883725189531)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save Einsatzdaten'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_calculated_einsatzdatum DATE;',
'    l_calculated_modeljahr DATE;',
'    l_fahrzeugklasseid NUMBER;',
'    l_vorschriftid T_VORSCHRIFT.VORSCHRIFTID%TYPE := :P37_VORSCHRIFTID;',
'    l_einsatzdatum_typid T_EINSATZDATUM_TYP.EINSATZDATUM_TYPID%TYPE := :P37_EINSATZDATUM_TYPID;',
'    l_input_einsatzdatum VARCHAR2(10) := :P37_EINSATZDATUM;',
'    l_input_modeljahr VARCHAR2(4) := :P37_MODELJAHR;',
'    l_mode_is_modeljahr NUMBER := NVL(:P37_DATUM_ANGABE_AS_MJ, 0);',
'    l_einsatzdatum_text T_VORSCHRIFT_REF_EINSATZDATUM_TYP.EINSATZDATUM_TEXT%TYPE := :P37_EINSATZDATUM_TEXT;',
'    l_manuelle_eintragung NUMBER := NVL(:P37_MANUELLE_EINTRAGUNG, 10);',
'',
'BEGIN',
unistr('    -- Force manual flag to "ja" (10) for VKO users and Au\00DFerkraftsetzungsdatum'),
'    IF :P37_EINSATZDATUM_TYPID = 1041 AND pck_ri.fIsUserInRolle(listRolleId => ''1000'') > 0 THEN',
'         :P37_MANUELLE_EINTRAGUNG := 10;',
'    END IF;',
'',
'    -- Determine FAHRZEUGKLASSEID based on EINSATZDATUM_TYPID',
unistr('    -- For Inkraftsetzung (1000) and Au\00DFerkraftsetzung (1041), Datum Au\00DFer Kraft FBU(1060) , '),
unistr('        -- Datum Au\00DFer Kraft CKD(1063)always use NULL'),
'    IF :P37_EINSATZDATUM_TYPID IN (1000, 1041, 1060, 1063) THEN',
'        l_fahrzeugklasseid := NULL;',
'    ELSE',
'        if ( :P37_FAHRZEUGKLASSEID is null) then ',
'          l_fahrzeugklasseid := 1024 ;  -- PKW',
'        else',
'          l_fahrzeugklasseid := :P37_FAHRZEUGKLASSEID;',
'        END IF;',
'    END IF;',
'',
'    -- Calculate the correct Einsatzdatum based on mode and type',
'    IF :P37_MODELJAHR IS NOT NULL THEN',
'        -- Model Year mode calculations',
'        CASE :P37_EINSATZDATUM_TYPID',
'            WHEN 1031 THEN ',
'                l_calculated_einsatzdatum := TO_DATE(''31.12.'' || :P37_MODELJAHR, ''DD.MM.YYYY'');',
'            WHEN 1041 THEN ',
'                l_calculated_einsatzdatum := TO_DATE(''01.01.'' || TO_CHAR(TO_NUMBER(:P37_MODELJAHR) + 1), ''DD.MM.YYYY'');',
'            WHEN 1030 THEN ',
'                l_calculated_einsatzdatum := null;-- TO_DATE(''02.01.'' || :P37_MODELJAHR, ''DD.MM.YYYY'');',
'            ELSE',
'                l_calculated_einsatzdatum := TO_DATE(:P37_EINSATZDATUM, ''DD.MM.YYYY'');',
'        END CASE;',
'        ',
'        -- Set model year',
'        IF :P37_EINSATZDATUM_TYPID IN (1030, 1031) THEN',
'            l_calculated_modeljahr := TO_DATE(''02.01.'' || :P37_MODELJAHR, ''dd.mm.YYYY'');',
'           -- debug('' P37: l_calcul_Modeljahr:= '' || l_calculated_modeljahr);',
'        ELSE',
'            l_calculated_modeljahr := NULL;',
'        END IF;',
'    ELSE',
'        -- Regular date mode',
'        IF :P37_EINSATZDATUM IS NOT NULL THEN',
'            l_calculated_einsatzdatum := TO_DATE(:P37_EINSATZDATUM, ''DD.MM.YYYY'');',
'        ELSE',
'            l_calculated_einsatzdatum := NULL;',
'        END IF;',
'        l_calculated_modeljahr := NULL;',
'    END IF;',
'    ',
'    -- Update T_VORSCHRIFT_REF_EINSATZDATUM_TYP with calculated values',
'    MERGE INTO t_vorschrift_ref_einsatzdatum_typ dest',
'    USING (SELECT :P37_VORSCHRIFTID AS vorschriftid,',
'                  :P37_EINSATZDATUM_TYPID AS einsatzdatum_typid,',
'                  l_fahrzeugklasseid AS fahrzeugklasseid,',
'                  l_calculated_einsatzdatum AS einsatzdatum,',
'                  :P37_EINSATZDATUM_TEXT AS einsatzdatum_text,',
'                  :P37_MANUELLE_EINTRAGUNG AS manuelle_eintragung,',
'                  l_calculated_modeljahr AS modeljahr,',
'                  SYSDATE AS letzte_aenderung_datum,',
'                  :G_BENUTZERID AS letzte_aenderung_benutzerid',
'            FROM dual) src',
'    ON (dest.vorschriftid = src.vorschriftid AND',
'        dest.einsatzdatum_typid = src.einsatzdatum_typid AND',
'        NVL(dest.fahrzeugklasseid, -1) = NVL(src.fahrzeugklasseid, -1))',
'    WHEN MATCHED THEN',
'        UPDATE SET einsatzdatum = nvl(src.einsatzdatum, null),',
'                   einsatzdatum_text = src.einsatzdatum_text,',
'                   manuelle_eintragung = src.manuelle_eintragung,',
'                   modeljahr = src.modeljahr,',
'                   ',
'                   letzte_aenderung_datum = src.letzte_aenderung_datum,',
'                   letzte_aenderung_benutzerid = src.letzte_aenderung_benutzerid',
'    WHEN NOT MATCHED THEN',
'        INSERT (vorschriftid, einsatzdatum_typid, fahrzeugklasseid, einsatzdatum, einsatzdatum_text, ',
'                manuelle_eintragung, modeljahr, letzte_aenderung_datum, letzte_aenderung_benutzerid)',
'        VALUES (src.vorschriftid, src.einsatzdatum_typid, src.fahrzeugklasseid, src.einsatzdatum, ',
'                src.einsatzdatum_text, src.manuelle_eintragung, src.modeljahr,',
'                src.letzte_aenderung_datum, src.letzte_aenderung_benutzerid);',
'   ',
'',
unistr('      -- Aktualisiere Status der Verkn\00FCpf bei Au\00DFerkraft Setzung'),
'    if (l_calculated_einsatzdatum is not null and l_calculated_einsatzdatum <= sysdate',
'         and :P37_EINSATZDATUM_TYPID in (1041, 1063, 1060)',
'       ) then',
'            UPDATE  t_vorschrift_ref_vorschrift set  status = 20',
'           where  beziehung_art  in (40, 102) and (nachfolger_vorschriftid  = :P37_VORSCHRIFTID  ) --or vorgaenger_vorschriftid = :P37_VORSCHRIFTID)',
'            and :P37_VORSCHRIFTID in ( select vre.vorschriftid ',
'                                        from t_vorschrift_ref_einsatzdatum_typ vre ',
'                                         join t_vorschrift v  on (v.vorschriftid = vre.vorschriftid)',
'                                        where ( v.einsatzdatum_modellID  in (10, 30) and',
'                                           vre.einsatzdatum_typid = 1041 and trunc(vre.einsatzdatum) <= sysdate )',
'                                        OR ( v.einsatzdatum_modellID  in (20) and',
'                                           vre.einsatzdatum_typid  in (1060, 1063) and trunc(vre.einsatzdatum) <= sysdate )',
'                                    )',
'            and status not in ( 20, 30);',
unistr('    -- aktualisiere status der Verkn\00FCpf wenn nicht mehr anwendbar, bzw. das gleiche f\00FCr CKD, FBU'),
'    elsif (l_calculated_einsatzdatum is not null and l_calculated_einsatzdatum <= sysdate',
'         and :P37_EINSATZDATUM_TYPID in (1051, 1071, 1073)',
'       ) then',
'            UPDATE  t_vorschrift_ref_vorschrift set  status = 30',
'           where  beziehung_art  in (40, 102) and (nachfolger_vorschriftid  = :P37_VORSCHRIFTID ) --or vorgaenger_vorschriftid = :P37_VORSCHRIFTID)',
'            and :P37_VORSCHRIFTID in ( select vre.vorschriftid ',
'                                        from t_vorschrift_ref_einsatzdatum_typ vre ',
'                                         join t_vorschrift v  on (v.vorschriftid = vre.vorschriftid)',
'                                        where ( v.einsatzdatum_modellID  in (10, 30) and',
'                                           vre.einsatzdatum_typid = 1051 and trunc(vre.einsatzdatum) <= sysdate )',
'                                        OR ( v.einsatzdatum_modellID  in (20) and',
'                                           vre.einsatzdatum_typid  in (1071, 1073) and trunc(vre.einsatzdatum) <= sysdate )',
'                                    )',
'            and status not in ( 20, 30);',
unistr('     -- Aktualisiere Status der Verkn\00FCpf bei Au\00DFerkraft Setzung > sysdate'),
'    elsif ( (l_calculated_einsatzdatum is null or trunc(l_calculated_einsatzdatum) > sysdate )',
'           and :P37_EINSATZDATUM_TYPID in (1041, 1063, 1060)',
'       ) then',
'         -- debug(''P37:einsatzdatum ='' || nvl(l_calculated_einsatzdatum, null) );',
'            UPDATE  t_vorschrift_ref_vorschrift set  status = 10',
'           where  beziehung_art  in (40, 102) and (nachfolger_vorschriftid  = :P37_VORSCHRIFTID ) -- or vorgaenger_vorschriftid = :P37_VORSCHRIFTID)',
'            and :P37_VORSCHRIFTID in ( select vre.vorschriftid ',
'                                        from t_vorschrift_ref_einsatzdatum_typ vre ',
'                                         join t_vorschrift v  on (v.vorschriftid = vre.vorschriftid)',
'                                        where ( v.einsatzdatum_modellID  in (10, 30) and',
'                                                vre.einsatzdatum_typid = 1041 and (vre.einsatzdatum is null or trunc(vre.einsatzdatum) > sysdate) )',
'                                        OR ( v.einsatzdatum_modellID  in (20) and',
'                                             vre.einsatzdatum_typid  in (1060, 1063) and (vre.einsatzdatum is null or trunc(vre.einsatzdatum) > sysdate ))',
'                                    )',
'            and status in ( 20);',
unistr('    -- aktualisiere status der Verkn\00FCpf wenn nicht mehr anwendbar, bzw. das gleiche f\00FCr CKD, FBU'),
'    elsif ( (l_calculated_einsatzdatum is null or trunc(l_calculated_einsatzdatum) > sysdate)',
'           and :P37_EINSATZDATUM_TYPID in (1051, 1071, 1073)',
'       ) then',
'            UPDATE  t_vorschrift_ref_vorschrift set  status = 10',
'           where  beziehung_art  in (40, 102) and (nachfolger_vorschriftid  = :P37_VORSCHRIFTID ) --or vorgaenger_vorschriftid = :P37_VORSCHRIFTID)',
'            and :P37_VORSCHRIFTID in ( select vre.vorschriftid ',
'                                        from t_vorschrift_ref_einsatzdatum_typ vre ',
'                                         join t_vorschrift v  on (v.vorschriftid = vre.vorschriftid)',
'                                        where ( v.einsatzdatum_modellID  in (10, 30) and',
'                                           vre.einsatzdatum_typid = 1051 and (vre.einsatzdatum is null or trunc(vre.einsatzdatum) > sysdate) )',
'                                        OR ( v.einsatzdatum_modellID  in (20) and',
'                                           vre.einsatzdatum_typid  in (1071, 1073) and (vre.einsatzdatum is null or trunc(vre.einsatzdatum) > sysdate) )',
'                                    )',
'            and status in ( 30);',
'    END IF;',
'',
unistr('     -- L\00D6SCHE EINTR\00C4GE MIT LEEREN EINSATZDATEN'),
'      delete from t_vorschrift_ref_einsatzdatum_typ where VORSCHRIFTID = :P37_VORSCHRIFTID and (einsatzdatum is null and modeljahr is null);',
'      ',
'    -- Call notification procedure',
'    PCK_RI_BENACHRICHTIGUNG.pBenachricht_Mfv_Arbeitskreise(',
'        :P37_VORSCHRIFTID, ',
'        emano_util.fLang(''Datum'', ''Date''), ',
'        :G_BENUTZERID',
'    );',
'    ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1019089881782189537)
,p_internal_uid=>2653128432174198704
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'   IF :P37_VORSCHRIFTID IS NOT NULL AND :P37_EINSATZDATUM_TYPID IS NOT NULL THEN ',
unistr('      -- When VKO user enters Au\00DFerkraftsetzungsdatum, force manual flag to "ja" (10)'),
'      IF :P37_EINSATZDATUM_TYPID = 1041 AND pck_ri.fIsUserInRolle(listRolleId => ''1000'') > 0 THEN',
'         :P37_MANUELLE_EINTRAGUNG := 10;',
'      END IF;',
'      ',
'      MERGE INTO t_vorschrift_ref_einsatzdatum_typ dest',
'      USING (SELECT :P37_VORSCHRIFTID AS vorschriftid,',
'                    :P37_EINSATZDATUM_TYPID AS einsatzdatum_typid,',
'                    TO_DATE(:P37_EINSATZDATUM, ''DD.MM.YYYY'') AS einsatzdatum,',
'                    :P37_EINSATZDATUM_TEXT AS einsatzdatum_text,',
'                    :P37_MANUELLE_EINTRAGUNG AS manuelle_eintragung,',
'                    SYSDATE AS letzte_aenderung_datum,',
'                    apex_util.get_current_user_id AS letzte_aenderung_benutzerid',
'             FROM dual) src',
'      ON (dest.vorschriftid = src.vorschriftid AND',
'          dest.einsatzdatum_typid = src.einsatzdatum_typid)',
'      WHEN MATCHED THEN',
'          UPDATE SET einsatzdatum = src.einsatzdatum,',
'                     einsatzdatum_text = src.einsatzdatum_text,',
'                     manuelle_eintragung = src.manuelle_eintragung,',
'                     letzte_aenderung_datum = src.letzte_aenderung_datum,',
'                     letzte_aenderung_benutzerid = src.letzte_aenderung_benutzerid',
'      WHEN NOT MATCHED THEN',
'          INSERT (vorschriftid, einsatzdatum_typid, einsatzdatum, einsatzdatum_text, ',
'                  manuelle_eintragung, letzte_aenderung_datum, letzte_aenderung_benutzerid)',
'          VALUES (src.vorschriftid, src.einsatzdatum_typid, src.einsatzdatum, ',
'                  src.einsatzdatum_text, src.manuelle_eintragung, ',
'                  src.letzte_aenderung_datum, src.letzte_aenderung_benutzerid);',
'      ',
'',
'   END IF;',
'END;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1016889718045243325)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save Einsatzdaten_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_calculated_einsatzdatum DATE;',
'    l_calculated_modeljahr DATE;',
'    l_vorschriftid T_VORSCHRIFT.VORSCHRIFTID%TYPE := :P37_VORSCHRIFTID;',
'    l_einsatzdatum_typid T_EINSATZDATUM_TYP.EINSATZDATUM_TYPID%TYPE := :P37_EINSATZDATUM_TYPID;',
'    l_input_einsatzdatum VARCHAR2(10) := :P37_EINSATZDATUM;',
'    l_input_modeljahr VARCHAR2(4) := :P37_MODELJAHR;',
'    l_mode_is_modeljahr NUMBER := NVL(:P37_DATUM_ANGABE_AS_MJ, 0);',
'    l_einsatzdatum_text T_VORSCHRIFT_REF_EINSATZDATUM_TYP.EINSATZDATUM_TEXT%TYPE := :P37_EINSATZDATUM_TEXT;',
'    l_manuelle_eintragung NUMBER := NVL(:P37_MANUELLE_EINTRAGUNG, 10);',
'',
'BEGIN',
unistr('    -- Force manual flag to "ja" (10) for VKO users and Au\00DFerkraftsetzungsdatum'),
'    IF :P37_EINSATZDATUM_TYPID = 1041 AND pck_ri.fIsUserInRolle(listRolleId => ''1000'') > 0 THEN',
'         :P37_MANUELLE_EINTRAGUNG := 10;',
'    END IF;',
'',
'    -- Calculate the correct Einsatzdatum based on mode and type',
'    IF :P37_DATUM_ANGABE_AS_MJ = 1 AND :P37_MODELJAHR IS NOT NULL THEN',
'        -- Model Year mode calculations',
'        CASE :P37_EINSATZDATUM_TYPID',
'            WHEN 1031 THEN ',
'                l_calculated_einsatzdatum := TO_DATE(''31.12.'' || :P37_MODELJAHR, ''DD.MM.YYYY'');',
'            WHEN 1041 THEN ',
'                l_calculated_einsatzdatum := TO_DATE(''01.01.'' || TO_CHAR(TO_NUMBER(:P37_MODELJAHR) + 1), ''DD.MM.YYYY'');',
'            WHEN 1030 THEN ',
'                l_calculated_einsatzdatum := NULL;',
'            ELSE',
'                l_calculated_einsatzdatum := TO_DATE(:P37_EINSATZDATUM, ''DD.MM.YYYY'');',
'        END CASE;',
'        ',
'        -- Set model year',
'        IF :P37_EINSATZDATUM_TYPID IN (1030, 1031, 1041) THEN',
'            l_calculated_modeljahr := TO_DATE(:P37_MODELJAHR, ''YYYY'');',
'        ELSE',
'            l_calculated_modeljahr := NULL;',
'        END IF;',
'    ELSE',
'        -- Regular date mode',
'        IF :P37_EINSATZDATUM IS NOT NULL THEN',
'            l_calculated_einsatzdatum := TO_DATE(:P37_EINSATZDATUM, ''DD.MM.YYYY'');',
'        ELSE',
'            l_calculated_einsatzdatum := NULL;',
'        END IF;',
'        l_calculated_modeljahr := NULL;',
'    END IF;',
'    ',
'    -- Update T_VORSCHRIFT_REF_EINSATZDATUM_TYP with calculated values',
'    MERGE INTO t_vorschrift_ref_einsatzdatum_typ dest',
'    USING (SELECT :P37_VORSCHRIFTID AS vorschriftid,',
'                  :P37_EINSATZDATUM_TYPID AS einsatzdatum_typid,',
'                  l_calculated_einsatzdatum AS einsatzdatum,',
'                  :P37_EINSATZDATUM_TEXT AS einsatzdatum_text,',
'                  :P37_MANUELLE_EINTRAGUNG AS manuelle_eintragung,',
'                  l_calculated_modeljahr AS modeljahr,',
'                  SYSDATE AS letzte_aenderung_datum,',
'                  :G_BENUTZERID AS letzte_aenderung_benutzerid',
'            FROM dual) src',
'    ON (dest.vorschriftid = src.vorschriftid AND',
'        dest.einsatzdatum_typid = src.einsatzdatum_typid)',
'    WHEN MATCHED THEN',
'        UPDATE SET einsatzdatum = src.einsatzdatum,',
'                   einsatzdatum_text = src.einsatzdatum_text,',
'                   manuelle_eintragung = src.manuelle_eintragung,',
'                   modeljahr = src.modeljahr,',
'                   letzte_aenderung_datum = src.letzte_aenderung_datum,',
'                   letzte_aenderung_benutzerid = src.letzte_aenderung_benutzerid',
'    WHEN NOT MATCHED THEN',
'        INSERT (vorschriftid, einsatzdatum_typid, einsatzdatum, einsatzdatum_text, ',
'                manuelle_eintragung, modeljahr, letzte_aenderung_datum, letzte_aenderung_benutzerid)',
'        VALUES (src.vorschriftid, src.einsatzdatum_typid, src.einsatzdatum, ',
'                src.einsatzdatum_text, src.manuelle_eintragung, src.modeljahr,',
'                src.letzte_aenderung_datum, src.letzte_aenderung_benutzerid);',
'',
'    -- here is  P37_DATUM_ANGABE_AS_MJ 2Read Only"  that must be used in KerndatenDialog ',
'    -- Save P37_DATUM_ANGABE_AS_MJ to T_VORSCHRIFT.MJ_SCHALTER_STATUS ',
'   /* IF :P37_EINSATZDATUM_MODELLID = 30 THEN',
'        UPDATE T_VORSCHRIFT',
'        SET MJ_SCHALTER_STATUS = :P37_DATUM_ANGABE_AS_MJ,',
'            LETZTE_AENDERUNG_DATUM = SYSDATE,',
'            LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'        WHERE VORSCHRIFTID = :P37_VORSCHRIFTID;',
'    END IF;',
'    */',
'    -- Call notification procedure',
'    PCK_RI_BENACHRICHTIGUNG.pBenachricht_Mfv_Arbeitskreise(',
'        :P37_VORSCHRIFTID, ',
'        emano_util.fLang(''Datum'', ''Date''), ',
'        :G_BENUTZERID',
'    );',
'    ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2655322597854144910
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'   IF :P37_VORSCHRIFTID IS NOT NULL AND :P37_EINSATZDATUM_TYPID IS NOT NULL THEN ',
unistr('      -- When VKO user enters Au\00DFerkraftsetzungsdatum, force manual flag to "ja" (10)'),
'      IF :P37_EINSATZDATUM_TYPID = 1041 AND pck_ri.fIsUserInRolle(listRolleId => ''1000'') > 0 THEN',
'         :P37_MANUELLE_EINTRAGUNG := 10;',
'      END IF;',
'      ',
'      MERGE INTO t_vorschrift_ref_einsatzdatum_typ dest',
'      USING (SELECT :P37_VORSCHRIFTID AS vorschriftid,',
'                    :P37_EINSATZDATUM_TYPID AS einsatzdatum_typid,',
'                    TO_DATE(:P37_EINSATZDATUM, ''DD.MM.YYYY'') AS einsatzdatum,',
'                    :P37_EINSATZDATUM_TEXT AS einsatzdatum_text,',
'                    :P37_MANUELLE_EINTRAGUNG AS manuelle_eintragung,',
'                    SYSDATE AS letzte_aenderung_datum,',
'                    apex_util.get_current_user_id AS letzte_aenderung_benutzerid',
'             FROM dual) src',
'      ON (dest.vorschriftid = src.vorschriftid AND',
'          dest.einsatzdatum_typid = src.einsatzdatum_typid)',
'      WHEN MATCHED THEN',
'          UPDATE SET einsatzdatum = src.einsatzdatum,',
'                     einsatzdatum_text = src.einsatzdatum_text,',
'                     manuelle_eintragung = src.manuelle_eintragung,',
'                     letzte_aenderung_datum = src.letzte_aenderung_datum,',
'                     letzte_aenderung_benutzerid = src.letzte_aenderung_benutzerid',
'      WHEN NOT MATCHED THEN',
'          INSERT (vorschriftid, einsatzdatum_typid, einsatzdatum, einsatzdatum_text, ',
'                  manuelle_eintragung, letzte_aenderung_datum, letzte_aenderung_benutzerid)',
'          VALUES (src.vorschriftid, src.einsatzdatum_typid, src.einsatzdatum, ',
'                  src.einsatzdatum_text, src.manuelle_eintragung, ',
'                  src.letzte_aenderung_datum, src.letzte_aenderung_benutzerid);',
'      ',
'',
'   END IF;',
'END;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1016890522721243333)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Recalculate Cockpit and GETEX Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P37_VORSCHRIFTID IS NOT NULL THEN ',
'        PCK_RI_GETEX_CTRL.pRecalculateGetexAndCockpitData(:P37_VORSCHRIFTID);',
'    END IF;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_debug.error(''Recalculation error: '' || SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1019089881782189537)
,p_internal_uid=>2655321793178144902
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1019083491512189530)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1019089881782189537)
,p_internal_uid=>2653128824387198705
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1019084256681189532)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Einsatzdaten'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  -- Initialize display items to NULL in case no IDs are passed or data isn''t found',
'  :P37_VORSCHRIFT_NUMMER := NULL;',
'  :P37_EINSATZDATUM := NULL;',
'  :P37_EINSATZDATUM_TEXT := NULL;',
'  :P37_MANUELLE_EINTRAGUNG := 10; ',
'  :P37_LETZTE_AENDERUNG_DATUM := NULL;',
'  :P37_LETZTE_AENDERUNG_BENUTZER := NULL;',
'  ',
'  if (:P37_FAHRZEUGKLASSEID is null and :P37_EINSATZDATUM_TYPID not in (1031, 1041, 1000,1060, 1063) ) THEN',
'   :P37_FAHRZEUGKLASSEID :=1024;',
'  end IF;',
'',
' --debug(''P37: P37_FAHRZEUGKLASSEID=''|| :P37_FAHRZEUGKLASSEID);',
'  -- First, try to load the Vorschrift Nummer if P37_VORSCHRIFTID is available',
'  IF :P37_VORSCHRIFTID IS NOT NULL THEN',
'    BEGIN',
'      SELECT vorschrift_nummer',
'      INTO :P37_VORSCHRIFT_NUMMER',
'      FROM t_vorschrift',
'      WHERE vorschriftid = :P37_VORSCHRIFTID;',
'    EXCEPTION',
'      WHEN NO_DATA_FOUND THEN',
'        :P37_VORSCHRIFT_NUMMER := NULL;',
'        RETURN; ',
'    END;',
'',
'    -- Then, if P37_EINSATZDATUM_TYPID is also available, load the einsatzdatum specific details',
'    IF :P37_EINSATZDATUM_TYPID IS NOT NULL THEN',
'      BEGIN',
'        SELECT TO_CHAR(vredt.einsatzdatum, ''DD.MM.YYYY''),',
'               vredt.einsatzdatum_text,',
'               vredt.manuelle_eintragung,',
'               TO_CHAR(vredt.letzte_aenderung_datum, ''DD.MM.YYYY HH24:MI:SS''),',
'               CASE',
'                 WHEN b.nachname IS NOT NULL AND b.vorname IS NOT NULL ',
'                   THEN b.nachname || '', '' || b.vorname',
'                 WHEN b.nachname IS NOT NULL ',
'                   THEN b.nachname',
'                 WHEN b.vorname IS NOT NULL ',
'                   THEN b.vorname',
'                 ELSE NULL',
'               END,',
'               TO_CHAR(vredt.Modeljahr, ''YYYY'')  ',
'               ',
'        INTO :P37_EINSATZDATUM,',
'             :P37_EINSATZDATUM_TEXT,',
'             :P37_MANUELLE_EINTRAGUNG,',
'             :P37_LETZTE_AENDERUNG_DATUM,',
'             :P37_LETZTE_AENDERUNG_BENUTZER,',
'             :P37_MODELJAHR',
'          ',
'        FROM T_VORSCHRIFT_REF_EINSATZDATUM_TYP vredt',
'        LEFT JOIN T_BENUTZER b ON b.benutzerid = vredt.letzte_aenderung_benutzerid',
'        WHERE vredt.vorschriftid = :P37_VORSCHRIFTID',
'          AND vredt.einsatzdatum_typid = :P37_EINSATZDATUM_TYPID',
'           AND  (:P37_EINSATZDATUM_TYPID in (1000, 1041, 1063, 1060) and vredt.fahrzeugklasseid is null',
'                 OR NVL(vredt.fahrzeugklasseid, -1) = NVL(:P37_FAHRZEUGKLASSEID, -1)',
'           );',
'          ',
'      EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'          -- These will be used if it''s a new entry for this typid for the given vorschriftid',
'          :P37_EINSATZDATUM := NULL;',
'          :P37_EINSATZDATUM_TEXT := NULL;',
'          :P37_MANUELLE_EINTRAGUNG := 10;',
'          :P37_LETZTE_AENDERUNG_DATUM := NULL;',
'          :P37_LETZTE_AENDERUNG_BENUTZER := NULL;',
'          --:P37_FAHRZEUGKLASSEID := NULL;',
'           --debug(''P37 :no data found'');',
'      END;',
'    END IF;',
'  END IF;',
'',
'EXCEPTION',
'  WHEN OTHERS THEN',
'',
'    apex_debug.error(''P37 Load Error: '' || SQLERRM);',
'',
'    :P37_VORSCHRIFT_NUMMER := NULL;',
'    :P37_EINSATZDATUM := NULL;',
'    :P37_EINSATZDATUM_TEXT := NULL;',
'    :P37_MANUELLE_EINTRAGUNG := NULL;',
'    :P37_LETZTE_AENDERUNG_DATUM := NULL;',
'    :P37_LETZTE_AENDERUNG_BENUTZER := NULL;',
'    RAISE; ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2653128059218198703
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- working coed withtou vko ',
'',
'BEGIN',
'  IF :P37_EINSATZDATUM_TYPID IS NOT NULL THEN',
'    SELECT TO_CHAR(einsatzdatum, ''DD.MM.YYYY''),',
'           einsatzdatum_text,',
'           manuelle_eintragung',
'    INTO :P37_EINSATZDATUM,',
'         :P37_EINSATZDATUM_TEXT,',
'         :P37_MANUELLE_EINTRAGUNG',
'    FROM T_VORSCHRIFT_REF_EINSATZDATUM_TYP',
'    WHERE vorschriftid = :P37_VORSCHRIFTID',
'      AND einsatzdatum_typid = :P37_EINSATZDATUM_TYPID;',
'  END IF;',
'EXCEPTION',
'  WHEN NO_DATA_FOUND THEN',
'    :P37_EINSATZDATUM := NULL;',
'    :P37_EINSATZDATUM_TEXT := NULL;',
'    :P37_MANUELLE_EINTRAGUNG := 10;',
'END;',
'',
'',
'',
'BEGIN',
'  IF :P37_EINSATZDATUM_TYPID IS NOT NULL THEN',
'    SELECT TO_CHAR(einsatzdatum, ''DD.MM.YYYY''),',
'           einsatzdatum_text,',
'           manuelle_eintragung',
'    INTO :P37_EINSATZDATUM,',
'         :P37_EINSATZDATUM_TEXT,',
'         :P37_MANUELLE_EINTRAGUNG',
'    FROM T_VORSCHRIFT_REF_EINSATZDATUM_TYP',
'    WHERE vorschriftid = :P37_VORSCHRIFTID',
'      AND einsatzdatum_typid = :P37_EINSATZDATUM_TYPID;',
'  END IF;',
'EXCEPTION',
'  WHEN NO_DATA_FOUND THEN',
'    :P37_EINSATZDATUM := NULL;',
'    :P37_EINSATZDATUM_TEXT := NULL;',
'    :P37_MANUELLE_EINTRAGUNG := 10;',
'END;',
'',
'',
'BEGIN',
'  -- Initialize display items to NULL in case no IDs are passed or data isn''t found',
'  :P37_VORSCHRIFT_NUMMER := NULL;',
'  :P37_EINSATZDATUM := NULL;',
'  :P37_EINSATZDATUM_TEXT := NULL;',
'  :P37_MANUELLE_EINTRAGUNG := 10; ',
'',
'  -- First, try to load the Vorschrift Nummer if P37_VORSCHRIFTID is available',
'  IF :P37_VORSCHRIFTID IS NOT NULL THEN',
'    BEGIN',
'      SELECT vorschrift_nummer',
'      INTO :P37_VORSCHRIFT_NUMMER',
'      FROM t_vorschrift',
'      WHERE vorschriftid = :P37_VORSCHRIFTID;',
'    EXCEPTION',
'      WHEN NO_DATA_FOUND THEN',
'        :P37_VORSCHRIFT_NUMMER := NULL; -- Or set to some ''Not Found'' text',
'        -- If VorschriftID is not found, we probably shouldn''t try to load related data',
'        RETURN; ',
'    END;',
'',
'    -- Then, if P37_EINSATZDATUM_TYPID is also available, load the einsatzdatum specific details',
'    IF :P37_EINSATZDATUM_TYPID IS NOT NULL THEN',
'      BEGIN',
'        SELECT TO_CHAR(einsatzdatum, ''DD.MM.YYYY''),',
'               einsatzdatum_text,',
'               manuelle_eintragung',
'        INTO :P37_EINSATZDATUM,',
'             :P37_EINSATZDATUM_TEXT,',
'             :P37_MANUELLE_EINTRAGUNG',
'        FROM T_VORSCHRIFT_REF_EINSATZDATUM_TYP',
'        WHERE vorschriftid = :P37_VORSCHRIFTID',
'          AND einsatzdatum_typid = :P37_EINSATZDATUM_TYPID;',
'      EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'          -- These will be used if it''s a new entry for this typid for the given vorschriftid',
'          :P37_EINSATZDATUM := NULL;',
'          :P37_EINSATZDATUM_TEXT := NULL;',
'          :P37_MANUELLE_EINTRAGUNG := 10; -- Default for a new typid entry, as per original code',
'      END;',
'    END IF;',
'  END IF;',
'',
'EXCEPTION',
'  WHEN OTHERS THEN',
'    -- This is a general catch-all for unexpected errors during the loading process',
'    apex_debug.error(''P37 Load Error: '' || SQLERRM);',
'    -- Clear items or re-raise, depending on desired behavior for unexpected errors',
'    :P37_VORSCHRIFT_NUMMER := NULL;',
'    :P37_EINSATZDATUM := NULL;',
'    :P37_EINSATZDATUM_TEXT := NULL;',
'    :P37_MANUELLE_EINTRAGUNG := NULL;',
'    RAISE; -- Re-raise the exception to make APEX aware of it',
'END;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1016889670241243324)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Einsatzdaten_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  -- Initialize display items to NULL in case no IDs are passed or data isn''t found',
'  :P37_VORSCHRIFT_NUMMER := NULL;',
'  :P37_EINSATZDATUM := NULL;',
'  :P37_EINSATZDATUM_TEXT := NULL;',
'  :P37_MANUELLE_EINTRAGUNG := 10; ',
'  :P37_LETZTE_AENDERUNG_DATUM := NULL;',
'  :P37_LETZTE_AENDERUNG_BENUTZER := NULL;',
'',
'  -- First, try to load the Vorschrift Nummer if P37_VORSCHRIFTID is available',
'  IF :P37_VORSCHRIFTID IS NOT NULL THEN',
'    BEGIN',
'      SELECT vorschrift_nummer',
'      INTO :P37_VORSCHRIFT_NUMMER',
'      FROM t_vorschrift',
'      WHERE vorschriftid = :P37_VORSCHRIFTID;',
'    EXCEPTION',
'      WHEN NO_DATA_FOUND THEN',
'        :P37_VORSCHRIFT_NUMMER := NULL;',
'        RETURN; ',
'    END;',
'',
'    -- Then, if P37_EINSATZDATUM_TYPID is also available, load the einsatzdatum specific details',
'    IF :P37_EINSATZDATUM_TYPID IS NOT NULL THEN',
'      BEGIN',
'        SELECT TO_CHAR(vredt.einsatzdatum, ''DD.MM.YYYY''),',
'               vredt.einsatzdatum_text,',
'               vredt.manuelle_eintragung,',
'               TO_CHAR(vredt.letzte_aenderung_datum, ''DD.MM.YYYY HH24:MI:SS''),',
'               CASE',
'                 WHEN b.nachname IS NOT NULL AND b.vorname IS NOT NULL ',
'                   THEN b.nachname || '', '' || b.vorname',
'                 WHEN b.nachname IS NOT NULL ',
'                   THEN b.nachname',
'                 WHEN b.vorname IS NOT NULL ',
'                   THEN b.vorname',
'                 ELSE NULL',
'               END,',
'               TO_CHAR(vredt.Modeljahr, ''YYYY'')',
'        INTO :P37_EINSATZDATUM,',
'             :P37_EINSATZDATUM_TEXT,',
'             :P37_MANUELLE_EINTRAGUNG,',
'             :P37_LETZTE_AENDERUNG_DATUM,',
'             :P37_LETZTE_AENDERUNG_BENUTZER,',
'             :P37_MODELJAHR',
'        FROM T_VORSCHRIFT_REF_EINSATZDATUM_TYP vredt',
'        LEFT JOIN T_BENUTZER b ON b.benutzerid = vredt.letzte_aenderung_benutzerid',
'        WHERE vredt.vorschriftid = :P37_VORSCHRIFTID',
'          AND vredt.einsatzdatum_typid = :P37_EINSATZDATUM_TYPID;',
'      EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'          -- These will be used if it''s a new entry for this typid for the given vorschriftid',
'          :P37_EINSATZDATUM := NULL;',
'          :P37_EINSATZDATUM_TEXT := NULL;',
'          :P37_MANUELLE_EINTRAGUNG := 10;',
'          :P37_LETZTE_AENDERUNG_DATUM := NULL;',
'          :P37_LETZTE_AENDERUNG_BENUTZER := NULL;',
'      END;',
'    END IF;',
'  END IF;',
'',
'EXCEPTION',
'  WHEN OTHERS THEN',
'',
'    apex_debug.error(''P37 Load Error: '' || SQLERRM);',
'',
'    :P37_VORSCHRIFT_NUMMER := NULL;',
'    :P37_EINSATZDATUM := NULL;',
'    :P37_EINSATZDATUM_TEXT := NULL;',
'    :P37_MANUELLE_EINTRAGUNG := NULL;',
'    :P37_LETZTE_AENDERUNG_DATUM := NULL;',
'    :P37_LETZTE_AENDERUNG_BENUTZER := NULL;',
'    RAISE; ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2655322645658144911
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- working coed withtou vko ',
'',
'BEGIN',
'  IF :P37_EINSATZDATUM_TYPID IS NOT NULL THEN',
'    SELECT TO_CHAR(einsatzdatum, ''DD.MM.YYYY''),',
'           einsatzdatum_text,',
'           manuelle_eintragung',
'    INTO :P37_EINSATZDATUM,',
'         :P37_EINSATZDATUM_TEXT,',
'         :P37_MANUELLE_EINTRAGUNG',
'    FROM T_VORSCHRIFT_REF_EINSATZDATUM_TYP',
'    WHERE vorschriftid = :P37_VORSCHRIFTID',
'      AND einsatzdatum_typid = :P37_EINSATZDATUM_TYPID;',
'  END IF;',
'EXCEPTION',
'  WHEN NO_DATA_FOUND THEN',
'    :P37_EINSATZDATUM := NULL;',
'    :P37_EINSATZDATUM_TEXT := NULL;',
'    :P37_MANUELLE_EINTRAGUNG := 10;',
'END;',
'',
'',
'',
'BEGIN',
'  IF :P37_EINSATZDATUM_TYPID IS NOT NULL THEN',
'    SELECT TO_CHAR(einsatzdatum, ''DD.MM.YYYY''),',
'           einsatzdatum_text,',
'           manuelle_eintragung',
'    INTO :P37_EINSATZDATUM,',
'         :P37_EINSATZDATUM_TEXT,',
'         :P37_MANUELLE_EINTRAGUNG',
'    FROM T_VORSCHRIFT_REF_EINSATZDATUM_TYP',
'    WHERE vorschriftid = :P37_VORSCHRIFTID',
'      AND einsatzdatum_typid = :P37_EINSATZDATUM_TYPID;',
'  END IF;',
'EXCEPTION',
'  WHEN NO_DATA_FOUND THEN',
'    :P37_EINSATZDATUM := NULL;',
'    :P37_EINSATZDATUM_TEXT := NULL;',
'    :P37_MANUELLE_EINTRAGUNG := 10;',
'END;',
'',
'',
'BEGIN',
'  -- Initialize display items to NULL in case no IDs are passed or data isn''t found',
'  :P37_VORSCHRIFT_NUMMER := NULL;',
'  :P37_EINSATZDATUM := NULL;',
'  :P37_EINSATZDATUM_TEXT := NULL;',
'  :P37_MANUELLE_EINTRAGUNG := 10; ',
'',
'  -- First, try to load the Vorschrift Nummer if P37_VORSCHRIFTID is available',
'  IF :P37_VORSCHRIFTID IS NOT NULL THEN',
'    BEGIN',
'      SELECT vorschrift_nummer',
'      INTO :P37_VORSCHRIFT_NUMMER',
'      FROM t_vorschrift',
'      WHERE vorschriftid = :P37_VORSCHRIFTID;',
'    EXCEPTION',
'      WHEN NO_DATA_FOUND THEN',
'        :P37_VORSCHRIFT_NUMMER := NULL; -- Or set to some ''Not Found'' text',
'        -- If VorschriftID is not found, we probably shouldn''t try to load related data',
'        RETURN; ',
'    END;',
'',
'    -- Then, if P37_EINSATZDATUM_TYPID is also available, load the einsatzdatum specific details',
'    IF :P37_EINSATZDATUM_TYPID IS NOT NULL THEN',
'      BEGIN',
'        SELECT TO_CHAR(einsatzdatum, ''DD.MM.YYYY''),',
'               einsatzdatum_text,',
'               manuelle_eintragung',
'        INTO :P37_EINSATZDATUM,',
'             :P37_EINSATZDATUM_TEXT,',
'             :P37_MANUELLE_EINTRAGUNG',
'        FROM T_VORSCHRIFT_REF_EINSATZDATUM_TYP',
'        WHERE vorschriftid = :P37_VORSCHRIFTID',
'          AND einsatzdatum_typid = :P37_EINSATZDATUM_TYPID;',
'      EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'          -- These will be used if it''s a new entry for this typid for the given vorschriftid',
'          :P37_EINSATZDATUM := NULL;',
'          :P37_EINSATZDATUM_TEXT := NULL;',
'          :P37_MANUELLE_EINTRAGUNG := 10; -- Default for a new typid entry, as per original code',
'      END;',
'    END IF;',
'  END IF;',
'',
'EXCEPTION',
'  WHEN OTHERS THEN',
'    -- This is a general catch-all for unexpected errors during the loading process',
'    apex_debug.error(''P37 Load Error: '' || SQLERRM);',
'    -- Clear items or re-raise, depending on desired behavior for unexpected errors',
'    :P37_VORSCHRIFT_NUMMER := NULL;',
'    :P37_EINSATZDATUM := NULL;',
'    :P37_EINSATZDATUM_TEXT := NULL;',
'    :P37_MANUELLE_EINTRAGUNG := NULL;',
'    RAISE; -- Re-raise the exception to make APEX aware of it',
'END;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1019083017991189530)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Check_If_Has_VKO_Role'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  -- Check if user has VKO role (1000)',
'  IF pck_ri.fIsUserInRolle(listRolleId => ''1000'') > 0 THEN',
'    -- User has the role, return true',
'    apex_json.open_object;',
'    apex_json.write(''hasVKORole'', true);',
'    apex_json.close_object;',
'  ELSE',
'    -- User doesn''t have the role, return false',
'    apex_json.open_object;',
'    apex_json.write(''hasVKORole'', false);',
'    apex_json.close_object;',
'  END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2653129297908198705
);
wwv_flow_imp.component_end;
end;
/
