prompt --application/pages/page_00360
begin
--   Manifest
--     PAGE: 00360
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>360
,p_name=>unistr('\00DCbersicht FALKO')
,p_alias=>unistr('\00DCBERSICHT-FALKO')
,p_step_title=>unistr('\00DCbersicht FALKO')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(2660026449262803947)
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1009290260066703344)
,p_plug_name=>unistr('\00DCbersicht FALKO')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select fp_kpb, fp_bezeichnung, sm_nomenklatur, ltue_sop, ltue_eop, tpl_name, ltue_deleted, ltue_von',
'from v_x_falko@carmah_e'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_read_only_when_type=>'ALWAYS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_page_header=>unistr('\00DCbersicht FALKO')
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1009290142619703344)
,p_name=>unistr('\00DCbersicht FALKO')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>103402794475431060
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016220102008619196)
,p_db_column_name=>'FP_KPB'
,p_display_order=>10
,p_column_identifier=>'D'
,p_column_label=>'KPB'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016219949682619195)
,p_db_column_name=>'FP_BEZEICHNUNG'
,p_display_order=>20
,p_column_identifier=>'E'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016216332235619158)
,p_db_column_name=>'SM_NOMENKLATUR'
,p_display_order=>30
,p_column_identifier=>'I'
,p_column_label=>'Nomenklatur'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016219882273619194)
,p_db_column_name=>'TPL_NAME'
,p_display_order=>40
,p_column_identifier=>'F'
,p_column_label=>'B-Nummer Land'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1009289771674703339)
,p_db_column_name=>'LTUE_SOP'
,p_display_order=>50
,p_column_identifier=>'A'
,p_column_label=>'SOP'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1009289346215703336)
,p_db_column_name=>'LTUE_EOP'
,p_display_order=>60
,p_column_identifier=>'B'
,p_column_label=>'EOP'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016219809226619193)
,p_db_column_name=>'LTUE_DELETED'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('Gel\00F6scht')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1016219720479619192)
,p_db_column_name=>'LTUE_VON'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Datum von'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1009288070278693396)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1034049'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FP_KPB:FP_BEZEICHNUNG:SM_NOMENKLATUR:TPL_NAME:LTUE_SOP:LTUE_EOP:LTUE_DELETED:LTUE_VON:'
);
wwv_flow_imp.component_end;
end;
/
