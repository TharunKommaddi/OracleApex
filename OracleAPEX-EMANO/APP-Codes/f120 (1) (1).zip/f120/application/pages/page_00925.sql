prompt --application/pages/page_00925
begin
--   Manifest
--     PAGE: 00925
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>925
,p_name=>unistr('Importeure bearbeiten/hinzuf\00FCgen')
,p_alias=>unistr('IMPORTEURE-BEARBEITEN-HINZUF\00DCGEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Importeure bearbeiten/hinzuf\00FCgen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function loadLaenderShuttle() {',
'    var shuttleName = ''P925_LAENDER'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadLaenderShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P925_F_LAENDERGRUPPE''),',
'          x03: $v(''P925_F_LAND'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                console.log(pData);',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Schulungen & Audits Report Column Status Color & ToolTip',
'function initializeStatusTooltips() {',
'    const tooltipConfigs = {',
'        ''#RSchulungen'': {',
'            grey: ''Schulungstyp ist nicht mehr relevant'',',
unistr('            green: ''Schulung ist g\00FCltig: - Zuk\00FCnftiges Datum ODER - Durchgef\00FChrt und innerhalb der G\00FCltigkeitsdauer'','),
unistr('            red: ''Schulung ist ung\00FCltig: - Nicht durchgef\00FChrt ODER - G\00FCltigkeitsdauer abgelaufen'''),
'        },',
'        ''#RAudits'': {',
'            grey: ''Audittyp ist nicht mehr relevant'',',
unistr('            green: ''Audit ist g\00FCltig: - Zuk\00FCnftiges Datum ODER - Durchgef\00FChrt und innerhalb der G\00FCltigkeitsdauer'','),
unistr('            red: ''Audit ist ung\00FCltig: - Nicht durchgef\00FChrt ODER - G\00FCltigkeitsdauer abgelaufen'''),
'        }',
'    };',
'',
'    [''#RSchulungen'', ''#RAudits''].forEach(regionId => {',
'        apex.jQuery(`${regionId} .status-dot`).each(function() {',
'            const backgroundColor = apex.jQuery(this).css(''background-color'');',
'            let tooltipText;',
'',
'            if (backgroundColor.includes(''rgb(187, 187, 187)'') || backgroundColor.includes(''#BBBBBB'')) {',
'                tooltipText = tooltipConfigs[regionId].grey;',
'            } else if (backgroundColor.includes(''rgb(50, 205, 50)'') || backgroundColor.includes(''limegreen'')) {',
'                tooltipText = tooltipConfigs[regionId].green;',
'            } else if (backgroundColor.includes(''rgb(255, 0, 0)'') || backgroundColor.includes(''red'')) {',
'                tooltipText = tooltipConfigs[regionId].red;',
'            }',
'',
'            apex.jQuery(this).attr(''title'', tooltipText);',
'        });',
'    });',
'',
'    apex.jQuery(".status-dot").tooltip({',
'        show: { effect: "fade", delay: 200 },',
'        hide: { effect: "fade", delay: 200 },',
'       ',
'        position: { ',
'                    my: "left+10 top+20",',
'                    at: "right bottom",',
'                    collision: "flipfit"',
'                },',
'                tooltipClass: "status-tooltip",',
'                track: true,',
'                items: "*"',
'    });',
'}',
'',
'apex.jQuery(document).ready(initializeStatusTooltips);',
'[''#RSchulungen'', ''#RAudits''].forEach(regionId => {',
'    apex.jQuery(regionId).on(''apexafterrefresh'', initializeStatusTooltips);',
'});',
'',
'',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#P925_ZUSATZVEREINBARUNG_MSOR_inline_help {',
'    white-space: pre-wrap',
'}',
'',
'#P925_ZUSATZVEREINBARUNG_MSOR_inline_help a {',
'    text-decoration: underline',
'}',
'',
'',
'',
'',
'/* ToolTip CSS for Schulung, Audit, Ansprechpartner*/',
'.ap-title {',
'    display: flex;',
'    align-items: center;',
'}',
'.ap-dot {',
'    width: 20px;',
'    height: 20px;',
'    border-radius: 50%;',
'    margin-right: 5px;',
'',
'}',
'.status-tooltip {',
'    padding: 8px;',
'    background-color: #fff;',
'    border: 1px solid #ddd;',
'    box-shadow: 0 2px 4px rgba(0,0,0,0.1);',
'    max-width: 300px;',
'    font-size: 14px;',
'    z-index: 1000;',
'}',
'',
'',
'/* No Data Found CSS for Reports*/',
'.no-data-message {',
'    background-color: #f5f5f5;',
'    color: #333333;',
'    padding: 8px 12px;',
'    font-family: ''Segoe UI'', Arial, sans-serif;',
'    border-left: 3px solid #bb0a31; /*#4CAF50;*/',
'    margin: 10px 0;',
'    font-size: 13px;',
'    line-height: 1.4;    ',
'}',
'',
'.highlight {',
'    color: #d60c38; /*#e6b800;*/',
'',
'}',
'',
'',
''))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_dialog_chained=>'N'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6108836632644413402)
,p_plug_name=>'Importeure'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_IMPORTEUR'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_ajax_items_to_submit=>'P925_BEZEICHNUNG'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1602169444118275311)
,p_plug_name=>'Links oben'
,p_parent_plug_id=>wwv_flow_imp.id(6108836632644413402)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_read_only_when=>'P925_READONLYMODE'
,p_plug_read_only_when2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1602169640514275312)
,p_plug_name=>'Rechts oben'
,p_parent_plug_id=>wwv_flow_imp.id(6108836632644413402)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_read_only_when=>'P925_READONLYMODE'
,p_plug_read_only_when2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1602171208515275328)
,p_plug_name=>'Links unten'
,p_parent_plug_id=>wwv_flow_imp.id(6108836632644413402)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1095749925142347786)
,p_name=>unistr('Auff\00E4lligkeiten <span onclick="redirect(821)" class="fa fa-info-square-o"></span>')
,p_parent_plug_id=>wwv_flow_imp.id(1602171208515275328)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    kc.KONZERN_CLUSTERID,',
'    kc.BEZEICHNUNG as BEZEICHNUNG',
'FROM ',
'    t_konzern_cluster kc',
'JOIN ',
'    t_importeur_ref_konzern_cluster irc ',
'    ON kc.KONZERN_CLUSTERID = irc.KONZERN_CLUSTERID',
'WHERE ',
'    irc.IMPORTEURID = :P925_IMPORTEURID',
'    AND  not EXISTS (',
'        SELECT 1 ',
'        FROM t_ansprechpartner_ref_konzern_cluster tark',
'        JOIN T_ANSPRECHPARTNER ta ',
'            ON ta.ANSPRECHPARTNERID = tark.ANSPRECHPARTNERID',
'        WHERE ta.IMPORTEURID = :P925_IMPORTEURID',
'        AND tark.KONZERN_CLUSTERID = kc.KONZERN_CLUSTERID',
'        and R_VKO =10',
'    )',
'ORDER BY ',
'    kc.BEZEICHNUNG'))
,p_display_when_condition=>'P925_IMPORTEURID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P925_IMPORTEURID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="no-data-message">',
unistr('    Alle Konzern-Cluster sind vollst\00E4ndig einem R-VKO Ansprechpartner zugeordnet. Es liegen <span class="highlight">keine</span> unzugewiesenen Regionen vor.'),
'</div>'))
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1095749829602347785)
,p_query_column_id=>1
,p_column_alias=>'KONZERN_CLUSTERID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1095212363516265234)
,p_query_column_id=>2
,p_column_alias=>'BEZEICHNUNG'
,p_column_display_sequence=>20
,p_column_heading=>'Cluster ohne R-VKO Ansprechpartner'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1027868469281176627)
,p_name=>'<span id="ansprechpartner-title">Ansprechpartner</span>'
,p_region_name=>'R490939196568863415'
,p_parent_plug_id=>wwv_flow_imp.id(1602171208515275328)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct ansprechpartnerid,',
'    2 as link,',
'    nachname || '', '' || vorname ||',
'    case when r_vko = 10 or spoc = 10 then',
'        '' ('' || case when r_vko = 10 then ''R-VKO'' end || case when r_vko = 10 and spoc = 10 then '', '' end || case when spoc = 10 then ''SPOC'' end || '')''',
'    end ||',
'    ''<br>'' || email_adresse',
'    || case when kommentar is not null then ''<br /><i>'' || kommentar || ''</i>'' end as ansprechpartner',
'    from t_ansprechpartner',
'    where importeurid = :P925_IMPORTEURID',
'    order by ansprechpartner;',
''))
,p_display_when_condition=>'P925_IMPORTEURID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P925_IMPORTEURID,P925_READONLYMODE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="no-data-message">',
unistr('    Es wurden <span class="highlight">keine</span> R-VKO Ansprechpartner f\00FCr diesen Konzern-Cluster zugewiesen. Bitte weisen Sie mindestens einen Ansprechpartner zu.'),
'</div>'))
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>'Ansprechpartner <span onclick="redirect(504)" class="fa fa-info-square-o"></span>'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(798695964927397462)
,p_query_column_id=>1
,p_column_alias=>'ANSPRECHPARTNERID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(798695592730397461)
,p_query_column_id=>2
,p_column_alias=>'LINK'
,p_column_display_sequence=>2
,p_column_link=>'f?p=&APP_ID.:926:&SESSION.::&DEBUG.::P926_ANSPRECHPARTNERID,P926_IMPORTEURID:#ANSPRECHPARTNERID#,&P925_IMPORTEURID.#IMPORTEURID#'
,p_column_linktext=>'<span aria-label="Eintrag bearbeiten"><span class="fa fa-edit" aria-hidden="true" title="Eintrag bearbeiten"></span></span>'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P925_READONLYMODE'
,p_display_when_condition2=>'0'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(798695219828397461)
,p_query_column_id=>3
,p_column_alias=>'ANSPRECHPARTNER'
,p_column_display_sequence=>3
,p_column_heading=>'Ansprechpartner'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1602171062674275327)
,p_plug_name=>unistr('L\00E4nderzuordnungen')
,p_parent_plug_id=>wwv_flow_imp.id(1602171208515275328)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1602170689339275323)
,p_plug_name=>unistr('Container L\00E4nder links')
,p_parent_plug_id=>wwv_flow_imp.id(1602171062674275327)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P925_READONLYMODE'
,p_plug_display_when_cond2=>'0'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1602171032875275326)
,p_plug_name=>unistr('Container L\00E4nder rechts')
,p_parent_plug_id=>wwv_flow_imp.id(1602171062674275327)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1602171300660275329)
,p_plug_name=>'Rechts unten'
,p_parent_plug_id=>wwv_flow_imp.id(6108836632644413402)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1027868937592176631)
,p_name=>'Schulungen <span onclick="redirect(505)" class="fa fa-info-square-o"></span>'
,p_region_name=>'RSchulungen'
,p_parent_plug_id=>wwv_flow_imp.id(1602171300660275329)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct schulungid,',
'    2 as link,',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END  || ''<br>'' || datum_schulung ',
'                                    || '' ('' ',
'                                    || CASE status_schulung ',
'                                         WHEN 10 THEN emano_util.fLang(''Unterlagen verteilt'', ''Distributed Documents'') ',
'                                         WHEN 20 THEN emano_util.fLang(''geplant'', ''planned'') ',
unistr('                                         WHEN 30 THEN emano_util.fLang(''durchgef\00FChrt'', ''conducted'') '),
'                                       END ',
'                                    || '')'' AS schulung,',
'    CASE ',
'',
'        -- Check for repeated Schulung',
'            WHEN EXISTS (',
'                SELECT 1 ',
'                FROM t_schulung s2',
'                WHERE s2.schulung_typid = s.schulung_typid  -- same training type',
'                AND s2.importeurid = s.importeurid         -- same importer',
'                AND s2.datum_schulung > s.datum_schulung   -- newer date exists',
'                AND s2.schulungid != s.schulungid          -- not same record',
'            ) THEN ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:#BBBBBB;;" class="status-dot"></span>''',
'',
'            ',
'        -- WHITE/GREY (not relevant)',
'        WHEN st.status = 20 THEN   ',
'            ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:#BBBBBB;" class="status-dot"></span>''',
'            ',
'        -- GREEN (future or within validity period)',
'        WHEN (',
'            datum_schulung > TRUNC(SYSDATE)  -- Future training',
'            OR (status_schulung = 30 AND     -- Training completed AND',
'                ADD_MONTHS(s.datum_schulung, st.DAUER_GUELTIGKEIT) > SYSDATE)  -- Still within validity period',
'            )',
'         THEN',
'            ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:limegreen;" class="status-dot"></span>''',
'            ',
'        -- RED (overdue or invalid)',
'        ELSE ',
'            ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:red;" class="status-dot"></span>''',
'    END as ampel_status',
'',
'    from t_schulung s',
'    join t_schulung_typ st on s.schulung_typid = st.schulung_typid',
'    where importeurid = :P925_IMPORTEURID',
'    order by schulung'))
,p_display_when_condition=>'P925_IMPORTEURID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P925_IMPORTEURID,P925_READONLYMODE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="no-data-message">',
unistr('    Es wurden <span class="highlight">keine</span> Schulungen f\00FCr diesen Importeur gefunden. Bitte planen Sie die erforderlichen Schulungen.'),
'</div>'))
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(798691720394397456)
,p_query_column_id=>1
,p_column_alias=>'SCHULUNGID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(798691334814397456)
,p_query_column_id=>2
,p_column_alias=>'LINK'
,p_column_display_sequence=>2
,p_column_link=>'f?p=&APP_ID.:927:&SESSION.::&DEBUG.::P927_SCHULUNGID:#SCHULUNGID#'
,p_column_linktext=>'<span aria-label="Eintrag bearbeiten"><span class="fa fa-edit" aria-hidden="true" title="Eintrag bearbeiten"></span></span>'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P925_READONLYMODE'
,p_display_when_condition2=>'0'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(798690908856397455)
,p_query_column_id=>3
,p_column_alias=>'SCHULUNG'
,p_column_display_sequence=>3
,p_column_heading=>'Schulung'
,p_column_format=>'DD.MM.YYYY'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1095750137067347788)
,p_query_column_id=>4
,p_column_alias=>'AMPEL_STATUS'
,p_column_display_sequence=>13
,p_column_heading=>'Ampel Status'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1027869213157176634)
,p_name=>'Audits <span onclick="redirect(506)" class="fa fa-info-square-o"></span>'
,p_region_name=>'RAudits'
,p_parent_plug_id=>wwv_flow_imp.id(1602171300660275329)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct auditid, ',
'    2 as link, ',
'    CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung ELSE name_eng END  || ''<br>'' || datum_audit || '' ('' || status_audit || '')'' as  auditbezeichnung,',
'',
'    CASE ',
'        -- Check for repeated audit',
'        WHEN EXISTS (',
'            SELECT 1 ',
'            FROM t_audit a2',
'            WHERE a2.audit_typid = a.audit_typid       -- same audit type',
'            AND a2.importeurid = a.importeurid         -- same importer',
'            AND a2.datum_audit > a.datum_audit         -- newer date exists',
'            AND a2.auditid != a.auditid               -- not same record',
'        ) THEN ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:#BBBBBB;" class="status-dot"></span>''',
'        ',
'        -- WHITE/GREY (not relevant)',
'        WHEN at.status = 20 THEN   ',
'            ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:#BBBBBB;" class="status-dot"></span>''',
'            ',
'        -- GREEN (future or within validity period)',
'        WHEN (',
'            datum_audit > TRUNC(SYSDATE)  -- Future audit',
'            OR (status_audit = ''20'' AND     -- Audit completed AND',
'                ADD_MONTHS(a.datum_audit, at.DAUER_GUELTIGKEIT) > SYSDATE) -- Still within validity period',
'        ) THEN',
'            ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:limegreen;" class="status-dot"></span>''',
'            ',
'        -- RED (overdue or invalid)',
'        ELSE ',
'            ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:red;" class="status-dot"></span>''',
'    END as ampel_status',
'',
'',
'    ',
'    from t_audit a',
'    join t_audit_typ at on a.audit_typid = at.audit_typid',
'    where importeurid = :P925_IMPORTEURID',
'    order by auditbezeichnung'))
,p_display_when_condition=>'P925_IMPORTEURID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P925_IMPORTEURID,P925_READONLYMODE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="no-data-message">',
unistr('    Es wurden <span class="highlight">keine</span> Audits f\00FCr diesen Importeur gefunden. Bitte planen Sie die erforderlichen Audits.'),
'</div>'))
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(798689754552397454)
,p_query_column_id=>1
,p_column_alias=>'AUDITID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(798689344137397454)
,p_query_column_id=>2
,p_column_alias=>'LINK'
,p_column_display_sequence=>2
,p_column_link=>'f?p=&APP_ID.:928:&SESSION.::&DEBUG.::P928_AUDITID:#AUDITID#'
,p_column_linktext=>'<span aria-label="Eintrag bearbeiten"><span class="fa fa-edit" aria-hidden="true" title="Eintrag bearbeiten"></span></span>'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P925_READONLYMODE'
,p_display_when_condition2=>'0'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(798689035633397454)
,p_query_column_id=>3
,p_column_alias=>'AUDITBEZEICHNUNG'
,p_column_display_sequence=>3
,p_column_heading=>'Audit'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1095750085299347787)
,p_query_column_id=>4
,p_column_alias=>'AMPEL_STATUS'
,p_column_display_sequence=>13
,p_column_heading=>'Ampel Status'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1602170496035275321)
,p_name=>'Arbeitsaufgaben <span onclick="redirect(507)" class="fa fa-info-square-o"></span>'
,p_parent_plug_id=>wwv_flow_imp.id(1602171300660275329)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.rowid as a_rowid, CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN at.Aufgabe_de ELSE at.Aufgabe_en END || emano_util.fLang(''<br />Datum Aufgabe: '', ''<br />Task Date: '') || a.datum_aufgabe ||',
'    '', Status: '' || case status_aufgabe ',
'    when 10 then emano_util.fLang(''offen'', ''open'') ',
'    when 20 then emano_util.fLang(''in Bearbeitung'', ''in progress'') ',
'    when 30 then emano_util.fLang(''erledigt'', ''completed'') end as text',
'from t_arbeitsaufgabe a',
'join t_arbeitsaufgabe_typ at on (a.arbeitsaufgabe_typid = at.arbeitsaufgabe_typid)',
'where importeurid = :P925_IMPORTEURID',
'order by 2'))
,p_display_when_condition=>'P925_IMPORTEURID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P925_IMPORTEURID,P925_READONLYMODE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="no-data-message">',
unistr('    Es wurden <span class="highlight">keine</span> Arbeitsaufgaben f\00FCr diesen Importeur gefunden. Alle Aufgaben sind abgeschlossen.'),
'</div>'))
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(798687931198397453)
,p_query_column_id=>1
,p_column_alias=>'A_ROWID'
,p_column_display_sequence=>1
,p_column_link=>'f?p=&APP_ID.:929:&SESSION.::&DEBUG.:929:P929_ROWID:#A_ROWID#'
,p_column_linktext=>'<span aria-label="Eintrag bearbeiten"><span class="fa fa-edit" aria-hidden="true" title="Eintrag bearbeiten"></span></span>'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P925_READONLYMODE'
,p_display_when_condition2=>'0'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(798687495300397453)
,p_query_column_id=>2
,p_column_alias=>'TEXT'
,p_column_display_sequence=>2
,p_column_heading=>'Text'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6108837382825413402)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(798686384990397452)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6108837382825413402)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(798686026043397451)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(6108837382825413402)
,p_button_name=>'DELETE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P925_READONLYMODE'
,p_button_condition2=>'0'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(798690471086397455)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1027868937592176631)
,p_button_name=>'P925_SCHULUNG_HINZUFUEGEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:927:&SESSION.::&DEBUG.::P927_IMPORTEURID:&P925_IMPORTEURID.'
,p_button_condition=>'P925_READONLYMODE'
,p_button_condition2=>'0'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(798688587372397454)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1027869213157176634)
,p_button_name=>'P925_AUDIT_HINZUFUEGEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:928:&SESSION.::&DEBUG.:928:P928_IMPORTEURID:&P925_IMPORTEURID.'
,p_button_condition=>'P925_READONLYMODE'
,p_button_condition2=>'0'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(798687118256397452)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1602170496035275321)
,p_button_name=>'P925_ARBEITSAUFGABE_HINZUFUEGEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:929:&SESSION.::&DEBUG.:929:P929_IMPORTEURID:&P925_IMPORTEURID.'
,p_button_condition=>'P925_READONLYMODE'
,p_button_condition2=>'0'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(798694785233397461)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1027868469281176627)
,p_button_name=>'P925_ANSPRECHPARTNER_HINZUFUEGEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:926:&SESSION.::&DEBUG.:926:P926_IMPORTEURID:&P925_IMPORTEURID.'
,p_button_condition=>'(:P925_IMPORTEURID is not null and :P925_READONLYMODE = 0 )'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(798685626022397451)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6108837382825413402)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'( (:P925_IMPORTEURID is null) and :P925_READONLYMODE = 0 )'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(798685236535397450)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(6108837382825413402)
,p_button_name=>'SAVE_CLOSE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Speichern & Schlie\00DFen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>' ( (:P925_IMPORTEURID is not null) and :P925_READONLYMODE = 0 )'
,p_button_condition2=>'SQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(798666441877397425)
,p_branch_action=>'f?p=&APP_ID.:925:&SESSION.::&DEBUG.::P925_IMPORTEURID:&P925_IMPORTEURID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(798685626022397451)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798704488907397482)
,p_name=>'P925_IMPORTEURID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6108836632644413402)
,p_item_source_plug_id=>wwv_flow_imp.id(6108836632644413402)
,p_source=>'IMPORTEURID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798704094847397480)
,p_name=>'P925_READONLYMODE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(6108836632644413402)
,p_use_cache_before_default=>'NO'
,p_source=>'case pck_ri.fIsUserInRolle(:G_BENUTZERID, ''1003:1050'') when 0 then 1 else 0 end'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798703648545397479)
,p_name=>'P925_CAME_FROM'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(6108836632644413402)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798703293199397479)
,p_name=>'P925_LANDID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(6108836632644413402)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798702263931397472)
,p_name=>'P925_BEZEICHNUNG'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1602169444118275311)
,p_item_source_plug_id=>wwv_flow_imp.id(6108836632644413402)
,p_prompt=>'Importeur'
,p_source=>'BEZEICHNUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>100
,p_read_only_when=>'P925_READONLYMODE'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798701887903397471)
,p_name=>'P925_VERANTWORTUNG_IMPORTEUR'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1602169444118275311)
,p_prompt=>'Verantwortung <span onclick="redirect(500)" class="fa fa-info-square-o"></span>'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Hauptverantwortlicher Importeur'', ''Main importer responsible'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Supportimporteur'', ''Support importer'') AS display_value,',
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798701461963397471)
,p_name=>'P925_CRO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1602169444118275311)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798701123520397471)
,p_name=>'P925_KONZERN_CLUSTER'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1602169444118275311)
,p_prompt=>'Konzern Cluster <span onclick="redirect(502)" class="fa fa-info-square-o"></span>'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung, konzern_clusterid',
'from t_konzern_cluster',
'order by 1'))
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798700690557397470)
,p_name=>'P925_DATEN_ERFASST_KONTROLLIERT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1602169444118275311)
,p_item_default=>'10'
,p_prompt=>'Daten des Importeurs erfasst und kontrolliert'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''offen'', ''open'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''in Bearbeitung'', ''in Progress'') AS display_value,',
'        20 AS actual_value,',
'        2 AS sort_order ',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''ja'', ''yes'') AS display_value,',
'        30 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;'))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798699713198397470)
,p_name=>'P925_GHV_DATUM'
,p_source_data_type=>'DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1602169640514275312)
,p_item_source_plug_id=>wwv_flow_imp.id(6108836632644413402)
,p_source=>'GHV_DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798699246081397469)
,p_name=>'P925_KOMMUNIKATIONSART'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1602169640514275312)
,p_prompt=>'Kommunikationsart'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select name_de, kommunikationsartid',
'from t_kommunikationsart',
'order by 1'))
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '4')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798698839261397469)
,p_name=>'P925_RTF'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1602169640514275312)
,p_prompt=>'Reporting Tool & Frequency'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select name_de, rtfid',
'from t_rtf',
'order by 1'))
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '4')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798698472853397469)
,p_name=>'P925_KONZERN_MARKEN'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1602169640514275312)
,p_prompt=>'Konzern Marken'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select name, konzern_markeid',
'from t_konzern_marke km',
'order by 1'))
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '5')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798698098141397469)
,p_name=>'P925_FAHRZEUGKLASSEN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1602169640514275312)
,p_prompt=>'Fahrzeugklassen (Marke VW)'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung, fahrzeugklasseid',
'from t_fahrzeugklasse',
'order by 1'))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '5')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798697675300397468)
,p_name=>'P925_ZUSATZVEREINBARUNG_MSOR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(1602169640514275312)
,p_prompt=>'Zusatzvereinbarung zum MSoR mit Importeur'
,p_post_element_text=>'&nbsp;<span onclick="redirect(503)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>3
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>'&nbsp;'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798697262715397468)
,p_name=>'P925_ZUSATZVEREINBARUNG_MSOR_D'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(1602169640514275312)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798693823270397458)
,p_name=>'P925_F_LAENDERGRUPPE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1602170689339275323)
,p_prompt=>unistr('Vorfilter L\00E4ndergruppe')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select laendergruppe, laendergruppeid',
'from t_laendergruppe where laendergruppeid != 1220',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- alle -'
,p_cHeight=>5
,p_display_when=>'P925_READONLYMODE'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798693355893397458)
,p_name=>'P925_F_LAND'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1602170689339275323)
,p_prompt=>unistr('Vorfilter L\00E4nder')
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" onclick="loadLaenderShuttle()"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>25
,p_display_when=>'P925_READONLYMODE'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(798692697320397457)
,p_name=>'P925_LAENDER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1602171032875275326)
,p_prompt=>unistr('L\00E4nder')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    l.B_NUMMER || '' - '' || ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.LAND',
'        ELSE l.LAND_ENG',
'    END ||'' Prio: ''|| PRIO AS d, ',
'    l.LANDID',
'FROM ',
'    t_land l',
'WHERE ',
'    (:P925_FILTER_LAENDERGRUPPE IS NULL OR ',
'     l.LANDID IN (SELECT landid FROM t_land_ref_laendergruppe WHERE laendergruppeid = :P925_FILTER_LAENDERGRUPPE))',
'ORDER BY ',
'    NLSSORT(l.B_NUMMER, ''NLS_SORT=BINARY_AI'')',
''))
,p_cHeight=>5
,p_read_only_when=>'P925_READONLYMODE'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(798684314370397442)
,p_validation_name=>'New'
,p_validation_sequence=>10
,p_validation=>'P925_BEZEICHNUNG'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Importeur muss einen Wert haben.'
,p_associated_item=>wwv_flow_imp.id(798702263931397472)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(798684697520397443)
,p_validation_name=>unistr('inaktive L\00E4nder')
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lFehler clob;',
'begin',
'',
'    select listagg(''Der Konzern Cluster "'' || kc.bezeichnung || ''" darf beim Land '' || l.b_nummer || '' - '' || l.land || '' nicht zugewiesen werden!'',''</li><li class="a-Notification-item htmldbStdErr">'') into lFehler',
'    from t_konzern_cluster_ref_land kcrl',
'    join t_land l on (kcrl.landid = l.landid)',
'    join t_konzern_cluster kc on (kcrl.konzern_clusterid = kc.konzern_clusterid)',
'    where kcrl.landid in (select column_value from apex_string.split_numbers(:P925_LAENDER,'':''))',
'    and kcrl.konzern_clusterid in (select column_value from apex_string.split_numbers(:P925_KONZERN_CLUSTER,'':''));',
'',
'    return lFehler;',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_validation_condition=>':P925_KONZERN_CLUSTER is not null and :P925_LAENDER is not null'
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_associated_item=>wwv_flow_imp.id(798701123520397471)
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(798681985869397438)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(798686384990397452)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(798681598333397435)
,p_event_id=>wwv_flow_imp.id(798681985869397438)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(798681213486397435)
,p_name=>'Create - P926 closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(798694785233397461)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(798680666726397434)
,p_event_id=>wwv_flow_imp.id(798681213486397435)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6108836632644413402)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(798680323788397434)
,p_name=>'Create - P927 closed'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(798690471086397455)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(798679742351397434)
,p_event_id=>wwv_flow_imp.id(798680323788397434)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6108836632644413402)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(798679368705397434)
,p_name=>'Create - P928 closed'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(798688587372397454)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(798678875642397433)
,p_event_id=>wwv_flow_imp.id(798679368705397434)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6108836632644413402)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(798678494212397433)
,p_name=>'Create - P929 closed'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(798687118256397452)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(798677965171397433)
,p_event_id=>wwv_flow_imp.id(798678494212397433)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1602170496035275321)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(798677600998397433)
,p_name=>'Edit - P926 closed'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1027868469281176627)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(798677078108397432)
,p_event_id=>wwv_flow_imp.id(798677600998397433)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1027868469281176627)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1095210994317265220)
,p_name=>'Edit - P926 closed_1'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1027868469281176627)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1095210911748265219)
,p_event_id=>wwv_flow_imp.id(1095210994317265220)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1095749925142347786)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(798676724874397432)
,p_name=>'Edit - P927 closed'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1027868937592176631)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(798676158823397432)
,p_event_id=>wwv_flow_imp.id(798676724874397432)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1027868937592176631)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(798675783306397432)
,p_name=>'Edit - P928 closed'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1027869213157176634)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(798675276126397431)
,p_event_id=>wwv_flow_imp.id(798675783306397432)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1027869213157176634)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(798674935897397431)
,p_name=>'Edit - P929 closed'
,p_event_sequence=>90
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1602170496035275321)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(798674430758397431)
,p_event_id=>wwv_flow_imp.id(798674935897397431)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1602170496035275321)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(798674018215397431)
,p_name=>'change Vorfilter'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P925_F_LAENDERGRUPPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(798673516837397430)
,p_event_id=>wwv_flow_imp.id(798674018215397431)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(798673081221397430)
,p_name=>unistr('enter im l\00E4nderfilter')
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P925_F_LAND'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(798672552127397430)
,p_event_id=>wwv_flow_imp.id(798673081221397430)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(798672157167397430)
,p_name=>unistr('Zusatzvereinbarung MSOR ver\00E4ndert')
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P925_ZUSATZVEREINBARUNG_MSOR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(798671710417397430)
,p_event_id=>wwv_flow_imp.id(798672157167397430)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P925_ZUSATZVEREINBARUNG_MSOR_D'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>'PCK_RI.fCreateLinkIfUrl(:P925_ZUSATZVEREINBARUNG_MSOR,80)'
,p_attribute_07=>'P925_ZUSATZVEREINBARUNG_MSOR'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(798671202357397429)
,p_event_id=>wwv_flow_imp.id(798672157167397430)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#P925_ZUSATZVEREINBARUNG_MSOR_inline_help'').html($v(''P925_ZUSATZVEREINBARUNG_MSOR_D''));'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(798670791878397429)
,p_name=>'Click delete'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(798686026043397451)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(798670309179397429)
,p_event_id=>wwv_flow_imp.id(798670791878397429)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Soll dieser Importeur wirklich gel\00F6scht werden?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(798669740177397428)
,p_event_id=>wwv_flow_imp.id(798670791878397429)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'DELETE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(798669363858397428)
,p_name=>'Marke VW ?'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P925_KONZERN_MARKEN'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$v(''P925_KONZERN_MARKEN'').split('':'').find(element => element == ''2'') == ''2'''
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(798668904365397428)
,p_event_id=>wwv_flow_imp.id(798669363858397428)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P925_FAHRZEUGKLASSEN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(798668403839397428)
,p_event_id=>wwv_flow_imp.id(798669363858397428)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P925_FAHRZEUGKLASSEN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(798667915713397428)
,p_event_id=>wwv_flow_imp.id(798669363858397428)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P925_FAHRZEUGKLASSEN'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1095750445472347791)
,p_name=>'Ansprechpartner Status Color & ToolTip'
,p_event_sequence=>150
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1095750379753347790)
,p_event_id=>wwv_flow_imp.id(1095750445472347791)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1027868469281176627)
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const CONSTANTS = {',
'    REGION_ID: ''R490939196568863415'',',
'    IMPORTEUR_ID_ITEM: ''P925_IMPORTEURID'',',
'    COLORS: {',
'        GREEN: ''#4CAF50'',',
'        RED: ''#FF0000''',
'    },',
'    TOOLTIP_TEXT: {',
'        green: ''Alle Konzern Cluster sind einem Ansprechpartner zugeordnet'',',
unistr('        red: ''<b>Achtung</b>: Mindestens ein Konzern Cluster ist keinem Ansprechpartner zugeordnet. Bitte \00FCberpr\00FCfen Sie die Zuordnungen.'''),
'    }',
'};',
'',
'function initializeAPStatusTooltips() {',
'    const $dots = apex.jQuery(`#${CONSTANTS.REGION_ID} .ap-dot`);',
'    ',
'    $dots.each(function() {',
'        const $dot = apex.jQuery(this);',
'        const backgroundColor = $dot.css(''background-color'');',
'        let tooltipContent;',
'        if (backgroundColor.includes(''rgb(76, 175, 80)'') || backgroundColor.includes(CONSTANTS.COLORS.GREEN)) {',
'            tooltipContent = CONSTANTS.TOOLTIP_TEXT.green;',
'        } else if (backgroundColor.includes(''rgb(255, 0, 0)'') || backgroundColor.includes(CONSTANTS.COLORS.RED)) {',
'            tooltipContent = CONSTANTS.TOOLTIP_TEXT.red;',
'        }',
'        $dot.removeAttr(''title'')',
'            .tooltip({',
'                content: tooltipContent,',
'                show: { effect: "fade", duration: 200 },',
'                hide: { effect: "fade", duration: 200 },',
'                position: { ',
'                    my: "left+10 top+20",',
'                    at: "right bottom",',
'                    collision: "flipfit"',
'                },',
'                tooltipClass: "status-tooltip",',
'                track: true,',
'                items: "*"',
'            });',
'    });',
'}',
'',
'function checkAnsprechpartnerStatus() {',
'    const importeurId = $v(CONSTANTS.IMPORTEUR_ID_ITEM);',
'    ',
'    apex.server.process(',
'        ''Ansprechpartner Cluster Assignment Status'',',
'        { ',
'            pageItems: ''#'' + CONSTANTS.IMPORTEUR_ID_ITEM',
'        },',
'        {',
'            success: function(pData) {',
'                const dotColor = pData.exists === ''true'' ? CONSTANTS.COLORS.GREEN : CONSTANTS.COLORS.RED;',
'                const status = pData.exists === ''true'' ? ''green'' : ''red'';',
'                ',
'                const $title = apex.jQuery(`#${CONSTANTS.REGION_ID} #ansprechpartner-title`);',
'                $title.html(`<span class="ap-title">',
'                    <span class="ap-dot" style="background:${dotColor}" data-status="${status}"></span>',
'                    Ansprechpartner',
'                    <span onclick="redirect(504)" class="fa fa-info-square-o" style="margin-left: 5px; cursor: pointer;"></span>',
'                </span>`);',
'                ',
'                initializeAPStatusTooltips();',
'            },',
'            error: function(xhr, status, error) {',
'                console.error(''Error checking Ansprechpartner status:'', error);',
'                apex.message.showErrors([{',
'                    type: "error",',
'                    location: ["page"],',
unistr('                    message: "Fehler beim Pr\00FCfen des Ansprechpartner-Status",'),
'                    unsafe: false',
'                }]);',
'            }',
'        }',
'    );',
'}',
'',
'',
'apex.jQuery(document).ready(function() {',
'    initializeAPStatusTooltips();',
'    checkAnsprechpartnerStatus();',
'});',
'',
'apex.jQuery(`#${CONSTANTS.REGION_ID}`).on("apexafterrefresh", function() {',
'    initializeAPStatusTooltips();',
'    checkAnsprechpartnerStatus();',
'});',
'',
'',
'',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(798683593484397441)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P925_IMPORTEURID is null then',
'    insert into T_IMPORTEUR (',
'        BEZEICHNUNG, GHV_DATUM, LETZTE_AENDERUNG_DATUM,',
'        LETZTE_AENDERUNG_BENUTZER_ID, VERANTWORTUNG_IMPORTEUR, CRO,',
'        ZUSATZVEREINBARUNG_MSOR, DATEN_ERFASST_KONTROLLIERT',
'    ) values (',
'        :P925_BEZEICHNUNG, :P925_GHV_DATUM, sysdate,',
'        PCK_RI.fGetUserId, :P925_VERANTWORTUNG_IMPORTEUR, :P925_CRO,',
'        :P925_ZUSATZVEREINBARUNG_MSOR, :P925_DATEN_ERFASST_KONTROLLIERT',
'    )        ',
'    returning importeurid into :p925_importeurid;',
'else',
'    update T_IMPORTEUR',
'    set BEZEICHNUNG = :P925_BEZEICHNUNG,',
'    GHV_DATUM = :P925_GHV_DATUM,',
'    LETZTE_AENDERUNG_DATUM = sysdate,',
'    LETZTE_AENDERUNG_BENUTZER_ID = PCK_RI.fGetUserId,',
'    CRO = :P925_CRO,',
'    zusatzvereinbarung_msor = :P925_ZUSATZVEREINBARUNG_MSOR,',
'    verantwortung_importeur = :P925_VERANTWORTUNG_IMPORTEUR,',
'    daten_erfasst_kontrolliert = :P925_DATEN_ERFASST_KONTROLLIERT',
'    where IMPORTEURID = :P925_IMPORTEURID;',
'end if;',
'',
'delete from t_importeur_ref_konzern_marke where importeurid = :P925_IMPORTEURID;',
'insert into t_importeur_ref_konzern_marke (importeurid, konzern_markeid)',
'select :P925_IMPORTEURID, column_value',
'from table(apex_string.split_numbers(:P925_KONZERN_MARKEN,'':''));',
'',
'delete from t_importeur_ref_kommunikationsart where importeurid = :P925_IMPORTEURID;',
'insert into t_importeur_ref_kommunikationsart (importeurid, kommunikationsartid)',
'select :P925_IMPORTEURID, column_value',
'from table(apex_string.split_numbers(:P925_KOMMUNIKATIONSART,'':''));',
'',
'delete from t_importeur_ref_konzern_cluster where importeurid = :P925_IMPORTEURID;',
'insert into t_importeur_ref_konzern_cluster (importeurid, konzern_clusterid)',
'select :P925_IMPORTEURID, column_value',
'from table(apex_string.split_numbers(:P925_KONZERN_CLUSTER,'':''));',
'',
'delete from t_importeur_ref_rtf where importeurid = :P925_IMPORTEURID;',
'insert into t_importeur_ref_rtf (importeurid, rtfid)',
'select :P925_IMPORTEURID, column_value',
'from table(apex_string.split_numbers(:P925_RTF,'':''));',
'',
'delete from t_importeur_ref_land where importeurid = :P925_IMPORTEURID;',
'insert into t_importeur_ref_land (importeurid, landid)',
'select :P925_IMPORTEURID, column_value',
'from table(apex_string.split_numbers(:P925_LAENDER,'':''));',
'',
'delete from t_importeur_ref_fahrzeugklasse where importeurid = :P925_IMPORTEURID;',
'insert into t_importeur_ref_fahrzeugklasse (importeurid, fahrzeugklasseid)',
'select :P925_IMPORTEURID, column_value',
'from table(apex_string.split_numbers(:P925_FAHRZEUGKLASSEN,'':''));'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE, SAVE_CLOSE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_process_success_message=>'Die Daten wurden gespeichert.'
,p_internal_uid=>2873528722414990794
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(798682793638397440)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DELETE'
,p_process_sql_clob=>'update t_importeur set is_deleted = 1 where importeurid = :P925_IMPORTEURID;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DELETE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>2873529522260990795
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(798683231047397441)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':REQUEST in (''SAVE_CLOSE'',''DELETE'')'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'SQL'
,p_internal_uid=>2873529084851990794
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(798683944385397442)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Initialize form Importeure bearbeiten/hinzuf\00FCgen')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (:P925_CAME_FROM = ''960'') then',
'    :P925_IMPORTEURID := :P960_CLICKED_IMPORTEUR;',
'end if;    ',
'',
'',
'if :P925_IMPORTEURID is not null then',
'    select bezeichnung, ghv_datum, verantwortung_importeur, cro, zusatzvereinbarung_msor, daten_erfasst_kontrolliert',
'    into :P925_BEZEICHNUNG, :P925_GHV_DATUM, :P925_VERANTWORTUNG_IMPORTEUR, :P925_CRO, :P925_ZUSATZVEREINBARUNG_MSOR, :P925_DATEN_ERFASST_KONTROLLIERT',
'    from t_importeur',
'    where importeurid = :P925_IMPORTEURID;',
'    ',
'    select listagg(konzern_markeid,'':'') into :P925_KONZERN_MARKEN',
'    from t_importeur_ref_konzern_marke',
'    where importeurid = :P925_IMPORTEURID;',
'    ',
'    select listagg(kommunikationsartid,'':'') into :P925_KOMMUNIKATIONSART',
'    from t_importeur_ref_kommunikationsart',
'    where importeurid = :P925_IMPORTEURID;',
'    ',
'    select listagg(konzern_clusterid,'':'') into :P925_KONZERN_CLUSTER',
'    from t_importeur_ref_konzern_cluster',
'    where importeurid = :P925_IMPORTEURID;',
'    ',
'    select listagg(rtfid,'':'') into :P925_RTF',
'    from t_importeur_ref_rtf',
'    where importeurid = :P925_IMPORTEURID;',
'    ',
'    select listagg(landid,'':'') into :P925_LAENDER',
'    from t_importeur_ref_land',
'    where importeurid = :P925_IMPORTEURID;',
'',
'    select listagg(fahrzeugklasseid,'':'') into :P925_FAHRZEUGKLASSEN',
'    from t_importeur_ref_fahrzeugklasse',
'    where importeurid = :P925_IMPORTEURID;',
'end if;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2873528371513990793
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(798682353646397440)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLaenderShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lLaendergruppe varchar2(2000) := apex_application.g_x02;',
'    lTextfilter varchar2(2000) := apex_application.g_x03;',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    for l in (',
'        select b_nummer || '' - '' || CASE ',
'    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'    ELSE land_eng',
'END as d, landid',
'        from t_land',
'        where landid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))        ',
'        and (',
'            lLaendergruppe is null',
'            or landid in (',
'                select landid from t_land_ref_laendergruppe where laendergruppeid in (',
'                    select column_value from table(apex_string.split_numbers(lLaendergruppe,'':''))',
'                )',
'            )',
'        )',
'        and (',
'            lTextfilter is null',
'            or instr(upper(b_nummer),upper(lTextFilter)) != 0',
'            or instr(upper(land),upper(lTextFilter)) != 0',
'        )',
'        --and (status_datenstand <> 0 and include_Land_inaktDaten=0 OR include_Land_inaktDaten=1 )',
'        order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'')        ',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.landid);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'    ',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2873529962252990795
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1095750224065347789)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Ansprechpartner Cluster Assignment Status'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_exists        VARCHAR2(5);',
'    l_importeur_id  NUMBER;',
'BEGIN',
'    l_importeur_id := :P925_IMPORTEURID;',
'    ',
'    SELECT ',
'        CASE ',
'            WHEN EXISTS (',
'                SELECT 1',
'                FROM t_importeur_ref_konzern_cluster ticrk',
'                WHERE ticrk.IMPORTEURID = l_importeur_id',
'                AND NOT EXISTS (',
'                    SELECT 1 ',
'                    FROM t_ansprechpartner_ref_konzern_cluster tark ',
'                    JOIN T_ANSPRECHPARTNER ta ',
'                        ON ta.ANSPRECHPARTNERID = tark.ANSPRECHPARTNERID',
'                    WHERE ta.IMPORTEURID = l_importeur_id',
'                    AND tark.KONZERN_CLUSTERID = ticrk.KONZERN_CLUSTERID',
'                )',
'            ) ',
unistr('            THEN ''false''  -- At least one is unassigned \2192 ROT'),
unistr('            ELSE ''true''   -- All are assigned \2192 GR\00DCN'),
'        END',
'    INTO l_exists',
'    FROM dual;',
'    ',
'    apex_json.open_object;',
'    apex_json.write(''exists'', l_exists);',
'    apex_json.close_object;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_json.open_object;',
'        apex_json.write(''exists'', ''false'');',
'        apex_json.write(''error'', SQLERRM);',
'        apex_json.close_object;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2576462091834040446
);
wwv_flow_imp.component_end;
end;
/
