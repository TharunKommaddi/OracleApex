prompt --application/pages/page_00640
begin
--   Manifest
--     PAGE: 00640
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>640
,p_name=>'GETEX IMPORT LIST'
,p_alias=>'GETEX-IMPORT-LIST'
,p_step_title=>'GETEX Import Liste'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(868148424454009783)
,p_plug_name=>'GETEX Vorschriften'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  GETEX_IMPORTID,  GETEX_SCHLUESSEL, ',
'  vv.v_nummer vorschrift_nummer,',
'    decode(Status, 1, ''hochgeladen'', 2, ''importiert'', 3, ''Fehler'', 3) as IMPORT_STATUS, ',
'    VORSCHRIFTID GETEX_VORSCHRIFTID, ZEITPUNKT_UPLOAD',
'    ',
'  from  T_X_GETEX_IMPORT gi',
'  join v_GETEX_VORSCHRIFT vv on (vv.v_id = gi.GETEX_SCHLUESSEL)',
'  order by vv.v_nummer'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'GETEX Vorschriften'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(875242132446362268)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:645:&SESSION.::&DEBUG.:645:P645_GETEX_SCHLUESSEL,P645_IMPORT_STATUS,P645_ZEITPUNKT_UPLOAD,P645_VORSCHRIFTID,P645_GETEX_IMPORTID:#GETEX_SCHLUESSEL#,#IMPORT_STATUS#,#ZEITPUNKT_UPLOAD#,#GETEX_VORSCHRIFTID#,#GETEX_IMPORTID#'
,p_detail_link_text=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>237450804648772136
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(875241975141362267)
,p_db_column_name=>'GETEX_IMPORTID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Getex Importid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(875241858546362266)
,p_db_column_name=>'GETEX_SCHLUESSEL'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Getex Schluessel'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(875241780990362265)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Vorschrift Nummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(875241695299362264)
,p_db_column_name=>'IMPORT_STATUS'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Import Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(875241457782362262)
,p_db_column_name=>'ZEITPUNKT_UPLOAD'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Zeitpunkt Upload'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(875241432658362261)
,p_db_column_name=>'GETEX_VORSCHRIFTID'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Getex Vorschriftid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(858220086503954460)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2544729'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'VORSCHRIFT_NUMMER:IMPORT_STATUS:GETEX_SCHLUESSEL:ZEITPUNKT_UPLOAD:GETEX_VORSCHRIFTID:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(868144201363009770)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414126953447820548)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3414151185686820583)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(3414145144550820567)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(868145847021009775)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(868148424454009783)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:645:&APP_SESSION.::&DEBUG.:645::'
,p_button_condition_type=>'NEVER'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(868145631429009774)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(868148424454009783)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(868145129520009773)
,p_event_id=>wwv_flow_imp.id(868145631429009774)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(868148424454009783)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
