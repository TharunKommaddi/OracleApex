prompt --application/pages/page_00203
begin
--   Manifest
--     PAGE: 00203
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>203
,p_name=>unistr('Regel\00FCberpr\00FCfung')
,p_alias=>unistr('REGEL\00DCBERPR\00DCFUNG')
,p_step_title=>unistr('Regel\00FCberpr\00FCfung')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(344200979156364076)
,p_plug_name=>unistr('Regel\00FCberpr\00FCfung')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select COCKPIT_DATENID,',
'       REGEL_NR,',
'       ANZEIGE_IN,',
'       case anzeige_in when 10 then ''verpflichtend'' when 20 then ''optional'' when 30 then ''zukunft'' else null end anzeige_in_text,',
'       d.VORSCHRIFTID,',
'       d.LANDID,',
'       l.b_nummer || '' - '' || l.land as land,',
'       d.THEMAID,',
'       t.bezeichnung as thema,',
'       RR_VORSCHRIFTID,',
'       ZEITPUNKT,',
'       VERKN_VORSCHRIFTID,',
'       v1.vorschrift_nummer,',
'       v_rr.vorschrift_nummer vorschrift_nummer_rr,',
'       v_v.vorschrift_nummer vorschrift_nummer_verkn',
'  from T_COCKPIT_DATEN d',
'  join t_land l on (d.landid = l.landid)',
'  join v_thema_baum t on (d.themaid = t.themaid)',
'  join t_vorschrift v1 on (d.vorschriftid = v1.vorschriftid)',
'  left outer join t_vorschrift v_rr on (d.rr_vorschriftid = v_rr.vorschriftid)',
'  left outer join t_vorschrift v_v on (d.verkn_vorschriftid = v_v.vorschriftid)',
'  where d.landid = nvl(:P203_LAND, d.landid)',
'  and d.themaid = nvl(:P203_THEMA, d.themaid)'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_page_header=>unistr('Regel\00FCberpr\00FCfung')
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(344200905508364076)
,p_name=>unistr('Regel\00FCberpr\00FCfung')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>768492031586770328
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(869097645119342715)
,p_db_column_name=>'COCKPIT_DATENID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Cockpit Datenid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(869097313495342715)
,p_db_column_name=>'REGEL_NR'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Regel Nr.'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(869096869789342715)
,p_db_column_name=>'ANZEIGE_IN'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Anzeige In'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(869096534129342715)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Vorschrift orig.'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::P25_VORSCHRIFTID:#VORSCHRIFTID##_blank'
,p_column_linktext=>'#VORSCHRIFT_NUMMER#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(869096125122342715)
,p_db_column_name=>'LANDID'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Landid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(869095735704342714)
,p_db_column_name=>'THEMAID'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Themaid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(869095281178342714)
,p_db_column_name=>'RR_VORSCHRIFTID'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Vorschrift RR'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::P25_VORSCHRIFTID:#RR_VORSCHRIFTID##_blank'
,p_column_linktext=>'#VORSCHRIFT_NUMMER_RR#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(869094841993342714)
,p_db_column_name=>'ZEITPUNKT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Zeitpunkt'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(869094493525342714)
,p_db_column_name=>'VERKN_VORSCHRIFTID'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Vorschrift vernetzt'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::P25_VORSCHRIFTID:#VERKN_VORSCHRIFTID##_blank'
,p_column_linktext=>'#VORSCHRIFT_NUMMER_VERKN#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(869100052519342717)
,p_db_column_name=>'LAND'
,p_display_order=>19
,p_column_identifier=>'J'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(869099665573342717)
,p_db_column_name=>'THEMA'
,p_display_order=>29
,p_column_identifier=>'K'
,p_column_label=>'Thema'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(869099255761342716)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>39
,p_column_identifier=>'L'
,p_column_label=>'Vorschrift Nummer'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(869098894138342716)
,p_db_column_name=>'ANZEIGE_IN_TEXT'
,p_display_order=>49
,p_column_identifier=>'M'
,p_column_label=>'Anzeige in'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(869098465003342716)
,p_db_column_name=>'VORSCHRIFT_NUMMER_RR'
,p_display_order=>59
,p_column_identifier=>'N'
,p_column_label=>'Vorschrift Nummer Rr'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(869098059022342716)
,p_db_column_name=>'VORSCHRIFT_NUMMER_VERKN'
,p_display_order=>69
,p_column_identifier=>'O'
,p_column_label=>'Vorschrift Nummer Verkn'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(344196734754361898)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2435988'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'REGEL_NR:VORSCHRIFTID:RR_VORSCHRIFTID:VERKN_VORSCHRIFTID:LAND:THEMA:ANZEIGE_IN_TEXT:VORSCHRIFT_NUMMER_VERKN:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(869093688522342705)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(344200979156364076)
,p_button_name=>'REFRESH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Daten aktualisieren'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(869093281541342704)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(344200979156364076)
,p_button_name=>'DOWNLOAD_RULEBOOK'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'Regeldefinitionen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'#APP_IMAGES#RegIndex_Darstellungsregeln_Cockpit.xlsx'
,p_icon_css_classes=>'fa-file-excel-o'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869092857086342704)
,p_name=>'P203_LAND'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(344200979156364076)
,p_prompt=>'Land'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b_nummer || '' - '' || CASE ',
'    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'    ELSE land_eng',
'END as d, landid as r',
'from t_land',
'order by b_nummer'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'alle'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'Y',
  'page_action_on_selection', 'SUBMIT')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869092477372342703)
,p_name=>'P203_THEMA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(344200979156364076)
,p_prompt=>'Thema'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nummer || '' - '' || bezeichnung as d, themaid as r',
'from v_thema_baum',
'order by thema_sortorder'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'alle'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'Y',
  'page_action_on_selection', 'SUBMIT')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(869092096511342703)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'REFRESH_DATA'
,p_process_sql_clob=>'pck_ri_cockpit2.pAufbereitungDaten;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(869093688522342705)
,p_internal_uid=>2803120219388045532
);
wwv_flow_imp.component_end;
end;
/
