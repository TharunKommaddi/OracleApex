prompt --application/pages/page_00929
begin
--   Manifest
--     PAGE: 00929
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>929
,p_name=>'Arbeitsaufgaben zuweisen'
,p_alias=>'ARBEITSAUFGABEN-ZUWEISEN'
,p_page_mode=>'MODAL'
,p_step_title=>'Arbeitsaufgaben zuweisen'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(401845672029217434)
,p_plug_name=>'Arbeitsaufgaben zuweisen'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_ARBEITSAUFGABE'
,p_include_rowid_column=>true
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(401841077956217397)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(401840677373217397)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(401841077956217397)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(401839045680217394)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(401841077956217397)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>unistr('javascript:apex.confirm(''M\00F6chten Sie diese Arbeitsaufgabe l\00F6schen?'',''DELETE'');')
,p_button_execute_validations=>'N'
,p_button_condition=>'P929_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(401838254486217393)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(401841077956217397)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Speichern & Schlie\00DFen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401845323732217433)
,p_name=>'P929_ROWID'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(401845672029217434)
,p_item_source_plug_id=>wwv_flow_imp.id(401845672029217434)
,p_source=>'ROWID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401844921431217420)
,p_name=>'P929_ARBEITSAUFGABE_TYPID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(401845672029217434)
,p_item_source_plug_id=>wwv_flow_imp.id(401845672029217434)
,p_prompt=>'Arbeitsaufgabe-Typ'
,p_source=>'ARBEITSAUFGABE_TYPID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN aufgabe_de',
'        ELSE aufgabe_en',
'    END, ',
'    arbeitsaufgabe_typid  ',
'FROM t_arbeitsaufgabe_typ',
'ORDER BY 1;',
''))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401844505386217414)
,p_name=>'P929_IMPORTEURID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(401845672029217434)
,p_item_source_plug_id=>wwv_flow_imp.id(401845672029217434)
,p_prompt=>'Importeur'
,p_source=>'IMPORTEURID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung, importeurid',
'from t_importeur',
'order by 2'))
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401844078455217409)
,p_name=>'P929_DATUM_AUFGABE'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(401845672029217434)
,p_item_source_plug_id=>wwv_flow_imp.id(401845672029217434)
,p_prompt=>'Datum Aufgabe'
,p_source=>'DATUM_AUFGABE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401843649862217405)
,p_name=>'P929_STATUS_AUFGABE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(401845672029217434)
,p_item_source_plug_id=>wwv_flow_imp.id(401845672029217434)
,p_prompt=>'Status Aufgabe'
,p_source=>'STATUS_AUFGABE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''offen'', ''open'') AS display_value, ',
'        10 AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''in Bearbeitung'', ''in progress'') AS display_value,',
'        20 AS return_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''erledigt'', ''completed'') AS display_value,',
'        30 AS return_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401843325862217400)
,p_name=>'P929_BEARBEITERID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(401845672029217434)
,p_item_source_plug_id=>wwv_flow_imp.id(401845672029217434)
,p_prompt=>'Bearbeiter'
,p_source=>'BEARBEITERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct nachname || '', '' || vorname || '' ('' || abteilung || '')'' as d, b.benutzerid as r',
'from t_benutzer b',
'join t_benutzer_ref_rolle brr on (brr.benutzerid = b.benutzerid)',
'where brr.rolleid in (1000,1050) -- VIK und VKO',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(401840597811217397)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(401840677373217397)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401839818190217396)
,p_event_id=>wwv_flow_imp.id(401840597811217397)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(401837528361217392)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(401845672029217434)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Arbeitsaufgaben zuweisen'
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (:P929_ROWID is null) then',
'    insert into t_arbeitsaufgabe (importeurid, arbeitsaufgabe_typid, datum_aufgabe, status_aufgabe, letzte_aenderung_datum, letzte_aenderung_benutzerid, bearbeiterid)',
'    values (:P929_IMPORTEURID, :P929_ARBEITSAUFGABE_TYPID, :P929_DATUM_AUFGABE, :P929_STATUS_AUFGABE, sysdate, pck_ri.fGetUserid, :P929_BEARBEITERID);',
'else',
'    update t_arbeitsaufgabe',
'    set importeurid = :P929_IMPORTEURID,',
'    arbeitsaufgabe_typid = :P929_ARBEITSAUFGABE_TYPID,',
'    datum_aufgabe = :P929_DATUM_AUFGABE,',
'    status_aufgabe = :P929_STATUS_AUFGABE,',
'    bearbeiterid = :P929_BEARBEITERID',
'    where rowid = :P929_ROWID;',
'end if;'))
,p_attribute_05=>'N'
,p_attribute_06=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(401838254486217393)
,p_internal_uid=>3270374787538170843
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(401859213535284899)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete'
,p_process_sql_clob=>'delete from T_ARBEITSAUFGABE where rowid = :P929_ROWID;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DELETE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>3270353102364103336
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(401837076850217391)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3270375239049170844
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(401837844159217392)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(401845672029217434)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Arbeitsaufgaben zuweisen'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3270374471740170843
);
wwv_flow_imp.component_end;
end;
/
