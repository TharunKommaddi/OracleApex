prompt --application/pages/page_00573
begin
--   Manifest
--     PAGE: 00573
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>573
,p_name=>unistr('Stichw\00F6rter')
,p_alias=>unistr('STICHW\00D6RTER')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Stichw\00F6rter')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'450'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2307614892780660675)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(637561291400734979)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2307614987258660675)
,p_plug_name=>'Stichworte'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2307615079607660675)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(656795747752690195)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2307615079607660675)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(656795384302690194)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2307615079607660675)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Zusammenfassung'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(656794981492690194)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2307615079607660675)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(656792808513690192)
,p_branch_action=>'f?p=&APP_ID.:574:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(656795384302690194)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(656793148956690193)
,p_branch_action=>'f?p=&APP_ID.:572:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(656794981492690194)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(656796908961690195)
,p_name=>'P573_STICHWORT_SEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2307614987258660675)
,p_prompt=>'Keywords'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (Select trim(s.column_value) slabel from t_mfv t,',
'apex_string.split(t.schlagworte,'','')s',
'where mfvid =:P581_MFVS ',
')',
'Select  LISTAGG (slabel ,'':'') r from cte1'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_SCHLAGWORT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- SELECT  stext as Schlagwort, SCHLAGWORTID as R, spath as Pfad ',
'-- FROM (',
'--   SELECT  stext, SCHLAGWORTID, sys_connect_by_path(stext, ''/'') spath',
'--   FROM T_SCHLAGWORT',
'--   CONNECT BY PRIOR SCHLAGWORTID = parentid',
'--   START WITH parentid IS NULL',
'-- );',
'',
'SELECT stext as Schlagwort, stext as R, spath as Pfad ',
'FROM (',
'  SELECT stext, SCHLAGWORTID, sys_connect_by_path(stext, ''/'') spath',
'  FROM T_SCHLAGWORT',
'  WHERE SCHLAGWORTID NOT IN (SELECT DISTINCT PARENTID FROM T_SCHLAGWORT WHERE PARENTID IS NOT NULL)',
'  CONNECT BY PRIOR SCHLAGWORTID = parentid',
'  START WITH parentid IS NULL',
');',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-w\00E4hlen-')
,p_cSize=>80
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'height', '350',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(656796511019690195)
,p_name=>'P573_HINWEIS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2307614987258660675)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('emano_util.fLang(''In diesem Dialog k\00F6nnen Sie Stichw\00F6rter die in REGINDEX gepflegt wurden ausw\00E4hlen. Es k\00F6nnen keine neuen Stichw\00F6rter angelegt, bzw. an JIRA \00FCbertragen, werden.'', '),
'''In this dialog, you can select keywords that have been maintained in REGINDEX. It is not possible to create new keywords or transfer them to JIRA.'') as mesage FROM dual;',
''))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Hinweis'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'Y',
  'character_counter', 'N',
  'resizable', 'N',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(656794197477690193)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(656795747752690195)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(656793670480690193)
,p_event_id=>wwv_flow_imp.id(656794197477690193)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(656794600778690194)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'save_Schagworerter'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--  delete only the the entries which are not in the  new list',
'',
'delete from T_VORSCHRIFT_REF_SCHLAGWORT where VORSCHRIFTID in (select column_value from table(apex_string.split_numbers(:P572_VORSCHRIFTEN_SEL,'':'')))',
'and SCHLAGWORTID not in (select column_value from table(apex_string.split_numbers(:P573_STICHWORT_SEL,'':'')));',
'',
'-- insert entries from the new list',
'for cur  in (select column_value from table ( apex_string.split_numbers(:P572_VORSCHRIFTEN_SEL,'':'')) ) LOOP',
'--   debug (''vorschr_Id ='', cur.column_value);',
'  ',
'  merge into T_VORSCHRIFT_REF_SCHLAGWORT vrs using  (',
'   select cur.column_value as VORSCHRIFT_ID, column_value as schlagwort_ID from table ( apex_string.split_numbers(:P573_STICHWORT_SEL,'':''))) src',
'   on (vrs.VORSCHRIFTID = src.VORSCHRIFT_ID and vrs.schlagwortID= src.schlagwort_ID )',
'   when not matched then',
'   insert  ( vrs.VORSCHRIFTID, vrs.schlagwortID)',
'   values ( src.VORSCHRIFT_ID,  src.schlagwort_ID);',
'   ',
'end loop;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>3015417715120698041
);
wwv_flow_imp.component_end;
end;
/
