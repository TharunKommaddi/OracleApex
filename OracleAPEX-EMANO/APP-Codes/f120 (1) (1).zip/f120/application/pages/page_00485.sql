prompt --application/pages/page_00485
begin
--   Manifest
--     PAGE: 00485
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>485
,p_name=>unistr('\00DCbergangsbestimmung_Farbe')
,p_alias=>unistr('\00DCBERGANGSBESTIMMUNG-FARBE')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('\00DCbergangsbestimmung_Farbe')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1982157648550127014)
,p_plug_name=>unistr('\00DCbergangsbestimmung_Farbe')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_UEBERGANGSBESTIMMUNG_FARBE'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1982159915602127094)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1073630302358731751)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1982159915602127094)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1073630704589731754)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1982159915602127094)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P485_UEBERGANGSBESTIMMUNG_FARBEID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1073629900812731751)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1982159915602127094)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P485_VORSCHRIFT_AENDERUNGID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1073629498112731751)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(1982159915602127094)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P485_VORSCHRIFT_AENDERUNGID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1073633770768731770)
,p_name=>'P485_UEBERGANGSBESTIMMUNG_FARBEID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1982157648550127014)
,p_item_source_plug_id=>wwv_flow_imp.id(1982157648550127014)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Uebergangsbestimmung Farbeid'
,p_source=>'UEBERGANGSBESTIMMUNG_FARBEID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1073633333499731765)
,p_name=>'P485_VORSCHRIFT_AENDERUNGID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1982157648550127014)
,p_item_source_plug_id=>wwv_flow_imp.id(1982157648550127014)
,p_prompt=>unistr('\00C4enderungsvorschrift ')
,p_source=>'VORSCHRIFT_AENDERUNGID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_VORSCHRIFT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select VORSCHRIFT_NUMMER || '' - '' || VORSCHRIFT_BEZEICHNUNG d,',
'       VORSCHRIFTID as r',
'  from T_VORSCHRIFT',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1073632937823731760)
,p_name=>'P485_FARBE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1982157648550127014)
,p_item_source_plug_id=>wwv_flow_imp.id(1982157648550127014)
,p_prompt=>'Farbe'
,p_source=>'FARBE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:lightgreen;lightgreen,brown;brown,red;red,orange;orange,pink;pink,gray;gray'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1073627088153731748)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1073630302358731751)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1073626531222731747)
,p_event_id=>wwv_flow_imp.id(1073627088153731748)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1073631390253731755)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(1982157648550127014)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('Process form \00DCbergangsbestimmung_Farbe')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2598580925645656480
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1073628655362731749)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_uebergangsbestimmung_farbe ',
'set farbe =:P485_FARBE',
'where uebergangsbestimmung_farbeID = :P485_UEBERGANGSBESTIMMUNG_FARBEID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1073629900812731751)
,p_process_when=>'P485_UEBERGANGSBESTIMMUNG_FARBEID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>2598583660536656486
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1073628314308731749)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Insert'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into  t_uebergangsbestimmung_farbe (farbe, VORSCHRIFT_AENDERUNGID)',
' values(:P485_FARBE, :P485_VORSCHRIFT_AENDERUNGID);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1073629498112731751)
,p_process_when=>'P485_UEBERGANGSBESTIMMUNG_FARBEID'
,p_process_when_type=>'ITEM_IS_NULL'
,p_internal_uid=>2598584001590656486
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1073627873234731749)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('L\00F6schen')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from t_uebergangsbestimmung_farbe ',
'where uebergangsbestimmung_farbeid = :P485_UEBERGANGSBESTIMMUNG_FARBEID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1073630704589731754)
,p_process_when=>'P485_UEBERGANGSBESTIMMUNG_FARBEID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>2598584442664656486
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1073627511149731748)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2598584804749656487
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1073631751815731757)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(1982157648550127014)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form \00DCbergangsbestimmung_Farbe')
,p_process_when_type=>'NEVER'
,p_internal_uid=>2598580564083656478
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1073629110270731750)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Initialise  Form'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  Farbe, VORSCHRIFT_AENDERUNGID --uebergangsbestimmung_farbeid, ',
'into  :P485_FARBE , :P485_VORSCHRIFT_AENDERUNGID',
' from t_uebergangsbestimmung_farbe ',
'where UEBERGANGSBESTIMMUNG_FARBEID = :P485_UEBERGANGSBESTIMMUNG_FARBEID;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P485_UEBERGANGSBESTIMMUNG_FARBEID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>2598583205628656485
);
wwv_flow_imp.component_end;
end;
/
