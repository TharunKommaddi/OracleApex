prompt --application/pages/page_00250
begin
--   Manifest
--     PAGE: 00250
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>250
,p_name=>'Keywords'
,p_step_title=>'Keywords'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(644982715742150431)
,p_plug_name=>'Keywords - Listenansicht'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT s."ROWID" AS xrowid,',
'       s.SCHLAGWORTID,',
'       s.STEXT AS schlagwort,',
'       s.LETZTE_AENDERUNG_DATUM,',
'       s.LETZTE_AENDERUNG_BENUTZERID,',
'       sp.stext AS parent',
'FROM "#OWNER#"."T_SCHLAGWORT" s',
'LEFT OUTER JOIN T_SCHLAGWORT sp ON (s.parentid = sp.SCHLAGWORTID)',
'WHERE s.SCHLAGWORTID NOT IN (SELECT DISTINCT parentid FROM "#OWNER#"."T_SCHLAGWORT" WHERE parentid IS NOT NULL);',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Keywords - Listenansicht'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(644982323798150431)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:255:&SESSION.::&DEBUG.:RP,:P255_ROWID:#XROWID##ROWID#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>467710613296983973
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644981092659150426)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>unistr('Letzte \00C4nderung')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644980703129150426)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZERID'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Letzte Aenderung Benutzerid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644978892238140103)
,p_db_column_name=>'SCHLAGWORTID'
,p_display_order=>15
,p_column_identifier=>'F'
,p_column_label=>'Schlagwortid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644978811703140102)
,p_db_column_name=>'XROWID'
,p_display_order=>25
,p_column_identifier=>'G'
,p_column_label=>'Xrowid'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644978679534140101)
,p_db_column_name=>'PARENT'
,p_display_order=>35
,p_column_identifier=>'H'
,p_column_label=>'Parent'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644978619131140100)
,p_db_column_name=>'SCHLAGWORT'
,p_display_order=>45
,p_column_identifier=>'I'
,p_column_label=>'Keyword'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(644969978913074569)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4677230'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SCHLAGWORT:PARENT:LETZTE_AENDERUNG_DATUM:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(644979285793150423)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(644982715742150431)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:255:&SESSION.::&DEBUG.:255::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(644978347834140098)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(644982715742150431)
,p_button_name=>'BAUMANSICHT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Baumansicht'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:251:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(644980309510150425)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(644982715742150431)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(644979773802150423)
,p_event_id=>wwv_flow_imp.id(644980309510150425)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(644982715742150431)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
