prompt --application/pages/page_00343
begin
--   Manifest
--     PAGE: 00343
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>343
,p_name=>unistr('Funktionen ausw\00E4hlen (Mehrfachauswahl)')
,p_alias=>unistr('FUNKTIONEN-AUSW\00C4HLEN-MEHRFACHAUSWAHL')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Funktionen ausw\00E4hlen (Mehrfachauswahl)')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function getParentArray(n){',
'    var arr = [], ln = n;',
'    while (ln._parent !== null) arr.push(ln = ln._parent);',
'    return arr.reverse(); // in correct order',
'};',
'',
'function expandUpTo(aID) {',
'    if (aID == '''') return;',
'    var tree = $("#mytree div[role=''tree'']");',
'    ',
'    var arr = tree.treeView("getExpandedNodeIds");',
'    if (arr.indexOf(aID.toString()) != -1) {',
'        console.log(''skip!!!'');',
'        return;',
'    } ',
'    ',
'    ',
'    var treenode = tree.treeView("find", {',
'        depth: -1,',
'        findAll: false,',
'        match: function(n) {',
'            return n.id == aID;',
'        }',
'    });',
'',
'    var mnode = tree.treeView("getNodes",treenode);',
'',
'    try {',
'        getParentArray(mnode[0]).forEach(function(p){',
'            if (arr.indexOf(p.id.toString()) != -1) {',
'                throw BreakException;            ',
'            }',
'            tree.treeView("expand",tree.treeView("getTreeNode",p));',
'        });',
'    } catch (e) {',
'        null;',
'    }        ',
'}',
'',
'$(''#r_vo'').on(''click'', ''th input'', function() {',
'    var check_all = $("#r_vo").find("th input:checked").is(":checked");',
'',
'    $("#r_vo").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'});'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var tree$ = $("#mytree div[role=''tree'']"), // change this to use whatever id you give the tree',
'    nodeAdapter = tree$.treeView("getNodeAdapter");',
'',
'// Set a custom node renderer that adds a checkbox icon span',
'nodeAdapter.renderNodeContent = function( node, out, options, state ) {',
'    out.markup("<span class=''treeSelCheck''></span>"); // this is the checkbox - its not a real checkbox input',
'    // the rest of this code is essentially a copy of what is in widget.treeView.js function renderTreeNodeContent',
'    if ( this.getIcon ) {',
'        icon = this.getIcon( node );',
'        if ( icon !== null ) {',
'            out.markup( "<span" ).attr( "class", options.iconType + " " + icon ).markup( "></span>" );',
'        }',
'    }',
'    link = options.useLinks && this.getLink && this.getLink( node );',
'    if ( link ) {',
'        elementName = "a";',
'    } else {',
'        elementName = "span";',
'    }',
'    out.markup( "<" + elementName + " tabIndex=''-1'' role=''treeitem''" ).attr( "class",options.labelClass )',
'        .optionalAttr( "href", link )',
'        .attr( "aria-level", state.level )',
'        .attr( "aria-selected", state.selected ? "true" : "false" )',
'        .optionalAttr( "aria-disabled", state.disabled ? "true" : null )',
'        .optionalAttr( "aria-expanded", state.hasChildren === false ? null : state.expanded ? "true" : "false" )',
'        .markup( ">" )',
'        .content( this.getLabel( node ) )',
'        .markup( "</" + elementName + ">" );',
'',
'};',
'',
'',
'',
'// Standard Event Handler des Trees deaktivieren',
'tree$.off("click");',
'',
'tree$.treeView("option","multiple", true) // make the tree support multiple selection',
'    .treeView("refresh") // refresh so that all the nodes are redrawn with custom renderer',
'    .on("click", ".treeSelCheck", function(event) { // make that "checkbox" span control the selection',
'        var nodeContent$ = $(event.target).closest(".a-TreeView-content"),',
'            isSelected = nodeContent$.hasClass("is-selected"),',
'            selection$ = tree$.treeView("getSelection");',
'        if ( isSelected ) {',
'            selection$ = selection$.not(nodeContent$);',
'        } else {',
'            selection$ = selection$.add(nodeContent$);',
'        }',
'        tree$.treeView("setSelection", selection$);',
'        return false; // stop propagation and prevent default',
'    });',
'',
'tree$.on("click",".fa-level-down", function(event) {',
'    var nodeContent$ = $(event.target).closest(".a-TreeView-content"),',
'        isSelected = nodeContent$.hasClass("is-selected"),',
'        modelNode = tree$.treeView("getNodes",nodeContent$)[0],',
'        selection$ = tree$.treeView("getSelection");',
'    /*dynActionActive = false;',
'    if (isSelected) {',
'        toggleSubTree(modelNode,false);',
'    } else {        ',
'        toggleSubTree(modelNode,true);        ',
'    }',
'    dynActionActive = true;*/',
'    ',
'    tree$.treeView("expandAll",nodeContent$);',
'    if (isSelected) {',
'        selection$ = selection$.not($(event.target).parent().parent().find(''.a-TreeView-content''));',
'    } else {',
'        selection$ = selection$.add($(event.target).parent().parent().find(''.a-TreeView-content''));',
'    }',
'    tree$.treeView("setSelection", selection$);',
'    ',
'    ',
'    ',
'    ',
'    return false;',
'    ',
'});',
'',
'tree$.on("click",".a-TreeView-toggle", function(event) {',
'    var nodeContent$ = $(event.target).next(),',
'        treeNode = nodeContent$.parent(),',
'        isExpanded = treeNode.hasClass("is-collapsible");',
'    if (isExpanded) {',
'        //tree$.treeView("collapse",nodeContent$);    ',
'        treeNode.removeClass("is-collapsible").addClass("is-expandable").children(".a-TreeView-content").find(".a-TreeView-label").attr("aria-expanded", false );',
'        treeNode.children( "ul" ).hide();            ',
'    } else {',
'        tree$.treeView("expand",nodeContent$);  ',
'    ',
'    }',
'    return false; ',
'});',
'',
'var selected = $v("P343_SELECTED");',
'if (selected != "") {',
'    var splitSelected = $v("P343_SELECTED").split(":");',
'    if (splitSelected.length <= 100) {',
'        $v("P343_SELECTED").split(":").forEach(function(i) { expandUpTo(i) });  ',
'    } else {',
'        tree$.treeView("expandAll");',
'    }',
'    tree$.treeView("setSelectedNodes", $v("P343_SELECTED").split(":").map(function(i) { return { id: i }; }));       ',
'}'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* These are the same styles as fa */',
'.treeSelCheck {',
'    display: inline-block;',
'    font: normal normal normal 14px/1 "Font APEX Small";',
'    text-rendering: auto;',
'    width: 14px;',
'    margin-right: 4px;',
'    cursor: default;',
'    color: black;',
'}',
'',
'/* fa-square-o */',
'.treeSelCheck::before {',
unistr('    content: "\F096";'),
'}',
'',
'/* fa-check-square-o */',
'.is-selected > .treeSelCheck::before {',
unistr('    content: "\F046";'),
'}',
'',
'',
'.a-TreeView-row.is-selected {',
'    border-bottom: none !important;',
'    background-color: #f7f7f7 !important;',
'    color: black;',
'}',
'',
'.a-TreeView-content.is-selected .a-Icon, .a-TreeView-content.is-selected .a-TreeView-label {',
'    color: black;',
'}',
'.a-TreeView-row.is-selected+.a-TreeView-toggle {',
'    color: black;',
'}',
'',
'.a-TreeView-row.is-selected, .a-TreeView-row.is-selected.is-hover {',
'    ',
'}',
'',
'',
'',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(653889888646692692)
,p_name=>'Vorschriften'
,p_region_name=>'r_vo'
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    select APEX_ITEM.CHECKBOX2(2, v.vorschriftid, null, :P343_SELECTED_VORSCHRIFTEN_FU_P35, '':'' ) as checkbox, ',
'         v.vorschrift_nummer  --, vrf.funktionid',
'       , listagg( fu.bezeichnung, '','' on overflow truncate ''...'') within group (order by fu.bezeichnung) Funktionen',
'    from t_Vorschrift_ref_thema vrt',
'    join t_vorschrift v  on (v.vorschriftid = vrt.vorschriftid )',
'    join t_Thema t on (t.Themaid = vrt.Themaid and vrt.geloescht =0)',
'     left join t_vorschrift_ref_funktion vrf on (vrf.vorschriftid = v.vorschriftid)',
'    left join t_funktion fu on (fu.funktionid = vrf.funktionid and vrf.geloescht=0)',
'     where vrt.themaid = :P343_THEMAID',
'     -- where cte.vorschriftid= 11260',
'    group by v.vorschrift_nummer, v.vorschriftid'))
,p_display_when_condition=>'(:P343_CAME_FROM = 35 and :P343_THEMAID is not null)'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(644171678445575985)
,p_query_column_id=>1
,p_column_alias=>'CHECKBOX'
,p_column_display_sequence=>10
,p_column_heading=>'<input type="checkbox" />'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(653889642674692690)
,p_query_column_id=>2
,p_column_alias=>'VORSCHRIFT_NUMMER'
,p_column_display_sequence=>20
,p_column_heading=>'Vorschrift Nummer'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(653889549781692689)
,p_query_column_id=>3
,p_column_alias=>'FUNKTIONEN'
,p_column_display_sequence=>30
,p_column_heading=>'Funktionen'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(644172301076575991)
,p_name=>'Test'
,p_region_name=>'r_tst'
,p_template=>wwv_flow_imp.id(2707059584407204267)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APEX_ITEM.CHECKBOX2(1, chb , null, :P343_TESTIDS, '':'') as checkbox,',
'chb FROM',
'(   select 1 as chb from dual',
'    union ',
'    select 2 as chb from dual',
'    union ',
'    select 3 as chb from dual',
'    union ',
'    select 4 as chb from dual',
')'))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(644171956289575988)
,p_query_column_id=>1
,p_column_alias=>'CHECKBOX'
,p_column_display_sequence=>20
,p_column_heading=>'<input type="checkbox" />'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(644172143271575990)
,p_query_column_id=>2
,p_column_alias=>'CHB'
,p_column_display_sequence=>10
,p_column_heading=>'Chb'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(544709943340649678)
,p_plug_name=>'Dialog Footer'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(277166844946629722)
,p_plug_name=>'Funktionen (Baumansicht)'
,p_region_name=>'mytree'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select funktionid, parentid,  substr(case when (status = emano_util.fLang(''freigegeben'', ''released'')) then to_char(id_aus_excel)||''-''||bezeichnung',
'                                   else to_char(id_aus_excel)||''-''||bezeichnung ||'' - - '' || status end,1,500)   ',
'    as bezeichnung_1,              ',
'      ''javascript:$s("P343_SELECTED","'' || funktionid || ''")''   as link',
'from t_funktion',
'-- default  expoired ausblenden',
'where (:P343_EXPIRED_AUS=1 and (status is null or status != emano_util.fLang(''veraltet'', ''expired'') ) )',
'      OR :P343_EXPIRED_AUS=0 ;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_JSTREE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'activate_node_link_with', 'S',
  'node_id_column', 'FUNKTIONID',
  'node_label_column', 'BEZEICHNUNG_1',
  'node_value_column', 'FUNKTIONID',
  'parent_key_column', 'PARENTID',
  'selected_node_page_item', 'P343_SELECTED',
  'start_tree_with', 'NULL',
  'tree_hierarchy', 'SQL',
  'tree_tooltip', 'N')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(814504216089929031)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(277166844946629722)
,p_button_name=>'NO_PARENT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Ohne Parent'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P343_CAME_FROM'
,p_button_condition2=>'345'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(814501949967929004)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(544709943340649678)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(653888894697692682)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(544709943340649678)
,p_button_name=>'APPL2'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Zwischenspeichern'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P343_CAME_FROM'
,p_button_condition2=>'35'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(838323178732542687)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(544709943340649678)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P343_CAME_FROM'
,p_button_condition2=>'25'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(814502359362929005)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(544709943340649678)
,p_button_name=>'APPLY'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P343_CAME_FROM != 35 and :P343_CAME_FROM !=25'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(838323530982542690)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(277166844946629722)
,p_button_name=>'RESET_V'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Zur\00FCcksetzung auf Zuordnungen zu Themengebiet')
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P343_CAME_FROM'
,p_button_condition2=>'25'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(495808069420818190)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(277166844946629722)
,p_button_name=>'EXPAND'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Alle aufklappen'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(495807801743818187)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(277166844946629722)
,p_button_name=>'COLLAPSE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Alle zuklappen'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3148580006785251406)
,p_name=>'P343_EXPIRED_AUS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(277166844946629722)
,p_item_default=>'1'
,p_prompt=>'Expired ausblenden'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', '1',
  'unchecked_value', '0',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(838324421570542699)
,p_name=>'P343_THEMAID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(277166844946629722)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(838323616287542691)
,p_name=>'P343_VORSCHRIFTID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(277166844946629722)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(814503807100929021)
,p_name=>'P343_CAME_FROM'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(277166844946629722)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(814503462784929014)
,p_name=>'P343_SELECTED'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(277166844946629722)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(814503056779929014)
,p_name=>'P343_D_SELECTED'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(277166844946629722)
,p_prompt=>unistr('Gew\00E4hlt')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(653889370679692687)
,p_name=>'P343_SELECTED_VORSCHRIFTEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(653889888646692692)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(653887574908692669)
,p_name=>'P343_SELECTED_VORSCHRIFTEN_FU_P35'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(653889888646692692)
,p_use_cache_before_default=>'NO'
,p_source=>'select :P35_SELECTED_VORSCHRIFTEN_FU from dual;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(644172111385575989)
,p_name=>'P343_TESTIDS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(644172301076575991)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(814500688972928959)
,p_name=>'Close Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(814502359362929005)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(814500148290928959)
,p_event_id=>wwv_flow_imp.id(814500688972928959)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
,p_attribute_01=>'P343_SELECTED'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(814498907881928959)
,p_name=>'Changed'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P343_SELECTED'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(814498357828928958)
,p_event_id=>wwv_flow_imp.id(814498907881928959)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P343_D_SELECTED'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lReturn varchar2(4000);',
'begin',
'    select listagg(f.bezeichnung,'', '' ON OVERFLOW TRUNCATE ''...'') within group (order by f.bezeichnung) into lReturn',
'    from t_funktion f',
'    join table(apex_string.split_numbers(:P343_SELECTED,'':'')) c on (f.funktionid = c.column_value and  f.status not in ( emano_util.fLang(''veraltet'', ''outdated''),',
'            emano_util.fLang(''in Bearbeitung'', ''in Progress'') ) );',
'    ',
'    return lReturn;',
'exception',
'    when no_data_found then',
'        return emano_util.fLang(''kein Parent'', ''no Parent'');',
'end;'))
,p_attribute_07=>'P343_SELECTED'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(814499789609928959)
,p_name=>'Cancel Dialog'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(814501949967929004)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(814499238627928959)
,p_event_id=>wwv_flow_imp.id(814499789609928959)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(814501608015928967)
,p_name=>'no parent'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(814504216089929031)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(814501094763928961)
,p_event_id=>wwv_flow_imp.id(814501608015928967)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P343_SELECTED'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(838324618244542701)
,p_name=>'tree selection change'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(277166844946629722)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'treeviewselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(838324461065542700)
,p_event_id=>wwv_flow_imp.id(838324618244542701)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var nodes = $("#mytree div[role=''tree'']").treeView("getSelectedNodes");',
'$s("P343_SELECTED", nodes.map(function(n) {return n.id;}).join(":"));'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(495807979727818189)
,p_name=>'Expand'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(495808069420818190)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(495807851138818188)
,p_event_id=>wwv_flow_imp.id(495807979727818189)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(277166844946629722)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(495807678130818186)
,p_name=>'Collapse'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(495807801743818187)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(495807627944818185)
,p_event_id=>wwv_flow_imp.id(495807678130818186)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_COLLAPSE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(277166844946629722)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3148579828990251405)
,p_name=>'Change'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P343_EXPIRED_AUS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3148579797120251404)
,p_event_id=>wwv_flow_imp.id(3148579828990251405)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P343_EXPIRED_AUS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3148579693593251403)
,p_event_id=>wwv_flow_imp.id(3148579828990251405)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(277166844946629722)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(644171921323575987)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Test Auslese'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P343_TESTIDS := null;',
'   debug('' P343: count G_F01 = ''|| APEX_APPLICATION.G_F01.COUNT);',
'     FOR i IN 1 .. APEX_APPLICATION.G_F02.COUNT LOOP ',
'     --debug('' P343: element ''||I||'' = ''||APEX_APPLICATION.G_F02(i)); ',
'      :P343_TESTIDS := :P343_TESTIDS || APEX_APPLICATION.G_F01(i) || '':'';',
'     END LOOP; '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>3028040394575812248
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(653889453678692688)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Auslesen Vorschriften'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'   :P343_SELECTED_VORSCHRIFTEN := null;',
'   --debug('' P343: count G_F02 = ''|| APEX_APPLICATION.G_F02.COUNT);',
'     FOR i IN 1 .. APEX_APPLICATION.G_F02.COUNT LOOP ',
'     --debug('' P343: element ''||I||'' = ''||APEX_APPLICATION.G_F02(i)); ',
'      :P343_SELECTED_VORSCHRIFTEN := :P343_SELECTED_VORSCHRIFTEN || APEX_APPLICATION.G_F02(i) || '':'';',
'     END LOOP; ',
'    -- debug(''P343, P343_SELECTED_VORSCHRIFTEN = ''|| :P343_SELECTED_VORSCHRIFTEN);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(653888894697692682)
,p_internal_uid=>3018322862220695547
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(838323279434542688)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Reset f\00FCr Vorschrift')
,p_process_sql_clob=>'pck_ri.pResetFunktionen(:P343_VORSCHRIFTID);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(838323530982542690)
,p_internal_uid=>2833889036464845547
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(838323084023542686)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Speichern f\00FCr Vorschrift')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_vorschrift_ref_funktion',
'set geloescht = 1, letzte_aenderung_datum = sysdate, letzte_aenderung_benutzerid = pck_ri.fGetUserId',
'where vorschriftid = :P343_VORSCHRIFTID',
'and geloescht = 0',
'and funktionid not in (',
'    select column_value',
'    from table(apex_string.split_numbers(:P343_SELECTED,'':''))',
');',
'',
'update t_vorschrift_ref_funktion',
'set geloescht = 0, letzte_aenderung_datum = sysdate, letzte_aenderung_benutzerid = pck_ri.fGetUserId',
'where vorschriftid = :P343_VORSCHRIFTID',
'and geloescht = 1',
'and funktionid in (',
'    select column_value',
'    from table(apex_string.split_numbers(:P343_SELECTED,'':''))',
');',
'',
'insert into t_vorschrift_ref_funktion (',
'    vorschriftid, funktionid, letzte_aenderung_benutzerid, letzte_aenderung_datum',
')',
'with cte1 as (',
'    select column_value as funktionid',
'    from table(apex_string.split_numbers(:P343_SELECTED,'':''))',
')',
'select :P343_VORSCHRIFTID, funktionid, pck_ri.fGetUserId, sysdate',
'from cte1',
'where funktionid not in (',
'    select funktionid',
'    from t_vorschrift_ref_funktion',
'    where vorschriftid = :P343_VORSCHRIFTID',
') and funktionid not in (select funktionid from t_funktion ',
'                         where status in (emano_util.fLang(''veraltet'', ''outdated''), emano_util.fLang(''in Bearbeitung'', ''in progress'')));',
'                  '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(838323178732542687)
,p_internal_uid=>2833889231875845549
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(838322597480542681)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close dialog'
,p_attribute_01=>'P343_SELECTED,P343_SELECTED_VORSCHRIFTEN'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE, APPL2'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2833889718418845554
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(838324317964542698)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (:P343_CAME_FROM in (35)) then',
'',
'',
'    :P343_SELECTED := :P35_FUNKTIONEN;',
'    :P343_SELECTED_VORSCHRIFTEN_FU_P35 := :P35_SELECTED_VORSCHRIFTEN_FU;',
'    --debug (''P343_SELECTED_VORSCHRIFTEN_FU_P35=''|| :P343_SELECTED_VORSCHRIFTEN_FU_P35);',
'    /*select listagg(funktionid,'':'') within group (order by funktionid) into :P343_SELECTED',
'    from t_thema_ref_funktion',
'    where themaid = :P343_THEMAID;*/',
'end if;',
'if (:P343_CAME_FROM in (25)) then',
'    select listagg(funktionid,'':'') within group (order by funktionid) into :P343_SELECTED',
'    from t_vorschrift_ref_funktion',
'    where vorschriftid = :P343_VORSCHRIFTID',
'    and geloescht = 0;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2833887997934845537
);
wwv_flow_imp.component_end;
end;
/
