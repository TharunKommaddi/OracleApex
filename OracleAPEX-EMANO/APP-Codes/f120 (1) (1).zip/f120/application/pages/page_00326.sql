prompt --application/pages/page_00326
begin
--   Manifest
--     PAGE: 00326
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>326
,p_name=>'Historische Suchen laden/verwalten'
,p_page_mode=>'MODAL'
,p_step_title=>'Historische Suchen laden/verwalten'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1460575302694518264)
,p_plug_name=>'Alert'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--danger:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'htp.p(''',
unistr('Zum Speichern und Laden von Suchparametern ist eine Registrierung als Benutzer notwendig. Sie konnten jedoch nicht im LDAP gefunden werden, sodass dies nicht m\00F6glich ist.<br /><r />'),
'Ihre GID: '' || OWA_UTIL.GET_CGI_ENV(''HTTP_GID'') || ''<br /><br />Bitte wenden Sie sich an einen Administrator.'');'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'pck_ri.fUserIsCreatable() = 20'
,p_plug_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2663603546522436634)
,p_plug_name=>'Historische Suche laden'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select SUCHEID,',
'       ''edit'' as EDIT_LINK,',
'       BEZEICHNUNG,',
'       BESCHREIBUNG,',
'       BENUTZERID,',
'       ZEITPUNKT,',
'       SUCHDATEN,',
'       ''delete'' AS DELETE_LINK',
'  from T_SUCHE_JSON',
'  where BENUTZERID = :G_BENUTZERID;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'pck_ri.fUserIsCreatable() = 10'
,p_plug_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2663603605709436634)
,p_name=>'Historische Suche laden'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'Noch keine historischen Suchen gespeichert.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_enable_mail_download=>'N'
,p_detail_link=>'f?p=&APP_ID.:320:&SESSION.::&DEBUG.:RP,320:P320_SUCHEID:#SUCHEID#'
,p_detail_link_text=>'<span class="fa fa-box-arrow-out-east" aria-hidden="true"></span>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>174257039751164398
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2663604054331436642)
,p_db_column_name=>'SUCHEID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Sucheid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1020292267760660192)
,p_db_column_name=>'EDIT_LINK'
,p_display_order=>11
,p_column_identifier=>'H'
,p_column_label=>'<span title="Suche bearbeiten">&nbsp;</span>'
,p_column_link=>'f?p=&APP_ID.:329:&SESSION.::&DEBUG.:329:P329_SUCHEID:#SUCHEID#'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-pencil"></span>'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2663604425091436656)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>21
,p_column_identifier=>'B'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2663604821140436656)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>31
,p_column_identifier=>'C'
,p_column_label=>'Beschreibung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2663605192846436657)
,p_db_column_name=>'BENUTZERID'
,p_display_order=>41
,p_column_identifier=>'D'
,p_column_label=>'Benutzerid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2663605665302436657)
,p_db_column_name=>'ZEITPUNKT'
,p_display_order=>51
,p_column_identifier=>'E'
,p_column_label=>'Zeitpunkt'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY HH24:Mi'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1029689898615519354)
,p_db_column_name=>'DELETE_LINK'
,p_display_order=>71
,p_column_identifier=>'G'
,p_column_label=>unistr('<span title="Suche l\00F6schen">&nbsp;</span>')
,p_column_link=>'f?p=&APP_ID.:328:&SESSION.::&DEBUG.:328:P328_SUCHEID,P328_BEZEICHNUNG:#SUCHEID#,#BEZEICHNUNG#'
,p_column_linktext=>'<span class="fa fa-trash-o" aria-hidden="true"></span>'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(842882852130700800)
,p_db_column_name=>'SUCHDATEN'
,p_display_order=>81
,p_column_identifier=>'I'
,p_column_label=>'Suchdaten'
,p_column_type=>'CLOB'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2663607426678466901)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1742609'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EDIT_LINK:BEZEICHNUNG:BESCHREIBUNG:ZEITPUNKT:DELETE_LINK'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1020292447507660194)
,p_name=>'Dialog Delete Suche closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2663603546522436634)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1020292356220660193)
,p_event_id=>wwv_flow_imp.id(1020292447507660194)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2663603546522436634)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
