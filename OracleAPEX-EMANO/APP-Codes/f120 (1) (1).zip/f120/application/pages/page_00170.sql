prompt --application/pages/page_00170
begin
--   Manifest
--     PAGE: 00170
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>170
,p_name=>'Hilfe'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Hilfe'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_dialog_height=>'600'
,p_dialog_width=>'800'
,p_dialog_resizable=>'Y'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1455206704221506576)
,p_plug_name=>'&P170_TITEL.'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for t in (',
'    with cte1 as (',
'        select hilfetext',
'        from t_hilfe',
'        where hilfeid = :P170_HILFEID',
'    )',
'        select substr(hilfetext,(level-1)*2000,2000) as text',
'        from cte1',
'        connect by level <= ceil(length(hilfetext)/2000)',
') loop',
'    htp.p(t.text);',
'end loop;',
''))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(789494807066286996)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1455206704221506576)
,p_button_name=>'BESTAETIGEN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hiermit best\00E4tige ich die Hinweise gelesen und verstanden zu haben')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P170_HILFEID'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1455206262055506572)
,p_name=>'P170_HILFEID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1455206704221506576)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1455206432047506574)
,p_name=>'P170_TITEL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1455206704221506576)
,p_use_cache_before_default=>'NO'
,p_source=>'select titel from t_hilfe where hilfeid = :P170_HILFEID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(789494684674286995)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Bestaetigung speichern'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update T_BENUTZER',
'set BESTAETIGUNG_DATUM = sysdate',
'where BenutzerId = :G_BENUTZERID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(789494807066286996)
,p_internal_uid=>2882717631225101240
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(789494582001286994)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(789494807066286996)
,p_internal_uid=>2882717733898101241
);
wwv_flow_imp.component_end;
end;
/
