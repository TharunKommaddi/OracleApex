prompt --application/pages/page_00553
begin
--   Manifest
--     PAGE: 00553
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>553
,p_name=>'Arbeitskreise'
,p_alias=>'ARBEITSKREISE'
,p_step_title=>'Arbeitskreise'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(638184509352952507)
,p_plug_name=>'Arbeitskreise'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_imp.id(3414127510682820548)
,p_plug_display_sequence=>10
,p_list_id=>wwv_flow_imp.id(638188819932952575)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(638184433650952507)
,p_plug_name=>'Arbeitskreise'
,p_parent_plug_id=>wwv_flow_imp.id(638184509352952507)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(638182660054952506)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(638184509352952507)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(638182348244952506)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(638184509352952507)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(638182508482952506)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(638184509352952507)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(638180941676952505)
,p_branch_action=>'f?p=&APP_ID.:556:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(638182348244952506)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(638181682146952506)
,p_branch_action=>'f?p=&APP_ID.:550:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(638182508482952506)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(638182972446952506)
,p_name=>'P553_SELECTED_AK'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(638184433650952507)
,p_prompt=>'Arbeitskreise'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_ARBEITSKREIS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' SELECT ',
'    ET_B_AKID, ',
'    kurz, ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN Bezeichnung',
'        ELSE name_eng',
'    END AS name',
'FROM T_ET_B_AK ',
'WHERE ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN Bezeichnung',
'        ELSE name_eng',
'    END NOT IN ',
'    (',
'        CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''Administratoren'' ELSE ''Administrators'' END,',
'        CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''Redaktionsteam'' ELSE ''Editorial Team'' END',
'    );',
''))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp.component_end;
end;
/
