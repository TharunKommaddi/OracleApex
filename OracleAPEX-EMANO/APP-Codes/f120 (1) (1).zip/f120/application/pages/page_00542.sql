prompt --application/pages/page_00542
begin
--   Manifest
--     PAGE: 00542
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>542
,p_name=>'MfVs'
,p_alias=>'MFVS'
,p_page_mode=>'MODAL'
,p_step_title=>'MfVs'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
''))
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_dialog_height=>'400'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(108955081702098742)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(712760182011977984)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(108955100581098742)
,p_plug_name=>'Vorschrift kopieren'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(628092455810742862)
,p_plug_name=>'MfVs'
,p_parent_plug_id=>wwv_flow_imp.id(108955100581098742)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(210197939741469053)
,p_plug_name=>'Data list from RegIndex'
,p_region_name=>'report-verknuepfungen'
,p_parent_plug_id=>wwv_flow_imp.id(628092455810742862)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3151662948216864704)
,p_name=>'REPORT_MFV'
,p_region_name=>'report-verknuepfungen'
,p_parent_plug_id=>wwv_flow_imp.id(210197939741469053)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select m.rowid,',
'       m.MFVID,',
'       APEX_ITEM.CHECKBOX(2, m.MFVID, null, :P542_SELECTED_MFVS, '':'') as checkbox,',
'       m.mfv_name,',
'       mt.TEIL || ''. '' || mt.BEZEICHNUNG AS "MFV_TEIL",',
'       m.mfv_thema,',
'       SCHLAGWORTE,',
'       VORSCHRIFTENVERANTWORTLICHER AS "VORSCHRIFTENVERANTWORTLICHER",',
'       BETEILIGTE_OES,',
'      PCK_RI.fCreateLinkIfUrl("LINK_MFV_DMS") AS "LINK_MFV_DMS",',
'       m.DMS_DOKUMENTENSTATUS as "DMS_DOKUMENTENSTATUS",',
'       m.LETZTE_AENDERUNG_DATUM,',
'       nvl2(m.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) AS "LETZTE_AENDERUNG_BENUTZER"',
'',
'from T_MFV m',
'join T_MFV_REF_VORSCHRIFT mrv on mrv.mfvid = m.mfvid',
'join T_MFV_TEIL mt on mt.MFV_TEILID = m.MFV_TEILID',
'left outer join T_BENUTZER b on b.BENUTZERID = m.LETZTE_AENDERUNG_BENUTZERID',
'where mrv.vorschriftid = :P540_SOURCE_VORSCHRIFTID and mt.TEIL=2 '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'Keine MfVs zugeordnet.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(610009131059473536)
,p_query_column_id=>1
,p_column_alias=>'ROWID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_report_column_required_role=>wwv_flow_imp.id(2645659840847340007)
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(591079509408850458)
,p_query_column_id=>2
,p_column_alias=>'MFVID'
,p_column_display_sequence=>13
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(591079648929850460)
,p_query_column_id=>3
,p_column_alias=>'CHECKBOX'
,p_column_display_sequence=>2
,p_column_heading=>'<input type="checkbox" onclick="$f_CheckFirstColumn(this)" />'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(610008326821473535)
,p_query_column_id=>4
,p_column_alias=>'MFV_NAME'
,p_column_display_sequence=>3
,p_column_heading=>'MfV ID'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(610007929187473535)
,p_query_column_id=>5
,p_column_alias=>'MFV_TEIL'
,p_column_display_sequence=>4
,p_column_heading=>'MfV Teil'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(610007485845473534)
,p_query_column_id=>6
,p_column_alias=>'MFV_THEMA'
,p_column_display_sequence=>5
,p_column_heading=>'Thema der MfV'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(610007070923473534)
,p_query_column_id=>7
,p_column_alias=>'SCHLAGWORTE'
,p_column_display_sequence=>6
,p_column_heading=>'Schlagworte'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(610006644167473534)
,p_query_column_id=>8
,p_column_alias=>'VORSCHRIFTENVERANTWORTLICHER'
,p_column_display_sequence=>7
,p_column_heading=>'ET Arbeitskreis'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(610006312793473534)
,p_query_column_id=>9
,p_column_alias=>'BETEILIGTE_OES'
,p_column_display_sequence=>8
,p_column_heading=>'Beteiligte OEs'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(610005909872473534)
,p_query_column_id=>10
,p_column_alias=>'LINK_MFV_DMS'
,p_column_display_sequence=>9
,p_column_heading=>'Link zur Ablage DMS'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(610009476655473536)
,p_query_column_id=>11
,p_column_alias=>'DMS_DOKUMENTENSTATUS'
,p_column_display_sequence=>10
,p_column_heading=>'DMS Dokumentenstatus'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(958148833580521269)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(610005458080473534)
,p_query_column_id=>12
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>11
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_column_format=>'DD.MM.YYYY HH24:Mi'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(610005053370473533)
,p_query_column_id=>13
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZER'
,p_column_display_sequence=>12
,p_column_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(108955207281098742)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(701814329039094231)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(108955207281098742)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(701814657195094232)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(108955207281098742)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('L\00E4nder und Themen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(700566222019495976)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(108955207281098742)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(701805969542094227)
,p_branch_name=>'Go To Page 545'
,p_branch_action=>'f?p=&APP_ID.:545:&SESSION.::&DEBUG.:25::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(701814657195094232)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(700566107356495975)
,p_branch_name=>'Go To Page 541'
,p_branch_action=>'f?p=&APP_ID.:541:&SESSION.::&DEBUG.:25::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(700566222019495976)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(697277049707037103)
,p_name=>'P542_SELECTED_MFVS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3151662948216864704)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(701813502864094230)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(701814329039094231)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(701812965202094230)
,p_event_id=>wwv_flow_imp.id(701813502864094230)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(701808975485094228)
,p_name=>'copy nachfolger changed'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P542_COPY_NACHFOLGER'
,p_condition_element=>'P542_COPY_NACHFOLGER'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Y'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(701808532332094228)
,p_event_id=>wwv_flow_imp.id(701808975485094228)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P542_COPY_ALL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(701808031720094227)
,p_event_id=>wwv_flow_imp.id(701808975485094228)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P542_COPY_ALL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(591079747289850461)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get Selected MfVs'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--debug(''Prozess get selected MfVS: '',APEX_APPLICATION.G_F02.COUNT);',
'',
':P542_SELECTED_MFVS := null;',
'',
'FOR i IN 1..APEX_APPLICATION.G_F02.COUNT LOOP ',
'    --debug(''element ''||I||'' has a value of ''||APEX_APPLICATION.G_F02(i)); ',
'    :P542_SELECTED_MFVS := :P542_SELECTED_MFVS || APEX_APPLICATION.G_F02(i) || '':'';',
'END LOOP;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3081132568609537774
);
wwv_flow_imp.component_end;
end;
/
