prompt --application/pages/page_00415
begin
--   Manifest
--     PAGE: 00415
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>415
,p_name=>'Regulierungsverantwortlichen bearbeiten'
,p_alias=>'REGULIERUNGSVERANTWORTLICHEN-BEARBEITEN'
,p_step_title=>'Regulierungsverantwortlichen bearbeiten'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'function delete_fun(){',
'    // alert(''TEST'');',
'    apex.submit(''DELETE'');',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(695691244064674588)
,p_plug_name=>'Regulierungsverantwortlichen bearbeiten'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_query_type=>'TABLE'
,p_query_table=>'T_VERANTWORTLICHER'
,p_include_rowid_column=>true
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(394300278485385583)
,p_name=>unistr('Vorschriften und Hauptumsetzende OE f\00FCr SW-Relevanz')
,p_parent_plug_id=>wwv_flow_imp.id(695691244064674588)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'vrv.VORSCHRIFT_REF_VERANTWORTLICHERID as VORSCHRIFT_REF_VERANTWORTLICHERID,',
'vrv.VORSCHRIFT_REF_VERANTWORTLICHERID as VOR_REF_VERANTWORTLICHERID,',
'1 as details,',
'vo.vorschriftid as Vorschriftid,',
'vo.vorschrift_nummer as Vorschrift, ',
'vo.swr_hauptumsetzende_oe as hauptumsetzende_oe, ',
'CASE vrv.ist_Hauptverantwortlicher',
'        WHEN 10 THEN ''Hauptverantwortlicher''',
'        WHEN 20 THEN ''Nebenverantwortlicher''',
'END AS Ist_Hauptverantwortlicher',
'from t_vorschrift vo ',
'join t_vorschrift_ref_verantwortlicher vrv on (vrv.vorschriftid = vo.vorschriftid)',
'where vrv.verantwortlicherID = :P415_VERANTWORTLICHERID',
'order by 1'))
,p_display_when_condition=>'P415_VERANTWORTLICHERID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P415_VERANTWORTLICHERID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(710660659293549863)
,p_query_column_id=>1
,p_column_alias=>'VORSCHRIFT_REF_VERANTWORTLICHERID'
,p_column_display_sequence=>10
,p_column_link=>'f?p=&APP_ID.:416:&SESSION.::&DEBUG.:416:P416_VORSCHRIFT_REF_VERANTWORTLICHERID,P416_VERANTWORTLICHERID:#VORSCHRIFT_REF_VERANTWORTLICHERID#,&P415_VERANTWORTLICHERID.'
,p_column_linktext=>'<span aria-label="Edit"><span class="fa fa-pencil" aria-hidden="true" title="Edit"></span></span>'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(708796177139754001)
,p_query_column_id=>2
,p_column_alias=>'VOR_REF_VERANTWORTLICHERID'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(708792883699753968)
,p_query_column_id=>3
,p_column_alias=>'DETAILS'
,p_column_display_sequence=>30
,p_column_heading=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_column_linktext=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_column_link_attr=>'target="_blank"'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(708792974900753969)
,p_query_column_id=>4
,p_column_alias=>'VORSCHRIFTID'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(394300191492385582)
,p_query_column_id=>5
,p_column_alias=>'VORSCHRIFT'
,p_column_display_sequence=>50
,p_column_heading=>'Vorschrift Nummer'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(394300086716385581)
,p_query_column_id=>6
,p_column_alias=>'HAUPTUMSETZENDE_OE'
,p_column_display_sequence=>60
,p_column_heading=>'Hauptumsetzende OE2'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(710663425996549890)
,p_query_column_id=>7
,p_column_alias=>'IST_HAUPTVERANTWORTLICHER'
,p_column_display_sequence=>70
,p_column_heading=>'Ist Hauptverantwortlicher'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(695676581873648401)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_imp.id(3414126953447820548)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(695686640861674532)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(695691244064674588)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:410:&SESSION.::&DEBUG.:::'
,p_button_condition_type=>'NEVER'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(710661687708549873)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(394300278485385583)
,p_button_name=>'Vorschrifthinzufuegen'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Vorschrift hinzuf\00FCgen')
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:416:&SESSION.::&DEBUG.:416:P416_VERANTWORTLICHERID:&P415_VERANTWORTLICHERID.'
,p_button_condition=>'P415_VERANTWORTLICHERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(708792399964753963)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(695691244064674588)
,p_button_name=>'Delete'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lAnzVorschriften number;',
'begin',
'    if (:P415_VERANTWORTLICHERID is null) then',
'        return false;',
'    end if;',
'',
'    select count(*) into lAnzVorschriften',
'    from t_vorschrift_ref_verantwortlicher',
'    where verantwortlicherid = :P415_VERANTWORTLICHERID;',
'',
'    if (lAnzVorschriften > 0) then',
'        return false;',
'    end if;',
'',
'    return true;',
'end;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(695674707650648382)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(695691244064674588)
,p_button_name=>'PREVIOUS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:410:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(695685549986674527)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(695691244064674588)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P415_VERANTWORTLICHERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
,p_button_comment=>'item is not null p415 riowid'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(695685209805674527)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(695691244064674588)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P415_VERANTWORTLICHERID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(695684843712674527)
,p_branch_name=>'Go To Page 410'
,p_branch_action=>'f?p=&APP_ID.:410:&SESSION.::&DEBUG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(695690476852674562)
,p_name=>'P415_VERANTWORTLICHERID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(695691244064674588)
,p_item_source_plug_id=>wwv_flow_imp.id(695691244064674588)
,p_source=>'VERANTWORTLICHERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(695690131107674551)
,p_name=>'P415_NACHNAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(695691244064674588)
,p_item_source_plug_id=>wwv_flow_imp.id(695691244064674588)
,p_prompt=>'Nachname'
,p_source=>'NACHNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>250
,p_read_only_when=>'P415_VERANTWORTLICHERID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(695689650301674547)
,p_name=>'P415_VORNAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(695691244064674588)
,p_item_source_plug_id=>wwv_flow_imp.id(695691244064674588)
,p_prompt=>'Vorname'
,p_source=>'VORNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>250
,p_read_only_when=>'P415_VERANTWORTLICHERID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(695689262269674542)
,p_name=>'P415_ABTEILUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(695691244064674588)
,p_item_source_plug_id=>wwv_flow_imp.id(695691244064674588)
,p_prompt=>'Abteilung'
,p_source=>'ABTEILUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>250
,p_read_only_when=>'P415_VERANTWORTLICHERID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(695688849493674537)
,p_name=>'P415_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(695691244064674588)
,p_item_source_plug_id=>wwv_flow_imp.id(695691244064674588)
,p_prompt=>'Email'
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>250
,p_read_only_when=>'P415_VERANTWORTLICHERID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(695676450284648400)
,p_name=>'P415_GID'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(695691244064674588)
,p_item_source_plug_id=>wwv_flow_imp.id(695691244064674588)
,p_prompt=>'GID'
,p_source=>'GID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(708795643366753996)
,p_name=>'Edit - P416 closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(394300278485385583)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(708795620950753995)
,p_event_id=>wwv_flow_imp.id(708795643366753996)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(394300278485385583)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(708791755843753957)
,p_event_id=>wwv_flow_imp.id(708795643366753996)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P415_DELETE_CONDITION'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(708795454751753994)
,p_name=>'Create - P416 closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(710661687708549873)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(708794887440753988)
,p_event_id=>wwv_flow_imp.id(708795454751753994)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P415_VERANTWORTLICHERID'
,p_attribute_03=>'P415_VERANTWORTLICHERID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(708795338226753993)
,p_event_id=>wwv_flow_imp.id(708795454751753994)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(394300278485385583)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(708791880727753958)
,p_event_id=>wwv_flow_imp.id(708795454751753994)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P415_DELETE_CONDITION'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(708792336904753962)
,p_name=>'Delete Process'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(708792399964753963)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(708791946354753959)
,p_event_id=>wwv_flow_imp.id(708792336904753962)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('M\00F6chten Sie diesen Regulierungsverantwortlichen l\00F6schen?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(739321679408286554)
,p_event_id=>wwv_flow_imp.id(708792336904753962)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'DELETE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(695683963078674525)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(695691244064674588)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Regulierungsverantwortlichen bearbeiten'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2976528352820713710
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(708792464043753964)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete Process'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from T_VERANTWORTLICHER',
'where verantwortlicherid = :P415_VERANTWORTLICHERID;',
'    '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DELETE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>2963419851855634271
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(695684391226674525)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(695691244064674588)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Regulierungsverantwortlichen bearbeiten'
,p_internal_uid=>2976527924672713710
);
wwv_flow_imp.component_end;
end;
/
