prompt --application/pages/page_00056
begin
--   Manifest
--     PAGE: 00056
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>56
,p_name=>'Landesansprechpartner'
,p_alias=>'LANDESANSPRECHPARTNER'
,p_page_mode=>'MODAL'
,p_step_title=>'Landesansprechpartner'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>unistr('var htmldb_delete_message=''"M\00F6chten Sie die L\00E4nderzuordnung l\00F6schen?"'';')
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4638888550771557060)
,p_plug_name=>'Landesansprechpartner'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_BENUTZER_REF_LAND'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4638889300952557060)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(442853701450961388)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4638889300952557060)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(442852838869961387)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4638889300952557060)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_confirm_message=>unistr('M\00F6chten Sie diese Landesansprechpartner-Zuordnung l\00F6schen?')
,p_confirm_style=>'warning'
,p_button_condition=>'P56_BENUTZER_REF_LANDID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(442853325060961387)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(4638889300952557060)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Speichern & Schlie\00DFen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(442913639498880891)
,p_name=>'P56_ROWID'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(4638888550771557060)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(442912934574880883)
,p_name=>'P56_BENUTZER_REF_LANDID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4638888550771557060)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(442857219046961397)
,p_name=>'P56_BENUTZER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(4638888550771557060)
,p_prompt=>'Benutzer'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct nachname || '', '' || vorname d, benutzerid r',
'from t_benutzer',
'where status = 10',
'order by 1;'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_read_only_when=>'P56_BENUTZER'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(442855636094961396)
,p_name=>'P56_KONTROLL_DATUM'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(4638888550771557060)
,p_prompt=>'Kontrolldatum'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(442854747621961395)
,p_name=>'P56_HAUPT_ANSPRECHPARTNER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4638888550771557060)
,p_prompt=>'Hauptansprechpartner'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_value', '20',
  'on_value', '10',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(442854420745961395)
,p_name=>'P56_LANDID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(4638888550771557060)
,p_prompt=>unistr('L\00E4nderauswahl')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'        ELSE land_eng',
'    END as d, ',
'    landid s',
'from t_land',
'order by d',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when=>'P56_LANDID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(429933443762891600)
,p_name=>'P56_CAME_FROM'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(4638888550771557060)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(429933174585891597)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(442853701450961388)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(429933067544891596)
,p_event_id=>wwv_flow_imp.id(429933174585891597)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(442850516693961360)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    debug(''benutzer_ref_landid: '' || :p56_benutzer_ref_landid || '', rowid: '' || :p56_rowid || '', benutzer: '' || :p56_benutzer || '', hauptansprechpartner: '' || :p56_haupt_ansprechpartner, ''landid: '' || :p56_landid);',
'if :p56_benutzer_ref_landid is null then',
'    insert into t_benutzer_ref_land (benutzerid, landid, haupt_ansprechpartner, kontroll_datum)',
'    values (:p56_benutzer, :p56_landid, :P56_haupt_ansprechpartner, :P56_kontroll_datum)',
'    returning benutzer_ref_landid into :p56_benutzer_ref_landid;',
'else',
'    update t_benutzer_ref_land',
'    set landid = :p56_landid,',
'    benutzerid = :p56_benutzer,',
'    haupt_ansprechpartner = :p56_haupt_ansprechpartner,',
'    kontroll_datum = :p56_kontroll_datum',
'    where benutzer_ref_landid = :p56_benutzer_ref_landid;',
'end if;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(442853325060961387)
,p_process_success_message=>'Die Daten wurden gespeichert.'
,p_internal_uid=>3229361799205426875
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(442851330708961361)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from t_benutzer_ref_land',
'where benutzerid = :P56_BENUTZER;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(442852838869961387)
,p_internal_uid=>3229360985190426874
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(442850127058961360)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3229362188840426875
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(442850900177961360)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Initialize form Landesansprechpartner'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    debug(''rowid: '' || :p56_rowid || '', benutzerid: '' || :p56_benutzerid, ''landid: '' || :p56_landid);',
'if :p56_benutzer_ref_landid is not null then',
'    select benutzerid, landid, haupt_ansprechpartner, kontroll_datum',
'    into :p56_benutzer, :p56_landid, :p56_haupt_ansprechpartner, :p56_kontroll_datum',
'    from t_benutzer_ref_land ref ',
'    where benutzer_ref_landid = :p56_benutzer_ref_landid;',
'elsif :p56_rowid is not null then',
'    select benutzerid',
'    into :p56_benutzer',
'    from t_benutzer',
'    where rowid = :p56_rowid;',
'end if;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3229361415721426875
);
wwv_flow_imp.component_end;
end;
/
