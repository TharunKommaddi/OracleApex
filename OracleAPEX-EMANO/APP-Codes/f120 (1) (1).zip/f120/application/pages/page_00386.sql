prompt --application/pages/page_00386
begin
--   Manifest
--     PAGE: 00386
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>386
,p_name=>'VKO zuordnen'
,p_alias=>'VKO-ZUORDNEN'
,p_page_mode=>'MODAL'
,p_step_title=>'VKO zuordnen'
,p_error_handling_function=>'(  ( --pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and     pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0 -- Rolle VKO, Fachadmin  ) ) = false    or (:P25_EDIT_MODE is null or :P25_EDIT_MODE <> 1)'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'// Laender',
'function loadLaenderShuttle() {',
'    var shuttleName = ''P386_FILTER_BLAND'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadLaenderShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P386_FILTER_LAENDERGRUPPE''),',
'          x03: $v(''P386_FILTER_BLAND_PRE'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                console.log(pData);',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'// Themen',
'function loadThemenShuttle() {',
'    var shuttleName = ''P386_FILTER_THEMEN'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    //var lAK_ID = $v(''P386_ET_B_AKID'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadThemenShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P386_FILTER_THEMEN_PRE''),',
'          x03: $v(''P386_ET_B_AK_REF_BENUTZERID''),',
'          //x04: $v(''P386_FILTER_THEMEN_PRE_CLUSTER'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'function addItemToShuttle(aShuttle, aID, aDisplay) {',
'    var lLeft = $(''#'' + aShuttle + ''_LEFT'');',
'    var lRight = $(''#'' + aShuttle + ''_RIGHT'');',
'    lLeft.find(''option[value='' + aID + '']'').remove();',
'    lRight.append(''<option value="'' + aID + ''">'' + aDisplay + ''</option>'');',
'}',
'',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'parent.$(''.ui-dialog-title:contains("VKO zuordnen")'').text($v(''P386_TITEL''));',
'',
'document.getElementById("P386_VKO_NACHNAME").readOnly = true;',
'document.getElementById("P386_VKO_VORNAME").readOnly = true;',
'document.getElementById("P386_VKO_ABTEILUNG").readOnly = true;'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'950'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(859702513587799700)
,p_plug_name=>'VKO zuordnen'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_ET_B_AK_REF_BENUTZER'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(978723790101585554)
,p_name=>'Vorschriften, in denen der Anwender als Lead-VKO zugeordnet ist'
,p_parent_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    select vorschriftid',
'    from t_vorschrift_ref_et_b_ak',
'    where et_b_akid = :P386_ET_B_AKID',
')',
' select ',
' ''<a href="f?p='' || :APP_ID || '':25:'' || v(''APP_SESSION'') || '':::25:P25_VORSCHRIFTID:'' || vorschriftid || ''" target="_blank"><span class="fa fa-search"></span></a>'' as link,',
' vorschriftid, vorschrift_nummer, ak.liste',
' from t_vorschrift v',
' outer apply (',
'',
'    select listagg(distinct ak.kurz, '', '') within group (order by ak.kurz) liste',
'    from t_vorschrift_ref_et_b_ak vr',
'    join t_et_b_ak ak on (vr.et_b_akid = ak.et_b_akid)',
'    where vr.vorschriftid = v.vorschriftid and vr.geloescht = 0',
' ) ak',
' where lead_vko_benutzerid = :P386_VKO_BENUTZERID',
' and vorschriftid in (select vorschriftid from cte1)',
' order by vorschrift_nummer'))
,p_display_when_condition=>'P386_ET_B_AK_REF_BENUTZERID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Keiner Vorschrift als Lead-VKO zugeordnet, die auch diesem Arbeitskreis zugeordnet ist.'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(781401890787132196)
,p_query_column_id=>1
,p_column_alias=>'LINK'
,p_column_display_sequence=>10
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(781402188507132199)
,p_query_column_id=>2
,p_column_alias=>'VORSCHRIFTID'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(781402108100132198)
,p_query_column_id=>3
,p_column_alias=>'VORSCHRIFT_NUMMER'
,p_column_display_sequence=>30
,p_column_heading=>'Vorschriftennummer'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(185709016098679363)
,p_query_column_id=>4
,p_column_alias=>'LISTE'
,p_column_display_sequence=>40
,p_column_heading=>'Arbeitskreise'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(859699378434799634)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(155429596288345109)
,p_plug_name=>'BOX Vorfilter Themen'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>5
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(155250438917796026)
,p_plug_name=>'BOX Filter Themen'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(89526218021972589)
,p_plug_name=>unistr('Trennlinie_L\00E4nder')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<hr>',
unistr('L\00E4ndereinschr\00E4nkungen f\00FCr VKO des Arbeitskreises:')))
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P386_ET_B_AK_REF_BENUTZERID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(562435517307966721)
,p_plug_name=>'Trennlinie_Themen'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>50
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<hr>',
unistr('Themengebietseinschr\00E4nkungen f\00FCr VKO des Arbeitskreises:')))
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P386_ET_B_AK_REF_BENUTZERID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1545674017609261622)
,p_plug_name=>unistr('Box Vorfilter L\00E4nder')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>4
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P386_ET_B_AK_REF_BENUTZERID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1545676042536278814)
,p_plug_name=>unistr('Box Filter L\00E4nder')
,p_region_template_options=>'#DEFAULT#:margin-left-md'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P386_ET_B_AK_REF_BENUTZERID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(628163762423863913)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1545676042536278814)
,p_button_name=>'B_KOMMENTARE_PRUEFEN'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('Kommentar bez. ausgew\00E4lten L\00E4ndern pr\00FCfen')
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-info-square-o'
,p_button_cattributes=>'style="margin: 0px; padding: 0px; "'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(346702156739268703)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_button_name=>'SEARCH_LDAP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'In LDAP suchen'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:65:&SESSION.::&DEBUG.:65:P65_CAMEFROM:386'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(userId => PCK_RI.fGetUserId, ',
'                      pageId => :APP_PAGE_ID,',
'                      accessMode => 200))'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(859699031674799633)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(859699378434799634)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(859697472288799623)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(859699378434799634)
,p_button_name=>'DELETE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Entfernen'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P386_ET_B_AK_REF_BENUTZERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(859697052210799623)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(859699378434799634)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P386_ET_B_AK_REF_BENUTZERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(859696699636799623)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(859699378434799634)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P386_ET_B_AK_REF_BENUTZERID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1005256937041844700)
,p_name=>'P386_VORSCHRIFTEN_WITH_LEAD'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  --''<html><a href="javascript:window.open(''''f?p='' || ''118''||'':25:&'' || ''SESSION.''||''::NO:25:P25_VORSCHRIFTID:''|| vorschriftid || '''''',''''_blank'''');">'' ',
'--|| vorschrift_nummer||'' </a></html>''',
'vorschrift_nummer',
'from t_vorschrift',
' where lead_vko_benutzerid = :P386_VKO_BENUTZERID and rownum=1;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(978724069560585557)
,p_name=>'P386_VORSCHRIFTEN_ID_WITH_LEAD'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  listagg(vorschriftid, '' :'') within group (order by vorschriftid)',
'from t_vorschrift',
' where lead_vko_benutzerid = :P386_VKO_BENUTZERID and rownum=1;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(859702233424799693)
,p_name=>'P386_ET_B_AK_REF_BENUTZERID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_item_source_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_source=>'ET_B_AK_REF_BENUTZERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(859701802928799658)
,p_name=>'P386_ET_B_AKID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_item_source_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_source=>'ET_B_AKID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(859700997863799637)
,p_name=>'P386_BEMERKUNG'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Bemerkung'
,p_source=>'select bemerkung from t_et_b_ak_ref_benutzer where et_b_ak_ref_benutzerid = :P386_ET_B_AK_REF_BENUTZERID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>200
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628165819472881093)
,p_name=>'P386_FILTER_LAENDERGRUPPE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1545674017609261622)
,p_prompt=>unistr('Vorfilter L\00E4ndergruppe')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select laendergruppe, laendergruppeid',
'from t_laendergruppe where laendergruppeid!=1220',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- alle -'
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628165413781881087)
,p_name=>'P386_FILTER_BLAND_PRE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1545674017609261622)
,p_prompt=>unistr('Vorfilter L\00E4nder')
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" onclick="loadLaenderShuttle()"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628163434559863909)
,p_name=>'P386_FILTER_BLAND'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1545676042536278814)
,p_prompt=>unistr('L\00E4nder')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b_nummer || '' - '' || CASE ',
'    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'    ELSE land_eng',
'END as d, landid',
'from t_land l',
'where (:P386_FILTER_LAENDERGRUPPE is null or landid in (select landid from t_land_ref_laendergruppe where laendergruppeid = :P386_FILTER_LAENDERGRUPPE))',
'    and status_datenstand <> 0',
'order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'')'))
,p_cHeight=>5
,p_tag_css_classes=>'margin-bottom-none padding-bottom-none'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_css_classes=>'margin-bottom-none padding-bottom-none'
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'U'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628163025191863908)
,p_name=>'P386_BESONDERHEITEN_MAERKTE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1545676042536278814)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628162591556863907)
,p_name=>'P386_URL_KOMMENTARE_PRUEFEN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1545676042536278814)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628100614865863872)
,p_name=>'P386_FILTER_THEMEN_PRE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(155429596288345109)
,p_prompt=>'Vorfilter Themengebiete'
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" onclick="loadThemenShuttle()"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628099810846863858)
,p_name=>'P386_FILTER_THEMEN_PRE_CLUSTER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(155429596288345109)
,p_prompt=>'Cluster Vorfilter'
,p_source=>'-1'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  c.BEZEICHNUNG, c.konzern_clusterid from T_Konzern_cluster c ',
'order by  c.BEZEICHNUNG;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-alle-'
,p_lov_null_value=>'-1'
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628099040112861024)
,p_name=>'P386_FILTER_THEMEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(155250438917796026)
,p_prompt=>'Filter Themen'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN v.bezeichnung',
'        ELSE v.name_eng',
'    END as d, v.themaid as r ',
'from T_THEMA_REF_ET_B_AK tra',
'join v_thema_baum v on (v.themaid = tra.themaid and v.gueltig=1) ',
'where tra.et_b_akid = (select ET_B_AKID from T_ET_B_AK_REF_BENUTZER',
'                        where ET_B_AK_REF_BENUTZERID = :P386_ET_B_AK_REF_BENUTZERID)',
'  OR v.themaid in ( select distinct vrt.themaid from T_ET_B_AK_vko_REF_THEMA vrt ',
'                  join T_ET_B_AK_REF_BENUTZER art on (art.ET_B_AK_REF_BENUTZERid = vrt.ET_B_AK_VKOID)',
'                   where ET_B_AK_vkoid = :P386_ET_B_AK_REF_BENUTZERID )',
'',
''))
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628095941503742897)
,p_name=>'P386_LEAD_VKO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_item_source_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_prompt=>'Ist AK-Leiter'
,p_source=>'LEAD_VKO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Nein',
  'off_value', '0',
  'on_label', 'Ja',
  'on_value', '1',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628095111466742888)
,p_name=>'P386_LAND_INDEPENDENT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_item_source_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_prompt=>unistr('Ist Land unabh\00E4ngig')
,p_source=>'LAND_INDEPENDENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Nein',
  'off_value', '0',
  'on_label', 'Ja',
  'on_value', '1',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(628068159637277909)
,p_name=>'P386_THEMEN_CHILDREN_TO_ADD'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(155250438917796026)
,p_display_as=>'NATIVE_HIDDEN'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(357618623346193559)
,p_name=>'P386_VKO_BENUTZERID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_item_source_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_source=>'BENUTZERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(357618445734193558)
,p_name=>'P386_BENUTZER_GID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(357618423749193557)
,p_name=>'P386_VKO_NACHNAME'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_prompt=>'VKO Nachname'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(346702058430268702)
,p_name=>'P386_VKO_VORNAME'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_prompt=>'VKO Vorname'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(346701732625268698)
,p_name=>'P386_VKO_EMAIL'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(346700829863268689)
,p_name=>'P386_VKO_ABTEILUNG'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_prompt=>'Abteilung'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(346700651738268688)
,p_name=>'P386_NEW_USER'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(185708851934679362)
,p_name=>'P386_VALIDATE_DELETE'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_use_cache_before_default=>'NO'
,p_source=>'pck_ak.fValidateDeleteVKO(:P386_ET_B_AK_REF_BENUTZERID)'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P386_ET_B_AK_REF_BENUTZERID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(185708200848679355)
,p_name=>'P386_TITEL'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(859702513587799700)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''VKO-Zuordnung in '' || kurz || '' - '' || bezeichnung',
'from t_et_b_ak',
'where et_b_akid = :P386_ET_B_AKID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(346697662011268658)
,p_validation_name=>'Is Lead VKO'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_co number :=0; ',
'    l_lead_v_num number :=0;',
'BEGIN ',
'-- wenn   vko zu loeschen (P386_VKO_BENUTZERID) ein Lead VKO in einem Vorschrift P386_LEAD_VKO ',
unistr('-- und keinem AK mehr zugeordnet ist, dann darf er aus register nicht gel\00F6scht werden'),
'',
'-- ist  er ein Lead VKO',
'    select count(*) into l_co from t_vorschrift',
'    where lead_vko_benutzerid = :P386_VKO_BENUTZERID;',
'    if (l_co = 0 ) then',
'       return true;  -- ist kein lead ',
'    end if;',
unistr('   -- es soll  noch mindestens AK f\00FCr diesen VKO geben'),
'',
'    select  count(*) into l_co from T_et_b_AK_ref_benutzer ',
'    where -- et_b_AK_ref_benutzerid != P386_ET_B_AK_REF_BENUTZERID and',
'     et_b_AKid  != :P386_ET_B_AKID',
'    and benutzerid = :P386_VKO_BENUTZERID;',
'   -- ist lead in vorschriften mit aktuellem AK ?',
'    select  count(v.vorschrift_nummer) into l_lead_v_num',
'      from t_vorschrift v',
'     join t_et_b_ak_ref_benutzer arb on (arb.benutzerid = v.lead_VKO_benutzerid)',
'    where v.lead_VKO_benutzerid is not null',
'      and  arb.et_b_ak_ref_benutzerid = :P386_ET_B_AK_REF_BENUTZERID;',
'',
'    if (l_co > 0 and l_lead_v_num = 0) then',
'       return true;',
'    end if;',
'   return false;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'VKO ist VKO-Lead in einigen Vorschriften',
'und darf nicht entfernt werden!'))
,p_always_execute=>'Y'
,p_validation_condition_type=>'NEVER'
,p_when_button_pressed=>wwv_flow_imp.id(859697472288799623)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(859698886151799633)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(859699031674799633)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(859698102501799627)
,p_event_id=>wwv_flow_imp.id(859698886151799633)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(632207192224546158)
,p_name=>'Enter im Laendersuchfeld '
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P386_FILTER_BLAND_PRE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(632207080134546157)
,p_event_id=>wwv_flow_imp.id(632207192224546158)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(632206912532546155)
,p_name=>'Change Laendergruppe'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P386_FILTER_LAENDERGRUPPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(632206782146546154)
,p_event_id=>wwv_flow_imp.id(632206912532546155)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(628096610291742903)
,p_name=>'Enter im Themensuchfeld'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P386_FILTER_THEMEN_PRE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(628096501604742902)
,p_event_id=>wwv_flow_imp.id(628096610291742903)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadThemenShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(628069820466302555)
,p_name=>'Add childThemen'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P386_FILTER_THEMEN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(628068849804302529)
,p_event_id=>wwv_flow_imp.id(628069820466302555)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lThemenliste apex_t_number := apex_string.split_numbers(:P386_FILTER_THEMEN,'':'');',
'begin    ',
'',
'    apex_json.initialize_clob_output;',
'    apex_json.open_array;    ',
'',
unistr('    -- Jedes bereits ausgew\00E4hlte Thema durchgehen und dessen Kinder selektieren'),
'    for i in 1 .. lThemenliste.count loop',
'        for childthemen in (',
'            select themaid, nummer || '' - '' || bezeichnung as d',
'            from t_thema',
'             where gueltig =1',
'            connect by parentid = prior themaid',
'            start with parentid = lThemenliste(i)',
'        ) loop',
'            -- Wenn das entsprechende Kind noch nicht im Shuttle ist, dann ',
unistr('            -- zu einer Hinzuf\00FCgungs-Liste addieren'),
'            if (childthemen.themaid not member of lThemenliste) then',
'                apex_json.open_object;',
'                apex_json.write(''id'',childthemen.themaid);',
'                apex_json.write(''display'',childthemen.d);',
'                apex_json.close_object;',
'            end if;',
'        end loop;',
'    ',
'    end loop;',
unistr('    -- Hinzuf\00FCgungs-Liste ist hidden item'),
unistr('    -- Direktes Hinzuf\00FCgen w\00FCrde zu einem Refresh der Scrollbalken des Items f\00FChren'),
'    apex_json.close_array;',
'    :P386_THEMEN_CHILDREN_TO_ADD := apex_json.get_clob_output;',
'    apex_json.free_output;',
'end;    '))
,p_attribute_02=>'P386_FILTER_THEMEN'
,p_attribute_03=>'P386_THEMEN_CHILDREN_TO_ADD'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(628069364813302530)
,p_event_id=>wwv_flow_imp.id(628069820466302555)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var items = JSON.parse($v(''P386_THEMEN_CHILDREN_TO_ADD''));',
'',
unistr('// alle Items im Shuttle hinzuf\00FCgen'),
'for (item of items) {',
'    if (item) addItemToShuttle(''P386_FILTER_THEMEN'',item.id,item.display);',
'} '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(628096329824742900)
,p_name=>'Change Cluster Filter'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P386_FILTER_THEMEN_PRE_CLUSTER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(628096181335742899)
,p_event_id=>wwv_flow_imp.id(628096329824742900)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadThemenShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(628094942601742887)
,p_name=>'Switch Land-independent'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P386_LAND_INDEPENDENT'
,p_condition_element=>'P386_LAND_INDEPENDENT'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(628094886203742886)
,p_event_id=>wwv_flow_imp.id(628094942601742887)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1545674017609261622)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(132811043629615794)
,p_event_id=>wwv_flow_imp.id(628094942601742887)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(89526218021972589)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(132811500876615798)
,p_event_id=>wwv_flow_imp.id(628094942601742887)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1545676042536278814)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(132811228581615795)
,p_event_id=>wwv_flow_imp.id(628094942601742887)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1545676042536278814)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(132811405129615797)
,p_event_id=>wwv_flow_imp.id(628094942601742887)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(89526218021972589)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(132811293230615796)
,p_event_id=>wwv_flow_imp.id(628094942601742887)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1545674017609261622)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(628094206652742879)
,p_name=>'Anpassen'
,p_event_sequence=>90
,p_condition_element=>'P386_ET_B_AK_REF_BENUTZERID'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(628094121203742878)
,p_event_id=>wwv_flow_imp.id(628094206652742879)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P386_FILTER_LAENDERGRUPPE,P386_FILTER_BLAND,P386_FILTER_THEMEN_PRE,P386_FILTER_THEMEN,P386_FILTER_BLAND_PRE,P386_FILTER_THEMEN_PRE_CLUSTER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(346701501817268696)
,p_name=>unistr('Dialog Cl\00F6sed')
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(346702156739268703)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(346701429840268695)
,p_event_id=>wwv_flow_imp.id(346701501817268696)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' l_co number :=0;',
'begin',
'select :P65_NACHNAME_AUSGEWAEHLT, :P65_VORNAME_AUSGEWAEHLT, :P65_EMAIL_AUSGEWAEHLT, :P65_ABTEILUNG_AUSGEWAEHLT, :P65_GID_CHOSEN',
'  into :P386_VKO_NACHNAME,      :P386_VKO_VORNAME,        :P386_VKO_EMAIL,         :P386_VKO_ABTEILUNG,    :P386_BENUTZER_GID',
'  from dual;',
'',
'  :P386_VKO_BENUTZERID := PCK_RI.fCreatePlaceHolderUser(:P65_GID_CHOSEN);',
'  ',
'/* -- Alternative',
' select count(*) into l_co   from t_benutzer where GID = :P65_GID_CHOSEN;',
' if(l_co >0) then',
'     --select benutzerid into :P386_VKO_BENUTZERID',
'     --  from t_benutzer where GID = :P65_GID_CHOSEN;',
'     select  b.Benutzerid into  :P386_VKO_BENUTZERID from t_benutzer b',
'     where b.GID = nvl(:P386_BENUTZER_GID, -1);',
' else',
'   insert into t_benutzer (gid, nachname, vorname, email, abteilung)',
'   values ( :P65_GID_CHOSEN, :P65_NACHNAME_AUSGEWAEHLT, :P65_VORNAME_AUSGEWAEHLT, :P65_EMAIL_AUSGEWAEHLT, :P65_ABTEILUNG_AUSGEWAEHLT )',
'   returning benutzerid into :P386_VKO_BENUTZERID;',
' end if;',
' */',
' end;',
'',
'',
''))
,p_attribute_03=>'P65_NACHNAME_AUSGEWAEHLT,P65_VORNAME_AUSGEWAEHLT,P65_EMAIL_AUSGEWAEHLT,P65_GID_CHOSEN,P386_VKO_NACHNAME,P386_VKO_VORNAME,P386_VKO_EMAIL,P386_BENUTZER_GID,P386_VKO_BENUTZERID,P65_ABTEILUNG_AUSGEWAEHLT,P386_VKO_ABTEILUNG,P65_NEW_USER,P386_NEW_USER'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1005256535403844696)
,p_name=>'Try delete'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(859697472288799623)
,p_condition_element=>'P386_VALIDATE_DELETE'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(185708398444679357)
,p_event_id=>wwv_flow_imp.id(1005256535403844696)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Soll die Zuordnung dieses VKOs zu diesem Arbeitskreis gel\00F6scht werden?')
,p_attribute_06=>unistr('L\00F6schen')
,p_attribute_07=>'Abbrechen'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(185708274089679356)
,p_event_id=>wwv_flow_imp.id(1005256535403844696)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'&P386_VALIDATE_DELETE.'
,p_attribute_03=>'danger'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1005256302696844694)
,p_event_id=>wwv_flow_imp.id(1005256535403844696)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'DELETE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(185708556556679359)
,p_name=>unistr('L\00F6schvorgang erlaubt?')
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P386_VALIDATE_DELETE'
,p_condition_element=>'P386_VALIDATE_DELETE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(346701235693268693)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'erstelle Benutzer'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--debug(''P386_ET_B_AK_REF_BENUTZERID=''|| :P386_ET_B_AK_REF_BENUTZERID);',
'if (:P386_VKO_BENUTZERID is null) then',
'  insert into t_benutzer (gid,   nachname,        vorname,              email,   abteilung)',
'   values (  :P386_BENUTZER_GID, :P386_VKO_NACHNAME, :P386_VKO_VORNAME, :P386_VKO_EMAIL, :P386_VKO_ABTEILUNG )',
'   returning benutzerid into :P386_VKO_BENUTZERID;',
'  -- debug('':P386_VKO_BENUTZERID=''|| :P386_VKO_BENUTZERID);',
'   commit;',
' end if;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Fehler im Prozess "erstelle Benutzer"'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3325511080206119542
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(929251020749458755)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'BASIS_Rolle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (:P386_VKO_BENUTZERID is not null) then',
unistr('    -- recht f\00FCr Suche'),
'    insert into t_benutzer_ref_rolle (benutzerid, rolleid)',
'        select :P386_VKO_BENUTZERID, 1004 from dual',
'        where not exists (',
'            select 1 from t_benutzer_ref_rolle',
'            where benutzerid = :P386_VKO_BENUTZERID',
'        );',
'    -- Basisrecht',
'    insert into t_benutzer_ref_rolle (benutzerid, rolleid)',
'        select :P386_VKO_BENUTZERID, 1010 from dual',
'        where not exists (',
'            select 1 from t_benutzer_ref_rolle',
'            where benutzerid = :P386_VKO_BENUTZERID and rolleid = 1010',
'        );',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(859696699636799623)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2742961295149929480
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(628095601109742893)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'delete from T_ET_B_AK_VKO_REF_THEMA   ',
' where ET_B_AK_VKOID = :P386_ET_B_AK_REF_BENUTZERID;   ',
'',
'delete from T_ET_B_AK_VKO_REF_LAND   ',
' where ET_B_AK_VKOID = :P386_ET_B_AK_REF_BENUTZERID;   '))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Einige Vorschriften haben diesen VKO als Lead.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(859697472288799623)
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_co number :=0; ',
'    l_lead_v_num number :=0;',
'BEGIN ',
'-- wenn   vko zu loeschen (P386_VKO_BENUTZERID) ein Lead VKO in einem Vorschrift P386_LEAD_VKO ',
unistr('-- und keinem AK mehr zugeordnet ist, dann darf er aus register nicht gel\00F6scht werden'),
' if(:P386_VORSCHRRIFTEN_WITH_LEAD is not null) then ',
'   return false;',
' else',
'    return  true;',
' end if;',
'-- ist  er ein Lead VKO',
' /*   select count(*) into l_co from t_vorschrift',
'    where lead_vko_benutzerid = :P386_VKO_BENUTZERID;',
'    if (l_co = 0 ) then',
'       return true;  -- ist kein lead ',
'    end if;',
unistr('   -- es soll  noch mindestens AK f\00FCr diesen VKO geben'),
'',
'    select  count(*) into l_co from T_et_b_AK_ref_benutzer ',
'    where -- et_b_AK_ref_benutzerid != P386_ET_B_AK_REF_BENUTZERID and',
'     et_b_AKid  != :P386_ET_B_AKID',
'    and benutzerid = :P386_VKO_BENUTZERID;',
'   -- ist lead in vorschriften mit aktuellem AK ?',
'    select  count(v.vorschrift_nummer) into l_lead_v_num',
'      from t_vorschrift v',
'     join t_et_b_ak_ref_benutzer arb on (arb.benutzerid = v.lead_VKO_benutzerid)',
'    where v.lead_VKO_benutzerid is not null',
'      and  arb.et_b_ak_ref_benutzerid = :P386_ET_B_AK_REF_BENUTZERID;',
'',
'    if (l_co > 0 and l_lead_v_num = 0) then',
'       return true;',
'    end if;',
'   return false;',
'   */',
'END;'))
,p_process_when_type=>'FUNCTION_BODY'
,p_process_when2=>'PLSQL'
,p_internal_uid=>3044116714789645342
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(346700288133268684)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process form_Delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- delete nur aus diesem Arbeitskreis',
'delete from t_et_b_ak_ref_benutzer where et_b_ak_ref_benutzerid= :P386_ET_B_AK_REF_BENUTZERID;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Fehler aufgetreten in Process form_Delete.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(859697472288799623)
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
' DECLARE',
'    l_co number :=0; ',
'BEGIN ',
'-- wenn   vko zu loeschen (P386_VKO_BENUTZERID) ein Lead VKO in einem Vorschrift P386_LEAD_VKO ',
unistr('-- und keinem AK mehr zugeordnet ist, dann darf er aus register nicht gel\00F6scht werden'),
'',
' if(:P386_VORSCHRRIFTEN_WITH_LEAD is not null) then ',
unistr('    return false;  -- nicht l\00F6schen'),
' else',
'    return  true;',
' end if;',
'',
'END;'))
,p_process_when_type=>'FUNCTION_BODY'
,p_process_when2=>'PLSQL'
,p_internal_uid=>3325512027766119551
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(859695860273799620)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process form VKO zuordnen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_et_b_ak_ref_benutzer set benutzerid = :P386_VKO_BENUTZERID, ',
'lead_vko =:P386_LEAD_VKO, LAND_INDEPENDENT =:P386_LAND_INDEPENDENT , bemerkung = :P386_BEMERKUNG',
'where et_b_ak_ref_benutzerid = :P386_ET_B_AK_REF_BENUTZERID;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Fehler aufgetretten in Process form VKO zuordn.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(859697052210799623)
,p_internal_uid=>2812516455625588615
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(346700433743268685)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process form_Insert'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into t_et_b_ak_ref_benutzer (benutzerid, ET_B_AKID, lead_vko, land_independent, bemerkung )',
'values(:P386_VKO_BENUTZERID, :P386_ET_B_AKID, :P386_LEAD_VKO , :P386_LAND_INDEPENDENT, :P386_BEMERKUNG)',
'returning et_b_ak_ref_benutzerid into :P386_ET_B_AK_REF_BENUTZERID;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Fehler aufgetretten in Process form Insert.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(859696699636799623)
,p_internal_uid=>3325511882156119550
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(628096120376742898)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' ',
' ',
' -- insert into table  T_ET_B_AK_VKO_REF_THEMA ',
' --insert into table  T_ET_B_AK_VKO_REF_THEMA ()',
'--     values();',
' -- insert into table  T_ET_B_AK_VKO_REF_LAND ',
'begin',
'',
'  if (:P386_LAND_INDEPENDENT = 1) then',
'     delete from T_ET_B_AK_VKO_REF_LAND   ',
'       where ET_B_AK_VKOID = :P386_ET_B_AK_REF_BENUTZERID;   ',
'  else',
'      --debug(''P386_FILTER_BLAND: '', :P386_FILTER_BLAND);',
'     DELETE from T_ET_B_AK_VKO_REF_LAND ',
'     where ET_B_AK_VKOID = :P386_ET_B_AK_REF_BENUTZERID',
'       AND LANDID not in ( select column_value from table (apex_string.split_numbers(:P386_FILTER_BLAND, '':'')));',
'',
'     merge into T_ET_B_AK_VKO_REF_LAND dest ',
'       using (select :P386_ET_B_AK_REF_BENUTZERID vkoid, column_value landid ',
'         from table (apex_string.split_numbers(:P386_FILTER_BLAND, '':'') )',
'         ) src',
'         on (src.vkoid = dest.ET_B_AK_VKOID and src.landid = dest.landid)',
'         when not matched then',
'         insert ( dest.ET_B_AK_VKOID, dest.landid)',
'         values( src.vkoid, src.landid);',
'',
'  end if;',
'   -- themes always assignable -----',
'      DELETE from T_ET_B_AK_VKO_REF_THEMA ',
'     where ET_B_AK_VKOID = :P386_ET_B_AK_REF_BENUTZERID',
'       AND THEMAID not in ( select column_value from table (apex_string.split_numbers(:P386_FILTER_THEMEN, '':'')));',
'      --debug(''P386_FILTER_THEMEN: '', :P386_FILTER_THEMEN);',
'      ',
'    merge into T_ET_B_AK_VKO_REF_THEMA dest ',
'      using (select :P386_ET_B_AK_REF_BENUTZERID vkoid, column_value themaid ',
'         from table (apex_string.split_numbers(:P386_FILTER_THEMEN, '':'') )',
'         ) src',
'         on (src.vkoid = dest.ET_B_AK_VKOID and src.themaid = dest.themaid)',
'         when not matched then',
'         insert ( dest.ET_B_AK_VKOID, dest.themaid)',
'         values( src.vkoid, src.themaid);',
'',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3044116195522645337
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(859695494949799620)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2812516820949588615
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(346701602704268697)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Benutzerdaten'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_co number :=0;',
'begin',
'',
'  if(:P386_VKO_BENUTZERID is null and :P386_ET_B_AK_REF_BENUTZERID is not null) then',
'     select benutzerid,lead_vko,LAND_INDEPENDENT, et_b_akid',
'     into  :P386_VKO_BENUTZERID,:P386_LEAD_VKO,:P386_LAND_INDEPENDENT,:P386_ET_B_AKID',
'     from  T_ET_B_AK_REF_BENUTZER  ',
'     where  ET_B_AK_REF_BENUTZERID =:P386_ET_B_AK_REF_BENUTZERID fetch first 1 rows only ;',
'  end if;',
'',
'  if(:P386_VKO_BENUTZERID is not null ) then',
'      select b.gid,            b.nachname,           b.vorname,      b.email, b.Abteilung',
'      into :P386_BENUTZER_GID,  :P386_VKO_NACHNAME, :P386_VKO_VORNAME, :P386_VKO_EMAIL, :P386_VKO_ABTEILUNG',
'      from t_benutzer b',
'      where b.benutzerid =  nvl(:P386_VKO_BENUTZERID, -1);',
'',
'   end if;',
'end;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>3325510713195119538
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(628095893314742896)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Laender'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  land_ind number :=0;',
'begin',
'    if (:P386_ET_B_AK_REF_BENUTZERID is null) then',
'      null;',
'    else  ',
'       select LAND_INDEPENDENT into land_ind FROM T_ET_B_AK_REF_BENUTZER where ET_B_AK_REF_BENUTZERID = :P386_ET_B_AK_REF_BENUTZERID;',
'        if (land_ind =1) then',
'          null;',
'',
'        else',
'            select listagg(Landid, '':'') within group (order by Landid)',
'                 into :P386_FILTER_BLAND',
'                FROM T_ET_B_AK_VKO_REF_LAND',
'               where ET_B_AK_VKOID = :P386_ET_B_AK_REF_BENUTZERID;',
'        end if; ',
'     end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3044116422584645339
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(628095783224742895)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Themen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--begin',
'    if (:P386_ET_B_AK_REF_BENUTZERID is null) then',
'      null;',
'    else  ',
'      select listagg(Themaid, '':'') within group (order by Themaid)',
'       into :P386_FILTER_THEMEN',
'      FROM T_ET_B_AK_VKO_REF_THEMA',
'      where ET_B_AK_VKOID = :P386_ET_B_AK_REF_BENUTZERID;',
'    end if;',
'--end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3044116532674645340
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(632206971701546156)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLaenderShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lLaendergruppe varchar2(2000) := apex_application.g_x02;',
'    lTextfilter varchar2(2000) := apex_application.g_x03;',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    for l in (',
'        select b_nummer || '' - '' || CASE ',
'    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'    ELSE land_eng',
'END as d, landid',
'        from t_land',
'        where landid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))        ',
'        and (',
'            lLaendergruppe is null',
'            or landid in (',
'                select landid from t_land_ref_laendergruppe where laendergruppeid in (',
'                    select column_value from table(apex_string.split_numbers(lLaendergruppe,'':''))',
'                )',
'            )',
'        )',
'        and (',
'            lTextfilter is null',
'            or instr(upper(b_nummer),upper(lTextFilter)) != 0',
'            or instr(upper(land),upper(lTextFilter)) != 0',
'        )',
'        and (status_datenstand <> 0)',
'        order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'')        ',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.landid);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>3040005344197842079
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(628096432831742901)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadThemenShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lText varchar2(2000) := apex_application.g_x02;',
'    lArbeitskreis varchar2(2000) ;',
'    lAK_VKO_ID varchar2(2000) := apex_application.g_x03;',
'    lcluster varchar2(2000) := apex_application.g_x04;',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    select  ET_B_AKID into lArbeitskreis from T_ET_B_AK_REF_BENUTZER',
'        where ET_B_AK_REF_BENUTZERID = TO_NUMBER(lAK_VKO_ID); ',
'    --debug(''selected'', lSelected);',
'    --debug(''lText'', lText);',
'    --debug(''lArbeitskreis'', lArbeitskreis);',
'    ',
'    for l in (',
'        select nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ',
'        ( bezeichnung || case when nvl(gueltig, 0) =0 then '' (in GETEX inaktiv)''  ',
'                                                          else '' '' end ',
'        )',
'        ELSE ( name_eng || case when nvl(gueltig, 0) =0 then '' (in GETEX inactive)''  ',
'                                                          else '' '' end ',
'        )',
'    END as  d,',
'         themaid as r',
'        from v_thema_baum',
'        where upper(nummer || '' - '' || bezeichnung) like ''%'' || upper(lText) || ''%''',
'        and  themaid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))      ',
'        and',
'        (',
'            lArbeitskreis = ''-1'' or themaid  in (Select themaid from t_thema_ref_et_b_ak tre where et_b_akid in (',
'            select column_value from table(apex_string.split(lArbeitskreis,'':''))) )',
'        )',
'        and gueltig =1',
'       -- and',
'       -- (',
'      --      lCluster = ''-1'' or themaid  in (Select distinct themaid from t_thema_ref_cluster  where konzern_clusterid in (',
'      --          select column_value from table(apex_string.split(lCluster,'':'')))',
'      --      )',
'     --   )',
'       -- group by nummer, bezeichnung, themaid, thema_sortorder order by thema_sortorder     ',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.r);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>3044115883067645334
);
wwv_flow_imp.component_end;
end;
/
