prompt --application/pages/page_00034
begin
--   Manifest
--     PAGE: 00034
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>34
,p_name=>'25 Working - Backup - 1582'
,p_alias=>'25-WORKING-BACKUP-1582'
,p_step_title=>'25 Working - Backup - 1582'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'/* Click auf Checkbox in Tabellenheader: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'$(''#report-verknuepfungen'').on(''click'', ''th input'', function() {',
'    var check_all = $("#report-verknuepfungen").find("th input:checked").is(":checked");',
'',
'    $("#report-verknuepfungen").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'    if (check_all) {',
'        $("#DELETE_VERKNUEPFUNG").removeClass("apex_disabled");',
'    } else {',
'        $("#DELETE_VERKNUEPFUNG").addClass("apex_disabled");',
'    }',
'',
'    $("#DELETE_VERKNUEPFUNG").prop(''disabled'', !check_all);',
'});',
'',
'/* Click auf Checkbox in Tabellenzeile: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'',
'$(''#report-verknuepfungen'').on(''click'', ''td input'', function() {',
'    var any_checked = $("#report-verknuepfungen").find("td input:checked").length > 0;',
'',
'    if (any_checked) {',
'        $("#DELETE_VERKNUEPFUNG").removeClass("apex_disabled");',
'    } else {',
'        $("#DELETE_VERKNUEPFUNG").addClass("apex_disabled");',
'    }',
'',
'    $("#DELETE_VERKNUEPFUNG").prop(''disabled'', !any_checked);',
'});',
'',
'/* report amendments   ------------------------*/ ',
'$(''#report-amendments'').on(''click'', ''th input'', function() {',
'    var check_all_a = $("#report-amendments").find("th input:checked").is(":checked");',
'',
'    $("#report-amendments").find("td input").each(function() {',
'        this.checked = check_all_a;',
'    });',
'',
'    if (check_all_a) {',
'        $("#DELETE_AMENDMENT").removeClass("apex_disabled");',
'    } else {',
'        $("#DELETE_AMENDMENT").addClass("apex_disabled");',
'    }',
'',
'    $("#DELETE_AMENDMENT").prop(''disabled'', !check_all_a);',
'});',
'',
'/* Click auf Checkbox in Tabellenzeile: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'',
'$(''#report-amendments'').on(''click'', ''td input'', function() {',
'    var any_checked_a = $("#report-amendments").find("td input:checked").length > 0;',
'',
'    if (any_checked_a) {',
'        $("#DELETE_AMENDMENT").removeClass("apex_disabled");',
'    } else {',
'        $("#DELETE_AMENDMENT").addClass("apex_disabled");',
'    }',
'',
'    $("#DELETE_AMENDMENT").prop(''disabled'', !any_checked_a);',
'});',
'',
'',
'',
'',
'',
'',
'',
'function initializeDateTooltips() {',
'    apex.jQuery(".date-tooltip").tooltip({',
'        show: { effect: "fade", delay: 100 },',
'        hide: { effect: "fade", delay: 100 },',
'        track: true,',
'        position: { ',
'            my: "left+10 top+25",',
'            at: "right bottom",',
'            collision: "flipfit"',
'        }',
'    });',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'initializeDateTooltips()',
'',
'',
'',
'$(''#rKerndaten .t-Region-title'').append('' <span onclick="redirect(5)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rEinsatzdaten .t-Region-title'').append('' <span onclick="redirect(6)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rVerknuepfungen .t-Region-title'').append('' <span onclick="redirect(7)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rAnsprechpartner .t-Region-title'').append('' <span onclick="redirect(1109)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rSupplements .t-Region-title'').append('' <span onclick="redirect(1110)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rAmendments .t-Region-title'').append('' <span onclick="redirect(1112)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rErweiterteInfos .t-Region-title'').append('' <span onclick="redirect(1111)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rLaenderThemen .t-Region-title'').append('' <span onclick="redirect(8)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rLaender .t-Region-title'').append('' <span onclick="redirect(30)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rThemen .t-Region-title'').append('' <span onclick="redirect(31)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rMfVs .t-Region-title'').append('' <span onclick="redirect(141)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rVerlinkteNormen .t-Region-title'').append('' <span onclick="redirect(142)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'$(''#rFunktionen .t-Region-title'').append('' <span onclick="redirect(361)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'',
'',
'// Icons im Region Display Selector',
'$(''#rEinsatzdaten_tab span'').replaceWith(''<span><i class="fa fa-calendar" alt="Einsatzdaten" title="Einsatzdaten" aria-hidden="true"></i></span>'');',
unistr('$(''#rVerknuepfungen_tab span'').replaceWith(''<span><i class="fa fa-link" alt="Verkn\00FCpfungen" title="Verkn\00FCpfungen" aria-hidden="true"></i></span>'');'),
'$(''#rAnsprechpartner_tab span'').replaceWith(''<span><i class="fa fa-user" alt="Ansprechpartner" title="Ansprechpartner" aria-hidden="true"></i></span>'');',
'$(''#rSupplements_tab span'').replaceWith(''<span><i class="fa fa-file-plus" alt="UN-R Supplements" title="UN-R Supplements" aria-hidden="true"></i></span>'');',
'',
'',
'',
'var $container = $(''<div>'').css({',
'    ''display'': ''flex'',',
'    ''align-items'': ''center'',',
'    ''gap'': ''20px'',',
'    ''margin-right'': ''80px'' ',
'});',
'',
'var $datumGroup = $(''<div>'').css({',
'    ''display'': ''flex'',',
'    ''align-items'': ''center'',',
'    ''gap'': ''5px''',
'});',
'',
'var $phaseGroup = $(''<div>'').css({',
'    ''display'': ''flex'',',
'    ''align-items'': ''center'',',
'    ''gap'': ''5px''',
'});',
'',
'$(''#P34_DATUM_ANGABE_AS_MJ_LABEL'').appendTo($datumGroup).css({',
'    ''white-space'': ''nowrap'',',
'    ''margin'': ''0''',
'});',
'',
'$(''#P34_DATUM_ANGABE_AS_MJ'').appendTo($datumGroup);',
'',
'$(''#P34_PHASEIN_ENTHALTEN_LABEL'').appendTo($phaseGroup).css({',
'    ''white-space'': ''nowrap'',',
'    ''margin'': ''0''',
'});',
'$(''#P34_PHASEIN_ENTHALTEN'').appendTo($phaseGroup);',
'',
'$container.append($datumGroup).append($phaseGroup);',
'$(''#B487779934025970930'').parent().before($container);',
'',
'$(''#rThemen .t-Region-headerItems--buttons'').css({',
'    ''display'': ''flex'',',
'    ''align-items'': ''center''',
'});',
'',
'if ($(''#P34_DATUM_ANGABE_AS_MJ_CONTAINER'').children().length === 0) {',
'    $(''#P34_DATUM_ANGABE_AS_MJ_CONTAINER'').closest(''.row'').remove();',
'}',
'if ($(''#P34_PHASEIN_ENTHALTEN_CONTAINER'').children().length === 0) {',
'    $(''#P34_PHASEIN_ENTHALTEN_CONTAINER'').closest(''.row'').remove();',
'}',
'',
'',
'',
'',
'',
'',
'',
'// apex.jQuery(document).ready(function() {',
'//     apex.jQuery(''.EDIT_ENABLE'').on(''click'', function() {',
'//         console.log(''1. Edit button clicked'');',
'        ',
'//         var item = apex.item(''P34_DATUM_ANGABE_AS_MJ'');',
'//         console.log(''2. Item value:'', item.getValue());',
'//         console.log(''3. Item enabled:'', !item.isDisabled());',
'        ',
'//         apex.message.setThemeHooks({',
'//             beforeShow: function(msg) {',
'//                 console.log(''4. Error:'', msg);',
'//             }',
'//         });',
'//     });',
'// });',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'$(document).ready(function() {',
'   function applyMerging() {',
'       var $report = $(''#R482915162223535309''); ',
'       ',
'       if (!$report.length) {',
'           return;',
'       }',
'',
'       $report.find(''.t-Report-report'').each(function() {',
'           $(this).find(''tbody tr'').css(''background-color'', ''transparent'');',
'           $(this).find(''tbody tr:even'').css(''background-color'', ''#f0f0f0'');',
'           ',
'           $(this).find(''.t-Report-cell, .t-Report-colHead'').css({ ',
'               ''border'': ''1px solid #e6e6e6''',
'           });',
'           ',
'           const dateColumns = [',
'               ''Einsatztermin alle Fahrzeuge'',',
'               ''Einsatztermin neue Typen'',',
unistr('               ''Datum Au\00DFer Kraft FBU'','),
unistr('               ''Datum Au\00DFer Kraft CKD'','),
'               ''Neue Typen CKD'',',
'               ''Alle Fahrzeuge CKD'',',
'               ''Neue Typen FBU'',',
'               ''Alle Fahrzeuge FBU'',',
'               ''Einsatzzeitpunkt'',',
'               ''MJ Phasein end'',',
'               ''Modelljahr''',
'           ];',
'           ',
'           var columnIndices = {};',
'           var i = 1;',
'           ',
'           $(this).find(''th'').each(function() {',
'               var headerText = $(this).text().trim();',
'               if (dateColumns.includes(headerText)) {',
'                   columnIndices[headerText] = i;',
'               }',
'               i++;',
'           });',
'',
'           var rowData = [];',
'           $(this).find(''tbody tr'').each(function() {',
'               var cells = $(this).find(''td'');',
'               var rowCells = {};',
'               ',
'               Object.keys(columnIndices).forEach(function(columnName) {',
'                   rowCells[columnName] = cells.eq(columnIndices[columnName] - 1);',
'               });',
'               ',
'               rowData.push(rowCells);',
'           });',
'',
'           var mergedCellsMap = new Map();',
'           var mergedRowMap = new Map();',
'',
'           Object.keys(columnIndices).forEach(function(columnName) {',
'               var firstInstance = null;',
'               var currentValue = null;',
'               var currentRowspan = 1;',
'               var startRowIndex = 0;',
'',
'               rowData.forEach(function(row, index) {',
'                   var cell = row[columnName];',
'                   if (!cell || !cell.length) return;',
'                   ',
'                   var cleanText = cell.text().replace(/[*\s]/g, '''').trim();',
'                   var originalHtml = cell.html();',
'',
'                   if (!cleanText || cleanText === '''') {',
'                       firstInstance = null;',
'                       currentValue = null;',
'                       currentRowspan = 1;',
'                       return;',
'                   }',
'',
'                   if (firstInstance === null) {',
'                       firstInstance = cell;',
'                       currentValue = cleanText;',
'                       startRowIndex = index;',
'                       firstInstance.css({',
'                           ''text-align'': ''center'',',
'                           ''vertical-align'': ''middle'',',
'                           ''background-color'': index % 2 === 0 ? ''#f0f0f0'' : ''transparent''',
'                       });',
'                   } else if (cleanText === currentValue) {',
'                       cell.remove();',
'                       currentRowspan++;',
'                       firstInstance.attr(''rowspan'', currentRowspan);',
'                       ',
'                       if (!mergedCellsMap.has(firstInstance[0])) {',
'                           mergedCellsMap.set(firstInstance[0], {',
'                               startRow: startRowIndex,',
'                               rowspan: currentRowspan,',
'                               cells: []',
'                           });',
'                       }',
'                       mergedCellsMap.get(firstInstance[0]).cells.push(firstInstance[0]);',
'',
'                       for(let i = startRowIndex; i < startRowIndex + currentRowspan; i++) {',
'                           if (!mergedRowMap.has(i)) {',
'                               mergedRowMap.set(i, new Set());',
'                           }',
'                           mergedRowMap.get(i).add(firstInstance[0]);',
'                       }',
'                       ',
'                       if (originalHtml.includes(''*'') && !firstInstance.html().includes(''*'')) {',
'                           firstInstance.html(originalHtml);',
'                       }',
'                       firstInstance.css({',
'                           ''border-bottom'': ''1px solid #e6e6e6'',',
'                           ''text-align'': ''center'',',
'                           ''vertical-align'': ''middle'',',
'                           ''background-color'': ''#e6f3ff''',
'                       });',
'                   } else {',
'                       firstInstance = cell;',
'                       currentValue = cleanText;',
'                       currentRowspan = 1;',
'                       startRowIndex = index;',
'                       firstInstance.css({',
'                           ''text-align'': ''center'',',
'                           ''vertical-align'': ''middle'',',
'                           ''background-color'': index % 2 === 0 ? ''#f0f0f0'' : ''transparent''',
'                       });',
'                   }',
'               });',
'           });',
'',
'           $report.find(''tbody tr'').off(''mouseenter mouseleave'');',
'',
'           var $rows = $(this).find(''tbody tr'');',
'           ',
'           $rows.hover(',
'               function() {',
'                   var $currentRow = $(this);',
'                   var rowIndex = $rows.index($currentRow);',
'                   ',
'                   $currentRow.find(''td'').each(function() {',
'                       var $td = $(this);',
'                       if (!$td.attr(''rowspan'')) {',
'                           $td.css({',
'                               ''background-color'': ''#bb0a31'',',
'                               ''color'': ''white''',
'                           });',
'                           ',
'                           $td.find(''.status-asterisk'').css(''color'', ''white'');',
'                       }',
'                   });',
'                   ',
'                   if (mergedRowMap.has(rowIndex)) {',
'                       mergedRowMap.get(rowIndex).forEach(function(cell) {',
'                           var $cell = $(cell);',
'                           $cell.css({',
'                               ''background-color'': ''#bb0a31'',',
'                               ''color'': ''white''',
'                           });',
'                           ',
'                           $cell.find(''.status-asterisk'').css(''color'', ''white'');',
'                       });',
'                   }',
'',
'                   mergedCellsMap.forEach(function(info, cell) {',
'                       if (rowIndex >= info.startRow && rowIndex < (info.startRow + info.rowspan)) {',
'                           var $cell = $(cell);',
'                           $cell.css({',
'                               ''background-color'': ''#bb0a31'',',
'                               ''color'': ''white''',
'                           });',
'                           ',
'                           $cell.find(''.status-asterisk'').css(''color'', ''white'');',
'                       }',
'                   });',
'               },',
'               function() {',
'                   var $currentRow = $(this);',
'                   var rowIndex = $rows.index($currentRow);',
'                   var isEvenRow = rowIndex % 2 === 0;',
'                   ',
'                   $currentRow.find(''td:not([rowspan])'').each(function() {',
'                       var $td = $(this);',
'                       $td.css({',
'                           ''background-color'': isEvenRow ? ''#f0f0f0'' : ''transparent'',',
'                           ''color'': ''inherit''',
'                       });',
'                      ',
'                       $td.find(''.status-asterisk'').css(''color'', ''red'');',
'                   });',
'                   ',
'                   if (mergedRowMap.has(rowIndex)) {',
'                       mergedRowMap.get(rowIndex).forEach(function(cell) {',
'                           var $cell = $(cell);',
'                           $cell.css({',
'                               ''background-color'': ''#e6f3ff'',',
'                               ''color'': ''inherit''',
'                           });',
'                          ',
'                           $cell.find(''.status-asterisk'').css(''color'', ''red'');',
'                       });',
'                   }',
'',
'                   mergedCellsMap.forEach(function(info, cell) {',
'                       if (rowIndex >= info.startRow && rowIndex < (info.startRow + info.rowspan)) {',
'                           var $cell = $(cell);',
'                           $cell.css({',
'                               ''background-color'': ''#e6f3ff'',',
'                               ''color'': ''inherit''',
'                           });',
'                          ',
'                           $cell.find(''.status-asterisk'').css(''color'', ''red'');',
'                       }',
'                   });',
'               }',
'           );',
'       });',
'   }',
'',
'   applyMerging();',
'',
'   apex.jQuery("#R482915162223535309").on("apexafterrefresh", function() {',
'    //    location.reload();',
'       applyMerging();',
'   });',
'});',
'',
'',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#t_Body_content_offset {',
'    height: 90px !important;',
'}',
'',
'div#ig_einsatzdaten div.a-GV-footer {',
'    display: none',
'}',
'',
'div#ig_einsatzdaten tr.is-selected .a-GV-cell {',
'    background-color: white !important; ',
'    color: rgb(64, 64, 64) !important;',
'}',
'',
'',
'#P34_LINK_ZUR_VORSCHRIFT_DMS_inline_help {',
'    white-space: pre-wrap',
'}',
'',
'#P34_LINK_ZUR_VORSCHRIFT_DMS_inline_help a {',
'    text-decoration: underline',
'}',
'',
'div#ig_einsatzdaten td.is-readonly {',
'    white-space: pre-wrap;',
'}',
'',
'.red_noasc{',
'    color: red !important;',
'}',
'',
'#P34_NORMID_inline_help a {',
'    text-decoration: underline;',
'    text-decoration-style: dashed;',
'}',
'',
'',
'.getexlogo::after {',
'    content: ''GETEX'';',
'    position: absolute;',
'    right: 20px;',
'    color: #0000ff82;',
'    margin-right: 15px;',
'    font-weight: bold;',
'    top: 5px;',
'    font-size: 20px;',
'    font-family: ''Audi Type Extended'';',
'}',
'',
'',
'',
'.getexlogo.t-Region-header::after {',
'    margin-right: 50px;',
'}',
'',
'',
'',
'.status-asterisk {',
'    color: red;',
'}',
'/* ',
'tr:hover .status-asterisk {',
'    color: white;',
'}',
' */',
'',
'',
'',
'.fa-asterisk:hover {',
'   color: lightgreen !important;',
'}',
'',
'',
'/* ',
'.date-tooltip {',
'    cursor: help;',
'} */',
'',
'',
'',
'',
'',
'',
'',
'/* No Data Found CSS for Reports*/',
'.no-data-message {',
'    background-color: #f5f5f5;',
'    color: #333333;',
'    padding: 8px 12px;',
'    font-family: ''Segoe UI'', Arial, sans-serif;',
'    border-left: 3px solid #bb0a31; /*#4CAF50;*/',
'    margin: 10px 0;',
'    font-size: 13px;',
'    line-height: 1.4;    ',
'}',
'',
'.highlight {',
'    color: #d60c38; /*#e6b800;*/',
'',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(541399329256322071)
,p_plug_name=>'Themen'
,p_region_name=>'rThemen'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>35
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
' -- and :P34_VORSCHRIFT_TYPID <> 20)',
' (:P34_ROWID is not null or :P34_Vorschriftid is not null)'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(541398481243322062)
,p_name=>'Themen neu'
,p_region_name=>'R482915162223535309'
,p_parent_plug_id=>wwv_flow_imp.id(541399329256322071)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  sqlqry clob;',
'  lVorschriftID number := :P34_VORSCHRIFTID;',
'  lColList clob;',
'  l_columns clob;',
'  l_modelyear_col clob;  -- New variable for conditional Model Year column',
'BEGIN',
'    -- Get dynamic columns for PIVOT ',
'    SELECT LISTAGG('''''''' || EINSATZDATUM_TYP || '''''' AS "'' || EINSATZDATUM_TYP || ''"'', '', '') ',
'    WITHIN GROUP (ORDER BY sortorder) into lColList',
'    FROM (',
'      SELECT DISTINCT EINSATZDATUM_TYP, sortorder',
'      FROM T_EINSATZDATUM_TYP edt',
'      JOIN T_VORSCHRIFT_REF_THEMA_REF_EINSATZDATUM_TYP vte ON edt.EINSATZDATUM_TYPID = vte.EINSATZDATUM_TYPID',
'      WHERE vte.VORSCHRIFTID = lVorschriftID ',
'      AND vte.einsatzdatum_typid != 1031',
'      AND (',
'           (:P34_VORSCHRIFT_TYPID IN (10, 30, 40) AND edt.einsatzdatum_modellid = :P34_EINSATZDATUM_MODELLID)',
'          )',
'    );',
'',
'    -- Get column names for final SELECT',
'    WITH cols AS (',
'      SELECT DISTINCT '',"'' || EINSATZDATUM_TYP || ''"'' as col_name, sortorder',
'      FROM T_EINSATZDATUM_TYP edt',
'      JOIN T_VORSCHRIFT_REF_THEMA_REF_EINSATZDATUM_TYP vte ON edt.EINSATZDATUM_TYPID = vte.EINSATZDATUM_TYPID',
'      WHERE vte.VORSCHRIFTID = lVorschriftID ',
'      AND vte.einsatzdatum_typid != 1031',
'      AND (',
'          (:P34_VORSCHRIFT_TYPID IN (10, 30, 40) AND edt.einsatzdatum_modellid = :P34_EINSATZDATUM_MODELLID)',
'          )',
'    )',
'    SELECT LISTAGG(col_name) WITHIN GROUP (ORDER BY sortorder) INTO l_columns',
'    FROM cols;',
'',
'    ',
'    IF l_columns IS NULL THEN',
'        l_columns := '''';',
'    END IF;',
'',
'    -- Set Model Year column based on MODELLID',
'    IF :P34_EINSATZDATUM_MODELLID = 30 THEN',
'        l_modelyear_col := '',MODELLJAHR as "Modelljahr"'';',
'    ELSE',
'        l_modelyear_col := '''';',
'    END IF;',
'',
'    sqlqry := ''WITH base_data AS (',
'    SELECT ',
'        ''''<a href='''' || ''''"'''' || APEX_PAGE.GET_URL (',
'            p_clear_cache => 104,',
'            p_page => 104,',
'            p_items => ''''P104_THEMAID'''' || '''',P104_VORSCHRIFTID,P104_OPEN_TO_DELETE,'''' || ''''P104_THEMA_READ_ONLY'''',',
'            p_values => vt.themaid || '''','''' || :P34_VORSCHRIFTID || '''',1,0''''',
'        ) || ''''"'''' || ''''"><span class="fa fa-trash" alt="'''' ',
unistr('        || emano_util.fLang(''''L\00F6schen'''', ''''Delete'''') '),
'        || ''''" title="'''' ',
unistr('        || emano_util.fLang(''''L\00F6schen'''', ''''Delete'''') '),
'        || ''''"></span></a>'''' AS " ",',
'',
'        CASE ',
'            WHEN PCK_RI.fIsAuthorized01(pck_ri.fGetUserid, 25, 200) = 1 -- AND (:P34_EDIT_MODE = 1) ',
'            THEN ''''<a href='''' || ''''"'''' || APEX_PAGE.GET_URL (',
'                p_clear_cache => 104,',
'                p_page => 104,',
'                p_items => ''''P104_THEMAID'''' || '''',P104_VORSCHRIFTID,P104_THEMA_READ_ONLY'''',',
'                p_values => vt.themaid || '''','''' || vrt.vorschriftid || '''','''' || 0',
'            ) || ''''"'''' || ''''"><span class="fa fa-pencil" alt="'''' ',
'            || emano_util.fLang(''''Bearbeiten'''', ''''Edit'''') ',
'            || ''''" title="'''' ',
'            || emano_util.fLang(''''Bearbeiten'''', ''''Edit'''') ',
'            || ''''"></span></a>'''' || '''' ''''',
'            ELSE NULL ',
'        END AS "&#160;",',
'        ',
'        vt.thema_sortorder as SORT_ORDER,',
'        vt.nummer as "Nummer",',
'        CASE ',
'            WHEN :FSP_LANGUAGE_PREFERENCE = ''''de'''' THEN concat(vt.bezeichnung, case when (nvl(vt.gueltig,0)=0) then '''' <b>(in GETEX inaktiv )</b>''''  else '''' '''' end )',
'            ELSE concat(vt.name_eng, case when (nvl(vt.gueltig,0)=0) then  '''' ( in GETEX inactive)''''  else '''' '''' end )',
'        END AS "Thema",',
'',
'        CASE ',
'            WHEN :FSP_LANGUAGE_PREFERENCE = ''''de'''' THEN vrt.bemerkung',
'            ELSE vrt.bemerkung_englisch',
'        END AS "Kommentar",',
'        ',
'        vrt.letzte_aenderung_datum as AENDERUNG_DATUM_TEMP,',
'        -- b.nachname || '''', '''' || b.vorname as AENDERUNG_BENUTZER_TEMP,',
'        CASE ',
'            WHEN b.nachname IS NOT NULL AND b.vorname IS NOT NULL ',
'                THEN b.nachname || '''', '''' || b.vorname',
'            WHEN b.nachname IS NOT NULL AND b.vorname IS NULL ',
'                THEN b.nachname',
'            WHEN b.nachname IS NULL AND b.vorname IS NOT NULL ',
'                THEN b.vorname',
'            ELSE NULL ',
'        END as AENDERUNG_BENUTZER_TEMP,',
'        ',
'        edt.EINSATZDATUM_TYP as TYP,',
'        TO_CHAR(vte.EINSATZDATUM, ''''DD.MM.YYYY'''') || CASE ',
'            WHEN vte.EINSATZDATUM = vrte.EINSATZDATUM and vte.EINSATZDATUM_TYPID = vrte.EINSATZDATUM_TYPID',
unistr('            THEN '''' <span class="date-tooltip" title="F\00FCr Berechnung im Cockpit verwendet"><sup><span class="fa fa-asterisk status-asterisk" style="font-size:13px;"></span></sup></span>'''''),
'            ELSE ''''''''  ',
'        END as DATUM,',
'        ',
'        CASE ',
'            WHEN :P34_EINSATZDATUM_MODELLID = 30 AND :P34_DATUM_ANGABE_AS_MJ = 1 THEN EXTRACT(YEAR FROM vte.MODELJAHR)',
'            ELSE NULL',
'        END as MODELLJAHR',
'        ',
'    FROM t_vorschrift_ref_thema vrt',
'    LEFT OUTER JOIN v_thema_baum vt ON (vrt.themaid = vt.themaid) ',
'    LEFT OUTER JOIN T_VORSCHRIFT_REF_THEMA_REF_EINSATZDATUM_TYP vte ON (vrt.themaid = vte.themaid and vte.VORSCHRIFTID=vrt.VORSCHRIFTID) ',
'    LEFT OUTER JOIN T_VORSCHRIFT_REF_EINSATZDATUM_TYP vrte ON (vrte.EINSATZDATUM_TYPID = vte.EINSATZDATUM_TYPID and vrte.VORSCHRIFTID=vte.VORSCHRIFTID) ',
'    LEFT OUTER JOIN T_EINSATZDATUM_TYP edt ON (vte.einsatzdatum_typid = edt.einsatzdatum_typid)',
'    LEFT JOIN t_benutzer b ON (b.benutzerid = vrt.letzte_aenderung_benutzerid)',
'    WHERE vrt.vorschriftid = '' || lVorschriftID || '' ',
'    AND vrt.geloescht != 1',
'    ),',
'    pivot_data AS (',
'        SELECT *',
'        FROM base_data',
'        PIVOT (',
'            MAX(DATUM)',
'            FOR TYP IN ('' || lColList || '')',
'        )',
'    )',
'    SELECT ',
'        " ",',
'        "&#160;",',
'        SORT_ORDER,',
'        "Nummer",',
'        "Thema",',
'        "Kommentar"'' || ',
'        l_columns || ',
'        l_modelyear_col || '',',
unistr('        AENDERUNG_BENUTZER_TEMP as "\00C4nderungsbenutzer",'),
unistr('        AENDERUNG_DATUM_TEMP as "\00C4nderungsdatum"'),
'        ',
'    FROM pivot_data',
'    ORDER BY sort_order'';',
'',
'   RETURN sqlqry;',
'   ',
'END;'))
,p_optimizer_hint=>'WITH_PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_read_only_when=>'(:P34_STRG_GETEX_ANZEIGE = 20 and nvl(:P34_EDIT_MODE, 0) = 1)'
,p_read_only_when2=>'PLSQL'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P34_VORSCHRIFTID,P34_EDIT_MODE,P34_EINSATZDATUM_MODELLID,P34_DATUM_ANGABE_AS_MJ'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_plug_query_max_columns=>20
,p_query_headings_type=>'QUERY_COLUMNS'
,p_query_num_rows=>100000
,p_query_options=>'GENERIC_REPORT_COLUMNS'
,p_query_no_data_found=>'Noch keine Themen zugeordnet.'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>unistr('title="F\00FCr Berechnung im Cockpit verwendet"')
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1029176117699292895)
,p_query_column_id=>1
,p_column_alias=>'COL01'
,p_column_display_sequence=>20
,p_column_heading=>'Delete'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>'(:P34_STRG_GETEX_ANZEIGE = 10)'
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_column_comment=>'(:P34_STRG_GETEX_ANZEIGE !=20)'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1029175723516292892)
,p_query_column_id=>2
,p_column_alias=>'COL02'
,p_column_display_sequence=>10
,p_column_heading=>'Edit'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_column_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P34_STRG_GETEX_ANZEIGE !=20)',
'',
'f useer has wriete accecss edit mode '))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1029175378886292892)
,p_query_column_id=>3
,p_column_alias=>'COL03'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1029174948494292891)
,p_query_column_id=>4
,p_column_alias=>'COL04'
,p_column_display_sequence=>50
,p_column_heading=>'Col04'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028974597867292891)
,p_query_column_id=>5
,p_column_alias=>'COL05'
,p_column_display_sequence=>60
,p_column_heading=>'Col05'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028974116024292889)
,p_query_column_id=>6
,p_column_alias=>'COL06'
,p_column_display_sequence=>70
,p_column_heading=>'Col06'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028973750596292889)
,p_query_column_id=>7
,p_column_alias=>'COL07'
,p_column_display_sequence=>80
,p_column_heading=>'Col07'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028973364596292888)
,p_query_column_id=>8
,p_column_alias=>'COL08'
,p_column_display_sequence=>90
,p_column_heading=>'Col08'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028972948377292888)
,p_query_column_id=>9
,p_column_alias=>'COL09'
,p_column_display_sequence=>100
,p_column_heading=>'Col09'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028972607426292887)
,p_query_column_id=>10
,p_column_alias=>'COL10'
,p_column_display_sequence=>110
,p_column_heading=>'Col10'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028972142837292887)
,p_query_column_id=>11
,p_column_alias=>'COL11'
,p_column_display_sequence=>120
,p_column_heading=>'Col11'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028971797808292887)
,p_query_column_id=>12
,p_column_alias=>'COL12'
,p_column_display_sequence=>130
,p_column_heading=>'Col12'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028971360995292886)
,p_query_column_id=>13
,p_column_alias=>'COL13'
,p_column_display_sequence=>140
,p_column_heading=>'Col13'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028970924281292886)
,p_query_column_id=>14
,p_column_alias=>'COL14'
,p_column_display_sequence=>150
,p_column_heading=>'Col14'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028970593033292885)
,p_query_column_id=>15
,p_column_alias=>'COL15'
,p_column_display_sequence=>160
,p_column_heading=>'Col15'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028970175032292885)
,p_query_column_id=>16
,p_column_alias=>'COL16'
,p_column_display_sequence=>170
,p_column_heading=>'Col16'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028969751164292884)
,p_query_column_id=>17
,p_column_alias=>'COL17'
,p_column_display_sequence=>180
,p_column_heading=>'Col17'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028969356396292884)
,p_query_column_id=>18
,p_column_alias=>'COL18'
,p_column_display_sequence=>190
,p_column_heading=>'Col18'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028968922427292884)
,p_query_column_id=>19
,p_column_alias=>'COL19'
,p_column_display_sequence=>200
,p_column_heading=>'Col19'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028968572951292883)
,p_query_column_id=>20
,p_column_alias=>'COL20'
,p_column_display_sequence=>210
,p_column_heading=>'Col20'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1952421421779429465)
,p_plug_name=>'Amendments'
,p_region_name=>'rAmendments'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>95
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'((:P34_ROWID is not null or :P34_Vorschriftid is not null)',
'  and :P34_VORSCHRIFT_TYPID not in (20, 50)',
'  --and instr(UPPER(:P34_VORSCHRIFT_NUMMER), ''UN-R'') = 0 ',
')'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1952421574103429466)
,p_name=>'REPORT_AMENDMENTS'
,p_region_name=>'report-amendments'
,p_parent_plug_id=>wwv_flow_imp.id(1952421421779429465)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vrv.rowid as ROW_ID,',
'    vv.vorschrift_nummer || nvl2(vv.vorschrift_bezeichnung,'' - '', '' '' ) || vv.vorschrift_bezeichnung as vorgaenger_vorschrift,',
'    nv.vorschrift_nummer ||  nvl2(nv.vorschrift_bezeichnung,'' - '', '' '' )  || nv.vorschrift_bezeichnung as nachfolger_vorschrift,',
'    vrv.beziehung_art,',
'    (select vret.einsatzdatum',
'        from t_vorschrift_ref_einsatzdatum_typ  vret',
'        where (nv.vorschriftid = vret.vorschriftid)',
'        and vret.einsatzdatum_typid = 1000) as DATUM_IN_KRAFT,',
'    vrv.kommentar,',
'    vrv.letzte_aenderung_datum,',
'    b.nachname || '', '' || b.vorname as Letzte_aenderung_Benutzer,',
'    nv.rowid as amnd_rowid,',
'    nvl(vorgaenger_vorschriftid,vrv.nachfolger_vorschriftid) as vorgaenger_vorschriftid,',
'    vrv.nachfolger_vorschriftid',
'from t_vorschrift_ref_vorschrift vrv',
'left outer join t_benutzer b on b.benutzerid = vrv.letzte_aenderung_benutzerid',
'join t_vorschrift vv on vv.vorschriftid = vrv.vorgaenger_vorschriftid and (vrv.BEZIEHUNG_ART IN (20))-- Beziehung Amendment',
'join t_vorschrift nv on nv.vorschriftid = vrv.nachfolger_vorschriftid and (vrv.BEZIEHUNG_ART IN (20))-- Beziehung Amendment',
'',
'where  (vrv.vorgaenger_vorschriftid = :P34_VORSCHRIFTID)     ',
'      --  or (vrv.nachfolger_vorschriftid = :P34_VORSCHRIFTID)     ',
'    ',
'order by 1 ',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P34_VORSCHRIFTID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Keine Amendments zugeordnet.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028873866052292708)
,p_query_column_id=>1
,p_column_alias=>'ROW_ID'
,p_column_display_sequence=>20
,p_column_link=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.:45:P45_ROWID,P45_MASTER:#ROW_ID#,&P34_STRG_GETEX_ANZEIGE.'
,p_column_linktext=>'<span class="fa fa-pencil" alt="Bearbeiten" title="Bearbeiten"  />'
,p_report_column_required_role=>wwv_flow_imp.id(756418224517528353)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028873485772292707)
,p_query_column_id=>2
,p_column_alias=>'VORGAENGER_VORSCHRIFT'
,p_column_display_sequence=>40
,p_column_heading=>'Vorschrift'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028873065215292707)
,p_query_column_id=>3
,p_column_alias=>'NACHFOLGER_VORSCHRIFT'
,p_column_display_sequence=>50
,p_column_heading=>'Verlinkte Vorschrift'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028872678457292707)
,p_query_column_id=>4
,p_column_alias=>'BEZIEHUNG_ART'
,p_column_display_sequence=>60
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028872220444292706)
,p_query_column_id=>5
,p_column_alias=>'DATUM_IN_KRAFT'
,p_column_display_sequence=>70
,p_column_heading=>unistr('In Kraftsetzung aus verkn\00FCpfter Vorschrift')
,p_column_format=>'DD.MM.YYYY'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028871871998292706)
,p_query_column_id=>6
,p_column_alias=>'KOMMENTAR'
,p_column_display_sequence=>80
,p_column_heading=>'Kommentar'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028871487781292706)
,p_query_column_id=>7
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>90
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028871050468292705)
,p_query_column_id=>8
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZER'
,p_column_display_sequence=>100
,p_column_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028870649938292705)
,p_query_column_id=>9
,p_column_alias=>'AMND_ROWID'
,p_column_display_sequence=>110
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028870285329292705)
,p_query_column_id=>10
,p_column_alias=>'VORGAENGER_VORSCHRIFTID'
,p_column_display_sequence=>120
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028869877046292705)
,p_query_column_id=>11
,p_column_alias=>'NACHFOLGER_VORSCHRIFTID'
,p_column_display_sequence=>130
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028869504475292704)
,p_query_column_id=>12
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>30
,p_column_heading=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:25:P34_VORSCHRIFTID:#NACHFOLGER_VORSCHRIFTID#'
,p_column_linktext=>unistr('<span class="fa fa-search" alt="\00D6ffnen" title="\00D6ffnen"  />')
,p_column_link_attr=>'  target="_blank"'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028869052465292704)
,p_query_column_id=>13
,p_column_alias=>'DERIVED$02'
,p_column_display_sequence=>10
,p_column_heading=>'<input type="checkbox" value="all" />'
,p_column_html_expression=>'<input type="checkbox" value="#ROW_ID#" />'
,p_column_alignment=>'CENTER'
,p_report_column_required_role=>wwv_flow_imp.id(756418224517528353)
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5702656122314296104)
,p_plug_name=>unistr('L\00E4nder')
,p_region_name=>'rLaender'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>165
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'((:P34_ROWID is not null or :P34_Vorschriftid is not null)',
'  and :P34_VORSCHRIFT_TYPID <> 20)'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(5702656355675296106)
,p_name=>unistr('L\00E4nder Tabelle')
,p_parent_plug_id=>wwv_flow_imp.id(5702656122314296104)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'''<a href=''||''"''||APEX_PAGE.GET_URL ( ',
'        p_clear_cache => 103,',
'        p_page   => 103,  ',
'        p_items  =>   ''P103_LANDID''  ||'',P103_VORSCHRIFTID,P103_OPEN_TO_DELETE,''||''P103_LAND_READ_ONLY'', ',
'        p_values => la.landid||'',''||:P34_VORSCHRIFTID ||'',1,0''  )||''"''|| ''"><span class="fa fa-trash" alt="'' ',
unistr('                                                                                                        || emano_util.fLang(''L\00F6schen'', ''Delete'') '),
'                                                                                                        || ''" title="'' ',
unistr('                                                                                                        || emano_util.fLang(''L\00F6schen'', ''Delete'') '),
'                                                                                                        || ''"></span></a>'' AS link,',
'',
'case when PCK_RI.fIsAuthorized01(pck_ri.fGetUserid,25,200) = 1 and (:P34_EDIT_MODE = 1) ',
'     then ''<a href=''||''"''||APEX_PAGE.GET_URL (      ',
'                                       p_clear_cache => 103,',
'                                       p_page   => 103,  ',
'                                       p_items  =>  ''P103_LANDID''   ',
'                                       ||'',P103_VORSCHRIFTID,P103_LAND_READ_ONLY'', ',
'                                       p_values => vrl.landid||'',''||vorschriftid ||'',''|| 0 ) ||',
'                     ''"''|| ''><span class="fa fa-pencil" alt="'' ',
'                                                                    || emano_util.fLang(''Bearbeiten'', ''Edit'') ',
'                                                                    || ''" title="'' ',
'                                                                    || emano_util.fLang(''Bearbeiten'', ''Edit'') ',
'                                                                    || ''"></span></a>'' || '' '' ',
'                                                                    ELSE NULL END AS lnk,',
'',
'la.b_nummer || '' - '' ||  ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN la.Land',
'        ELSE la.Land_eng ',
'    END AS Land,',
'  nvl2(FLAGGE, ''<img width=20 src="'' || apex_page.get_url(p_page => 0, p_items => ''G_LANDID'', p_values => la.landid, p_request => ''APPLICATION_PROCESS=getFlag'') || ''" />'', null)',
'   AS FLAGGE_URL,',
'    --  vrl.bemerkung Kommentar,',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN vrl.bemerkung',
'        ELSE vrl.BEMERKUNG_ENGLISCH',
'    END as Kommentar,',
'',
'     vrl.letzte_aenderung_datum Aenderungsdatum,',
'    --  b.nachname ||'', ''|| b.vorname as Aenderungsbenutzer ,',
'    CASE ',
'        WHEN b.nachname IS NOT NULL AND b.vorname IS NOT NULL ',
'            THEN b.nachname || '', '' || b.vorname',
'        WHEN b.nachname IS NOT NULL AND b.vorname IS NULL ',
'            THEN b.nachname',
'        WHEN b.nachname IS NULL AND b.vorname IS NOT NULL ',
'            THEN b.vorname',
'        ELSE NULL ',
'    END as Aenderungsbenutzer,',
'     CASE la.SUMS_RELEVANT',
'        WHEN 10 THEN ''ja''',
'        WHEN 20 THEN ''nein''',
'        WHEN 30 THEN ''nicht bewertet''',
'       ',
'',
'    END AS SUMS_RELEVANT',
'from t_vorschrift_ref_land vrl',
'left outer join t_land la on (vrl.landid = la.landid)',
'left join t_benutzer b on (b.benutzerid = vrl.letzte_aenderung_benutzerid)',
'where vrl.vorschriftid = :P34_VORSCHRIFTID and vrl.geloescht !=1',
''))
,p_read_only_when_type=>'EXPRESSION'
,p_read_only_when=>' (:P34_STRG_GETEX_ANZEIGE = 20 and nvl(:P34_EDIT_MODE, 0) = 1)'
,p_read_only_when2=>'PLSQL'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P34_VORSCHRIFTID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>200
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('Noch keine L\00E4nder zugeordnet.')
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028866827935292702)
,p_query_column_id=>1
,p_column_alias=>'LINK'
,p_column_display_sequence=>10
,p_column_heading=>'&nbsp;'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>'(:P34_STRG_GETEX_ANZEIGE !=20)'
,p_display_when_condition2=>'PLSQL'
,p_report_column_required_role=>wwv_flow_imp.id(756418224517528353)
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028866418989292701)
,p_query_column_id=>2
,p_column_alias=>'LNK'
,p_column_display_sequence=>20
,p_column_heading=>'&nbsp;'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>'(:P34_STRG_GETEX_ANZEIGE !=20)'
,p_display_when_condition2=>'PLSQL'
,p_report_column_required_role=>wwv_flow_imp.id(756418224517528353)
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028866099157292701)
,p_query_column_id=>3
,p_column_alias=>'LAND'
,p_column_display_sequence=>40
,p_column_heading=>'Land'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028865712441292701)
,p_query_column_id=>4
,p_column_alias=>'FLAGGE_URL'
,p_column_display_sequence=>30
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028865274919292700)
,p_query_column_id=>5
,p_column_alias=>'KOMMENTAR'
,p_column_display_sequence=>50
,p_column_heading=>'Kommentar'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028864876496292700)
,p_query_column_id=>6
,p_column_alias=>'AENDERUNGSDATUM'
,p_column_display_sequence=>70
,p_column_heading=>unistr('\00C4nderungsdatum')
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028864452555292700)
,p_query_column_id=>7
,p_column_alias=>'AENDERUNGSBENUTZER'
,p_column_display_sequence=>60
,p_column_heading=>unistr('\00C4nderungsbenutzer')
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028864107688292699)
,p_query_column_id=>8
,p_column_alias=>'SUMS_RELEVANT'
,p_column_display_sequence=>80
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5702656960153296112)
,p_plug_name=>'Themen alt'
,p_region_name=>'rThemen'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>175
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(5702657139491296114)
,p_name=>'Themen Tabelle'
,p_parent_plug_id=>wwv_flow_imp.id(5702656960153296112)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
' ''<a href=''||''"''||APEX_PAGE.GET_URL ( ',
'        p_clear_cache => 104,',
'        p_page   => 104,  ',
'        p_items  =>  ''P104_THEMAID''  ||'',P104_VORSCHRIFTID,P104_OPEN_TO_DELETE,''||''P104_THEMA_READ_ONLY'', ',
'        p_values => vt.themaid||'',''||:P34_VORSCHRIFTID ||'',1,0''  )||''"''|| ''"><span class="fa fa-trash" alt="'' ',
unistr('                                                                                                                || emano_util.fLang(''L\00F6schen'', ''Delete'') '),
'                                                                                                                || ''" title="'' ',
unistr('                                                                                                                || emano_util.fLang(''L\00F6schen'', ''Delete'') '),
'                                                                                                                || ''"></span></a>'' AS link,',
'',
'case when PCK_RI.fIsAuthorized01(pck_ri.fGetUserid,25,200) = 1 and (:P34_EDIT_MODE = 1) ',
'     then ''<a href=''||''"''||APEX_PAGE.GET_URL (      ',
'                                       p_clear_cache => 104,',
'                                       p_page   => 104,  ',
'                                       p_items  =>   ''P104_THEMAID''   ',
'                                       ||'',P104_VORSCHRIFTID,P104_THEMA_READ_ONLY'', ',
'                                       p_values => vt.themaid||'',''||vrt.vorschriftid ||'',''|| 0 ) ||',
'                     ''"''|| ''"><span class="fa fa-pencil" alt="'' ',
'|| emano_util.fLang(''Bearbeiten'', ''Edit'') ',
'|| ''" title="'' ',
'|| emano_util.fLang(''Bearbeiten'', ''Edit'') ',
'|| ''"></span></a>'' || '' '' ',
'ELSE NULL END AS lnk,',
'    vt.nummer || '' '' || ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN vt.bezeichnung',
'        ELSE vt.name_eng',
'    END as Thema,',
'',
'    -- vt.nummer||'' '' || vt.bezeichnung as Thema,',
'    --  vrt.bemerkung Kommentar,',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN vrt.bemerkung',
'        ELSE vrt.bemerkung_englisch',
'    END as Kommentar,',
'     vrt.letzte_aenderung_datum Aenderungsdatum,',
'     b.nachname ||'', ''|| b.vorname as Aenderungsbenutzer ',
'     --',
'from t_vorschrift_ref_thema vrt',
'left outer join v_thema_baum vt on (vrt.themaid = vt.themaid) ',
'left join t_benutzer b on (b.benutzerid = vrt.letzte_aenderung_benutzerid)',
'where vrt.vorschriftid = :P34_VORSCHRIFTID and vrt.geloescht !=1',
'order by vt.thema_sortorder;'))
,p_read_only_when_type=>'EXPRESSION'
,p_read_only_when=>'(:P34_STRG_GETEX_ANZEIGE = 20 and nvl(:P34_EDIT_MODE, 0) = 1)'
,p_read_only_when2=>'PLSQL'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P34_VORSCHRIFTID,P34_EDIT_MODE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Noch keine Themen zugeordnet.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028862248893292697)
,p_query_column_id=>1
,p_column_alias=>'LINK'
,p_column_display_sequence=>10
,p_column_heading=>'&nbsp;'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>'(:P34_STRG_GETEX_ANZEIGE !=20)'
,p_display_when_condition2=>'PLSQL'
,p_report_column_required_role=>wwv_flow_imp.id(756418224517528353)
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028861896435292697)
,p_query_column_id=>2
,p_column_alias=>'LNK'
,p_column_display_sequence=>20
,p_column_heading=>'&nbsp;'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>'(:P34_STRG_GETEX_ANZEIGE !=20)'
,p_display_when_condition2=>'PLSQL'
,p_report_column_required_role=>wwv_flow_imp.id(756418224517528353)
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028861452485292697)
,p_query_column_id=>3
,p_column_alias=>'THEMA'
,p_column_display_sequence=>30
,p_column_heading=>'Thema'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028861083386292696)
,p_query_column_id=>4
,p_column_alias=>'KOMMENTAR'
,p_column_display_sequence=>40
,p_column_heading=>'Kommentar'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028860655020292696)
,p_query_column_id=>5
,p_column_alias=>'AENDERUNGSDATUM'
,p_column_display_sequence=>60
,p_column_heading=>unistr('\00C4nderungsdatum')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028860313936292696)
,p_query_column_id=>6
,p_column_alias=>'AENDERUNGSBENUTZER'
,p_column_display_sequence=>50
,p_column_heading=>unistr('\00C4nderungsbenutzer')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5707933684500382675)
,p_plug_name=>'Verlinkte Normen'
,p_region_name=>'rVerlinkteNormen'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>135
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'NEVER'
,p_plug_read_only_when_type=>'FUNCTION_BODY'
,p_plug_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if apex_util.public_check_authorization(''fUserHasWriteAccess'') then ',
'    return false or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1);',
'else ',
'    return true or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1);',
'end if;'))
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5707933731121382676)
,p_plug_name=>'Verlinkte Normen'
,p_parent_plug_id=>wwv_flow_imp.id(5707933684500382675)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vn.rowid',
'    , vn.VORSCHRIFTID',
'    , vn.NUMMER as NormNummer',
'    , vn.BEZEICHNUNG AS NormBezeichnung',
'    , vn.LETZTE_AENDERUNG_DATUM',
'    , nvl2(vn.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname  , null) AS LETZTE_AENDERUNG_BENUTZER',
'FROM T_VERLINKTE_NORM vn',
'LEFT OUTER JOIN T_BENUTZER b on b.benutzerid = vn.LETZTE_AENDERUNG_BENUTZERID',
'WHERE VORSCHRIFTID = :P34_VORSCHRIFTID',
';'))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsUserInRolle(',
'    listRolleId => ''1000:1003'' -- 1000 = VKO, 1003 = Admin',
') = 0'))
,p_plug_read_only_when2=>'PLSQL'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Verlinkte Normen'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5707933898391382678)
,p_name=>'NORMNUMMER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NORMNUMMER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Nummer der Norm'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>true
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5707934050015382679)
,p_name=>'NORMBEZEICHNUNG'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NORMBEZEICHNUNG'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Bezeichnung der Norm'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>1024
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5707934147276382680)
,p_name=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ROWID'
,p_data_type=>'ROWID'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5707934281050382681)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5707934302685382682)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'Y',
  'hide_control', 'N',
  'show_select_all', 'Y')).to_clob
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5707934855409382687)
,p_name=>'LETZTE_AENDERUNG_DATUM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LETZTE_AENDERUNG_DATUM'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DATE_PICKER'
,p_heading=>unistr('Letzte \00C4nderung Datum')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5707934979140382688)
,p_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LETZTE_AENDERUNG_BENUTZER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>242
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5707935023210382689)
,p_name=>'VORSCHRIFTID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFTID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P34_VORSCHRIFTID'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(5707933836457382677)
,p_internal_uid=>9380146152356770912
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_edit_row_operations_column=>'ROWID'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_no_data_found_message=>'Es sind keine verlinkten Normen vorhanden.'
,p_show_toolbar=>true
,p_toolbar_buttons=>null
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV'
,p_enable_mail_download=>false
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(5717738194425457080)
,p_interactive_grid_id=>wwv_flow_imp.id(5707933836457382677)
,p_static_id=>'20337782'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(5717738290619457082)
,p_report_id=>wwv_flow_imp.id(5717738194425457080)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(5717738811877457088)
,p_view_id=>wwv_flow_imp.id(5717738290619457082)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(5707933898391382678)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(5717739300268457094)
,p_view_id=>wwv_flow_imp.id(5717738290619457082)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(5707934050015382679)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(5717739804626457096)
,p_view_id=>wwv_flow_imp.id(5717738290619457082)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(5707934147276382680)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(5717742384008480682)
,p_view_id=>wwv_flow_imp.id(5717738290619457082)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(5707934281050382681)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(5717760983993962506)
,p_view_id=>wwv_flow_imp.id(5717738290619457082)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(5707934855409382687)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(5717761447787962514)
,p_view_id=>wwv_flow_imp.id(5717738290619457082)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(5707934979140382688)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(5717764050590024472)
,p_view_id=>wwv_flow_imp.id(5717738290619457082)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(5707935023210382689)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(5884384521697244472)
,p_name=>'Erweiterte Infos'
,p_region_name=>'rErweiterteInfos'
,p_template=>wwv_flow_imp.id(3414119964980820545)
,p_display_sequence=>145
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Cards--animColorFill:t-Cards--3cols:t-Cards--basic'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select distinct',
'    tt.nummer|| '' ''|| CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN tt.Bezeichnung',
'        ELSE tt.name_eng',
'    END as CARD_TITLE,',
'    --emano_util.fLang(''Antriebsart(en) Vorschrift: '', ''Drive type(s): '') || nvl(av.liste, emano_util.fLang(''<i>keine</i>'', ''<i>none</i>'' )) ||    ''<br />'' ||',
'    emano_util.fLang(''Antriebsart(en): '', ''Drive type(s): '') || nvl(aa2.liste, emano_util.fLang(''<i>keine</i>'', ''<i>none</i>'' )) || ''<br />'' ||',
'    emano_util.fLang(''Cluster: '', ''Cluster: '') ||  kc.liste ||    ''<br />'' ||',
'    emano_util.fLang(''Arbeitskreis(e): '', ''Working group(s): '') || nvl(ak2.liste, emano_util.fLang(''<i>keine</i>'', ''<i>none</i>'' )) as CARD_TEXT,',
'    null as CARD_LINK, null as CARD_SUBTEXT,',
'    v.thema_sortorder',
'from t_thema tt',
'join v_thema_baum v on (tt.themaid = v.themaid)',
'join t_vorschrift_ref_thema vr on (tt.themaid = vr.themaid and vr.geloescht != 1)',
' left outer join t_thema_ref_antriebsart trf on (tt.themaid = trf.themaid)',
'outer apply (',
'    select LISTAGG(CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN aa.bezeichnung ELSE aa.name_eng END, '', '') WITHIN GROUP (ORDER BY CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN aa.bezeichnung ELSE aa.name_eng END) AS liste',
'    from t_thema_ref_antriebsart tra',
'    join t_vorschrift_ref_antriebsart vra on (tra.antriebsartid = vra.antriebsartid and vra.geloescht = 0)',
'    join t_antriebsart aa on (vra.antriebsartid = aa.antriebsartid)',
'    where tra.themaid = tt.themaid and vra.vorschriftid = vr.vorschriftid',
') aa2',
'outer apply (',
'    select LISTAGG(CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ak.bezeichnung ELSE ak.name_eng END || '' '' || ak.kurz, '', '') WITHIN GROUP (ORDER BY ak.kurz) AS liste',
'    from t_thema_ref_et_b_ak tra',
'    join t_vorschrift_ref_et_b_ak vra on (tra.et_b_akid = vra.et_b_akid and vra.geloescht = 0)',
'    join t_et_b_ak ak on (vra.et_b_akid = ak.et_b_akid)',
'    where tra.themaid = tt.themaid and vra.vorschriftid = vr.vorschriftid',
') ak2',
'outer apply (',
'    select listagg(distinct kc.bezeichnung,'', '') within group (order by kc.bezeichnung) liste',
'    from t_thema_ref_cluster trc',
'    join t_konzern_cluster kc on (trc.konzern_clusterid = kc.konzern_clusterid)',
'    where trc.themaid = tt.themaid',
') kc',
'-- Antriebsarten der Vorschrift --> Diese kann sich zum Thema unterscheiden',
'/*outer apply (',
'    select LISTAGG(CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN aa.bezeichnung ELSE aa.name_eng END, '', '') WITHIN GROUP (ORDER BY CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN aa.bezeichnung ELSE aa.name_eng END) AS liste',
'    from t_vorschrift_ref_antriebsart vra',
'    left outer join T_ANTRIEBSART aa on aa.ANTRIEBSARTID = vra.ANTRIEBSARTID',
'    where vra.geloescht = 0 and vra.vorschriftid = :P34_Vorschriftid',
') av*/',
'left  join t_antriebsart aa on (aa.antriebsartid = trf.antriebsartid)',
'left join t_et_b_ak ak on (ak.et_b_akid = tt.et_b_akid)',
'where vr.vorschriftid = :P34_Vorschriftid',
'order by v.thema_sortorder'))
,p_display_when_condition=>'(:P34_ROWID is not null or :P34_Vorschriftid is not null)'
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414129911996820551)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Der Vorschrift sind keine eigenen Themen zugeordnet.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028853873557292688)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>2
,p_column_heading=>'Card Title'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028853497176292688)
,p_query_column_id=>2
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>1
,p_column_heading=>'Card Text'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028853035168292687)
,p_query_column_id=>3
,p_column_alias=>'CARD_LINK'
,p_column_display_sequence=>14
,p_column_heading=>'Card Link'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028852648766292687)
,p_query_column_id=>4
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>3
,p_column_heading=>'Card Subtext'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028852224968292686)
,p_query_column_id=>5
,p_column_alias=>'THEMA_SORTORDER'
,p_column_display_sequence=>4
,p_column_heading=>'Thema Sortorder'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6205588740037282195)
,p_plug_name=>'Ansprechpartner'
,p_region_name=>'rAnsprechpartner'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>105
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'(:P34_ROWID is not null or :P34_VORSCHRIFTID is not null)'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(6205588863463282196)
,p_name=>'REPORT_ANSPRECHPARTNER'
,p_parent_plug_id=>wwv_flow_imp.id(6205588740037282195)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with vko_land as (',
unistr('    -- F\00FCr jeden VKO ermitteln, f\00FCr welche L\00E4nder er zust\00E4ndig ist'),
'    select distinct  arb.benutzerid benutzerid, arb.et_b_akid et_b_akid, nvl(arb.Land_independent,0) land_independent, avrl.landid, arb.lead_vko, ET_B_AK_REF_BENUTZERID',
'    from T_ET_B_AK_REF_BENUTZER arb',
'    left outer join t_et_b_ak_vko_ref_land avrl on (avrl.et_b_ak_vkoid = arb.ET_B_AK_REF_BENUTZERID)',
'), v_land as (',
unistr('    -- L\00E4nder, die der Vorschrift zugeordnet sind'),
'    Select distinct vrtl.vorschriftid vorschriftid, vrtl.landid',
'    from T_VORSCHRIFT_REF_LAND  vrtl',
'    where vrtl.geloescht = 0 and vrtl.vorschriftid = :P34_VORSCHRIFTID_PARENT',
'), vko_themen as (',
'    -- Die zugeordneten Themen der VKOs ermitteln',
'    select arb.benutzerid, arb.et_b_ak_ref_benutzerid, case when avrt.themaid is null then 1 else 0 end as themen_unabhaengig, avrt.themaid',
'    from t_et_b_ak_ref_benutzer arb',
'    left outer join t_et_b_ak_vko_ref_thema avrt on (avrt.et_b_ak_vkoid = arb.et_b_ak_ref_benutzerid)',
'), vko_themen2 as (',
'    -- Die Themen der VKOs mit den Themen der Vorschrift abgleichen',
'    select distinct v1.benutzerid, v1.et_b_ak_ref_benutzerid',
'    from vko_themen v1',
'    join t_vorschrift_ref_thema vrt on (v1.themaid = vrt.themaid or v1.themen_unabhaengig = 1)',
'    where vrt.vorschriftid = nvl(:P34_PARENT_VORSCHRIFTID, :P34_VORSCHRIFTID) and vrt.geloescht = 0',
'),',
'cte_vex as (',
'    select',
'        t1.benutzerid, -- VEX',
'        t3.themaid,',
'        case when t3.themaid is null then 1 else 0 end as thema_alle,',
'        t1.et_b_akid et_b_akid, t1.rolleid rolleid',
'    from t_et_b_ak_ref_thema_benutzer t1',
'    left outer join t_et_b_ak_ref_thema_benutzer_ref_et_b_ak_ref_thema t2 on (t1.et_b_ak_ref_thema_benutzerid = t2.et_b_ak_ref_thema_benutzerid)',
'    left outer join t_thema_ref_et_b_ak t3 on (t2.thema_ref_et_b_akid = t3.thema_ref_et_b_akid)',
')',
'',
'select ',
'    distinct ''VKO'' as TYP, b.Nachname ||'', ''||b.Vorname || '' (''||b.Abteilung || '')'' as Bezeichnung,',
'    CASE WHEN vl.Lead_VKO = 1 THEN emano_util.fLang(''Ja'', ''Yes'') ELSE emano_util.fLang(''Nein'', ''No'')END AS AK_Leiter,',
'    case when (nvl(vl.Land_independent, 0) =1 ) then emano_util.fLang(''Ja'', ''Yes'') ',
'         else (select listagg(tl.B_nummer, '', '') within group (order by tl.B_nummer)  ',
'                from v_land l --t_land l ',
'                join t_land tl on (l.landid = tl.landid)',
'                join t_et_b_ak_vko_ref_land avrl on (avrl.landid = l.landid and avrl.et_b_ak_vkoid = vl.ET_B_AK_REF_BENUTZERID)',
'         ) ',
'    end as Land_independent, b.email E_Mail, ak.bezeichnung Arbeitskreis',
'FROM T_VORSCHRIFT_REF_ET_B_AK vra',
'join t_et_b_ak ak on (vra.et_b_akid = ak.et_b_akid)',
'left outer join v_land l on (vra.vorschriftid = l.vorschriftid)',
'left outer join vko_land vl on (vra.et_b_akid = vl.et_b_akid and (vl.land_independent = 1 or l.landid = vl.landid))',
'--left join vko_themen2 t2 on (t2.benutzerid = vl.benutzerid)',
'left outer join t_benutzer b on (vl.benutzerid = b.benutzerid)',
'where vra.vorschriftid = nvl(:P34_PARENT_VORSCHRIFTID, :P34_VORSCHRIFTID) and vra.geloescht = 0 and vl.benutzerid is not null',
'and vl.benutzerid in (select benutzerid from vko_themen2)',
'',
'',
'  UNION all',
'  /*',
'   select distinct ''Regulierungsverantwortliche'' TYP, v.Nachname ||'', ''||v.Vorname || '' (''||v.Abteilung || '')'' as Bezeichnung,',
'       '''' AK_Leiter, '''' Land_independent, ',
'             '''' E_Mail, '''' Arbeitskreis',
'    FROM T_VORSCHRIFT_REF_verantwortlicher  vrv',
'    join  t_verantwortlicher v on (v.verantwortlicherid = vrv.verantwortlicherid)',
'  WHERE vrv.VORSCHRIFTID = nvl(:P34_PARENT_VORSCHRIFTID, :P34_VORSCHRIFTID)',
'  */',
'',
'  /*',
'listagg(CASE WHEN vrv.IST_HAUPTVERANTWORTLICHER = 10 THEN ',
'  ''<span style="text-decoration: underline;">'' || vv.nachname || '', '' || vv.vorname || ''</span>''',
'  ELSE vv.nachname || '', '' || vv.vorname END, ''; '') WITHIN GROUP (ORDER BY vv.nachname) as verantwortlicher  ',
' */',
'',
'   SELECT DISTINCT ',
'  ''Regulierungsverantwortliche'' AS TYP, ',
'  CASE ',
'    WHEN vrv.IST_HAUPTVERANTWORTLICHER = 10 ',
'    THEN ''<span style="text-decoration: underline;">'' || v.Nachname || '', '' || v.Vorname || ''</span>'' ',
'    ELSE v.Nachname || '', '' || v.Vorname ',
'  END || '' ('' || v.Abteilung || '')'' AS Bezeichnung,',
'  '''' AS AK_Leiter, ',
'  '''' AS Land_independent, ',
'  '''' AS E_Mail, ',
'  '''' AS Arbeitskreis',
'FROM T_VORSCHRIFT_REF_VERANTWORTLICHER vrv',
'JOIN t_verantwortlicher v ON v.verantwortlicherid = vrv.verantwortlicherid',
'WHERE vrv.VORSCHRIFTID = NVL(:P34_PARENT_VORSCHRIFTID, :P34_VORSCHRIFTID)',
'',
'',
'  UNION ALL',
'  ',
'  select distinct --cv.benutzerid',
'    case brr.rolleid when  1002 then ''VEX'' ',
'                      when  1006 then ''FbEx'' ',
'                      else '''' end  TYP, ',
'   b.Nachname ||'', '' || b.Vorname || '' ('' || b.Abteilung || '')'' as Bezeichnung,',
'       '''' as AK_Leiter, '''' as Land_independent,  b.email as E_Mail0,',
'       CASE ',
'           WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ak.bezeichnung ',
'           ELSE ak.name_eng ',
'       END as Arbeitskreis',
'       ',
'from t_vorschrift_ref_et_b_ak vak',
unistr('join t_vorschrift_ref_thema vrt on (vak.vorschriftid = vrt.vorschriftid)    -- alle ak der Vorschrift die mit themen der Vorschriften verkn\00FCpft sind '),
'join cte_vex cv on (vak.et_b_akid = cv.et_b_akid ',
unistr('                    and (vrt.themaid = cv.themaid or cv.thema_alle = 1)) -- zusatzbedingung AK von VEX  mit themen von VEX  OR themenunabh\00E4ngig'),
'join  t_benutzer b on (b.benutzerid = cv.benutzerid and b.Status=10 )  -- active',
'    join T_BENUTZER_REF_ROLLE brr on (brr.benutzerid = b.benutzerid and brr.rolleid in (1002, 1006) and brr.rolleid = cv.rolleid )',
'    join T_ET_B_AK ak on (ak.ET_B_AKID = cv.ET_B_AKID  )',
'where vak.vorschriftid = nvl(:P34_PARENT_VORSCHRIFTID, :P34_VORSCHRIFTID) and vak.geloescht = 0 and vrt.geloescht = 0',
'order by 1,2;',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P34_VORSCHRIFTID_PARENT'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>30
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Keine Ansprechpartner zugeordnet.'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028849660498292682)
,p_query_column_id=>1
,p_column_alias=>'TYP'
,p_column_display_sequence=>1
,p_column_heading=>'Typ'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028849303164292682)
,p_query_column_id=>2
,p_column_alias=>'BEZEICHNUNG'
,p_column_display_sequence=>2
,p_column_heading=>'Bezeichnung'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028848889561292681)
,p_query_column_id=>3
,p_column_alias=>'AK_LEITER'
,p_column_display_sequence=>5
,p_column_heading=>'AK Leiter'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028848500814292681)
,p_query_column_id=>4
,p_column_alias=>'LAND_INDEPENDENT'
,p_column_display_sequence=>3
,p_column_heading=>unistr('L\00E4nderunabh\00E4ngig')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028848099927292680)
,p_query_column_id=>5
,p_column_alias=>'E_MAIL'
,p_column_display_sequence=>6
,p_column_heading=>'E-Mail'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028847630275292680)
,p_query_column_id=>6
,p_column_alias=>'ARBEITSKREIS'
,p_column_display_sequence=>4
,p_column_heading=>'Arbeitskreis'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6447492617794536969)
,p_plug_name=>unistr('Konzernaktivit\00E4ten')
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>115
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'(:P34_ROWID is not null or :P34_VORSCHRIFTID is not null)'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(6447492777168536970)
,p_name=>'Konzern JIRA Tickets'
,p_parent_plug_id=>wwv_flow_imp.id(6447492617794536969)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  TicketNr, ',
'        PCK_RI.fCreateLinkIfUrl("LINK", 250) as Link',
'  from t_Konzern_Jira_ticket kj',
'  join T_KONZERN_JIRA_TICKET_REF_VORSCHRIFT krv on (krv.KONZERN_JIRA_TICKETID = kj.KONZERN_JIRA_TICKETID )',
' WHERE krv.vorschriftid = :P34_VORSCHRIFTID'))
,p_display_when_condition=>'exists (select 1 from T_Benutzer_ref_rolle where rolleid in (1000, 1003, 1002) and benutzerid = pck_ri.fgetUserId);'
,p_display_when_cond2=>'SQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Keine Tickets zugeordnet'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028846671965292678)
,p_query_column_id=>1
,p_column_alias=>'TICKETNR'
,p_column_display_sequence=>1
,p_column_heading=>'Ticketnummer'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028846306172292678)
,p_query_column_id=>2
,p_column_alias=>'LINK'
,p_column_display_sequence=>2
,p_column_heading=>'Link'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6984700939625258899)
,p_plug_name=>'Funktionen FuKa (System42)'
,p_region_name=>'rFunktionen'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>155
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'(:P34_ROWID is not null or :P34_Vorschriftid is not null)'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(6984701086671258900)
,p_name=>'Funktionen Tabelle'
,p_parent_plug_id=>wwv_flow_imp.id(6984700939625258899)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  case when f.status = emano_util.fLang(''veraltet'', ''outdated'') then',
'              ''<span style="color:darkred;">'' ||f.bezeichnung || ''</span>''',
'           when f.status = emano_util.fLang(''in Bearbeitung'', ''in progress'') then',
'             ''<span style="color:darkorange;">'' ||f.bezeichnung || ''</span>''',
'           else f.bezeichnung',
'           end "BEZEICHNUNG",',
'         f.beschreibung, f.objekttyp,',
'    --    vrf.LETZTE_AENDERUNG_DATUM, ',
'    case when :FSP_LANGUAGE_PREFERENCE = ''de'' then to_char(vrf.LETZTE_AENDERUNG_DATUM, ''DD.MM.YYYY HH24:MI'') else to_char(vrf.LETZTE_AENDERUNG_DATUM, ''MM/DD/YYYY HH24:MI'') end LETZTE_AENDERUNG_DATUM,',
'        f.status,',
'       nvl2(vrf.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) as LETZTE_AENDERUNG_BENUTZERID,',
'       f.id_aus_excel',
'from T_VORSCHRIFT_REF_FUNKTION vrf',
'inner join t_funktion f on (f.funktionid = vrf.funktionid)',
'left outer join t_benutzer b on (b.benutzerid = vrf.LETZTE_AENDERUNG_BENUTZERID)',
'where vrf.vorschriftid = :P34_VORSCHRIFTID',
'and vrf.geloescht = 0'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'Keine Funktionen zugeordnet.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028844474008292675)
,p_query_column_id=>1
,p_column_alias=>'BEZEICHNUNG'
,p_column_display_sequence=>1
,p_column_heading=>'Bezeichnung'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028844098342292675)
,p_query_column_id=>2
,p_column_alias=>'BESCHREIBUNG'
,p_column_display_sequence=>3
,p_column_heading=>'Beschreibung'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028843670610292674)
,p_query_column_id=>3
,p_column_alias=>'OBJEKTTYP'
,p_column_display_sequence=>5
,p_column_heading=>'Objekttyp'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028843311363292674)
,p_query_column_id=>4
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>6
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028842880464292674)
,p_query_column_id=>5
,p_column_alias=>'STATUS'
,p_column_display_sequence=>4
,p_column_heading=>'Status'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028842420496292674)
,p_query_column_id=>6
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZERID'
,p_column_display_sequence=>7
,p_column_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028842051863292674)
,p_query_column_id=>7
,p_column_alias=>'ID_AUS_EXCEL'
,p_column_display_sequence=>2
,p_column_heading=>'ID Function42'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9412247026821870581)
,p_plug_name=>'Kerndaten'
,p_region_name=>'rKerndaten'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--PCK_RI.fIsAuthorized(pck_ri.fGetUserid,25,200) = false',
'false'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9413676743982265743)
,p_plug_name=>unistr('Verkn\00FCpfte Vorschriften')
,p_region_name=>'rVerknuepfungen'
,p_region_template_options=>'#DEFAULT#:is-expanded:i-h480:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>65
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'( ( (:P34_ROWID is not null or :P34_Vorschriftid is not null)',
'     and :P34_VORSCHRIFT_TYPID <> 20 ',
'  )',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
')'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1030054015916286890)
,p_plug_name=>'REPORT_VERKNUEPFUNGEN IR - lastworijng code '
,p_parent_plug_id=>wwv_flow_imp.id(9413676743982265743)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ctl_b_nummern AS (',
'    SELECT vorschriftid, LISTAGG(b_nummer, '', '') WITHIN GROUP (ORDER BY b_nummer) AS b_nummern',
'    FROM (',
'        SELECT DISTINCT vrtrl.vorschriftid, l.b_nummer',
'        FROM t_vorschrift_ref_land vrtrl',
'        JOIN t_land l ON l.landid = vrtrl.landid',
'        WHERE vrtrl.geloescht = 0',
'    )',
'    GROUP BY vorschriftid',
')',
'SELECT',
'    vrv.rowid AS xrowid,',
'    vrv.rowid AS checkbox,',
'',
'',
unistr('    -- Vorg\00E4nger (Predecessor) - Display number and links only'),
'    CASE WHEN vv.vorschriftid != :P34_VORSCHRIFTID THEN',
'        ''<a href="'' ||',
'            apex_page.get_url(p_page => 34, p_items => ''P34_VORSCHRIFTID'', p_values => vv.vorschriftid, p_clear_cache => 34)',
'            || ''" target="_blank"><span alt="Anzeigen" title="Anzeigen" class="fa fa-search"></span></a> '' ||',
'        ''<a href="'' ||',
'            apex_page.get_url(p_page => 300, p_items => ''P300_VORSCHRIFTID'', p_values => vv.vorschriftid, p_clear_cache => 300)',
unistr('            || ''" target="_blank"><span alt="Vernetzungsansicht \00F6ffnen" title="Vernetzungsansicht \00F6ffnen" class="fa fa-network-hub"></span></a> '''),
'    END || vv.vorschrift_nummer AS vorgaenger_vorschrift_nr, -- Renamed, Title removed',
'    vv.dokumentendatum AS vv_doku_datum, -- Added Document Date',
'',
'    -- Nachfolger (Successor) - Display number and links only',
'    CASE WHEN nv.vorschriftid != :P34_VORSCHRIFTID THEN',
'        ''<a href="'' ||',
'            apex_page.get_url(p_page => 34, p_items => ''P34_VORSCHRIFTID'', p_values => nv.vorschriftid, p_clear_cache => 34)',
'            || ''" target="_blank"><span alt="Anzeigen" title="Anzeigen" class="fa fa-search"></span></a> '' ||',
'        ''<a href="'' ||',
'            apex_page.get_url(p_page => 300, p_items => ''P300_VORSCHRIFTID'', p_values => nv.vorschriftid, p_clear_cache => 300) -- Changed vv.vorschriftid to nv.vorschriftid',
unistr('            || ''" target="_blank"><span alt="Vernetzungsansicht \00F6ffnen" title="Vernetzungsansicht \00F6ffnen" class="fa fa-network-hub"></span></a> '''),
'    END || nv.vorschrift_nummer AS nachfolger_vorschrift_nr, -- Renamed, Title removed',
'    nv.dokumentendatum AS nv_doku_datum, -- Added Document Date',
'',
'    -- Other columns',
'    vrv.beziehung_art,',
'    (SELECT vret.einsatzdatum -- Selecting specific date type 1000 ''In Kraft'' from the *other* regulation in the link',
'        FROM t_vorschrift_ref_einsatzdatum_typ vret',
'        WHERE vret.vorschriftid = CASE WHEN vrv.vorgaenger_vorschriftid = :P34_VORSCHRIFTID THEN vrv.nachfolger_vorschriftid ELSE vrv.vorgaenger_vorschriftid END',
'          AND vret.einsatzdatum_typid = 1000',
'    ) AS datum_in_kraft_verlinkt, -- Renamed',
'    vrv.datum_neue_typen,',
'    vrv.datum_alle_typen,',
'    -- vrv.homologation_serie,',
'    CASE vrv.homologation_serie',
'        WHEN 10 THEN ''Ja''',
'        WHEN 0 THEN ''Nein''',
'        ELSE NULL',
'    END AS homologation_serie_display,',
'',
'    vrv.kommentar,',
'    vrv.kommentar_englisch,',
'    CASE',
unistr('        WHEN (vrv.beziehung_art = 40 AND vv.vorschriftid != :P34_VORSCHRIFTID AND vv.vorschrift_typid = 30) THEN -- L\00E4nder einer RR (predecessor)'),
'             (SELECT bn.b_nummern FROM ctl_b_nummern bn WHERE bn.vorschriftid = vv.vorschriftid)',
unistr('        WHEN (vrv.beziehung_art = 40 AND nv.vorschriftid != :P34_VORSCHRIFTID AND nv.vorschrift_typid = 30) OR -- L\00E4nder einer RR (successor)'),
unistr('             (vrv.beziehung_art = 102 AND nv.vorschrift_typid = 10) THEN -- L\00E4nder einer gleichwertigen Vorschrift (successor)'),
'             (SELECT bn.b_nummern FROM ctl_b_nummern bn WHERE bn.vorschriftid = nv.vorschriftid)',
'        ELSE NULL -- Added ELSE NULL',
'    END AS b_nummern,',
'    vrv.letzte_aenderung_datum,',
'    mref.vorschrift_nummer AS max_ref,',
'    -- b.nachname || '', '' || b.vorname AS letzte_aenderung_benutzer',
'    nvl2(vrv.letzte_aenderung_benutzerid,',
'    CASE ',
'        WHEN b.nachname IS NOT NULL AND b.vorname IS NOT NULL ',
'        THEN b.nachname || '', '' || b.vorname',
'        WHEN b.nachname IS NOT NULL AND b.vorname IS NULL ',
'        THEN b.nachname',
'        WHEN b.nachname IS NULL AND b.vorname IS NOT NULL ',
'        THEN b.vorname',
'        ELSE NULL',
'    END,',
'    null) AS letzte_aenderung_benutzer',
'FROM',
'    t_vorschrift_ref_vorschrift vrv',
'LEFT OUTER JOIN t_benutzer b ON b.benutzerid = vrv.letzte_aenderung_benutzerid',
'JOIN t_vorschrift vv ON vv.vorschriftid = vrv.vorgaenger_vorschriftid',
'JOIN t_vorschrift nv ON nv.vorschriftid = vrv.nachfolger_vorschriftid',
'LEFT OUTER JOIN t_vorschrift mref ON vrv.max_homologation_vorschriftid = mref.vorschriftid',
'WHERE',
'    (vrv.vorgaenger_vorschriftid = :P34_VORSCHRIFTID AND vrv.beziehung_art != 20) -- Exclude Amendments (Type 20)',
'    OR vrv.nachfolger_vorschriftid = :P34_VORSCHRIFTID',
'    AND (vrv.beziehung_art NOT IN (30)) -- Exclude Supplements (Type 30)',
'-- ORDER BY 1'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P34_VORSCHRIFTID'
,p_plug_display_condition_type=>'NEVER'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>' (:P34_STRG_GETEX_ANZEIGE = 20 and nvl(:P34_EDIT_MODE, 0) = 1)'
,p_plug_read_only_when2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'REPORT_VERKNUEPFUNGEN IR - lastworijng code '
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1030053961623286889)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>2642158354276101346
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1030053913068286888)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'<input type="checkbox" value="all" />'
,p_column_html_expression=>'<input type="checkbox" value="#XROWID#" />'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1030053747648286887)
,p_db_column_name=>'XROWID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.:45:P45_ROWID,P45_MASTER:#XROWID#,&P34_STRG_GETEX_ANZEIGE.'
,p_column_linktext=>'<span class="fa fa-pencil" alt="Bearbeiten" title="Bearbeiten"></span>'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_column_alignment=>'CENTER'
,p_rpt_show_filter_lov=>'N'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 45,',
'                      accessMode => 200))'))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1030053685421286886)
,p_db_column_name=>'NACHFOLGER_VORSCHRIFT_NR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Verlinkte Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1030053608255286885)
,p_db_column_name=>'NV_DOKU_DATUM'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Verlinkte Vorschrift Doku Datum'
,p_column_type=>'DATE'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1027688002299552934)
,p_db_column_name=>'BEZIEHUNG_ART'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Art der Beziehung'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(2655378917409322525)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1027687845388552933)
,p_db_column_name=>'VORGAENGER_VORSCHRIFT_NR'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1027687716880552932)
,p_db_column_name=>'VV_DOKU_DATUM'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Vorschrift Doku Datum'
,p_column_type=>'DATE'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1027687651072552931)
,p_db_column_name=>'DATUM_IN_KRAFT_VERLINKT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('In Kraftsetzung aus verkn\00FCpfter Vorschrift')
,p_column_type=>'DATE'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1027687606699552930)
,p_db_column_name=>'DATUM_NEUE_TYPEN'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Einsatztermin neue Typen'
,p_column_type=>'DATE'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1027687491755552929)
,p_db_column_name=>'DATUM_ALLE_TYPEN'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Einsatztermin alle Fahrzeuge'
,p_column_type=>'DATE'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1027687326210552928)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1027687300390552927)
,p_db_column_name=>'B_NUMMERN'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>unistr('L\00E4nder')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1027687171892552926)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1027687085647552925)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1027686987672552924)
,p_db_column_name=>'HOMOLOGATION_SERIE_DISPLAY'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>unistr('Homologation mit h\00F6herer Serie m\00F6glich')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1027686842113552923)
,p_db_column_name=>'MAX_REF'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Maximale Homologationsvorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1027686723660552922)
,p_db_column_name=>'KOMMENTAR_ENGLISCH'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Kommentar Englisch'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(494103106877030562)
,p_plug_name=>'REPORT_VERKNUEPFUNGEN IR'
,p_region_name=>'report-verknuepfungen'
,p_parent_plug_id=>wwv_flow_imp.id(9413676743982265743)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ctl_b_nummern AS (',
'    SELECT vorschriftid, LISTAGG(b_nummer, '', '') WITHIN GROUP (ORDER BY b_nummer) AS b_nummern',
'    FROM (',
'        SELECT DISTINCT vrtrl.vorschriftid, l.b_nummer',
'        FROM t_vorschrift_ref_land vrtrl',
'        JOIN t_land l ON l.landid = vrtrl.landid',
'        WHERE vrtrl.geloescht = 0',
'    )',
'    GROUP BY vorschriftid',
')',
'SELECT',
'    vrv.rowid AS xrowid,',
'    vrv.rowid AS checkbox,',
'',
unistr('    -- Vorg\00E4nger (Predecessor) - Link + Number + Conditional Date'),
'    CASE WHEN vv.vorschriftid != :P34_VORSCHRIFTID THEN',
'        ''<a href="'' ||',
'            apex_page.get_url(p_page => 34, p_items => ''P34_VORSCHRIFTID'', p_values => vv.vorschriftid, p_clear_cache => 34) ',
'            || ''" target="_blank"><span alt="Anzeigen" title="Anzeigen" class="fa fa-search"></span></a> '' ||',
'        ''<a href="'' ||',
'            apex_page.get_url(p_page => 300, p_items => ''P300_VORSCHRIFTID'', p_values => vv.vorschriftid, p_clear_cache => 300)',
unistr('            || ''" target="_blank"><span alt="Vernetzungsansicht \00F6ffnen" title="Vernetzungsansicht \00F6ffnen" class="fa fa-network-hub"></span></a> '''),
'    END ||',
'    vv.vorschrift_nummer || -- Number',
'    case -- Conditional Date Display based on P34_ERW_LAND_ANZEIGE',
'      when (vv.dokumentendatum is not null and :P34_ERW_LAND_ANZEIGE = ''Ja'')',
'      then '' - '' || TO_CHAR(vv.dokumentendatum, ''DD.MM.YYYY'') -- Added formatting',
'      else '''' -- Display only number if condition not met or date is null',
'    end',
'    AS vorgaenger_vorschrift,',
'',
'    -- Nachfolger (Successor) - Link + Number + Conditional Date',
'    CASE WHEN nv.vorschriftid != :P34_VORSCHRIFTID THEN',
'        ''<a href="'' ||',
'            apex_page.get_url(p_page => 34, p_items => ''P34_VORSCHRIFTID'', p_values => nv.vorschriftid, p_clear_cache => 34) ',
'            || ''" target="_blank"><span alt="Anzeigen" title="Anzeigen" class="fa fa-search"></span></a> '' ||',
'        ''<a href="'' ||',
'            apex_page.get_url(p_page => 300, p_items => ''P300_VORSCHRIFTID'', p_values => nv.vorschriftid, p_clear_cache => 300)',
unistr('            || ''" target="_blank"><span alt="Vernetzungsansicht \00F6ffnen" title="Vernetzungsansicht \00F6ffnen" class="fa fa-network-hub"></span></a> '''),
'    END ||',
'    nv.vorschrift_nummer || -- Number',
'    case -- Conditional Date Display based on P34_ERW_LAND_ANZEIGE',
'      when (nv.dokumentendatum is not null and :P34_ERW_LAND_ANZEIGE = ''Ja'')',
'      then '' - '' || TO_CHAR(nv.dokumentendatum, ''DD.MM.YYYY'') -- Added formatting',
'      else '''' -- Display only number if condition not met or date is null',
'    end',
'    AS nachfolger_vorschrift,',
'',
'    vrv.beziehung_art,',
'    (SELECT vret.einsatzdatum',
'        FROM t_vorschrift_ref_einsatzdatum_typ vret',
'        WHERE vret.vorschriftid = CASE WHEN vrv.vorgaenger_vorschriftid = :P34_VORSCHRIFTID THEN vrv.nachfolger_vorschriftid ELSE vrv.vorgaenger_vorschriftid END',
'          AND vret.einsatzdatum_typid = 1000',
'    ) AS datum_in_kraft_verlinkt,',
'    vrv.datum_neue_typen,',
'    vrv.datum_alle_typen,',
'    CASE vrv.homologation_serie',
'        WHEN 10 THEN ''Ja''',
'        WHEN 0 THEN ''Nein''',
'        ELSE NULL',
'    END AS homologation_serie_display,',
'    vrv.kommentar,',
'    vrv.kommentar_englisch,',
'    CASE',
'        WHEN (vrv.beziehung_art = 40 AND vv.vorschriftid != :P34_VORSCHRIFTID AND vv.vorschrift_typid = 30) THEN',
'             (SELECT bn.b_nummern FROM ctl_b_nummern bn WHERE bn.vorschriftid = vv.vorschriftid)',
'        WHEN (vrv.beziehung_art = 40 AND nv.vorschriftid != :P34_VORSCHRIFTID AND nv.vorschrift_typid = 30) OR',
'             (vrv.beziehung_art = 102 AND nv.vorschrift_typid = 10) THEN',
'             (SELECT bn.b_nummern FROM ctl_b_nummern bn WHERE bn.vorschriftid = nv.vorschriftid)',
'        ELSE NULL',
'    END AS b_nummern,',
'    vrv.letzte_aenderung_datum,',
'    mref.vorschrift_nummer AS max_ref,',
'    nvl2(vrv.letzte_aenderung_benutzerid,',
'    CASE',
'        WHEN b.nachname IS NOT NULL AND b.vorname IS NOT NULL',
'        THEN b.nachname || '', '' || b.vorname',
'        WHEN b.nachname IS NOT NULL AND b.vorname IS NULL',
'        THEN b.nachname',
'        WHEN b.nachname IS NULL AND b.vorname IS NOT NULL',
'        THEN b.vorname',
'        ELSE NULL',
'    END,',
'    null) AS letzte_aenderung_benutzer',
'FROM',
'    t_vorschrift_ref_vorschrift vrv',
'LEFT OUTER JOIN t_benutzer b ON b.benutzerid = vrv.letzte_aenderung_benutzerid',
'JOIN t_vorschrift vv ON vv.vorschriftid = vrv.vorgaenger_vorschriftid',
'JOIN t_vorschrift nv ON nv.vorschriftid = vrv.nachfolger_vorschriftid',
'LEFT OUTER JOIN t_vorschrift mref ON vrv.max_homologation_vorschriftid = mref.vorschriftid',
'WHERE',
'    (vrv.vorgaenger_vorschriftid = :P34_VORSCHRIFTID AND vrv.beziehung_art != 20) -- Exclude Amendments (Type 20)',
'    OR vrv.nachfolger_vorschriftid = :P34_VORSCHRIFTID',
'    AND (vrv.beziehung_art NOT IN (30)) -- Exclude Supplements (Type 30)',
'ORDER BY 1'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P34_VORSCHRIFTID,P34_ERW_LAND_ANZEIGE'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>' (:P34_STRG_GETEX_ANZEIGE = 20 and nvl(:P34_EDIT_MODE, 0) = 1)'
,p_plug_read_only_when2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'REPORT_VERKNUEPFUNGEN IR'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1612905818400740046)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>5285118134300128281
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1030056489802286914)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>10
,p_column_identifier=>'Q'
,p_column_label=>'<input type="checkbox" value="all" />'
,p_column_html_expression=>'<input type="checkbox" value="#XROWID#" />'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1028939999048292831)
,p_db_column_name=>'XROWID'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.:45:P45_ROWID,P45_MASTER:#XROWID#,&P34_STRG_GETEX_ANZEIGE.'
,p_column_linktext=>'<span class="fa fa-pencil" alt="Bearbeiten" title="Bearbeiten"></span>'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_column_alignment=>'CENTER'
,p_rpt_show_filter_lov=>'N'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 45,',
'                      accessMode => 200))'))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1028937940086292827)
,p_db_column_name=>'BEZIEHUNG_ART'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Art der Beziehung'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(2655378917409322525)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1028937543912292826)
,p_db_column_name=>'DATUM_IN_KRAFT_VERLINKT'
,p_display_order=>100
,p_column_identifier=>'G'
,p_column_label=>unistr('In Kraftsetzung aus verkn\00FCpfter Vorschrift')
,p_column_type=>'DATE'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1028937139174292825)
,p_db_column_name=>'DATUM_NEUE_TYPEN'
,p_display_order=>110
,p_column_identifier=>'H'
,p_column_label=>'Einsatztermin neue Typen'
,p_column_type=>'DATE'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1028936760296292825)
,p_db_column_name=>'DATUM_ALLE_TYPEN'
,p_display_order=>120
,p_column_identifier=>'I'
,p_column_label=>'Einsatztermin alle Fahrzeuge'
,p_column_type=>'DATE'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1028936386169292825)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>130
,p_column_identifier=>'J'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1028935576638292824)
,p_db_column_name=>'B_NUMMERN'
,p_display_order=>140
,p_column_identifier=>'L'
,p_column_label=>unistr('L\00E4nder')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1028935135165292823)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>150
,p_column_identifier=>'M'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1028934393651292823)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>160
,p_column_identifier=>'O'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1028933931136292822)
,p_db_column_name=>'HOMOLOGATION_SERIE_DISPLAY'
,p_display_order=>170
,p_column_identifier=>'P'
,p_column_label=>unistr('Homologation mit h\00F6herer Serie m\00F6glich')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1028934769826292823)
,p_db_column_name=>'MAX_REF'
,p_display_order=>180
,p_column_identifier=>'N'
,p_column_label=>'Maximale Homologationsvorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1028935925602292824)
,p_db_column_name=>'KOMMENTAR_ENGLISCH'
,p_display_order=>190
,p_column_identifier=>'K'
,p_column_label=>'Kommentar Englisch'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1027686692994552921)
,p_db_column_name=>'VORGAENGER_VORSCHRIFT'
,p_display_order=>200
,p_column_identifier=>'R'
,p_column_label=>'Vorgaenger Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1027686528026552920)
,p_db_column_name=>'NACHFOLGER_VORSCHRIFT'
,p_display_order=>210
,p_column_identifier=>'S'
,p_column_label=>'Nachfolger Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1613002897403835821)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'26421820'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'XROWID:NACHFOLGER_VORSCHRIFT:VORGAENGER_VORSCHRIFT:BEZIEHUNG_ART:DATUM_IN_KRAFT_VERLINKT:DATUM_NEUE_TYPEN:DATUM_ALLE_TYPEN:KOMMENTAR:B_NUMMERN:LETZTE_AENDERUNG_DATUM:LETZTE_AENDERUNG_BENUTZER:HOMOLOGATION_SERIE_DISPLAY:MAX_REF:KOMMENTAR_ENGLISCH:'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(9413676815357265744)
,p_name=>'REPORT_VERKNUEPFUNGEN CR'
,p_region_name=>'report-verknuepfungen'
,p_parent_plug_id=>wwv_flow_imp.id(9413676743982265743)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ctl_b_nummern as (',
'    select vorschriftid, listagg(b_nummer, '', '') within group (order by b_nummer) as b_nummern',
'    from (',
'        select distinct vrtrl.vorschriftid, l.b_nummer',
'        from t_vorschrift_ref_land vrtrl ',
'        join t_land l on l.landid = vrtrl.landid',
'        where vrtrl.geloescht = 0)',
'    group by vorschriftid',
')',
'select vrv.rowid as xrowid,',
'    case when vv.vorschriftid != :P34_VORSCHRIFTID then',
'        ''<a href="'' ||',
'            apex_page.get_url(p_page => 25, p_items => ''P34_VORSCHRIFTID'', p_values => vv.vorschriftid, p_clear_cache => 25)',
'            || ''" target="_blank"><span alt="Anzeigen" title="Anzeigen" class="fa fa-search"></span></a> '' ||',
'            ''<a href="'' ||',
'            apex_page.get_url(p_page => 300, p_items => ''P300_VORSCHRIFTID'', p_values => vv.vorschriftid, p_clear_cache => 300)',
unistr('            || ''" target="_blank"><span alt="Vernetzungsansicht \00F6ffnen" title="Vernetzungsansicht \00F6ffnen" class="fa fa-network-hub"></span></a> '''),
'    end || vv.vorschrift_nummer || '' - '' || vv.vorschrift_bezeichnung as vorgaenger_vorschrift,',
'    ',
'    case when nv.vorschriftid != :P34_VORSCHRIFTID then',
'        ''<a href="'' ||',
'            apex_page.get_url(p_page => 25, p_items => ''P34_VORSCHRIFTID'', p_values => nv.vorschriftid, p_clear_cache => 25)',
'            || ''" target="_blank"><span alt="Anzeigen" title="Anzeigen" class="fa fa-search"></span></a> '' ||',
'            ''<a href="'' ||',
'            apex_page.get_url(p_page => 300, p_items => ''P300_VORSCHRIFTID'', p_values => vv.vorschriftid, p_clear_cache => 300)',
unistr('            || ''" target="_blank"><span alt="Vernetzungsansicht \00F6ffnen" title="Vernetzungsansicht \00F6ffnen" class="fa fa-network-hub"></span></a> '''),
'    end || nv.vorschrift_nummer || '' - '' || nv.vorschrift_bezeichnung as nachfolger_vorschrift,',
'',
'    vrv.beziehung_art,',
'    vret.einsatzdatum as DATUM_IN_KRAFT,',
'    vrv.DATUM_NEUE_TYPEN,',
'    vrv.DATUM_ALLE_TYPEN,',
'        vrv.homologation_serie,',
'    vrv.kommentar,',
'    vrv.KOMMENTAR_ENGLISCH,',
'    case when ',
unistr('      (vrv.beziehung_art = 40 and vv.vorschriftid != :P34_VORSCHRIFTID and vv.vorschrift_typid = 30) -- Anzeige der L\00E4nder einer RR'),
unistr('      /*or (vrv.beziehung_art = 102 and vv.vorschriftid != :P34_VORSCHRIFTID and vv.vorschrift_typid = 10)*/ -- Anzeige der L\00E4nder einer gleichwertigen Vorschrift'),
'      then',
'            (select bn.b_nummern ',
'            from ctl_b_nummern bn',
'            where bn.vorschriftid = vv.vorschriftid)',
'      when      ',
unistr('      (vrv.beziehung_art = 40 and nv.vorschriftid != :P34_VORSCHRIFTID and nv.vorschrift_typid = 30) -- Anzeige der L\00E4nder einer RR'),
unistr('      or (vrv.beziehung_art = 102 and nv.vorschrift_typid = 10) -- Anzeige der L\00E4nder einer gleichwertigen Vorschrift            '),
'        then',
'            (select bn.b_nummern ',
'            from ctl_b_nummern bn',
'            where bn.vorschriftid = nv.vorschriftid)',
'      end as B_NUMMERN,',
'    vrv.letzte_aenderung_datum,',
'    mref.vorschrift_nummer as Max_Ref,',
'    b.nachname || '', '' || b.vorname',
'from t_vorschrift_ref_vorschrift vrv',
'left outer join t_benutzer b on b.benutzerid = vrv.letzte_aenderung_benutzerid',
'join t_vorschrift vv on vv.vorschriftid = vrv.vorgaenger_vorschriftid',
'join t_vorschrift nv on nv.vorschriftid = vrv.nachfolger_vorschriftid',
'left outer join t_vorschrift mref on (vrv.max_homologation_vorschriftid = mref.vorschriftid)',
'left outer join t_vorschrift_ref_einsatzdatum_typ vret on (',
'    vret.vorschriftid = case when vrv.vorgaenger_vorschriftid = :P34_VORSCHRIFTID then vrv.nachfolger_vorschriftid else vrv.vorgaenger_vorschriftid end',
'    and /*vrv.beziehung_art = 40 and*/ vret.einsatzdatum_typid = 1000',
')',
'where ( vrv.vorgaenger_vorschriftid = :P34_VORSCHRIFTID and vrv.BEZIEHUNG_ART != 20  -- Amendments von Vorschr nicht hier, sondern in Amendments-Report',
'       or vrv.nachfolger_vorschriftid = :P34_VORSCHRIFTID )',
unistr('    -- Beziehung ist nicht Supplement     --  verkn zu typ  ''UN-R xx/xx Supplement'' anzeigen, wenn andere verkn\00FCpf art, z. b. equivalent , linked, T.1449 '),
'     and (vrv.BEZIEHUNG_ART NOT IN ( 30)  )  ',
'    ',
'order by 1'))
,p_display_condition_type=>'NEVER'
,p_read_only_when_type=>'EXPRESSION'
,p_read_only_when=>' (:P34_STRG_GETEX_ANZEIGE = 20 and nvl(:P34_EDIT_MODE, 0) = 1)'
,p_read_only_when2=>'PLSQL'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P34_VORSCHRIFTID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>unistr('Noch keine Verkn\00FCpfungen vorhanden.')
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028932967616292798)
,p_query_column_id=>1
,p_column_alias=>'XROWID'
,p_column_display_sequence=>2
,p_column_heading=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.:45:P45_ROWID,P45_MASTER:#XROWID#,&P34_STRG_GETEX_ANZEIGE.'
,p_column_linktext=>'<span class="fa fa-pencil" alt="Bearbeiten" title="Bearbeiten"></span>'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 45,',
'                      accessMode => 200))'))
,p_display_when_condition2=>'PLSQL'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028932534486292798)
,p_query_column_id=>2
,p_column_alias=>'VORGAENGER_VORSCHRIFT'
,p_column_display_sequence=>5
,p_column_heading=>'Vorschrift'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028932195172292797)
,p_query_column_id=>3
,p_column_alias=>'NACHFOLGER_VORSCHRIFT'
,p_column_display_sequence=>3
,p_column_heading=>'Verlinkte Vorschrift'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028931746731292797)
,p_query_column_id=>4
,p_column_alias=>'BEZIEHUNG_ART'
,p_column_display_sequence=>4
,p_column_heading=>'Art der Beziehung'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(2655378917409322525)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028931319523292796)
,p_query_column_id=>5
,p_column_alias=>'DATUM_IN_KRAFT'
,p_column_display_sequence=>6
,p_column_heading=>unistr('In Kraftsetzung aus verkn\00FCpfter Vorschrift')
,p_column_format=>'DD.MM.YYYY'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028930982380292796)
,p_query_column_id=>6
,p_column_alias=>'DATUM_NEUE_TYPEN'
,p_column_display_sequence=>7
,p_column_heading=>'Einsatztermin neue Typen'
,p_column_format=>'DD.MM.YYYY'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028930530060292795)
,p_query_column_id=>7
,p_column_alias=>'DATUM_ALLE_TYPEN'
,p_column_display_sequence=>8
,p_column_heading=>'Einsatztermin alle Fahrzeuge'
,p_column_format=>'DD.MM.YYYY'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028930192696292794)
,p_query_column_id=>8
,p_column_alias=>'HOMOLOGATION_SERIE'
,p_column_display_sequence=>13
,p_column_heading=>unistr('Homologation mit h\00F6herer Serie m\00F6glich')
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'  ',
') ',
'ORDER BY sort_order;',
''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028929777931292793)
,p_query_column_id=>9
,p_column_alias=>'KOMMENTAR'
,p_column_display_sequence=>9
,p_column_heading=>'Kommentar'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028929365775292792)
,p_query_column_id=>10
,p_column_alias=>'KOMMENTAR_ENGLISCH'
,p_column_display_sequence=>24
,p_column_heading=>'Kommentar Englisch'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028928983557292792)
,p_query_column_id=>11
,p_column_alias=>'B_NUMMERN'
,p_column_display_sequence=>10
,p_column_heading=>unistr('L\00E4nder')
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028928541441292792)
,p_query_column_id=>12
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>11
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_column_format=>'DD.MM.YYYY HH24:MI'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028928131228292790)
,p_query_column_id=>13
,p_column_alias=>'MAX_REF'
,p_column_display_sequence=>14
,p_column_heading=>'Maximale Homologationsvorschrift'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028927785404292790)
,p_query_column_id=>14
,p_column_alias=>'B.NACHNAME||'',''||B.VORNAME'
,p_column_display_sequence=>12
,p_column_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028927347326292790)
,p_query_column_id=>14
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>1
,p_column_heading=>'<input type="checkbox" value="all" />'
,p_column_html_expression=>'<input type="checkbox" value="#XROWID#" />'
,p_heading_alignment=>'LEFT'
,p_report_column_required_role=>wwv_flow_imp.id(756418224517528353)
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9419691149654807307)
,p_plug_name=>'MfVs'
,p_region_name=>'rMfVs'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>125
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'((:P34_ROWID is not null or :P34_Vorschriftid is not null)',
'--  and :P34_VORSCHRIFT_TYPID <> 20',
')'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1554232699486963102)
,p_name=>'MfV -  Interpretation'
,p_region_name=>'p34_mfv_report_interpretation'
,p_parent_plug_id=>wwv_flow_imp.id(9419691149654807307)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:margin-bottom-sm'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ex as (  select i.mfvid as mfvid, ',
'    listagg(a.kurz,'', '') within group (order by a.kurz) as ak_liste',
'    from t_mfv_ref_et_b_ak i',
'    join t_et_b_ak a on (i.et_b_akid = a.et_b_akid) group by i.mfvid',
' ),',
'teil as ( select listagg( t.teil || ''. ''||t.bezeichnung, '', '') within group (order by t.teil || ''. ''||t.bezeichnung) as teil_bez_list,',
'                                 mrt.mfvid mfvid',
'                from t_mfv_ref_mfv_teil mrt',
'                join t_mfv_teil t on (t.mfv_teilID = mrt.mfv_teilid)',
'                 group by mrt.mfvid',
' ) ',
'  ',
'select DISTINCT m.rowid as Interpretation_row_id, ',
' m.MFVID as row_key,  -- Using MFVID instead of rowid',
'       case when ( (:P34_EDIT_MODE is not null and :P34_EDIT_MODE = 1 ) ',
'                       and  m.DMS_DOKUMENTENSTATUS != 30  ',
'                   and nvl(m.GUELTIGKEITSDATUM, sysdate) < sysdate ) ',
'              then',
unistr('                    ''<span style="cursor:pointer;" text-align:center;" class="setzegueltigkeit fa fa-check" data-id="'' || m.mfvid || ''"><small><br>'' || emano_util.fLang(''G\00FCltigkeit'', ''Validity'') || ''<br>'' || emano_util.fLang(''best\00E4tigen'', ''confirm'') ')
||'|| ''<small></span>'' ',
'                else',
'                    ''#'' end as link,',
'       m.MFVID,',
'       m.mfv_name,',
'       teil.teil_bez_list AS "MFV_TEIL",',
'       case when length(m.mfv_thema ) > 64 then substr(m.mfv_thema,0,64)||''...'' else m.mfv_thema  end as mfv_thema,',
'       SCHLAGWORTE,',
'       VORSCHRIFTENVERANTWORTLICHER AS "VORSCHRIFTENVERANTWORTLICHER",',
'       ex.ak_liste  as Arbeitskreis_liste,',
'       BETEILIGTE_OES,',
'       PCK_RI.fCreateLinkIfUrl("LINK_MFV_DMS") AS "LINK_MFV_DMS",',
'       case when (m.JIRA_Status is null or m.JIRA_Status=0) then ',
'                                                            emano_util.fLang(''offen'', ''open'') ',
'                                                        when (m.JIRA_Status =10) then ',
'                                                            emano_util.fLang(''geschlossen'', ''closed'') ',
'                                                        when (m.JIRA_Status =20) then    ',
'                                                        emano_util.fLang(''ohne MfV beendet'', ''closed without notification'')  ',
'                                                        else ',
'                                                            emano_util.fLang(''offen'', ''open'') ',
'                                                        end as JIRA_STATUS,',
'       m.DMS_DOKUMENTENSTATUS as "DMS_DOKUMENTENSTATUS",',
'       m.LETZTE_AENDERUNG_DATUM,',
'       m.GUELTIGKEITSDATUM,  -- Keeping validity date for Interpretations',
'       nvl2(m.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) AS "LETZTE_AENDERUNG_BENUTZER",',
'       PCK_RI.fJiraTicketsToLinks(m.JIRA_TICKET) AS "JIRA_TICKET"',
'from T_MFV m',
'join T_MFV_REF_VORSCHRIFT mrv on mrv.mfvid = m.mfvid',
'join t_mfv_ref_mfv_teil mrt on mrt.mfvid = m.mfvid',
'join t_mfv_teil t on t.mfv_teilid = mrt.mfv_teilid',
'left join teil on (teil.mfvid = m.mfvid)',
'left outer join T_BENUTZER b on b.BENUTZERID = m.LETZTE_AENDERUNG_BENUTZERID',
'left outer join ex  on (ex.mfvid = m.mfvid)',
'where ( mrv.vorschriftid = :P34_VORSCHRIFTID ',
'       -- MfVs  aus konsolidierten Vorschriften  anzeigen',
'            OR mrv.vorschriftid in ( select vorgaenger_vorschriftid from t_vorschrift_ref_vorschrift where  nachfolger_vorschriftid = :P34_VORSCHRIFTID and beziehung_art = 200 )',
'      )',
'and t.teil = 2  -- Filter for Interpretations only',
'-- and not exists (',
'--     -- Exclude if has other types',
'--     select 1 ',
'--     from t_mfv_ref_mfv_teil mrt2 ',
'--     join t_mfv_teil t2 on t2.mfv_teilid = mrt2.mfv_teilid',
'--     where mrt2.mfvid = m.mfvid ',
'--     and t2.teil != 2',
'-- )',
'',
'',
'and  ( ',
'    (  :P34_STATUS_OPTION = 100 and m.jira_status in (0, 10) )  -- alle MFV: show only geschlossen and offen',
'     or',
'    ( m.jira_status = 10 and :P34_STATUS_OPTION = 10 )  -- geschlossen',
'    or ',
'    ( m.jira_status = 20 and :P34_STATUS_OPTION = 20 )  -- ohne MFV beendet',
'    or ',
'    ( m.jira_status = 0 and :P34_STATUS_OPTION = 0  )   -- offen',
'    )'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P34_VORSCHRIFTID,P34_STATUS_OPTION'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="no-data-message">',
'    Keine MfVs-Interpretationen zugeordnet.',
'</div>'))
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028918331496292779)
,p_query_column_id=>1
,p_column_alias=>'INTERPRETATION_ROW_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>'(PCK_RI.fIsAuthorized(pageId => 85, accessMode => 200))'
,p_display_when_condition2=>'PLSQL'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028917986635292778)
,p_query_column_id=>2
,p_column_alias=>'ROW_KEY'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028919559669292780)
,p_query_column_id=>3
,p_column_alias=>'LINK'
,p_column_display_sequence=>160
,p_column_heading=>unistr('Best\00E4tige G\00FCltigkeit')
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028924809888292787)
,p_query_column_id=>4
,p_column_alias=>'MFVID'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028924352894292785)
,p_query_column_id=>5
,p_column_alias=>'MFV_NAME'
,p_column_display_sequence=>40
,p_column_heading=>'MfV Name'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028923916425292785)
,p_query_column_id=>6
,p_column_alias=>'MFV_TEIL'
,p_column_display_sequence=>50
,p_column_heading=>'MfV Teil'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028923535729292784)
,p_query_column_id=>7
,p_column_alias=>'MFV_THEMA'
,p_column_display_sequence=>60
,p_column_heading=>'Thema der MfV'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028923127518292784)
,p_query_column_id=>8
,p_column_alias=>'SCHLAGWORTE'
,p_column_display_sequence=>70
,p_column_heading=>'Schlagworte'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028919140842292780)
,p_query_column_id=>9
,p_column_alias=>'VORSCHRIFTENVERANTWORTLICHER'
,p_column_display_sequence=>170
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028922752163292783)
,p_query_column_id=>10
,p_column_alias=>'ARBEITSKREIS_LISTE'
,p_column_display_sequence=>80
,p_column_heading=>'ET Arbeitskreise'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028922366716292783)
,p_query_column_id=>11
,p_column_alias=>'BETEILIGTE_OES'
,p_column_display_sequence=>90
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028921946132292783)
,p_query_column_id=>12
,p_column_alias=>'LINK_MFV_DMS'
,p_column_display_sequence=>100
,p_column_heading=>'Link zur Ablage DMS'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028921604192292782)
,p_query_column_id=>13
,p_column_alias=>'JIRA_STATUS'
,p_column_display_sequence=>110
,p_column_heading=>'Jira Status'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028921134731292782)
,p_query_column_id=>14
,p_column_alias=>'DMS_DOKUMENTENSTATUS'
,p_column_display_sequence=>120
,p_column_heading=>'MfV Dokumentenstatus'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(958148833580521269)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028920753183292781)
,p_query_column_id=>15
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>130
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028919981573292781)
,p_query_column_id=>16
,p_column_alias=>'GUELTIGKEITSDATUM'
,p_column_display_sequence=>150
,p_column_heading=>unistr('G\00FCltigkeitsdatum')
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028920331574292781)
,p_query_column_id=>17
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZER'
,p_column_display_sequence=>140
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028918787269292780)
,p_query_column_id=>18
,p_column_alias=>'JIRA_TICKET'
,p_column_display_sequence=>180
,p_column_heading=>'Jira Ticket'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1554234421630963120)
,p_name=>'MfV - Information'
,p_region_name=>'p34_mfv_report_information'
,p_parent_plug_id=>wwv_flow_imp.id(9419691149654807307)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ex as (  select i.mfvid as mfvid, ',
'    listagg(a.kurz,'', '') within group (order by a.kurz) as ak_liste',
'    from t_mfv_ref_et_b_ak i',
'    join t_et_b_ak a on (i.et_b_akid = a.et_b_akid) group by i.mfvid',
' ),',
'teil as ( select listagg( t.teil || ''. ''||t.bezeichnung, '', '') within group (order by t.teil || ''. ''||t.bezeichnung) as teil_bez_list,',
'                                 mrt.mfvid mfvid',
'                from t_mfv_ref_mfv_teil mrt',
'                join t_mfv_teil t on (t.mfv_teilID = mrt.mfv_teilid)',
'                 group by mrt.mfvid',
' ) ',
'  ',
'select DISTINCT mrv.rowid as Information_row_id , ',
'm.MFVID as row_key,',
'       case when ( (:P34_EDIT_MODE is not null and :P34_EDIT_MODE = 1 ) ',
'                       and  m.DMS_DOKUMENTENSTATUS != 30  ',
'                   and nvl(m.GUELTIGKEITSDATUM, sysdate) < sysdate ) ',
'              then',
unistr('                    ''<span style="cursor:pointer;" text-align:center;" class="setzegueltigkeit fa fa-check" data-id="'' || m.mfvid || ''"><small><br>'' || emano_util.fLang(''G\00FCltigkeit'', ''Validity'') || ''<br>'' || emano_util.fLang(''best\00E4tigen'', ''confirm'') ')
||'|| ''<small></span>'' ',
'                else',
'                    ''#'' end as link,',
'       m.MFVID,',
'       m.mfv_name,',
'       teil.teil_bez_list AS "MFV_TEIL",',
'       case when length(m.mfv_thema ) > 64 then substr(m.mfv_thema,0,64)||''...'' else m.mfv_thema  end as mfv_thema,',
'       SCHLAGWORTE,',
'       VORSCHRIFTENVERANTWORTLICHER AS "VORSCHRIFTENVERANTWORTLICHER",',
'       ex.ak_liste  as Arbeitskreis_liste,',
'       BETEILIGTE_OES,',
'       PCK_RI.fCreateLinkIfUrl("LINK_MFV_DMS") AS "LINK_MFV_DMS",',
'       case when (m.JIRA_Status is null or m.JIRA_Status=0) then ',
'                                                            emano_util.fLang(''offen'', ''open'') ',
'                                                        when (m.JIRA_Status =10) then ',
'                                                            emano_util.fLang(''geschlossen'', ''closed'') ',
'                                                        when (m.JIRA_Status =20) then    ',
'                                                        emano_util.fLang(''ohne MfV beendet'', ''closed without notification'')  ',
'                                                        else ',
'                                                            emano_util.fLang(''offen'', ''open'') ',
'                                                        end as JIRA_STATUS,',
'       m.DMS_DOKUMENTENSTATUS as "DMS_DOKUMENTENSTATUS",',
'       m.LETZTE_AENDERUNG_DATUM,',
'       -- Removed GUELTIGKEITSDATUM as per requirements',
'       nvl2(m.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) AS "LETZTE_AENDERUNG_BENUTZER",',
'       PCK_RI.fJiraTicketsToLinks(m.JIRA_TICKET) AS "JIRA_TICKET"',
'from T_MFV m',
'join T_MFV_REF_VORSCHRIFT mrv on mrv.mfvid = m.mfvid',
'join t_mfv_ref_mfv_teil mrt on mrt.mfvid = m.mfvid',
'join t_mfv_teil t on t.mfv_teilid = mrt.mfv_teilid',
'left join teil on (teil.mfvid = m.mfvid)',
'left outer join T_BENUTZER b on b.BENUTZERID = m.LETZTE_AENDERUNG_BENUTZERID',
'left outer join ex  on (ex.mfvid = m.mfvid)',
'where (mrv.vorschriftid = :P34_VORSCHRIFTID ',
'       -- MfVs  aus konsolidierten Vorschriften  anzeigen',
'        OR mrv.vorschriftid in ( select vorgaenger_vorschriftid from t_vorschrift_ref_vorschrift where  nachfolger_vorschriftid = :P34_VORSCHRIFTID and beziehung_art = 200 )',
'       )',
'and t.teil in (1,3)  -- Filter for Information and Action Items',
'',
'-- and not exists (',
'--     -- Exclude if has Interpretation type',
'--     select 1 ',
'--     from t_mfv_ref_mfv_teil mrt2 ',
'--     join t_mfv_teil t2 on t2.mfv_teilid = mrt2.mfv_teilid',
'--     where mrt2.mfvid = m.mfvid ',
'--     and t2.teil = 2',
'-- )',
'',
'',
'',
'and  ( ',
'    (  :P34_STATUS_OPTION = 100 and m.jira_status in (0, 10) )  -- alle MFV: show only geschlossen and offen',
'     or',
'    ( m.jira_status = 10 and :P34_STATUS_OPTION = 10 )  -- geschlossen',
'    or ',
'    ( m.jira_status = 20 and :P34_STATUS_OPTION = 20 )  -- ohne MFV beendet',
'    or ',
'    ( m.jira_status = 0 and :P34_STATUS_OPTION = 0  )   -- offen',
'    )'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P34_VORSCHRIFTID,P34_STATUS_OPTION'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="no-data-message">',
'    Keine MfVs-Informationen und Handlungsbedarf zugeordnet.',
'</div>'))
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028910821612292770)
,p_query_column_id=>1
,p_column_alias=>'INFORMATION_ROW_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>'(PCK_RI.fIsAuthorized(pageId => 85, accessMode => 200))'
,p_display_when_condition2=>'PLSQL'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028910514840292770)
,p_query_column_id=>2
,p_column_alias=>'ROW_KEY'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028912023089292772)
,p_query_column_id=>3
,p_column_alias=>'LINK'
,p_column_display_sequence=>160
,p_hidden_column=>'Y'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028916841900292777)
,p_query_column_id=>4
,p_column_alias=>'MFVID'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028916446011292776)
,p_query_column_id=>5
,p_column_alias=>'MFV_NAME'
,p_column_display_sequence=>50
,p_column_heading=>'MfV Name'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028916097706292776)
,p_query_column_id=>6
,p_column_alias=>'MFV_TEIL'
,p_column_display_sequence=>60
,p_column_heading=>'MfV Teil'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028915690902292776)
,p_query_column_id=>7
,p_column_alias=>'MFV_THEMA'
,p_column_display_sequence=>70
,p_column_heading=>'Thema der MfV'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028915281789292775)
,p_query_column_id=>8
,p_column_alias=>'SCHLAGWORTE'
,p_column_display_sequence=>80
,p_column_heading=>'Schlagworte'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028911689658292771)
,p_query_column_id=>9
,p_column_alias=>'VORSCHRIFTENVERANTWORTLICHER'
,p_column_display_sequence=>170
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028914863382292775)
,p_query_column_id=>10
,p_column_alias=>'ARBEITSKREIS_LISTE'
,p_column_display_sequence=>90
,p_column_heading=>'ET Arbeitskreise'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028914482212292774)
,p_query_column_id=>11
,p_column_alias=>'BETEILIGTE_OES'
,p_column_display_sequence=>100
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028914046330292774)
,p_query_column_id=>12
,p_column_alias=>'LINK_MFV_DMS'
,p_column_display_sequence=>110
,p_column_heading=>'Link zur Ablage DMS'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028913672075292774)
,p_query_column_id=>13
,p_column_alias=>'JIRA_STATUS'
,p_column_display_sequence=>120
,p_column_heading=>'Jira Status'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028913272537292773)
,p_query_column_id=>14
,p_column_alias=>'DMS_DOKUMENTENSTATUS'
,p_column_display_sequence=>130
,p_column_heading=>'MfV Dokumentenstatus'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(958148833580521269)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028912897343292773)
,p_query_column_id=>15
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>140
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028912459027292772)
,p_query_column_id=>16
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZER'
,p_column_display_sequence=>150
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028911299874292771)
,p_query_column_id=>17
,p_column_alias=>'JIRA_TICKET'
,p_column_display_sequence=>180
,p_column_heading=>'Jira Ticket'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(9419691373988807309)
,p_name=>'REPORT_MFV - All'
,p_region_name=>'p34_mfv_report'
,p_parent_plug_id=>wwv_flow_imp.id(9419691149654807307)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ex as (  select i.mfvid as mfvid, ',
'    listagg(a.kurz,'', '') within group (order by a.kurz) as ak_liste',
'    from t_mfv_ref_et_b_ak i',
'    join t_et_b_ak a on (i.et_b_akid = a.et_b_akid) group by i.mfvid',
' ),',
'teil as ( select listagg( t.teil || ''. ''||t.bezeichnung, '', '') within group (order by t.teil || ''. ''||t.bezeichnung) as teil_bez_list,',
'                                 mrt.mfvid mfvid',
'                from t_mfv_ref_mfv_teil mrt',
'                join t_mfv_teil t on (t.mfv_teilID = mrt.mfv_teilid)',
'                 group by mrt.mfvid',
' ) ',
'  ',
'select mrv.rowid, ',
'       case when ( (:P34_EDIT_MODE is not null and :P34_EDIT_MODE = 1 ) ',
'                       and  m.DMS_DOKUMENTENSTATUS != 30  ',
'                   and nvl(m.GUELTIGKEITSDATUM, sysdate) < sysdate ) ',
'              then',
unistr('                    ''<span style="cursor:pointer;" text-align:center;" class="setzegueltigkeit fa fa-check" data-id="'' || m.mfvid || ''"><small><br>'' || emano_util.fLang(''G\00FCltigkeit'', ''Validity'') || ''<br>'' || emano_util.fLang(''best\00E4tigen'', ''confirm'') ')
||'|| ''<small></span>'' ',
'                else',
'                    ''#'' end as link,',
'',
'       m.MFVID,',
'       m.mfv_name,',
'       teil.teil_bez_list AS "MFV_TEIL",',
'       case when length(m.mfv_thema ) > 64 then substr(m.mfv_thema,0,64)||''...'' else m.mfv_thema  end as mfv_thema,',
'       SCHLAGWORTE,',
'       VORSCHRIFTENVERANTWORTLICHER AS "VORSCHRIFTENVERANTWORTLICHER",',
'        ex.ak_liste  as Arbeitskreis_liste,',
'       BETEILIGTE_OES,',
'PCK_RI.fCreateLinkIfUrl("LINK_MFV_DMS") AS "LINK_MFV_DMS",',
'    case when (m.JIRA_Status is null or m.JIRA_Status=0) then ',
'                                                            emano_util.fLang(''offen'', ''open'') ',
'                                                        when (m.JIRA_Status =10) then ',
'                                                            emano_util.fLang(''geschlossen'', ''closed'') ',
'                                                        when (m.JIRA_Status =20) then    ',
'                                                        emano_util.fLang(''ohne MfV beendet'', ''closed without notification'')  ',
'                                                        else ',
'                                                            emano_util.fLang(''offen'', ''open'') ',
'                                                        end as JIRA_STATUS,',
'',
'       m.DMS_DOKUMENTENSTATUS as "DMS_DOKUMENTENSTATUS",',
'       m.LETZTE_AENDERUNG_DATUM,',
'       m.GUELTIGKEITSDATUM,',
'       nvl2(m.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) AS "LETZTE_AENDERUNG_BENUTZER",',
'PCK_RI.fJiraTicketsToLinks(m.JIRA_TICKET) AS "JIRA_TICKET"',
'from T_MFV m',
'join T_MFV_REF_VORSCHRIFT mrv on mrv.mfvid = m.mfvid',
'left join teil on (teil.mfvid = m.mfvid)',
'left outer join T_BENUTZER b on b.BENUTZERID = m.LETZTE_AENDERUNG_BENUTZERID',
'left outer join ex  on (ex.mfvid = m.mfvid)',
'where mrv.vorschriftid = :P34_VORSCHRIFTID and  ( ',
'    (  :P34_STATUS_OPTION = 100  and (m.jira_status != 20 or (pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0 and m.jira_status= 0) ))',
'     or',
'    ( m.jira_status= 10  and :P34_STATUS_OPTION = 10 )',
'    or ',
'    (m.jira_status = 20 AND :P34_STATUS_OPTION = 20)',
'    or ',
'    ( m.jira_status= 0  and :P34_STATUS_OPTION = 0  and pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0)',
'    )',
'    ',
''))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'Keine MfVs zugeordnet.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028909735601292769)
,p_query_column_id=>1
,p_column_alias=>'ROWID'
,p_column_display_sequence=>1
,p_column_link=>'f?p=&APP_ID.:85:&SESSION.::&DEBUG.:RP,85:P85_ROWID:#ROWID#'
,p_column_linktext=>'<span class="fa fa-pencil" alt="Bearbeiten" title="Bearbeiten"  />'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(2931365771368179754)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028909322005292768)
,p_query_column_id=>2
,p_column_alias=>'LINK'
,p_column_display_sequence=>70
,p_column_heading=>unistr('Best\00E4tige G\00FCltigkeit')
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028908944749292768)
,p_query_column_id=>3
,p_column_alias=>'MFVID'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028908566887292767)
,p_query_column_id=>4
,p_column_alias=>'MFV_NAME'
,p_column_display_sequence=>3
,p_column_heading=>'MfV Name'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028908146007292767)
,p_query_column_id=>5
,p_column_alias=>'MFV_TEIL'
,p_column_display_sequence=>4
,p_column_heading=>'MfV Teil'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028907895102292767)
,p_query_column_id=>6
,p_column_alias=>'MFV_THEMA'
,p_column_display_sequence=>5
,p_column_heading=>'Thema der MfV'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028907450902292766)
,p_query_column_id=>7
,p_column_alias=>'SCHLAGWORTE'
,p_column_display_sequence=>6
,p_column_heading=>'Schlagworte'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028907025437292766)
,p_query_column_id=>8
,p_column_alias=>'VORSCHRIFTENVERANTWORTLICHER'
,p_column_display_sequence=>80
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028906646556292766)
,p_query_column_id=>9
,p_column_alias=>'ARBEITSKREIS_LISTE'
,p_column_display_sequence=>7
,p_column_heading=>'ET Arbeitskreise'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028906294999292765)
,p_query_column_id=>10
,p_column_alias=>'BETEILIGTE_OES'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028905863269292765)
,p_query_column_id=>11
,p_column_alias=>'LINK_MFV_DMS'
,p_column_display_sequence=>10
,p_column_heading=>'Link zur Ablage DMS'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028905508367292764)
,p_query_column_id=>12
,p_column_alias=>'JIRA_STATUS'
,p_column_display_sequence=>20
,p_column_heading=>'Jira Status'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028905079648292764)
,p_query_column_id=>13
,p_column_alias=>'DMS_DOKUMENTENSTATUS'
,p_column_display_sequence=>30
,p_column_heading=>'DMS Dokumentenstatus'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(958148833580521269)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028904712228292764)
,p_query_column_id=>14
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028904232885292763)
,p_query_column_id=>15
,p_column_alias=>'GUELTIGKEITSDATUM'
,p_column_display_sequence=>60
,p_column_heading=>unistr('G\00FCltigkeitsdatum')
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028903871129292763)
,p_query_column_id=>16
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZER'
,p_column_display_sequence=>50
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028903473158292763)
,p_query_column_id=>17
,p_column_alias=>'JIRA_TICKET'
,p_column_display_sequence=>90
,p_column_heading=>'Jira Ticket'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9426008302536293131)
,p_plug_name=>'Einsatzdaten'
,p_region_name=>'rEinsatzdaten'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'( ( (:P34_ROWID is not null or :P34_VORSCHRIFTID is not null)',
'     --and :P34_VORSCHRIFT_TYPID <> 20 ',
'  ) ',
'  or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1 ) ',
')'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1966673048204011770)
,p_name=>'Themengebietsspezifische Einsatzdaten aus GETEX'
,p_parent_plug_id=>wwv_flow_imp.id(9426008302536293131)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>70
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-top-md'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  sqlqry clob;',
'  lVorschriftID number := :P34_VORSCHRIFTID;',
'  lColList clob;',
'BEGIN',
'',
'    SELECT LISTAGG('''''''' || EINSATZDATUM_TYP || '''''' AS "'' || EINSATZDATUM_TYP || ''"'', '', '') WITHIN GROUP (ORDER BY EINSATZDATUM_TYP) into lColList',
'    FROM (',
'      SELECT DISTINCT EINSATZDATUM_TYP',
'      FROM V_THEMA_BAUM vtb',
'      JOIN T_VORSCHRIFT_REF_THEMA_REF_EINSATZDATUM_TYP tvrtret ON vtb.THEMAID = tvrtret.THEMAID',
'      JOIN T_EINSATZDATUM_TYP tet ON tvrtret.EINSATZDATUM_TYPID = tet.EINSATZDATUM_TYPID',
'      WHERE tvrtret.VORSCHRIFTID = lVorschriftID and tvrtret.einsatzdatum_typid != 1031',
'    );',
'',
'    sqlqry := ''SELECT *',
'     FROM (',
'       WITH cte_thema AS (',
'         SELECT --tvrtret.VORSCHRIFTID,',
'                --vtb.THEMA_SORTORDER,',
'                vtb.NUMMER AS "Nummer",',
'                vtb.BEZEICHNUNG AS "Thema",',
'                tvrtret.EINSATZDATUM,',
'                tet.EINSATZDATUM_TYP,',
'                extract(year from tvrtret.MODELJAHR) as "Modelljahr" --,',
'                --tvrtret.KOMMENTAR,',
'                --tvrtret.LETZTE_AENDERUNG_DATUM',
'         FROM V_THEMA_BAUM vtb',
'         JOIN T_VORSCHRIFT_REF_THEMA_REF_EINSATZDATUM_TYP tvrtret ON vtb.THEMAID = tvrtret.THEMAID',
'         JOIN T_EINSATZDATUM_TYP tet ON tvrtret.EINSATZDATUM_TYPID = tet.EINSATZDATUM_TYPID',
'         WHERE tvrtret.VORSCHRIFTID = '' || lVorschriftID || '' and tvrtret.einsatzdatum_typid != 1031',
'       )',
'       SELECT *',
'       FROM cte_thema',
'     )',
'     PIVOT (MAX(EINSATZDATUM) FOR EINSATZDATUM_TYP IN ('' || lColList || ''))'';',
'',
'',
'  RETURN sqlqry;',
'END;',
''))
,p_optimizer_hint=>'WITH_PLSQL'
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P34_VORSCHRIFTID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_plug_query_max_columns=>12
,p_query_headings_type=>'QUERY_COLUMNS'
,p_query_num_rows=>15
,p_query_options=>'GENERIC_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028901686572292760)
,p_query_column_id=>1
,p_column_alias=>'COL01'
,p_column_display_sequence=>10
,p_column_heading=>'Col01'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028901256205292760)
,p_query_column_id=>2
,p_column_alias=>'COL02'
,p_column_display_sequence=>20
,p_column_heading=>'Col02'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028900889368292760)
,p_query_column_id=>3
,p_column_alias=>'COL03'
,p_column_display_sequence=>30
,p_column_heading=>'Col03'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P34_EINSATZDATUM_MODELLID'
,p_display_when_condition2=>'30'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028900506464292760)
,p_query_column_id=>4
,p_column_alias=>'COL04'
,p_column_display_sequence=>40
,p_column_heading=>'Col04'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028900055490292760)
,p_query_column_id=>5
,p_column_alias=>'COL05'
,p_column_display_sequence=>50
,p_column_heading=>'Col05'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028899653144292759)
,p_query_column_id=>6
,p_column_alias=>'COL06'
,p_column_display_sequence=>60
,p_column_heading=>'Col06'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028899296351292759)
,p_query_column_id=>7
,p_column_alias=>'COL07'
,p_column_display_sequence=>70
,p_column_heading=>'Col07'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028898907313292759)
,p_query_column_id=>8
,p_column_alias=>'COL08'
,p_column_display_sequence=>80
,p_column_heading=>'Col08'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028898475135292759)
,p_query_column_id=>9
,p_column_alias=>'COL09'
,p_column_display_sequence=>90
,p_column_heading=>'Col09'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028898047118292758)
,p_query_column_id=>10
,p_column_alias=>'COL10'
,p_column_display_sequence=>100
,p_column_heading=>'Col10'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028897646650292758)
,p_query_column_id=>11
,p_column_alias=>'COL11'
,p_column_display_sequence=>110
,p_column_heading=>'Col11'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028897235420292758)
,p_query_column_id=>12
,p_column_alias=>'COL12'
,p_column_display_sequence=>120
,p_column_heading=>'Col12'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2001617475957638639)
,p_plug_name=>'Alert T_LAND'
,p_parent_plug_id=>wwv_flow_imp.id(9426008302536293131)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:t-Alert--removeHeading:margin-bottom-sm'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1531333716731902102)
,p_name=>'T_LAND'
,p_parent_plug_id=>wwv_flow_imp.id(2001617475957638639)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    tv.vorschriftid,',
'    LISTAGG(tl.LANDID, '', '' ON OVERFLOW TRUNCATE) WITHIN GROUP (ORDER BY tl.LAND) AS LANDIDS,',
'    LISTAGG(tl.LAND, '', '' ON OVERFLOW TRUNCATE) WITHIN GROUP (ORDER BY tl.LAND) AS LAENDER,',
'    DBMS_LOB.SUBSTR(tl.BEDEUTUNG_EINSATZTERMIN, 4000, 1) AS BEDEUTUNG_EINSATZTERMIN,',
'    DBMS_LOB.SUBSTR(tl.BEMERKUNG_EINSATZTERMIN, 4000, 1) AS BEMERKUNG_EINSATZTERMIN',
'    -- CASE ',
'    --     WHEN DBMS_LOB.SUBSTR(tl.BEMERKUNG_EINSATZTERMIN, 4000, 1) IS NOT NULL THEN',
'    --         ''<a href="#" onclick="apex.navigation.redirect(''''f?p=&APP_ID.:12:&APP_SESSION.::NO::P12_VORSCHRIFTID:'''' || tv.vorschriftid);">'' ||',
'    --         ''<span class="fa fa-info-circle" aria-hidden="true"></span></a>''',
'    --     ELSE',
'    --         NULL',
'    -- END AS BEMERKUNG_EINSATZTERMIN',
'FROM ',
'    t_vorschrift tv',
'LEFT OUTER JOIN ',
'    t_vorschrift_ref_land tvrl ON (tv.vorschriftid = tvrl.vorschriftid)',
'LEFT OUTER JOIN ',
'    t_land tl ON (tvrl.landid = tl.landid)',
'LEFT JOIN ',
'    t_benutzer tb ON (tv.letzte_aenderung_benutzerid = tb.benutzerid)',
'WHERE ',
'    tv.vorschriftid = :P34_VORSCHRIFTID AND tvrl.geloescht != 1',
'GROUP BY ',
'    tv.vorschriftid,',
'    DBMS_LOB.SUBSTR(tl.BEDEUTUNG_EINSATZTERMIN, 4000, 1),',
'    DBMS_LOB.SUBSTR(tl.BEMERKUNG_EINSATZTERMIN, 4000, 1)',
'ORDER BY ',
'    DBMS_LOB.SUBSTR(tl.BEDEUTUNG_EINSATZTERMIN, 4000, 1),',
'    DBMS_LOB.SUBSTR(tl.BEMERKUNG_EINSATZTERMIN, 4000, 1)'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P34_VORSCHRIFTID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('Noch keine L\00E4nder zugeordnet.')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028896255051292755)
,p_query_column_id=>1
,p_column_alias=>'VORSCHRIFTID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028895862215292755)
,p_query_column_id=>2
,p_column_alias=>'LANDIDS'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028895483583292755)
,p_query_column_id=>3
,p_column_alias=>'LAENDER'
,p_column_display_sequence=>30
,p_column_heading=>unistr('L\00E4nder')
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select landid from (select',
'      count(tl.landid) landid ,tv.vorschriftid',
'  from t_vorschrift tv',
'  left outer join t_vorschrift_ref_land tvrl on (tv.vorschriftid = tvrl.vorschriftid)',
'  left outer join t_land tl on (tvrl.landid = tl.landid)',
'  left join t_benutzer tb on (tv.letzte_aenderung_benutzerid = tb.benutzerid)',
'  where tv.vorschriftid = :P34_VORSCHRIFTID AND tvrl.geloescht != 1',
'  group by tv.vorschriftid',
'  having count(*)>1)'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028895056842292755)
,p_query_column_id=>4
,p_column_alias=>'BEDEUTUNG_EINSATZTERMIN'
,p_column_display_sequence=>40
,p_column_heading=>unistr('Bedeutung Erf\00FCllungszeitpunkt')
,p_column_alignment=>'CENTER'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028894624502292754)
,p_query_column_id=>5
,p_column_alias=>'BEMERKUNG_EINSATZTERMIN'
,p_column_display_sequence=>60
,p_column_heading=>unistr('<span onclick="redirect(1441)" style="font-size:2em; vertical-align:middle;" class="fa fa-info-square-o"  title="Informationen zum Erf\00FCllungszeitpunkt" ></span> &nbsp; Bemerkung Erf\00FCllungszeitpunkt')
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_column_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<span class="fa fa-info-circle" aria-hidden="true" title="Bemerkung Erf\00FCllungszeitpunkt" alt="Bemerkung Erf\00FCllungszeitpunkt"></span>'),
'',
'',
'LINK',
'',
'PAGE 12',
'',
'',
'P12_VORSCHRIFTID    #VORSCHRIFTID#',
'P12_BEMERKUNG_EINSATZTERMIN #BEMERKUNG_EINSATZTERMIN#'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5721721984254991065)
,p_plug_name=>'Hinweis'
,p_parent_plug_id=>wwv_flow_imp.id(9426008302536293131)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:t-Alert--removeHeading:margin-bottom-sm'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as(',
unistr('    Select emano_util.fLang(''Achtung,  f\00FCr neue typen darf diese Vorschrift nicht mehr verwendet werden'','),
'                          ''Attention, this regulation must not be used for new types'')',
'    as hinweis',
'     from  T_VORSCHRIFT_REF_EINSATZDATUM_TYP vre',
'   join T_vorschrift_ref_vorschrift vrv on (vrv.nachfolger_vorschriftid = vre.vorschriftid)',
'  where vrv.beziehung_art in (10) and vrv.vorgaenger_vorschriftid = :P34_VORSCHRIFTID',
'  and vre.einsatzdatum_typid in (1010, 1020) and vre.einsatzdatum < sysdate',
')',
'select ''<span style="color:red">'' || hinweis ||''</span>'' a --, hinweis b',
'from  cte1',
'  fetch first 1 rows only'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9426008489308293132)
,p_plug_name=>'GRID_EINSATZDATEN'
,p_region_name=>'ig_einsatzdaten'
,p_parent_plug_id=>wwv_flow_imp.id(9426008302536293131)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select edt.EINSATZDATUM_TYP,',
'  vredt.VORSCHRIFT_REF_EINSATZDATUM_TYPID,',
'  :P34_VORSCHRIFTID as vorschriftid,',
'  edt.EINSATZDATUM_TYPID,',
'  nvl(to_char(to_date(vredt.einsatzdatum,''dd.mm.yy''), ''dd.mm.yyyy''), null) einsatzdatum,',
'  case when (:P34_DATUM_ANGABE_AS_MJ = 1 and edt.EINSATZDATUM_TYPID in ( 1041,1030,1031)) ',
'      then nvl2(vredt.Modeljahr, to_char(to_date(vredt.Modeljahr,''dd.mm.yy''), ''YYYY''), null)',
'      else null end Modeljahr,',
'  vredt.einsatzdatum_text,',
'  vredt.einsatzdatum_text_englisch,',
'  vredt.letzte_aenderung_datum,',
'--   nvl2(vredt.letzte_aenderung_benutzerid, b.Nachname || '', '' || b.vorname, null) as LETZTE_AENDERUNG_BENUTZER,',
'nvl2(vredt.letzte_aenderung_benutzerid,',
'    CASE ',
'        WHEN b.nachname IS NOT NULL AND b.vorname IS NOT NULL ',
'            THEN b.nachname || '', '' || b.vorname',
'        WHEN b.nachname IS NOT NULL AND b.vorname IS NULL ',
'            THEN b.nachname',
'        WHEN b.nachname IS NULL AND b.vorname IS NOT NULL ',
'            THEN b.vorname',
'        ELSE NULL ',
'    END,',
'    null) as LETZTE_AENDERUNG_BENUTZER,',
'',
'  MANUELLE_EINTRAGUNG, edt.SORTORDER as SORTORDER',
'from T_EINSATZDATUM_TYP edt',
'left outer join T_VORSCHRIFT_REF_EINSATZDATUM_TYP vredt on (vredt.einsatzdatum_typid = edt.einsatzdatum_typid',
'                                                              AND ',
'                                                              (vredt.vorschriftid is null ',
'                                                                   OR vredt.vorschriftid = :P34_VORSCHRIFTID)',
'                                                           )',
'left outer join T_BENUTZER b on b.benutzerid = vredt.letzte_aenderung_benutzerid',
'where  ( ',
unistr('    -- regul\00E4re datumsangaben'),
'    edt.einsatzdatum_typid = 1000 -- in kraft immer anzeigen',
unistr('    or (edt.einsatzdatum_typid in (1060,1063) and :P34_EINSATZDATUM_MODELLID = 20) -- au\00DFer kraft ckd/fbu'),
unistr('    or (edt.einsatzdatum_typid = 1041 and :P34_EINSATZDATUM_MODELLID in (10,30)) -- au\00DFer kraft'),
')',
'-- mit rolle inaktive Funktionen alle anzeigen',
'or (pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0',
'    and edt.einsatzdatum_typid in (1010, 1011, 1020, 1021, 1022, 1023, 1030)',
')',
'',
''))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P34_VORSCHRIFTID,P34_DATUM_ANGABE_AS_MJ,P34_EDIT_MODE,P34_EINSATZDATUM_MODELLID'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--  (:P34_STRG_GETEX_ANZEIGE = 20 and nvl(:P34_EDIT_MODE, 0) = 1)',
'',
'',
'(',
'  (  ',
'         pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1080'') > 0) -- Rolle VKO, Fachadm',
') = false',
'  or ',
'(  ',
'   (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
')'))
,p_plug_read_only_when2=>'PLSQL'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1027685636517552911)
,p_name=>'Edit'
,p_source_type=>'NONE'
,p_item_type=>'NATIVE_LINK'
,p_heading=>'&nbsp;'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>10
,p_value_alignment=>'CENTER'
,p_link_target=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:37:P37_VORSCHRIFTID,P37_EINSATZDATUM_MODELLID,P37_EINSATZDATUM_TYPID,P37_DATUM_ANGABE_AS_MJ:&P34_VORSCHRIFTID.,&P34_EINSATZDATUM_MODELLID.,&EINSATZDATUM_TYPID.,&P34_DATUM_ANGABE_AS_MJ.'
,p_link_text=>'<span class="fa fa-pencil" alt="Bearbeiten" title="Bearbeiten"></span>'
,p_link_attributes=>' class="t-Button t-Button--icon t-Button--small"'
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1200:1080'') > 0 ',
'OR (pck_ri.fIsUserInRolle(listRolleId => ''1001:1002'') > 0 AND :P34_VORSCHRIFT_FREIGABESTATUSID in (10,30))'))
,p_display_condition2=>'PLSQL'
,p_escape_on_http_output=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5706325860060900865)
,p_name=>'MANUELLE_EINTRAGUNG'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MANUELLE_EINTRAGUNG'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'10'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5790533769453777394)
,p_name=>'SORTORDER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SORTORDER'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>120
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5807829505583938280)
,p_name=>'EINSATZDATUM_TEXT_ENGLISCH'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EINSATZDATUM_TEXT_ENGLISCH'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Einsatzdatum Text Englisch'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6413091100680409890)
,p_name=>'MODELJAHR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MODELJAHR'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Modelljahr'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_format_mask=>'YYYY'
,p_item_width=>4
,p_is_required=>false
,p_max_length=>4
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>true
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P34_EINSATZDATUM_MODELLID'
,p_display_condition2=>'30'
,p_readonly_condition_type=>'FUNCTION_BODY'
,p_readonly_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'begin',
'',
'-- Nur bearbeitbar wenn',
'if (:EINSATZDATUM_TYPID = (1030) -- Einsatzzeitpunkt',
'    and nvl(:P34_STRG_GETEX_ANZEIGE,10) = 10 -- Master RegIndex',
'    and nvl(:P34_EDIT_MODE,0) = 1  -- Edit Modus',
'    and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0 -- Rechte',
'    and nvl(:P34_DATUM_ANGABE_AS_MJ,0) = 1) then -- Modelljahresschalter',
'',
'    return false;',
'',
'    else',
'',
'    return true;',
'end if;',
'',
'',
'end;'))
,p_readonly_condition2=>'PLSQL'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9426008850355293136)
,p_name=>'EINSATZDATUM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EINSATZDATUM'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER'
,p_heading=>'Datum'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
,p_format_mask=>'dd.mm.yyyy'
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_static_id=>'ig_einsatzdaten_datum'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'FUNCTION_BODY'
,p_readonly_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'    -- Wenn Editmodus, Rolle VKO und eins der Datum-Ausser-Kraft-Angaben => dann bearbeitbar',
'    if (nvl(:P34_EDIT_MODE,0) = 1 and pck_ri.fIsUserInRolle(listRolleId => ''1000'') > 0 and :EINSATZDATUM_TYPID in (1041,1060,1063)) then',
'        return false;',
'    end if;',
'',
'    -- First check if edit mode is on and user has role 1080 (inaktive Funktionen)',
'    if ((nvl(:P34_EDIT_MODE,0) = 0) or pck_ri.fIsUserInRolle(listRolleId => ''1080'') = 0) then',
'        -- If edit mode is off OR user doesn''t have role 1080, then read only',
'        return true;',
'    end if;',
'',
'    -- If MJ switch is off, everything is editable',
'    if nvl(:P34_DATUM_ANGABE_AS_MJ,0) = 0 then',
'        return false;',
'    -- If MJ switch is on and it''s deployment date type, make read-only',
'    elsif nvl(:P34_DATUM_ANGABE_AS_MJ,0) = 1 and :EINSATZDATUM_TYPID = 1030 then',
'        return true;',
'    -- If MJ switch is on but not deployment date type, keep editable',
'    elsif nvl(:P34_DATUM_ANGABE_AS_MJ,0) = 1 and :EINSATZDATUM_TYPID != 1030 then',
'        return false;',
'    else',
unistr('        debug(''Ung\00FCltiger Else - Zweig!'');'),
'        raise CASE_NOT_FOUND;',
'    end if;',
'end;'))
,p_readonly_condition2=>'PLSQL'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9426008896005293137)
,p_name=>'EINSATZDATUM_TEXT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EINSATZDATUM_TEXT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Bemerkung Datum'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'FUNCTION_BODY'
,p_readonly_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'begin',
'',
'    if (nvl(:P34_EDIT_MODE,0) = 1 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0) then',
'        return false;',
'    else',
'        return true;',
'    end if;',
'',
'end;'))
,p_readonly_condition2=>'PLSQL'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9426009085076293138)
,p_name=>'LETZTE_AENDERUNG_DATUM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LETZTE_AENDERUNG_DATUM'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('Letzte \00C4nderung Datum')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_format_mask=>'DD.MM.YYYY HH24:Mi'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9426009104079293139)
,p_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LETZTE_AENDERUNG_BENUTZER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>3202
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9426009667042293144)
,p_name=>'EINSATZDATUM_TYP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EINSATZDATUM_TYP'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Einsatzdatum'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>true
,p_max_length=>160
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9426009702471293145)
,p_name=>'VORSCHRIFT_REF_EINSATZDATUM_TYPID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFT_REF_EINSATZDATUM_TYPID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9426009882061293146)
,p_name=>'EINSATZDATUM_TYPID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EINSATZDATUM_TYPID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>90
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9426286917558803112)
,p_name=>'VORSCHRIFTID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFTID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>100
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(9426008574110293133)
,p_internal_uid=>13098220890009681368
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>false
,p_no_data_found_message=>'Es wurden noch keine Einsatzdaten zugeordnet.'
,p_show_toolbar=>false
,p_toolbar_buttons=>null
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>true
,p_fixed_header=>'NONE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(9426105197086989200)
,p_interactive_grid_id=>wwv_flow_imp.id(9426008574110293133)
,p_static_id=>'1577401'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(9426105357824989200)
,p_report_id=>wwv_flow_imp.id(9426105197086989200)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1025455531572615140)
,p_view_id=>wwv_flow_imp.id(9426105357824989200)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(1027685636517552911)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>52
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(5706331835261914069)
,p_view_id=>wwv_flow_imp.id(9426105357824989200)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(5706325860060900865)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(5796748151799984924)
,p_view_id=>wwv_flow_imp.id(9426105357824989200)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(5790533769453777394)
,p_is_visible=>true
,p_is_frozen=>false
,p_sort_order=>1
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(5815758719373704555)
,p_view_id=>wwv_flow_imp.id(9426105357824989200)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(5807829505583938280)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(6418061639769303667)
,p_view_id=>wwv_flow_imp.id(9426105357824989200)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(6413091100680409890)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(9426106856476989206)
,p_view_id=>wwv_flow_imp.id(9426105357824989200)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(9426008850355293136)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(9426107325876989207)
,p_view_id=>wwv_flow_imp.id(9426105357824989200)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(9426008896005293137)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(9426107860824989209)
,p_view_id=>wwv_flow_imp.id(9426105357824989200)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(9426009085076293138)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(9426108366597989210)
,p_view_id=>wwv_flow_imp.id(9426105357824989200)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(9426009104079293139)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(9426162750160473788)
,p_view_id=>wwv_flow_imp.id(9426105357824989200)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(9426009667042293144)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(9426238274709938975)
,p_view_id=>wwv_flow_imp.id(9426105357824989200)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(9426009702471293145)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(9426267937460218341)
,p_view_id=>wwv_flow_imp.id(9426105357824989200)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(9426009882061293146)
,p_is_visible=>true
,p_is_frozen=>false
,p_sort_order=>1
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(9426294901943839655)
,p_view_id=>wwv_flow_imp.id(9426105357824989200)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(9426286917558803112)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9426288395056803127)
,p_plug_name=>'UN-R Supplements'
,p_region_name=>'rSupplements'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>85
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'((:P34_ROWID is not null or :P34_Vorschriftid is not null)',
'  and :P34_VORSCHRIFT_TYPID <> 20)'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(9426288669606803129)
,p_name=>'REPORT_SUPPLEMENTS'
,p_parent_plug_id=>wwv_flow_imp.id(9426288395056803127)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vrv.rowid,',
'    vv.vorschrift_nummer || '' - '' || vv.vorschrift_bezeichnung as vorgaenger_vorschrift,',
'    nv.vorschrift_nummer || '' - '' || nv.vorschrift_bezeichnung as nachfolger_vorschrift,',
'    vrv.beziehung_art,',
'    (select vret.einsatzdatum',
'        from t_vorschrift_ref_einsatzdatum_typ  vret',
'        where (nv.vorschriftid = vret.vorschriftid)',
'        and vret.einsatzdatum_typid = 1000) as DATUM_IN_KRAFT,',
'    vrv.kommentar,',
'    vrv.letzte_aenderung_datum,',
'    b.nachname || '', '' || b.vorname,',
'    nv.rowid as sup_rowid,',
'    nvl(vorgaenger_vorschriftid,vrv.nachfolger_vorschriftid) as vorgaenger_vorschriftid,',
'    vrv.nachfolger_vorschriftid,',
'    (select listagg(mfv.mfv_name, '', '')',
'        from t_mfv_ref_vorschrift mrv ',
'        left outer join t_mfv mfv on mfv.mfvid = mrv.mfvid',
'        where mrv.vorschriftid = nv.vorschriftid) as MFV',
'from t_vorschrift_ref_vorschrift vrv',
'left outer join t_benutzer b on b.benutzerid = vrv.letzte_aenderung_benutzerid',
'join t_vorschrift vv on vv.vorschriftid = vrv.vorgaenger_vorschriftid and (vrv.BEZIEHUNG_ART IN ( 30))-- Beziehung Suplemtnt/Amendment',
'join t_vorschrift nv on nv.vorschriftid = vrv.nachfolger_vorschriftid and (vrv.BEZIEHUNG_ART IN ( 30))-- Beziehung Suplemtnt/Amendment',
'--left outer join t_mfv_ref_vorschrift mrv on mrv.vorschriftid = :P34_VORSCHRIFTID',
'--left outer join t_mfv mfv on mfv.mfvid = mrv.mfvid',
'',
'where ((vrv.vorgaenger_vorschriftid = :P34_VORSCHRIFTID)--and nv.vorschrift_typid = 20) -- Supplement UN-R ',
'    or (vrv.nachfolger_vorschriftid = :P34_VORSCHRIFTID)) --and vv.vorschrift_typid = 20)) -- Supplement UN-R',
'    ',
'order by 1 ',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P34_VORSCHRIFTID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'Keine Supplements zugeordnet.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028885582210292716)
,p_query_column_id=>1
,p_column_alias=>'ROWID'
,p_column_display_sequence=>1
,p_column_link=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:RP,:P34_ROWID,P34_VORSCHRIFTID_PARENT:#SUP_ROWID#,#VORGAENGER_VORSCHRIFT#'
,p_column_linktext=>'<span class="fa fa-pencil" alt="Bearbeiten" title="Bearbeiten"  />'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028885121617292716)
,p_query_column_id=>2
,p_column_alias=>'VORGAENGER_VORSCHRIFT'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028884731403292715)
,p_query_column_id=>3
,p_column_alias=>'NACHFOLGER_VORSCHRIFT'
,p_column_display_sequence=>4
,p_column_heading=>'Supplement'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028884347240292715)
,p_query_column_id=>4
,p_column_alias=>'BEZIEHUNG_ART'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028884008129292715)
,p_query_column_id=>5
,p_column_alias=>'DATUM_IN_KRAFT'
,p_column_display_sequence=>6
,p_column_heading=>'In Kraftsetzung'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028883558405292715)
,p_query_column_id=>6
,p_column_alias=>'KOMMENTAR'
,p_column_display_sequence=>7
,p_column_heading=>'Kommentar'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028883171039292714)
,p_query_column_id=>7
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>9
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_column_format=>'DD.MM.YYYY HH24:Mi'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028882783307292714)
,p_query_column_id=>8
,p_column_alias=>'B.NACHNAME||'',''||B.VORNAME'
,p_column_display_sequence=>10
,p_column_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028882369598292714)
,p_query_column_id=>9
,p_column_alias=>'SUP_ROWID'
,p_column_display_sequence=>11
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028882014965292714)
,p_query_column_id=>10
,p_column_alias=>'VORGAENGER_VORSCHRIFTID'
,p_column_display_sequence=>21
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028881608785292714)
,p_query_column_id=>11
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>2
,p_column_heading=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:RP,:P34_ROWID,P34_VORSCHRIFTID_PARENT:#SUP_ROWID#,#VORGAENGER_VORSCHRIFTID#'
,p_column_linktext=>unistr('<span class="fa fa-search" alt="Bearbeiten" title="\00D6ffnen"  />')
,p_column_link_attr=>'    target="_blank"'
,p_column_alignment=>'CENTER'
,p_report_column_required_role=>'!'||wwv_flow_imp.id(756418224517528353)
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028881204549292712)
,p_query_column_id=>11
,p_column_alias=>'NACHFOLGER_VORSCHRIFTID'
,p_column_display_sequence=>31
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1028880717890292712)
,p_query_column_id=>12
,p_column_alias=>'MFV'
,p_column_display_sequence=>8
,p_column_heading=>'MfVs'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9426438869390950105)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>wwv_flow_imp.id(3414122116128820546)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_header=>'Vorschrift bearbeiten '
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'SESSION')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028851142195292685)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(6205588740037282195)
,p_button_name=>'BTN_EDIT_LEAD_VKO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Bearbeiten'
,p_button_redirect_url=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:32:P32_VORSCHRIFTID,P32_VORSCHRIFT_TYPID:&P34_VORSCHRIFTID.,&P34_VORSCHRIFT_TYPID.'
,p_button_condition=>'RETURN pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0 AND :P34_VORSCHRIFT_TYPID IN (10,30,40);'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-edit'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1029178473017292928)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(541399329256322071)
,p_button_name=>'ADD_THEMA_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Themen zuordnen'
,p_button_position=>'COPY'
,p_button_redirect_url=>'f?p=&APP_ID.:104:&SESSION.::&DEBUG.:RP,104:P104_NEW_CREATE,P104_EDIT_THEMEN,P104_VORSCHRIFTID:1,1,&P34_VORSCHRIFTID.'
,p_button_condition=>'(:P34_STRG_GETEX_ANZEIGE = 10)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
'f user has wierte acces edit mode '))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028867948527292703)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5702656122314296104)
,p_button_name=>'ADD_LAND'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00E4nder zuordnen')
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.:RP,103:P103_NEW_CREATE,P103_EDIT_LAENDER,P103_VORSCHRIFTID:1,1,&P34_VORSCHRIFTID.'
,p_button_condition=>'(:P34_STRG_GETEX_ANZEIGE != 20 )'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_security_scheme=>wwv_flow_imp.id(756418224517528353)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028863369065292698)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5702656960153296112)
,p_button_name=>'ADD_THEMA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Themen zuordnen'
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:104:&SESSION.::&DEBUG.:RP,104:P104_NEW_CREATE,P104_EDIT_THEMEN,P104_VORSCHRIFTID:1,1,&P34_VORSCHRIFTID.'
,p_button_condition=>'(:P34_STRG_GETEX_ANZEIGE != 20)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_security_scheme=>wwv_flow_imp.id(756418224517528353)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1029178023677292925)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(541399329256322071)
,p_button_name=>'BTN_H_THEMA_1'
,p_button_static_id=>'B487779934025970930'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('\00C4nderungshistorie Thema')
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:357:&SESSION.::&DEBUG.::P357_VORSCHRIFTID:&P34_VORSCHRIFTID.'
,p_button_condition=>'pck_ri.fIsAuthorized(pageId => 357, accessMode => 100)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-history'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028941510573292850)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9413676743982265743)
,p_button_name=>'DELETE_VERKNUEPFUNG'
,p_button_static_id=>'DELETE_VERKNUEPFUNG'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Markierte Verkn\00FCpfungen l\00F6schen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P34_STRG_GETEX_ANZEIGE'
,p_button_condition2=>'20'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_button_css_classes=>'apex_disabled'
,p_icon_css_classes=>'fa-trash-o'
,p_security_scheme=>wwv_flow_imp.id(756418224517528353)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028926218725292788)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9419691149654807307)
,p_button_name=>'ADD_MFV'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:85:&SESSION.::&DEBUG.:RP,85:P85_VORSCHRIFTID,P85_CAME_FROM:&P34_VORSCHRIFTID.,25'
,p_icon_css_classes=>'fa-plus-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028902795295292762)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9426008302536293131)
,p_button_name=>'BTN_EDIT_EINSATZDATEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Edit Einsatzdaten'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:37:P37_VORSCHRIFTID,P37_EINSATZDATUM_MODELLID:&P34_VORSCHRIFTID.,&P34_EINSATZDATUM_MODELLID.#EINSATZDATUM_TYPID#,#VORSCHRIFT_REF_EINSATZDATUM_TYPID##EINSATZDATUM_TYPID#,#VORSCHRIFT_REF_EINSATZDATUM_TYPID#'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028886305297292717)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9426288395056803127)
,p_button_name=>'CREATE_SUPPLEMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:RP,25:P34_PARENT_VORSCHRIFTID,P34_VORSCHRIFT_TYPID,P34_PROCESS_FROM:&P34_VORSCHRIFTID.,20,SUP_CRT'
,p_button_condition=>'instr(UPPER(:P34_VORSCHRIFT_NUMMER), ''UN-R'') > 0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-plus-circle-o'
,p_security_scheme=>wwv_flow_imp.id(756418224517528353)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028875327607292709)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1952421421779429465)
,p_button_name=>'DELETE_AMENDMENT'
,p_button_static_id=>'DELETE_AMENDMENT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Markierte Amendments l\00F6schen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'apex_disabled'
,p_icon_css_classes=>'fa-trash-o'
,p_security_scheme=>wwv_flow_imp.id(756418224517528353)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028851874422292686)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5884384521697244472)
,p_button_name=>'EDIT_VERKNUEPFTE_DATEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Bearbeiten'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:225:&SESSION.::&DEBUG.:225:P225_VORSCHRIFTID:&P34_VORSCHRIFTID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 225, accessMode => 100)',
'and (:P34_EDIT_MODE = 1)'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-pencil'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028845533354292677)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6984700939625258899)
,p_button_name=>'BTN_FUKA_COPY_ASSIST'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Kopierassistent'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:470:&SESSION.::&DEBUG.:470,472,474:P470_ZIEL_VORSCHRIFTID:&P34_VORSCHRIFTID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(pck_ri.fIsAuthorized(pageId => 470, accessMode => 200))',
'AND',
'(:P34_EDIT_MODE = 1)'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028967423601292882)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_button_name=>'GETEX'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('\00C4nderungen zur Pr\00FCfung/\00DCbernahme')
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:29:P29_VORSCHRIFTID,P29_CAMEFROM:&P34_VORSCHRIFTID.,25'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'    :P34_IMPORT_STATUS = 20',
'    and :P34_ROWID is not null',
'    and pck_ri.fIsUserInRolle(listRolleId => ''1003:1100:1000'') > 0  -- 1003 = Fachadmin, 1100 =  Getex Migration, 1000 = VKO',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_cattributes=>unistr('title="In Getex 2 wurden Daten ge\00E4ndert - mit dem Assistenten k\00F6nnen diese ge\00E4nderten Daten in RegIndex \00FCbernommen werden."')
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028941097060292850)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(9413676743982265743)
,p_button_name=>'CREATE_VERKNUEPFUNG'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.:RP,45:P45_VORGAENGER_VORSCHRIFTID,P45_MASTER:&P34_VORSCHRIFTID.,&P34_STRG_GETEX_ANZEIGE.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(pck_ri.fIsAuthorized(pageId => 45, accessMode => 200)',
'',
') and (:P34_STRG_GETEX_ANZEIGE != 20 )'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-plus-circle-o'
,p_security_scheme=>wwv_flow_imp.id(756418224517528353)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028925882876292788)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(9419691149654807307)
,p_button_name=>'BTN_H_MFV'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('\00C4nderungshistorie MfVs')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:353:&SESSION.::&DEBUG.::P353_VORSCHRIFTID:&P34_VORSCHRIFTID.'
,p_button_condition=>'pck_ri.fIsAuthorized(pageId => 353, accessMode => 100)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-history'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028902353899292761)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(9426008302536293131)
,p_button_name=>'BTN_H_EINSATZDATEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('\00C4nderungshistorie Einsatzdaten')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:351:&SESSION.::&DEBUG.::P351_VORSCHRIFTID:&P34_VORSCHRIFTID.'
,p_button_condition=>'pck_ri.fIsAuthorized(pageId => 351, accessMode => 100)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-history'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028874982186292709)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1952421421779429465)
,p_button_name=>'CREATE_AMENDMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.:45:P45_VORGAENGER_VORSCHRIFTID,P45_BEZIEHUNG_ART,P45_AMENDMENTID,P45_MASTER:&P34_VORSCHRIFTID.,20,20,&P34_STRG_GETEX_ANZEIGE.'
,p_button_condition=>'instr(UPPER(:P34_VORSCHRIFT_NUMMER), ''UN-R'') = 0 and (:P34_STRG_GETEX_ANZEIGE != 20 )'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-plus-circle-o'
,p_security_scheme=>wwv_flow_imp.id(756418224517528353)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028867558041292703)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(5702656122314296104)
,p_button_name=>'BTN_H_LAND'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('\00C4nderungshistorie Land')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:356:&SESSION.::&DEBUG.::P356_VORSCHRIFTID:&P34_VORSCHRIFTID.'
,p_button_condition=>'pck_ri.fIsAuthorized(pageId => 356, accessMode => 100)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-history'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028862917960292698)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(5702656960153296112)
,p_button_name=>'BTN_H_THEMA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('\00C4nderungshistorie Thema')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:357:&SESSION.::&DEBUG.::P357_VORSCHRIFTID:&P34_VORSCHRIFTID.'
,p_button_condition=>'pck_ri.fIsAuthorized(pageId => 357, accessMode => 100)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-history'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028859567132292695)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(5707933684500382675)
,p_button_name=>'B_NOLIS_MYNET'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Nolis Mynet'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028845204849292677)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6984700939625258899)
,p_button_name=>'BTN_MANAGE_FUNKTIONEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Funktionen zuordnen'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:343:&SESSION.::&DEBUG.:RP,343:P343_CAME_FROM,P343_VORSCHRIFTID:25,&P34_VORSCHRIFTID.'
,p_button_condition=>'pck_ri.fIsAuthorized(pageId => 343, accessMode => 200)    and :P34_EDIT_MODE = 1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-pencil'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028940666880292849)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(9413676743982265743)
,p_button_name=>'BTN_H_VERKNUEPFUNGEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('\00C4nderungshistorie Einsatzdaten')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:352:&SESSION.::&DEBUG.::P352_VORSCHRIFTID:&P34_VORSCHRIFTID.'
,p_button_condition=>'pck_ri.fIsAuthorized(pageId => 352, accessMode => 100)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-history'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028874611697292709)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1952421421779429465)
,p_button_name=>'BTN_H_AMENDMENTS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('\00C4nderungshistorie Amendments')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:352:&SESSION.::&DEBUG.::P352_VORSCHRIFTID,P352_AMENDMENTID:&P34_VORSCHRIFTID.,20'
,p_button_condition=>'pck_ri.fIsAuthorized(pageId => 352, accessMode => 100)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-history'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028859191423292695)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(5707933684500382675)
,p_button_name=>'BTN_H_VERLINKTE_NORMEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('\00C4nderungshistorie Verlinkte Normen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:354:&SESSION.::&DEBUG.::P354_VORSCHRIFTID:&P34_VORSCHRIFTID.'
,p_button_condition=>'pck_ri.fIsAuthorized(pageId => 354, accessMode => 100)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-history'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028967078295292882)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_button_name=>'BTN_CREATE_MESSAGE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Erstelle Benachrichtigung'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:617:&SESSION.::&DEBUG.:617:P617_VORSCHRIFTID:&P34_VORSCHRIFTID.'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P34_VORSCHRIFTID is not null and (PCK_RI.fIsAuthorized(pageId => 617,',
'                      accessMode => 100))'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028966658954292881)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_button_name=>'BTN_COPY_PERMALINK'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Permalink in Zwischenablage kopieren'
,p_button_position=>'EDIT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P34_VORSCHRIFTID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028966254911292881)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_button_name=>'JIRA_TICKET_ASSIST'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Jira Ticket Assistent'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:581:&SESSION.::&DEBUG.:570, 571, 572,573, 574,581:P572_VORSCHRIFTEN_SEL:&P34_VORSCHRIFTID.'
,p_button_condition=>':P34_VORSCHRIFT_FREIGABESTATUSID >1 and :P34_VORSCHRIFTID is not null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028965826232292880)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_button_name=>'P34_BTN_CREATE_JIRA_TICKET'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'BETA Jira-Ticket erstellen'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028965451172292880)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_button_name=>'P34_BTN_CREATE_JIRA_TICKET_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Jira-Ticket erstellen (Dialog)'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:185:&SESSION.::&DEBUG.:RP:P185_VORSCHRIFTID:&P34_VORSCHRIFTID.'
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028967821893292882)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_button_name=>'BTN_KERNDATEN_BEARBEITEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Kerndaten Bearbeiten'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:31:P31_VORSCHRIFTID,P31_ROWID:&P34_VORSCHRIFTID.,&P34_ROWID.'
,p_icon_css_classes=>'fa-edit'
,p_button_comment=>':G_BENUTZERID = 15643'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028965039201292880)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_button_name=>'BTN_H_COREDATA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('\00C4nderungshistorie Kerndaten')
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:350:&SESSION.::&DEBUG.:RP,350:P350_VORSCHRIFTID:&P34_VORSCHRIFTID.'
,p_button_condition=>'pck_ri.fIsAuthorized(pageId => 350, accessMode => 100)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-history'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028880042798292711)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9426438869390950105)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Zur\00FCck zur Vorschriftenliste')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:::'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028879690415292711)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(9426438869390950105)
,p_button_name=>'CHANGE_FREIGABE_STATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Freigabe Status \00E4ndern')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
':P34_ROWID is not null',
'and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0  -- Rolle VKO/Fachadmin',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028879286421292711)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(9426438869390950105)
,p_button_name=>'EDIT_ENABLE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Bearbeitung aktivieren'
,p_button_position=>'NEXT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P34_ROWID is not null',
'and:P34_EDIT_MODE is null',
'and (',
unistr('    pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1200:1080'') > 0 -- Wenn Fachadmin/VKO/Redaktionsteam/Inaktive Funktionen, dann Bearbeitung immer m\00F6glich'),
'    or (pck_ri.fIsUserInRolle(listRolleId => ''1001:1002'') > 0 and :P34_VORSCHRIFT_FREIGABESTATUSID in (10,30)))'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_css_classes=>'EDIT_ENABLE'
,p_icon_css_classes=>'fa-edit'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P34_ROWID is not null',
'and:P34_EDIT_MODE is null',
'and (',
unistr('    pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1200:1080'') > 0 -- Wenn Fachadmin/VKO/Redaktionsteam/Inaktive Funktionen, dann Bearbeitung immer m\00F6glich'),
'    or (pck_ri.fIsUserInRolle(listRolleId => ''1001:1002'') > 0 and :P34_VORSCHRIFT_FREIGABESTATUSID in (10,30)))'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028878855938292711)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(9426438869390950105)
,p_button_name=>'EDIT_DISABLE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Bearbeitung abbrechen'
,p_button_position=>'NEXT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
':P34_ROWID is not null and (pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) ',
'                            or pck_ri.fIsUserInRolle(listRolleId => ''1002:1001:1200'') > 0) -- Rolle VEX: ZVEX : Reduktionsteam',
'                           and :P34_EDIT_MODE is not null',
'',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-minus-circle-o'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
':P34_ROWID is not null and (pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) ',
'                            or pck_ri.fIsUserInRolle(listRolleId => ''1002:1001:1200'') > 0) -- Rolle VEX: ZVEX : Reduktionsteam',
'                           and :P34_EDIT_MODE is not null',
'',
')'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028878480190292711)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(9426438869390950105)
,p_button_name=>'COPY'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Vorschrift kopieren'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:540:&SESSION.::&DEBUG.:540, 544, 541, 542, 545:P540_SOURCE_VORSCHRIFTID:&P34_VORSCHRIFTID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
':P34_ROWID is not null and  pck_ri.fIsUserInRolle(listRolleId => ''1080'')>0 ',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-copy'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028878087148292711)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(9426438869390950105)
,p_button_name=>'LNK_NETZ'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Baumansicht'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa fa-network-hub'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028877652320292710)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(9426438869390950105)
,p_button_name=>'DELETE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0 and :P34_VORSCHRIFTID is not null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-trash-o'
,p_database_action=>'DELETE'
,p_button_comment=>','
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028877303696292710)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(9426438869390950105)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'((:P34_ROWID is not null or :P34_Vorschriftid is not null) and (pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) ',
'                            or pck_ri.fIsUserInRolle(listRolleId => ''1002:1001:1200'') > 0)) -- Rolle VEX, ZVEX',
'    and :P34_EDIT_MODE = 1',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1028876850549292710)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(9426438869390950105)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P34_ROWID is NULL and :P34_VORSCHRIFTID is null',
' and ( pck_ri.fIsUserInRolle(listRolleId => ''1080'')>0 ) )'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1028752634860292585)
,p_branch_name=>'Redirect nach Erstellung Supplement'
,p_branch_action=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1028876850549292710)
,p_branch_sequence=>10
,p_branch_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1028753875012292586)
,p_branch_name=>'redirect to Freigabestatus Dialog'
,p_branch_action=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:28:P28_VORSCHRIFTID:&P34_VORSCHRIFTID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1028879690415292711)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1028752249267292584)
,p_branch_name=>'redirect to_parent- create'
,p_branch_action=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:34:P34_VORSCHRIFTID,P34_PROCESS_FROM:&P34_PARENT_VORSCHRIFTID.,1&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1028876850549292710)
,p_branch_sequence=>30
,p_branch_condition_type=>'ITEM_IS_NOT_NULL'
,p_branch_condition=>'P34_PROCESS_FROM'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1028753457966292585)
,p_branch_name=>unistr('Branch ung\00FCltige VorschriftID')
,p_branch_action=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
,p_branch_condition_type=>'NOT_EXISTS'
,p_branch_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from t_vorschrift vs',
'where (vs.vorschriftid = :P34_VORSCHRIFTID or (:P34_VORSCHRIFTID is null and :P34_ROWID is null))',
'and (',
'    ',
'       (vs.vorschrift_freigabestatusid = -1 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0) -- Wenn Status "Imported", dann VKO/Fachadmin',
unistr('    or (vs.vorschrift_freigabestatusid = 1 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0) -- Wenn Status "Grundbef\00FCllung", dann VKO/Fachadmin'),
unistr('    or (vs.vorschrift_freigabestatusid = 10 and pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002:1001:1040:1006'') > 0) -- Wenn Status "in Bearbeitung" dann sichtbar f\00FCr Fachadmin, VKO, VEX, ZVEX, KFEX, GBEX'),
unistr('    or (vs.vorschrift_freigabestatusid = 20) -- Wenn Status "freigegeben", dann sichtbar f\00FCr alle'),
unistr('    or (vs.vorschrift_freigabestatusid = 30 and pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002:1001'') > 0) -- Wenn Status "nicht relevant", dann sichtbar f\00FCr Fachadmin, VKO, VEX, ZVEX'),
')'))
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1028753049490292585)
,p_branch_name=>'REDIRECT_AFTER_DELETE'
,p_branch_action=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:RP,20,25::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'REQUEST_EQUALS_CONDITION'
,p_branch_condition=>'DELETE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1030054176630286891)
,p_name=>'P34_ERW_LAND_ANZEIGE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(494103106877030562)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_lnd_erweit as (',
'  select distinct gvl.v_id, v.vorschriftid ',
'  from mv_getex_vorschrift_land gvl      ',
'  join T_land la on (la.iso_code_3 = gvl.iso_code3 and la.cockpit_erw_anzeige > 0) ',
'  join t_vorschrift v on (v.regindexid is not null and v.regindexid = gvl.v_id) ',
'  where nvl(la.cockpit_erw_anzeige, 0) > 0',
'  and v.vorschriftid = :P34_VORSCHRIFTID ',
')',
'select case when (select count(vorschriftid) from cte_lnd_erweit) > 0',
'            then ''Ja''',
'            else ''No''',
'       end as co',
'from dual;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1029177713992292914)
,p_name=>'P34_DATUM_ANGABE_AS_MJ'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(541399329256322071)
,p_item_default=>'0'
,p_prompt=>'Datumsformat Modelljahr ?'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mj_schalter_status from t_vorschrift ',
'where vorschriftid = :P34_vorschriftID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Ja;1,Nein;0'
,p_display_when=>'P34_EINSATZDATUM_MODELLID'
,p_display_when2=>'30'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'declare',
'l_value number;',
'begin',
'',
'if :P34_STRG_GETEX_ANZEIGE =20 then l_value :=0;',
'elsif :P34_STRG_GETEX_ANZEIGE !=20 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0  then',
' l_value :=1;',
'else l_value :=0;',
'end if;',
'',
'if l_value =0 then return (true);',
'else return(false);',
'end if;',
'',
'end;',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'read only item ! = value edit mode  1 ',
'',
'',
'',
'',
'',
'declare',
'l_value number;',
'begin',
'',
'if :P34_STRG_GETEX_ANZEIGE =20 then l_value :=0;',
'elsif :P34_STRG_GETEX_ANZEIGE !=20 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0  then',
' l_value :=1;',
'else l_value :=0;',
'end if;',
'',
'if l_value =0 then return (true);',
'else return(false);',
'end if;',
'',
'end;',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1029177257378292910)
,p_name=>'P34_PHASEIN_ENTHALTEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(541399329256322071)
,p_use_cache_before_default=>'NO'
,p_prompt=>'<b><font size="3">Sind Phase in''s enthalten?</font></b>'
,p_source=>'PHASEIN_ENTHALTEN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:;1'
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_display_when=>'P34_EINSATZDATUM_MODELLID'
,p_display_when2=>'30'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_value number;',
'begin',
'',
'if :P34_STRG_GETEX_ANZEIGE =20 then l_value :=0;',
'elsif :P34_STRG_GETEX_ANZEIGE !=20 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0  then',
' l_value :=1;',
'else l_value :=0;',
'end if;',
'',
'if l_value =0 then return (true);',
'else return(false);',
'end if;',
'',
'end;'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_value number;',
'begin',
'',
'if :P34_STRG_GETEX_ANZEIGE =20 then l_value :=0;',
'elsif :P34_STRG_GETEX_ANZEIGE !=20 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0  then',
' l_value :=1;',
'else l_value :=0;',
'end if;',
'',
'if l_value =0 then return (true);',
'else return(false);',
'end if;',
'',
'end;'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1029176850524292910)
,p_name=>'P34_DATUM_ANGABE_AS_MJ_1'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(541399329256322071)
,p_item_default=>'0'
,p_prompt=>'Datumsformat Modelljahr ?'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mj_schalter_status from t_vorschrift ',
'where vorschriftid = :P34_vorschriftID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Ja;1,Nein;0'
,p_display_when_type=>'NEVER'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_value number;',
'begin',
'',
'if :P34_STRG_GETEX_ANZEIGE =20 then l_value :=0;',
'elsif :P34_STRG_GETEX_ANZEIGE !=20 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0  then',
' l_value :=1;',
'else l_value :=0;',
'end if;',
'',
'if l_value =0 then return (true);',
'else return(false);',
'end if;',
'',
'end;',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'read only item ! = value edit mode  1 ',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028964695826292880)
,p_name=>'P34_PERMALINK'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.host_url(''SCRIPT'') || apex_page.get_url(',
'    p_application => :APP_ALIAS',
'    , p_page => ''VORSCHRIFT''',
'    , p_items => ''P34_VORSCHRIFTID''',
'    , p_values => :P34_VORSCHRIFTID',
'    , p_session => null',
'    , p_clear_cache => ''25''',
')'))
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028964240580292879)
,p_name=>'P34_IMPORT_STATUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_item_default=>'30'
,p_prompt=>'Getex Aktualisierung'
,p_source=>'select status_update_getex from t_vorschrift where vorschriftid = :P34_VORSCHRIFTID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_IMPORT_STATUS_GETZEX'
,p_lov=>'.'||wwv_flow_imp.id(799385323802234434)||'.'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Server-Side Condition for Visibility',
'-- Show for Fachadmin, ',
'-- Fachadmin, Getex Migration, VKO',
'pck_ri.fIsUserInRolle(listRolleId => ''1003:1100:1000'') > 0'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028963846176292878)
,p_name=>'P34_MASTER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_item_default=>'10'
,p_prompt=>unistr('Master f\00FCr diese Vorschrift')
,p_source=>'MASTER'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>unistr('STATIC2:Master in GETEX;20,Master in RegIndex;10,Master in GETEX + automatische \00DCbernahme;30')
,p_begin_on_new_line=>'N'
,p_grid_column=>7
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  (',
'  ( pck_ri.fIsUserInRolle(listRolleId => ''1003:1200'') > 0) -- Fachadmin, Redaktionsteam',
') = false',
'',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
'    or (:P34_IMPORT_STATUS = 30 )  ',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--read only on 20.02.2024',
'',
'(',
'  (  --pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'                            pck_ri.fIsUserInRolle(listRolleId => ''1000:1002:1001:1003'') > 0) -- Rolle VKO, VEX, ZVEX, Fachadm',
') = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
'',
'',
'',
'--- server side ',
'',
'-- Server-Side Condition for Visibility',
'-- Show for Fachadmin, VKO, and GETEX-Migration',
'--pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1100'') > 0',
'',
'',
'',
'',
'-- read only on 21.02.2024',
'(',
'  (  --pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'                            pck_ri.fIsUserInRolle(listRolleId => ''1000:1002:1001:1003:1100'') > 0) -- Rolle VKO, VEX, ZVEX, Fachadm',
') = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
'',
'',
'',
'',
'---- server side 9 augu fridat 9:39 am ',
'',
'-- Server-Side Condition for Visibility',
'-- Show for Fachadmin only,',
'pck_ri.fIsUserInRolle(listRolleId => ''1002:1003:1200:1000:1100'') > 0'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028963478022292877)
,p_name=>'P34_DMS_DISPLAY'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028963055401292876)
,p_name=>'P34_NORM_BEISPIEL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028962658838292876)
,p_name=>'P34_LINK'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028962238807292875)
,p_name=>'P34_VORSCHRIFT_TYPID'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Vorschrift Typ'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1100)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'VORSCHRIFT_TYPID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VORSCHRIFT_TYP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung ',
'        ELSE name_eng',
'    END AS d,',
'    vorschrift_typid AS r',
'FROM t_vorschrift_typ',
'ORDER BY 2;',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>6
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'   (  pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'            (    pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0',
'                   OR ( pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0 and :P34_VORSCHRIFTID is null) -- on "create"  f. Rolle Inaktive F.',
'            )',
'    ) ',
'',
') = false',
'  or ',
'(  ',
'   (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
')',
'',
'or (:P34_STRG_GETEX_ANZEIGE = 20 )'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- (pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0) =false',
'--     or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
'--  and  (:P34_STRG_GETEX_ANZEIGE = 20)',
'',
'',
'(pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
') or (:P34_STRG_GETEX_ANZEIGE = 20 )',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028961821995292874)
,p_name=>'P34_EINSATZDATUM_MODELLID'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Einsatz DATUM Modell'
,p_source=>'EINSATZDATUM_MODELLID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN MODELL',
'        ELSE MODELL_ENG',
'    END AS MODELL, ',
'    EINSATZDATUM_MODELLID',
'FROM T_EINSATZDATUM_MODELL ',
'ORDER BY 2;',
''))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_grid_column=>7
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
') or (:P34_STRG_GETEX_ANZEIGE = 20 )'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028961429979292874)
,p_name=>'P34_PARENT_VORSCHRIFTID'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('\00DCbergeordnete Vorschrift')
,p_post_element_text=>unistr('<a alt="\00DCbergeordnete Vorschrift \00F6ffnen" title="\00DCbergeordnete Vorschrift \00F6ffnen" style="margin-left: 5px" class="a-Button a-Button--icon" href="#" target="_blank" id="bLinkParent"><span class="fa fa-search"></span></a>')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vrv.vorgaenger_vorschriftid',
'from t_vorschrift_ref_vorschrift vrv',
'where vrv.nachfolger_vorschriftid = :P34_VORSCHRIFTID',
'and vrv.BEZIEHUNG_ART = (case when :P34_VORSCHRIFT_TYPID = 20 then 30 else 20 end)',
'and :P34_VORSCHRIFT_TYPID = 20 -- parents gibts nur bei Supplements',
'fetch first row only'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select VORSCHRIFT_NUMMER || '' - '' || VORSCHRIFT_BEZEICHNUNG d,',
'       VORSCHRIFTID as r',
'  from T_VORSCHRIFT where vorschrift_typid !=20  -- supplement is not allowed as parent',
'  and (:P34_VORSCHRIFT_NUMMER is null  or VORSCHRIFT_NUMMER != :P34_VORSCHRIFT_NUMMER)',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_grid_column=>7
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'DIALOG',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028961115286292873)
,p_name=>'P34_NORMID'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1016'
,p_prompt=>'Notation Vorschrift'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1101)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'NORMID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_NOTATION'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_la as (',
'    select ',
'        normid,',
'        nvl(listagg(trim(la.b_nummer), '', '') within group (order by la.b_nummer),null) as laender_nummer,',
'        nvl(listagg(trim(CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN la.LAND ELSE la.LAND_ENG END), '', '') within group (order by la.LAND),null) as laender_name',
'    from t_norm_ref_land nrl',
'    left outer join t_land la on nrl.landid = la.landid',
'    group by normid',
')',
'select ',
'    n.normid, ',
'    n.bezeichnung "BEZEICHNUNG",',
'    cte_la.laender_nummer "B_NUMMER",',
'    cte_la.laender_name "LAND"',
'from "#OWNER#"."T_NORM" n',
'left outer join cte_la on cte_la.normid = n.normid',
'where n.normid not in (1016)',
'order by n.BEZEICHNUNG asc;'))
,p_cSize=>30
,p_colspan=>6
,p_display_when_type=>'NEVER'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_inline_help_text=>'abc'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028960677325292873)
,p_name=>'P34_VORSCHRIFT_NUMMER'
,p_is_required=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Vorschriftennummer'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1102)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'VORSCHRIFT_NUMMER'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>250
,p_begin_on_new_line=>'N'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
') or (:P34_STRG_GETEX_ANZEIGE = 20 )'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>'OK'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028960310599292873)
,p_name=>'P34_DOKUMENTENDATUM'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Dokumentendatum'
,p_source=>'DOKUMENTENDATUM'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_display_when=>'P34_VORSCHRIFTID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028959854627292872)
,p_name=>'P34_WITHOUT_NORM_VALIDATION'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Notation nicht validieren'
,p_source=>'WITHOUT_NORM_VALIDATION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC(,):&nbsp; 1'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('W\00E4hle die Checkbox, wenn die ausgew\00E4hlte Notation nicht validiert werden soll.'),
unistr('In diesem Fall wird automatisch eine Benachrichtigung f\00FCr die Fachadministratoren erstellt.')))
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028959049466292865)
,p_name=>'P34_TITEL_KURZ'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Title Kurz'
,p_source=>'TITEL_KURZ'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'( --pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'   -- or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
'  --) or (:P34_STRG_GETEX_ANZEIGE = 20 )',
'true',
')'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028958649841292864)
,p_name=>'P34_VORSCHRIFT_BEZEICHNUNG'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Title English (\00DCberschrift)')
,p_source=>'VORSCHRIFT_BEZEICHNUNG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>500
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
') or (:P34_STRG_GETEX_ANZEIGE = 20 )'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028958306680292864)
,p_name=>'P34_VORSCHRIFT_BEZEICHNUNG_DEUTSCH'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_source=>'VORSCHRIFT_BEZEICHNUNG_DEUTSCH'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when_type=>'NEVER'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028957895669292863)
,p_name=>'P34_ROWID'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_source=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028957478834292863)
,p_name=>'P34_PROGNOSE_QUALITAETID'
,p_is_required=>true
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Prognosequalit\00E4t Einsatztermine')
,p_post_element_text=>'&nbsp;<span onclick="redirect(1103)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'PROGNOSE_QUALITAETID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VORSCHRIFT_PROGNOSE_QUALITAET'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''offen'', ''open'') AS display_value,',
'        0 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''sicher'', ''secure'') AS display_value,',
'        10 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'    ',
'    UNION ALL',
'    ',
'    SELECT ',
unistr('        emano_util.fLang(''absch\00E4tzbar'', ''estimable'') AS display_value,'),
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_cHeight=>1
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'(',
'      --pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'    (   pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0 -- Rolle VKO, Fachadm',
'            OR ( pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0 and :P34_VORSCHRIFTID is null) -- on "create"  f. Rolle Inaktive F.',
'    )',
'    ',
') = false',
'  or ',
'(  ',
'   (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
')',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'--   or ',
'-- (  ',
'--    (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
'-- )',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028957063113292863)
,p_name=>'P34_FAHRZEUGKLASSE1'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(fahrzeugklasseid, '':'')',
'from t_vorschrift_ref_fahrzeugklasse',
'where vorschriftid = :P34_VORSCHRIFTID'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028956713154292862)
,p_name=>'P34_FAHRZEUGKLASSE'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fahrzeugart'
,p_post_element_text=>'&nbsp;<span onclick="redirect(400)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(fahrzeugklasseid, '':'')',
'from t_vorschrift_ref_fahrzeugklasse',
'where vorschriftid = :P34_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung d, fahrzeugklasseid r',
'from t_fahrzeugklasse',
'order by bezeichnung asc'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>'nvl(:P34_VORSCHRIFT_TYPID,10) != 20'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'  or   (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
') ',
'or (:P34_STRG_GETEX_ANZEIGE = 20 )',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028956302520292862)
,p_name=>'P34_FAHRZEUGKLASSE_SUPP'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_prompt=>'Fahrzeugklassen'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(fk.bezeichnung, '', '')',
'from t_vorschrift_ref_fahrzeugklasse vrf',
'join t_fahrzeugklasse fk on (fk.fahrzeugklasseid = vrf.fahrzeugklasseid)',
'where vorschriftid = :P34_PARENT_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P34_VORSCHRIFT_TYPID'
,p_display_when2=>'20'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028955904520292862)
,p_name=>'P34_VORSCHRIFT_FREIGABESTATUSID'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1'
,p_prompt=>'Interner DB Freigabestatus'
,p_post_element_text=>'&nbsp;<span onclick="redirect(281)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_source=>'VORSCHRIFT_FREIGABESTATUSID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VORSCHRIFT_FREIGABE_STATUS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vorschrift_freigabestatusid as actual_value, emano_util.fLang(name_deutsch,name_englisch) as display_value',
'from t_vorschrift_freigabestatus',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028955501346292861)
,p_name=>'P34_VORSCHRIFT_STATUSID'
,p_is_required=>true
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_item_default=>'20'
,p_prompt=>'Status der Vorschrift'
,p_post_element_text=>'&nbsp;<span onclick="redirect(181)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'VORSCHRIFT_STATUSID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select status, vorschrift_statusid',
'from t_vorschrift_status',
'order by 2'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
') or (:P34_STRG_GETEX_ANZEIGE = 20 )'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028955017448292861)
,p_name=>'P34_RXSWIN'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_item_default=>'20'
,p_prompt=>'Potentiell SUMS-relevant'
,p_post_element_text=>'&nbsp;<span onclick="redirect(184)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_source=>'RXSWIN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nicht gepruft'', ''Not checked'') AS display_value,',
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_colspan=>2
,p_grid_column=>1
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  1 from t_vorschrift tv',
' where (tv.publisher = ''UNECE'' ',
' or tv.vorschriftid in (select distinct (vrl.vorschriftid)   ',
'                        from t_vorschrift_ref_land vrl',
'left outer join t_land la on (vrl.landid = la.landid)',
'where vrl.vorschriftid = tv.vorschriftid and vrl.geloescht !=1',
'and SUMS_RELEVANT =10))',
'and tv.vorschriftid = :P34_VORSCHRIFTID',
'and pck_ri.fIsUserInRolle(listRolleId => ''1000:1002:1003'') > 0',
'and :P34_EDIT_MODE is not  null',
'--and (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
'',
'',
''))
,p_read_only_when_type=>'NOT_EXISTS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'expression ',
'(',
'  ( -- pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'                            pck_ri.fIsUserInRolle(listRolleId => ''1000:1002:1003'') > 0) -- Rolle VKO, VEX, ZVEX, Fachadm',
') = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
'',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028954640293292861)
,p_name=>'P34_SWR_HAUPTUMSETZENDE_OE'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'OE2 des REV'
,p_post_element_text=>'&nbsp;<span onclick="redirect(461)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_source=>'SWR_HAUPTUMSETZENDE_OE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct swr_hauptumsetzende_oe ',
'  from t_vorschrift',
' where swr_hauptumsetzende_oe is not null'))
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_grid_column=>3
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'  (  ',
'      pck_ri.fIsUserInRolle(listRolleId => ''1000:1002:1003'') > 0 ) -- Rolle VKO, VEX, Fachadm',
') = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'fetch_on_type', 'N',
  'match_type', 'CONTAINS_IGNORE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028954222387292861)
,p_name=>'P34_COP_RELEVANT'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_item_default=>'20'
,p_prompt=>'CoP Relevant'
,p_post_element_text=>'&nbsp;<span onclick="redirect(201)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_source=>'COP_RELEVANT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nicht gepruft'', ''Not checked'') AS display_value,',
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_begin_on_new_line=>'N'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'  (  ',
'       pck_ri.fIsUserInRolle(listRolleId => ''1000:1001:1002:1003'') > 0) -- Rolle VKO, VEX, ZVEX, Fachadm',
') = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'  (  ',
'       pck_ri.fIsUserInRolle(listRolleId => ''1000:1002:1003'') > 0) -- Rolle VKO, VEX, ZVEX, Fachadm',
') = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028953875107292860)
,p_name=>'P34_HOMOLOGATIONSRELEVANT'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_item_default=>'20'
,p_prompt=>'Homologationsrelevant'
,p_post_element_text=>'&nbsp;<span onclick="redirect(282)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_source=>'HOMOLOGATIONSRELEVANT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nicht gepruft'', ''Not checked'') AS display_value,',
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'  (  pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'                            pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0) -- Rolle VKO, Fachadm',
') = false',
'  or ',
'(  ',
'   (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
')',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028953430178292860)
,p_name=>'P34_HOMOLOGATIONSEIGENSCHAFTEN'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Homologationseigenschaften'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    select distinct e.EIGENSCHAFT_KENNUNG || ''-'' || et.kuerzel || ''-'' || e.eigenschaft as eigenschaft',
'    from t_vorschrift_ref_thema vtl',
'    join carmah2_admin.t_eigenschaft_ref_regindexthemen err on (vtl.themaid = err.regindex_themen_id)',
'    join carmah2_admin.t_eigenschaft e on (err.eigenschaft_id = e.eigenschaft_id)',
'    join carmah2_admin.t_eigenschaft_typ et on (e.eigenschaft_typ_id = et.eigenschaft_typ_id)',
'    where vtl.vorschriftid = :P34_VORSCHRIFTID and geloescht = 0',
')',
'select listagg(eigenschaft,'', '') within group (order by eigenschaft)',
'from cte1',
'',
'',
'',
'--e.EIGENSCHAFT_KENNUNG || ''-'' || et.kuerzel || ''-'' || e.eigenschaft'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028953088130292860)
,p_name=>'P34_REV_NOTWENDIG'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_item_default=>'10'
,p_prompt=>'REV Notwendig'
,p_post_element_text=>'&nbsp;<span onclick="redirect(202)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_source=>'REV_NOTWENDIG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_REV_NOTWENDIG'
,p_lov=>'.'||wwv_flow_imp.id(646432047862271176)||'.'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'  (  pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'                            pck_ri.fIsUserInRolle(listRolleId => ''1000:1002:1003'') > 0) -- Rolle VKO, VEX, Fachadm',
') = false',
'  or ',
'(  ',
'   (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
')',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028952704190292860)
,p_name=>'P34_BEMERKUNG'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Bemerkung zur Vorschrift'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1104)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'BEMERKUNG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>1024
,p_cHeight=>4
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'  (  pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'             (  pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0',
'                OR ( pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0 and :P34_VORSCHRIFTID is null) -- on "create"  f. Rolle Inaktive F.',
'            )',
'    ) -- Rolle VKO, Fachadm',
') = false',
'  or ',
'(  ',
'   (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
')',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028952305892292859)
,p_name=>'P34_BEMERKUNG_ENGLISCH'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Bemerkung zur Vorschrift English'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1104)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'BEMERKUNG_ENGLISCH'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_begin_on_new_line=>'N'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'  (  pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'        ( pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0',
'          OR ( pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0 and :P34_VORSCHRIFTID is null) -- on "create"  f. Rolle Inaktive F.',
'         )',
'  ) -- Rolle VKO, Fachadm',
') = false',
'  or ',
'(  ',
'   (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
')',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028951827698292859)
,p_name=>'P34_GETEX_URL'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Zum Dokument (GETEX2-URL)'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pck_ri.fcreateLinkIfUrl(url_getex_vorschrift, 512)',
'from t_vorschrift ',
'where vorschriftid = :P34_VORSCHRIFTID ',
'/*select pck_ri.fcreateLinkIfUrl(rev_DisplayURL, 160)',
'from mv_getex_vorschrift ',
'--where rev_regindexid  =:P34_VORSCHRIFTID;',
'where reg_id = (select regindexid from t_vorschrift where vorschriftid = :P34_VORSCHRIFTID);*/'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="text-decoration: underline; text-decoration-style: dashed"'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028951506095292857)
,p_name=>'P34_LINK_ZUR_VORSCHRIFT_DMS'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu DMS (Ein Link pro Zeile)'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1105)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'LINK_ZUR_VORSCHRIFT_DMS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>1024
,p_cHeight=>3
,p_display_when=>'P34_EDIT_MODE'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'--     or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
'--     or :P34_STRG_GETEX_ANZEIGE = 20',
'',
'(',
'  (  pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'       pck_ri.fIsUserInRolle(listRolleId => ''1000'') > 0) -- Rolle VKO',
') = false',
'  or ',
'(  ',
'   (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
')',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>'&nbsp;'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028951070603292857)
,p_name=>'P34_LINK_ZUR_VORSCHRIFT_DMS_RO'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu DMS'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1105)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PCK_RI.fCreateLinkIfUrl(v.link_zur_vorschrift_dms, 80)',
'from t_vorschrift v',
'where v.vorschriftid = :P34_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="text-decoration: underline; text-decoration-style: dashed"'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_display_when=>'P34_EDIT_MODE'
,p_display_when_type=>'ITEM_IS_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028950694506292857)
,p_name=>'P34_LINK_REQMAN_RO'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu REQMAN'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1107)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PCK_RI.fCreateLinkIfUrl(v.link_reqman, 80)',
'from t_vorschrift v',
'where v.vorschriftid = :P34_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="text-decoration: underline; text-decoration-style: dashed"'
,p_display_when=>'false'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'N')).to_clob
,p_item_comment=>'resd only - tem is null - edit mode '
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028950222497292857)
,p_name=>'P34_LINK_REQMAN'
,p_item_sequence=>390
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu ReqMan (Ein Link pro  Zeile)'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1107)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'LINK_REQMAN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>1024
,p_cHeight=>3
,p_display_when_type=>'NEVER'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
'    or :P34_STRG_GETEX_ANZEIGE = 20',
'',
'',
'',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>'&nbsp;'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
'    or :P34_STRG_GETEX_ANZEIGE = 20',
'',
'',
'',
'server side edut mode itme is not  null ',
'',
'',
'',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028949836762292857)
,p_name=>'P34_LINK_ZUR_VORSCHRIFT_GETEX'
,p_item_sequence=>400
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Getex 1.0 ID'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1106)" style="font-size:2em" class="fa fa-info-square-o"></span><a style="margin-left: 5px; margin-top: 5px" href="https://getex.wob.vw.vwg/web/guest/dokumente_suche" target="_blank"><button class="t-Button" type="button'
||unistr('">Getex 1.0 \00F6ffnen</button></a>')
,p_source=>'LINK_ZUR_VORSCHRIFT_GETEX'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>20
,p_cMaxlength=>1024
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
'    or (:P34_STRG_GETEX_ANZEIGE = 20 )'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
'    or (:P34_STRG_GETEX_ANZEIGE = 20 )'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028949491011292856)
,p_name=>'P34_WEBSITEID'
,p_item_sequence=>410
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Webseite'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1106)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'WEBSITEID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT w.WEBSITE_NAME, w.WEBSITEID',
'FROM T_WEBSITE w',
'ORDER BY 1',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when_type=>'NEVER'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028949063822292856)
,p_name=>'P34_WEBSITELINK'
,p_item_sequence=>420
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu Web Site'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1108)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>'WEBSITELINK'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>200
,p_cMaxlength=>800
,p_begin_on_new_line=>'N'
,p_display_when=>'P34_EDIT_MODE'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
'    or :P34_STRG_GETEX_ANZEIGE = 20',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028948634092292856)
,p_name=>'P34_WEBSITELINK_RO'
,p_item_sequence=>430
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu Web Site'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1108)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  pck_ri.fcreateLinkIfUrl(websitelink,80)',
'from t_vorschrift v',
'where v.vorschriftid = :P34_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="text-decoration: underline; text-decoration-style: dashed"'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_display_when=>'P34_EDIT_MODE'
,p_display_when_type=>'ITEM_IS_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028948227539292855)
,p_name=>'P34_KSU'
,p_item_sequence=>440
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1020'
,p_prompt=>'KSU'
,p_source=>'KSUID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN k.bezeichnung',
'        ELSE k.name_eng',
'    END AS bezeichnung, ',
'    k.ksuid',
'FROM t_ksu k',
'ORDER BY ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN k.bezeichnung',
'        ELSE k.name_eng',
'    END;',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when=>'true'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028947905510292855)
,p_name=>'P34_IN_KRAFT_DATUM_SUPPLEMENT'
,p_item_sequence=>450
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'In Kraft'
,p_format_mask=>'DD.MM.YYYY'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vredt.einsatzdatum',
'from T_VORSCHRIFT_REF_EINSATZDATUM_TYP vredt',
'where  vredt.vorschriftid = :P34_VORSCHRIFTID',
'    AND vredt.einsatzdatum_typid = 1000;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028947505673292855)
,p_name=>'P34_TYPSCHILD'
,p_item_sequence=>460
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_prompt=>'Typschild'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(typschild, '', '') within group(order by typschild)',
'from (',
'    select distinct l.typschild',
'    from T_VORSCHRIFT_REF_LAND ttl',
'    inner join T_LAND l on l.landid = ttl.landid',
'    where ttl.vorschriftid = :P34_VORSCHRIFTID and ttl.geloescht = 0',
');'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Rolle inakt. Funktionen',
'(pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0) = true',
'',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>unistr('Nur f\00FCr Administratoren sichtbar')
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028946605458292854)
,p_name=>'P34_JIRA_TICKET'
,p_item_sequence=>470
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Jira-Tickets'
,p_source=>'JIRA_TICKET'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>150
,p_cMaxlength=>60
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028946156149292854)
,p_name=>'P34_TECHNOLOGIE'
,p_item_sequence=>480
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Technologie'
,p_source=>'TECHNOLOGIE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct technologie from t_vorschrift',
'order by technologie'))
,p_cSize=>30
,p_cMaxlength=>256
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Rolle inaktive Funktionen',
'(pck_ri.fIsUserInRolle(listRolleId => ''1080:1080'') > 0)',
'',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'  (  pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) /* and ',
'                            pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0*/) -- Rolle inaktive Funktionen',
') = false',
'  or ',
'(  ',
'   (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
')'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'fetch_on_type', 'Y',
  'match_type', 'CONTAINS_IGNORE',
  'min_chars', '2',
  'use_cache', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'  (  pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) and ',
'                            pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0) -- Rolle Fachadm',
') = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
'-- (pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0)',
'',
'',
'',
'read only ',
'',
'',
'pck_ri.fIsAuthorized(pageId => 25, accessMode => 200) = false',
'    or (:P34_EDIT_MODE is null or :P34_EDIT_MODE <> 1)',
'',
'',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028945780276292853)
,p_name=>'P34_VERANTWORTLICHE'
,p_item_sequence=>490
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Regulierungsverantwortliche'
,p_post_element_text=>'&nbsp;<span onclick="redirect(322)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(nachname || '', '' || vorname || '' ('' || abteilung || '')'', '', '') within group (order by nachname)',
'    from t_vorschrift_ref_verantwortlicher vrv',
'    left outer join t_verantwortlicher v on (vrv.verantwortlicherid = v.verantwortlicherid)',
'    where vrv.vorschriftid = :P34_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028945391587292853)
,p_name=>'P34_STICHWOERTER'
,p_item_sequence=>500
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_prompt=>unistr('Stichw\00F6rter')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(sw.stext,  '', '') within group (order by sw.stext)',
'    from t_vorschrift_ref_schlagwort vrs',
'    join t_schlagwort sw on (sw.schlagwortid = vrs.schlagwortid)',
'   where vrs.vorschriftid = :P34_VORSCHRIFTID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028944916659292853)
,p_name=>'P34_INHALTLICH_SACHLICH_GEPRUEFT'
,p_is_required=>true
,p_item_sequence=>510
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_item_default=>'10'
,p_prompt=>unistr('inhaltlich sachlich gepr\00FCft')
,p_source=>'INHALTLICH_SACHLICH_GEPRUEFT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_INHALTLICH_SACHLICH_GEPRUEFT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
unistr('        emano_util.fLang(''nicht gepr\00FCft'', ''not checked'') AS display_value,'),
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''n.i.O gepr\00FCft'', ''checked n.i.O'') AS display_value,'),
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''i.O gepr\00FCft'', ''checked i.O'') AS display_value,'),
'        30 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_display_when=>':P34_EDIT_MODE = 1 and pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028944562099292853)
,p_name=>'P34_INHALTLICH_SACHLICH_GEPRUEFT_RO'
,p_item_sequence=>520
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('inhaltlich sachlich gepr\00FCft')
,p_source=>'INHALTLICH_SACHLICH_GEPRUEFT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_INHALTLICH_SACHLICH_GEPRUEFT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
unistr('        emano_util.fLang(''nicht gepr\00FCft'', ''not checked'') AS display_value,'),
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''n.i.O gepr\00FCft'', ''checked n.i.O'') AS display_value,'),
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''i.O gepr\00FCft'', ''checked i.O'') AS display_value,'),
'        30 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_display_when=>'nvl(:P34_EDIT_MODE,0) = 0 and pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028944159318292852)
,p_name=>'P34_DOCUMENT_TYPE'
,p_item_sequence=>530
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Document Type'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select emano_util.flang(dt.text_deutsch, dt.text_englisch)',
'from t_vorschrift v',
'join t_document_type dt on (v.document_typeid = dt.document_typeid)',
'where v.vorschriftid = :P34_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P34_VORSCHRIFTID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028943780946292852)
,p_name=>'P34_X_JIRA_URL'
,p_item_sequence=>540
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028943361256292852)
,p_name=>'P34_VORSCHRIFTID'
,p_item_sequence=>550
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_source=>'VORSCHRIFTID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028942950747292852)
,p_name=>'P34_VORSCHRIFTID_PARENT'
,p_item_sequence=>560
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028942559133292852)
,p_name=>'P34_STRG_GETEX_ANZEIGE'
,p_item_sequence=>570
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_use_cache_before_default=>'NO'
,p_item_default=>'10'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- master in ( GEtEX ,  "Getex + automatical update")',
'case  when (:P34_MASTER in (20, 30))  then 20 else 10 end'))
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028942194259292852)
,p_name=>'P34_PROCESS_FROM'
,p_item_sequence=>580
,p_item_plug_id=>wwv_flow_imp.id(9412247026821870581)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028926950286292789)
,p_name=>'P34_SELECTED_ROWS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(494103106877030562)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028925426106292788)
,p_name=>'P34_STATUS_OPTION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9419691149654807307)
,p_use_cache_before_default=>'NO'
,p_item_default=>'10'
,p_prompt=>'Jira Status'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''alle MfVs'', ''all MfVs'') AS display_value, ',
'        100 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''geschlossen'', ''closed'') AS display_value,',
'        10 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''offen'', ''open'') AS display_value,',
'        0 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''ohne MfV beendet'', ''without MfV terminated'') AS display_value,',
'        20 AS actual_value,',
'        4 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '4',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028917554252292778)
,p_name=>'P34_SET_GUELTIG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1554232699486963102)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028893926943292753)
,p_name=>'P34_HINWEIS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(5721721984254991065)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*with cte1 as(',
unistr('    Select  emano_util.fLang(''Keine automatische Berechnung des Au\00DFer Kraft Datums, da dieses manuell bef\00FCllt wurde'', '),
'    ''No automatic calculation of the out-of-force date, as this was filled manually'')',
'    as hinweis',
'     from  T_VORSCHRIFT_REF_EINSATZDATUM_TYP vredt',
'where vredt.vorschriftid = :P34_VORSCHRIFTID and  vredt.EINSATZDATUM_TYPID in (1041,1060,1063)',
'  and (MANUELLE_EINTRAGUNG = 10 and einsatzdatum is not null)',
'union all',
' Select  hinweis',
'     from  T_VORSCHRIFT_REF_EINSATZDATUM_TYP vredt',
'where vredt.vorschriftid = :P34_VORSCHRIFTID and  vredt.EINSATZDATUM_TYPID in (1041,1060,1063)',
'  and MANUELLE_EINTRAGUNG = 20 and hinweis is not null',
')',
'*/',
'',
'with cte1 as(',
unistr('    Select emano_util.fLang(''Achtung,  f\00FCr neue typen darf diese Vorschrift nicht mehr verwendet werden'','),
'                          ''Attention, this regulation must not be used for new types'')',
'    as hinweis',
'     from  T_VORSCHRIFT_REF_EINSATZDATUM_TYP vre',
'   join T_vorschrift_ref_vorschrift vrv on (vrv.nachfolger_vorschriftid = vre.vorschriftid)',
'  where vrv.beziehung_art in (10) and vrv.vorgaenger_vorschriftid = :P34_VORSCHRIFTID',
'  and vre.einsatzdatum_typid in (1010, 1020) and vre.einsatzdatum < sysdate',
')',
'select ''<span style="color:red">'' || hinweis ||''</span>'' a --, hinweis b',
'from  cte1',
'  fetch first 1 rows only'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028876466511292710)
,p_name=>'P34_EDIT_MODE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9426438869390950105)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'if :P34_ROWID is null then',
'    return 1;',
'else',
'    return null;',
'end if;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028876040203292710)
,p_name=>'P34_LAZY_LOAD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9426438869390950105)
,p_use_cache_before_default=>'NO'
,p_source=>'N'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028868702022292704)
,p_name=>'P34_SELECTED_AMENDM_ROWS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1952421574103429466)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028850739764292685)
,p_name=>'P34_LEAD_VKO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(6205588740037282195)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Lead VKO'
,p_source=>'LEAD_VKO_BENUTZERID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with vko_land as (',
unistr('    -- F\00FCr jeden VKO ermitteln, f\00FCr welche L\00E4nder er zust\00E4ndig ist'),
'    select distinct  arb.benutzerid benutzerid, arb.et_b_akid et_b_akid, nvl(arb.Land_independent,0) land_independent, avrl.landid, arb.lead_vko, ET_B_AK_REF_BENUTZERID',
'    from T_ET_B_AK_REF_BENUTZER arb',
'    left outer join t_et_b_ak_vko_ref_land avrl on (avrl.et_b_ak_vkoid = arb.ET_B_AK_REF_BENUTZERID)',
'), v_land as (',
unistr('    -- L\00E4nder, die der Vorschrift zugeordnet sind'),
'    Select distinct vrtl.vorschriftid vorschriftid, vrtl.landid',
'    from T_VORSCHRIFT_REF_LAND  vrtl',
'    where vrtl.geloescht = 0 and vrtl.vorschriftid = :P34_VORSCHRIFTID',
'), vko_themen as (',
'    -- Die zugeordneten Themen der VKOs ermitteln',
'    select arb.benutzerid, arb.et_b_ak_ref_benutzerid, case when avrt.themaid is null then 1 else 0 end as themen_unabhaengig, avrt.themaid,',
'    arb.et_b_akid',
'    from t_et_b_ak_ref_benutzer arb',
'    left outer join t_et_b_ak_vko_ref_thema avrt on (avrt.et_b_ak_vkoid = arb.et_b_ak_ref_benutzerid)',
'), vko_themen2 as (',
'    -- Die Themen der VKOs mit den Themen der Vorschrift abgleichen',
'    select distinct v1.benutzerid, v1.et_b_ak_ref_benutzerid, v1.et_b_akid',
'    from vko_themen v1',
'    join t_vorschrift_ref_thema vrt on (v1.themaid = vrt.themaid or v1.themen_unabhaengig = 1)',
'    where vrt.vorschriftid = :P34_VORSCHRIFTID and vrt.geloescht = 0',
')',
' select distinct   d,   r from',
'(',
'    select  distinct  b.Nachname ||'', ''||b.Vorname || '' (''||b.Abteilung || '')'' as d,   b.benutzerid r',
'    FROM T_VORSCHRIFT_REF_ET_B_AK vra',
'          join t_et_b_ak ak on (vra.et_b_akid = ak.et_b_akid)',
'         left join vko_themen2 t2 on (t2.et_b_akid = vra.et_b_akid)',
'         left outer join t_benutzer b on (t2.benutzerid = b.benutzerid)',
'           where vra.vorschriftid = :P34_VORSCHRIFTID and vra.geloescht = 0 ',
'           and instr(UPPER(:P34_VORSCHRIFT_NUMMER), ''UN-R'')>0  and b.benutzerid is not null ',
'   union all',
'    select distinct  b.Nachname ||'', ''||b.Vorname || '' (''||b.Abteilung || '')'' as d,  b.benutzerid r ',
unistr('   -- mit l\00E4nder'),
'    FROM T_VORSCHRIFT_REF_ET_B_AK vra',
'    join t_et_b_ak ak on (vra.et_b_akid = ak.et_b_akid)',
'    left outer join v_land l on (vra.vorschriftid = l.vorschriftid)',
'    left outer join vko_land vl on (vra.et_b_akid = vl.et_b_akid and (vl.land_independent = 1 or l.landid = vl.landid))',
'    left outer join t_benutzer b on (vl.benutzerid = b.benutzerid)',
'    where vra.vorschriftid = :P34_VORSCHRIFTID and vra.geloescht = 0 and vl.benutzerid is not null',
'    and (vl.benutzerid in (select benutzerid from vko_themen2) )',
'   union ',
'    select  distinct  b.Nachname ||'', ''||b.Vorname || '' (''||b.Abteilung || '')'' as d, lead_vko_benutzerid AS r ',
'      from t_vorschrift v',
'      join t_benutzer b on (b.benutzerid = v.lead_vko_benutzerid)',
'    where v.vorschriftid =:P34_VORSCHRIFTID',
'    --select  distinct  bezeichnung as d,  benutzerid r',
'  --FROM V_VORSCHRIFT_VKO where vorschriftid = :P34_VORSCHRIFTID',
')  ',
'  order by 1;'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P34_VORSCHRIFT_NUMMER,P34_VORSCHRIFTID_PARENT'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_display_when=>':P34_VORSCHRIFT_TYPID in (10,30,40)'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:margin-bottom-sm'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'P39_EDIT_MODE',
'',
'1',
'',
'itme ! = value',
'',
'',
'',
'srver ',
'',
':P39_VORSCHRIFT_TYPID in (10,30,40)',
'',
'',
'',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1028850400845292683)
,p_name=>'P34_LEAD_VKO_PARENT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(6205588740037282195)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Lead VKO - Parent'
,p_source=>'select lead_vko_benutzerid from t_vorschrift where vorschriftid = :P34_PARENT_VORSCHRIFTID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b.Nachname ||'', ''||b.Vorname || '' (''||b.Abteilung || '')'' as d,   b.benutzerid',
'from t_benutzer b'))
,p_display_when=>':P34_VORSCHRIFT_TYPID in (20)'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1028839242899292647)
,p_validation_name=>'VALIDATE_NORM'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_regex VARCHAR(1000);',
'    lBeispiele VARCHAR(1000);',
'    ',
'    lArrRegex wwv_flow_t_varchar2;',
'    lRegexMatched boolean;',
'begin',
'  debug(''P34_WITHOUT_NORM_VALIDATION= ''|| :P34_WITHOUT_NORM_VALIDATION);',
'    if (:P34_NORMID = 1016) then',
'        return ''Die Vorschrift kann nicht ohne Notation gespeichert werden.'';',
'    end if;',
'    if (:P34_WITHOUT_NORM_VALIDATION = ''1'' ) then  --:P34_VORSCHRIFT_FREIGABESTATUSID = ''1'') then',
'        return  null;',
'    end if;',
'',
'    select regex, ',
'    nvl2(beispiel, ''<br />Beispiele:<br />'' || beispiel, '''') ',
'    into l_regex, lBeispiele ',
'    from t_norm ',
'    where normid = :P34_NORMID;',
'    ',
'    lArrRegex := apex_string.split(l_regex, apex_application.cr || ''?'' || apex_application.lf);',
'    for i in 1 .. lArrRegex.count loop',
'        if regexp_like(:P34_VORSCHRIFT_NUMMER, lArrRegex(i)) then',
'            return null;',
'        end if;',
'    end loop;',
'    ',
unistr('    return ''Die Vorschrift entspricht nicht der ausgew\00E4hlten Norm '''''' '),
'            || regexp_replace(l_regex, apex_application.cr || ''?'' || apex_application.lf, ''<br />'')',
'            || ''''''.'' ',
'            || regexp_replace(lBeispiele, apex_application.cr || ''?'' || apex_application.lf, ''<br />'')',
'            ;',
'    ',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_validation_condition_type=>'NEVER'
,p_when_button_pressed=>wwv_flow_imp.id(1028877303696292710)
,p_associated_item=>wwv_flow_imp.id(1028960677325292873)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1028840049874292647)
,p_validation_name=>'VALIDATE_NORM_on_Create'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_regex VARCHAR(1000);',
'    lBeispiele VARCHAR(1000);',
'    ',
'    lArrRegex wwv_flow_t_varchar2;',
'    lRegexMatched boolean;',
'begin',
'    if (:P34_NORMID = 1016) then',
'        return ''Die Vorschrift kann nicht ohne Notation gespeichert werden.'';',
'    end if;',
'    if (:P34_WITHOUT_NORM_VALIDATION = ''1'' ) then  --:P34_VORSCHRIFT_FREIGABESTATUSID = ''1'') then',
'        return  null;',
'    end if;',
'',
'',
'    select regex, ',
'    nvl2(beispiel, ''<br />Beispiele:<br />'' || beispiel, '''') ',
'    into l_regex, lBeispiele ',
'    from t_norm ',
'    where normid = :P34_NORMID;',
'    ',
'    lArrRegex := apex_string.split(l_regex, apex_application.cr || ''?'' || apex_application.lf);',
'    for i in 1 .. lArrRegex.count loop',
'        if regexp_like(:P34_VORSCHRIFT_NUMMER, lArrRegex(i)) then',
'            return null;',
'        end if;',
'    end loop;',
'    ',
unistr('    return ''Die Vorschrift entspricht nicht der ausgew\00E4hlten Norm '''''' '),
'            || regexp_replace(l_regex, apex_application.cr || ''?'' || apex_application.lf, ''<br />'')',
'            || ''''''.'' ',
'            || regexp_replace(lBeispiele, apex_application.cr || ''?'' || apex_application.lf, ''<br />'')',
'            ;',
'    ',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_validation_condition_type=>'NEVER'
,p_when_button_pressed=>wwv_flow_imp.id(1028876850549292710)
,p_associated_item=>wwv_flow_imp.id(1028960677325292873)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1028838910278292647)
,p_validation_name=>'Vorschrift Nummer unique (neuanlage)'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from t_vorschrift where trim(vorschrift_nummer) = trim(:P34_VORSCHRIFT_NUMMER) ',
'and  ( dokumentendatum is null and  :P34_DOKUMENTENDATUM is null  OR to_char(dokumentendatum, ''dd.mm.yyyy'') = :P34_DOKUMENTENDATUM )'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Es existiert bereits eine Vorschrift mit dieser Nummer!'
,p_validation_condition=>'P34_VORSCHRIFT_TYPID'
,p_validation_condition2=>'20'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(1028876850549292710)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1028838433225292647)
,p_validation_name=>'Vorschrift Nummer unique (edit)'
,p_validation_sequence=>40
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from t_vorschrift where trim(vorschrift_nummer) = trim(:P34_VORSCHRIFT_NUMMER) and vorschriftid != :P34_VORSCHRIFTID',
'and  ( dokumentendatum is null and  :P34_DOKUMENTENDATUM is null  OR to_char(dokumentendatum, ''dd.mm.yyyy'') = :P34_DOKUMENTENDATUM )'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Es existiert bereits eine Vorschrift mit dieser Nummer!'
,p_validation_condition=>'P34_VORSCHRIFT_TYPID'
,p_validation_condition2=>'20'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(1028877303696292710)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1028839632346292647)
,p_validation_name=>'V_Status_Einsatzdatum'
,p_validation_sequence=>50
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'',
'from  T_VORSCHRIFT_REF_EINSATZDATUM_TYP vredt  ',
'',
'where ((EINSATZDATUM_TYPID = 1000) and (vredt.vorschriftid = :P34_VORSCHRIFTID) and einsatzdatum is not null) -- Vorschrift',
'    or ((:P34_IN_KRAFT_DATUM_SUPPLEMENT is not null) and (:P34_VORSCHRIFT_TYPID = 20)) -- Supplement',
'       ',
';'))
,p_validation_type=>'EXISTS'
,p_error_message=>unistr('Die Vorschrift ben\00F6tigt ein in Kraft-Datum bevor diese den Status In Kraft erhalten kann.')
,p_validation_condition_type=>'NEVER'
,p_associated_item=>wwv_flow_imp.id(1028955501346292861)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1028840480041292648)
,p_validation_name=>'Validate_Links'
,p_validation_sequence=>70
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    return ',
'    ((:P34_VORSCHRIFT_FREIGABESTATUSID = ''1'')',
'    or (:P34_VORSCHRIFT_FREIGABESTATUSID = ''30'')',
'     or',
'      (:P34_LINK_ZUR_VORSCHRIFT_GETEX is not null',
'         or :P34_LINK_ZUR_VORSCHRIFT_DMS is not null',
'         or :P34_WEBSITELINK is not null)',
'    );'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('Sie m\00FCssen einen Link zum Dokument angeben, bef\00FCllen Sie mindestens eins der Felder DMS, Website, GETEX nach Prioliste.')
,p_always_execute=>'Y'
,p_validation_condition_type=>'NEVER'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1028840898214292648)
,p_validation_name=>'validation 3 item null'
,p_validation_sequence=>100
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1 ',
'FROM dual ',
'WHERE :P34_LINK_ZUR_VORSCHRIFT_DMS IS NULL ',
'AND :P34_LINK_REQMAN IS NULL ',
'AND :P34_WEBSITELINK IS NULL;'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>unistr('Mindestens einer der Link-Felder DMS, GETEX-ID oder WebSite enth\00E4lt einen Eintrag.')
,p_validation_condition_type=>'NEVER'
,p_when_button_pressed=>wwv_flow_imp.id(1028877303696292710)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1028841304152292648)
,p_validation_name=>'Validate Supplement Parent'
,p_validation_sequence=>110
,p_validation=>'(:P34_VORSCHRIFT_TYPID != 20 or  :P34_PARENT_VORSCHRIFTID is not null)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Supplement muss eine \00FCbergeordnete Vorschrift haben.')
,p_when_button_pressed=>wwv_flow_imp.id(1028876850549292710)
,p_associated_item=>wwv_flow_imp.id(1028961429979292874)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1028841524721292649)
,p_validation_name=>'Validate existing MfVs'
,p_validation_sequence=>120
,p_validation=>' (select count(*) from T_MFV_REF_VORSCHRIFT  where vorschriftid = :P34_VORSCHRIFTID)=0'
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('MfV existieren. Vorschrift kann nicht gel\00F6scht werden.')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(1028877652320292710)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028829864911292630)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1028880042798292711)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028829318382292630)
,p_event_id=>wwv_flow_imp.id(1028829864911292630)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028829009114292630)
,p_name=>'DIALOG_VERKNUEPFUNGEN_CLOSED'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(9413676743982265743)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028828466258292630)
,p_event_id=>wwv_flow_imp.id(1028829009114292630)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9413676815357265744)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028828101937292630)
,p_name=>'CHANGE_SWITCH_THEMEN'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_THEMEN_LAENDER'
,p_condition_element=>'P34_THEMEN_LAENDER'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'10'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028827539889292629)
,p_event_id=>wwv_flow_imp.id(1028828101937292630)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P34_THEMEN_LAENDER'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028827111081292629)
,p_event_id=>wwv_flow_imp.id(1028828101937292630)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P34_THEMEN_LAENDER'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028826636527292629)
,p_name=>'DIALOG_MFV_CLOSED'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(9419691149654807307)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028826204244292629)
,p_event_id=>wwv_flow_imp.id(1028826636527292629)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'refresh report_MfV'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9419691373988807309)
,p_attribute_01=>'N'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028825130116292628)
,p_event_id=>wwv_flow_imp.id(1028826636527292629)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'refresh report_MfV -  Interpretation'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1554232699486963102)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028825683714292629)
,p_event_id=>wwv_flow_imp.id(1028826636527292629)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'refresh report_MfV - Information'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1554234421630963120)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028824735006292628)
,p_name=>'DELETE_VORSCHRIFT'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1028877652320292710)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028824241757292628)
,p_event_id=>wwv_flow_imp.id(1028824735006292628)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('M\00F6chten Sie die Vorschrift ''&P34_VORSCHRIFT_NUMMER.'' mit allen verkn\00FCpften Daten, Historie und Benachrichtigungen endg\00FCltig l\00F6schen?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028823732853292627)
,p_event_id=>wwv_flow_imp.id(1028824735006292628)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lResult boolean;',
'begin',
'   -- delete  Vorschriftid dependences',
'    --update t_benachrichtigung set vorschriftid =null where vorschriftid = P34_VORSCHRIFTID;',
'    --or',
'    --delete from T_BENACHRICHTIGUNG_kommentar where BENACHRICHTIGUNGID in (select BENACHRICHTIGUNGID from t_benachrichtigung  where vorschriftid = :P34_VORSCHRIFTID);',
'    --delete from t_benachrichtigung  where vorschriftid = :P34_VORSCHRIFTID;',
'    --',
'    lResult := PCK_RI.fDeleteVorschrift(:P34_VORSCHRIFTID);',
'    if(lResult) then',
unistr('      pck_ri_benachrichtigung.pBenachrichtigung( null,  ''1400'', ''Vorschrift "'' || :P34_VORSCHRIFT_NUMMER || ''", id:''|| :P34_VORSCHRIFTID || '' ist gel\00F6scht.'', aGrund =>90, '),
'      aLoeschmarker =>0, aBenutzerid => PCK_RI.fGetUserId());',
'    end if;',
'    ',
'   pck_ri_cockpit_refresh.pTriggerRefresh;',
'end;'))
,p_attribute_02=>'P34_VORSCHRIFTID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028823266385292627)
,p_event_id=>wwv_flow_imp.id(1028824735006292628)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('apex.message.showPageSuccess(''Die Vorschrift wurde gel\00F6scht.'');'),
'',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028822767361292627)
,p_event_id=>wwv_flow_imp.id(1028824735006292628)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'DELETE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028822395763292627)
,p_name=>'DELETE_SELECTED_VERKNUEPFUNGEN'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1028941510573292850)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028821861118292627)
,p_event_id=>wwv_flow_imp.id(1028822395763292627)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('M\00F6chten Sie die ausgew\00E4hlten Verkn\00FCpfungen l\00F6schen?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028821356703292627)
,p_event_id=>wwv_flow_imp.id(1028822395763292627)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var sel_rows = $("#P34_SELECTED_ROWS");',
'sel_rows.val("");',
'$("#report-verknuepfungen").find("td input:checked").each(function() {',
'  // alert(this.value);',
'  if(sel_rows.val().length > 0) {',
'    sel_rows.val(sel_rows.val() + "|");    ',
'  }',
'  sel_rows.val(sel_rows.val() + this.value);',
'  //sel_rows.val(sel_rows.val().push(this.value));',
'  //alert(sel_rows.val());',
'});',
'            '))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028820865406292626)
,p_event_id=>wwv_flow_imp.id(1028822395763292627)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  lStartIdx binary_integer;',
'  lCurIdx   binary_integer;',
'  lCurValue varchar2(1000);',
'begin',
'',
'   --debug ('' sel_rows:P34_SELECTED_ROWS= ''|| :P34_SELECTED_ROWS);',
unistr('    -- aenderung der Getex_attr f\00FCr beide voschriften'),
'    -- select vorschrift_ref_vorschriftid from t_vorschrift_ref_vorschrift where ROWID in (select  column_value from apex_string.split(:P34_SELECTED_ROWS,''|'') x)',
'    update t_vorschrift set letzte_aenderung_getex_attr = sysdate ',
'    where Vorschriftid  in (',
'        select  vorgaenger_vorschriftid from t_vorschrift_ref_vorschrift',
'        where vorschrift_ref_vorschriftid  in ( select vorschrift_ref_vorschriftid from t_vorschrift_ref_vorschrift vrv',
'                                                join table (apex_string.split(:P34_SELECTED_ROWS,''|'') ) x on (x.column_value =vrv.rowid) )',
'         union ',
'          select  nachfolger_vorschriftid from t_vorschrift_ref_vorschrift',
'        where vorschrift_ref_vorschriftid  in ( select vorschrift_ref_vorschriftid from t_vorschrift_ref_vorschrift vrv',
'                                                join table (apex_string.split(:P34_SELECTED_ROWS,''|'') ) x on (x.column_value =vrv.rowid) )',
'     );    ',
'     ',
'    for cur in (',
'        select vrv.vorschrift_ref_vorschriftid',
'        from apex_string.split(:P34_SELECTED_ROWS,''|'') x',
'        join t_vorschrift_ref_vorschrift vrv on (x.column_value = vrv.rowid)',
'    )',
'    loop',
'        delete from t_vorschrift_ref_vorschrift_ref_thema where vorschrift_ref_vorschriftid = cur.vorschrift_ref_vorschriftid;',
'        delete from t_vorschrift_ref_vorschrift where vorschrift_ref_vorschriftid = cur.vorschrift_ref_vorschriftid;',
'    end loop;',
'',
'',
' /* lStartIdx := 0;',
'  lCurIdx   := instr(:P34_SELECTED_ROWS, ''|''); ',
'',
'  while(lCurIdx > 0) loop',
'    lCurValue := substr(:P34_SELECTED_ROWS, lStartIdx+1, lCurIdx - lStartIdx - 1);',
'',
'    -- call proc here',
'    delete from t_vorschrift_ref_vorschrift_ref_thema where vorschrift_ref_vorschriftid in (',
'        select vorschrift_ref_vorschriftid from t_vorschrift_ref_vorschrift where rowid = lCurValue',
'    );',
'    delete from t_vorschrift_ref_vorschrift where rowid = lCurValue;',
'',
'    lStartIdx := lCurIdx;',
'    lCurIdx := instr(:P34_SELECTED_ROWS, ''|'', lStartIdx + 1);  ',
'  end loop;',
'',
'  -- Call proc here for last part (or in case of single element)',
'  lCurValue := substr(:P34_SELECTED_ROWS, lStartIdx+1);',
'  delete from t_vorschrift_ref_vorschrift where rowid = lCurValue;*/',
'',
'end;'))
,p_attribute_02=>'P34_SELECTED_ROWS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028820325458292626)
,p_event_id=>wwv_flow_imp.id(1028822395763292627)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9413676815357265744)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028819990169292626)
,p_name=>'Typ Supplement UN-R'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_VORSCHRIFT_TYPID'
,p_condition_element=>'P34_VORSCHRIFT_TYPID'
,p_triggering_condition_type=>'IN_LIST'
,p_triggering_expression=>'20'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028819425969292625)
,p_event_id=>wwv_flow_imp.id(1028819990169292626)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_EINSATZDATUM_MODELLID,P34_PROGNOSE_QUALITAETID,P34_JIRA_TICKET,P34_TYPSCHILD,P34_IN_KRAFT_DATUM_SUPPLEMENT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028818926835292625)
,p_event_id=>wwv_flow_imp.id(1028819990169292626)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_PARENT_VORSCHRIFTID, P34_FAHRZEUGKLASSE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028818463469292625)
,p_event_id=>wwv_flow_imp.id(1028819990169292626)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_NORMIDALT'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1060'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028818048949292625)
,p_name=>'Typ Vorschrift'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_VORSCHRIFT_TYPID'
,p_condition_element=>'P34_VORSCHRIFT_TYPID'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'10'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028817594292292624)
,p_event_id=>wwv_flow_imp.id(1028818048949292625)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_EINSATZDATUM_MODELLID,P34_PROGNOSE_QUALITAETID,P34_VORSCHRIFT_FREIGABESTATUSID,P34_TYPSCHILD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028817063669292624)
,p_event_id=>wwv_flow_imp.id(1028818048949292625)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_JIRA_TICKET, P34_PARENT_VORSCHRIFTID, P34_IN_KRAFT_DATUM_SUPPLEMENT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028816541593292624)
,p_event_id=>wwv_flow_imp.id(1028818048949292625)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_NORMIDALT'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1016'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028816175496292624)
,p_name=>'Typ Norm'
,p_event_sequence=>160
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_VORSCHRIFT_TYPID'
,p_condition_element=>'P34_VORSCHRIFT_TYPID'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'40'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028815675192292623)
,p_event_id=>wwv_flow_imp.id(1028816175496292624)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_EINSATZDATUM_MODELLID,P34_PROGNOSE_QUALITAETID,P34_VORSCHRIFT_FREIGABESTATUSID,P34_TYPSCHILD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028815117571292623)
,p_event_id=>wwv_flow_imp.id(1028816175496292624)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_JIRA_TICKET, P34_PARENT_VORSCHRIFTID, P34_IN_KRAFT_DATUM_SUPPLEMENT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028814666074292623)
,p_event_id=>wwv_flow_imp.id(1028816175496292624)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_NORMIDALT'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1016'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028814260932292623)
,p_name=>'New Parent'
,p_event_sequence=>170
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_PARENT_VORSCHRIFTID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028813718661292623)
,p_event_id=>wwv_flow_imp.id(1028814260932292623)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lRowid rowid;',
'begin',
'    if (:P34_PARENT_VORSCHRIFTID is not null) then',
'        select rowid into lRowid from t_vorschrift where vorschriftid = :P34_PARENT_VORSCHRIFTID;',
'        :P34_LINK := apex_page.get_url(p_page => 34,p_items => ''P34_ROWID'', p_values => lRowid, p_clear_cache => 34);',
'    else',
'        :P34_LINK := null;',
'    end if;',
'    ',
'',
'',
'end;',
'',
''))
,p_attribute_02=>'P34_PARENT_VORSCHRIFTID'
,p_attribute_03=>'P34_LINK'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028813217028292622)
,p_event_id=>wwv_flow_imp.id(1028814260932292623)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var link = $v(''P34_LINK'');',
'if (link) {',
'    $(''#bLinkParent'').attr(''href'',$v(''P34_LINK'')).show();',
'} else {',
'    $(''#bLinkParent'').hide();',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028812850287292622)
,p_name=>'Typ Rahmenrichtlinie'
,p_event_sequence=>180
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_VORSCHRIFT_TYPID'
,p_condition_element=>'P34_VORSCHRIFT_TYPID'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'30'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028812342721292622)
,p_event_id=>wwv_flow_imp.id(1028812850287292622)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_EINSATZDATUM_MODELLID,P34_PROGNOSE_QUALITAETID,P34_VORSCHRIFT_FREIGABESTATUSID,P34_TYPSCHILD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028811859351292622)
,p_event_id=>wwv_flow_imp.id(1028812850287292622)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_PARENT_VORSCHRIFTID, P34_IN_KRAFT_DATUM_SUPPLEMENT, P34_JIRA_TICKET'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028811401929292621)
,p_event_id=>wwv_flow_imp.id(1028812850287292622)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_NORMIDALT'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1016'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028811005704292621)
,p_name=>'Change Norm'
,p_event_sequence=>190
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_NORMID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028810466014292621)
,p_event_id=>wwv_flow_imp.id(1028811005704292621)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_NORM_BEISPIEL'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select replace(beispiel,chr(10),''; '') || ''<br /><b><u>Beschreibung:</u></b> '' || regexp_replace(beschreibung,''(http([^ ]*))'',''<a href="\1" target="_blank">\1</a>'') as x',
'from t_norm',
'where normid = nvl(:P34_NORMID, 1016)'))
,p_attribute_07=>'P34_NORMID'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028809943565292620)
,p_event_id=>wwv_flow_imp.id(1028811005704292621)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#P34_NORMID_inline_help'').html(''<b><u>Beispiel(e)</u></b>: '' + $v(''P34_NORM_BEISPIEL''));'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028809597753292620)
,p_name=>'ACTION_OPEN_JIRA_URL'
,p_event_sequence=>200
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1028965826232292880)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028809034242292620)
,p_event_id=>wwv_flow_imp.id(1028809597753292620)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'    :P34_X_JIRA_URL := PCK_RI.fCreateJiraUrl(aVorschriftId => :P34_VORSCHRIFTID);',
'',
'end;'))
,p_attribute_02=>'P34_VORSCHRIFTID'
,p_attribute_03=>'P34_X_JIRA_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028808590082292620)
,p_event_id=>wwv_flow_imp.id(1028809597753292620)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lUrl = apex.item("P34_X_JIRA_URL").getValue();',
'//alert(decodeURI(lUrl));',
'//alert(lUrl);',
'window.open(lUrl, ''_blank'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028808181779292620)
,p_name=>'DIALOG_FUNKTIONEN_CLOSED'
,p_event_sequence=>210
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(6984700939625258899)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028807689590292619)
,p_event_id=>wwv_flow_imp.id(1028808181779292620)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6984701086671258900)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028807272438292619)
,p_name=>'copy permalink'
,p_event_sequence=>220
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1028966658954292881)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028806767167292619)
,p_event_id=>wwv_flow_imp.id(1028807272438292619)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'navigator.clipboard.writeText($v("P34_PERMALINK"));',
'alert(''Der Permalink wurde in die Zwischenablage kopiert:\n\n'' + $v("P34_PERMALINK"));'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028806324902292619)
,p_name=>'Open Nolis Mynet'
,p_event_sequence=>230
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1028859567132292695)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028805854099292619)
,p_event_id=>wwv_flow_imp.id(1028806324902292619)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window.open(''https://portal.epp.audi.vwg/wps/poc?uri=audi-np:oid:1399899331515'', ''_blank'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028805431089292619)
,p_name=>'A_EINSATZDATUM_MODELL_CHANGED'
,p_event_sequence=>240
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_EINSATZDATUM_MODELLID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_display_when_cond=>'P34_ROWID'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028804959478292618)
,p_event_id=>wwv_flow_imp.id(1028805431089292619)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Die \00C4nderung des ''Einsatz DATUM Modells'' erfordert eine Speicherung der Vorschrift.'),
'',
unistr('Die Bearbeitung abseits der Kerndaten nicht m\00F6glich.')))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028804462876292618)
,p_event_id=>wwv_flow_imp.id(1028805431089292619)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''.t-Region'').slice(1).addClass(''apex_disabled'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028804082410292618)
,p_name=>'A_VORSCHRIFT_TYP_CHANGED'
,p_event_sequence=>250
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_VORSCHRIFT_TYPID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_display_when_cond=>'P34_ROWID'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028803587174292618)
,p_event_id=>wwv_flow_imp.id(1028804082410292618)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Die \00C4nderung des ''Vorschrift Typs'' erfordert eine Speicherung der Vorschrift.'),
'',
unistr('Die Bearbeitung abseits der Kerndaten nicht m\00F6glich.')))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028803044928292618)
,p_event_id=>wwv_flow_imp.id(1028804082410292618)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//$(''#rEinsatzdaten'').addClass(''apex_disabled'');',
'//$(''#rVerknuepfungen'').addClass(''apex_disabled'');',
'$(''.t-Region'').slice(1).addClass(''apex_disabled'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028802628952292617)
,p_name=>'homologationsrelevant?'
,p_event_sequence=>260
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_HOMOLOGATIONSRELEVANT'
,p_condition_element=>'P34_HOMOLOGATIONSRELEVANT'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'10'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028802160535292617)
,p_event_id=>wwv_flow_imp.id(1028802628952292617)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_HOMOLOGATIONSEIGENSCHAFTEN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028801630017292617)
,p_event_id=>wwv_flow_imp.id(1028802628952292617)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_HOMOLOGATIONSEIGENSCHAFTEN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028801263526292617)
,p_name=>unistr('DMS Links ver\00E4ndert')
,p_event_sequence=>270
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_LINK_ZUR_VORSCHRIFT_DMS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028800733420292617)
,p_event_id=>wwv_flow_imp.id(1028801263526292617)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_DMS_DISPLAY'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>'PCK_RI.fCreateLinkIfUrl(:P34_LINK_ZUR_VORSCHRIFT_DMS,80)'
,p_attribute_07=>'P34_LINK_ZUR_VORSCHRIFT_DMS'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028800303024292616)
,p_event_id=>wwv_flow_imp.id(1028801263526292617)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ( !$v(''P34_EDIT_MODE'') ){',
'   $(''#P34_LINK_ZUR_VORSCHRIFT_DMS_inline_help'').html($v(''P34_DMS_DISPLAY''));',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028799855803292616)
,p_name=>'Dialog Funktionszuordnung closed'
,p_event_sequence=>280
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1028845204849292677)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028799389645292616)
,p_event_id=>wwv_flow_imp.id(1028799855803292616)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6984700939625258899)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028798920475292616)
,p_name=>'ENABLE_EDITING'
,p_event_sequence=>290
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1028879286421292711)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028798501142292616)
,p_event_id=>wwv_flow_imp.id(1028798920475292616)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_COP_RELEVANT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028797972856292615)
,p_event_id=>wwv_flow_imp.id(1028798920475292616)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_WITHOUT_NORM_VALIDATION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028797498823292615)
,p_event_id=>wwv_flow_imp.id(1028798920475292616)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_EDIT_MODE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select nvl2(:P34_EDIT_MODE, null, 1) from dual'
,p_attribute_07=>'P34_EDIT_MODE'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028796996293292615)
,p_event_id=>wwv_flow_imp.id(1028798920475292616)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'EDIT_ENABLE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028796432665292615)
,p_event_id=>wwv_flow_imp.id(1028798920475292616)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_WITHOUT_NORM_VALIDATION'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'SELECT without_norm_validation from T_VORSCHRIFT where vorschriftid = :P34_VORSCHRIFTID;'
,p_attribute_07=>'P34_VORSCHRIFTID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028795986584292615)
,p_event_id=>wwv_flow_imp.id(1028798920475292616)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_DATUM_ANGABE_AS_MJ,P34_PHASEIN_ENTHALTEN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028795566858292614)
,p_name=>'DISABLE_EDITING'
,p_event_sequence=>300
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1028878855938292711)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028795063918292614)
,p_event_id=>wwv_flow_imp.id(1028795566858292614)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_WITHOUT_NORM_VALIDATION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028794563453292614)
,p_event_id=>wwv_flow_imp.id(1028795566858292614)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_EDIT_MODE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select nvl2(:P34_EDIT_MODE, null, 1) from dual'
,p_attribute_07=>'P34_EDIT_MODE'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028794057783292614)
,p_event_id=>wwv_flow_imp.id(1028795566858292614)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'EDIT_ENABLE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028793599905292614)
,p_event_id=>wwv_flow_imp.id(1028795566858292614)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_DATUM_ANGABE_AS_MJ,P34_PHASEIN_ENTHALTEN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028793152910292614)
,p_name=>'A_LAZY_LOAD'
,p_event_sequence=>320
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028792669721292613)
,p_event_id=>wwv_flow_imp.id(1028793152910292614)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_LAZY_LOAD'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028792233254292613)
,p_name=>unistr('Dialog verkn\00FCpfte Daten closed')
,p_event_sequence=>330
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1028851874422292686)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028791789728292613)
,p_event_id=>wwv_flow_imp.id(1028792233254292613)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P34_VORSCHRIFTID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028791297041292613)
,p_event_id=>wwv_flow_imp.id(1028792233254292613)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5884384521697244472)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028790895184292613)
,p_name=>'Show_Netz'
,p_event_sequence=>340
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1028878087148292711)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028790413491292613)
,p_event_id=>wwv_flow_imp.id(1028790895184292613)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'javascript:window.open(''f?p=&APP_ID.:300:&APP_SESSION.::&DEBUG.:300:P300_VORSCHRIFTID:''+$v("P34_VORSCHRIFTID") +'''',''_blank'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028790005773292612)
,p_name=>unistr('Set G\00FCltigkeitsdatum')
,p_event_sequence=>360
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.setzegueltigkeit'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028789457077292612)
,p_event_id=>wwv_flow_imp.id(1028790005773292612)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var mfvid = $(this.triggeringElement).attr(''data-id'');',
'$s(''P34_SET_GUELTIG'',mfvid);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028788916881292612)
,p_event_id=>wwv_flow_imp.id(1028790005773292612)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_mfv set gueltigkeitsdatum = sysdate + 2*365 where mfvid = :P34_SET_GUELTIG;',
''))
,p_attribute_02=>'P34_SET_GUELTIG'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028788486688292612)
,p_event_id=>wwv_flow_imp.id(1028790005773292612)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.jQuery("#p34_mfv_report").trigger("apexrefresh");',
'',
'apex.jQuery("#p34_mfv_report_interpretation").trigger("apexrefresh");',
'',
'apex.jQuery("#p34_mfv_report_information").trigger("apexrefresh");',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028785686213292611)
,p_name=>'Check ASCII'
,p_event_sequence=>370
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_VORSCHRIFT_NUMMER'
,p_condition_element=>'P34_VORSCHRIFT_NUMMER'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028785156345292610)
,p_event_id=>wwv_flow_imp.id(1028785686213292611)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_VORSCHRIFT_NUMMER'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var ostr =  apex.item("P34_VORSCHRIFT_NUMMER").getValue();',
'var nstr ="";',
'var mark_on = 0;',
'var any_no_ascii =0;',
'for (var ic = 0; ic < ostr.length; ic++)',
'{',
'  if ( ostr.charCodeAt(ic) !== null && ostr.charCodeAt(ic) > 128  )',
'  {',
'      if( nstr == null)',
'      {',
'          //if(mark_on == 0) // always true',
'          //{',
'            nstr += "<mark>";',
'            mark_on = 1;',
'         // }',
'            nstr += ostr.charAt(ic) ;',
'      }',
'      else',
'      {',
'          if(mark_on == 0)',
'          {',
'             nstr += "<mark>" + ostr.charAt(ic) ;',
'              mark_on = 1;',
'          }',
'          else',
'          {',
'              nstr += ostr.charAt(ic) ;',
'          }',
'      }',
'      any_no_ascii=1;',
'  }',
'  else',
'  {',
'      if(mark_on == 1)',
'      {',
'          nstr += "</mark>";',
'          mark_on = 0;',
'      }',
'      if(nstr == null)',
'          nstr = ostr.charAt(ic);',
'      else',
'          nstr += ostr.charAt(ic);',
'  }',
'}',
'',
'if(mark_on == 1)',
'{    ',
'     nstr += "</mark>";   ',
'}',
'',
'if(any_no_ascii == 1)',
unistr('     $(''#P34_VORSCHRIFT_NUMMER_inline_help'').html(nstr + ''   - <span style ="color:red"><b>Die von Ihnen eingegeben Vorschriftennummer enth\00E4lt einige nicht unterst\00FCtzte Sonderzeichen. Bitte \00E4ndern Sie die gelb hervorgehobenen Sonderzeichen bis die Me')
||'ldung nicht mehr erscheint.</b></span>'');',
'else',
'     $(''#P34_VORSCHRIFT_NUMMER_inline_help'').html('' '');'))
);
end;
/
begin
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028784808954292610)
,p_name=>'Hide Create Message Button'
,p_event_sequence=>380
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NOT_EXISTS'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from t_benutzer_ref_rolle where benutzerid=:G_BENUTZERID',
'AND rolleid in (1003,1000 )'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028784230468292609)
,p_event_id=>wwv_flow_imp.id(1028784808954292610)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(1028967078295292882)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028783901575292609)
,p_name=>'Hide Jira ticket assist Button'
,p_event_sequence=>390
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NOT_EXISTS'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from t_benutzer_ref_rolle where benutzerid=:G_BENUTZERID',
'AND rolleid in (1003,1000 )'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028783393440292609)
,p_event_id=>wwv_flow_imp.id(1028783901575292609)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(1028966254911292881)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028782949078292608)
,p_name=>'Change ability of norm validation'
,p_event_sequence=>430
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_WITHOUT_NORM_VALIDATION'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexbeforerefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028782502718292608)
,p_event_id=>wwv_flow_imp.id(1028782949078292608)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_WITHOUT_NORM_VALIDATION'
,p_server_condition_type=>'EXPRESSION'
,p_server_condition_expr1=>':P34_EDIT_MODE is null'
,p_server_condition_expr2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028782112669292607)
,p_name=>'Change'
,p_event_sequence=>440
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_RXSWIN'
,p_condition_element=>'P34_RXSWIN'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'10'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028781580799292607)
,p_event_id=>wwv_flow_imp.id(1028782112669292607)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_SWR_HAUPTUMSETZENDE_OE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028781063616292607)
,p_event_id=>wwv_flow_imp.id(1028782112669292607)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_SWR_HAUPTUMSETZENDE_OE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028780579373292607)
,p_event_id=>wwv_flow_imp.id(1028782112669292607)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_REV_NOTWENDIG'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028780064991292607)
,p_event_id=>wwv_flow_imp.id(1028782112669292607)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_SWR_HAUPTUMSETZENDE_OE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028779605870292606)
,p_event_id=>wwv_flow_imp.id(1028782112669292607)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_REV_NOTWENDIG'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'10'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028779072422292606)
,p_event_id=>wwv_flow_imp.id(1028782112669292607)
,p_event_result=>'FALSE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_REV_NOTWENDIG'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028778695421292606)
,p_name=>'Visibility'
,p_event_sequence=>450
,p_condition_element=>'P34_VORSCHRIFT_NUMMER'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028778214711292606)
,p_event_id=>wwv_flow_imp.id(1028778695421292606)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_TEXT_FOR_NUMMER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028777626538292606)
,p_event_id=>wwv_flow_imp.id(1028778695421292606)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_TEXT_FOR_NUMMER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028777223599292606)
,p_name=>'Set_val'
,p_event_sequence=>460
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_DATUMS_ANGABEN'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$(this.triggeringElement).find(''input'').prop(''checked'')'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028776738467292606)
,p_event_id=>wwv_flow_imp.id(1028777223599292606)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_DATUMS_ANGABEN_MJ'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if( $v(''P34_DATUMS_ANGABEN'') =="1" ){',
'   $s(''P34_DATUMS_ANGABEN_MJ'', "0");',
'}',
'else {',
'    $s(''P34_DATUMS_ANGABEN_MJ'', "1");',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028776230162292605)
,p_event_id=>wwv_flow_imp.id(1028777223599292606)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_DATUMS_ANGABEN_MJ'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028775805900292605)
,p_event_id=>wwv_flow_imp.id(1028777223599292606)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_DATUMS_ANGABEN_MJ'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028775315912292604)
,p_name=>'Change Value'
,p_event_sequence=>470
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_DATUM_ANGABE_AS_MJ'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028774824163292604)
,p_event_id=>wwv_flow_imp.id(1028775315912292604)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028774461520292604)
,p_name=>'Hide Modeljahr'
,p_event_sequence=>480
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028774008276292603)
,p_event_id=>wwv_flow_imp.id(1028774461520292604)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_DATUM_ANGABE_AS_MJ'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028773433110292603)
,p_event_id=>wwv_flow_imp.id(1028774461520292604)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_DATUM_ANGABE_AS_MJ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028773071592292603)
,p_name=>'change'
,p_event_sequence=>500
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_STATUS_OPTION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028772059728292603)
,p_event_id=>wwv_flow_imp.id(1028773071592292603)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P34_STATUS_OPTION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028771558063292603)
,p_event_id=>wwv_flow_imp.id(1028773071592292603)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1554232699486963102)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028772587058292603)
,p_event_id=>wwv_flow_imp.id(1028773071592292603)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1554234421630963120)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028771191516292602)
,p_name=>'DIALOG_LAENDER_CLOSED'
,p_event_sequence=>510
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(5702656122314296104)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028770700335292602)
,p_event_id=>wwv_flow_imp.id(1028771191516292602)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5702656355675296106)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028770215661292602)
,p_event_id=>wwv_flow_imp.id(1028771191516292602)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5884384521697244472)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028769696607292600)
,p_event_id=>wwv_flow_imp.id(1028771191516292602)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6984701086671258900)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028769202393292599)
,p_event_id=>wwv_flow_imp.id(1028771191516292602)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6205588863463282196)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028788105079292612)
,p_name=>'DIALOG_THEMEN_CLOSED_N_1'
,p_event_sequence=>530
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId && this.data.dialogPageId == 104'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028787540875292611)
,p_event_id=>wwv_flow_imp.id(1028788105079292612)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(541398481243322062)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028787059159292611)
,p_event_id=>wwv_flow_imp.id(1028788105079292612)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5884384521697244472)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028786584299292611)
,p_event_id=>wwv_flow_imp.id(1028788105079292612)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6984701086671258900)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028786112354292611)
,p_event_id=>wwv_flow_imp.id(1028788105079292612)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6205588863463282196)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028768749341292599)
,p_name=>'Dialog Closed'
,p_event_sequence=>540
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(9412247026821870581)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028768245676292599)
,p_event_id=>wwv_flow_imp.id(1028768749341292599)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9412247026821870581)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028767856395292599)
,p_name=>'dialog_Freigabestatus_closed'
,p_event_sequence=>550
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId && this.data.dialogPageId == 28'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028767389830292599)
,p_event_id=>wwv_flow_imp.id(1028767856395292599)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.page.submit(''REFRESH'');',
''))
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028754865227292589)
,p_name=>unistr('Dialog Closed Aenderungen zur Pr\00FCfung/\00DCbernahme Page')
,p_event_sequence=>560
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId && this.data.dialogPageId == 29'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028754356618292588)
,p_event_id=>wwv_flow_imp.id(1028754865227292589)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.page.submit(''REFRESH'');',
''))
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028766964976292598)
,p_name=>'New'
,p_event_sequence=>570
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1028967423601292882)
,p_condition_element=>'P34_IMPORT_STATUS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028766514961292598)
,p_event_id=>wwv_flow_imp.id(1028766964976292598)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(1028967423601292882)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028765955617292598)
,p_event_id=>wwv_flow_imp.id(1028766964976292598)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(1028967423601292882)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028765531997292597)
,p_name=>'Init_ButtonGetex'
,p_event_sequence=>580
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_IMPORT_STATUS'
,p_condition_element=>'P34_IMPORT_STATUS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
,p_da_event_comment=>'can delete it in future'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028765100455292597)
,p_event_id=>wwv_flow_imp.id(1028765531997292597)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(1028967423601292882)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028764552919292597)
,p_event_id=>wwv_flow_imp.id(1028765531997292597)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(1028967423601292882)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028764209630292597)
,p_name=>'Getex_Button_show_hide'
,p_event_sequence=>590
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_MASTER'
,p_condition_element=>'P34_IMPORT_STATUS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'20'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
,p_da_event_comment=>'can delete it in future'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028763648444292596)
,p_event_id=>wwv_flow_imp.id(1028764209630292597)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(1028967423601292882)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P34_MASTER'
,p_client_condition_expression=>'20'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028763170533292596)
,p_event_id=>wwv_flow_imp.id(1028764209630292597)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(1028967423601292882)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028762677583292595)
,p_event_id=>wwv_flow_imp.id(1028764209630292597)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(1028967423601292882)
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P34_MASTER'
,p_client_condition_expression=>'20'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028762264801292595)
,p_name=>'SET GETEX Logo'
,p_event_sequence=>600
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'( (20 = :P34_STRG_GETEX_ANZEIGE ) ',
'-- and (:P25_EDIT_MODE is not null) and (1 =:P25_EDIT_MODE )',
')'))
,p_display_when_cond2=>'PLSQL'
,p_da_event_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'( (20 = :P34_STRG_GETEX_ANZEIGE ) ',
'and (:P34_EDIT_MODE is not null) and (1 =:P34_EDIT_MODE )',
')'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028761777948292594)
,p_event_id=>wwv_flow_imp.id(1028762264801292595)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'#P34_EINSATZDATUM_MODELLID_DISPLAY,#P34_VORSCHRIFT_TYPID_DISPLAY,#P34_FAHRZEUGKLASSE_DISPLAY,#P34_VORSCHRIFT_STATUSID_DISPLAY,#rEinsatzdaten .t-Region-header,#rLaender .t-Region-header,#rThemen .t-Region-header'
,p_attribute_01=>'getexlogo'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028761266664292594)
,p_event_id=>wwv_flow_imp.id(1028762264801292595)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'#P34_VORSCHRIFT_NUMMER_DISPLAY,#P34_VORSCHRIFT_BEZEICHNUNG_DISPLAY,#P34_TITEL_KURZ_DISPLAY'
,p_attribute_01=>'getexlogo'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028760840274292594)
,p_name=>'DELETE_SEL_AMENDMENTS'
,p_event_sequence=>610
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1028875327607292709)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028760352911292594)
,p_event_id=>wwv_flow_imp.id(1028760840274292594)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('M\00F6chten Sie die ausgew\00E4hlten Verkn\00FCpfungen l\00F6schen?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028759845350292593)
,p_event_id=>wwv_flow_imp.id(1028760840274292594)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var sel_rows_a = $("#P34_SELECTED_AMENDM_ROWS");',
'sel_rows_a.val("");',
'$("#report-amendments").find("td input:checked").each(function() {',
'  // alert(this.value);',
'  if(sel_rows_a.val().length > 0) {',
'    sel_rows_a.val(sel_rows_a.val() + "|");    ',
'  }',
'  sel_rows_a.val(sel_rows_a.val() + this.value);',
' // alert(sel_rows_a.val());',
'});'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028759336743292593)
,p_event_id=>wwv_flow_imp.id(1028760840274292594)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'   -- debug (''P34_SELECTED_AMENDM_ROWS='' || :P34_SELECTED_AMENDM_ROWS);',
unistr('    -- aenderung der Getex_attr f\00FCr beide voschriften  '),
'    update t_vorschrift set letzte_aenderung_getex_attr = sysdate ',
'    where Vorschriftid  in (',
'        select  vorgaenger_vorschriftid from t_vorschrift_ref_vorschrift',
'        where vorschrift_ref_vorschriftid  in  --(select  column_value from apex_string.split(:P34_SELECTED_AMENDM_ROWS,''|'') x)',
'                                             ( select vorschrift_ref_vorschriftid from t_vorschrift_ref_vorschrift vrv',
'                                                join table (apex_string.split(:P34_SELECTED_AMENDM_ROWS,''|'') ) x on (x.column_value = vrv.rowid) )',
'         union ',
'          select  nachfolger_vorschriftid from t_vorschrift_ref_vorschrift',
'        where vorschrift_ref_vorschriftid  in ( select vorschrift_ref_vorschriftid from t_vorschrift_ref_vorschrift vrv',
'                                                join table (apex_string.split(:P34_SELECTED_AMENDM_ROWS,''|'') ) x on (x.column_value = vrv.rowid) )',
'    );',
'    ',
'     for x in (',
'        select vrv.vorschrift_ref_vorschriftid',
'        from apex_string.split(:P34_SELECTED_AMENDM_ROWS,''|'') x',
'        join t_vorschrift_ref_vorschrift vrv on (x.column_value = vrv.rowid)',
'    )',
'    loop',
'        delete from t_vorschrift_ref_vorschrift_ref_thema where vorschrift_ref_vorschriftid = x.vorschrift_ref_vorschriftid;',
'        delete from t_vorschrift_ref_vorschrift where vorschrift_ref_vorschriftid = x.vorschrift_ref_vorschriftid;',
'    end loop;',
'   ',
'    ',
'end;'))
,p_attribute_02=>'P34_SELECTED_AMENDM_ROWS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028758906429292593)
,p_event_id=>wwv_flow_imp.id(1028760840274292594)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1952421574103429466)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028758431346292592)
,p_name=>'DIALOG_AMENDMENT_CLOSED'
,p_event_sequence=>620
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1952421421779429465)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028758013213292592)
,p_event_id=>wwv_flow_imp.id(1028758431346292592)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1952421574103429466)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028830763774292631)
,p_name=>unistr('Dialog Closed From Page 29 - Aenderungen zur Pr\00FCfung/\00DCbernahme Page')
,p_event_sequence=>630
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId && this.data.dialogPageId == 29'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028830259626292631)
,p_event_id=>wwv_flow_imp.id(1028830763774292631)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'EVENT_SOURCE'
,p_attribute_01=>'apex.page.submit("REFRESH");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028756691999292591)
,p_name=>'Dialog Closed From Page 31 - Kerndaten Bearbeiter'
,p_event_sequence=>640
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId && this.data.dialogPageId == 31'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028756197075292591)
,p_event_id=>wwv_flow_imp.id(1028756691999292591)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'EVENT_SOURCE'
,p_attribute_01=>'apex.page.submit("REFRESH");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028831629367292631)
,p_name=>'Dialog Closed From Page 32 - Edit Lead VKO'
,p_event_sequence=>660
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId && this.data.dialogPageId == 32'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028831118384292631)
,p_event_id=>wwv_flow_imp.id(1028831629367292631)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'EVENT_SOURCE'
,p_attribute_01=>'apex.page.submit("REFRESH");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028755815557292589)
,p_name=>'Dialog Closed From Page 32 - Edit Lead VKO_1'
,p_event_sequence=>670
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1028851142195292685)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028755257428292589)
,p_event_id=>wwv_flow_imp.id(1028755815557292589)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_LEAD_VKO'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028757561973292591)
,p_name=>'Dialog Closed From Page 37 - Edit Einsatzdaten'
,p_event_sequence=>680
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId && this.data.dialogPageId == 37'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028757028714292591)
,p_event_id=>wwv_flow_imp.id(1028757561973292591)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'EVENT_SOURCE'
,p_attribute_01=>'apex.page.submit("REFRESH");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1028832530125292639)
,p_name=>'Dialog Closed From Page 37 - Edit Einsatzdaten_1'
,p_event_sequence=>690
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1028902795295292762)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1028832061334292633)
,p_event_id=>wwv_flow_imp.id(1028832530125292639)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9426008489308293132)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1027685324472552908)
,p_name=>'Dialog Closed From Page 37 - Edit Einsatzdaten_1_1'
,p_event_sequence=>700
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(9426008489308293132)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1027685224619552907)
,p_event_id=>wwv_flow_imp.id(1027685324472552908)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9426008489308293132)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1028835317788292644)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_VORSCHRIFT'
,p_attribute_02=>'T_VORSCHRIFT'
,p_attribute_03=>'P34_ROWID'
,p_attribute_04=>'ROWID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2643376998111095591
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1028836576456292645)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'check_letzte_Aenderung_GETEX_attr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'     l_any_attr_changed number :=0;',
'begin',
'   -- debug(''Seite 25'', ''Rowstatus: '' || :APEX$ROW_STATUS);',
'    if(:P34_VORSCHRIFTID is not null ) then   --and :P34_VORSCHRIFT_TYPID <> 20) then',
'        -- debug('' P34_EINSATZDATUM_MODELLID: '' || :P34_EINSATZDATUM_MODELLID);',
unistr('        -- wird erst f\00FCr naechste entwicklungsstufe vorgesehen --------'),
'         if (   pck_ri_getex.fIsEinsatzdatumModelChanging(:P34_VORSCHRIFTID, :P34_EINSATZDATUM_MODELLID) >0',
'             OR',
'              pck_ri_getex.fIsFzgKlasseListChanging(:P34_VORSCHRIFTID, :P34_FAHRZEUGKLASSE) >0 )',
'         then',
'              ',
'            update t_Vorschrift set letzte_aenderung_getex_attr = sysdate where Vorschriftid  = :P34_VORSCHRIFTID',
'            and (letzte_aenderung_getex_attr is null or letzte_aenderung_getex_attr <= sysdate - 0.0001 ); -- ca 8 sec;',
'            return;',
'         else',
'            select count (*) into l_any_attr_changed ',
'            from  T_VORSCHRIFT',
'            where  VORSCHRIFTID = :P34_VORSCHRIFTID and VORSCHRIFT_BEZEICHNUNG != :P34_VORSCHRIFT_BEZEICHNUNG;',
'            if (l_any_attr_changed >0) then',
'               update t_Vorschrift set letzte_aenderung_getex_attr = sysdate where Vorschriftid  = :P34_VORSCHRIFTID',
'               and (letzte_aenderung_getex_attr is null  or letzte_aenderung_getex_attr <= sysdate - 0.0001 );',
'               return;',
'            end if;',
'            -- Vorschr._sttatus',
'            select count (*) into l_any_attr_changed ',
'            from  T_VORSCHRIFT',
'            where  VORSCHRIFTID = :P34_VORSCHRIFTID and VORSCHRIFT_STATUSID != :P34_VORSCHRIFT_STATUSID;',
'            if (l_any_attr_changed >0) then',
'               update t_Vorschrift set letzte_aenderung_getex_attr = sysdate where Vorschriftid  = :P34_VORSCHRIFTID',
'               and (letzte_aenderung_getex_attr is null  or letzte_aenderung_getex_attr <= sysdate - 0.0001 );',
'               return;',
'            end if;',
'           -- Vorschr.-nummer',
'            select count (*) into l_any_attr_changed ',
'            from  T_VORSCHRIFT',
'            where  VORSCHRIFTID = :P34_VORSCHRIFTID and VORSCHRIFT_NUMMER != :P34_VORSCHRIFT_NUMMER;',
'            if (l_any_attr_changed >0) then',
'               update t_Vorschrift set letzte_aenderung_getex_attr = sysdate where Vorschriftid  = :P34_VORSCHRIFTID',
'               and (letzte_aenderung_getex_attr is null  or letzte_aenderung_getex_attr <= sysdate - 0.0001 );',
'               return;',
'            end if;',
'            -- Vorschr._-typ',
'            select count (*) into l_any_attr_changed ',
'            from  T_VORSCHRIFT',
'            where  VORSCHRIFTID = :P34_VORSCHRIFTID and VORSCHRIFT_TYPID != :P34_VORSCHRIFT_TYPID;',
'            if (l_any_attr_changed >0) then',
'               update t_Vorschrift set letzte_aenderung_getex_attr = sysdate where Vorschriftid  = :P34_VORSCHRIFTID',
'               and (letzte_aenderung_getex_attr is null  or letzte_aenderung_getex_attr <= sysdate - 0.0001 );',
'               return;',
'            end if;',
'',
'         end if;',
'',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1028877303696292710)
,p_internal_uid=>2643375739443095590
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1028834996500292644)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process Row of T_VORSCHRIFT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  lInKraft number default 1;',
'  exc_not_saved exception;',
'  PRAGMA exception_init( exc_not_saved, -20101 );',
'begin',
'',
'if (:P34_VORSCHRIFT_FREIGABESTATUSID = 40)',
'then',
'    select count(*) into lInKraft',
'    from t_vorschrift_ref_einsatzdatum_typ',
'    where einsatzdatum_typid = 1000 and vorschriftid = :P34_VORSCHRIFTID;',
'end if;',
'',
'if lInkraft < 1 then',
'    apex_error.add_error(p_message => ''Bitte geben Sie ein Datum Inkraftsetzung ein bevor Sie die Vorschrift auf In Kraft setzen'', p_display_location => apex_error.c_inline_in_notification);',
'    --debug(''page25: Error lInklraft'', lInKraft);',
'else',
'',
'    if (:REQUEST = ''CREATE'') then -- neue Vorschrift/Supplement anlegen',
'        --debug(''page25: insert Vorschr'', '''');',
'        insert into t_vorschrift (',
'            vorschrift_nummer',
'            , vorschrift_bezeichnung',
'            -- , vorschrift_bezeichnung_deutsch',
'            , prognose_qualitaetid',
'            , jira_ticket',
'            , vorschrift_freigabestatusid',
'            , bemerkung',
'            , bemerkung_englisch',
'            , link_zur_vorschrift_dms',
'            , link_zur_vorschrift_getex',
'            , websiteid',
'            , websitelink',
'            , einsatzdatum_modellid',
'            , vorschrift_typid',
'            , normid',
'            , ksuid',
'            , vorschrift_statusid',
'            , homologationsrelevant',
'            , rxswin',
'            , cop_relevant',
'            , technologie',
'            , without_norm_validation',
'            , link_reqman',
'            , swr_hauptumsetzende_OE',
'            , mj_schalter_status  -- 1- modeljahr angabe  0- datumeingabe ',
'            , phasein_enthalten',
'            , LEAD_VKO_benutzerid',
'            , REVISIONSZAEHLER',
'            , inhaltlich_sachlich_geprueft',
'            , master -- new ',
'            , getex_vergleich_bitmaske',
'        ) VALUES (',
'            trim(:P34_VORSCHRIFT_NUMMER )--|| trim(:P34_TEXT_FOR_NUMMER)',
'            , :P34_VORSCHRIFT_BEZEICHNUNG ',
'            -- , :P34_VORSCHRIFT_BEZEICHNUNG_DEUTSCH',
'            , :P34_PROGNOSE_QUALITAETID',
'            , :P34_JIRA_TICKET',
'            , 1',
'            , :P34_BEMERKUNG ',
'            , :P34_BEMERKUNG_ENGLISCH',
'            , :P34_LINK_ZUR_VORSCHRIFT_DMS ',
'            , :P34_LINK_ZUR_VORSCHRIFT_GETEX ',
'            , :P34_WEBSITEID ',
'            , :P34_WEBSITELINK',
'            , :P34_EINSATZDATUM_MODELLID',
'            , :P34_VORSCHRIFT_TYPID ',
'            , nvl(:P34_NORMID, 1016)',
'            , :P34_KSU',
'            , :P34_VORSCHRIFT_STATUSID ',
'            , :P34_HOMOLOGATIONSRELEVANT ',
'            , :P34_RXSWIN',
'            , :P34_COP_RELEVANT',
'            , :P34_TECHNOLOGIE',
'            , :P34_WITHOUT_NORM_VALIDATION',
'            , :P34_LINK_REQMAN',
'            , :P34_SWR_HAUPTUMSETZENDE_OE',
'            , :P34_DATUM_ANGABE_AS_MJ',
'            , :P34_PHASEIN_ENTHALTEN',
'            , :P34_LEAD_VKO',
'            , 1',
'            , nvl(:P34_INHALTLICH_SACHLICH_GEPRUEFT,10)',
'            , :P34_MASTER -- new ',
'            , -1  -- getex_vergleich_bitmaske = no match',
'        ) RETURNING rowid, vorschriftid INTO :P34_ROWID, :P34_VORSCHRIFTID;',
unistr('        if ( nvl(:P34_VORSCHRIFTID,0) > 0 and nvl(:P34_PARENT_VORSCHRIFTID,0)>0) then  -- verkn\00FCpf to parent'),
'           insert into t_vorschrift_ref_vorschrift (',
'            vorgaenger_vorschriftid, nachfolger_vorschriftid , beziehung_art)',
'               values(:P34_PARENT_VORSCHRIFTID , :P34_VORSCHRIFTID, (case when :P34_VORSCHRIFT_TYPID=20 then 30 else 20 end));',
'        end if;              ',
'             ',
'       /* deactiv nach Anforderung regindexe-512',
'       if( nvl(:P34_VORSCHRIFTID,0) > 0)  then',
'           -- create SW-Relev  Notation to AK E18 (is  ak independent)',
'           PCK_RI_BENACHRICHTIGUNG.pBenachrichtigungSWRelevanz(:P34_VORSCHRIFTID);',
'        end if;',
'    */',
'',
unistr('    elsif (:REQUEST = ''SAVE'' or (:REQUEST = ''CHANGE_FREIGABE_STATE'' and :P34_EDIT_MODE = 1)) then -- vorhandene Vorschrift/Supplement \00E4ndern/speichern'),
'    ',
'        UPDATE t_vorschrift',
'        SET vorschrift_nummer = trim(:P34_VORSCHRIFT_NUMMER)',
'            , vorschrift_bezeichnung = :P34_VORSCHRIFT_BEZEICHNUNG',
'            -- , vorschrift_bezeichnung_deutsch = :P34_VORSCHRIFT_BEZEICHNUNG_DEUTSCH',
'            , prognose_qualitaetid = :P34_PROGNOSE_QUALITAETID',
'            , jira_ticket = :P34_JIRA_TICKET',
'            , vorschrift_freigabestatusid = :P34_VORSCHRIFT_FREIGABESTATUSID',
'            , bemerkung = :P34_BEMERKUNG',
'            , bemerkung_englisch = :P34_BEMERKUNG_ENGLISCH',
'            , link_zur_vorschrift_dms = :P34_LINK_ZUR_VORSCHRIFT_DMS',
'            , link_zur_vorschrift_getex = :P34_LINK_ZUR_VORSCHRIFT_GETEX',
'            , websiteid = :P34_WEBSITEID',
'            , websitelink = :P34_WEBSITELINK',
'            , einsatzdatum_modellid = :P34_EINSATZDATUM_MODELLID',
'            , vorschrift_typid = :P34_VORSCHRIFT_TYPID',
'            , normid = nvl(:P34_NORMID, 1016)',
'            , ksuid = :P34_KSU',
'            , vorschrift_statusid = :P34_VORSCHRIFT_STATUSID',
'            , homologationsrelevant = :P34_HOMOLOGATIONSRELEVANT',
'            , rxswin = :P34_RXSWIN',
'            , cop_relevant = :P34_COP_RELEVANT',
'            , rev_notwendig = :P34_REV_NOTWENDIG',
'            , technologie = :P34_TECHNOLOGIE',
'            , without_norm_validation = :P34_WITHOUT_NORM_VALIDATION',
'            , link_reqman = :P34_LINK_REQMAN',
'            , swr_hauptumsetzende_OE = :P34_SWR_HAUPTUMSETZENDE_OE',
'            , mj_schalter_status = :P34_DATUM_ANGABE_AS_MJ',
'            , PHASEIN_ENTHALTEN = :P34_PHASEIN_ENTHALTEN',
'            , LEAD_VKO_benutzerid = :P34_LEAD_VKO',
'            , REVISIONSZAEHLER = REVISIONSZAEHLER +1',
'            , master=:P34_MASTER -- new',
'           -- , inhaltlich_sachlich_geprueft = nvl(:P34_INHALTLICH_SACHLICH_GEPRUEFT,inhaltlich_sachlich_geprueft)',
'        WHERE rowid = :P34_ROWID;',
'       /*  deactiv nach Anforderung regindexe-512',
'        --PCK_RI_BENACHRICHTIGUNG.pBenachrichtigungSWRelevanz(:P34_VORSCHRIFTID); */',
'    end if; -- :REQUEST save Ende',
'',
'end if; -- Ende Validate Einsatzdatum',
'',
'',
unistr('    -- Wenn das Einsatzdatumsmodell gewechselt wurde, dann die Datumsangaben der vorherigen Modelle l\00F6schen'),
'    delete from t_vorschrift_ref_einsatzdatum_typ where vorschrift_ref_einsatzdatum_typid in (',
'        select vret.vorschrift_ref_einsatzdatum_typid',
'        from t_vorschrift v',
'        join t_vorschrift_ref_einsatzdatum_typ vret on (v.vorschriftid = vret.vorschriftid)',
'        join t_einsatzdatum_typ et on (vret.einsatzdatum_typid = et.einsatzdatum_typid)',
'        where v.vorschriftid = :P34_VORSCHRIFTID and v.einsatzdatum_modellid != et.einsatzdatum_modellid and et.einsatzdatum_modellid is not null',
'    );',
'',
' --EXCEPTION when OTHERS then',
unistr(' -- raise_application_error(-20101,''Vorschrift/\00C4nderungen nicht gespeichert'');'),
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Fehler ist aufgetretten, Vorschrift ist nicht gespeichert'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE,CHANGE_FREIGABE_STATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_process_success_message=>'Vorschrift gespeichert.'
,p_internal_uid=>2643377319399095591
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1028835778579292644)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Benachrichtigung an Administratoren'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
' Opened_Notif number :=0;',
'Begin',
'-- check  offene & ''in Bearbeitung''',
'select count(*) into Opened_Notif from t_Benachrichtigung WHERE VORSCHRIFTID = :P34_VORSCHRIFTID and status in (10, 20) and grund = 20;',
'',
'    if (:P34_WITHOUT_NORM_VALIDATION = 1 and Opened_Notif = 0 ) then',
unistr('      PCK_RI_BENACHRICHTIGUNG.pBenachrichtigung(:P34_VORSCHRIFTID, ''1200'', ''Vorschrift ge\00E4ndert/erstellt ohne Pr\00FCfung von Notation'',  20, 0, :G_BENUTZERID);'),
'      commit;',
'    end if;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE,CHANGE_FREIGABE_STATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2643376537320095591
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1028833335989292642)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'getVorschriftid'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vorschriftid into :P34_VORSCHRIFTID',
'from t_vorschrift',
'where rowid = :P34_ROWID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2643378979910095593
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1028833752828292642)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_PARENT_VORSCHRIFT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--debug(''save Parent:  vorschrid '' , :P34_VORSCHRIFTID);',
'--debug(''save Parent: parent_vorschrid '' , :P34_PARENT_VORSCHRIFTID);',
'if (:P34_VORSCHRIFTID is not null   and :P34_VORSCHRIFT_TYPID in (20, 50)) then',
'merge into T_VORSCHRIFT_REF_VORSCHRIFT dest',
'using (select  :P34_VORSCHRIFTID  as vorschriftid,   ',
'              :P34_PARENT_VORSCHRIFTID as parent_vorschriftid,  ',
'           case when :P34_VORSCHRIFT_TYPID =20 then 30 else 20 end as beziehung_art ',
'           from dual) src',
'    on (src.vorschriftid = dest.nachfolger_vorschriftid ',
'       and src.beziehung_art = dest.beziehung_art)',
'    when not matched then insert (',
'       dest.nachfolger_vorschriftid, ',
'       dest.vorgaenger_vorschriftid,',
'        dest.beziehung_art',
'    ) VALUES (',
'       src.vorschriftid , ',
'       src.parent_vorschriftid,',
'        src.beziehung_art',
'    )',
'    when matched then update ',
'      set dest.vorgaenger_vorschriftid = src.parent_vorschriftid;',
'end if; ',
'    ',
'    ',
'    '))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('Das Supplement konnte nicht der \00FCbergeordneten Vorschrift zugeordnet werden.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE, CHANGE_FREIGABE_STATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2643378563071095593
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1028832987884292642)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_IN_KRAFT_DATUM_SUPPLEMENT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--debug(''In Kraft Supplement'');',
'merge into T_VORSCHRIFT_REF_EINSATZDATUM_TYP dest',
'using (select :P34_VORSCHRIFTID as vorschriftid, :P34_IN_KRAFT_DATUM_SUPPLEMENT as in_kraft_datum from dual) src',
'    on (src.vorschriftid = dest.vorschriftid ',
'       and 1000 = dest.einsatzdatum_typid)',
'    when matched then update set ',
'        dest.einsatzdatum = in_kraft_datum',
'    when not matched then insert (',
'       vorschriftid, ',
'       einsatzdatum,',
'       einsatzdatum_typid',
'    ) VALUES (',
'       src.vorschriftid,',
'       src.in_kraft_datum,',
'       1000',
'    );',
'    ',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P34_VORSCHRIFTID is not null ',
'  and :P34_VORSCHRIFT_TYPID = 20)'))
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>2643379328015095593
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1028834580789292643)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2643377735110095592
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1028837785961292646)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Fahrzeugklasse - Save Tag Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--debug(''Fahrzeugklasse Vorschrift'');',
'merge into T_VORSCHRIFT_REF_FAHRZEUGKLASSE dest',
'using (select :P34_VORSCHRIFTID as vorschriftid, column_value as fahrzeugklasseid ',
'       from table (apex_string.split_numbers(:P34_FAHRZEUGKLASSE, '':''))) src',
'    on (src.vorschriftid = dest.vorschriftid ',
'       and src.fahrzeugklasseid = dest.fahrzeugklasseid)',
'    when not matched then insert (',
'       vorschriftid, ',
'       fahrzeugklasseid',
'    ) VALUES (',
'       src.vorschriftid,',
'       src.fahrzeugklasseid',
'    );',
'    ',
'delete from T_VORSCHRIFT_REF_FAHRZEUGKLASSE',
'where vorschriftid = :P34_VORSCHRIFTID',
'    and fahrzeugklasseid not in (',
'        select column_value',
'        from table(apex_string.split_numbers(:P34_FAHRZEUGKLASSE, '':''))',
'    );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P34_VORSCHRIFTID is not null ',
'  and :P34_VORSCHRIFT_TYPID IN (10,40,30) and :REQUEST = ''SAVE'' and nvl(:P34_EDIT_MODE, 0) = 1)'))
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>2643374529938095589
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1028854544507292690)
,p_process_sequence=>150
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(5707933731121382676)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Verlinkte Normen - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P34_VORSCHRIFTID is not null ',
'  and :P34_VORSCHRIFT_TYPID <> 20)'))
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'SQL'
,p_exec_cond_for_each_row=>'Y'
,p_internal_uid=>2643357771392095545
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1028836917862292645)
,p_process_sequence=>160
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Check & Set Getex Status'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--pck_ri_getex.pVergleichAttributevonGetex(:P34_VORSCHRIFTID);',
'pck_ri_getex.pCompareVorschrift(:P34_VORSCHRIFTID);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1028877303696292710)
,p_process_when=>'(:P34_VORSCHRIFTID is not null)'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>2643375398037095590
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1028838125510292646)
,p_process_sequence=>170
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'refresh cockpit_neu'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for a in (',
'    Select distinct landid',
'    from t_vorschrift_ref_land',
'    where vorschriftid = :P34_Vorschriftid',
'    and nvl(geloescht,0) = 0',
'    union',
'    Select distinct landid',
'    from t_vorschrift_ref_vorschrift tvrv ',
'    join t_vorschrift_ref_land trfl on (',
'        (trfl.vorschriftid = tvrv.vorgaenger_vorschriftid or trfl.vorschriftid = tvrv.nachfolger_vorschriftid )',
'        and beziehung_art in (40,102)',
'    )',
'    where (tvrv.vorgaenger_vorschriftid = :P34_Vorschriftid or trfl.vorschriftid = :P34_Vorschriftid)',
')',
'loop',
'PCK_RI_COCKPIT2.pAufbereitungDaten(a.LandID);',
'',
'end loop;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2643374190389095589
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1028834132738292642)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load ROWID'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--evaluate P615_VORSCHRIFTID  if it''s set use it ',
'if (:P34_ROWID is null and :P34_VORSCHRIFTID is not null)',
'then',
'   select rowid, status_update_getex into :P34_ROWID, :P34_IMPORT_STATUS from t_vorschrift where vorschriftid = :P34_VORSCHRIFTID;',
'elsif (:P34_ROWID is not null and :P34_VORSCHRIFTID is  null) then',
'   select vorschriftid, status_update_getex into :P34_VORSCHRIFTID, :P34_IMPORT_STATUS from t_vorschrift where  rowid= :P34_ROWID ;',
'',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':P34_VORSCHRIFTID is not null or :P34_ROWID is not null'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'SQL'
,p_internal_uid=>2643378183161095593
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1028837335894292646)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Import Status for Getex'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  l_co  number :=0;',
'  l_status_update number := 10;',
'  l_intern_status number := 0;',
'begin',
'   ',
'-- check  status_update_getex',
'   select status_update_getex into l_status_update from t_vorschrift where vorschriftid = :P34_VORSCHRIFTID;',
'    if (l_status_update is not null and  l_status_update = 20) then  -- some differences',
'        :P34_IMPORT_STATUS := 1;',
'    elsif  (l_status_update is not null and  l_status_update = 10 or l_status_update = 30) then  -- no ifferences or error',
'        :P34_IMPORT_STATUS := 0;',
'    else ',
'         select  count(*) into l_co from T_X_GETEX_IMPORT txgi',
'         join t_vorschrift tv on  ( tv.REGINDEXID is not null and txgi.GETEX_SCHLUESSEL = tv.REGINDEXID  )',
'        where   tv.VORSCHRIFTID =:P34_VORSCHRIFTID  ;',
'  ',
'       if (l_co >0) then ',
'           ',
'            select  DISTINCT(STATUS) into l_intern_status ',
'              from T_X_GETEX_IMPORT txgi',
'              join t_vorschrift tv on  ( tv.REGINDEXID is not null and txgi.GETEX_SCHLUESSEL = tv.REGINDEXID  )',
'             where   tv.VORSCHRIFTID =:P34_VORSCHRIFTID  ;',
'             if (l_intern_status != 30)  then ',
'                 :P34_IMPORT_STATUS := 1;',
'             end if;',
'',
'       else ',
'     -- there is no  data in GETEX for this vorschrift',
'     --  therefore set status to 2  to force hiding the  button ''Getex''',
'         :P34_IMPORT_STATUS := 2;',
'       end if;',
'   end if;',
'',
'   exception when no_data_found then :P34_IMPORT_STATUS :=0;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2643374980005095589
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1028836166875292645)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Daten laden'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- Permalink in Item speichern beim \00D6ffnen der Seite  '),
':P34_PERMALINK := apex_util.host_url(''SCRIPT'') || apex_page.get_url(',
'    p_application => :APP_ALIAS',
'    , p_page => ''VORSCHRIFT''',
'    , p_items => ''P34_VORSCHRIFTID''',
'    , p_values => :P34_VORSCHRIFTID',
'    , p_session => null',
'    , p_clear_cache => ''25''',
');',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2643376149024095590
);
wwv_flow_imp.component_end;
end;
/
