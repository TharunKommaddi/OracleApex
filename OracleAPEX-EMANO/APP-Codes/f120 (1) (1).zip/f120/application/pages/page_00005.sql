prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Browser Support'
,p_alias=>'BROWSER-SUPPORT'
,p_step_title=>'Browser Support'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(3414109515918820536)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(842898892293855001)
,p_plug_name=>unistr('Kein Support f\00FCr Internet Explorer 11')
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--danger'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<br />Bitte verwenden Sie f\00FCr diese Applikation den Browser Mozilla Firefox oder Microsoft Edge.<br /><br />'),
unistr('Sie k\00F6nnen den Regulation Index anschlie\00DFend \00FCber den folgenden Link \00F6ffnen:<br /><br />'),
'<a href="https://portal.epp.audi.vwg/pkmscdsso?https://apps1.web.audi.vwg/apexaudi-sp/apex-sp/f?p=regindex"><span class="fa fa-external-link"></span> <span style="text-decoration: underline">https://portal.epp.audi.vwg/pkmscdsso?https://apps1.web.aud'
||'i.vwg/apexaudi-sp/apex-sp/f?p=regindex</span></a>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
