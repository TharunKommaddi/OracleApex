prompt --application/pages/page_00230
begin
--   Manifest
--     PAGE: 00230
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>230
,p_name=>'Subcountries'
,p_alias=>'SUBCOUNTRIES'
,p_step_title=>unistr('Subl\00E4nder Mapping')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3170883066692169429)
,p_plug_name=>'Mapping Typ'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr(' Typ 1  - L\00E4nder vom Typ ''SUBCOUNTRY'' in GETEX <br>'),
unistr(' Typ 2  - L\00E4nder vom Typ ''COUNTRY''  in GETEX, die in den L\00E4ndern von Regindex nicht vorkommen <br>'),
unistr(' Typ 3  - L\00E4nder, welche den Arabischen Emiraten geh\00F6ren und den gleichen ISO code in Getex haben: '),
'(Abu Dhabi, Dubai)'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(658868909546856720)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414126953447820548)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3414151185686820583)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(3414145144550820567)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(658868330207856716)
,p_plug_name=>unistr('Mapping der Subl\00E4nder')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select  lm.LAND_MAPPING_GETEXID, lm.MAPPING_TYP MAPPING_TYP, lm.MAPPING_TEXT MAPPING_TEXT ,  gs.name as Subcountry,',
'       (select LAND from T_LAND where LANDID = lm.LANDID ) as LAND, lm.bemerkung',
'from T_LAND_MAPPING_GETEX lm',
'join T_X_getex_Subcountry_map gs on (lm.MAPPING_TEXT = gs.ISOCODE and gs.Type= ''SUB_COUNTRY''',
'or lm.MAPPING_TEXT = gs.ISOCODE3)',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Mapping der Subl\00E4nder')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Select  LAND_MAPPING_GETEXID, lm.MAPPING_TYP MAPPING_TYP, lm.MAPPING_TEXT MAPPING_TEXT,  ',
' --      (select LAND from T_LAND where LANDID = lm.LANDID ) as LAND, lm.bemerkung',
'-- from T_LAND_MAPPING_GETEX lm'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(658868200899856716)
,p_name=>'Subcountries'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'Keine Daten Vorhanden.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_pivot=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:235:&SESSION.::&DEBUG.::P235_LAND_MAPPING_GETEXID:\#LAND_MAPPING_GETEXID#\'
,p_detail_link_text=>'<span class="fa fa-pencil" aria-hidden="true"></span>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>453824736195277688
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(658867834251856703)
,p_db_column_name=>'LAND_MAPPING_GETEXID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'&nbsp;'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(658867398670856696)
,p_db_column_name=>'MAPPING_TYP'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Mapping Typ'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(658866970620856696)
,p_db_column_name=>'MAPPING_TEXT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Mapping Text'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(669153030571068774)
,p_db_column_name=>'LAND'
,p_display_order=>13
,p_column_identifier=>'E'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644171562675575984)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>23
,p_column_identifier=>'F'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1097457170084393495)
,p_db_column_name=>'SUBCOUNTRY'
,p_display_order=>33
,p_column_identifier=>'G'
,p_column_label=>'Subland'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(658866174809853638)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4538268'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'MAPPING_TYP:MAPPING_TEXT:SUBCOUNTRY:LAND:BEMERKUNG:'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(1091388376423772543)
,p_report_id=>wwv_flow_imp.id(658866174809853638)
,p_name=>unistr('Zeilentext enth\00E4lt ''A''')
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'A'
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(658699029032885399)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(658868330207856716)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:235:&SESSION.::&DEBUG.:235::'
,p_button_condition=>'pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(669152863819068773)
,p_name=>'Dialodg Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(658699029032885399)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(669152798031068772)
,p_event_id=>wwv_flow_imp.id(669152863819068773)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(658868330207856716)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(658639740898621096)
,p_name=>'Edit-Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(658868330207856716)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(658639721626621095)
,p_event_id=>wwv_flow_imp.id(658639740898621096)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(658868330207856716)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
