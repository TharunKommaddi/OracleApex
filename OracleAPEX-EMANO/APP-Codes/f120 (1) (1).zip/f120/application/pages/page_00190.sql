prompt --application/pages/page_00190
begin
--   Manifest
--     PAGE: 00190
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>190
,p_name=>'Hilfe Bilder'
,p_step_title=>'Hilfe Bilder'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(210692048345802486)
,p_name=>'Bilderliste'
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "HILFE_BILDID", ',
'"BILD_KOMMENTAR",',
'dbms_lob.getlength("BILD_BLOB") "BILD_BLOB",',
'''f?p=REGINDEX:0::APPLICATION_PROCESS%3DgetHelpPicture:NO::G_HILFE_BILDID:'' ||HILFE_BILDID as BIld_URL',
'',
'from "#OWNER#"."T_HILFE_BILD" ',
'  ',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_query_row_count_max=>500
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(210692769859802497)
,p_query_column_id=>1
,p_column_alias=>'HILFE_BILDID'
,p_column_display_sequence=>1
,p_column_link=>'f?p=#APP_ID#:195:#APP_SESSION#::::P195_HILFE_BILDID:#HILFE_BILDID#'
,p_column_linktext=>'<span class="fa fa-pencil" aria-hidden="true"></span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_ref_schema=>'VORSCHRIFTEN_ADMIN'
,p_ref_table_name=>'T_HILFE_BILD'
,p_ref_column_name=>'HILFE_BILDID'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(210693117129802498)
,p_query_column_id=>2
,p_column_alias=>'BILD_KOMMENTAR'
,p_column_display_sequence=>2
,p_column_heading=>'Bild Kommentar'
,p_heading_alignment=>'LEFT'
,p_ref_schema=>'VORSCHRIFTEN_ADMIN'
,p_ref_table_name=>'T_HILFE_BILD'
,p_ref_column_name=>'BILD_KOMMENTAR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(210693502096802499)
,p_query_column_id=>3
,p_column_alias=>'BILD_BLOB'
,p_column_display_sequence=>3
,p_column_heading=>'Bild'
,p_column_format=>'DOWNLOAD:T_HILFE_BILD:BILD_BLOB:HILFE_BILDID::MIME_TYPE:FILENAME:::attachment::'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_ref_schema=>'VORSCHRIFTEN_ADMIN'
,p_ref_table_name=>'T_HILFE_BILD'
,p_ref_column_name=>'BILD_BLOB'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(210712332415191202)
,p_query_column_id=>4
,p_column_alias=>'BILD_URL'
,p_column_display_sequence=>4
,p_column_heading=>'Bild Url'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(210695723313802502)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(210692048345802486)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:195:&SESSION.::&DEBUG.:195'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(210694808476802500)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(210692048345802486)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(210695343765802501)
,p_event_id=>wwv_flow_imp.id(210694808476802500)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(210692048345802486)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(210696127576802502)
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(210695723313802502)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(210696631064802502)
,p_event_id=>wwv_flow_imp.id(210696127576802502)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(210692048345802486)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
