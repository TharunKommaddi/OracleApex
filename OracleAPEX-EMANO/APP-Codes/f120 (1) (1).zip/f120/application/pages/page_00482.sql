prompt --application/pages/page_00482
begin
--   Manifest
--     PAGE: 00482
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>482
,p_name=>'Post-process Hub'
,p_alias=>'POST-PROCESS-HUB'
,p_step_title=>'Post-process Hub'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'/* Style for each card in the postprocess_cards region */',
'#postprocess_cards .a-CardView {',
'    background-color: #ffffff; /* Clean white background */',
'    border: 1px solid #e0e0e0; /* Subtle border */',
'    border-left: 4px solid #bb0a31; /* Audi red accent color on the left */',
'    border-radius: 8px; /* Slightly more rounded corners */',
'    box-shadow: 0 2px 8px rgba(0,0,0,0.08); /* Soft shadow for depth */',
'    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); /* Smooth transition */',
'    overflow: hidden;',
'    padding: 4px;',
'}',
'',
'/* Style for the card when you hover over it*/',
'#postprocess_cards .a-CardView:hover {',
'    box-shadow: 0 6px 16px rgba(187,10,49,0.15); /* Red-tinted shadow */',
'    border-left-color: #d01a45; /* Brighter red on hover */',
'    border-color: #bb0a31; /* Audi red border all around */',
'}',
'',
'/* Style for the card title - LARGER TEXT */',
'#postprocess_cards .a-CardView-title {',
'    color: #2c2c2c; /* Darker text for better readability */',
'    font-weight: 600;',
'    /* font-size: 1.3rem !important; Larger title text */',
'    margin-bottom: 6px;',
'    line-height: 1.4;',
'}',
'',
'/* Style for the card subtitle - LARGER TEXT */',
'#postprocess_cards .a-CardView-subTitle {',
'    color: #666666; /* Better contrast for readability */',
'    /* font-size: 1rem !important; Larger subtitle text */',
'    font-weight: 400;',
'    line-height: 1.5;',
'}',
'',
'/* Icon styling */',
'#postprocess_cards .a-CardView-icon {',
'    color: #bb0a31; /* Audi red for icons */',
'    /* font-size: 1.8rem !important; Larger icon */',
'}',
'',
'/* Icon wrapper background */',
'#postprocess_cards .a-CardView-iconWrap {',
'    background-color: #fff5f7; /* Very light red background */',
'    border-radius: 50%;',
'    padding: 14px;',
'}',
'',
'/* Additional card view styles */',
'#postprocess_cards .a-CardView-headerBody {',
'    margin-top: 0px;',
'    padding: 10px 8px;',
'}',
'',
'#postprocess_cards .a-CardView-header {',
'    padding: 8px;',
'}',
'',
'/* Full card link hover effect */',
'#postprocess_cards a.a-CardView-fullLink {',
'    transition: all 0.3s ease;',
'}',
'',
'#postprocess_cards a.a-CardView-fullLink:hover {',
'    border: none;',
'}',
'',
'/* Card spacing */',
'#postprocess_cards .a-CardView-item {',
'    margin-bottom: 16px;',
'}',
'',
'/* Card icon container size */',
'#postprocess_cards .t-CardsRegion--styleB {',
'    --a-cv-icon-container-size: 70px;',
'}',
'',
'/* subtle background pattern to the region */',
'#postprocess_cards .t-Region-body {',
'    background-color: #fafafa;',
'    padding: 16px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'&CARD_LINK!RAW.',
'',
'',
'/* Style for each card in the postprocess_cards region */',
'#postprocess_cards .t-Card {',
'    background-color: #f8f9fa; /* A very light grey background */',
'    border: 1px solid #dee2e6; /* A subtle border */',
'    border-left: 4px solid #bb0a31; /* Audi red accent color on the left */',
'    border-radius: 4px;',
'    box-shadow: 0 2px 4px rgba(0,0,0,0.05); /* Soft shadow for depth */',
'    transition: all 0.3s ease; /* Smooth transition for hover effects */',
'}',
'',
'/* Style for the card when you hover over it */',
'#postprocess_cards .t-Card:hover {',
'    transform: translateY(-3px); /* Lifts the card slightly */',
'    box-shadow: 0 4px 8px rgba(0,0,0,0.1); /* A more pronounced shadow */',
'    border-left-color: #d01a45; /* A slightly brighter red on hover */',
'}',
'',
'/* Style for the card title (e.g., "Search 2686") */',
'#postprocess_cards .t-Card-title {',
'    color: #343a40; /* Darker text for better readability */',
'    font-weight: bold;',
'}',
'',
'/* Style for the card subtitle (e.g., "Milestone 2") */',
'#postprocess_cards .t-Card-subtitle {',
'    color: #6c757d; /* Softer color for the secondary text */',
'}',
'',
'',
'',
'.t-CardsRegion--styleB {',
'    --a-cv-icon-container-size: 77px;',
'    }',
'    ',
'    .a-CardView-headerBody {',
'        margin-top: -7px;',
'    }',
'    ',
'    img.a-CardView-iconImg {',
'        margin-top: -20px;',
'    }',
'    a.a-CardView-fullLink:hover{',
'        border: 2px solid #bb0a31;',
'    ',
'    }',
'',
'',
'',
'',
'',
'',
'<div class="no-data-message">',
unistr('    Es wurden <span class="highlight">keine</span> Vorschriftsnummern f\00FCr diese L\00E4nder gefunden. Bitte planen Sie die erforderlichen L\00E4nder.'),
'</div>'))
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2317348600060245194)
,p_plug_name=>unistr('Post-process erstellen oder ausw\00E4hlen')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2317348688445245195)
,p_plug_name=>unistr('Mit dieser Post-process verkn\00FCpfte Suchen')
,p_region_name=>'postprocess_cards'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ''Suche ID: '' || s.sucheid ',
'    -- || '' (ID: '' || s.sucheid || '')'' ',
'    AS card_title,',
unistr('    ''Meilenstein '' || s.meilenstein || '' \2022 '' || TO_CHAR(s.zeitpunkt, ''DD.MM.YYYY HH24:MI:SS'') AS card_subtitle,'),
'    tsj.bezeichnung AS card_text, ',
'    -- APEX_PAGE.GET_URL(',
'    --     p_page   => 460,',
'    --     p_items  => ''P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION,P460_POSTPROZESS_ID'',',
'    --     p_values => s.sucheid || '','' || s.meilenstein || '','' || :P482_POSTPROZESS_ID',
'    -- ) AS card_link,',
'    APEX_PAGE.GET_URL(',
'    p_page   => 460,',
'    p_items  => ''P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION,P460_POSTPROZESS_ID,P460_SORT_ORDER'',',
'    p_values => s.sucheid || '','' || s.meilenstein || '','' || :P482_POSTPROZESS_ID || '','' || :P482_SORT_ORDER',
') AS card_link,',
'    ''fa fa-search'' AS card_icon,',
'    ''u-color-1'' AS card_color,',
'    ''M'' || s.meilenstein AS card_initials,',
'    s.postprozess_ref_sucheid AS primary_key_col',
'FROM',
'    T_POSTPROZESS_REF_SUCHE s',
'JOIN',
'    T_SUCHE_JSON tsj ON s.sucheid = tsj.sucheid ',
'WHERE',
'    s.POSTPROZESSID = :P482_POSTPROZESS_ID',
'ORDER BY',
'    CASE WHEN :P482_SORT_ORDER = ''DESC'' THEN s.zeitpunkt END DESC,',
'    CASE WHEN :P482_SORT_ORDER = ''ASC''  THEN s.zeitpunkt END ASC'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P482_SORT_ORDER,P482_POSTPROZESS_ID'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P482_POSTPROZESS_ID'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ''Search '' || s.sucheid AS card_title,',
'    ''Milestone '' || s.meilenstein AS card_subtitle,',
'    APEX_PAGE.GET_URL(',
'        p_page   => 460,',
'        p_items  => ''P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION'',',
'        p_values => s.sucheid || '','' || s.meilenstein',
'    ) AS card_link,',
'    ',
'    s.postprozess_ref_sucheid AS primary_key_col',
'FROM T_POSTPROZESS_REF_SUCHE s',
'WHERE s.POSTPROZESSID = :P480_POSTPROZESS_ID',
'ORDER BY',
'    CASE WHEN :P480_SORT_ORDER = ''DESC'' THEN s.zeitpunkt END DESC,',
'    CASE WHEN :P480_SORT_ORDER = ''ASC''  THEN s.zeitpunkt END ASC'))
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(964456951856524714)
,p_region_id=>wwv_flow_imp.id(2317348688445245195)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CARD_TITLE'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'CARD_SUBTITLE'
,p_body_adv_formatting=>false
,p_body_column_name=>'CARD_TEXT'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'CARD_ICON'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_media_css_classes=>'&CARD_COLOR.'
,p_pk1_column_name=>'PRIMARY_KEY_COL'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(964456512586524708)
,p_card_id=>wwv_flow_imp.id(964456951856524714)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'&CARD_LINK.'
,p_link_attributes=>'target="_blank"'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(952963566465997330)
,p_card_id=>wwv_flow_imp.id(964456951856524714)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>20
,p_label=>unistr('L\00F6schen')
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>unistr('javascript:apex.message.confirm(''Sind Sie sicher, dass Sie diese Suche aus dem Nachbearbeitungsprozess entfernen m\00F6chten?'',function(okPressed){if(okPressed){apex.page.submit({request:''DELETE_CARD'',set:{''P482_CARD_TO_DELETE'':''&PRIMARY_KEY_COL.''}});}})')
||';'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-trash-o'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3092385419848381489)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2317348600060245194)
,p_button_name=>'BTN_DELETE_POSTPROCESS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('Post-process l\00F6schen')
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P482_POSTPROZESS_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-trash-o'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964455904622524701)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2317348688445245195)
,p_button_name=>'BTN_ADD_SEARCH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Suche hinzuf\00FCgen')
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964454103896524674)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2317348600060245194)
,p_button_name=>'BTN_CREATE_POSTPROCESS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Erstellen'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3092385139898381486)
,p_name=>'P482_CARD_TO_DELETE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2317348688445245195)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964455491040524686)
,p_name=>'P482_SEARCH_TO_ADD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2317348688445245195)
,p_prompt=>unistr('Suche/Meilenstein zu dieser Post-process hinzuf\00FCgen')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH pri_user_check AS (',
'    SELECT 1 AS is_pri_user',
'    FROM t_benutzer_ref_rolle',
'    WHERE benutzerid = :G_BENUTZERID',
'      AND rolleid = 1001',
'      AND ROWNUM = 1',
')',
'SELECT',
'    s.bezeichnung || '' (Suche ID: '' || s.sucheid || '') - Meilenstein '' || s.meilenstein || ',
'    '' (KPB: '' || s.kpb_nummer || '') - Benutzer: '' || b.nachname || '', '' || b.vorname AS d,',
'    s.sucheid || '':'' || s.meilenstein AS r',
'FROM V_SUCHE_JSON_SPLIT s',
'JOIN t_benutzer b ON s.benutzerid = b.benutzerid',
'WHERE s.manuelle_speicherung > 0',
'    AND (',
'        (SELECT NVL(is_pri_user, 0) FROM pri_user_check) = 1',
'        OR s.benutzerid = :G_BENUTZERID',
'    )',
'ORDER BY s.zeitpunkt DESC'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Ausw\00E4hlen --')
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:margin-top-none:margin-bottom-lg'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964455105588524682)
,p_name=>'P482_SORT_ORDER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2317348688445245195)
,p_item_default=>'ASC'
,p_prompt=>'Sortieren nach'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:absteigend;DESC,aufsteigend  ;ASC'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964453710039524674)
,p_name=>'P482_POSTPROZESS_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2317348600060245194)
,p_prompt=>unistr('Bestehende Post-process / KPB ausw\00E4hlen')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT BENNENUNG as d, POSTPROZESSID as r',
'FROM T_POSTPROZESS',
'ORDER BY BENNENUNG'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Ausw\00E4hlen --')
,p_cHeight=>1
,p_colspan=>3
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964453228923524674)
,p_name=>'P482_NEW_POSTPROCESS_NAME'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2317348600060245194)
,p_prompt=>'Neue Post-process / KPB-Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_grid_column=>9
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964451833059524643)
,p_name=>'Post-process Changed - Refresh the Cards Region'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P482_POSTPROZESS_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964451377255524637)
,p_event_id=>wwv_flow_imp.id(964451833059524643)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964450977192524636)
,p_name=>'Sort Order Changed - Refresh the Cards Region'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P482_SORT_ORDER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964450489168524635)
,p_event_id=>wwv_flow_imp.id(964450977192524636)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(952963467089997329)
,p_name=>'Confirm Delete Post-process'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(3092385419848381489)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(952963374120997328)
,p_event_id=>wwv_flow_imp.id(952963467089997329)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('M\00F6chten Sie diesen Nachbearbeitungsprozess wirklich l\00F6schen? Alle verkn\00FCpften Suchanfragen werden entfernt.')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(952963193675997326)
,p_event_id=>wwv_flow_imp.id(952963467089997329)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P482_POSTPROZESS_ID IS NOT NULL THEN',
'        -- Delete all related searches first',
'        DELETE FROM T_POSTPROZESS_REF_SUCHE',
'        WHERE POSTPROZESSID = :P482_POSTPROZESS_ID;',
'        ',
'        -- Delete the post-process',
'        DELETE FROM T_POSTPROZESS',
'        WHERE POSTPROZESSID = :P482_POSTPROZESS_ID;',
'        ',
'        -- Clear the selection',
'        :P482_POSTPROZESS_ID := NULL;',
'        ',
'        -- Show success message',
'        apex_application.g_print_success_message := ''Post-process deleted successfully.'';',
'    END IF;',
'END;'))
,p_attribute_02=>'P482_POSTPROZESS_ID'
,p_attribute_03=>'P482_POSTPROZESS_ID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(952963017122997325)
,p_event_id=>wwv_flow_imp.id(952963467089997329)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess("Post-process deleted successfully.");'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(952963307167997327)
,p_event_id=>wwv_flow_imp.id(952963467089997329)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964452635824524647)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create New Post-process'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P482_NEW_POSTPROCESS_NAME IS NOT NULL THEN',
'        INSERT INTO T_POSTPROZESS (BENNENUNG)',
'        VALUES (:P482_NEW_POSTPROCESS_NAME);',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(964454103896524674)
,p_internal_uid=>2707759680074863588
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964452260597524646)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add Search to Post-process'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_sucheid     NUMBER;',
'    l_meilenstein NUMBER;',
'BEGIN',
'    IF :P482_SEARCH_TO_ADD IS NOT NULL AND :P482_POSTPROZESS_ID IS NOT NULL THEN',
'        l_sucheid     := TO_NUMBER(SUBSTR(:P482_SEARCH_TO_ADD, 1, INSTR(:P482_SEARCH_TO_ADD, '':'') - 1));',
'        l_meilenstein := TO_NUMBER(SUBSTR(:P482_SEARCH_TO_ADD, INSTR(:P482_SEARCH_TO_ADD, '':'') + 1));',
'',
'        MERGE INTO T_POSTPROZESS_REF_SUCHE t',
'        USING (',
'            SELECT :P482_POSTPROZESS_ID AS postprozessid,',
'                   l_sucheid AS sucheid,',
'                   l_meilenstein AS meilenstein',
'            FROM dual',
'        ) s ON (t.postprozessid = s.postprozessid AND t.sucheid = s.sucheid AND t.meilenstein = s.meilenstein)',
'        WHEN NOT MATCHED THEN',
'            INSERT (postprozessid, sucheid, meilenstein)',
'            VALUES (s.postprozessid, s.sucheid, s.meilenstein);',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(964455904622524701)
,p_internal_uid=>2707760055301863589
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3092385357120381488)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete Post-process'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'       IF :P482_POSTPROZESS_ID IS NOT NULL THEN',
'           -- Delete all related searches first',
'           DELETE FROM T_POSTPROZESS_REF_SUCHE',
'           WHERE POSTPROZESSID = :P482_POSTPROZESS_ID;',
'           ',
'           -- Delete the post-process',
'           DELETE FROM T_POSTPROZESS',
'           WHERE POSTPROZESSID = :P482_POSTPROZESS_ID;',
'           ',
'           -- Clear the selection',
'           :P482_POSTPROZESS_ID := NULL;',
'       END IF;',
'   END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(3092385419848381489)
,p_process_success_message=>'Post-process deleted successfully.'
,p_internal_uid=>579826958779006747
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3092385257950381487)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete Search from Post-process'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'       IF :P482_CARD_TO_DELETE IS NOT NULL THEN',
'           DELETE FROM T_POSTPROZESS_REF_SUCHE',
'           WHERE POSTPROZESS_REF_SUCHEID = :P482_CARD_TO_DELETE;',
'           ',
'           -- Clear the hidden item',
'           :P482_CARD_TO_DELETE := NULL;',
'       END IF;',
'   END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DELETE_CARD'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'Suche erfolgreich aus dem Nachbearbeitungsprozess entfernt.'
,p_internal_uid=>579827057949006748
);
wwv_flow_imp.component_end;
end;
/
