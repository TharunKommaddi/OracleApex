prompt --application/pages/page_00235
begin
--   Manifest
--     PAGE: 00235
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>235
,p_name=>'SubCountry bearbeiten/ hinzufuegen'
,p_alias=>'SUBCOUNTRY-FORM'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Subland bearbeiten/ hinzuf\00FCgen')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'600'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(658696015781828027)
,p_plug_name=>'Land Mapping Details'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_LAND_MAPPING_GETEX'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(658692847530828002)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(658692510482828002)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(658692847530828002)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(658691086848827999)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(658692847530828002)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0',
'false'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(658690718172827999)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(658692847530828002)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P235_LAND_MAPPING_GETEXID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(658690317795827999)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(658692847530828002)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P235_LAND_MAPPING_GETEXID is null and ',
'pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1097457076267393494)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(658692847530828002)
,p_button_name=>'REMOVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Mapping aufheben'
,p_button_position=>'NEXT'
,p_button_condition=>':P235_MAPPING_TEXT is not null and :P235_LANDID is not null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019019188399583122)
,p_name=>'P235_ZWINGE_TYP3'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(658696015781828027)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>'Zwinge Typ 3'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', '1',
  'unchecked_value', '0',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(669151379479068758)
,p_name=>'P235_LAND_MAPPING_GETEXID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(658696015781828027)
,p_item_source_plug_id=>wwv_flow_imp.id(658696015781828027)
,p_source=>'LAND_MAPPING_GETEXID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(669151278954068757)
,p_name=>'P235_MAPPING_TYP'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(658696015781828027)
,p_item_source_plug_id=>wwv_flow_imp.id(658696015781828027)
,p_source=>'MAPPING_TYP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(669151228339068756)
,p_name=>'P235_MAPPING_TEXT'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(658696015781828027)
,p_item_source_plug_id=>wwv_flow_imp.id(658696015781828027)
,p_prompt=>'Sub Land'
,p_source=>'MAPPING_TEXT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'  with cte_sub as ( select   ISOCODE3 || '' ''|| name as  land, name, ISOCODE3 isocode               -- 2,  isocode3 , null',
'    from T_X_GETEX_SUBCOUNTRY_MAP where ID is not null and type=''COUNTRY'' and',
'      isocode3 not in (select distinct iso_code_3 from T_Land where  iso_code_3 is not null)    --49',
'     ',
'    union',
unistr('     -- NAMEN Subl\00E4nder isocode3 for APEX'),
'    select  ISOCODE || '' ''|| name as land, name, ISOCODE               -- 2,  isocode3 , null',
'    from T_X_GETEX_SUBCOUNTRY_MAP where ID is not null and type=''SUB_COUNTRY'' ',
'     -- ISOCODE not in ( select mapping_text from T_LAND_MAPPING_GETEX  where landid is not null);',
' )',
' select land, isocode',
'  from cte_sub',
'    order by name     '))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('- w\00E4hle Land  -')
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(669151079642068755)
,p_name=>'P235_LANDID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(658696015781828027)
,p_item_source_plug_id=>wwv_flow_imp.id(658696015781828027)
,p_prompt=>'Ziel Land'
,p_source=>'LANDID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH cte1 AS (',
'    SELECT  iso_code_3|| '' '' || l.b_nummer || '' - '' || emano_util.fLang(l.land,l.land_eng) name,',
'    l.b_nummer,',
'        l.landid',
'    FROM ',
'        t_land l',
'    --WHERE         l.status_datenstand = 10',
')',
'select name, landid',
'from cte1',
'ORDER BY NLSSORT(cte1.B_NUMMER, ''NLS_SORT=BINARY_AI'') ASC '))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('- w\00E4hle Land  -')
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(644171490315575983)
,p_name=>'P235_BEMERKUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(658696015781828027)
,p_item_source_plug_id=>wwv_flow_imp.id(658696015781828027)
,p_prompt=>'Bemerkung'
,p_source=>'BEMERKUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>200
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(658640098307621099)
,p_validation_name=>'Validate'
,p_validation_sequence=>10
,p_validation=>'(:P235_MAPPING_TEXT is not null)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Sub Land muss gew\00E4hlt werden')
,p_validation_condition=>'SAVE, CREATE'
,p_validation_condition_type=>'REQUEST_IN_CONDITION'
,p_associated_item=>wwv_flow_imp.id(669151228339068756)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(658639592573621094)
,p_validation_name=>'oncreate -Mappin_Text doppelt'
,p_validation_sequence=>20
,p_validation=>'not exists (select MAPPING_TEXT from t_land_mapping_getex where MAPPING_TEXT = :P235_MAPPING_TEXT)'
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('MAPPING mit gew\00E4hltem Subland existiert bereits.')
,p_always_execute=>'Y'
,p_validation_condition=>'CREATE'
,p_validation_condition_type=>'REQUEST_IN_CONDITION'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1097456723016393491)
,p_validation_name=>'check_existing_mapping'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'not exists ( select * from T_Land_mapping_getex ',
'            where mapping_text = :P235_MAPPING_TEXT',
'             and LANDID is not null ',
'             and Land_mapping_getexid != :P235_LAND_MAPPING_GETEXID )'))
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Subland ist bereits auf eine Zielland gemappt'
,p_when_button_pressed=>wwv_flow_imp.id(658690718172827999)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(658692340443828002)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(658692510482828002)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(658691549217827999)
,p_event_id=>wwv_flow_imp.id(658692340443828002)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(669151025159068754)
,p_name=>'Set Typ'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P235_MAPPING_TEXT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(658640518054621103)
,p_event_id=>wwv_flow_imp.id(669151025159068754)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P235_MAPPING_TYP'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*    WITH imp_line AS ( select DATEN from T_X_GETEX_IMPORT ), cte1 as (',
'      SELECT ge.land_name , ge.l_typ,  ge.ISO_CODE3, ge.isocode5, ge.land_id',
'          FROM imp_line il, JSON_TABLE ( il.DATEN ,   ''$''',
'             COLUMNS( reg_id VARCHAR2(64)    PATH ''$.id'',',
'                   reg_num VARCHAR2(128)    PATH ''$.regulationNumber'',',
'                   reg_status  VARCHAR2(64)  PATH ''$.regulatoryStatus'', ',
'                    NESTED PATH ''$.jurisdictions[*]''  COLUMNS (',
'                       land_id    VARCHAR2(64)  PATH ''$.id''',
'                      , l_typ       VARCHAR2(32)  PATH ''$.type''',
'                      , land_name    VARCHAR2(250)  PATH ''$.name.de''',
'                      , land_name_en    VARCHAR2(250)  PATH ''$.name.en''',
'                      , originType varchar2(250) path ''$.originType''',
'                      , ISO_CODE3  VARCHAR2(16)  PATH ''$.isoCode3''',
'                      , isocode5 varchar2(20) path ''$.isoCode''',
'                      , NESTED PATH ''$.bNumbers[*]''  COLUMNS (',
'                             B_NUMBER  VARCHAR2(64)  PATH ''$''   )',
'                    )',
'            )',
'        ) ge ',
'    )',
'    ',
'    select distinct case when l_typ= ''SUB_COUNTRY''  then',
'      1 else 2 end as MAPPING_TYP ',
'    from cte1  --where iso_code3 is not null and isocode5 is not null',
'    where ( l_typ = ''SUB_COUNTRY''  -- and isocode5 like ''US%''',
'            or (iso_code3 is not null and iso_code3 not in (select l.iso_code_3 from t_land l where l.iso_code_3 is not null) )',
'    )',
'     and (isocode5= :P235_MAPPING_TEXT   OR iso_code3 = :P235_MAPPING_TEXT )',
'     */',
'  with cte_ic as ( select distinct mapping_text from ',
'                  T_Land_mapping_getex',
'  )',
'  select distinct case when lm.mapping_text in (''AE-DU'', ''AE-AZ'')    then 3',
'                        when length (lm.mapping_text)=3 then 2 ',
'                 ',
'                   else 1 end MAPPING_TYP   -- distinct case when l_typ=',
' from T_Land_mapping_getex lm',
' join cte_ic on (cte_ic.mapping_text =lm.mapping_text)',
' where (lm.mapping_text= :P235_MAPPING_TEXT ) '))
,p_attribute_07=>'P235_MAPPING_TEXT'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3170878980661169388)
,p_event_id=>wwv_flow_imp.id(669151025159068754)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P235_MAPPING_TEXT'
,p_attribute_03=>'P235_MAPPING_TYP'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1019019006091583120)
,p_name=>'change'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P235_ZWINGE_TYP3'
,p_condition_element=>'P235_ZWINGE_TYP3'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1019018851528583119)
,p_event_id=>wwv_flow_imp.id(1019019006091583120)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P235_MAPPING_TYP'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'3'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1097456977605393493)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Unmap'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update T_LAND_MAPPING_GETEX set Landid = null, bemerkung=''''',
'   where mapping_text = :P235_MAPPING_TEXT;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1097457076267393494)
,p_internal_uid=>2574755338293994742
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3170883366230169432)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(658696015781828027)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Land Mapping Details'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'N'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>501328949669218803
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1019019091320583121)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Erstelle Mapping'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (:P235_ZWINGE_TYP3 = 1) then',
'    insert into  T_LAND_MAPPING_GETEX (mapping_typ, landid, mapping_text)',
'    values(3, :P235_LANDID, :P235_MAPPING_TEXT);',
'elsif (length(:P235_MAPPING_TEXT) = 3) then',
'     insert into  T_LAND_MAPPING_GETEX (mapping_typ, landid, mapping_text)',
'      values(2, :P235_LANDID, :P235_MAPPING_TEXT);',
'elsif(length(:P235_MAPPING_TEXT) = 5) then',
'    insert into  T_LAND_MAPPING_GETEX (mapping_typ, landid, mapping_text)',
'     values(1, :P235_LANDID, :P235_MAPPING_TEXT);',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(658690317795827999)
,p_internal_uid=>2653193224578805114
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(658689089972827996)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE, REMOVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3013523225926560239
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(669151529553068759)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(658696015781828027)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form SubCountry bearbeiten/ hinzufuegen'
,p_process_when_type=>'NEVER'
,p_internal_uid=>3003060786346319476
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(658639908250621097)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  MAPPING_TYP, MAPPING_TEXT, LANDID, BEMERKUNG',
'INTO :P235_MAPPING_TYP, :P235_MAPPING_TEXT, :P235_LANDID, :P235_BEMERKUNG',
' from T_LAND_MAPPING_GETEX where LAND_MAPPING_GETEXID =:P235_LAND_MAPPING_GETEXID;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P235_LAND_MAPPING_GETEXID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>3013572407648767138
);
wwv_flow_imp.component_end;
end;
/
