prompt --application/pages/page_01000
begin
--   Manifest
--     PAGE: 01000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>1000
,p_name=>'Tableau-Tabelle'
,p_alias=>'TABLEAU-TABELLE'
,p_step_title=>'Tableau-Tabelle'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.apex-item-display-only, ',
'.t-Form-itemWrapper ',
'.t-Form-itemWrapper input {',
'    order: 3;',
'    color: red !important;',
'    width: 225px !important;',
'}',
'',
'#P1000_STATUS_BEZ_CONTAINER{ position: absolute; right: 20px;}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1055141178341317504)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1351546104543035418)
,p_plug_name=>'Tableau Tabelle : Letzte Aktualisierung - <b><u> &P1000_REFRESH_DATE_TIME.</u></b>'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select VORSCHRIFTNUMMER, VORSCHRIFTTITEL, VORSCHRIFTID, VORSCHRIFTTYP, VORSCHRIFTTYPENGLISH, ',
' LANDID, NEUE_TYPEN_CKD, NEUE_TYPEN_FBU, ALLE_FZG_CKD, ALLE_FZG_FBU, ERSTELLUNG_DATUM, AENDERUNGEN,',
' LAND, LAND_ENG, MFV_ID, MFV_TYP,  AK_KURZ, THEMA, VORSCHRIFT_FREIGABESTATUS, ',
unistr(' INHALTLICH_SACHLICH_GEPRUEFT, PERMALINK, LINK, EINSATZTERMIN, AU\00DFER_KRAFT_DATUM, AU\00DFER_KRAFT_DATUM_FBU, AU\00DFER_KRAFT_DATUM_CKD,'),
' IN_KRAFT , NEUE_TYPEN , ALLE_FZG',
' from MV_TABLEAU_BASE;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Tableau Tabelle : Letzte Aktualisierung - <b><u> &P1000_REFRESH_DATE_TIME.</u></b>'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Reprot Code in Comments',
'',
'-- SELECT VORSCHRIFTNUMMER, ',
'',
'--     CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN VORSCHRIFTTYP ELSE VORSCHRIFT_TYP_ENGLISH END AS VORSCHRIFTTYP, ',
'--     VORSCHRIFTID, LANDID, ',
'--     CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN LAND ELSE LAND_ENG END AS land, ',
'--     IN_KRAFT, NEUE_TYPEN, NEUE_TYPEN_CKD, NEUE_TYPEN_FBU, ALLE_FZG, ALLE_FZG_CKD, ALLE_FZG_FBU, ERSTELLUNG_DATUM, ',
'--     AENDERUNGEN, MFV_ID, MFV_TYP, AK_KURZ FROM V_TABLEAU_BASE;'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1351546150571035418)
,p_name=>'Tableau-Tabelle'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>2464239087666169822
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(984998765525198588)
,p_db_column_name=>'VORSCHRIFTNUMMER'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Vorschriftnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(984997937250198587)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>21
,p_column_identifier=>'C'
,p_column_label=>'Vorschriftid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(984997629694198587)
,p_db_column_name=>'VORSCHRIFTTYP'
,p_display_order=>31
,p_column_identifier=>'D'
,p_column_label=>'Vorschrifttyp'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXISTS'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual',
'where :FSP_LANGUAGE_PREFERENCE = ''de'''))
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(984997180897198587)
,p_db_column_name=>'LANDID'
,p_display_order=>41
,p_column_identifier=>'E'
,p_column_label=>'Landid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(984996025276198586)
,p_db_column_name=>'NEUE_TYPEN_CKD'
,p_display_order=>51
,p_column_identifier=>'H'
,p_column_label=>'Neue Typen Ckd'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(984995559018198586)
,p_db_column_name=>'NEUE_TYPEN_FBU'
,p_display_order=>61
,p_column_identifier=>'I'
,p_column_label=>'Neue Typen Fbu'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(984994787566198585)
,p_db_column_name=>'ALLE_FZG_CKD'
,p_display_order=>71
,p_column_identifier=>'K'
,p_column_label=>'Alle Fzg Ckd'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(984994371753198585)
,p_db_column_name=>'ALLE_FZG_FBU'
,p_display_order=>81
,p_column_identifier=>'L'
,p_column_label=>'Alle Fzg Fbu'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(984993989568198585)
,p_db_column_name=>'ERSTELLUNG_DATUM'
,p_display_order=>91
,p_column_identifier=>'M'
,p_column_label=>'Erstellung Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(984993554134198585)
,p_db_column_name=>'AENDERUNGEN'
,p_display_order=>101
,p_column_identifier=>'N'
,p_column_label=>'Aenderungen'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(984993192047198584)
,p_db_column_name=>'LAND'
,p_display_order=>111
,p_column_identifier=>'O'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXISTS'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual',
'where :FSP_LANGUAGE_PREFERENCE = ''de'''))
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(984992824655198584)
,p_db_column_name=>'MFV_ID'
,p_display_order=>121
,p_column_identifier=>'P'
,p_column_label=>'Mfv Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(984992384697198584)
,p_db_column_name=>'MFV_TYP'
,p_display_order=>131
,p_column_identifier=>'Q'
,p_column_label=>'Mfv Typ'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(953283980907841398)
,p_db_column_name=>'AK_KURZ'
,p_display_order=>141
,p_column_identifier=>'R'
,p_column_label=>'Ak Kurz'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949209134236439886)
,p_db_column_name=>'VORSCHRIFTTITEL'
,p_display_order=>151
,p_column_identifier=>'S'
,p_column_label=>'Vorschrifttitel'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949208907019439884)
,p_db_column_name=>'LAND_ENG'
,p_display_order=>161
,p_column_identifier=>'U'
,p_column_label=>'Land Deutsch'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXISTS'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual',
'where :FSP_LANGUAGE_PREFERENCE = ''en'''))
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(741542321558369703)
,p_db_column_name=>'VORSCHRIFTTYPENGLISH'
,p_display_order=>171
,p_column_identifier=>'V'
,p_column_label=>'Vorschrifttypenglish'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(741542229374369702)
,p_db_column_name=>'THEMA'
,p_display_order=>181
,p_column_identifier=>'W'
,p_column_label=>'Thema'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(741542070723369701)
,p_db_column_name=>'VORSCHRIFT_FREIGABESTATUS'
,p_display_order=>191
,p_column_identifier=>'X'
,p_column_label=>'Vorschrift Freigabestatus'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1434772458284790111)
,p_db_column_name=>'INHALTLICH_SACHLICH_GEPRUEFT'
,p_display_order=>201
,p_column_identifier=>'Y'
,p_column_label=>'Inhaltlich Sachlich Geprueft'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1434772473411790112)
,p_db_column_name=>'PERMALINK'
,p_display_order=>211
,p_column_identifier=>'Z'
,p_column_label=>'Permalink'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1434772616212790113)
,p_db_column_name=>'LINK'
,p_display_order=>221
,p_column_identifier=>'AA'
,p_column_label=>'Link'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1434772710443790114)
,p_db_column_name=>'EINSATZTERMIN'
,p_display_order=>231
,p_column_identifier=>'AB'
,p_column_label=>'Einsatztermin'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3095365086330678227)
,p_db_column_name=>unistr('AU\00DFER_KRAFT_DATUM')
,p_display_order=>241
,p_column_identifier=>'AV'
,p_column_label=>unistr('Au\00DFer Kraft Datum')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3095364989690678226)
,p_db_column_name=>unistr('AU\00DFER_KRAFT_DATUM_FBU')
,p_display_order=>251
,p_column_identifier=>'AW'
,p_column_label=>unistr('Au\00DFer Kraft Datum Fbu')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3095364830308678225)
,p_db_column_name=>unistr('AU\00DFER_KRAFT_DATUM_CKD')
,p_display_order=>261
,p_column_identifier=>'AX'
,p_column_label=>unistr('Au\00DFer Kraft Datum Ckd')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3095364745854678224)
,p_db_column_name=>'IN_KRAFT'
,p_display_order=>271
,p_column_identifier=>'AY'
,p_column_label=>'In Kraft'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3095364711143678223)
,p_db_column_name=>'NEUE_TYPEN'
,p_display_order=>281
,p_column_identifier=>'AZ'
,p_column_label=>'Neue Typen'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3095364457669678221)
,p_db_column_name=>'ALLE_FZG'
,p_display_order=>291
,p_column_identifier=>'BA'
,p_column_label=>'Alle Fzg'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1351595311752078668)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'22089199'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'VORSCHRIFTNUMMER:VORSCHRIFTID:VORSCHRIFTTITEL:VORSCHRIFTTYP:LANDID:NEUE_TYPEN_CKD:NEUE_TYPEN_FBU:ALLE_FZG_CKD:ALLE_FZG_FBU:ERSTELLUNG_DATUM:AENDERUNGEN:LAND:MFV_ID:MFV_TYP:AK_KURZ:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1052443745991228330)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1351546104543035418)
,p_button_name=>'Refresh'
,p_button_static_id=>'refresh'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Auffrischen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1052443266386211275)
,p_name=>'P1000_REFRESH_DATE_TIME'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1351546104543035418)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'  TO_CHAR(LAST_REFRESH_DATE, ''DD.MM.YYYY HH24:MI'') AS REFRESH_DATE_TIME ',
'FROM USER_MVIEWS',
'WHERE MVIEW_NAME = ''MV_TABLEAU_BASE'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1052442139645166653)
,p_name=>'P1000_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1351546104543035418)
,p_item_default=>':G_BENUTZERID'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1052441869298164517)
,p_name=>'P1000_STATUS_BEZ'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1351546104543035418)
,p_use_cache_before_default=>'NO'
,p_prompt=>'&nbsp;'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1052441528423162240)
,p_name=>'P1000_HIDDEN_REFRESH_ITEM'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1351546104543035418)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1052441392487159526)
,p_name=>'NEW VERSION'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1000_HIDDEN_REFRESH_ITEM'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1052440990656159512)
,p_event_id=>wwv_flow_imp.id(1052441392487159526)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_count number;',
'l_value varchar2(100);',
'begin',
'begin',
'SELECT count(*) into l_count',
'FROM USER_MVIEWS',
'WHERE MVIEW_NAME = ''MV_TABLEAU_BASE''',
'--and LAST_REFRESH_DATE> :P2020_REFRESH_DATE_TIME;',
'and TO_char(LAST_REFRESH_DATE, ''DD.MM.YYYY HH24:MI'') >:P2020_REFRESH_DATE_TIME;',
'exception when no_data_found then l_count :=0;',
'end;',
'if l_count >0 then ',
unistr('l_value:=''Neue Version Verf\00FCgbar!'';'),
'',
'else',
'l_value :=null;',
'end if;',
':P2020_STATUS_BEZ := l_value;',
'--:P2020_STATUS_BEZ :=null;',
'--end if;',
'end;'))
,p_attribute_02=>'P1000_REFRESH_DATE_TIME'
,p_attribute_03=>'P1000_STATUS_BEZ'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1055140973639317502)
,p_name=>'change refresh item'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1055140837327317501)
,p_event_id=>wwv_flow_imp.id(1055140973639317502)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'setInterval( ()=> { $s(''P1000_HIDDEN_REFRESH_ITEM'', ''refresh'') }, 4000 );',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1055140743766317500)
,p_name=>'change item position'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1055140697859317499)
,p_event_id=>wwv_flow_imp.id(1055140743766317500)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#ir_region_toolbar'').append($(''#P1000_STATUS_BEZ_CONTAINER'')); // to set position',
'$(''#P1000_STATUS_BEZ_LABEL'').css(''display'', ''block''); // make item label as block',
'$(''#P1000_STATUS_BEZ_LABEL'').css(''white-space'', ''nowrap''); // disable wrapping'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1052444151767229356)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Refresh_Materialized_View'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'DBMS_SCHEDULER.RUN_JOB(''J_REFRESH_MV_FREE_VKO_REPORT_AND_MV_VORSCHRIFTEN_LANG_VERSION_REPORT'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2619768164132158879
);
wwv_flow_imp.component_end;
end;
/
