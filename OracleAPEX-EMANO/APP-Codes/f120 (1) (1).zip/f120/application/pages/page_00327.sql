prompt --application/pages/page_00327
begin
--   Manifest
--     PAGE: 00327
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>327
,p_name=>unistr('Suche speichern / \00FCbergeben')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Suche speichern / \00FCbergeben')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1664218434411807376)
,p_plug_name=>'Alert'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--danger:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'htp.p(''',
unistr('Zum Speichern und Laden von Suchparametern ist eine Registrierung als Benutzer notwendig. Sie konnten jedoch nicht im LDAP gefunden werden, sodass dies nicht m\00F6glich ist.<br /><r />'),
'Ihre GID: '' || OWA_UTIL.GET_CGI_ENV(''HTTP_GID'') || ''<br /><br />Bitte wenden Sie sich an einen Administrator.'');'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'pck_ri.fUserIsCreatable() = 20'
,p_plug_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2663661675186177930)
,p_plug_name=>'Suche speichern'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'pck_ri.fUserIsCreatable() = 10'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1458191625268012541)
,p_plug_name=>'Warning'
,p_parent_plug_id=>wwv_flow_imp.id(2663661675186177930)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('Die Suchparameter enthalten den Modus "bestehender Typ" und d\00FCrfen nicht an Benutzer ohne Rolle oder deaktivierte Benutzer \00FCbergeben werden.')
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P327_MODUS = 1 and :P327_REASSIGN_USER is not null'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2663662305067177931)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2666336599284772652)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(2663661675186177930)
,p_button_name=>'SEARCH_USER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Benutzer suchen'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:65:&SESSION.::&DEBUG.:RP,65:P65_CAMEFROM:327'
,p_button_condition=>'P327_REASSIGN_USER'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2663662718915177932)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2663662305067177931)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2663662207662177931)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2663662305067177931)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2663662081561177931)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2663662305067177931)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2663661986210177931)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2663662305067177931)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Speichern / \00DCbergeben')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'pck_ri.fUserIsCreatable() = 10'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1458191555557012540)
,p_name=>'P327_MODUS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2663661675186177930)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from table(apex_string.split_numbers(:P327_SUCHE_TEMPIDS,'':'')) x',
'join t_suche_temp st on (x.column_value = st.suche_tempid)',
'where st.suchdaten.suchtyp = 10'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663309656808664060)
,p_name=>'P327_SUCHE_TEMPIDS'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(2663661675186177930)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663311676505664081)
,p_name=>'P327_REASSIGN_USER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2663661675186177930)
,p_use_cache_before_default=>'NO'
,p_source=>'REASSIGN_USER'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663665165728177938)
,p_name=>'P327_ROWID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2663661675186177930)
,p_use_cache_before_default=>'NO'
,p_source=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663665472403177955)
,p_name=>'P327_SUCHEID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2663661675186177930)
,p_use_cache_before_default=>'NO'
,p_source=>'SUCHEID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P327_SUCHEID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663665935439177960)
,p_name=>'P327_BEZEICHNUNG'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2663661675186177930)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Bezeichnung KPB'
,p_placeholder=>'Fahrzeugbezeichnung'
,p_source=>'BEZEICHNUNG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663666289459177961)
,p_name=>'P327_BESCHREIBUNG'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2663661675186177930)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Beschreibung'
,p_source=>'BESCHREIBUNG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>250
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663666686690177962)
,p_name=>'P327_BENUTZERID'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(2663661675186177930)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P327_REASSIGN_USER'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2663667103364177963)
,p_name=>'P327_ZEITPUNKT'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(2663661675186177930)
,p_use_cache_before_default=>'NO'
,p_source=>'ZEITPUNKT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2666337117437772657)
,p_name=>'P327_GID'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(2663661675186177930)
,p_use_cache_before_default=>'NO'
,p_source=>'GID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2666337542650772661)
,p_name=>'P327_D_BENUTZER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(2663661675186177930)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Benutzer'
,p_source=>'D_BENUTZER'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P327_REASSIGN_USER'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:margin-left-sm'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1458191851170012543)
,p_validation_name=>unistr('Benutzer gew\00E4hlt?')
,p_validation_sequence=>10
,p_validation=>'P327_BENUTZERID'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Bitte w\00E4hlen Sie einen Benutzer aus!')
,p_validation_condition=>':P327_REASSIGN_USER is not null'
,p_validation_condition2=>'SQL'
,p_validation_condition_type=>'EXPRESSION'
,p_associated_item=>wwv_flow_imp.id(2663666686690177962)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1458191815742012542)
,p_validation_name=>'Passender User?'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (pck_ri.fIsLimitedUser(:P327_BENUTZERID) = 1) then',
'    return false;',
'else',
'    return true;',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('Bitte w\00E4hlen Sie einen Benutzer mit der Rolle VKO, VEX oder ZVEX aus!')
,p_validation_condition=>':P327_REASSIGN_USER is not null and :P327_MODUS = 1 and :P327_BENUTZERID is not null'
,p_validation_condition2=>'SQL'
,p_validation_condition_type=>'EXPRESSION'
,p_associated_item=>wwv_flow_imp.id(2666337542650772661)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2663662800349177932)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2663662718915177932)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2663663619650177935)
,p_event_id=>wwv_flow_imp.id(2663662800349177932)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2666337205652772658)
,p_name=>unistr('GID zur\00FCckgeben')
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2666336599284772652)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2666337278928772659)
,p_event_id=>wwv_flow_imp.id(2666337205652772658)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P327_GID'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P65_GID_CHOSEN'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2666337607695772662)
,p_event_id=>wwv_flow_imp.id(2666337205652772658)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lBenutzerID number;',
'begin',
'    lBenutzerID := pck_ri.fCreatePlaceholderUser(:P327_GID);',
'    ',
'    :P327_BENUTZERID := lBenutzerID;    ',
'',
'    select b.nachname || '', '' || b.vorname || nvl2(b.abteilung, '' ('' || b.abteilung || '')'', '''')',
'    into :P327_D_BENUTZER',
'    from t_benutzer b',
'    where b.benutzerid = lBenutzerID;',
'end;    ',
'    ',
''))
,p_attribute_02=>'P327_GID'
,p_attribute_03=>'P327_BENUTZERID,P327_D_BENUTZER'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2663669396324177966)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_SUCHE'
,p_attribute_02=>'T_SUCHE'
,p_attribute_03=>'P327_ROWID'
,p_attribute_04=>'ROWID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6335881712223566201
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2663669776905177966)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process Row of T_SUCHE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (:P327_BENUTZERID is not null) then',
'    :P327_SUCHEID := PCK_RI_SUCHE.fSaveSuche(:P327_BEZEICHNUNG, :P327_BESCHREIBUNG, :P327_SUCHE_TEMPIDS, :P327_BENUTZERID);',
'else ',
'    :P327_SUCHEID := PCK_RI_SUCHE.fSaveSuche(:P327_BEZEICHNUNG, :P327_BESCHREIBUNG, :P327_SUCHE_TEMPIDS);',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Die Suchparameter konnten nicht gespeichert werden.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>6335882092804566201
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2663670250990177966)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2663662207662177931)
,p_internal_uid=>6335882566889566201
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2663670574332177966)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_01=>'P327_SUCHEID'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>6335882890231566201
);
wwv_flow_imp.component_end;
end;
/
