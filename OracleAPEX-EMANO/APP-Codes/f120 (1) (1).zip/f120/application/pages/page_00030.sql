prompt --application/pages/page_00030
begin
--   Manifest
--     PAGE: 00030
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>30
,p_name=>'Themen'
,p_step_title=>'Themen'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_comment=>'a'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1068904560667951387)
,p_plug_name=>'Neue Themen aus GETEX,  noch nicht gepflegt  '
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct ge.Thema_id, ''1'' as Link, ge.regindex_themaid, ge.thema_name --, thema_name_en',
'     from MV_GETEX_VORSCHRIFT_THEMA ge',
'     where ge.Thema_id not in (select distinct getex_thema_key from t_thema)',
'     or (select STATUS_PFLEGE from t_thema where getex_thema_key = ge.Thema_id ) = 1',
'-- for test',
' --union',
'  --select ''64e5e4391761e553de8b3600'', ''1'' as Link, 10000, ''Test_thema''',
'  -- from dual;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Neue Themen aus GETEX,  noch nicht gepflegt  '
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1068904434222951386)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>2603307881676436849
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1068904365519951385)
,p_db_column_name=>'THEMA_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Thema Id'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1057096704981192933)
,p_db_column_name=>'REGINDEX_THEMAID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Regindex Themaid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1057096548904192932)
,p_db_column_name=>'THEMA_NAME'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Thema Name'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1057096763203192934)
,p_db_column_name=>'LINK'
,p_display_order=>50
,p_column_identifier=>'B'
,p_column_label=>'Link'
,p_column_link=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.::P33_THEMA_ID:#THEMA_ID#'
,p_column_linktext=>'<span class="fa fa-pencil" aria-hidden="true"></span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1057089796448175883)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'26151226'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LINK:THEMA_ID:THEMA_NAME:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2641725015002572817)
,p_plug_name=>'Themen <span onclick="redirect(10)" class="fa fa-question-square-o"></span>'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT thema_id "THEMAID", thema_number "NUMMER",  thema_BEZEICHNUNG, thema_NAME_ENG , lrsa, ',
'        case when :FSP_LANGUAGE_PREFERENCE=''de'' then PARENT_BEZEICHNUNG else  PARENT_NAME_ENG END as "PARENT_BEZEICHNUNG",',
'        case when :FSP_LANGUAGE_PREFERENCE=''de'' then ANTRIEBSART_VORSCHRIFT_DE  else ANTRIEBSART_VORSCHRIFT_ENG END as "ANTRIEBSART_VORSCHRIFT",  --thema_gueltig',
'        thema_betroffenheit as betroffenheit,',
'        konzern_cluster, ',
'        case when :FSP_LANGUAGE_PREFERENCE=''de'' then et_bak else et_bak_eng end  as et_bak, ',
'        ET_B_AK_KURZ, LEAD_SYVA, LETZTE_AENDERUNG_DATUM, ',
'        benutzer as Letzte_aenderung_benutzer, ',
'        homologationseigenschaften, funktionsliste, MIRG_ZUORDNUNG, ',
'        GUELTIGKEIT_ENDEDATUM, GUELTIGKEIT_STARTDATUM,',
'        SYSTEMTEAM_ZUORDNUNG,',
'        DESCRIPTION_SOC_DE, DESCRIPTION_SOC_EN,',
'        CASE  WHEN BETA_FLAG = 0 THEN ''Nein'' WHEN BETA_FLAG = 10 THEN ''Ja'' END AS BETA_FLAG, ',
'        FAHRZEUGKLASSE',
'    ',
' FROM MV_THEMA_REPORT',
' where (nvl(:P30_STATUS_GUELTIG,0) =1 and nvl(thema_gueltig, 0) = 1 ) or nvl(:P30_STATUS_GUELTIG,0) = 0',
' order by regexp_replace(regexp_replace( thema_number, ''([0-9]+)'', ''0000\1''),',
'                        ''0+([0-9]{4})'', ''\1''), thema_number'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P30_STATUS_GUELTIG'
,p_prn_content_disposition=>'ATTACHMENT'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2641725464013572817)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_oracle_text_index_column=>'THEMA_NAME_ENG'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:35:P35_THEMAID:#THEMAID#'
,p_detail_link_text=>'<span class="fa fa-pencil" aria-hidden="true"></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_description=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(userId => PCK_RI.fGetUserId, ',
'                      pageId => :APP_PAGE_ID,',
'                      accessMode => 100))    -- 30 page      (plsql )'))
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>152378898055300581
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2648979288746203837)
,p_db_column_name=>'NUMMER'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Nummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781106133699218266)
,p_db_column_name=>'DESCRIPTION_SOC_DE'
,p_display_order=>41
,p_column_identifier=>'AB'
,p_column_label=>'Thema Bezeichnung SoC &shy;Deutsch'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(781105943397218265)
,p_db_column_name=>'DESCRIPTION_SOC_EN'
,p_display_order=>51
,p_column_identifier=>'AC'
,p_column_label=>'Thema Bezeichnung SoC &shy;Englisch'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1020015383247713032)
,p_db_column_name=>'LRSA'
,p_display_order=>61
,p_column_identifier=>'AH'
,p_column_label=>'LRSA'
,p_column_type=>'STRING'
,p_static_id=>'lrsa_cid'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2641731556530647538)
,p_db_column_name=>'PARENT_BEZEICHNUNG'
,p_display_order=>71
,p_column_identifier=>'I'
,p_column_label=>unistr('\00DCbergeordnetes Thema')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2641727085416572825)
,p_db_column_name=>'ANTRIEBSART_VORSCHRIFT'
,p_display_order=>81
,p_column_identifier=>'E'
,p_column_label=>'Antriebsart Vorschrift'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2641727526800572825)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>91
,p_column_identifier=>'F'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2658667125810531639)
,p_db_column_name=>'BETROFFENHEIT'
,p_display_order=>111
,p_column_identifier=>'N'
,p_column_label=>'<span class="tooltip" tooltipid=20>Betroffenheit</span>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2658667192794531640)
,p_db_column_name=>'KONZERN_CLUSTER'
,p_display_order=>121
,p_column_identifier=>'O'
,p_column_label=>'Konzern Cluster'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2658667356946531641)
,p_db_column_name=>'ET_BAK'
,p_display_order=>131
,p_column_identifier=>'P'
,p_column_label=>'Arbeitskreise'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2666177668636204547)
,p_db_column_name=>'LEAD_SYVA'
,p_display_order=>141
,p_column_identifier=>'Q'
,p_column_label=>'<span class="tooltip" tooltipid=21>Lead SYVA</span>'
,p_column_html_expression=>'<span style="display: block; width: 100%; height: 100%;" title="Pflege durch eine andere Abteilung">#LEAD_SYVA#&nbsp;</span>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2679650146723473138)
,p_db_column_name=>'ET_B_AK_KURZ'
,p_display_order=>151
,p_column_identifier=>'S'
,p_column_label=>'AK Kurzbezeichnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(895691884338829002)
,p_db_column_name=>'HOMOLOGATIONSEIGENSCHAFTEN'
,p_display_order=>161
,p_column_identifier=>'T'
,p_column_label=>'Homologationseigenschaften'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(772713018141225998)
,p_db_column_name=>'FUNKTIONSLISTE'
,p_display_order=>171
,p_column_identifier=>'U'
,p_column_label=>'Funktionen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(680053912058941177)
,p_db_column_name=>'MIRG_ZUORDNUNG'
,p_display_order=>181
,p_column_identifier=>'V'
,p_column_label=>'MIRG-Zuordnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(680053825334941176)
,p_db_column_name=>'SYSTEMTEAM_ZUORDNUNG'
,p_display_order=>191
,p_column_identifier=>'W'
,p_column_label=>'Systemteam-Zuordnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(687433840845921463)
,p_db_column_name=>'BETA_FLAG'
,p_display_order=>201
,p_column_identifier=>'AD'
,p_column_label=>'Beta Flag'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3141432557438707427)
,p_db_column_name=>'GUELTIGKEIT_ENDEDATUM'
,p_display_order=>211
,p_column_identifier=>'AE'
,p_column_label=>unistr('G\00FCltigkeit Endedatum')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3141432472290707426)
,p_db_column_name=>'GUELTIGKEIT_STARTDATUM'
,p_display_order=>221
,p_column_identifier=>'AF'
,p_column_label=>unistr('G\00FCltigkeit Startdatum')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1036435433626186196)
,p_db_column_name=>'FAHRZEUGKLASSE'
,p_display_order=>231
,p_column_identifier=>'AG'
,p_column_label=>'Fahrzeugart'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(988067839811880401)
,p_db_column_name=>'THEMAID'
,p_display_order=>271
,p_column_identifier=>'AO'
,p_column_label=>'Themaid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(988067782525880400)
,p_db_column_name=>'THEMA_BEZEICHNUNG'
,p_display_order=>281
,p_column_identifier=>'AP'
,p_column_label=>'Thema Bezeichnung Deutsch'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(988067693027880399)
,p_db_column_name=>'THEMA_NAME_ENG'
,p_display_order=>291
,p_column_identifier=>'AQ'
,p_column_label=>'Thema Bezeichnung  Englisch'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(988067535857880398)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>301
,p_column_identifier=>'AR'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2641737826825650950)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1523913'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMMER:THEMA_BEZEICHNUNG:THEMA_NAME_ENG:LRSA:DESCRIPTION_SOC_DE:DESCRIPTION_SOC_EN:PARENT_BEZEICHNUNG:ANTRIEBSART_VORSCHRIFT:BETROFFENHEIT:KONZERN_CLUSTER:ET_BAK:ET_B_AK_KURZ:HOMOLOGATIONSEIGENSCHAFTEN:FAHRZEUGKLASSE:FUNKTIONSLISTE:LEAD_SYVA:BETA_FLA'
||'G:MIRG_ZUORDNUNG:SYSTEMTEAM_ZUORDNUNG:LETZTE_AENDERUNG_DATUM:LETZTE_AENDERUNG_BENUTZER:GUELTIGKEIT_STARTDATUM:GUELTIGKEIT_ENDEDATUM:'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(972546584368462139)
,p_report_id=>wwv_flow_imp.id(2641737826825650950)
,p_name=>unistr('Zeilentext enth\00E4lt ''abgasemiss''')
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'abgasemiss'
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2641729168169572827)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2641725015002572817)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:35'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(userId => PCK_RI.fGetUserId, ',
'                      pageId => :APP_PAGE_ID,',
'                      accessMode => 300))'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3095362825678678205)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2641725015002572817)
,p_button_name=>'REFRESH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Refresh'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1068904934973951391)
,p_name=>'P30_STATUS_GUELTIG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2641725015002572817)
,p_item_default=>'1'
,p_display_as=>'NATIVE_YES_NO'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'alle',
  'off_value', '0',
  'on_label', unistr('nur g\00FCltige'),
  'on_value', '1',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2641728345829572826)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2641725015002572817)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2641728842307572827)
,p_event_id=>wwv_flow_imp.id(2641728345829572826)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2641725015002572817)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2641729593956572828)
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2641729168169572827)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2641730118135572828)
,p_event_id=>wwv_flow_imp.id(2641729593956572828)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2641725015002572817)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(530863783943178082)
,p_name=>'hide create button'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_security_scheme=>'!'||wwv_flow_imp.id(2660026449262803947)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(530863724639178081)
,p_event_id=>wwv_flow_imp.id(530863783943178082)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(2641729168169572827)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1068904877713951390)
,p_name=>'Change'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P30_STATUS_GUELTIG'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1068904769403951389)
,p_event_id=>wwv_flow_imp.id(1068904877713951390)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P30_STATUS_GUELTIG'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1068904698813951388)
,p_event_id=>wwv_flow_imp.id(1068904877713951390)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2641725015002572817)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1057095732680192924)
,p_name=>'Edit Row Report 1 - Dialog Closed'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1068904560667951387)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1057095661101192923)
,p_event_id=>wwv_flow_imp.id(1057095732680192924)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1068904560667951387)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1057095567009192922)
,p_event_id=>wwv_flow_imp.id(1057095732680192924)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2641725015002572817)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3095362794310678204)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Aktualisiere MView'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
' pck_ri.P_REFRESH_MV_THEMA_REPORT;',
'  --debug('' P30: MV_thema_REPORT aktualisiert'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(3095362825678678205)
,p_internal_uid=>576849521588710031
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3095362678810678203)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Aktualisiere Ora Text Suche Indexe'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    CTX_DDL.SYNC_INDEX(''MV_THEMA_EXTENDED_IDX'');',
'    CTX_DDL.SYNC_INDEX(''MV_THEMA_BEZEICHNUNG_IDX'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(3095362825678678205)
,p_internal_uid=>576849637088710032
);
wwv_flow_imp.component_end;
end;
/
