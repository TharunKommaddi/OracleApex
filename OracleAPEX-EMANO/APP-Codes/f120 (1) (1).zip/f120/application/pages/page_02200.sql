prompt --application/pages/page_02200
begin
--   Manifest
--     PAGE: 02200
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>2200
,p_name=>'2200 GETEX Upload'
,p_alias=>'2200-GETEX-UPLOAD'
,p_step_title=>'2200 GETEX Upload'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1156126651088198504)
,p_plug_name=>'GETEX Upload'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_X_GETEX_ZIP'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(589810312204584405)
,p_name=>'Files'
,p_parent_plug_id=>wwv_flow_imp.id(1156126651088198504)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select getex_zipid, dbms_lob.getlength(daten) dateigroesse, filename',
'from t_x_getex_zip'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(673054117944756290)
,p_query_column_id=>1
,p_column_alias=>'GETEX_ZIPID'
,p_column_display_sequence=>10
,p_column_heading=>'Getex Zipid'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(673053649949756288)
,p_query_column_id=>2
,p_column_alias=>'DATEIGROESSE'
,p_column_display_sequence=>20
,p_column_heading=>'Dateigroesse'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(673053299131756288)
,p_query_column_id=>3
,p_column_alias=>'FILENAME'
,p_column_display_sequence=>30
,p_column_heading=>'Filename'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(589810711379584409)
,p_plug_name=>'Skripts'
,p_parent_plug_id=>wwv_flow_imp.id(1156126651088198504)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>begin PCK_RI_GETEX_CTRL.pImportFromZip; end; -- ca. 8 Min.',
'begin PCK_RI_GETEX_CTRL.pSetAttributesForGetexImport; end; -- <1 Min.',
'begin PCK_RI_GETEX_CTRL.pRefreshMViews; end; -- <1 Min. ',
'',
'begin',
'for x in (select vorschriftid from t_vorschrift) loop',
'    PCK_RI_GETEX_COMPARE.pCompareVorschrift(x.vorschriftid);',
'end loop;',
'end;',
'    ',
'    </pre> '))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(673056755645756330)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(1156126651088198504)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(673056478777756313)
,p_name=>'P2200_GETEX_ZIPID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1156126651088198504)
,p_item_source_plug_id=>wwv_flow_imp.id(1156126651088198504)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Getex Zipid'
,p_source=>'GETEX_ZIPID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(673056115260756310)
,p_name=>'P2200_DATEN'
,p_source_data_type=>'BLOB'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1156126651088198504)
,p_item_source_plug_id=>wwv_flow_imp.id(1156126651088198504)
,p_prompt=>'Daten'
,p_source=>'DATEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>60
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_multiple_files', 'Y',
  'display_as', 'INLINE',
  'purge_file_at', 'REQUEST',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(673055710641756309)
,p_name=>'P2200_FILENAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1156126651088198504)
,p_item_source_plug_id=>wwv_flow_imp.id(1156126651088198504)
,p_source=>'FILENAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(673052615683756267)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process form GETEX Upload'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from t_x_getex_zip;',
'insert into t_x_getex_zip (daten, filename)',
'select blob_content, filename',
'from apex_application_temp_files;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2999159700215631968
);
wwv_flow_imp.component_end;
end;
/
