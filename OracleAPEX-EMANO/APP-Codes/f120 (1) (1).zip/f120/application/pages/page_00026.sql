prompt --application/pages/page_00026
begin
--   Manifest
--     PAGE: 00026
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>26
,p_name=>'Importierte Vorschriften'
,p_alias=>'IMPORTIERTE-VORSCHRIFTEN'
,p_step_title=>'Importierte Vorschriften'
,p_reload_on_submit=>'A'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('/* Erm\00F6glicht bei APEX-Checkbox-Items einen Quicklink um alle auszuw\00E4hlen */'),
'function fSelectAll(elem) {',
'',
'    var apexItem = $(elem).closest(''.t-Form-fieldContainer'');',
'    var itemValue = apexItem.find(''input'').map(function() {',
'        return this.value;',
'    }).get().join('':'');',
'    var itemName = apexItem.find(''label'').attr(''for'');',
'    $s(itemName,itemValue);',
'',
'}',
'',
'/* Click auf Checkbox in Tabellenheader: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'    $(''#VG_IG'').on(''click'', ''th input'', function() {',
'        var check_all = $("#VG_IG").find("th input:checked").is(":checked");',
'    ',
unistr('        // alle Zeilen ausw\00E4hlen/abw\00E4hlen'),
'        $("#VG_IG").find("td input").each(function() {',
'            this.checked = check_all;',
'        });',
'    ',
'        // Button aktivieren/deaktivieren',
'        if (check_all) {',
'            $("#b_MU").removeClass("apex_disabled");',
'        } else {',
'            $("#b_MU").addClass("apex_disabled");',
'        }',
'    ',
'        $("#b_MU").prop(''disabled'', !check_all);',
'        ',
unistr('        // alle ausgew\00E4hlten Zeilen-IDs in das Item P26_SELECTED_ROWS'),
'        var sel_rows = apex.item(''P26_SELECTED_ROWS'');',
'        sel_rows.setValue("");',
'        $("#VG_IG").find("td input:checked").each(function() {',
'          if(sel_rows.getValue().length > 0) {',
'            sel_rows.setValue(sel_rows.getValue() + ":");    ',
'          }',
'          sel_rows.setValue(sel_rows.getValue() + this.value);',
'        });',
'        apex.server.process(''MY_PROCESS'', {',
'            pageItems: ''#P26_SELECTED_ROWS''',
'        },{dataType: ''text''});',
'        //alert (sel_rows.getValue());',
'    });',
'',
'  '))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.link-preset {',
'    text-decoration: underline;',
'    text-decoration-style: dashed;',
'}',
'',
'#VG_IG .t-fht-tbody {max-height: calc(100vh - 260px)}',
'.t-Body-topButton {display: none !important}',
'.t-Body-content {padding-bottom: 3px !important}',
'.t-Body {margin-bottom: 3px !important}',
'.t-Body-contentInner {padding-bottom: 0px !important}',
'',
'#VG_IG_filter_type > .a-IRR-radioIconList-item:nth-child(3) {',
'    display: none;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4666347950230382883)
,p_plug_name=>'Neu importierte Vorschriften aus Getex 2 zur Weiterbearbeitung'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with etb_cte as (',
'    select listagg(etb,'', '') within group (order by etb) liste,  vorschriftid',
'    from (',
'        ',
'        select distinct ak.kurz etb, vtl.vorschriftid vorschriftid',
'        from t_vorschrift_ref_thema vtl',
'        join t_thema_ref_et_b_ak t on (vtl.themaid = t.themaid)',
'        join t_et_b_ak ak on (ak.et_b_akid = t.et_b_akid)',
'        where  vtl.geloescht = 0',
'    )',
'    group by vorschriftid',
') ',
' SELECT v.vorschriftID, v.vorschrift_nummer, v.DOKUMENTENDATUM, v.VORSCHRIFT_BEZEICHNUNG as VORSCHRIFT_BEZEICHNUNG,',
'               gk.Kommentar as Kommentar,',
'  v.Vorschrift_freigabeStatusid, v.VORSCHRIFT_STATUSID,',
'        v.Einsatzdatum_modellid,',
'       v.Vorschrift_typid, --CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN v.BEMERKUNG ELSE v.BEMERKUNG_ENGLISCH END BEMERKUNG, ',
'       v.LETZTE_AENDERUNG_DATUM ',
'       , nvl2(b.nachname, b.nachname||'',''|| b.vorname, ''system'') as letzter_benutzer, ',
'       etb_cte.liste as arbeitskreise,',
'       nvl2(lvko.nachname, lvko.nachname||'', ''|| lvko.vorname, null) as Lead_VKO,',
'       case when (v.status_update_getex is null) then ''-''',
'            when v.status_update_getex  =10 then ''aktuell'' ',
'            when v.status_update_getex  =20 then ''nicht aktuell'' ',
'            when v.status_update_getex  =30 then  ''nicht in Getex''  end  as status_update_getex',
'',
'    from T_Vorschrift v',
'    left outer join t_vorschrift_ref_vorschrift vrv on (v.vorschriftid = vrv.nachfolger_vorschriftid and beziehung_art = 30)    ',
'    left outer join t_vorschrift vp on (vrv.vorgaenger_vorschriftid = vp.vorschriftid and v.vorschrift_typid = 20) -- parent bei supplements',
'    left outer join T_BEnutzer b on (v.LETZTE_AENDERUNG_BENUTZERID = b.benutzerid)',
'    left outer join etb_cte on (etb_cte.vorschriftid = v.vorschriftid)',
'    left outer join T_BEnutzer lvko on (nvl(vp.lead_vko_benutzerid, v.LEAD_VKO_BENUTZERID) = lvko.benutzerid)',
'    left outer join T_getex_KOMMENTAR  gk on (v.regindexid is not null and gk.getex_key = v.regindexid)',
'  where v.Vorschrift_freigabeStatusid in (-1, 1) --and (v.status_update_getex is null or v.status_update_getex = 20 )',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_page_header=>'Importierte Vorschriften'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'l_count number;',
' ',
'begin',
'select count(*) into l_count',
'FROM T_BENUTZER_REF_ROLLE brr',
'WHERE brr.BENUTZERID  = :G_BENUTZERID',
'    AND brr.ROLLEID in (1100,1003);',
'    --exception when no_data_found then l_count :=0;',
'if l_count>0 then ',
'return (true);',
'else',
'return (false);',
'end if;',
'end;',
'',
'',
'',
'',
'',
'---s ever side ',
'',
'(',
'-- :P25_ROWID is not null and ',
'pck_ri.fIsUserInRolle(listRolleId => ''1100'') <= 0  -- 1100 = Rolle Getex Migration, 1003 = Fach admmin',
'',
'or',
'pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0',
'',
')'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(4666347975148382883)
,p_name=>'Importierte Vorschriften'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'Keine daten gefunden'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_detail_link_text=>'<span class="fa fa-search" aria-hidden="true"></span>	'
,p_detail_link_condition_type=>'EXPRESSION'
,p_detail_link_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 25,',
'                      accessMode => 100))'))
,p_detail_link_cond2=>'PLSQL'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>5779040912243517287
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672888397628495147)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Vorschriftid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672888014386495145)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Vorschrift Nummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672887616597495144)
,p_db_column_name=>'VORSCHRIFT_FREIGABESTATUSID'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Vorschrift Freigabestatus'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(958129793570194302)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672887161021495144)
,p_db_column_name=>'VORSCHRIFT_STATUSID'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Vorschrift Status'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(2490458092659806028)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672886809714495143)
,p_db_column_name=>'VORSCHRIFT_TYPID'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Vorschrift Typ'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(2656545044559578040)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672886396665495143)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672885970965495142)
,p_db_column_name=>'LETZTER_BENUTZER'
,p_display_order=>18
,p_column_identifier=>'I'
,p_column_label=>'Letzter Benutzer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672885215479495141)
,p_db_column_name=>'ARBEITSKREISE'
,p_display_order=>38
,p_column_identifier=>'K'
,p_column_label=>'Arbeitskreise'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672884809026495140)
,p_db_column_name=>'VORSCHRIFT_BEZEICHNUNG'
,p_display_order=>48
,p_column_identifier=>'N'
,p_column_label=>'Vorschrift Bezeichnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3148578237681251389)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>58
,p_column_identifier=>'R'
,p_column_label=>unistr('Gr\00FCnde f\00FCr\2018s nicht-Weiterschalten')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672884012477495139)
,p_db_column_name=>'STATUS_UPDATE_GETEX'
,p_display_order=>68
,p_column_identifier=>'P'
,p_column_label=>'Status Update Getex'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'pck_ri.fIsUserInRolle(listRolleId => ''1100:1003'') > 0'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1094032694934457134)
,p_db_column_name=>'DOKUMENTENDATUM'
,p_display_order=>78
,p_column_identifier=>'Q'
,p_column_label=>'Dokumentendatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3148578160807251388)
,p_db_column_name=>'EINSATZDATUM_MODELLID'
,p_display_order=>98
,p_column_identifier=>'S'
,p_column_label=>'Einsatzdatum Modell'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(1076773784946225404)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3148578043569251387)
,p_db_column_name=>'LEAD_VKO'
,p_display_order=>108
,p_column_identifier=>'T'
,p_column_label=>'Lead VKO'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(4666351873791393262)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'900049'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'VORSCHRIFT_NUMMER:DOKUMENTENDATUM:VORSCHRIFT_BEZEICHNUNG:KOMMENTAR:VORSCHRIFT_FREIGABESTATUSID:VORSCHRIFT_STATUSID:VORSCHRIFT_TYPID:EINSATZDATUM_MODELLID:LEAD_VKO:ARBEITSKREISE:LETZTE_AENDERUNG_DATUM:LETZTER_BENUTZER:STATUS_UPDATE_GETEX'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4862307312288111677)
,p_plug_name=>unistr('Ge\00E4nderte Vorschriften aus Getex 2 zur Pr\00FCfung und \00DCbernahme')
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with etb_cte as (',
'   select listagg(etb,'', '') within group (order by etb) liste,  vorschriftid',
'    from (',
'        select distinct ak.kurz etb, vtl.vorschriftid vorschriftid',
'        from t_vorschrift_ref_thema vtl',
'        join t_thema_ref_et_b_ak t on (vtl.themaid = t.themaid)',
'        join t_et_b_ak ak on (ak.et_b_akid = t.et_b_akid)',
'        where  vtl.geloescht = 0',
'    )',
'    group by vorschriftid',
'),',
'cte_act_g as ( -- alle Getex vorschriften , die activ in Verkn. sind ',
'           select distinct v.vorschriftid   -- gr.v_id , gr.reg_number --, gr.relationtype, gr.targetid ',
'            from  MV_getex_vorschrift_relation gr',
'            join t_vorschrift v on (v.regindexid is not null and v.regindexid = gr.v_id)',
'             where   gr.relationtype  in  (''EQUIVALENT_TO'', ''SUCCESSOR'',  ''CHANGES'', ''DEMANDS'', ''LINKED_TO'', ''CONSOLIDATES'') ',
'             and v.master in ( 20 , 30)',
'             order by v.vorschriftid ',
' ), ',
' cte_act_ri as ( -- alle active verkn. in Regindex, die vom GETEX gepflegt werden',
'          select distinct vrv.nachfolger_vorschriftid as vorschriftid',
'          from t_vorschrift_ref_vorschrift vrv',
'          join t_vorschrift v on (v.vorschriftid = vrv.nachfolger_vorschriftid)',
'          where  v.regindexid is not null ',
'          and v.master in ( 20 , 30)',
'          and v.regindexid in (select  reg_id  ',
'                             from mv_getex_vorschrift where nvl(loesch_datum, sysdate + 2) > sysdate )',
'           order by 1',
' )',
'--  cte_v_act as ( -- alle Getex vorschriften , die activ in Verkn. sind (exclusiv die Verkn. die als gegenpart von cte_v_pass)',
'--                select distinct v.vorschriftid   -- gr.v_id , gr.reg_number --, gr.relationtype, gr.targetid ',
' --               from  MV_getex_vorschrift_relation gr',
' --               full outer join t_vorschrift v on (v.regindexid is not null and v.regindexid = gr.v_id)',
'--                where (  gr.relationtype  in  (''EQUIVALENT_TO'', ''SUCCESSOR'',  ''CHANGES'', ''DEMANDS'',''LINKED_TO'', ''CONSOLIDATES'') ',
'--                       OR  (gr.relationtype is null and v.vorschriftid  in (',
'--                                                      select distinct nachfolger_vorschriftid from t_vorschrift_ref_vorschrift ) ) ',
'--                )',
'--                and v.master in ( 20 , 30)',
'--    ) ',
'    SELECT v.vorschriftid as link_abgl, ',
'       v.vorschriftID, v.vorschrift_nummer, v.DOKUMENTENDATUM, v.VORSCHRIFT_BEZEICHNUNG as VORSCHRIFT_BEZEICHNUNG, ',
'       gk.Kommentar as kommentar,',
'       v.Vorschrift_freigabeStatusid, v.VORSCHRIFT_STATUSID, v.EINSATZDATUM_MODELLID,',
'       v.Vorschrift_typid, -- CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN v.BEMERKUNG ELSE v.BEMERKUNG_ENGLISCH END BEMERKUNG, ',
'       v.LETZTE_AENDERUNG_DATUM ',
'       , nvl2(b.nachname, b.nachname||'',''|| b.vorname, ''system'') as letzter_benutzer,',
'       etb_cte.liste as arbeitskreise,',
'       case when (v.status_update_getex is null) then ''-''',
'            when v.status_update_getex  =10 then ''aktuell'' ',
'            when v.status_update_getex  =20 then ''nicht aktuell'' ',
'            when v.status_update_getex  =30 then  ''nicht in Getex''  end  as status_update_getex,',
'        v.LETZTE_AENDERUNG_GETEX_ATTR,',
'        v.MASTER,',
'        nvl2(lvko.nachname, lvko.nachname||'',''|| lvko.vorname, null) as Lead_VKO',
'    FROM T_Vorschrift v',
'    left outer join t_vorschrift_ref_vorschrift vrv on (v.vorschriftid = vrv.nachfolger_vorschriftid and beziehung_art = 30)    ',
'    left outer join t_vorschrift vp on (vrv.vorgaenger_vorschriftid = vp.vorschriftid and v.vorschrift_typid = 20) -- parent bei supplements    ',
'    left outer join T_BEnutzer b on (v.LETZTE_AENDERUNG_BENUTZERID = b.benutzerid)',
'    left outer join T_BEnutzer lvko on (nvl(vp.lead_vko_benutzerid, v.LEAD_VKO_BENUTZERID) = lvko.benutzerid)',
'    left outer join etb_cte on (etb_cte.vorschriftid = v.vorschriftid)',
'    left outer join T_getex_KOMMENTAR  gk on (v.regindexid is not null and gk.getex_key = v.regindexid)',
'   WHERE v.Vorschrift_freigabeStatusid not in (-1, 1) ',
'   and v.master in (20, 30)',
'   and (v.status_update_getex is not null and v.status_update_getex = 20)',
'   and ( --nvl(v.getex_vergleich_bitmaske, 0) != 16384 ',
'        ( bitand(nvl(v.getex_vergleich_bitmaske, 0), power(2,0)+ power(2,1)+ power(2,2)+ power(2,3)+ power(2,4)+ power(2,5)+ power(2,6)',
'           + power(2,7)+ power(2,8)+ power(2,9) + power(2,10)+ power(2,11)+ power(2,12)+power(2,13) ) >0',
'        )',
'       or  ',
'        (v.vorschriftid in (select vorschriftid from cte_act_g)',
'         or v.vorschriftid in (select vorschriftid from cte_act_ri) )',
unistr('    )    -- ''nicht relevant'' ausschlie\00DFen 1472, f. alle Rollen'),
'     AND (v.Vorschrift_FREIGABESTATUSID !=30 );  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'NEVER'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>'pck_ri.fIsUserInRolle(listRolleId => ''1003'') = 0'
,p_plug_read_only_when2=>'PLSQL'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'-- :P25_ROWID is not null and ',
'pck_ri.fIsUserInRolle(listRolleId => ''1100:1003'') > 0  -- 1100 = Rolle Getex Migration, 1003 = Fach admmin',
')'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(4862307423510111678)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'Keine daten gefunden'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_detail_link_text=>'<span class="fa fa-search" aria-hidden="true"></span>	'
,p_detail_link_condition_type=>'EXPRESSION'
,p_detail_link_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 25,',
'                      accessMode => 100))'))
,p_detail_link_cond2=>'PLSQL'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>5975000360605246082
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672883039951495123)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Vorschriftid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672877466160495113)
,p_db_column_name=>'LINK_ABGL'
,p_display_order=>20
,p_column_identifier=>'O'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:29:P29_VORSCHRIFTID,P29_MASTER:#VORSCHRIFTID#,#MASTER#'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-code-fork fa-rotate-180"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'( pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1100'') > 0 ) '
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672882665966495122)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Vorschrift Nummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672882238774495121)
,p_db_column_name=>'VORSCHRIFT_FREIGABESTATUSID'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Vorschrift Freigabestatus'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(958129793570194302)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672881871991495121)
,p_db_column_name=>'VORSCHRIFT_STATUSID'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Vorschrift Status'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(2490458092659806028)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672881506530495120)
,p_db_column_name=>'VORSCHRIFT_TYPID'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Vorschrift Typ'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(2656545044559578040)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672880714087495119)
,p_db_column_name=>'LETZTER_BENUTZER'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672879932807495118)
,p_db_column_name=>'ARBEITSKREISE'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Arbeitskreise'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672879479452495117)
,p_db_column_name=>'VORSCHRIFT_BEZEICHNUNG'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Vorschrift Bezeichnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3148577947509251386)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>120
,p_column_identifier=>'S'
,p_column_label=>unistr('Gr\00FCnde f\00FCr\2018s nicht-Weiterschalten')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672878720882495116)
,p_db_column_name=>'STATUS_UPDATE_GETEX'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Status Update Getex'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672878260202495115)
,p_db_column_name=>'LETZTE_AENDERUNG_GETEX_ATTR'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>unistr('Letzte \00C4nderung Getex Attribute')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672877869370495114)
,p_db_column_name=>'MASTER'
,p_display_order=>150
,p_column_identifier=>'N'
,p_column_label=>'Master'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(641251792420689703)
,p_db_column_name=>'LEAD_VKO'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Lead Vko'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3190445201488439820)
,p_db_column_name=>'EINSATZDATUM_MODELLID'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Einsatzdatum Modellid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(1076773784946225404)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1094032587689457133)
,p_db_column_name=>'DOKUMENTENDATUM'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Dokumentendatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1013004335551994334)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>190
,p_column_identifier=>'T'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(4876139988836105168)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2997930'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LINK_ABGL:VORSCHRIFT_NUMMER:DOKUMENTENDATUM:VORSCHRIFT_FREIGABESTATUSID:VORSCHRIFT_STATUSID:VORSCHRIFT_TYPID:EINSATZDATUM_MODELLID:LEAD_VKO:ARBEITSKREISE:VORSCHRIFT_BEZEICHNUNG:KOMMENTAR:STATUS_UPDATE_GETEX:LETZTE_AENDERUNG_GETEX_ATTR:LETZTE_AENDERUN'
||'G_DATUM:LETZTER_BENUTZER:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4949714774478619468)
,p_plug_name=>'Abgleich GETEX2 Attributgruppenweise'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'pck_ri.fIsUserInRolle(listRolleId => ''1100:1003:1200'') > 0'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5556230306285290277)
,p_plug_name=>'Abgleich Attributgruppenweise'
,p_region_name=>'VG_IG'
,p_parent_plug_id=>wwv_flow_imp.id(4949714774478619468)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    select level-1 as bitindex',
'    from dual',
'    connect by level <= 21',
'), cte2 as (',
'    select case when nvl(master,10) = 20 then ''GETEX 2'' ',
unistr('                when nvl(master,10) = 30 then ''GETEX 2 mit autom. \00DCbernahme'''),
'                else ''RegIndex'' end as master, ',
'    vorschriftid,',
'     null as link_abgleich, ',
'    1 as checkbox,',
'    vorschrift_nummer, DOKUMENTENDATUM, getex_vergleich_bitmaske, bitindex, emano_util.fbitmaskget(getex_vergleich_bitmaske, bitindex) wert,',
'    case when getex_vergleich_bitmaske = -1 then ''kein Match'' when getex_vergleich_bitmaske < 0 then ''Fehler'' when bitand(getex_vergleich_bitmaske,:P26_BITMASKE_GESAMTSTATUS) > 0 then ''abweichend'' else ''identisch'' end as gesamtstatus',
'    from t_vorschrift',
'    cross join cte1',
'    where getex_vergleich_bitmaske is not null',
'    order by vorschriftid, bitindex',
')',
'select *',
'from cte2',
'pivot (',
'  sum(wert) for bitindex in (0 as b00, 1 as b01, 2 as b02, 3 as b03, 4 as b04, 5 as b05, 6 as b06,7 as b07, 8 as b08,',
'  9 as b09,10 as b10,11 as b11,12 as b12, 13 as b13, 14 as b14, 15 as b15, 16 as b16,',
'    17 as b17, 18 as b18, 19 as b19, 20 as b20)',
')'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Abgleich Attributgruppenweise'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(5556230437050290278)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>6668923374145424682
);
wwv_flow_imp_page.create_worksheet_col_group(
 p_id=>wwv_flow_imp.id(5556232142973290295)
,p_name=>'Vergleich'
,p_display_sequence=>10
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672869508096495100)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_column_linktext=>'<span class="fa fa-search" aria-hidden="true"></span>	'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(653886386881692657)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>20
,p_column_identifier=>'AL'
,p_column_label=>'<input type="checkbox"  id="selectUnselectAll" title="Select/UnselectAll" value="all" />'
,p_column_html_expression=>'<input type="checkbox" value="#VORSCHRIFTID#" />'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_rpt_show_filter_lov=>'N'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'pck_ri.fIsUserInRolle(pck_ri.fGetUSerId, listRolleId => ''1003:1200'') >0'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672868257686495099)
,p_db_column_name=>'LINK_ABGLEICH'
,p_display_order=>30
,p_column_identifier=>'Q'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:RP,29:P29_VORSCHRIFTID:#VORSCHRIFTID#'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-code-fork fa-rotate-180"></span>'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672869037188495100)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Vorschrift'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672868649756495100)
,p_db_column_name=>'GETEX_VERGLEICH_BITMASKE'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Getex Vergleich Bitmaske'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672867921515495099)
,p_db_column_name=>'GESAMTSTATUS'
,p_display_order=>60
,p_column_identifier=>'S'
,p_column_label=>'Gesamtstatus'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672874250075495104)
,p_db_column_name=>'B00'
,p_display_order=>70
,p_column_identifier=>'T'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672873843476495103)
,p_db_column_name=>'B01'
,p_display_order=>80
,p_column_identifier=>'U'
,p_column_label=>'Dokumentendatum'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672873479620495103)
,p_db_column_name=>'B02'
,p_display_order=>90
,p_column_identifier=>'V'
,p_column_label=>'Dokumententyp'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672873047369495103)
,p_db_column_name=>'B03'
,p_display_order=>100
,p_column_identifier=>'W'
,p_column_label=>'Titel kurz'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672872698906495103)
,p_db_column_name=>'B04'
,p_display_order=>110
,p_column_identifier=>'X'
,p_column_label=>'Titel lang'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672872255028495103)
,p_db_column_name=>'B05'
,p_display_order=>120
,p_column_identifier=>'Y'
,p_column_label=>'Status der Vorschrift'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672871911275495102)
,p_db_column_name=>'B06'
,p_display_order=>130
,p_column_identifier=>'Z'
,p_column_label=>'Einsatzdatum Modell'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672871448099495102)
,p_db_column_name=>'B07'
,p_display_order=>140
,p_column_identifier=>'AA'
,p_column_label=>'Vorschriftentyp'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672871072521495102)
,p_db_column_name=>'B09'
,p_display_order=>150
,p_column_identifier=>'AC'
,p_column_label=>'Fahrzeugarten'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672870655600495102)
,p_db_column_name=>'B10'
,p_display_order=>160
,p_column_identifier=>'AD'
,p_column_label=>unistr('L\00E4nder')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672870249323495102)
,p_db_column_name=>'B11'
,p_display_order=>170
,p_column_identifier=>'AE'
,p_column_label=>'Themen'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672869864911495100)
,p_db_column_name=>'B12'
,p_display_order=>180
,p_column_identifier=>'AF'
,p_column_label=>'Inkraftsetzungsdatum'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672867462417495099)
,p_db_column_name=>'B13'
,p_display_order=>190
,p_column_identifier=>'AG'
,p_column_label=>'Einsatzdaten'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672867095586495099)
,p_db_column_name=>'B14'
,p_display_order=>200
,p_column_identifier=>'AH'
,p_column_label=>unistr('Verkn\00FCpfungen')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(672874671685495104)
,p_db_column_name=>'B08'
,p_display_order=>210
,p_column_identifier=>'AI'
,p_column_label=>'Antriebsarten'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1064037121433015303)
,p_db_column_name=>'B15'
,p_display_order=>220
,p_column_identifier=>'AN'
,p_column_label=>'Successor/Predecessor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_column_comment=>':G_BenutzerID = 15643'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1064037087407015302)
,p_db_column_name=>'B16'
,p_display_order=>230
,p_column_identifier=>'AO'
,p_column_label=>'Amendment/Supplement'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_column_comment=>':G_BenutzerID = 15643'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1064036972874015301)
,p_db_column_name=>'B17'
,p_display_order=>270
,p_column_identifier=>'AP'
,p_column_label=>'Demands'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_column_comment=>':G_BenutzerID = 15643'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1064036890528015300)
,p_db_column_name=>'B18'
,p_display_order=>280
,p_column_identifier=>'AQ'
,p_column_label=>'Linked To'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_column_comment=>':G_BenutzerID = 15643'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1064036760314015299)
,p_db_column_name=>'B19'
,p_display_order=>290
,p_column_identifier=>'AR'
,p_column_label=>'Equivalent'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_column_comment=>':G_BenutzerID = 15643'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1064036702903015298)
,p_db_column_name=>'B20'
,p_display_order=>300
,p_column_identifier=>'AS'
,p_column_label=>'Consolidates'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(739407984509553661)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_column_comment=>':G_BenutzerID = 15643'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1376714835436615200)
,p_db_column_name=>'MASTER'
,p_display_order=>310
,p_column_identifier=>'AK'
,p_column_label=>'Master'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1094032444925457132)
,p_db_column_name=>'DOKUMENTENDATUM'
,p_display_order=>320
,p_column_identifier=>'AM'
,p_column_label=>'Dokumentendatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(4949630218755337752)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3732832'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'VORSCHRIFTID:LINK_ABGLEICH:CHECKBOX:VORSCHRIFT_NUMMER:DOKUMENTENDATUM:MASTER:GESAMTSTATUS:B01:B02:B06:B09:B12:B10:B05:B11:B03:B04:B00:B07:B13:B14:B15:B16:B17:B18:B19:B20:'
,p_sort_column_1=>'VORSCHRIFT_NUMMER'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(672876515647495112)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4949714774478619468)
,p_button_name=>'APPLY_GESAMTSTATUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Berechnen'
,p_icon_css_classes=>'fa-calculator'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>1
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(672866435685495098)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5556230306285290277)
,p_button_name=>'ExportCSV'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Export Download'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-download-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(653886855845692662)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(5556230306285290277)
,p_button_name=>'Mass_Update'
,p_button_static_id=>'b_UB'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Massenupdate'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:44:&SESSION.::&DEBUG.::P44_LOAD_FROM:"P26_SELECTED_ROWS"'
,p_button_condition=>'pck_ri.fIsUserInRolle(pck_ri.fGetUSerId, listRolleId => ''1003:1200'') >0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-download-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(672876098690495110)
,p_name=>'P26_GESAMTSTATUS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4949714774478619468)
,p_prompt=>'Gesamtstatus berechnen aus:  (<span class="link-preset" onclick="fSelectAll(this)">alle</span> | <span class="link-preset" onclick="$s(''P26_GESAMTSTATUS'',''7:9:10:11:12:13:14'')">EDAG</span> | <span class="link-preset" onclick="$s(''P26_GESAMTSTATUS'','''''
||')">keine</span>)'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    select level-1 as bindex',
'    from dual',
'    connect by level <= 21 -- 15',
')',
'select decode(bindex,',
'        0,''Vorschriften nummer'',1,''Dokumentendatum'',2,''Dokumententyp'',',
'        3,''Titel kurz'',4,''Titel lang'',5,''Status der Vorschrift'',',
'        6,''Einsatzdatum Modell'', 7,''Vorschriftentyp'', 8,''Antriebsarten'',',
unistr('        9,''Fahrzeugarten'',10,''L\00E4nder'',11,''Themen'','),
unistr('        12,''Inkraftsetzungsdatum'', 13,''Einsatzdaten'', 14, ''Verkn\00FCpfungen'','),
'        15,''Successor/Predecessor'',',
'        16,''Amendment/Supplement'',',
'        17,''Demands'',',
'        18,''Linked To'',',
'        19,''Equivalent'',',
'        20,''Consolidates''',
'    ) as d,',
'    bindex as r',
'    ',
'from cte1 where  bindex != 8   '))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '7')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    select level-1 as bindex',
'    from dual',
'    connect by level <= 15',
')',
'select decode(bindex,',
'        0,''Vorschriften nummer'',1,''Dokumenten datum'',2,''Dokumententyp'',',
'        3,''Titel kurz'',4,''Titel lang'',5,''Status der Vorschrift'',',
'        6,''Einsatzdatum Modell'', 7,''Vorschriftentyp'', 8,''Antriebsarten'',',
unistr('        9,''Fahrzeug klassen'',10,''L\00E4nder'',11,''Themen'','),
unistr('        12,''Inkraft datum'', 13,''Einsatzdaten'', 14, ''Verkn\00FCpfungen'''),
'    ) as d,',
'    bindex as r',
'    ',
'from cte1 where  bindex != 8   '))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(672875678752495109)
,p_name=>'P26_BITMASKE_GESAMTSTATUS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(4949714774478619468)
,p_use_cache_before_default=>'NO'
,p_source=>'emano_util.fColonListToBitmask(:P26_GESAMTSTATUS)'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(653886825178692661)
,p_name=>'P26_SELECTED_ROWS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4949714774478619468)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(672865546109495095)
,p_name=>'Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(4666347950230382883)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(672865134059495091)
,p_event_id=>wwv_flow_imp.id(672865546109495095)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4666347950230382883)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1034408711660783707)
,p_event_id=>wwv_flow_imp.id(672865546109495095)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4862307312288111677)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(653886732877692660)
,p_name=>'Zeilenselektor'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'td input, th input'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#VG_IG'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(653886549391692659)
,p_event_id=>wwv_flow_imp.id(653886732877692660)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var any_checked = $("#VG_IG").find("td input:checked").length > 0;',
'',
'if (any_checked) {',
'    $("#b_UB").removeClass("apex_disabled");',
'} else {',
'    $("#b_UB").addClass("apex_disabled");',
'}',
'',
'$("#b_UB").prop(''disabled'', !any_checked);',
'',
'var sel_rows = apex.item(''P26_SELECTED_ROWS'');',
'sel_rows.setValue("");',
'$("#VG_IG").find("td input:checked").each(function() {',
'  if(sel_rows.getValue().length > 0) {',
'    sel_rows.setValue(sel_rows.getValue() + ":");    ',
'  }',
'  sel_rows.setValue(sel_rows.getValue() + this.value);',
'});'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(653886524230692658)
,p_event_id=>wwv_flow_imp.id(653886732877692660)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P26_SELECTED_ROWS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1088388828945898512)
,p_name=>unistr('Dialog Closed Aenderungen zur Pr\00FCfung/\00DCbernahme Page')
,p_event_sequence=>30
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId && this.data.dialogPageId == 29'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1088388493767898510)
,p_event_id=>wwv_flow_imp.id(1088388828945898512)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5556230306285290277)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1087942928473945534)
,p_event_id=>wwv_flow_imp.id(1088388828945898512)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4862307312288111677)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1034407502585783695)
,p_name=>'Dialog Closed or Canceled'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(4862307312288111677)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1034407370884783694)
,p_event_id=>wwv_flow_imp.id(1034407502585783695)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4862307312288111677)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(672866017743495097)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Custom XLSX Export'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_context apex_exec.t_context;',
'    l_print_config    apex_data_export.t_print_config;',
'    l_export apex_data_export.t_export;',
'    l_name VARCHAR2(255);',
'    lTitle varchar2(250);',
'BEGIN',
'',
'    -- Retrieve the user''s name',
'    SELECT b.nachname || ''_'' || b.vorname',
'    INTO l_name',
'    FROM t_benutzer b',
'    WHERE benutzerid = :G_BENUTZERID;',
'',
'     -- Set the sheet 1 title for the export',
'    lTitle := ''Abgleich Attributgruppenweise'';',
'',
'    l_context := apex_exec.open_query_context(',
'        p_location => apex_exec.c_location_local_db,',
'        p_sql_query => q''[',
'                WITH cte1 AS (',
'                    SELECT level - 1 AS bitindex',
'                    FROM dual',
'                    CONNECT BY level <= 15',
'                ), ',
'                cte2 AS (',
'                    SELECT',
'                        -- vorschriftid,',
'',
'                        apex_util.host_url(''SCRIPT'') || apex_page.get_url(',
'                            p_application => :APP_ALIAS',
'                            , p_page => ''VORSCHRIFT''',
'                            , p_items => ''P25_VORSCHRIFTID''',
'                            , p_values => vorschriftid',
'                            , p_session => null',
'                            , p_clear_cache => ''25''',
'                            ) as permalink,',
'                        -- NULL AS link_abgleich,',
'                        url_getex_vorschrift as getex_link,',
'                        ',
'                        vorschrift_nummer,',
'                        -- getex_vergleich_bitmaske,',
'                        bitindex,',
'                        emano_util.fbitmaskget(getex_vergleich_bitmaske, bitindex) wert,',
'                        ',
'                        CASE',
'                            WHEN getex_vergleich_bitmaske = -1 THEN ''kein Match''',
'                            WHEN getex_vergleich_bitmaske = -2 THEN ''Fehler''',
'                            WHEN BITAND(getex_vergleich_bitmaske, v(''P26_BITMASKE_GESAMTSTATUS'')) > 0 THEN ''abweichend''',
'                            ELSE ''identisch''',
'                        END AS gesamtstatus,',
'                        case when nvl(master,10) = 20 then ''GETEX 2'' ',
unistr('                             when nvl(master,10) = 30 then ''GETEX 2 mit autom \00DCbernahme'' '),
'                              else ''RegIndex'' end as master',
'                    FROM t_vorschrift',
'                    CROSS JOIN cte1',
'                    WHERE getex_vergleich_bitmaske IS NOT NULL',
'                    ORDER BY vorschriftid, bitindex',
'            )',
'',
'            SELECT --vorschriftid, ',
'            permalink as "Permalink", ',
'            getex_link as "Getex URL", ',
'           ',
'            vorschrift_nummer as "Vorschrift", ',
'            master as "Master",',
'            gesamtstatus as "Gesamtstatus",',
'            CASE WHEN Antriebsarten = 1 THEN ''identisch'' WHEN Antriebsarten = 0 THEN ''abweichend'' END AS "Antriebsarten",',
'            CASE WHEN Dokumentendatum = 1 THEN ''identisch'' WHEN Dokumentendatum = 0 THEN ''abweichend'' END AS "Dokumentendatum",',
'            CASE WHEN Dokumententyp = 1 THEN ''identisch'' WHEN Dokumententyp = 0 THEN ''abweichend'' END AS "Dokumententyp",',
'            CASE WHEN Einsatzdatum_Modell = 1 THEN ''identisch'' WHEN Einsatzdatum_Modell = 0 THEN ''abweichend'' END AS "Einsatzdatum Modell",',
'            CASE WHEN Fahrzeugkarten = 1 THEN ''identisch'' WHEN Fahrzeugkarten = 0 THEN ''abweichend'' END AS "Fahrzeugkarten",',
'            CASE WHEN Inkraftsetzungsdatum = 1 THEN ''identisch'' WHEN Inkraftsetzungsdatum = 0 THEN ''abweichend'' END AS "Inkraftsetzungsdatum",',
unistr('            CASE WHEN L\00E4nder = 1 THEN ''identisch'' WHEN L\00E4nder = 0 THEN ''abweichend'' END AS "L\00E4nder",'),
'            CASE WHEN Status_der_Vorschrift = 1 THEN ''identisch'' WHEN Status_der_Vorschrift = 0 THEN ''abweichend'' END AS "Status der Vorschrift",',
'            CASE WHEN Themen = 1 THEN ''identisch'' WHEN Themen = 0 THEN ''abweichend'' END AS "Themen",',
'            CASE WHEN Titel_kurz = 1 THEN ''identisch'' WHEN Titel_kurz = 0 THEN ''abweichend'' END AS "Titel kurz",',
'            CASE WHEN Titel_lang = 1 THEN ''identisch'' WHEN Titel_lang = 0 THEN ''abweichend'' END AS "Titel lang",',
'            CASE WHEN Vorschriftennummer = 1 THEN ''identisch'' WHEN Vorschriftennummer = 0 THEN ''abweichend'' END AS "Vorschriftennummer",',
'            CASE WHEN Vorschriftentyp = 1 THEN ''identisch'' WHEN Vorschriftentyp = 0 THEN ''abweichend'' END AS "Vorschriftentyp",',
'            CASE WHEN Einsatzdaten = 1 THEN ''identisch'' WHEN Einsatzdaten = 0 THEN ''abweichend'' END AS "Einsatzdaten",',
unistr('            CASE WHEN Verkn\00FCpfungen = 1 THEN ''identisch'' WHEN Verkn\00FCpfungen = 0 THEN ''abweichend'' END AS "Verkn\00FCpfungen"'),
'            FROM (',
'            SELECT *',
'            FROM cte2',
'            PIVOT (',
'                SUM(wert) FOR bitindex IN (',
'                   0 AS Vorschriftennummer, ',
'                   1 AS Dokumentendatum, ',
'                   2 AS Dokumententyp, ',
'                   3 AS Titel_kurz,',
'                   4 AS Titel_lang,',
'                   5 AS Status_der_Vorschrift,',
'                   6 AS Einsatzdatum_Modell,',
'                   7 AS Vorschriftentyp,',
'                   8 AS Antriebsarten,',
'                   9 AS Fahrzeugkarten,',
unistr('                   10 AS L\00E4nder,'),
'                   11 AS Themen,',
'                   12 AS Inkraftsetzungsdatum,',
'                   13 AS Einsatzdaten,',
unistr('                   14 AS Verkn\00FCpfungen'),
'               )',
'            )   ',
'        )',
'        order by "Vorschrift"',
'        ]'');',
'',
'',
'    l_print_config := apex_data_export.get_print_config(',
'        p_page_header => lTitle,',
'        p_header_font_family => ''Audi Type'',',
'        p_header_font_size => 10,',
'        p_body_font_family => ''Audi Type'',',
'        p_body_font_size => 10,',
'        p_border_width    => 0.5,',
'        p_page_footer => ''Abgleich Attributgruppenweise'',',
'        p_page_footer_font_family => ''Audi Type'',',
'        p_page_footer_font_size => 10,',
'        p_header_bg_color => ''#D0D0D0''',
'',
'',
'    ',
'    );',
'        ',
'    l_export := apex_data_export.export(',
'        p_context => l_context,',
'        p_print_config => l_print_config,',
'        p_format => apex_data_export.c_format_xlsx,',
'        p_file_name => ''Excel-Export-Abgleich Attributgruppenweise'' || ''-'' || l_name || ''-'' || TO_CHAR(SYSDATE, ''DD.MM.YYYY HH24:MI:SS'') || ''.xlsx''',
'',
'    );',
'',
'',
'',
'',
'',
'    apex_exec.close(l_context);',
'    apex_data_export.download(p_export => l_export);',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_exec.close(l_context);',
'        RAISE;',
'',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(672866435685495098)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2999346298155893138
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1064036565129015297)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Custom XLSX Export_NewBits'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_context apex_exec.t_context;',
'    l_print_config    apex_data_export.t_print_config;',
'    l_export apex_data_export.t_export;',
'    l_name VARCHAR2(255);',
'    lTitle varchar2(250);',
'BEGIN',
'',
'    -- Retrieve the user''s name',
'    SELECT b.nachname || ''_'' || b.vorname',
'    INTO l_name',
'    FROM t_benutzer b',
'    WHERE benutzerid = :G_BENUTZERID;',
'',
'     -- Set the sheet 1 title for the export',
'    lTitle := ''Abgleich Attributgruppenweise'';',
'',
'    l_context := apex_exec.open_query_context(',
'        p_location => apex_exec.c_location_local_db,',
'        p_sql_query => q''[',
'                WITH cte1 AS (',
'                    SELECT level - 1 AS bitindex',
'                    FROM dual',
'                    CONNECT BY level <= 21',
'                ), ',
'                cte2 AS (',
'                    SELECT',
'                        -- vorschriftid,',
'',
'                        apex_util.host_url(''SCRIPT'') || apex_page.get_url(',
'                            p_application => :APP_ALIAS',
'                            , p_page => ''VORSCHRIFT''',
'                            , p_items => ''P25_VORSCHRIFTID''',
'                            , p_values => vorschriftid',
'                            , p_session => null',
'                            , p_clear_cache => ''25''',
'                            ) as permalink,',
'                        -- NULL AS link_abgleich,',
'                        url_getex_vorschrift as getex_link,',
'                        ',
'                        vorschrift_nummer,',
'                        -- getex_vergleich_bitmaske,',
'                        bitindex,',
'                        emano_util.fbitmaskget(getex_vergleich_bitmaske, bitindex) wert,',
'                        ',
'                        CASE',
'                            WHEN getex_vergleich_bitmaske = -1 THEN ''kein Match''',
'                            WHEN getex_vergleich_bitmaske = -2 THEN ''Fehler''',
'                            WHEN BITAND(getex_vergleich_bitmaske, v(''P26_BITMASKE_GESAMTSTATUS'')) > 0 THEN ''abweichend''',
'                            ELSE ''identisch''',
'                        END AS gesamtstatus,',
'                        case when nvl(master,10) = 20 then ''GETEX 2'' ',
unistr('                        when nvl(master,10) = 30 then ''GETEX 2 mit autom. \00DCbernahme'''),
'                        else ''RegIndex'' end as master',
'                    FROM t_vorschrift',
'                    CROSS JOIN cte1',
'                    WHERE getex_vergleich_bitmaske IS NOT NULL',
'                    ORDER BY vorschriftid, bitindex',
'            )',
'',
'            SELECT --vorschriftid, ',
'            permalink as "Permalink", ',
'            getex_link as "Getex URL", ',
'           ',
'            vorschrift_nummer as "Vorschrift", ',
'            master as "Master",',
'            gesamtstatus as "Gesamtstatus",',
'            CASE WHEN Antriebsarten = 1 THEN ''identisch'' WHEN Antriebsarten = 0 THEN ''abweichend'' END AS "Antriebsarten",',
'            CASE WHEN Dokumentendatum = 1 THEN ''identisch'' WHEN Dokumentendatum = 0 THEN ''abweichend'' END AS "Dokumentendatum",',
'            CASE WHEN Dokumententyp = 1 THEN ''identisch'' WHEN Dokumententyp = 0 THEN ''abweichend'' END AS "Dokumententyp",',
'            CASE WHEN Einsatzdatum_Modell = 1 THEN ''identisch'' WHEN Einsatzdatum_Modell = 0 THEN ''abweichend'' END AS "Einsatzdatum Modell",',
'            CASE WHEN Fahrzeugarten = 1 THEN ''identisch'' WHEN Fahrzeugarten = 0 THEN ''abweichend'' END AS "Fahrzeugarten",',
'            CASE WHEN Inkraftsetzungsdatum = 1 THEN ''identisch'' WHEN Inkraftsetzungsdatum = 0 THEN ''abweichend'' END AS "Inkraftsetzungsdatum",',
unistr('            CASE WHEN L\00E4nder = 1 THEN ''identisch'' WHEN L\00E4nder = 0 THEN ''abweichend'' END AS "L\00E4nder",'),
'            CASE WHEN Status_der_Vorschrift = 1 THEN ''identisch'' WHEN Status_der_Vorschrift = 0 THEN ''abweichend'' END AS "Status der Vorschrift",',
'            CASE WHEN Themen = 1 THEN ''identisch'' WHEN Themen = 0 THEN ''abweichend'' END AS "Themen",',
'            CASE WHEN Titel_kurz = 1 THEN ''identisch'' WHEN Titel_kurz = 0 THEN ''abweichend'' END AS "Titel kurz",',
'            CASE WHEN Titel_lang = 1 THEN ''identisch'' WHEN Titel_lang = 0 THEN ''abweichend'' END AS "Titel lang",',
'            CASE WHEN Vorschriftennummer = 1 THEN ''identisch'' WHEN Vorschriftennummer = 0 THEN ''abweichend'' END AS "Vorschriftennummer",',
'            CASE WHEN Vorschriftentyp = 1 THEN ''identisch'' WHEN Vorschriftentyp = 0 THEN ''abweichend'' END AS "Vorschriftentyp",',
'            CASE WHEN Einsatzdaten = 1 THEN ''identisch'' WHEN Einsatzdaten = 0 THEN ''abweichend'' END AS "Einsatzdaten",',
unistr('            CASE WHEN Verkn\00FCpfungen = 1 THEN ''identisch'' WHEN Verkn\00FCpfungen = 0 THEN ''abweichend'' END AS "Verkn\00FCpfungen",'),
'            ',
'            CASE WHEN Successor_Predecessor = 1 THEN ''identisch'' WHEN Successor_Predecessor = 0 THEN ''abweichend'' END AS "Successor/Predecessor",',
'            CASE WHEN Amendment_Supplement = 1 THEN ''identisch'' WHEN Amendment_Supplement = 0 THEN ''abweichend'' END AS "Amendment/Supplement",',
'            CASE WHEN Demands = 1 THEN ''identisch'' WHEN Demands = 0 THEN ''abweichend'' END AS "Demands",',
'            CASE WHEN Linked_To = 1 THEN ''identisch'' WHEN Linked_To = 0 THEN ''abweichend'' END AS "Linked To",',
'            CASE WHEN Equivalent = 1 THEN ''identisch'' WHEN Equivalent = 0 THEN ''abweichend'' END AS "Equivalent",',
'            CASE WHEN Consolidates = 1 THEN ''identisch'' WHEN Consolidates = 0 THEN ''abweichend'' END AS "Consolidates"',
'',
'',
'            FROM (',
'            SELECT *',
'            FROM cte2',
'            PIVOT (',
'                SUM(wert) FOR bitindex IN (',
'                   0 AS Vorschriftennummer, ',
'                   1 AS Dokumentendatum, ',
'                   2 AS Dokumententyp, ',
'                   3 AS Titel_kurz,',
'                   4 AS Titel_lang,',
'                   5 AS Status_der_Vorschrift,',
'                   6 AS Einsatzdatum_Modell,',
'                   7 AS Vorschriftentyp,',
'                   8 AS Antriebsarten,',
'                   9 AS Fahrzeugarten,',
unistr('                   10 AS L\00E4nder,'),
'                   11 AS Themen,',
'                   12 AS Inkraftsetzungsdatum,',
'                   13 AS Einsatzdaten,',
unistr('                   14 AS Verkn\00FCpfungen,'),
'                   15 AS Successor_Predecessor,',
'                   16 AS Amendment_Supplement,',
'                   17 AS Demands,',
'                   18 AS Linked_To,',
'                   19 AS Equivalent,',
'                   20 AS Consolidates',
'                   ',
'               )',
'            )   ',
'        )',
'        order by "Vorschrift"',
'        ]'');',
'',
'',
'    l_print_config := apex_data_export.get_print_config(',
'        p_page_header => lTitle,',
'        p_header_font_family => ''Audi Type'',',
'        p_header_font_size => 10,',
'        p_body_font_family => ''Audi Type'',',
'        p_body_font_size => 10,',
'        p_border_width    => 0.5,',
'        p_page_footer => ''Abgleich Attributgruppenweise'',',
'        p_page_footer_font_family => ''Audi Type'',',
'        p_page_footer_font_size => 10,',
'        p_header_bg_color => ''#D0D0D0''',
'',
'',
'    ',
'    );',
'        ',
'    l_export := apex_data_export.export(',
'        p_context => l_context,',
'        p_print_config => l_print_config,',
'        p_format => apex_data_export.c_format_xlsx,',
'        p_file_name => ''Excel-Export-Abgleich Attributgruppenweise'' || ''-'' || l_name || ''-'' || TO_CHAR(SYSDATE, ''DD.MM.YYYY HH24:MI:SS'') || ''.xlsx''',
'',
'    );',
'',
'',
'',
'',
'',
'    apex_exec.close(l_context);',
'    apex_data_export.download(p_export => l_export);',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_exec.close(l_context);',
'        RAISE;',
'',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(672866435685495098)
,p_internal_uid=>2608175750770372938
);
wwv_flow_imp.component_end;
end;
/
