prompt --application/pages/page_00420
begin
--   Manifest
--     PAGE: 00420
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>420
,p_name=>'REV Benachrichtigung'
,p_alias=>'REV-BENACHRICHTIGUNG'
,p_step_title=>'REV Benachrichtigung'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-AlertMessage {',
'    padding-left: 20px;',
'    padding-right: 20px;',
'}',
'',
'.confirm_rev_changes {',
'    cursor:pointer;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8365875368866113090)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14396961581515623318)
,p_plug_name=>'Regulierungsverantwortliche'
,p_region_name=>'RVIR'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    select vrv.verantwortlicherid,',
'        listagg(case when vrv.ist_hauptverantwortlicher = 10 then ''<span style="text-decoration: underline;">'' else ''<span>'' end || vo.vorschrift_nummer || ''</span>'', '', '') within group (order by vrv.VORSCHRIFT_REF_VERANTWORTLICHERID) as liste_vorsch'
||'riften,',
'        listagg(distinct trim(vo.swr_hauptumsetzende_oe), '', '') within group (order by vrv.VORSCHRIFT_REF_VERANTWORTLICHERID)  as liste_hauptumsetzende_oe',
'    from t_vorschrift_ref_verantwortlicher vrv',
'    left outer join t_vorschrift vo on (vrv.vorschriftid = vo.vorschriftid)',
'    group by vrv.verantwortlicherid',
'),',
'cte2 as (',
'    select v.verantwortlicherid,',
'        decode(ctrl.STATUS, 10, ''offen'', 20, ''E-Mail versendet'', 30, ''erledigt'', 40, ''abgebrochen'') as status,',
'        ctrl.wert_hash as tracking_code,',
'        ctrl.zeitpunkt_versand,',
'        ctrl.zeitpunkt_klick,',
'        ctrl.zeitpunkt_erste_taetigkeit,',
'        ctrl.zeitpunkt_abschluss,',
'        ctrl.rev_kontrolle_id',
'    from T_VERANTWORTLICHER v',
'    left outer join t_rev_kontrolle ctrl on (v.verantwortlicherid = ctrl.verantwortlicherid)',
')',
'select ',
'       --v.ROWID,',
'       v.NACHNAME,',
'       v.VORNAME,',
'       case when rev.rev_kontrolle_gruppe_id is null then ''2024/Q4'' else gruppe.GRUPPE_NAME end as rev_kontrolle_gruppe_id,',
'       decode(rev.STATUS, 10, ''offen'', 20, ''E-Mail versendet'', 30, ''erledigt'', 40, ''abgebrochen'') as status,',
'       v.EMAIL,',
'       v.GID,',
'       cte1.liste_vorschriften,',
'       cte1.liste_hauptumsetzende_oe,',
'       PCK_REV.fCreateRevControlUrl(v.VERANTWORTLICHERID, cte2.tracking_code) as tracking_code,',
'       cte2.zeitpunkt_versand,',
'       cte2.zeitpunkt_klick,',
'       cte2.zeitpunkt_erste_taetigkeit,',
'       cte2.zeitpunkt_abschluss,',
'       rev.rev_kontrolle_id,',
'       v.VERANTWORTLICHERID,',
unistr('    --    ''<a href="'' || pck_rev.fCreateMailContent(rev.rev_kontrolle_id) || ''"><span title="Mailvorlage \00F6ffnen" class="fa fa-envelope-o"></span></a>'' as mail_vorbereiten1,'),
'        -- ''<button onclick="sendREVMail('' || rev.rev_kontrolle_id || '')" '' ||',
'        -- ''class="t-Button t-Button--icon t-Button--small" '' ||',
'        -- ''type="button" title="Send Email">'' ||',
'        -- ''<span class="fa fa-envelope-o" aria-hidden="true"></span></button>'' as mail_vorbereiten',
unistr('        ''<span data-id="'' || rev.rev_kontrolle_id || ''" title="E-Mail Vorlage \00F6ffnen" class="confirm_rev_changes fa fa-envelope-o" style="cursor: pointer;"></span>'' as mail_vorbereiten'),
'',
'',
'',
'  from T_REV_KONTROLLE rev',
'  left join t_rev_kontrolle_gruppe gruppe on gruppe.REV_KONTROLLE_GRUPPE_ID = rev.REV_KONTROLLE_GRUPPE_ID',
'  join T_VERANTWORTLICHER v on v.verantwortlicherid = rev.verantwortlicherid',
'  left outer join cte1 on (v.verantwortlicherid = cte1.verantwortlicherid)',
'  left outer join cte2 on (v.verantwortlicherid = cte2.verantwortlicherid and rev.rev_kontrolle_id = cte2.rev_kontrolle_id)',
'  where rev.rev_kontrolle_gruppe_id = nvl(:P420_KONTROLLE_GRUPPE, rev.rev_kontrolle_gruppe_id)',
'  /*group by rev_kontrolle_gruppe_id, rev.status,',
'       v.NACHNAME,',
'       v.VORNAME,',
'       v.EMAIL,',
'       v.GID,',
'       cte1.liste_vorschriften,',
'       cte1.liste_hauptumsetzende_oe,',
'       cte2.tracking_code,',
'       cte2.zeitpunkt_versand,',
'       cte2.zeitpunkt_klick,',
'       cte2.zeitpunkt_erste_taetigkeit,',
'       cte2.zeitpunkt_abschluss,',
'       rev.rev_kontrolle_id,',
'       v.VERANTWORTLICHERID*/'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P420_KONTROLLE_GRUPPE'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Regulierungsverantwortliche'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3168576918133816415)
,p_name=>'MAIL_VORBEREITEN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MAIL_VORBEREITEN'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>190
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13990671963138543960)
,p_name=>'VERANTWORTLICHERID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VERANTWORTLICHERID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13990672143588543961)
,p_name=>'NACHNAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NACHNAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Nachname'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13990672172240543962)
,p_name=>'VORNAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORNAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Vorname'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13990672285789543963)
,p_name=>'EMAIL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMAIL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Email'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13990672412244543964)
,p_name=>'GID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'GID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>100
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13990672484109543965)
,p_name=>'LISTE_VORSCHRIFTEN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LISTE_VORSCHRIFTEN'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_RICH_TEXT_EDITOR'
,p_heading=>'Liste Vorschriften'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_rich_text', 'Y',
  'format', 'MARKDOWN',
  'min_height', '180')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13990672594896543966)
,p_name=>'LISTE_HAUPTUMSETZENDE_OE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LISTE_HAUPTUMSETZENDE_OE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'OE2 des REV'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13990672741530544067)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Status'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'CENTER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13990672771009544068)
,p_name=>'TRACKING_CODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TRACKING_CODE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_LINK'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_link_target=>'&TRACKING_CODE.'
,p_link_text=>'&TRACKING_CODE.'
,p_link_attributes=>'target="_blank"'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'pck_ri.fIsUserInRolle(listRolleId => ''1200:1003'') > 0'
,p_display_condition2=>'PLSQL'
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13990672990403544070)
,p_name=>'ZEITPUNKT_VERSAND'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ZEITPUNKT_VERSAND'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Zeitpunkt <br/>Versand'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_format_mask=>'dd.mm.yy'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13990673140367544071)
,p_name=>'ZEITPUNKT_KLICK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ZEITPUNKT_KLICK'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Zeitpunkt <br/>Klick'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_format_mask=>'dd.mm.yy'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13990673249949544072)
,p_name=>'ZEITPUNKT_ERSTE_TAETIGKEIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ZEITPUNKT_ERSTE_TAETIGKEIT'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('Zeitpunkt <br/>erste T\00E4tigkeit')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>170
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_format_mask=>'dd.mm.yy'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13990673327577544073)
,p_name=>'ZEITPUNKT_ABSCHLUSS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ZEITPUNKT_ABSCHLUSS'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Zeitpunkt <br/>Abschluss'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>180
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_format_mask=>'dd.mm.yy'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13990987137269969756)
,p_name=>'REV_KONTROLLE_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'REV_KONTROLLE_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>false
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13990987703052969762)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'Y',
  'hide_control', 'N',
  'show_select_all', 'Y')).to_clob
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(14005068794853420861)
,p_name=>'REV_KONTROLLE_GRUPPE_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'REV_KONTROLLE_GRUPPE_ID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'REV <br/>Kontrollgruppe'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(13990671931139543959)
,p_internal_uid=>17662884247038932194
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>false
,p_fixed_row_height=>false
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>850
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(13990681856815603277)
,p_interactive_grid_id=>wwv_flow_imp.id(13990671931139543959)
,p_static_id=>'4799302'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(13990681964011603277)
,p_report_id=>wwv_flow_imp.id(13990681856815603277)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(5259074042771910543)
,p_view_id=>wwv_flow_imp.id(13990681964011603277)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(3168576918133816415)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>55
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(13510758323314381733)
,p_view_id=>wwv_flow_imp.id(13990681964011603277)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(13990987137269969756)
,p_is_visible=>false
,p_is_frozen=>false
,p_width=>68
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(13990682497612603278)
,p_view_id=>wwv_flow_imp.id(13990681964011603277)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(13990671963138543960)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(13990683445597603280)
,p_view_id=>wwv_flow_imp.id(13990681964011603277)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(13990672143588543961)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>147
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(13990684342876603283)
,p_view_id=>wwv_flow_imp.id(13990681964011603277)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(13990672172240543962)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>118
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(13990685249703603285)
,p_view_id=>wwv_flow_imp.id(13990681964011603277)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(13990672285789543963)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>244
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(13990686113473603288)
,p_view_id=>wwv_flow_imp.id(13990681964011603277)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(13990672412244543964)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(13990687046242603291)
,p_view_id=>wwv_flow_imp.id(13990681964011603277)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(13990672484109543965)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>255
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(13990687951848603293)
,p_view_id=>wwv_flow_imp.id(13990681964011603277)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(13990672594896543966)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>383
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(13990688825968603296)
,p_view_id=>wwv_flow_imp.id(13990681964011603277)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(13990672741530544067)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>102
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(13990689658413603298)
,p_view_id=>wwv_flow_imp.id(13990681964011603277)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(13990672771009544068)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>305
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(13990691494792603303)
,p_view_id=>wwv_flow_imp.id(13990681964011603277)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(13990672990403544070)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>142
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(13990692363946603305)
,p_view_id=>wwv_flow_imp.id(13990681964011603277)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(13990673140367544071)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>106
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(13990693350385603308)
,p_view_id=>wwv_flow_imp.id(13990681964011603277)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(13990673249949544072)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>109
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(13990694222898603311)
,p_view_id=>wwv_flow_imp.id(13990681964011603277)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(13990673327577544073)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>89
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(14005274017915177896)
,p_view_id=>wwv_flow_imp.id(13990681964011603277)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(14005068794853420861)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>104
,p_sort_order=>1
,p_sort_direction=>'DESC'
,p_sort_nulls=>'FIRST'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1021152352168644692)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8365875368866113090)
,p_button_name=>'BACK'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:425:&SESSION.::&DEBUG.:425::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1021151936555644691)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(8365875368866113090)
,p_button_name=>'SEND_MAIL'
,p_button_static_id=>'b_sendmail'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erinnerung Versenden'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-send-o'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1021151531140644680)
,p_name=>'P420_KONTROLLE_GRUPPE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8365875368866113090)
,p_prompt=>'Kontrollgruppe'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select gruppe_name, rev_kontrolle_gruppe_id',
'from t_rev_kontrolle_gruppe',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('- ausw\00E4hlen -')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1021143393054644640)
,p_name=>'P420_SELECTED_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1021143013735644639)
,p_name=>'P420_CONFIRM_ID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1021142177959644634)
,p_name=>'Refresh Regulierungs region'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(14396961581515623318)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1021141681094644630)
,p_event_id=>wwv_flow_imp.id(1021142177959644634)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(14396961581515623318)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1021141225104644630)
,p_name=>'Change'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(14396961581515623318)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1021140727745644630)
,p_event_id=>wwv_flow_imp.id(1021141225104644630)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i, selectedIds = "",',
'model = this.data.model;',
'for ( i = 0; i < this.data.selectedRecords.length; i++ ) {',
'    selectedIds += model.getValue( this.data.selectedRecords[i], "REV_KONTROLLE_ID") + ":";',
'}',
'$s("P420_SELECTED_ID", selectedIds);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1021140394716644629)
,p_name=>'Refresh'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P420_KONTROLLE_GRUPPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1021139825903644629)
,p_event_id=>wwv_flow_imp.id(1021140394716644629)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(14396961581515623318)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1021139455914644629)
,p_name=>'Send REV Email Confirm Message'
,p_event_sequence=>60
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.confirm_rev_changes'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#RVIR'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1021139006840644629)
,p_event_id=>wwv_flow_imp.id(1021139455914644629)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Email wird an den REV gesendet.'
,p_attribute_02=>'Email senden?'
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-question'
,p_attribute_06=>'Ja'
,p_attribute_07=>'Nein'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1021138478795644629)
,p_event_id=>wwv_flow_imp.id(1021139455914644629)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log($(this.triggeringElement).data("id"));',
'var id = $(this.triggeringElement).data("id");',
'$s(''P420_CONFIRM_ID'',id);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1021137971048644628)
,p_event_id=>wwv_flow_imp.id(1021139455914644629)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'pck_rev.pSendRevMail(:P420_CONFIRM_ID);'
,p_attribute_02=>'P420_CONFIRM_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1021137508590644628)
,p_event_id=>wwv_flow_imp.id(1021139455914644629)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var model = apex.region("RVIR").widget().interactiveGrid("getViews").grid.model;',
'var recordArray = [];',
'var record = model.getRecord($v(''P420_CONFIRM_ID''));',
'recordArray.push(record);',
'model.fetchRecords(recordArray);',
'',
'// apex.message.clearErrors();',
'apex.message.showPageSuccess("E-Mail erfolgreich gesendet");',
'',
'// apex.region("RVIR").refresh();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1021136931253644628)
,p_event_id=>wwv_flow_imp.id(1021139455914644629)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(14396961581515623318)
,p_attribute_01=>'N'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1021136605143644628)
,p_name=>'Selektion'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P420_SELECTED_ID'
,p_condition_element=>'P420_SELECTED_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1021136032714644628)
,p_event_id=>wwv_flow_imp.id(1021136605143644628)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(1021151936555644691)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1021135606185644627)
,p_event_id=>wwv_flow_imp.id(1021136605143644628)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(1021151936555644691)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1021135148657644627)
,p_name=>'Confirm'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1021151936555644691)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1021134704048644627)
,p_event_id=>wwv_flow_imp.id(1021135148657644627)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('M\00F6chten Sie eine Erinnerungs-Mail an die markierten Anwender senden?')
,p_attribute_03=>'warning'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1021134126615644627)
,p_event_id=>wwv_flow_imp.id(1021135148657644627)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'SEND_MAIL'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1021142546872644637)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Send_Mail'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    for x in (',
'        select rev_kontrolle_id',
'        from t_rev_kontrolle',
'        where status in (10,20)',
'        and rev_kontrolle_id in (select column_value from apex_string.split(:P420_SELECTED_ID,'':''))',
'    ) loop',
'        pck_rev.pSendRevMail(x.rev_kontrolle_id);',
'    end loop;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SEND_MAIL'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>2651069769026743598
);
wwv_flow_imp.component_end;
end;
/
