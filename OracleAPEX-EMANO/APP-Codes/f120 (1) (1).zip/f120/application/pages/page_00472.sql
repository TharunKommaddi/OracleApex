prompt --application/pages/page_00472
begin
--   Manifest
--     PAGE: 00472
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>472
,p_name=>'Select FUKA zum Kopieren'
,p_alias=>'SELECT-FUKA-ZUM-KOPIEREN'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Auswahl Funktionen vom Vorg\00E4nger')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Click auf Checkbox in Tabellenheader: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'$(''#report-funktionen'').on(''click'', ''th input'', function() {',
'    var check_all = $("#report-funktionen").find("th input:checked").is(":checked");',
'',
'    $("#report-funktionen").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'    setSelectedFunktionen();',
'});',
'',
'/* Click auf Checkbox in Tabellenzeile: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'',
'$(''#report-funktionen'').on(''click'', ''td input'', function() {',
'    setSelectedFunktionen();',
'});',
'',
'function setSelectedFunktionen() {',
'    var sel_rows = $("#P472_SELECTED_FUNCTIONS");',
'    sel_rows.val("");',
'    $("#report-funktionen").find("td input:checked").each(function() {',
'      // alert(this.value);',
'      if(sel_rows !=null && sel_rows.val() !=null && sel_rows.val().length > 0) {',
'        sel_rows.val(sel_rows.val() + ":");    ',
'      }',
'      sel_rows.val(sel_rows.val() + this.value);',
'    });',
'    //alert(sel_rows.val());',
'}',
'            ',
''))
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'400'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(988446375873471080)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(988451613722471139)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(988446263350471080)
,p_plug_name=>unistr('Auswahl Funktionen vom Vorg\00E4nger')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(990120132625731690)
,p_name=>'Funktionen'
,p_region_name=>'report-funktionen'
,p_parent_plug_id=>wwv_flow_imp.id(988446263350471080)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select --vrf.funktionid ,',
'    case when fu.status =''veraltet'' then',
'              ''<span style="color:darkred;">'' ||fu.bezeichnung || ''</span>''',
'         when fu.status =''in Bearbeitung'' then',
'             ''<span style="color:darkorange;">'' ||fu.bezeichnung || ''</span>''',
'         else fu.bezeichnung    end "BEZEICHNUNG", fu.objekttyp,',
'           fu.id_aus_excel, fu.beschreibung, --  fu.parentid, ',
'           fu.status,',
'    APEX_ITEM.CHECKBOX(1, vrf.vorschrift_ref_funktionid, null, :P472_SELECTED_FUNCTIONS,'':'') as checkbox,',
'    vrf.letzte_aenderung_datum',
'  from t_vorschrift_ref_funktion vrf',
'  join  t_funktion fu on (fu.funktionid = vrf.funktionid)',
'  where vrf.GELOESCHT !=1 and vorschriftid = :P470_SRC_VORSCHRIFTID_S',
'  order by fu.bezeichnung'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P472_SRS_FUNCTIONS,P472_SELECTED_FUNCTIONS'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(990119801825731687)
,p_query_column_id=>1
,p_column_alias=>'BEZEICHNUNG'
,p_column_display_sequence=>30
,p_column_heading=>'Bezeichnung'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(990119241899731682)
,p_query_column_id=>2
,p_column_alias=>'OBJEKTTYP'
,p_column_display_sequence=>60
,p_column_heading=>'Objekttyp'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(990119151016731681)
,p_query_column_id=>3
,p_column_alias=>'ID_AUS_EXCEL'
,p_column_display_sequence=>40
,p_column_heading=>'Id Funktion 42'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(929251418471458759)
,p_query_column_id=>4
,p_column_alias=>'BESCHREIBUNG'
,p_column_display_sequence=>50
,p_column_heading=>'Beschreibung'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(990119551029731685)
,p_query_column_id=>5
,p_column_alias=>'STATUS'
,p_column_display_sequence=>70
,p_column_heading=>'Status'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(990119495440731684)
,p_query_column_id=>6
,p_column_alias=>'CHECKBOX'
,p_column_display_sequence=>10
,p_column_heading=>'<input type="checkbox" />'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(990119063004731680)
,p_query_column_id=>7
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>80
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(988446155200471080)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(988444735472471078)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(988446155200471080)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(988444342417471078)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(988446155200471080)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Zum Kopieren'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(988444483377471078)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(988446155200471080)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Zum Quellvorschrift Auswahl'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(988442776522471077)
,p_branch_name=>'Go To Page 470'
,p_branch_action=>'f?p=&APP_ID.:470:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(988444483377471078)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(988442055035471076)
,p_branch_name=>'Go To Page 474'
,p_branch_action=>'f?p=&APP_ID.:474:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(988444342417471078)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(990120138444731691)
,p_name=>'P472_SELECTED_FUNCTIONS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(988446263350471080)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(990119362198731683)
,p_name=>'P472_SRS_FUNCTIONS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(988446263350471080)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(988444239580471077)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(988444735472471078)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(988443530830471077)
,p_event_id=>wwv_flow_imp.id(988444239580471077)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(990118994035731679)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'collect_selected_Funktionen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P472_SELECTED_FUNCTIONS := null;',
'FOR i IN 1..APEX_APPLICATION.G_F01.COUNT LOOP ',
'   -- debug('' P472: element ''||I||'' has a value of ''||APEX_APPLICATION.G_F01(i)); ',
'    :P472_SELECTED_FUNCTIONS := :P472_SELECTED_FUNCTIONS || APEX_APPLICATION.G_F01(i) || '':'';',
'END LOOP;',
'',
unistr('--debug(''quellvorschrift: gew\00E4hlte Funktionen:'', :P472_SELECTED_FUNCTIONS);')))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2682093321863656556
);
wwv_flow_imp.component_end;
end;
/
