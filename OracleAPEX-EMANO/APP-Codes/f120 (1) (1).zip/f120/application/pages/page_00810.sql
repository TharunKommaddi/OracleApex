prompt --application/pages/page_00810
begin
--   Manifest
--     PAGE: 00810
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>810
,p_name=>'Vorschriften Report Demand'
,p_alias=>'VORSCHRIFTEN-REPORT-DEMAND'
,p_step_title=>'Vorschriften Report Demand'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1805297351244458330)
,p_plug_name=>'Vorschriften Report Demand'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'"VORSCHRIFT_NUMMER", ',
'    "PERMALINK", ',
'    "VORSCHRIFTID",',
'    "DEMANDED_VORSCHRIFT", ',
'    "PERMALINK_DEMANDED", ',
'    "VORSCHRIFTID_DEMANDED",',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN "vorschrift_typ_german" ',
'        ELSE "vorschrift_typ_english" ',
'    END AS vorschrift_typ,',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN "DEMANDED_TYP_german" ',
'        ELSE "demanded_typ_english"',
'    END AS demanded_typ',
'    from V_VORSCHRIFT_DEMANDS'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_page_header=>'Vorschriften Report Demand'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1805297432993458330)
,p_name=>'Vorschriften Report Demand'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>2917990370088592734
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571955797834220300)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Vorschrift Nummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571955362369220299)
,p_db_column_name=>'PERMALINK'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Permalink'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571955005983220299)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_column_linktext=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571954200929220299)
,p_db_column_name=>'DEMANDED_VORSCHRIFT'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Demanded Vorschrift'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571953800024220299)
,p_db_column_name=>'PERMALINK_DEMANDED'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Permalink Demanded'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(571953376810220299)
,p_db_column_name=>'VORSCHRIFTID_DEMANDED'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::P25_VORSCHRIFTID:#VORSCHRIFTID_DEMANDED#'
,p_column_linktext=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(907588995937692582)
,p_db_column_name=>'VORSCHRIFT_TYP'
,p_display_order=>17
,p_column_identifier=>'S'
,p_column_label=>'Vorschrift Typ'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(907588881728692581)
,p_db_column_name=>'DEMANDED_TYP'
,p_display_order=>27
,p_column_identifier=>'T'
,p_column_label=>'Demanded Typ'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1805316724206508356)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5407403'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'VORSCHRIFTID:VORSCHRIFT_NUMMER:PERMALINK:VORSCHRIFT_TYP:VORSCHRIFTID_DEMANDED:DEMANDED_VORSCHRIFT:PERMALINK_DEMANDED:DEMANDED_TYP:'
);
wwv_flow_imp.component_end;
end;
/
