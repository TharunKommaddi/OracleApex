prompt --application/pages/page_00581
begin
--   Manifest
--     PAGE: 00581
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>581
,p_name=>unistr('Vorg\00E4nger MfV')
,p_alias=>unistr('VORG\00C4NGER-MFV')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Vorg\00E4nger MfV')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_dialog_width=>'1000'
,p_dialog_chained=>'N'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15255651403151532378)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(637561291400734979)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15255651509683532378)
,p_plug_name=>'Mfv Typ'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15255651644722532378)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1006073351085103319)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(15255651644722532378)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1006072947303103317)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(15255651644722532378)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'COCOA-Ticket'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1006067491283103289)
,p_branch_name=>'Go To Page 582'
,p_branch_action=>'f?p=&APP_ID.:582:&SESSION.::&DEBUG.:574,571,570,582::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1006072947303103317)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006072568398103309)
,p_name=>'P581_AUSWAHL'
,p_item_sequence=>20
,p_prompt=>unistr('M\00F6chten Sie Einstellungen aus einer Vorg\00E4nger MfV \00FCbertragen?')
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Nein',
  'off_value', '0',
  'on_label', 'Ja',
  'on_value', '10',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006072197760103306)
,p_name=>'P581_MFVS'
,p_item_sequence=>40
,p_prompt=>'MfVs'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select MFV_NAME || '' '' || listagg( tmt.bezeichnung, '', '') within group (order by tmt.teil) ||  '' '' ||tm.jira_ticket as d, tm.mfvid',
'',
'',
'',
'from t_mfv_ref_vorschrift mrv',
'join t_mfv tm on (mrv.mfvid = tm.mfvid)',
'left outer join t_mfv_ref_mfv_teil tmrt on (tm.mfvid = tmrt.mfvid )',
'left outer join t_mfv_teil tmt on (tmrt.MFV_TEILID = tmt.MFV_TEILID)',
'where vorschriftid = :P25_VORSCHRIFTID and tm.jira_status != 20 ',
'and tm.DMS_DOKUMENTENSTATUS != 30',
'group by MFV_NAME,tm.jira_ticket,tm.mfvid'))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(916344027054945420)
,p_name=>'P581_IS_CLONE'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(916343985453945419)
,p_name=>'P581_CLONE_MODE'
,p_item_sequence=>60
,p_item_default=>'0'
,p_prompt=>unistr('M\00F6chten Sie ein bestehendes Ticket klonen?')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT ',
'        emano_util.fLang(''Nein, neues Ticket'', ''No, new ticket'') AS display_value,',
'        ''0'' AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'    ',
'    UNION ALL',
'    ',
'    SELECT ',
'        emano_util.fLang(''Ja, Ticket klonen'', ''Yes, clone ticket'') AS display_value,',
'        ''1'' AS return_value,',
'        2 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order',
''))
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(916343865793945418)
,p_name=>'P581_CLONE_SOURCE_TICKET'
,p_item_sequence=>70
,p_prompt=>unistr('TVRB-Ticket zum Klonen ausw\00E4hlen')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    tm.jira_ticket || '' - '' || tm.mfv_name || '' ('' || ',
'    LISTAGG(tmt.bezeichnung, '', '') WITHIN GROUP (ORDER BY tmt.teil) || '')'' AS display_value,',
'    tm.jira_ticket AS return_value',
'FROM t_mfv_ref_vorschrift mrv',
'JOIN t_mfv tm ON (mrv.mfvid = tm.mfvid)',
'LEFT OUTER JOIN t_mfv_ref_mfv_teil tmrt ON (tm.mfvid = tmrt.mfvid)',
'LEFT OUTER JOIN t_mfv_teil tmt ON (tmrt.mfv_teilid = tmt.mfv_teilid)',
'WHERE mrv.vorschriftid = :P25_VORSCHRIFTID',
'  AND tm.jira_ticket IS NOT NULL',
'  AND tm.jira_status != 20  -- Not closed',
'  AND tm.dms_dokumentenstatus != 30  -- Not archived',
'  AND tm.jira_ticket NOT LIKE ''%TASK%''  -- No task tickets',
'GROUP BY tm.jira_ticket, tm.mfv_name, tm.mfvid',
'ORDER BY tm.jira_ticket DESC'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(914715562862462732)
,p_validation_name=>'Warn if cloning from a clone'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'DECLARE',
'    v_is_source_cloned NUMBER := 0;',
'BEGIN',
'    -- Check if the selected source ticket is itself a clone',
'    SELECT COUNT(*)',
'    INTO v_is_source_cloned',
'    FROM t_jira_post',
'    WHERE SOURCE_TVRB_TICKET = :P581_CLONE_SOURCE_TICKET',
'      AND IS_CLONE = 1',
'      AND ROWNUM = 1;',
'    ',
'    IF v_is_source_cloned > 0 THEN',
'        RETURN FALSE; -- Validation fails, show message',
'    END IF;',
'    ',
'    RETURN TRUE; -- Validation passes',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Warnung: Das ausgew\00E4hlte Ticket ist selbst ein Klon. '),
unistr('Es wird empfohlen, das urspr\00FCngliche Ticket zu klonen, '),
'um Datenverlust zu vermeiden.'))
,p_validation_condition_type=>'NEVER'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1006071801441103300)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1006073351085103319)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006071224559103294)
,p_event_id=>wwv_flow_imp.id(1006071801441103300)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1006070849788103293)
,p_name=>'Change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P581_AUSWAHL'
,p_condition_element=>'P581_AUSWAHL'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'10'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006070405617103293)
,p_event_id=>wwv_flow_imp.id(1006070849788103293)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P581_MFVS'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$s(''P581_MFVS'',null)'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006069895522103292)
,p_event_id=>wwv_flow_imp.id(1006070849788103293)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P581_MFVS'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$s(''P581_MFVS'',null)'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006069405360103292)
,p_event_id=>wwv_flow_imp.id(1006070849788103293)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P581_MFVS'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006068862773103292)
,p_event_id=>wwv_flow_imp.id(1006070849788103293)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P581_MFVS'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1006068450939103291)
,p_name=>'New'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P581_MFVS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006067929215103291)
,p_event_id=>wwv_flow_imp.id(1006068450939103291)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P571_AK_SEL := null;'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(916343435559945414)
,p_name=>'When Clone Mode Changes'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P581_CLONE_MODE'
,p_condition_element=>'P581_CLONE_MODE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(916343374445945413)
,p_event_id=>wwv_flow_imp.id(916343435559945414)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v(''P581_CLONE_MODE'') === ''0'') {',
'    $s(''P581_CLONE_SOURCE_TICKET'', '''');',
'    $s(''P581_IS_CLONE'', ''0'');',
'} else {',
'    $s(''P581_IS_CLONE'', ''1'');',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(916343039135945410)
,p_event_id=>wwv_flow_imp.id(916343435559945414)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P581_CLONE_SOURCE_TICKET'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P581_CLONE_MODE'
,p_client_condition_expression=>'0'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(916343279084945412)
,p_event_id=>wwv_flow_imp.id(916343435559945414)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P581_CLONE_SOURCE_TICKET'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P581_CLONE_MODE'
,p_client_condition_expression=>'1'
);
wwv_flow_imp.component_end;
end;
/
