prompt --application/pages/page_00210
begin
--   Manifest
--     PAGE: 00210
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>210
,p_name=>'Cockpit Einstellungen laden/verwalten'
,p_alias=>'COCKPIT-EINSTELLUNGEN-LADEN1'
,p_page_mode=>'MODAL'
,p_step_title=>'Cockpit Einstellungen laden/verwalten'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function fSetStartProfile(elem) {',
'    console.log(elem.value);',
'    $s(''P210_SET_STARTPROFILE'',elem.value);',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(654722248135906426)
,p_name=>'Cockpit Einstellungen laden/verwalten'
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select COCKPIT_PROFILEID,',
'       BENUTZERID,',
'       BEZEICHNUNG,',
'--       DATEN,',
'       JSON_VALUE(p.DATEN, ''$.laender'') as LAENDER,',
'      -- JSON_VALUE(p.DATEN, ''$.themen'') as THEMEN,',
'       ( select listagg(x.column_value, '':'') within group (order by x.column_value) ',
'            from table (apex_string.split_numbers( JSON_VALUE(p.DATEN, ''$.themen''), '':'') ) x ',
'           where x.column_value not in (select themaid from T_thema_ref_et_b_AK  where et_b_AKid =1036) ) as THEMEN,',
'       JSON_VALUE(p.DATEN, ''$.highlight_datum'') as highlight_datum,',
'       ( select listagg(x2.column_value, '':'') within group (order by x2.column_value) ',
'            from table (apex_string.split_numbers( JSON_VALUE(p.DATEN, ''$.themen''), '':'') ) x2 ',
'           where x2.column_value in (select themaid from T_thema_ref_et_b_AK  where et_b_AKid =1036) ) as QUER_THEMEN,',
'       apex_item.radiogroup(1,cockpit_profileid,',
'                            case when startprofile = 1 then cockpit_profileid else null end,',
'                            p_onchange => ''$s(''''P210_SET_STARTPROFILE'''',this.value)'')',
'        as radio_startprofile',
'from T_COCKPIT_PROFILE p',
'where BENUTZERID = :G_BENUTZERID;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Es wurden noch keine Einstellungen hinterlegt.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(883703140071003852)
,p_query_column_id=>1
,p_column_alias=>'COCKPIT_PROFILEID'
,p_column_display_sequence=>2
,p_default_sort_column_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(883702809287003850)
,p_query_column_id=>2
,p_column_alias=>'BENUTZERID'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(883702387053003850)
,p_query_column_id=>3
,p_column_alias=>'BEZEICHNUNG'
,p_column_display_sequence=>5
,p_column_heading=>'Name der Filter&shy;einstellung'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(882914453152911186)
,p_query_column_id=>4
,p_column_alias=>'LAENDER'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(882914396542911185)
,p_query_column_id=>5
,p_column_alias=>'THEMEN'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(806711911845495187)
,p_query_column_id=>6
,p_column_alias=>'HIGHLIGHT_DATUM'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(875245519153362302)
,p_query_column_id=>7
,p_column_alias=>'QUER_THEMEN'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(885807440662768085)
,p_query_column_id=>8
,p_column_alias=>'DERIVED$03'
,p_column_display_sequence=>6
,p_column_heading=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:215:&SESSION.:DELETE:&DEBUG.::P215_COCKPIT_PROFILEID:#COCKPIT_PROFILEID#'
,p_column_linktext=>unistr('<span class="fa fa-trash-o" aria-hidden="true" title="Cockpit-Einstellung l\00F6schen"></span>')
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41968309039100227)
,p_query_column_id=>8
,p_column_alias=>'RADIO_STARTPROFILE'
,p_column_display_sequence=>7
,p_column_heading=>'Startprofil'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(885807725238768087)
,p_query_column_id=>9
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>1
,p_column_heading=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.::P202_FILTER_BLAND,P202_FILTER_THEMEN,P202_HIGHLIGHT_DATUM_AENDERUNG,P202_QUERSCHNITT_THEMEN_CB:\#LAENDER#\,\#THEMEN#\,#HIGHLIGHT_DATUM#,\#QUER_THEMEN#\'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-share-square-o" title="Cockpit-Einstellung laden"></span>'
,p_column_alignment=>'CENTER'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(885807565154768086)
,p_query_column_id=>10
,p_column_alias=>'DERIVED$02'
,p_column_display_sequence=>4
,p_column_heading=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:215:&SESSION.::&DEBUG.:215:P215_BENUTZERID,P215_COCKPIT_PROFILEID:#BENUTZERID#,#COCKPIT_PROFILEID#'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-pencil" title="Cockpit-Einstellung bearbeiten"></span>'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(882915092221911192)
,p_name=>'P210_COCKPIT_URL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(654722248135906426)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41968569132100230)
,p_name=>'P210_SET_STARTPROFILE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(654722248135906426)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(885805460216768065)
,p_name=>'Edit Dialog closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(654722248135906426)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(885805342966768064)
,p_event_id=>wwv_flow_imp.id(885805460216768065)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(654722248135906426)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41968738603100231)
,p_name=>'change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P210_SET_STARTPROFILE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41968843696100232)
,p_event_id=>wwv_flow_imp.id(41968738603100231)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_cockpit_profile',
'set startprofile = case when cockpit_profileid = :P210_SET_STARTPROFILE then 1 else 0 end',
'where benutzerid = :G_BENUTZERID;'))
,p_attribute_02=>'P210_SET_STARTPROFILE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(885804634774768056)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2786407681124620179
);
wwv_flow_imp.component_end;
end;
/
