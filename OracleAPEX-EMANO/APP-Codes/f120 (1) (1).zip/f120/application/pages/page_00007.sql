prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Vorschrift'
,p_alias=>'VORSCHRIFT1'
,p_step_title=>'Vorschrift'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.align-colon:before {',
'    content: '''';',
'    display: inline-block;',
'    width: 1px;',
'}',
'ul {',
'    list-style-type: disc;',
'}',
'li b {',
'    display: inline-block;',
'    width: 180px;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(773104554588966615)
,p_plug_name=>'vorschrift'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       VORSCHRIFTID,',
'       VORSCHRIFT_NUMMER,',
'       VORSCHRIFT_BEZEICHNUNG',
'       /*',
'       PROGNOSE_QUALITAET,',
'       JIRA_TICKET,',
'       VORSCHRIFT_FREIGABESTATUSID,',
'       BEMERKUNG,',
'       LINK_ZUR_VORSCHRIFT_DMS,',
'       LINK_ZUR_VORSCHRIFT_GETEX,',
'       TYPSCHILD,',
'       LETZTE_AENDERUNG_DATUM,',
'       LETZTE_AENDERUNG_BENUTZERID,',
'       WEBSITEID,',
'       WEBSITELINK,',
'       EINSATZDATUM_MODELLID,',
'       VORSCHRIFT_TYPID,',
'       NORMID,',
'       HOMOLOGATION_MOEGLICH,',
'       KSUID,',
'       VORSCHRIFT_STATUSID,',
'       HOMOLOGATIONSRELEVANT,',
'       RXSWIN,',
'       VORSCHRIFT_BEZEICHNUNG_ENG,',
'       DEKRA_DATENSATZID,',
'       COP_RELEVANT,',
'       ERSTELLUNG_DATUM,',
'       TECHNOLOGIE,',
'       WITHOUT_NORM_VALIDATION,',
'       LINK_REQMAN,',
'       INHALTLICH_SACHLICH_GEPRUEFT,',
'       SWR_HAUPTUMSETZENDE_OE,',
'       PROGNOSE_QUALITAETID,',
'       MJ_SCHALTER_STATUS,',
'       LEAD_VKO_BENUTZERID,',
'       PHASEIN_ENTHALTEN,',
'       REVISIONSZAEHLER,',
'       VORSCHRIFT_BEZEICHNUNG_DEUTSCH,',
'       BEMERKUNG_ENGLISCH,',
'       PUBLISHER,',
'       DOCUMENT_TYPE,',
'       REGINDEXID,',
'       DOKUMENTENDATUM,',
'       DOCUMENT_TYPEID,',
'       STATUS_UPDATE_GETEX,',
'       MASTER,',
'       LETZTE_AENDERUNG_GETEX_ATTR',
'       */',
'  from T_VORSCHRIFT_SYNTHETIC'))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_required_role=>wwv_flow_imp.id(769823299513670358)
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from user_indexes',
'where index_name=''RI_VORSCHRIFT_TEXT_FTX'''))
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'vorschrift'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(771971062567128066)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Id'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>10
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(771970963455128065)
,p_name=>'VORSCHRIFTID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFTID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Vorschriftid'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>20
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(771970924255128064)
,p_name=>'VORSCHRIFT_NUMMER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFT_NUMMER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Vorschrift Nummer'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>255
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(771970813548128063)
,p_name=>'VORSCHRIFT_BEZEICHNUNG'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFT_BEZEICHNUNG'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Vorschrift Bezeichnung'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>255
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(771971207528128067)
,p_internal_uid=>340721729567006337
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_oracle_text_index_column=>'VORSCHRIFT_NUMMER'
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(769803531557458473)
,p_interactive_grid_id=>wwv_flow_imp.id(771971207528128067)
,p_static_id=>'3428895'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(769803333010458472)
,p_report_id=>wwv_flow_imp.id(769803531557458473)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(769802745660458467)
,p_view_id=>wwv_flow_imp.id(769803333010458472)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(771971062567128066)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(769801907020458459)
,p_view_id=>wwv_flow_imp.id(769803333010458472)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(771970963455128065)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(769800958286458456)
,p_view_id=>wwv_flow_imp.id(769803333010458472)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(771970924255128064)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(769800053476458454)
,p_view_id=>wwv_flow_imp.id(769803333010458472)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(771970813548128063)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(771970690767128062)
,p_plug_name=>'Overview: Oracle Text'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page shows how Oracle Text can be used within an Interactive Report to perform full-text search using linguistic features.</p>',
'<p>In this example, Oracle Text features are available to search the <b>VORSCHRIFT_NUMMER</b> and <b>VORSCHRIFT_BEZEICHNUNG_DEUTSCH</b> columns with the Interactive Report.</p>',
'<p>Few Test Cases which will work using Oracle Text</p>',
'<ul>',
'    <li><b>Thms</b><span class="align-colon">:</span> VORSCHRIFT_NUMMER - <strong>Tschernich Thomas</strong></li>',
'    <li><b>Domnk</b><span class="align-colon">:</span> VORSCHRIFT_NUMMER - <strong>Braunbeck Dominik</strong></li>',
'    <li><b>UN R</b><span class="align-colon">:</span> VORSCHRIFT_NUMMER -  <strong>UN-R</strong></li>',
'    <li><b>GB T</b><span class="align-colon">:</span> VORSCHRIFT_NUMMER -  <strong>GB/T and other records which match this</strong></li>',
'    <li><b>UN R 119 01 Suplmnt 2</b><span class="align-colon">:</span> VORSCHRIFT_NUMMER - <strong> UN-R 119/01 Supplement 2</strong></li>',
'    <li><b>119 00</b><span class="align-colon">:</span> VORSCHRIFT_NUMMER - <strong> UN-R 119/00 Supplement 4 and other records which match this</strong></li>',
unistr('    <li><b>GB Bremsbel\00E4ge</b><span class="align-colon">:</span> VORSCHRIFT_NUMMER - <strong>GB 5763-2008</strong> ; VORSCHRIFT_BEZEICHNUNG_DEUTSCH - <strong>Bremsbel\00E4ge f\00FCr Automobile</strong></li>'),
unistr('    <li><b>Brsbel\00E4ge</b><span class="align-colon">:</span> VORSCHRIFT_BEZEICHNUNG_DEUTSCH - <strong>Bremsbel\00E4ge f\00FCr Automobile</strong></li>'),
'    <li><b>Kommaddi -Tharun</b><span class="align-colon">:</span> VORSCHRIFT_NUMMER - <strong>Kommaddi is a software developer</strong> &nbsp;&nbsp;&nbsp; <i> Minus - not working </i> </li>',
'    <li><b>"Kommaddi Tharun"</b><span class="align-colon">:</span> VORSCHRIFT_NUMMER - <strong>Kommaddi Tharun</strong> &nbsp;&nbsp;&nbsp; <i> Exact Phrase - not working </i> </li>',
'    <li><b>"Kommaddi Tarun"</b><span class="align-colon">:</span> VORSCHRIFT_NUMMER - <strong>No Record Found</strong> &nbsp;&nbsp;&nbsp; <i> Exact Phrase - not working </i> </li>',
'</ul>'))
,p_plug_required_role=>wwv_flow_imp.id(769823299513670358)
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from user_indexes',
'where index_name=''RI_VORSCHRIFT_TEXT_FTX'''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(771970453538128060)
,p_plug_name=>'Oracle Text is not available'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Oracle Text is not available in this workspace. Contact the database administrator to get the <strong>CTXAPP</strong> role granted using the following SQL statement.</p>',
'<pre><strong>GRANT CTXAPP TO #OWNER#;</strong></pre>'))
,p_plug_required_role=>'!'||wwv_flow_imp.id(769823299513670358)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(771970361590128059)
,p_plug_name=>'Oracle Text Index does not exist'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<p>Oracle Text is available in this workspace.</p>'
,p_plug_required_role=>wwv_flow_imp.id(769823299513670358)
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from user_indexes',
'where index_name=''RI_VORSCHRIFT_TEXT_FTX'''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(771970334889128058)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(771970361590128059)
,p_button_name=>'CREATE_TEXT_INDEX'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Oracle Text index'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'Y'
,p_security_scheme=>wwv_flow_imp.id(769823299513670358)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(771971239347128068)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create Oracle Text Index'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    pck_ri_vorschrift_oracle_text_pkg.drop_text_preferences;',
'    pck_ri_vorschrift_oracle_text_pkg.create_text_preferences;',
'    pck_ri_vorschrift_oracle_text_pkg.create_text_index;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_security_scheme=>wwv_flow_imp.id(769823299513670358)
,p_internal_uid=>2900241076552260167
);
wwv_flow_imp.component_end;
end;
/
