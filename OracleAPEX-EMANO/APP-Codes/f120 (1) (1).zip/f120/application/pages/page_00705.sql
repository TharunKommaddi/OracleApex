prompt --application/pages/page_00705
begin
--   Manifest
--     PAGE: 00705
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>705
,p_name=>unistr('Parameter bearbeiten / hinzuf\00FCgen')
,p_alias=>unistr('PARAMETER-BEARBEITEN-HINZUF\00DCGEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Parameter bearbeiten / hinzuf\00FCgen')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Sticky Header',
'$(document).ready(function() {',
'    setTimeout(function() {',
'        var $legend = $(''.legend-container'');',
'        ',
'        var $dialogHeader = $(''.t-Dialog-header'');',
'        ',
'        if ($legend.length && $dialogHeader.length) {',
'            ',
'            $legend.css({',
'                ''margin'': ''0'',',
'                ''width'': ''100%'',',
'                ''border-radius'': ''0'',',
'                ''border-left'': ''none'',',
'                ''border-right'': ''none'',',
'                ''border-top'': ''none''',
'            });',
'          ',
'            $dialogHeader.append($legend);',
'        }',
'    }, 100);',
'});',
'',
'',
'// Navigate to the Clicked Region area + Highlight',
'$(document).ready(function() {',
'    setTimeout(function() {',
'        $(''.legend-item:has(.color-ordnung)'').css(''cursor'', ''pointer'').click(function() {',
'            scrollAndHighlight(''.region-ordnung'');',
'        });',
'        ',
'        $(''.legend-item:has(.color-stammdaten)'').css(''cursor'', ''pointer'').click(function() {',
'            scrollAndHighlight(''.region-stammdaten'');',
'        });',
'        ',
'        $(''.legend-item:has(.color-datum)'').css(''cursor'', ''pointer'').click(function() {',
'            if ($(''.region-datum'').is('':visible'')) {',
'                scrollAndHighlight(''.region-datum'');',
'            }',
'        });',
'        ',
'        $(''.legend-item:has(.color-modeljahr)'').css(''cursor'', ''pointer'').click(function() {',
'            if ($(''.region-modeljahr'').is('':visible'')) {',
'                scrollAndHighlight(''.region-modeljahr'');',
'            }',
'        });',
'        ',
'        $(''.legend-item:has(.color-output)'').css(''cursor'', ''pointer'').click(function() {',
'            scrollAndHighlight(''.region-output'');',
'        });',
'        ',
'        function scrollAndHighlight(selector) {',
'           ',
'            $(selector)[0].scrollIntoView();',
'          ',
'            var originalColor = $(selector).css(''background-color'');',
'',
'            $(selector).css(''background-color'', ''#FFFFC0'');',
'',
'            setTimeout(function() {',
'                $(selector).css(''background-color'', originalColor);',
'            }, 800);',
'        }',
'    }, 100);',
'});'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.col .rel-col {',
'    width: 40%;',
'    float: left;',
'',
'}',
'',
'',
'',
'',
' ',
'/***********************',
' * LEGEND MENU',
' ***********************/  ',
'',
'.region-ordnung {',
'    border-left: 5px solid #FF9933;',
'    background-color: #FFEDDF;',
'    padding: 10px;',
'    margin-bottom: 15px;',
'    border-radius: 4px;',
'}',
'',
'.region-ordnung .t-Region-header {',
'    background-color: #FF9933;;',
'    color: white;',
'    padding: 8px;',
'    border-radius: 4px 4px 0 0;',
'}',
'',
'',
'',
'.region-stammdaten {',
'    border-left: 5px solid #BB55DD;',
'    background-color: #F8EEFF;',
'    padding: 10px;',
'    margin-bottom: 15px;',
'    border-radius: 4px;',
'}',
'',
'.region-stammdaten .t-Region-header {',
'    background-color: #BB55DD;',
'    color: white;',
'    padding: 8px;',
'    border-radius: 4px 4px 0 0;',
'}',
'',
'',
'.region-datum {',
'    border-left: 5px solid #3399CC;',
'    background-color: #E6F7FF;',
'    padding: 10px;',
'    margin-bottom: 15px;',
'    border-radius: 4px;',
'}',
'',
'.region-datum .t-Region-header {',
'    background-color: #3399CC;',
'    color: white;',
'    padding: 8px;',
'    border-radius: 4px 4px 0 0;',
'}',
'',
'',
'.region-modeljahr {',
'    border-left: 5px solid #00B3A4;',
'    background-color: #E5F7F6;',
'    padding: 10px;',
'    margin-bottom: 15px;',
'    border-radius: 4px;',
'}',
'',
'.region-modeljahr .t-Region-header {',
'    background-color: #00B3A4;',
'    color: white;',
'    padding: 8px;',
'    border-radius: 4px 4px 0 0;',
'}',
'',
'',
'',
'.region-output {',
'    border-left: 5px solid #33CC33;',
'    background-color: #E6FFEA;',
'    padding: 10px;',
'    margin-bottom: 15px;',
'    border-radius: 4px;',
'}',
'',
'.region-output .t-Region-header {',
'    background-color: #33CC33;',
'    color: white;',
'    padding: 8px;',
'    border-radius: 4px 4px 0 0;',
'}',
'',
'',
'',
'.region-divider {',
'    border-top: 1px solid #ccc;',
'    margin: 20px 0;',
'}',
'',
'',
' ',
'',
'',
'',
'',
'/***********************',
' * LEGEND',
' ***********************/',
'',
'',
'/* Sticky Legend Header */',
'.t-Dialog-header {',
'    min-height: 50px;',
'    display: block !important;',
'    padding: 0 !important;',
'}',
'',
'',
'',
'',
'.legend-container {',
'    display: flex;',
'    align-items: center;',
'    padding: 8px 16px;',
'    background-color: #f9f9f9;',
'    border-radius: 4px;',
'    margin-bottom: 10px;',
'    margin-top: 8px;',
'} ',
'',
'',
'.legend-title {',
'    font-weight: bold;',
'    margin-right: 20px;',
'    white-space: nowrap;',
'}',
'',
'.legend-items {',
'    display: flex;',
'    flex-wrap: wrap;',
'    gap: 16px;',
'    align-items: center;',
'}',
'',
'.legend-item {',
'    display: flex;',
'    align-items: center;',
'}',
'',
'.legend-color {',
'    width: 16px;',
'    height: 16px;',
'    border-radius: 50%;',
'    margin-right: 8px;',
'    display: inline-block;',
'}',
'',
'.color-ordnung {',
'    background-color: #FF9933;',
'}',
'',
'.color-stammdaten {',
'    background-color: #BB55DD;',
'}',
'',
'.color-datum {',
'    background-color: #3399CC;',
'}',
'',
'',
'',
'',
'.color-modeljahr {',
'    background-color: #00B3A4;',
'}',
'',
'',
'.color-output {',
'    background-color: #33CC33;',
'}',
'',
'.t-Form-fieldContainer .legend-container {',
'    width: 100%;',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1300'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1958333006366490183)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1958405687271531832)
,p_plug_name=>unistr('Parameter bearbeiten / hinzuf\00FCgen')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>60
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    p.MS_PARAMETERID,',
'    p.NUMMER,',
'    p.BEMERKUNG,',
'    p.VERNETZUNGSART,',
'    p.FAHRZEUGZULASSUNG,',
'    p.FAHRZEUGKLASSE,',
'    p.THEMENGEBIET,',
'    p.LAND,',
'    p.DATUMSANGABEN_ORIGINAL_VERNETZUNG,',
'    p.VORSCHRIFTEN_TYP,',
'    p.FBU_CKD_RELEVANTES_LAND,',
'    p.PARAMETER_CKD_FBU_DATUM,',
'    p.QUELLVORSCHRIFT_GUELTIG,',
'    p.SOP_IST_VOR_DATUM_IN_KRAFT,',
'    p.SOP_GLEICH_ODER_NACH_DATUM_IN_KRAFT,',
'    p.SOP_IST_VOR_DATUM_NEUE_TYPEN,',
'    p.SOP_IST_NACH_ODER_GLEICH_DATUM_NEUE_TYPEN,',
'    p.SOP_IST_VOR_DATUM_ALLE_FAHRZEUGE,',
'    p.SOP_IST_NACH_ODER_GLECIH_DATUM_ALLE_FAHRZEUGE_,',
'    p.SOP_IST_VOR_DATUM_AUSSER_KRAFT,',
'    p.SOP_IST_NACH_ODER_GLEICH_DATUM_AUSSER_KRAFT,',
'    p.EOP_LIEGT_VOR_DATUM_ALLE_FAHRZEUGE,',
'    p.EOP_LIEGT_NACH_ODER_GLEICH_DATUM_ALLE_FAHRZEUGE,',
'    p.EOP_LIEGT_VOR_DATUM_IN_KRAFT,',
'    p.EOP_LIEGT_NACH_ODER_GLEICH_DATUM_IN_KRAFT,',
'    p.HOEHERE_SERIE_MOEGLICH,',
'    p.DECKELUNG_DER_HOEHEREN_SERIE,',
'    p.SOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS,',
'    p.SOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS,',
'    p.EOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS,',
'    p.EOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS,',
'    p.NACHFOLGER_ANZEIGEN,',
'    p.LESENDE_TABELLE_FUER_DATUMSANGABEN,',
'    p.AUSGABE_FUER_ANDERES_TOOL_ODER_FUER_MENSCH,',
'    p.VERNETZUNGSARTID,',
'    p.INTERNER_DB_STATUS,',
'    p.STATUS,',
'    p.PROGNOSE_QUALITAET,',
'    p.SEARCH_MODE,',
'    p.PARAMETER_MJ_DATUMSFORMAT,',
'    p.MJ_EINSATZ_JAHR_KLEINER_PHASEIN_START_JAHR,',
'    p.MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_START_JAHR,',
'    p.MJ_EINSATZ_JAHR_KLEINER_PHASEIN_ENDE_JAHR,',
'    p.MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_ENDE_JAHR,',
'    p.MJ_EINSATZ_JAHR_KLEINER_GLEICH_AUSSER_KRAFT_JAHR,',
'    p.MJ_EINSATZ_JAHR_GROESSER_AUSSER_KRAFT_JAHR,',
'    p.SUPPLEMENT,',
'    p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE,',
'    p.MJ_SOP_VOR_PHASEIN_START_OR_PHASEIN_LEER,',
'    p.MJ_SOP_NACH_PHASEIN_START,',
'    p.MJ_SOP_VOR_PHASEIN_END_OR_PHASEIN_LEER,',
'    p.MJ_SOP_NACH_PHASEIN_END,',
'    p.MJ_EOP_VOR_PHASEIN_START_OR_PHASEIN_LEER,',
'    p.MJ_EOP_NACH_PHASEIN_START,',
'    p.MJ_EOP_VOR_PHASEIN_END_OR_PHASEIN_LEER,',
'    p.MJ_EOP_NACH_PHASEIN_END,',
'    p.MJ_SOP_VOR_ODER_GLEICH_AUSSER_KRAFT,',
'    p.MJ_SOP_NACH_AUSSER_KRAFT,',
'    p.IN_KRAFT_RELEVANT,',
'    p.NEUE_TYPEN_RELEVANT,',
'    p.ALLE_FAHRZEUGE_RELEVANT,',
'    p.PHASE_IN_RELEVANT,',
'    p.PHASE_OUT_RELEVANT,',
'    p.DATUM_MJ_STATUS,',
'    p.AUSSER_KRAFT_IST_LEER,',
unistr('    p."KLEINER_ODER_GLEICH_LETZTE_M\00D6GLICHE_VORSCHRIFT_ZUR_HOMOLOGATION",'),
unistr('    p."GR\00D6SSER_LETZTE_M\00D6GLICHE_VORSCHRIFT_ZUR_HOMOLOGATION",'),
'    p.SOP__IST_GLEICH_ODER_NACH_IN_KRAFT_,',
'    p.SOP_VOR_IN_KRAFT_ODER_IN_KRAFT_IST_LEER,',
'    p.ALLE_FAHRZEUGE_RELEVANT_EOP,',
'    p.LETZTE_AENDERUNG_DATUM,',
'    p.LETZTE_AENDERUNG_BENUTZERID',
'    --benutzer.nachname || '', '' || benutzer.vorname AS LETZTE_AENDERUNG_BENUTZER',
'',
'    ',
'-- LEFT OUTER JOIN ',
'--     T_BENUTZER benutzer ON benutzer.benutzerid = p.LETZTE_AENDERUNG_BENUTZERID;',
'FROM  T_MS_PARAMETER p'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2122601048075229295)
,p_plug_name=>unistr('Ordnungskrit\00E4rium')
,p_parent_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_region_css_classes=>'region-ordnung'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2122601127466229296)
,p_plug_name=>'Stammdaten'
,p_parent_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_region_css_classes=>'region-stammdaten'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2122601261435229297)
,p_plug_name=>'Datumsverarbeitung'
,p_parent_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_region_css_classes=>'region-datum'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_plug_display_when_condition=>'P705_START_TYP'
,p_plug_display_when_cond2=>'0:10'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2122601359772229298)
,p_plug_name=>'Output'
,p_parent_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_region_css_classes=>'region-output'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2122601479014229300)
,p_plug_name=>'ModelJahrverarbeitung'
,p_parent_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_region_css_classes=>'region-modeljahr'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_plug_display_when_condition=>'P705_START_TYP'
,p_plug_display_when_cond2=>'0:20'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2122601618124229301)
,p_plug_name=>'Datum Legende'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="legend-container">',
'    <div class="legend-title">Legende</div>',
'    <div class="legend-items">',
'        <div class="legend-item">',
'            <span class="legend-color color-ordnung"></span>',
'            <span title="Zum Ordnungskriterium-Bereich springen">Ordnungskriterium</span>',
'        </div>',
'        <div class="legend-item">',
'            <span class="legend-color color-stammdaten"></span>',
'            <span title="Zum Stammdaten-Bereich springen">Stammdaten</span>',
'        </div>',
'        <div class="legend-item">',
'            <span class="legend-color color-datum"></span>',
'            <span title="Zum Datumsverarbeitung-Bereich springen">Datumsverarbeitung</span>',
'        </div>',
'        <!-- <div class="legend-item">',
'            <span class="legend-color color-modeljahr"></span>',
'            <span title="Zum ModelJahrverarbeitung-Bereich springen">ModelJahrverarbeitung</span>',
'        </div> -->',
'        <div class="legend-item">',
'            <span class="legend-color color-output"></span>',
'            <span title="Zum Output-Bereich springen">Output</span>',
'        </div>',
'    </div>',
'</div>'))
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P705_START_TYP'
,p_plug_display_when_cond2=>'10'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2122601708491229302)
,p_plug_name=>'ModelJahr Legende'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="legend-container">',
'    <div class="legend-title">Legende</div>',
'    <div class="legend-items">',
'        <div class="legend-item">',
'            <span class="legend-color color-ordnung"></span>',
'            <span title="Zum Ordnungskriterium-Bereich springen">Ordnungskriterium</span>',
'        </div>',
'        <div class="legend-item">',
'            <span class="legend-color color-stammdaten"></span>',
'            <span title="Zum Stammdaten-Bereich springen">Stammdaten</span>',
'        </div>',
'        <!-- <div class="legend-item">',
'            <span class="legend-color color-datum"></span>',
'            <span title="Zum Datumsverarbeitung-Bereich springen">Datumsverarbeitung</span>',
'        </div> -->',
'        <div class="legend-item">',
'            <span class="legend-color color-modeljahr"></span>',
'            <span title="Zum ModelJahrverarbeitung-Bereich springen">ModelJahrverarbeitung</span>',
'        </div>',
'        <div class="legend-item">',
'            <span class="legend-color color-output"></span>',
'            <span title="Zum Output-Bereich springen">Output</span>',
'        </div>',
'    </div>',
'</div>'))
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P705_START_TYP'
,p_plug_display_when_cond2=>'20'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2122601806919229303)
,p_plug_name=>'Alle Legende'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="legend-container">',
'    <div class="legend-title">Legende</div>',
'    <div class="legend-items">',
'        <div class="legend-item">',
'            <span class="legend-color color-ordnung"></span>',
'            <span title="Zum Ordnungskriterium-Bereich springen">Ordnungskriterium</span>',
'        </div>',
'        <div class="legend-item">',
'            <span class="legend-color color-stammdaten"></span>',
'            <span title="Zum Stammdaten-Bereich springen">Stammdaten</span>',
'        </div>',
'        <div class="legend-item">',
'            <span class="legend-color color-datum"></span>',
'            <span title="Zum Datumsverarbeitung-Bereich springen">Datumsverarbeitung</span>',
'        </div>',
'        <div class="legend-item">',
'            <span class="legend-color color-modeljahr"></span>',
'            <span title="Zum ModelJahrverarbeitung-Bereich springen">ModelJahrverarbeitung</span>',
'        </div>',
'        <div class="legend-item">',
'            <span class="legend-color color-output"></span>',
'            <span title="Zum Output-Bereich springen">Output</span>',
'        </div>',
'    </div>',
'</div>'))
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P705_START_TYP'
,p_plug_display_when_cond2=>'0'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1037467277239048501)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1958333006366490183)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1037466821857048500)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1958333006366490183)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1037466473353048499)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1958333006366490183)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P705_MS_PARAMETERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1037466104305048499)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(1958333006366490183)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P705_MS_PARAMETERID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1037407525262048454)
,p_branch_action=>'f?p=&APP_ID.:701:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037465395839048498)
,p_name=>'P705_MS_PARAMETERID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_source=>'MS_PARAMETERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037464974475048497)
,p_name=>'P705_LETZTE_AENDERUNG_BENUTZERID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>720
,p_item_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_source=>'LETZTE_AENDERUNG_BENUTZERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037464539439048497)
,p_name=>'P705_DECKELUNG_DER_HOEHEREN_SERIE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>730
,p_item_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Deckelung Der Hoeheren Serie'
,p_source=>'DECKELUNG_DER_HOEHEREN_SERIE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
unistr('        emano_util.fLang(''Kleiner oder gleich "Letzte m\00F6gliche Vorschrift f\00FCr Homologation"'', ''Smaller or equal "Last possible regulation for homologation"'') AS display_value,'),
'        1 AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Gr\00F6\00DFer "Letzte m\00F6gliche Vorschrift zur Homologation"'', ''Greater "Last possible regulation for homologation"'') AS display_value,'),
'        2 AS return_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''not relevant'') AS display_value,',
'        0 AS return_value,',
'        3 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037464159121048497)
,p_name=>'P705_VERNETZUNGSARTID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>740
,p_item_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Vernetzungsartid'
,p_source=>'VERNETZUNGSARTID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037463770425048497)
,p_name=>'P705_SEARCH_MODE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>750
,p_item_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Search Mode'
,p_source=>'SEARCH_MODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037463388315048497)
,p_name=>'P705_DATUM_MJ_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>760
,p_item_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_source=>'DATUM_MJ_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037462994359048496)
,p_name=>unistr('P705_KLEINER_ODER_GLEICH_LETZTE_M\00D6GLICHE_VORSCHRIFT_ZUR_HOMOLOGATION')
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>770
,p_item_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>unistr('Kleiner Oder Gleich Letzte M\00F6gliche Vorschrift Zur Homologation')
,p_source=>unistr('KLEINER_ODER_GLEICH_LETZTE_M\00D6GLICHE_VORSCHRIFT_ZUR_HOMOLOGATION')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037462516334048496)
,p_name=>unistr('P705_GR\00D6SSER_LETZTE_M\00D6GLICHE_VORSCHRIFT_ZUR_HOMOLOGATION')
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>780
,p_item_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>unistr('Gr\00F6sser Letzte M\00F6gliche Vorschrift Zur Homologation')
,p_source=>unistr('GR\00D6SSER_LETZTE_M\00D6GLICHE_VORSCHRIFT_ZUR_HOMOLOGATION')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037462194581048496)
,p_name=>'P705_AUSGABE_FUER_ANDERES_TOOL_ODER_FUER_MENSCH'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>790
,p_item_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'AUSGABE FUER ANDERES_TOOL_ODER_FUER_MENSCH'
,p_source=>'AUSGABE_FUER_ANDERES_TOOL_ODER_FUER_MENSCH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037457992893048490)
,p_name=>'P705_START_TYP'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2122601048075229295)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Start Typ'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Datum'', ''Date'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''ModelJahr'', ''ModelYear'') AS display_value,',
'        20 AS actual_value,',
'        2 AS sort_order  ',
'    FROM dual',
' UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''alle'', ''all'') AS display_value,',
'        0 AS actual_value,',
'        3 AS sort_order  ',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037457553859048490)
,p_name=>'P705_NUMMER'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2122601048075229295)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Nummer'
,p_source=>'NUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037457182090048489)
,p_name=>'P705_BEMERKUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(2122601048075229295)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Bemerkung'
,p_source=>'BEMERKUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>500
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037456783502048489)
,p_name=>'P705_FAHRZEUGKLASSE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(2122601048075229295)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Fahrzeugklasse'
,p_source=>'FAHRZEUGKLASSE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''nicht relevant'', ''not relevant'') AS display_value,',
'        ''nicht relevant'' AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Filterergebnis false'', ''Filter result false'') AS display_value,',
'        ''Filterergebnis false'' AS return_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Filterergebnis true'', ''Filter result true'') AS display_value,',
'        ''Filterergebnis true'' AS return_value,',
'        3 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037456379753048489)
,p_name=>'P705_THEMENGEBIET'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(2122601048075229295)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Themengebiet'
,p_source=>'THEMENGEBIET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''nicht relevant'', ''not relevant'') AS display_value,',
'        ''nicht relevant'' AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Filterergebnis false'', ''Filter result false'') AS display_value,',
'        ''Filterergebnis false'' AS return_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Filterergebnis true'', ''Filter result true'') AS display_value,',
'        ''Filterergebnis true'' AS return_value,',
'        3 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037455965779048489)
,p_name=>'P705_PARAMETER_MJ_DATUMSFORMAT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(2122601048075229295)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Parameter Mj Datumsformat'
,p_source=>'PARAMETER_MJ_DATUMSFORMAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Datum'', ''Date'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Jahreszahl'', ''Year'') AS display_value,',
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''Not relevant'') AS display_value,',
'        30 AS actual_value,',
'        3 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037453780732048487)
,p_name=>'P705_VERNETZUNGSART'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2122601127466229296)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Vernetzungsart'
,p_source=>'VERNETZUNGSART'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''nicht relevant'', ''not relevant'') AS display_value,',
'        ''nicht relevant'' AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''UN-R Supplement'', ''UN-R Supplement'') AS display_value,',
'        ''UN-R Supplement'' AS return_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''equivalent'', ''equivalent'') AS display_value,',
'        ''equivalent'' AS return_value,',
'        3 AS sort_order',
'    FROM dual',
'    ',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Supplement'', ''Supplement'') AS display_value,',
'        ''Supplement'' AS return_value,',
'        4 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''keine'', ''none'') AS display_value,',
'        ''keine'' AS return_value,',
'        5 AS sort_order',
'    FROM dual',
'    ',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''demands'', ''demands'') AS display_value,',
'        ''demands'' AS return_value,',
'        6 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037453383890048486)
,p_name=>'P705_FAHRZEUGZULASSUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2122601127466229296)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Fahrzeugzulassung'
,p_source=>'FAHRZEUGZULASSUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''nicht relevant'', ''not relevant'') AS display_value,',
'        ''nicht relevant'' AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''neuer Typ'', ''new type'') AS display_value,',
'        ''neuer Typ'' AS return_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''alter Typ'', ''old type'') AS display_value,',
'        ''alter Typ'' AS return_value,',
'        3 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037453002111048486)
,p_name=>'P705_LAND'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2122601127466229296)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Land'
,p_source=>'LAND'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Filterergebnis Vernetzungstabelle'', ''Filter result Cross-Reference Table'') AS display_value,',
'        ''Filterergebnis Vernetzungstabelle'' AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''not relevant'') AS display_value,',
'        ''nicht relevant'' AS return_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Filterergebnis true'', ''Filter result true'') AS display_value,',
'        ''Filterergebnis true'' AS return_value,',
'        3 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037452541485048486)
,p_name=>'P705_DATUMSANGABEN_ORIGINAL_VERNETZUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2122601127466229296)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Datumsangaben Original Vernetzung'
,p_source=>'DATUMSANGABEN_ORIGINAL_VERNETZUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''nicht relevant'', ''not relevant'') AS display_value,',
'        ''nicht relevant'' AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Original'', ''Original'') AS display_value,',
'        ''Original'' AS return_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Vernetzungstabelle'', ''Cross-Reference Table'') AS display_value,',
'        ''Vernetzungstabelle'' AS return_value,',
'        3 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037452193653048485)
,p_name=>'P705_VORSCHRIFTEN_TYP'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(2122601127466229296)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Vorschriften Typ'
,p_source=>'VORSCHRIFTEN_TYP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''nicht relevant'', ''not relevant'') AS display_value,',
'        ''nicht relevant'' AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Rahmenrichtlinie'', ''Rahmenrichtlinie'') AS display_value,',
'        ''Rahmenrichtlinie'' AS return_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Supplement'', ''Supplement'') AS display_value,',
'        ''Supplement'' AS return_value,',
'        3 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Vorschrift oder Norm'', ''Regulation or Standard'') AS display_value,',
'        ''Vorschrift oder Norm'' AS return_value,',
'        4 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037451720212048484)
,p_name=>'P705_FBU_CKD_RELEVANTES_LAND'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(2122601127466229296)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'FBU CKD relevantes Land'
,p_source=>'FBU_CKD_RELEVANTES_LAND'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''ja'', ''yes'') AS display_value,',
'        ''ja'' AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nein'', ''no'') AS display_value,',
'        ''nein'' AS return_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''not relevant'') AS display_value,',
'        ''nicht relevant'' AS return_value,',
'        3 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037451329896048484)
,p_name=>'P705_PARAMETER_CKD_FBU_DATUM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(2122601127466229296)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Parameter CKD FBU Datum'
,p_source=>'PARAMETER_CKD_FBU_DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''nicht relevant'', ''not relevant'') AS display_value,',
'        ''nicht relevant'' AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''CKD Spalten'', ''CKD Columns'') AS display_value,',
'        ''CKD Spalten'' AS return_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''FBU Spalten'', ''FBU Columns'') AS display_value,',
'        ''FBU Spalten'' AS return_value,',
'        3 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037451012547048484)
,p_name=>'P705_SUPPLEMENT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(2122601127466229296)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Supplement'
,p_source=>'SUPPLEMENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_JNNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nicht relevant'', ''Nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037450573365048484)
,p_name=>'P705_INTERNER_DB_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(2122601127466229296)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Interner DB Status'
,p_source=>'INTERNER_DB_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
unistr('        emano_util.fLang(''nicht relevant f\00FCr Audi AG; in Bearbeitung, Import is running'', ''not relevant for Audi AG; processing, import is running'') AS display_value,'),
'        10 AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Sichtbar in Regulation Index DB'', ''Visible in Regulation Index DB'') AS display_value,',
'        20 AS return_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''not relevant'') AS display_value,',
'        30 AS return_value,',
'        3 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037450183580048483)
,p_name=>'P705_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(2122601127466229296)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Status'
,p_source=>'STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''draft'', ''draft'') AS display_value,',
'        20 AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Final Document'', ''Final Document'') AS display_value,',
'        30 AS return_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Enacted'', ''Enacted'') AS display_value,',
'        40 AS return_value,',
'        3 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''not relevant'') AS display_value,',
'        50 AS return_value,',
'        4 AS sort_order',
'    FROM dual',
'    ',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Draft, Final document'', ''Draft, Final document'') AS display_value,',
'        60 AS return_value,',
'        5 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037449765603048483)
,p_name=>'P705_PROGNOSE_QUALITAET'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(2122601127466229296)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>unistr('Prognose Qualit\00E4t')
,p_source=>'PROGNOSE_QUALITAET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
unistr('        emano_util.fLang(''absch\00E4tzbar'', ''estimable'') AS display_value,'),
'        20 AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''best\00E4tigt'', ''confirmed'') AS display_value,'),
'        30 AS return_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''not relevant'') AS display_value,',
'        40 AS return_value,',
'        3 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''leer'', ''empty'') AS display_value,',
'        50 AS return_value,',
'        4 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037449389872048483)
,p_name=>'P705_SOP_VOR_IN_KRAFT_ODER_IN_KRAFT_IST_LEER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(2122601127466229296)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'SOP Vor In Kraft'
,p_source=>'SOP_VOR_IN_KRAFT_ODER_IN_KRAFT_IST_LEER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nicht relevant'', ''Nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual    ',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Vorschrift'', ''Regulation'') AS display_value,',
'        3 AS actual_value,',
'        4 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>'SOP Vor In Kraft Oder In Kraft Ist Leer'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037448946593048483)
,p_name=>'P705_SOP__IST_GLEICH_ODER_NACH_IN_KRAFT_'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(2122601127466229296)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'SOP Ist Gleich Oder Nach In Kraft '
,p_source=>'SOP__IST_GLEICH_ODER_NACH_IN_KRAFT_'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nicht relevant'', ''Nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual    ',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Vorschrift'', ''Regulation'') AS display_value,',
'        3 AS actual_value,',
'        4 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037448529188048482)
,p_name=>'P705_ALLE_FAHRZEUGE_RELEVANT_EOP'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(2122601127466229296)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Alle Fahrzeuge Relevant EOP'
,p_source=>'ALLE_FAHRZEUGE_RELEVANT_EOP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''existiert'', ''existiert'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''fehlt'', ''fehlt'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037443714439048479)
,p_name=>'P705_LESENDE_TABELLE_FUER_DATUMSANGABEN'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>unistr('Lesende Tabelle f\00FCr Datumsangaben')
,p_source=>'LESENDE_TABELLE_FUER_DATUMSANGABEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Vorschrift'', ''Regulation'') AS display_value,',
'        1 AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Vernetzungstabelle'', ''Cross-Reference Table'') AS display_value,',
'        2 AS return_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''not relevant'') AS display_value,',
'        0 AS return_value,',
'        3 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:10'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037443217120048479)
,p_name=>'P705_HOEHERE_SERIE_MOEGLICH'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>unistr('H\00F6here Serie M\00F6glich')
,p_source=>'HOEHERE_SERIE_MOEGLICH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_JNNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nicht relevant'', ''Nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037442826704048479)
,p_name=>'P705_IN_KRAFT_RELEVANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'In Kraft Relevant'
,p_source=>'IN_KRAFT_RELEVANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''existiert'', ''existiert'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''fehlt'', ''fehlt'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037442435501048479)
,p_name=>'P705_SOP_IST_VOR_DATUM_IN_KRAFT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'SOP ist Vor Datum In Kraft'
,p_source=>'SOP_IST_VOR_DATUM_IN_KRAFT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:10'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>'SOP ist Vor Datum In Kraft ODER in Kraft Datum ist leer'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037442114853048478)
,p_name=>'P705_SOP_GLEICH_ODER_NACH_DATUM_IN_KRAFT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'SOP gleich oder Nach Datum In Kraft'
,p_source=>'SOP_GLEICH_ODER_NACH_DATUM_IN_KRAFT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:10'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037441655555048478)
,p_name=>'P705_NEUE_TYPEN_RELEVANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Neue Typen Relevant'
,p_source=>'NEUE_TYPEN_RELEVANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''existiert'', ''existiert'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''fehlt'', ''fehlt'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037441295659048477)
,p_name=>'P705_SOP_IST_VOR_DATUM_NEUE_TYPEN'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'SOP ist vor Datum Neue Typen'
,p_source=>'SOP_IST_VOR_DATUM_NEUE_TYPEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:10'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>'SOP ist vor Datum Neue Typen ODER in Kraft Datum ist leer'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037440872649048477)
,p_name=>'P705_SOP_IST_NACH_ODER_GLEICH_DATUM_NEUE_TYPEN'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'SOP Ist nach oder gleich Datum Neue Typen'
,p_source=>'SOP_IST_NACH_ODER_GLEICH_DATUM_NEUE_TYPEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:10'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037440489289048477)
,p_name=>'P705_ALLE_FAHRZEUGE_RELEVANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Alle Fahrzeuge Relevant'
,p_source=>'ALLE_FAHRZEUGE_RELEVANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''existiert'', ''existiert'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''fehlt'', ''fehlt'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037440034657048477)
,p_name=>'P705_SOP_IST_VOR_DATUM_ALLE_FAHRZEUGE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'SOP Ist Vor Datum Alle FZG'
,p_source=>'SOP_IST_VOR_DATUM_ALLE_FAHRZEUGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:10'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>'SOP Ist Vor Datum Alle FZG ODER in Kraft Datum ist leer'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037439633619048476)
,p_name=>'P705_SOP_IST_NACH_ODER_GLECIH_DATUM_ALLE_FAHRZEUGE_'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'SOP Ist Nach oder gleich Datum Alle Fahrzeuge'
,p_source=>'SOP_IST_NACH_ODER_GLECIH_DATUM_ALLE_FAHRZEUGE_'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:10'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037439315825048476)
,p_name=>'P705_AUSSER_KRAFT_IST_LEER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Ausser Kraft Ist Leer'
,p_source=>'AUSSER_KRAFT_IST_LEER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''existiert'', ''existiert'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''fehlt'', ''fehlt'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037438881857048476)
,p_name=>'P705_SOP_IST_VOR_DATUM_AUSSER_KRAFT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>unistr('SOP ist vor Datum Au\00DFer Kraft')
,p_source=>'SOP_IST_VOR_DATUM_AUSSER_KRAFT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:10'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037438472432048476)
,p_name=>'P705_SOP_IST_NACH_ODER_GLEICH_DATUM_AUSSER_KRAFT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>unistr('SOP ist nach oder gleich Datum Au\00DFer Kraft')
,p_source=>'SOP_IST_NACH_ODER_GLEICH_DATUM_AUSSER_KRAFT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:10'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037438036813048475)
,p_name=>'P705_SOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'SOP ist vor Datum In Kraft des Nachfolgers'
,p_source=>'SOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:10'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037437647076048474)
,p_name=>'P705_SOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'SOP Ist gleich oder nach Datum In Kraft des Nachfolgers'
,p_source=>'SOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:10'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037437256929048474)
,p_name=>'P705_EOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'EOP ist vor Datum in Kraft des Nachfolgers'
,p_source=>'EOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:10'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037436844665048474)
,p_name=>'P705_EOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'EOP ist gleich oder nach Datum In Kraft des Nachfolgers'
,p_source=>'EOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:10'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037436430484048474)
,p_name=>'P705_EOP_LIEGT_VOR_DATUM_IN_KRAFT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'EOP liegt vor Datum in Kraft'
,p_source=>'EOP_LIEGT_VOR_DATUM_IN_KRAFT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:10'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037436071688048473)
,p_name=>'P705_EOP_LIEGT_NACH_ODER_GLEICH_DATUM_IN_KRAFT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'EOP liegt nach oder gleich Datum in Kraft'
,p_source=>'EOP_LIEGT_NACH_ODER_GLEICH_DATUM_IN_KRAFT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_RNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''relevant'', ''relevant'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:10'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037435700120048473)
,p_name=>'P705_EOP_LIEGT_VOR_DATUM_ALLE_FAHRZEUGE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'EOP liegt vor Datum Alle Fahrzeuge'
,p_source=>'EOP_LIEGT_VOR_DATUM_ALLE_FAHRZEUGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:10'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037435258581048473)
,p_name=>'P705_EOP_LIEGT_NACH_ODER_GLEICH_DATUM_ALLE_FAHRZEUGE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'EOP liegt nach oder gleich Datum Alle Fahrzeuge'
,p_source=>'EOP_LIEGT_NACH_ODER_GLEICH_DATUM_ALLE_FAHRZEUGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:10'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037434900731048473)
,p_name=>'P705_NACHFOLGER_ANZEIGEN'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(2122601261435229297)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Nachfolger anzeigen'
,p_source=>'NACHFOLGER_ANZEIGEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_JNNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nicht relevant'', ''Nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:10'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037427257871048468)
,p_name=>'P705_AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2122601359772229298)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Ausgabe Der Vorschrift Bei Report Baureihe'
,p_source=>'AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_JNNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nicht relevant'', ''Nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037426854883048468)
,p_name=>'P705_LETZTE_AENDERUNG_DATUM'
,p_source_data_type=>'DATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2122601359772229298)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>unistr('Letzte \00C4nderung Datum')
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_source=>'LETZTE_AENDERUNG_DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037426481329048468)
,p_name=>'P705_NEW_BENUTZER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2122601359772229298)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Letzte \00C4nderung Benutzer')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NACHNAME || '', '' || VORNAME ',
'FROM T_BENUTZER ',
'WHERE BENUTZERID = :P705_LETZTE_AENDERUNG_BENUTZERID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037425278866048467)
,p_name=>'P705_QUELLVORSCHRIFT_GUELTIG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>unistr('Quellvorschrift g\00FCltig')
,p_source=>'QUELLVORSCHRIFT_GUELTIG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''ja'', ''yes'') AS display_value,',
'        ''ja'' AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nein'', ''no'') AS display_value,',
'        ''nein'' AS return_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''not relevant'') AS display_value,',
'        ''nicht relevant'' AS return_value,',
'        3 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037424840040048467)
,p_name=>'P705_PHASE_IN_RELEVANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Phase In Relevant'
,p_source=>'PHASE_IN_RELEVANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''existiert'', ''exists'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''fehlt'', ''missing'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''not relevant'') AS display_value,',
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037424431975048466)
,p_name=>'P705_PHASE_OUT_RELEVANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Phase Out Relevant'
,p_source=>'PHASE_OUT_RELEVANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''existiert'', ''exists'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''fehlt'', ''missing'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''not relevant'') AS display_value,',
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037424028780048466)
,p_name=>'P705_IN_KRAFT_RELEVANT_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'In Kraft Relevant'
,p_source=>'IN_KRAFT_RELEVANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''existiert'', ''existiert'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''fehlt'', ''fehlt'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'20'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037423664054048466)
,p_name=>'P705_NEUE_TYPEN_RELEVANT_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Neue Typen Relevant'
,p_source=>'NEUE_TYPEN_RELEVANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''existiert'', ''existiert'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''fehlt'', ''fehlt'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'20'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037423270159048465)
,p_name=>'P705_ALLE_FAHRZEUGE_RELEVANT_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Alle Fahrzeuge Relevant'
,p_source=>'ALLE_FAHRZEUGE_RELEVANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''existiert'', ''existiert'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''fehlt'', ''fehlt'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'20'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037422818084048465)
,p_name=>'P705_AUSSER_KRAFT_IST_LEER_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Ausser Kraft Ist Leer'
,p_source=>'AUSSER_KRAFT_IST_LEER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''existiert'', ''existiert'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''fehlt'', ''fehlt'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'20'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037422442596048465)
,p_name=>'P705_MJ_SOP_VOR_PHASEIN_START_OR_PHASEIN_LEER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'SOP vor Phase in Start'
,p_source=>'MJ_SOP_VOR_PHASEIN_START_OR_PHASEIN_LEER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>'SOP vor Phase in Start ODER Phase in Start ist leer'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037422046418048465)
,p_name=>'P705_MJ_SOP_NACH_PHASEIN_START'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'SOP nach Phase in Start'
,p_source=>'MJ_SOP_NACH_PHASEIN_START'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037421711093048465)
,p_name=>'P705_MJ_SOP_VOR_PHASEIN_END_OR_PHASEIN_LEER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'SOP vor Phase in End'
,p_source=>'MJ_SOP_VOR_PHASEIN_END_OR_PHASEIN_LEER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>'SOP vor Phase in End ODER Phase in ist leer'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037421293958048464)
,p_name=>'P705_MJ_SOP_NACH_PHASEIN_END'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'SOP nach Phase in End'
,p_source=>'MJ_SOP_NACH_PHASEIN_END'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037420863599048464)
,p_name=>'P705_MJ_SOP_VOR_ODER_GLEICH_AUSSER_KRAFT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>unistr('SOP vor Oder gleich Au\00DFer Kraft')
,p_source=>'MJ_SOP_VOR_ODER_GLEICH_AUSSER_KRAFT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037420487981048464)
,p_name=>'P705_MJ_SOP_NACH_AUSSER_KRAFT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>unistr('SOP nach Au\00DFer Kraft')
,p_source=>'MJ_SOP_NACH_AUSSER_KRAFT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037420089323048464)
,p_name=>'P705_MJ_EOP_VOR_PHASEIN_START_OR_PHASEIN_LEER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'EOP vor Phase in Start'
,p_source=>'MJ_EOP_VOR_PHASEIN_START_OR_PHASEIN_LEER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>'EOP vor Phase in Start ODER Phase in Start ist leer'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037419715212048464)
,p_name=>'P705_MJ_EOP_NACH_PHASEIN_START'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'EOP nach Phase in Start'
,p_source=>'MJ_EOP_NACH_PHASEIN_START'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037419310417048463)
,p_name=>'P705_MJ_EOP_VOR_PHASEIN_END_OR_PHASEIN_LEER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'EOP vor Phase in End'
,p_source=>'MJ_EOP_VOR_PHASEIN_END_OR_PHASEIN_LEER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>'EOP vor Phase in End ODER Phase in ist leer'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037418850308048463)
,p_name=>'P705_MJ_EOP_NACH_PHASEIN_END'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'EOP nach Phase in End'
,p_source=>'MJ_EOP_NACH_PHASEIN_END'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037418462307048463)
,p_name=>'P705_MJ_EINSATZ_JAHR_KLEINER_PHASEIN_START_JAHR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Mj Einsatz Jahr Kleiner Phasein Start Jahr'
,p_source=>'MJ_EINSATZ_JAHR_KLEINER_PHASEIN_START_JAHR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037418084480048462)
,p_name=>'P705_MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_START_JAHR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Mj Einsatz Jahr Groesser Gleich Phasein Start Jahr'
,p_source=>'MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_START_JAHR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nicht relevant'', ''Not relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Serie'', ''Series'') AS display_value,',
'        3 AS actual_value,',
'        4 AS sort_order',
'    FROM dual    ',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037417681822048462)
,p_name=>'P705_MJ_EINSATZ_JAHR_KLEINER_PHASEIN_ENDE_JAHR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Mj Einsatz Jahr Kleiner Phasein Ende Jahr'
,p_source=>'MJ_EINSATZ_JAHR_KLEINER_PHASEIN_ENDE_JAHR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037417256866048462)
,p_name=>'P705_MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_ENDE_JAHR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Mj Einsatz Jahr Groesser Gleich Phasein Ende Jahr'
,p_source=>'MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_ENDE_JAHR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037416910853048462)
,p_name=>'P705_MJ_EINSATZ_JAHR_KLEINER_GLEICH_AUSSER_KRAFT_JAHR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Mj Einsatz Jahr Kleiner Gleich Ausser Kraft Jahr'
,p_source=>'MJ_EINSATZ_JAHR_KLEINER_GLEICH_AUSSER_KRAFT_JAHR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037416430803048461)
,p_name=>'P705_MJ_EINSATZ_JAHR_GROESSER_AUSSER_KRAFT_JAHR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(2122601479014229300)
,p_item_source_plug_id=>wwv_flow_imp.id(1958405687271531832)
,p_prompt=>'Mj Einsatz Jahr Groesser Ausser Kraft Jahr'
,p_source=>'MJ_EINSATZ_JAHR_GROESSER_AUSSER_KRAFT_JAHR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MS_PARAMETER_TFNR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''true'', ''true'') AS display_value,',
'        1 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''false'', ''false'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''nicht relevant'', ''nicht relevant'') AS display_value,',
'        2 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- w\00E4hlen --')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P705_START_TYP'
,p_display_when2=>'0:20'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1037408543312048456)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1037467277239048501)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1037408109134048455)
,p_event_id=>wwv_flow_imp.id(1037408543312048456)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1037458715210048491)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(1958405687271531832)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Ms parameter edit'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2634753600689339744
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1037459035119048491)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(1958405687271531832)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Ms parameter edit'
,p_internal_uid=>2634753280780339744
);
wwv_flow_imp.component_end;
end;
/
