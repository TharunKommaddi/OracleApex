prompt --application/pages/page_00028
begin
--   Manifest
--     PAGE: 00028
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>28
,p_name=>unistr('Qualit\00E4tscheck und \00C4nderung des Freigabestatus')
,p_alias=>unistr('VORSCHRIFT-FREIGABESTATUS-\00C4NDERN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Qualit\00E4tscheck und \00C4nderung des Freigabestatus')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'600'
,p_dialog_width=>'900'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1022620286513785473)
,p_plug_name=>unistr('Vorschrift Freigabestatus \00E4ndern')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  v.VORSCHRIFTID VORSCHRIFTID, Vorschrift_freigabeStatusid, vorschrift_nummer, vorschrift_bezeichnung, ',
'       Normid, without_norm_validation ,',
'       Link_zur_Vorschrift_dms, link_zur_vorschrift_GETEX, websitelink,',
'       LEAD_VKO_Benutzerid, vorschrift_statusid, PROGNOSE_QUALITAET, ',
'       v.Bemerkung',
' from T_Vorschrift v',
'where v.VorschriftID = :P28_VORSCHRIFTID'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3182772314091391832)
,p_name=>unistr('Interpretations-MFV mit Vorg\00E4nger/Nachfolger Details')
,p_parent_plug_id=>wwv_flow_imp.id(1022620286513785473)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH cte AS (',
'    SELECT ',
'        LISTAGG(t.bezeichnung, '', '') WITHIN GROUP (ORDER BY t.bezeichnung) as teil_bez_list,',
'        m.mfv_name,',
'        mrt.mfvid',
'    FROM t_mfv_ref_mfv_teil mrt',
'    JOIN t_mfv_teil t ON (t.mfv_teilID = mrt.mfv_teilid)',
'    JOIN t_mfv m ON (m.mfvid = mrt.mfvid)',
'    where m.mfvid in (select mfvid from t_mfv_ref_mfv_teil where mfv_teilid = 1001)',
'    GROUP BY mrt.mfvid, m.mfv_name',
')',
'SELECT',
'',
'',
'',
'',
'    CASE ',
'        WHEN m.JIRA_TICKET IS NOT NULL AND LENGTH(TRIM(m.JIRA_TICKET)) > 0 THEN',
'            APEX_ITEM.CHECKBOX(1, m.MFVID)',
'        ELSE',
'            ''<span title="Kein Jira-Ticket vorhanden">-</span>''',
'    END AS SELECT_MFV,',
'',
'    tv.NACHFOLGER_VORSCHRIFTID AS Nachfolger_Vorschrift_ID,',
'    n.VORSCHRIFT_NUMMER AS Nachfolger_Vorschrift_Nummer,',
'    tv.VORGAENGER_VORSCHRIFTID AS Vorgaenger_Vorschrift_ID,',
'    CASE ',
'        WHEN t.VORSCHRIFT_NUMMER IS NOT NULL THEN ',
'            ''<a href="f?p='' || :APP_ID || '':25:'' || :APP_SESSION || '':::RP,25:P25_VORSCHRIFTID:'' || ',
unistr('            tv.VORGAENGER_VORSCHRIFTID || ''" target="_blank" title="Vorg\00E4nger Vorschrift Details">'' ||'),
'            ''<span class="fa fa-search"></span></a> '' || ',
'            t.VORSCHRIFT_NUMMER',
'        ELSE NULL ',
'    END AS Vorgaenger_Vorschrift_Nummer,',
'    cte.teil_bez_list AS MFV_Teil,',
'    y.ak_liste AS AK_Liste,',
'    PCK_RI.fJiraTicketsToLinks(m.JIRA_TICKET) AS Jira_Ticket,',
'    CASE ',
'        WHEN m.LINK_MFV_DMS IS NOT NULL THEN ',
'            REGEXP_REPLACE(',
'                PCK_RI.fCreateLinkIfUrl(m.LINK_MFV_DMS),',
'                ''>(.*?)</a>'', ',
unistr('                ''><span aria-hidden="true" class="t-Icon fa fa-external-link"></span><span class="u-VisuallyHidden">DMS Link \00F6ffnen</span></a>'''),
'            )',
'        ELSE NULL ',
'    END AS Link_zum_DMS,',
'    cte.mfv_name,',
'    m.MFVID',
'   ',
'    ',
'    ',
'FROM t_vorschrift_ref_vorschrift tv ',
'LEFT OUTER JOIN t_vorschrift t ON (t.VORSCHRIFTID = tv.VORGAENGER_VORSCHRIFTID)',
'LEFT OUTER JOIN t_vorschrift n ON (n.VORSCHRIFTID = tv.NACHFOLGER_VORSCHRIFTID)',
'LEFT OUTER JOIN t_mfv_ref_vorschrift mv ON (mv.VORSCHRIFTID = tv.VORGAENGER_VORSCHRIFTID)',
'LEFT OUTER JOIN T_MFV m ON (mv.MFVID = m.MFVID)',
'JOIN cte ON (cte.mfvid = m.mfvid)',
'OUTER APPLY (',
'    SELECT LISTAGG(a.kurz, '', '') WITHIN GROUP (ORDER BY a.kurz) as ak_liste',
'    FROM t_mfv_ref_et_b_ak i',
'    JOIN t_et_b_ak a ON (i.et_b_akid = a.et_b_akid)',
'    WHERE m.mfvid = i.mfvid',
') y',
'WHERE tv.NACHFOLGER_VORSCHRIFTID = :P28_VORSCHRIFTID',
unistr('and tv.beziehung_art = 10 -- nur Vorg\00E4nger/Nachfolger Beziehungen'),
'--AND cte.teil_bez_list = ''Interpretation'''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('Keine MfVs zum Vorg\00E4nger zugeordnet.')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(918615760376446730)
,p_query_column_id=>1
,p_column_alias=>'SELECT_MFV'
,p_column_display_sequence=>100
,p_column_heading=>unistr('\00DCbernehmen')
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3182772122812391831)
,p_query_column_id=>2
,p_column_alias=>'NACHFOLGER_VORSCHRIFT_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3182772079880391830)
,p_query_column_id=>3
,p_column_alias=>'NACHFOLGER_VORSCHRIFT_NUMMER'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3182771929689391829)
,p_query_column_id=>4
,p_column_alias=>'VORGAENGER_VORSCHRIFT_ID'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3182771891427391828)
,p_query_column_id=>5
,p_column_alias=>'VORGAENGER_VORSCHRIFT_NUMMER'
,p_column_display_sequence=>40
,p_column_heading=>unistr('Vorg\00E4nger Vorschrift Nummer')
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3182771788545391827)
,p_query_column_id=>6
,p_column_alias=>'MFV_TEIL'
,p_column_display_sequence=>60
,p_column_heading=>'Mfv Teil'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3182771685889391826)
,p_query_column_id=>7
,p_column_alias=>'AK_LISTE'
,p_column_display_sequence=>70
,p_column_heading=>'AK'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3182771609596391825)
,p_query_column_id=>8
,p_column_alias=>'JIRA_TICKET'
,p_column_display_sequence=>80
,p_column_heading=>'Jira-Tickets'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3182771513368391824)
,p_query_column_id=>9
,p_column_alias=>'LINK_ZUM_DMS'
,p_column_display_sequence=>90
,p_column_heading=>'Link zur Ablage DMS'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3182771106893391820)
,p_query_column_id=>10
,p_column_alias=>'MFV_NAME'
,p_column_display_sequence=>50
,p_column_heading=>'MfV Name'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(918615653184446729)
,p_query_column_id=>11
,p_column_alias=>'MFVID'
,p_column_display_sequence=>110
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(829558067299399385)
,p_plug_name=>'Fehlgeschlagene Validationen'
,p_parent_plug_id=>wwv_flow_imp.id(1022620286513785473)
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(829557655666399381)
,p_plug_name=>'Statuswechsel'
,p_parent_plug_id=>wwv_flow_imp.id(1022620286513785473)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(829557089576399375)
,p_plug_name=>'Error'
,p_parent_plug_id=>wwv_flow_imp.id(829557655666399381)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--danger:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Der Statuswechsel kann nicht durchgef\00FChrt werden, da nicht alle f\00FCr den gew\00FCnschten Status erforderlichen Validationen des Qualit\00E4tscheck erfolgreich waren.<br />'),
'Bitte wende Dich ggf. an einen Admin um Diese Daten anzupassen.'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(781401710330132194)
,p_plug_name=>'Success'
,p_parent_plug_id=>wwv_flow_imp.id(829557655666399381)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('Die f\00FCr den gew\00FCnschten Freigabestatus erforderlichen Validationen sind erfolgreich - der Statuswechsel kann vorgenommen werden.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1022617803766785458)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1022617353613785457)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1022617803766785458)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1022615589682785454)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1022617803766785458)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1017361231099700184)
,p_branch_name=>'parent Page submit'
,p_branch_action=>'javascript:parent.apex.submit()'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1022615589682785454)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1036494969489372572)
,p_name=>'P28_NEUER_FREIGABESTATUSID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(829557655666399381)
,p_prompt=>'Neuer Freigabestatus'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case :P28_VORSCHRIFT_FREIGABESTATUSID when ''1'' then ''10'' ',
'                                            when ''10'' then ''20'' ',
'                                            when ''20'' then ''30''',
'                                            when ''30'' then ''1'' else ''1'' end',
'from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    select vorschrift_freigabestatusid as r, emano_util.fLang(name_deutsch,name_englisch) as d',
'    from t_vorschrift_freigabestatus',
')    ',
'select d, r',
'from cte1',
'WHERE (',
'       ( :P28_VORSCHRIFT_FREIGABESTATUSID =  1 and r in (10, 30) ) ',
'    or ( :P28_VORSCHRIFT_FREIGABESTATUSID = 10 and r in (20, 30) ) -- 20 and 30 ',
'    or ( :P28_VORSCHRIFT_FREIGABESTATUSID = 20 and r in (30) )  -- only next status',
'    or ( :P28_VORSCHRIFT_FREIGABESTATUSID = 30 and r = 1  )',
'    or ( :P28_VORSCHRIFT_FREIGABESTATUSID = -1 and r in (1))',
')'))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'Y',
  'page_action_on_selection', 'SUBMIT')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1022619861437785472)
,p_name=>'P28_VORSCHRIFTID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1022620286513785473)
,p_item_source_plug_id=>wwv_flow_imp.id(1022620286513785473)
,p_source=>'VORSCHRIFTID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1022619089819785460)
,p_name=>'P28_VORSCHRIFT_FREIGABESTATUSID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1022620286513785473)
,p_item_source_plug_id=>wwv_flow_imp.id(1022620286513785473)
,p_source=>'VORSCHRIFT_FREIGABESTATUSID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(829558010611399384)
,p_name=>'P28_ERRORTEXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(829558067299399385)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Errortext'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lErrorList apex_t_number;',
'    lErrorText varchar2(2000);',
'    lValList apex_t_number;',
'begin',
'    lValList := pck_ri_validation.fValListByStatus(:P28_NEUER_FREIGABESTATUSID);',
'    pck_ri_validation.pVal(:P28_VORSCHRIFTID,lValList,lErrorList,lErrorText);',
'    return ''<ul><li>'' || replace(lErrorText,chr(10),''</li><li>'') || ''</ul>'';',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144103148820565)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(829557903552399383)
,p_name=>'P28_ERRORLIST'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(829558067299399385)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(829557585391399380)
,p_name=>'P28_VAL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(829557655666399381)
,p_use_cache_before_default=>'NO'
,p_source=>'pck_ri_validation.fValByStatus(:P28_VORSCHRIFTID, :P28_NEUER_FREIGABESTATUSID)'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1022617303530785457)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1022617353613785457)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1022616496024785454)
,p_event_id=>wwv_flow_imp.id(1022617303530785457)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(990121254317731702)
,p_name=>'Change Norm'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P28_NORMID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(990121179771731701)
,p_event_id=>wwv_flow_imp.id(990121254317731702)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P28_NORM_BEISPIEL'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select replace(beispiel,chr(10),''; '') from t_norm where normid = nvl(:P28_NORMID, 1016)'
,p_attribute_07=>'P28_NORMID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(990121066459731700)
,p_event_id=>wwv_flow_imp.id(990121254317731702)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#P28_NORMID_inline_help'').html(''Beispiel(e): '' + $v(''P28_NORM_BEISPIEL''));'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(829557343650399378)
,p_name=>'Validation?'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P28_VAL'
,p_condition_element=>'P28_VAL'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(829557282126399377)
,p_event_id=>wwv_flow_imp.id(829557343650399378)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(1022615589682785454)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(781401200927132189)
,p_event_id=>wwv_flow_imp.id(829557343650399378)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(829557089576399375)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(781401628604132193)
,p_event_id=>wwv_flow_imp.id(829557343650399378)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(781401710330132194)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(781401289397132190)
,p_event_id=>wwv_flow_imp.id(829557343650399378)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(829558067299399385)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(781401770898132195)
,p_event_id=>wwv_flow_imp.id(829557343650399378)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(829558067299399385)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(781401381261132191)
,p_event_id=>wwv_flow_imp.id(829557343650399378)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(781401710330132194)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(829556939360399374)
,p_event_id=>wwv_flow_imp.id(829557343650399378)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(829557089576399375)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(781401521689132192)
,p_event_id=>wwv_flow_imp.id(829557343650399378)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(1022615589682785454)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3182771354964391823)
,p_name=>unistr('Show / Hide Interpretations-MFV mit Vorg\00E4nger/Nachfolger Details')
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P28_VORSCHRIFT_FREIGABESTATUSID'
,p_condition_element=>'P28_VORSCHRIFT_FREIGABESTATUSID'
,p_triggering_condition_type=>'IN_LIST'
,p_triggering_expression=>'10,1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3182771282737391822)
,p_event_id=>wwv_flow_imp.id(3182771354964391823)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3182772314091391832)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3182771182930391821)
,p_event_id=>wwv_flow_imp.id(3182771354964391823)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3182772314091391832)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(918615612459446728)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Adopt Selected MfVs'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_selected VARCHAR2(4000);',
'BEGIN',
'    l_selected := APEX_UTIL.TABLE_TO_STRING(APEX_APPLICATION.G_F01, '':'');',
'    ',
'    IF l_selected IS NOT NULL THEN',
'        PCK_CIP_JIRA.pAdoptInterpretationMfVs(',
'            p_new_vorschriftid => :P28_VORSCHRIFTID,',
'            p_mfvid_list => l_selected',
'        );',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1022615589682785454)
,p_internal_uid=>2753596703439941507
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1036494366919372566)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE CHANGES'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_vorschrift ',
'set vorschrift_freigabestatusID = :P28_NEUER_FREIGABESTATUSID, REVISIONSZAEHLER = REVISIONSZAEHLER + 1',
'   -- VORSCHRIFT_NUMMER = :P28_VORSCHRIFT_NUMMER,',
'   -- VOrschrift_bezeichnung = :P28_VORSCHRIFT_BEZEICHNUNG,',
'   -- normid = nvl(:P28_NORMID, 1016),',
'   -- without_norm_validation = :P28_WITHOUT_NORM_VALIDATION,',
'   -- LINK_ZUR_VORSCHRIFT_DMS = :P28_LINK_ZUR_VORSCHRIFT_DMS,',
'   -- LINK_ZUR_VORSCHRIFT_GETEX = :P28_LINK_ZUR_VORSCHRIFT_GETEX,',
'  --  WEBSITElink = :P28_WEBSITELINK,',
'   -- LEAD_VKO_BENUTZERID = :P28_LEAD_VKO,',
'  --  bemerkung = :P28_BEMERKUNG',
'where VORSCHRIFTID = :P28_VORSCHRIFTID;',
'-- send benachricht an AKs',
'if(:P28_NEUER_FREIGABESTATUSID = 10) then',
'    pck_ri_Benachrichtigung.pBenachrichtigung_Statuswechsel(:P28_VORSCHRIFTID ,  pck_ri.fgetuserId);',
'    pck_ri_Benachrichtigung.pThemenDiff_Vorgaenger(:P28_VORSCHRIFTID ,  pck_ri.fgetuserId);',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1022615589682785454)
,p_internal_uid=>2635717948980015669
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1022613978974785452)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE, DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2649598336924602783
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(829557777826399382)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Init'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lErrorList apex_t_number;',
'    lErrorText varchar2(2000);',
'begin',
'    /*pck_ri_validation.pVal(:P28_VORSCHRIFTID,apex_string.split_numbers(''1:2:3:4:5:6:7:8:9'','':''),lErrorList,lErrorText);',
'',
'    if (lErrorList.count > 0) then',
'        :P28_ERRORTEXT := ''<ul><li>'' || replace(lErrorText,chr(10),''</li><li>'') || ''</ul>'';',
'    else',
'        :P28_ERRORTEXT := ''Alle Validationen erfolgreich!'';',
'    end if;        ',
'',
'    ',
'    :P28_ERRORLIST := apex_string.join(lErrorList,'':'');*/',
'',
'    select vorschrift_freigabestatusid into :P28_VORSCHRIFT_FREIGABESTATUSID',
'    from t_vorschrift',
'    where vorschriftid = :P28_VORSCHRIFTID;',
'end;    '))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2842654538072988853
);
wwv_flow_imp.component_end;
end;
/
