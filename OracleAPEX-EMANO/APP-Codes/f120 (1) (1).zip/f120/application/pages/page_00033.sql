prompt --application/pages/page_00033
begin
--   Manifest
--     PAGE: 00033
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>33
,p_name=>'Thema aus Getex  Form'
,p_alias=>'THEMA-AUS-GETEX-FORM'
,p_page_mode=>'MODAL'
,p_step_title=>'Thema Pflege'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2045179411516634496)
,p_plug_name=>'Thema aus Getex'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct --V_ID,       --V_NUMMER,       --V_STATUS,      -- REV_ID,',
'      gt.THEMA_ID,',
'       gt.THEMA_NAME,',
'      gt.THEMA_NAME_EN,',
'       gt.REGINDEX_THEMAID,',
'       t.status_pflege',
'       --, t.status_gueltig',
'  from MV_GETEX_VORSCHRIFT_THEMA gt',
'  join T_Thema t on (t.getex_thema_key = gt.thema_id)',
' where THEMA_ID = :P33_THEMA_ID  and status_pflege =1'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1057095305613192919)
,p_plug_name=>'Pflege Status'
,p_parent_plug_id=>wwv_flow_imp.id(2045179411516634496)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<b>&nbsp;&nbsp;&nbsp; Thema wird aus der Liste neuer Themen entfernt<br>',
'   &nbsp;&nbsp;&nbsp; falls ''Pflege erledigt'' aktiviert ist</b>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2045185377932634523)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1057106054114206933)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2045185377932634523)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1057105705005206929)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2045185377932634523)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1057105248724206929)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2045185377932634523)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_condition=>'P33_THEMA_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1057104891585206928)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2045185377932634523)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1057111530103206945)
,p_name=>'P33_THEMA_ID'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2045179411516634496)
,p_item_source_plug_id=>wwv_flow_imp.id(2045179411516634496)
,p_prompt=>'GETEX Thema ID'
,p_source=>'THEMA_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1057111209191206943)
,p_name=>'P33_THEMA_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2045179411516634496)
,p_item_source_plug_id=>wwv_flow_imp.id(2045179411516634496)
,p_prompt=>'Bezeichnung deutsch'
,p_source=>'THEMA_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>1024
,p_cHeight=>4
,p_grid_label_column_span=>3
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1057110727525206943)
,p_name=>'P33_THEMA_NAME_EN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(2045179411516634496)
,p_item_source_plug_id=>wwv_flow_imp.id(2045179411516634496)
,p_prompt=>'Bezeichnung  englisch'
,p_source=>'THEMA_NAME_EN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>1024
,p_cHeight=>4
,p_grid_label_column_span=>3
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1057110332756206943)
,p_name=>'P33_REGINDEX_THEMAID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(2045179411516634496)
,p_item_source_plug_id=>wwv_flow_imp.id(2045179411516634496)
,p_source=>'REGINDEX_THEMAID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1057109941186206942)
,p_name=>'P33_STATUS_PFLEGE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1057095305613192919)
,p_item_source_plug_id=>wwv_flow_imp.id(2045179411516634496)
,p_item_default=>'1'
,p_prompt=>'Pflege erledigt'
,p_source=>'STATUS_PFLEGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Aktiviere die Checkbox, wenn Pflege des Themas abgeschlossen ist '
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', '0',
  'unchecked_value', '1',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1057109109408206938)
,p_name=>'P33_NUMMER'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(2045179411516634496)
,p_prompt=>'Nummer'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1057108684591206937)
,p_name=>'P33_PARENTID'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(2045179411516634496)
,p_prompt=>'Parent ID'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_THEMA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    NUMMER || '' - '' || ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN BEZEICHNUNG',
'        ELSE name_eng',
'    END as d,',
'    THEMAID as r',
'FROM V_THEMA_BAUM vtb',
'-- It excludes topics linked to et_b_akid = 1036 in t_thema_ref_et_b_ak, ensuring results are relevant to users without access to these excluded topics.',
'-- WHERE vtb.themaid not in (select themaid from t_thema_ref_et_b_ak where et_b_akid =1036 )',
'ORDER BY vtb.thema_sortorder;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-kein parent-'
,p_cSize=>30
,p_colspan=>10
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1057104386268206917)
,p_validation_name=>'Thema ID exists'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from t_Thema ',
'where :P33_THEMA_ID is not null and getex_thema_key = :P33_THEMA_ID'))
,p_validation_type=>'EXISTS'
,p_error_message=>'ein Thema mit Getex_Thema_ID  existiert ereits '
,p_when_button_pressed=>wwv_flow_imp.id(1057105248724206929)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1057103987924206916)
,p_validation_name=>unistr('g\00FCltiges Wert')
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--substr(:P33_NUMMER, 1, 1)',
'(:P33_NUMMER is not null)',
'and',
' (   instr(:P33_NUMMER, ''.'') = 0  and  REGEXP_LIKE(:P33_NUMMER,  ''^[[:digit:]]+$'')',
'  or instr(:P33_NUMMER, ''.'') > 0  and  REGEXP_LIKE(substr(:P33_NUMMER, 1, instr(:P33_NUMMER, ''.'')-1), ''^[[:digit:]]+$'')',
' )'))
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Ung\00FCltiger wert f\00FCr Nummer')
,p_when_button_pressed=>wwv_flow_imp.id(1057105248724206929)
,p_associated_item=>wwv_flow_imp.id(1057109109408206938)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1057102424659206914)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1057106054114206933)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1057101988921206910)
,p_event_id=>wwv_flow_imp.id(1057102424659206914)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1057101603902206910)
,p_name=>'change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P33_STATUS_PFLEGE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1057101040391206909)
,p_event_id=>wwv_flow_imp.id(1057101603902206910)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P33_STATUS_PFLEGE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1057102827191206916)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\00DCbernehme Thema')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' --  if(:P33_PARENTID is not null) then',
'      --  Insert into T_Thema (Getex_Thema_Key, Bezeichnung, name_eng, nummer, parentid )',
'     --   values (:P33_THEMA_ID, :P33_THEMA_NAME, :P33_THEMA_NAME_EN, :P33_NUMMER, :P33_PARENTID);',
' --  else',
' --        Insert into T_Thema (Getex_Thema_Key, Bezeichnung, name_eng, nummer, parentid )',
' --       values (:P33_THEMA_ID, :P33_THEMA_NAME, :P33_THEMA_NAME_EN, :P33_NUMMER, null);',
' -- end if; ',
' --debug (''P33_STATUS_PFLEGE=''|| :P33_STATUS_PFLEGE);',
' update T_Thema  set STATUS_PFLEGE = nvl(:P33_STATUS_PFLEGE, 0), Bezeichnung = :P33_THEMA_NAME, name_eng = :P33_THEMA_NAME_EN, ',
'                nummer = :P33_NUMMER, parentid = :P33_PARENTID',
' where Getex_Thema_Key = :P33_THEMA_ID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1057105248724206929)
,p_internal_uid=>2615109488708181319
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1057103707824206916)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1057105248724206929)
,p_internal_uid=>2615108608075181319
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1057106799370206934)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(2045179411516634496)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Thema aus Getex  Form'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2615105516529181301
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1057103245821206916)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LOAD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  distinct gt.Thema_name, gt.Thema_name_en, gt.regindex_Themaid, t.status_pflege, t.nummer, t.parentid --, t.gueltig',
'into :P33_THEMA_NAME, :P33_THEMA_NAME_EN, :P33_REGINDEX_THEMAID, :P33_STATUS_PFLEGE, :P33_NUMMER, :P33_PARENTID --, :P33_GUELTIG',
'',
'FROM MV_GETEX_VORSCHRIFT_THEMA gt',
'join T_Thema t on (t.getex_thema_key = gt.thema_id)',
'where gt.Thema_id = :P33_THEMA_ID;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2615109070078181319
);
wwv_flow_imp.component_end;
end;
/
