prompt --application/pages/page_00530
begin
--   Manifest
--     PAGE: 00530
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>530
,p_name=>'JIRA Test'
,p_alias=>'JIRA-TEST'
,p_step_title=>'JIRA Test'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(840647017272449703)
,p_plug_name=>'Rohdaten'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(840646328608449696)
,p_name=>'Daten'
,p_parent_plug_id=>wwv_flow_imp.id(840647017272449703)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id, teil, summary, listagg(labels, '', '') as labels, oes, status, ',
'    link,',
'    ak, key, umsetzung',
'    ',
'from json_table(pck_ri_jira.fJiraJqlRequest(:P530_REQUEST), ',
'               ''$.issues[*]''',
'               columns',
'               (',
'                   id varchar2(18 char) path ''$.fields.customfield_11670'',',
'                   teil varchar2(100 char) path ''$.fields.customfield_11406.value'',',
'                   summary varchar2(200 char) path ''$.fields.summary'',',
'                   --labels varchar2 (200 char) path ''$.fields.labels[*]'',',
'                   nested path ''$.fields.labels[*]'' ',
'                       columns (',
'                           labels varchar2 (200 char) path ''$''',
'                       ),',
'                   ',
'                   oes varchar2(200 char) path ''$.fields.customfield_13070'',',
'                   status varchar2(200 char) path ''$.fields.environment'',',
'                   link varchar2(400 char) path ''$.fields.customfield_11814'',',
'                   ak varchar2(100 char) path ''$.fields.components.name'',',
'                   key varchar2(100 char) path ''$.key'',',
'                   umsetzung varchar2(200 char) path ''$.fields.customfield_10598.value''',
'                   ',
'            ',
'               )',
'           )',
'           group by id, teil, summary, oes, status, ',
'    link,',
'    ak, key, umsetzung'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(814144592199272403)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(814144513230272402)
,p_query_column_id=>2
,p_column_alias=>'TEIL'
,p_column_display_sequence=>2
,p_column_heading=>'MfV Teil'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(840645894452449692)
,p_query_column_id=>3
,p_column_alias=>'SUMMARY'
,p_column_display_sequence=>3
,p_column_heading=>'Thema der MfV'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(814143694148272394)
,p_query_column_id=>4
,p_column_alias=>'LABELS'
,p_column_display_sequence=>4
,p_column_heading=>'Schlagworte'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(814144241709272400)
,p_query_column_id=>5
,p_column_alias=>'OES'
,p_column_display_sequence=>5
,p_column_heading=>'Beteiligte OEs'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(814144165281272399)
,p_query_column_id=>6
,p_column_alias=>'STATUS'
,p_column_display_sequence=>6
,p_column_heading=>'Status im VKO/VEX Prozess '
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(814144115459272398)
,p_query_column_id=>7
,p_column_alias=>'LINK'
,p_column_display_sequence=>7
,p_column_heading=>'Link zum Sammelordner '
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(814143975839272397)
,p_query_column_id=>8
,p_column_alias=>'AK'
,p_column_display_sequence=>8
,p_column_heading=>'Arbeitskreis Kurzbezeichnung '
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(814143884196272396)
,p_query_column_id=>9
,p_column_alias=>'KEY'
,p_column_display_sequence=>9
,p_column_heading=>'Jira ID '
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(814143742398272395)
,p_query_column_id=>10
,p_column_alias=>'UMSETZUNG'
,p_column_display_sequence=>10
,p_column_heading=>unistr('Welcher Umsetzungsverfolgung Fall wurde im AK gew\00E4hlt ')
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(840646821752449701)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(840647017272449703)
,p_button_name=>'submit'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abfragen'
,p_button_position=>'CHANGE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(840646934583449702)
,p_name=>'P530_REQUEST'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(840647017272449703)
,p_prompt=>'Request'
,p_source=>'issuetype = task AND status != closed AND Regelname ~ "IN IBAMA 07/2021"'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(840646652723449700)
,p_name=>'P530_RESPONSE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(840647017272449703)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Response'
,p_source=>'utl_raw.cast_to_varchar2(dbms_lob.substr(pck_ri_jira.fJiraJqlRequest(:P530_REQUEST), 10000, 1))'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp.component_end;
end;
/
