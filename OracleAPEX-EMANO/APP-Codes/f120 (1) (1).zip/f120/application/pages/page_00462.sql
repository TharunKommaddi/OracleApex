prompt --application/pages/page_00462
begin
--   Manifest
--     PAGE: 00462
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>462
,p_name=>'Einstellung bearbeiten/speichern'
,p_alias=>'EINSTELLUNG-BEARBEITEN-SPEICHERN'
,p_page_mode=>'MODAL'
,p_step_title=>'Einstellung bearbeiten/speichern'
,p_reload_on_submit=>'A'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/***********************',
' * Checkbox and Popup Styles',
' ***********************/',
'.apex-item-single-checkbox input:checked+.u-checkbox:after, ',
'.apex-item-single-checkbox input:checked+label:after, ',
'.u-checkbox.is-checked:after {',
'    opacity: 1;',
'    background-color: #bb0a31;',
'}',
'',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3270309472525629536)
,p_plug_name=>'Edit Filter&View Settings'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(5372039428574150492)
,p_name=>'Vorhandene Filter-Profile'
,p_parent_plug_id=>wwv_flow_imp.id(3270309472525629536)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-top-md'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select fvp.FILTER_VIEW_PROFILEID,',
'       fvp.BENUTZERID,',
'       fvp.NAME,',
'       fvp.DATA,',
'       fvp.START_PROFILE,',
'       CASE WHEN fvp.START_PROFILE = 1 THEN ''Ja'' ELSE ''Nein'' END as START_PROFILE_TEXT,',
'       fvp.NEW,',
'       fvp.PAGE,',
'       fvp.LETZTE_AENDERUNG_DATUM,',
'       fvp.LETZTE_AENDERUNG_BENUTZERID,',
'       nvl2(fvp.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) as LETZTE_AENDERUNG_BENUTZER,',
'       -- Add owner information for all profiles',
'       owner_b.nachname || '', '' || owner_b.vorname AS PROFILE_OWNER,',
'       CASE WHEN fvp.SHARED = 1 THEN ''Geteilt'' ELSE ''Privat'' END AS FREIGABE_STATUS',
'from T_FILTER_VIEW_PROFILE fvp',
'left outer join t_benutzer b on b.benutzerid = fvp.LETZTE_AENDERUNG_BENUTZERID',
'left outer join t_benutzer owner_b on owner_b.benutzerid = fvp.BENUTZERID',
'where (',
'    -- For PRI users: Show ALL profiles',
'    (EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'             WHERE brr.benutzerid = :G_BENUTZERID ',
'             AND brr.rolleid = 1001))',
'    OR',
'    -- For regular users: Show only own profiles + shared profiles',
'    (NOT EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                 WHERE brr.benutzerid = :G_BENUTZERID ',
'                 AND brr.rolleid = 1001)',
'     AND (fvp.BENUTZERID = :G_BENUTZERID OR fvp.SHARED = 1))',
')',
'and fvp.PAGE = :P462_FILTER_VIEW_PAGE',
'order by fvp.LETZTE_AENDERUNG_DATUM desc'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NAME',
'from T_FILTER_VIEW_PROFILE',
'where BENUTZERID = :G_BENUTZERID',
'-- and FILTER_VIEW_PROFILEID is null;',
'and PAGE = :P462_FILTER_VIEW_PAGE ;'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P462_FILTER_VIEW_PAGE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>7
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select fvp.FILTER_VIEW_PROFILEID,',
'       fvp.BENUTZERID,',
'       fvp.NAME,',
'       fvp.DATA,',
'       fvp.START_PROFILE,',
'       -- Convert START_PROFILE to Yes/No text',
'       CASE WHEN fvp.START_PROFILE = 1 THEN ''Ja'' ELSE ''Nein'' END as START_PROFILE_TEXT,',
'       fvp.NEW,',
'       fvp.PAGE,',
'       fvp.LETZTE_AENDERUNG_DATUM,',
'       fvp.LETZTE_AENDERUNG_BENUTZERID,',
'       nvl2(fvp.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) as LETZTE_AENDERUNG_BENUTZER',
'from T_FILTER_VIEW_PROFILE fvp',
'left outer join t_benutzer b on b.benutzerid = fvp.LETZTE_AENDERUNG_BENUTZERID',
'where fvp.BENUTZERID = :G_BENUTZERID',
'and fvp.PAGE = :P462_FILTER_VIEW_PAGE',
'order by fvp.LETZTE_AENDERUNG_DATUM desc'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1002360599161539160)
,p_query_column_id=>1
,p_column_alias=>'FILTER_VIEW_PROFILEID'
,p_column_display_sequence=>10
,p_column_heading=>'Filter View Profileid'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1002360210273539160)
,p_query_column_id=>2
,p_column_alias=>'BENUTZERID'
,p_column_display_sequence=>20
,p_column_heading=>'Benutzerid'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1002359795559539160)
,p_query_column_id=>3
,p_column_alias=>'NAME'
,p_column_display_sequence=>30
,p_column_heading=>unistr('Name der Filter\00ADeinstellung	')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1002356973922539158)
,p_query_column_id=>4
,p_column_alias=>'DATA'
,p_column_display_sequence=>40
,p_column_heading=>'Data'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1002356581072539157)
,p_query_column_id=>5
,p_column_alias=>'START_PROFILE'
,p_column_display_sequence=>60
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1002359408373539159)
,p_query_column_id=>6
,p_column_alias=>'START_PROFILE_TEXT'
,p_column_display_sequence=>50
,p_column_heading=>'Startprofil'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1002358950770539159)
,p_query_column_id=>7
,p_column_alias=>'NEW'
,p_column_display_sequence=>70
,p_column_heading=>'New'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1002358571397539159)
,p_query_column_id=>8
,p_column_alias=>'PAGE'
,p_column_display_sequence=>80
,p_column_heading=>'Page'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1002358156202539158)
,p_query_column_id=>9
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>90
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_column_format=>'DD.MM.YYYY HH24:MI:SS'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1002357745773539158)
,p_query_column_id=>10
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZERID'
,p_column_display_sequence=>100
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1002357321218539158)
,p_query_column_id=>11
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZER'
,p_column_display_sequence=>110
,p_column_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3112140294270461088)
,p_query_column_id=>12
,p_column_alias=>'PROFILE_OWNER'
,p_column_display_sequence=>120
,p_column_heading=>'Profil Besitzer'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3112140144878461087)
,p_query_column_id=>13
,p_column_alias=>'FREIGABE_STATUS'
,p_column_display_sequence=>130
,p_column_heading=>'Freigabe Status'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5372039558884150493)
,p_plug_name=>'Warning for START PROFILE'
,p_parent_plug_id=>wwv_flow_imp.id(3270309472525629536)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Es existiert bereits ein Startprofil. ',
unistr('Dieses wird \00FCberschrieben.')))
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from T_FILTER_VIEW_PROFILE',
'where BENUTZERID = :G_BENUTZERID',
'and PAGE = :P462_FILTER_VIEW_PAGE',
'and START_PROFILE = 1',
'and FILTER_VIEW_PROFILEID != nvl(:P462_FILTER_VIEW_PROFILE_ID, 0);'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8181665351159288569)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1002355578294539156)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8181665351159288569)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1002155153839539155)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(8181665351159288569)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>unistr('javascript:apex.confirm(''M\00F6chten Sie den FilterProfil l\00F6schen?'',''DELETE'');')
,p_button_execute_validations=>'N'
,p_button_condition=>'P462_FILTER_VIEW_PROFILE_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1002154776788539155)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(8181665351159288569)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P462_FILTER_VIEW_PROFILE_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
,p_button_comment=>'P462_FILTER_VIEW_PROFILE_ID itme not null'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1002154352649539155)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(8181665351159288569)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P462_FILTER_VIEW_PROFILE_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1002146097319539148)
,p_branch_name=>'Go To Page 460'
,p_branch_action=>'f?p=&APP_ID.:460:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002364145451539163)
,p_name=>'P462_FILTER_VIEW_PROFILE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3270309472525629536)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002363812625539163)
,p_name=>'P462_FILTER_VIEW_PAGE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3270309472525629536)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002363391335539163)
,p_name=>'P462_NAME'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(3270309472525629536)
,p_prompt=>'Name der Filter&shy;einstellung'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002362994962539162)
,p_name=>'P462_START_PROFILE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(3270309472525629536)
,p_prompt=>'Als Startprofil speichern'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:margin-top-md'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', '1',
  'unchecked_value', '0',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002362520364539162)
,p_name=>'P462_SHARED'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(3270309472525629536)
,p_item_default=>'0'
,p_prompt=>unistr('Profil f\00FCr andere Benutzer freigeben')
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>unistr('Wenn aktiviert, k\00F6nnen andere Benutzer dieses Filterprofil in der "Alle gespeicherten PRI Profile" Ansicht sehen und verwenden.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', '1',
  'unchecked_value', '0',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002361690826539161)
,p_name=>'P462_DATA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(3270309472525629536)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002361228655539161)
,p_name=>'P462_MESSAGE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(3270309472525629536)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1002153819282539154)
,p_validation_name=>'Unique Name'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from T_FILTER_VIEW_PROFILE',
'where BENUTZERID  = :G_BENUTZERID',
'and PAGE = :P462_FILTER_VIEW_PAGE',
'and trim(NAME) = trim(:P462_NAME)',
'and FILTER_VIEW_PROFILEID  != nvl(:P462_FILTER_VIEW_PROFILE_ID, 0);'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Eine Filtereinstellung mit diesem Namen existiert bereits'
,p_associated_item=>wwv_flow_imp.id(1002363391335539163)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1002150398173539151)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1002355578294539156)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002149855003539150)
,p_event_id=>wwv_flow_imp.id(1002150398173539151)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1002149467234539150)
,p_name=>'Show/Hide Start profile warning'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P462_START_PROFILE'
,p_condition_element=>'P462_START_PROFILE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'EXISTS'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from T_FILTER_VIEW_PROFILE',
'where BENUTZERID = :G_BENUTZERID',
'and PAGE = :P462_FILTER_VIEW_PAGE',
'and START_PROFILE = 1',
'and FILTER_VIEW_PROFILEID  != nvl(:P462_FILTER_VIEW_PROFILE_ID, 0);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002148946851539150)
,p_event_id=>wwv_flow_imp.id(1002149467234539150)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5372039558884150493)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002148429672539150)
,p_event_id=>wwv_flow_imp.id(1002149467234539150)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5372039558884150493)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002147934317539149)
,p_event_id=>wwv_flow_imp.id(1002149467234539150)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Es existiert bereits ein Startprofil. ',
unistr('Dieses wird \00FCberschrieben.')))
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002147470991539149)
,p_event_id=>wwv_flow_imp.id(1002149467234539150)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Es existiert bereits ein Startprofil. ',
unistr('Dieses wird \00FCberschrieben.')))
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1002147032728539149)
,p_name=>'New'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(5372039428574150492)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002146550070539149)
,p_event_id=>wwv_flow_imp.id(1002147032728539149)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5372039428574150492)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1002153575764539153)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create filter profile'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'declare',
'    lFilterDaten clob;',
'    lProfileName varchar2(255);',
'begin',
'    -- Trim and store the profile name to use in success message',
'    lProfileName := trim(:P462_NAME);',
'',
'    -- data assignment',
'    lFilterDaten := :P462_DATA;',
'',
'    -- If new profile is start profile, set the other profiles as not start profiles',
'    if :P462_START_PROFILE = 1 then',
'        update T_FILTER_VIEW_PROFILE',
'        set START_PROFILE = 0',
'        where BENUTZERID = :G_BENUTZERID',
'        and PAGE = :P462_FILTER_VIEW_PAGE;',
'    end if;',
'',
'    -- Validate data is not null',
'    IF lFilterDaten IS NOT NULL THEN',
'        -- Create profile (UPDATED TO INCLUDE SHARED)',
'        insert into T_FILTER_VIEW_PROFILE (',
'            BENUTZERID, ',
'            NAME, ',
'            DATA, ',
'            START_PROFILE, ',
'            PAGE, ',
'            NEW, ',
'            SHARED, ',
'            LETZTE_AENDERUNG_DATUM,',
'            LETZTE_AENDERUNG_BENUTZERID',
'        ) values (',
'            :G_BENUTZERID, ',
'            lProfileName, ',
'            lFilterDaten, ',
'            :P462_START_PROFILE, ',
'            :P462_FILTER_VIEW_PAGE, ',
'            0, ',
'            :P462_SHARED,  ',
'            sysdate,',
'            :G_BENUTZERID',
'        );',
'',
'        -- Set success message for new record',
'        apex_application.g_print_success_message := ''Filterprofil "'' || lProfileName || ''" erfolgreich erstellt'';',
'    else',
'        -- Handle the case where P462_DATA is NULL',
'        RAISE_APPLICATION_ERROR(-20001, ''DATA kann nicht NULL sein'');',
'    END IF;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1002154352649539155)
,p_process_success_message=>'&P462_MESSAGE.'
,p_internal_uid=>2670058740134849082
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lFilterDaten clob;',
'begin',
'',
'    if (:P462_FILTER_VIEW_PAGE = 80) then',
'        lFilterDaten := :P462_DATA;',
'    else',
'        lFilterDaten := :P462_DATA;',
'    end if;',
'',
'    -- If new profile is start profile, set the other profiles as not start profiles',
'    if :P462_START_PROFILE = 1 then',
'        update T_FILTER_VIEW_PROFILE',
'        set START_PROFILE = 0',
'        where BENUTZERID = :G_BENUTZERID',
'        and PAGE = :P462_FILTER_VIEW_PAGE;',
'    end if;',
'',
'    IF lFilterDaten IS NOT NULL THEN',
'    -- Create profile',
'    insert into T_FILTER_VIEW_PROFILE (BENUTZERID, NAME, DATA, START_PROFILE, PAGE, NEW, LETZTE_AENDERUNG_DATUM)',
'    values (:G_BENUTZERID, trim(:P462_NAME), lFilterDaten, :P462_START_PROFILE, :P462_FILTER_VIEW_PAGE, 0, sysdate);',
'    else',
'        -- Handle the case where P462_DATA is NULL',
'        RAISE_APPLICATION_ERROR(-20001, ''DATA cannot be NULL'');',
'    END IF;',
'end;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1002151577992539152)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create filter profile_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lFilterDaten clob;',
'    lProfileName varchar2(255);',
'begin',
'    -- Trim and store the profile name to use in success message',
'    lProfileName := trim(:P462_NAME);',
'',
'    -- data assignment',
'    lFilterDaten := :P462_DATA;',
'',
'    -- If new profile is start profile, set the other profiles as not start profiles',
'    if :P462_START_PROFILE = 1 then',
'        update T_FILTER_VIEW_PROFILE',
'        set START_PROFILE = 0',
'        where BENUTZERID = :G_BENUTZERID',
'        and PAGE = :P462_FILTER_VIEW_PAGE;',
'    end if;',
'',
'    -- Validate data is not null',
'    IF lFilterDaten IS NOT NULL THEN',
'        -- Create profile',
'        insert into T_FILTER_VIEW_PROFILE (',
'            BENUTZERID, ',
'            NAME, ',
'            DATA, ',
'            START_PROFILE, ',
'            PAGE, ',
'            NEW, ',
'            LETZTE_AENDERUNG_DATUM,',
'            LETZTE_AENDERUNG_BENUTZERID',
'        ) values (',
'            :G_BENUTZERID, ',
'            lProfileName, ',
'            lFilterDaten, ',
'            :P462_START_PROFILE, ',
'            :P462_FILTER_VIEW_PAGE, ',
'            0, ',
'            sysdate,',
'            :G_BENUTZERID',
'        );',
'',
'        -- Set success message for new record',
'        apex_application.g_print_success_message := ''Filterprofil "'' || lProfileName || ''" erfolgreich erstellt'';',
'        -- Set the success message',
'    -- :P462_MESSAGE := ''Filter profile created successfully.'';',
'    else',
'        -- Handle the case where P462_DATA is NULL',
'        RAISE_APPLICATION_ERROR(-20001, ''DATA kann nicht NULL sein'');',
'    END IF;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1002154352649539155)
,p_process_when_type=>'NEVER'
,p_process_success_message=>'&P462_MESSAGE.'
,p_internal_uid=>2670060737906849083
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lFilterDaten clob;',
'begin',
'',
'    if (:P462_FILTER_VIEW_PAGE = 80) then',
'        lFilterDaten := :P462_DATA;',
'    else',
'        lFilterDaten := :P462_DATA;',
'    end if;',
'',
'    -- If new profile is start profile, set the other profiles as not start profiles',
'    if :P462_START_PROFILE = 1 then',
'        update T_FILTER_VIEW_PROFILE',
'        set START_PROFILE = 0',
'        where BENUTZERID = :G_BENUTZERID',
'        and PAGE = :P462_FILTER_VIEW_PAGE;',
'    end if;',
'',
'    IF lFilterDaten IS NOT NULL THEN',
'    -- Create profile',
'    insert into T_FILTER_VIEW_PROFILE (BENUTZERID, NAME, DATA, START_PROFILE, PAGE, NEW, LETZTE_AENDERUNG_DATUM)',
'    values (:G_BENUTZERID, trim(:P462_NAME), lFilterDaten, :P462_START_PROFILE, :P462_FILTER_VIEW_PAGE, 0, sysdate);',
'    else',
'        -- Handle the case where P462_DATA is NULL',
'        RAISE_APPLICATION_ERROR(-20001, ''DATA cannot be NULL'');',
'    END IF;',
'end;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1002153191200539153)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save filter profile'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'declare',
'    lProfileName varchar2(255);',
'begin',
'    -- Trim and store the profile name',
'    lProfileName := trim(:P462_NAME);',
'',
'    -- If the profile is a new start profile, set other profiles as not start profiles',
'    if :P462_START_PROFILE = 1 then',
'        update T_FILTER_VIEW_PROFILE',
'        set START_PROFILE = 0',
'        where BENUTZERID = :G_BENUTZERID',
'        and PAGE = :P462_FILTER_VIEW_PAGE;',
'    end if;',
'',
'    -- Update profile (UPDATED TO INCLUDE SHARED)',
'    update T_FILTER_VIEW_PROFILE',
'    set NAME = lProfileName,',
'        START_PROFILE = :P462_START_PROFILE,',
'        SHARED = :P462_SHARED,  -- NEW: Add SHARED update',
'        NEW = 0,',
'        LETZTE_AENDERUNG_DATUM = sysdate,',
'        LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'    where FILTER_VIEW_PROFILEID = :P462_FILTER_VIEW_PROFILE_ID;',
'',
'    -- Set success message',
'    apex_application.g_print_success_message := ''Filterprofil "'' || lProfileName || ''" erfolgreich aktualisiert'';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1002154776788539155)
,p_internal_uid=>2670059124698849082
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- If the profile is a new start profile, set other profiles as not start profiles',
'if :P462_START_PROFILE = 1 then',
'    update T_FILTER_VIEW_PROFILE',
'    set START_PROFILE = 0',
'    where BENUTZERID = :G_BENUTZERID',
'    and PAGE = :P462_FILTER_VIEW_PAGE;',
'end if;',
'',
'-- Update profile',
'update T_FILTER_VIEW_PROFILE',
'set NAME = trim(:P462_NAME),',
'    START_PROFILE = :P462_START_PROFILE,',
'    NEW = 0,',
'    LETZTE_AENDERUNG_DATUM = sysdate',
'where FILTER_VIEW_PROFILEID = :P462_FILTER_VIEW_PROFILE_ID;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1002151140082539151)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save filter profile_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lProfileName varchar2(255);',
'begin',
'    -- Trim and store the profile name',
'    lProfileName := trim(:P462_NAME);',
'',
'    -- If the profile is a new start profile, set other profiles as not start profiles',
'    if :P462_START_PROFILE = 1 then',
'        update T_FILTER_VIEW_PROFILE',
'        set START_PROFILE = 0',
'        where BENUTZERID = :G_BENUTZERID',
'        and PAGE = :P462_FILTER_VIEW_PAGE;',
'    end if;',
'',
'    -- Update profile',
'    update T_FILTER_VIEW_PROFILE',
'    set NAME = lProfileName,',
'        START_PROFILE = :P462_START_PROFILE,',
'        NEW = 0,',
'        LETZTE_AENDERUNG_DATUM = sysdate,',
'        LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'    where FILTER_VIEW_PROFILEID = :P462_FILTER_VIEW_PROFILE_ID;',
'',
'    -- Set success message',
'    apex_application.g_print_success_message := ''Filterprofil "'' || lProfileName || ''" erfolgreich aktualisiert'';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1002154776788539155)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2670061175816849084
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- If the profile is a new start profile, set other profiles as not start profiles',
'if :P462_START_PROFILE = 1 then',
'    update T_FILTER_VIEW_PROFILE',
'    set START_PROFILE = 0',
'    where BENUTZERID = :G_BENUTZERID',
'    and PAGE = :P462_FILTER_VIEW_PAGE;',
'end if;',
'',
'-- Update profile',
'update T_FILTER_VIEW_PROFILE',
'set NAME = trim(:P462_NAME),',
'    START_PROFILE = :P462_START_PROFILE,',
'    NEW = 0,',
'    LETZTE_AENDERUNG_DATUM = sysdate',
'where FILTER_VIEW_PROFILEID = :P462_FILTER_VIEW_PROFILE_ID;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1002152800933539153)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete filter profile'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lProfileName varchar2(255);',
'begin',
'    -- Retrieve the name of the profile before deleting',
'    select NAME into lProfileName',
'    from T_FILTER_VIEW_PROFILE',
'    where FILTER_VIEW_PROFILEID = :P462_FILTER_VIEW_PROFILE_ID;',
'',
'    -- Delete the profile',
'    delete from T_FILTER_VIEW_PROFILE',
'    where FILTER_VIEW_PROFILEID = :P462_FILTER_VIEW_PROFILE_ID;',
'',
'    -- Set success message',
unistr('    apex_application.g_print_success_message := ''Filterprofil "'' || trim(lProfileName) || ''" erfolgreich gel\00F6scht'';'),
'exception',
'    when no_data_found then',
'        -- Handle case where profile might have already been deleted',
unistr('        apex_application.g_print_success_message := ''Filterprofil erfolgreich gel\00F6scht'';'),
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1002155153839539155)
,p_internal_uid=>2670059514965849082
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from T_FILTER_VIEW_PROFILE',
'where FILTER_VIEW_PROFILEID = :P462_FILTER_VIEW_PROFILE_ID;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1002150771398539151)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete filter profile_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lProfileName varchar2(255);',
'begin',
'    -- Retrieve the name of the profile before deleting',
'    select NAME into lProfileName',
'    from T_FILTER_VIEW_PROFILE',
'    where FILTER_VIEW_PROFILEID = :P462_FILTER_VIEW_PROFILE_ID;',
'',
'    -- Delete the profile',
'    delete from T_FILTER_VIEW_PROFILE',
'    where FILTER_VIEW_PROFILEID = :P462_FILTER_VIEW_PROFILE_ID;',
'',
'    -- Set success message',
unistr('    apex_application.g_print_success_message := ''Filterprofil "'' || trim(lProfileName) || ''" erfolgreich gel\00F6scht'';'),
'exception',
'    when no_data_found then',
'        -- Handle case where profile might have already been deleted',
unistr('        apex_application.g_print_success_message := ''Filterprofil erfolgreich gel\00F6scht'';'),
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1002155153839539155)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2670061544500849084
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from T_FILTER_VIEW_PROFILE',
'where FILTER_VIEW_PROFILEID = :P462_FILTER_VIEW_PROFILE_ID;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1002152415139539152)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1002355578294539156)
,p_internal_uid=>2670059900759849083
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1002151977735539152)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Form Initialization'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Retrieve and set values from the selected filter profile (UPDATED TO INCLUDE SHARED)',
'    SELECT ',
'        NAME,',
'        DATA,',
'        START_PROFILE,',
'        PAGE,',
'        SHARED  ',
'    INTO ',
'        :P462_NAME,',
'        :P462_DATA,',
'        :P462_START_PROFILE,',
'        :P462_FILTER_VIEW_PAGE,',
'        :P462_SHARED ',
'    FROM ',
'        T_FILTER_VIEW_PROFILE',
'    WHERE ',
'    FILTER_VIEW_PROFILEID = :P462_FILTER_VIEW_PROFILE_ID',
'    AND (BENUTZERID = :G_BENUTZERID ',
'         OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                    WHERE brr.benutzerid = :G_BENUTZERID ',
'                    AND brr.rolleid = 1001));',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Error handling',
'        :P462_NAME := NULL;',
'        :P462_DATA := NULL;',
'        :P462_START_PROFILE := 0;',
'        :P462_FILTER_VIEW_PAGE := NULL;',
'        :P462_SHARED := 0;  -- NEW: Add SHARED default',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P462_FILTER_VIEW_PROFILE_ID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>2670060338163849083
);
wwv_flow_imp.component_end;
end;
/
