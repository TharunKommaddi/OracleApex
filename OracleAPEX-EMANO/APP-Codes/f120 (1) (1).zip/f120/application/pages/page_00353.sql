prompt --application/pages/page_00353
begin
--   Manifest
--     PAGE: 00353
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>353
,p_name=>unistr('\00C4nderungshistorie Vorschrift MfVs')
,p_alias=>unistr('\00C4NDERUNGSHISTORIE-VORSCHRIFT-MFVS')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('\00C4nderungshistorie Vorschrift MfVs')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IR_HIST .t-fht-tbody {max-height: calc(100vh - 200px)}',
'.t-Body-topButton {display: none !important}',
'.t-Body-content {padding-bottom: 3px !important}',
'.t-Body {margin-bottom: 3px !important}',
'.t-Body-contentInner {padding-bottom: 0px !important}'))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(935396127395514574)
,p_plug_name=>'Historie Vorschrift MfVs'
,p_region_name=>'IR_HIST'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ex as (  select i.mfvid as mfvid, ',
'    listagg(a.kurz,'', '') within group (order by a.kurz) as ak_liste',
'    from t_mfv_ref_et_b_ak i',
'    join t_et_b_ak a on (i.et_b_akid = a.et_b_akid) group by i.mfvid',
' )',
'',
'select H_MMV_REF_VORSCHRIFTID,',
'       MFV_REF_VORSCHRIFTID,',
'       pck_ri_history.fdiff(v.VORSCHRIFT_NUMMER, LAG(v.VORSCHRIFT_NUMMER) over(partition by mrv.vorschriftid, mrv.MFV_REF_VORSCHRIFTID order by mrv.letzte_aenderung_datum asc)) as VORSCHRIFT,',
'       ',
'       pck_ri_history.fdiff(t.teil || ''. '' || t.bezeichnung || '' - '' || m.mfv_name, LAG(t.teil || ''. '' || t.bezeichnung || '' - '' || m.mfv_name) over(partition by mrv.vorschriftid, mrv.MFV_REF_VORSCHRIFTID order by mrv.letzte_aenderung_datum asc)) as '
||'MFV,',
'       ',
'       v.letzte_aenderung_datum as letzte_aenderung_datum,',
'       pck_ri.fCreatePermalinkUrl(v.vorschriftid) as PERMALINK,',
'       b.email as EMAIL,',
'       nvl2(v.letzte_aenderung_benutzerid, b.nachname || '', '' || b.vorname, null) AS LETZTE_AENDERUNG_BENUTZER,',
'       decode(mrv.geloescht, 1, ''ja'', 0, ''Nein'', ''Nein'') as geloescht_mfv,',
'       ex.ak_liste as Arbeitskreis_liste,',
'       decode(ak.geloescht, 1, ''ja'', 0, ''Nein'', ''Nein'') as geloescht_ak',
'',
'from T_H_MFV_REF_VORSCHRIFT mrv',
'left outer join t_benutzer b on (b.benutzerid = mrv.letzte_aenderung_benutzerid)',
'left outer join T_VORSCHRIFT v on (v.VORSCHRIFTID = mrv.VORSCHRIFTID)',
'left outer join T_MFV m on (m.MFVID = mrv.MFVID)',
'left outer join T_MFV_TEIL t on (t.MFV_TEILID  = m.MFV_TEILID)',
'left outer join ex on (ex.mfvid = m.mfvid)',
'left outer join T_H_MFV_REF_ET_B_AK ak on (ak.MFVID = m.MFVID)',
'where mrv.VORSCHRIFTID = :P353_VORSCHRIFTID',
'order by mrv.LETZTE_AENDERUNG_DATUM desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Historie Vorschrift MfVs'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(935396050858514574)
,p_name=>'Historie Vorschrift Kerndaten'
,p_max_row_count_message=>unistr('Der maximale Zeilenanzahl f\00FCr diesen Report ist #MAX_ROW_COUNT#. Bitte verwenden Sie einen Filter, um die Anzahl der Datens\00E4tze zu verringern.')
,p_no_data_found_message=>unistr('Es gibt noch keine historisierten Daten f\00FCr MfVs.')
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'mailto:#EMAIL#?body=#PERMALINK#'
,p_detail_link_text=>'<span class="fa fa-envelope-o" aria-hidden="true"></span>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>177296886236619830
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1018787208680839142)
,p_db_column_name=>'EMAIL'
,p_display_order=>432
,p_column_identifier=>'AQ'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1018786767261839142)
,p_db_column_name=>'PERMALINK'
,p_display_order=>442
,p_column_identifier=>'AR'
,p_column_label=>'Permalink'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1018786418011839141)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>452
,p_column_identifier=>'AS'
,p_column_label=>unistr('\00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1018786028327839140)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>462
,p_column_identifier=>'AT'
,p_column_label=>unistr('\00C4nderung Datum')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1020290705156660176)
,p_db_column_name=>'H_MMV_REF_VORSCHRIFTID'
,p_display_order=>472
,p_column_identifier=>'AU'
,p_column_label=>'H Mmv Ref Vorschriftid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1020290609601660175)
,p_db_column_name=>'MFV_REF_VORSCHRIFTID'
,p_display_order=>482
,p_column_identifier=>'AV'
,p_column_label=>'Mfv Ref Vorschriftid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1020290448136660174)
,p_db_column_name=>'VORSCHRIFT'
,p_display_order=>492
,p_column_identifier=>'AW'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1020290337861660173)
,p_db_column_name=>'MFV'
,p_display_order=>502
,p_column_identifier=>'AX'
,p_column_label=>'MfV'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048988852274004315)
,p_db_column_name=>'GELOESCHT_MFV'
,p_display_order=>512
,p_column_identifier=>'AZ'
,p_column_label=>unistr('MfV gel\00F6scht ')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048988766943004314)
,p_db_column_name=>'ARBEITSKREIS_LISTE'
,p_display_order=>522
,p_column_identifier=>'BA'
,p_column_label=>'Arbeitskreis Liste'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1048988568683004312)
,p_db_column_name=>'GELOESCHT_AK'
,p_display_order=>532
,p_column_identifier=>'BC'
,p_column_label=>unistr('AK gel\00F6scht')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(935377876504501401)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'939081'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LETZTE_AENDERUNG_BENUTZER:LETZTE_AENDERUNG_DATUM:VORSCHRIFT:MFV'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1018784348643839118)
,p_name=>'P353_VORSCHRIFTID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(935396127395514574)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
