prompt --application/pages/page_00578
begin
--   Manifest
--     PAGE: 00578
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>578
,p_name=>'Jira Ticket Create Prototyp'
,p_alias=>'JIRA-TICKET-CREATE-PROTOTYP'
,p_step_title=>'Jira Ticket Create Prototyp'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(924343798030487400)
,p_plug_name=>'Prototyp zum Erstellen/ Ausesen von Jira Tickets'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(6607221901102607297)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1577530124053546311)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_button_name=>'Read'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Lese Jira Ticket'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1577529990153546310)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_button_name=>'Clear_values'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Felder leeren'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:578:&SESSION.::&DEBUG.:578::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2080454425023703289)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_button_name=>'Erstellen'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1577529607886546306)
,p_name=>'P578_PROJEKT_ID'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_item_default=>'21724'
,p_prompt=>'Projekt Id'
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
''))
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Automatisch erstellt'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1577529743014546308)
,p_name=>'P578_JIRA_KEY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Jira key'
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
''))
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Automatisch erstellt'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1577529905002546309)
,p_name=>'P578_RESPONSE'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Response'
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  erstellte',
'',
'',
'',
'',
''))
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1577530251230546313)
,p_name=>'P578_LAENDER_FIELD'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1577530379535546314)
,p_name=>'P578_DESCRIPTION'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Beschreibung'
,p_post_element_text=>' customfield_10698'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1577530440260546315)
,p_name=>'P578_AK_KURZ_LIST'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080454820113703303)
,p_name=>'P578_JIRA_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Jira Id'
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
''))
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Automatisch erstellt'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080455689846703309)
,p_name=>'P578_STATUS_VKO_VEX'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Status VKO/VEX Process'
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Umgebung',
''))
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Automatisch erstellt'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080456445087703313)
,p_name=>'P578_THEMA_VON_MFV'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Thema der Mfv'
,p_post_element_text=>'Summary'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080456905445703313)
,p_name=>'P578_MFV_TYPE'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Mfv Type'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Information;83,Interpretation;11'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080457246190703313)
,p_name=>'P578_VORSCHRIFTENNR'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Vorschriftennummer'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080457695619703313)
,p_name=>'P578_TITEL'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Titel'
,p_post_element_text=>' customfield_10698'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080458120429703314)
,p_name=>'P578_STATUS_DER_VORSCHRIFT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Status der Vorschrift'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080458436356703315)
,p_name=>'P578_LINK_ZU_DMS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Link zu DMS'
,p_post_element_text=>' customfield_10696'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080458900516703315)
,p_name=>'P578_LINK_ZU_REQMAN'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Link zu ReqMAN'
,p_post_element_text=>' customfield_10696'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080459260088703315)
,p_name=>'P578_LINK_ZU_WEBSITE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Link zu Web Site'
,p_post_element_text=>' customfield_10696'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080459678846703316)
,p_name=>'P578_LINK_ZU_CETEX'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Link zu CETEX'
,p_post_element_text=>'_10696'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080460074585703316)
,p_name=>'P578_DATUM_IN_KRAFT'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Datum In Kraft'
,p_post_element_text=>'customfield_16653'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080460479576703316)
,p_name=>'P578_DATUM_NEUE_TYPEN'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Datum neue Typen'
,p_post_element_text=>'_10698'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080460867154703317)
,p_name=>'P578_DATUM_NEUE_TYPEN_CKD'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Datum neue Typen CKD'
,p_post_element_text=>'_10698'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080461276852703317)
,p_name=>'P578_DATUM_NEUE_TYPEN_FBU'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Datum neue Typen FBU'
,p_post_element_text=>'_10698'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080461635349703317)
,p_name=>'P578_DATUM_ALLE_FAHRZEUGE'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Datum alle Fahrzeuge'
,p_post_element_text=>'_10698'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080462086249703318)
,p_name=>'P578_DATUM_ALLE_FAHRZEUGE_CKD'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Datum alle Fahrzeuge CKD'
,p_post_element_text=>'_10698'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080462527968703318)
,p_name=>'P578_DATUM_ALLE_FAHRZEUGE_FBU'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Datum alle Fahrzeuge FBU'
,p_post_element_text=>'_10698'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080462903331703318)
,p_name=>'P578_MODELJAHR_PHASEN_START'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Modeljahr Phasen Start'
,p_post_element_text=>'_10696'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080463317339703318)
,p_name=>'P578_MODELJAHR_PHASEN_END'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Modeljahr Phasen End'
,p_post_element_text=>'_10696'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080463686877703319)
,p_name=>'P578_VORSCHRIFT_PREDESESSOR'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Vorschrift Predesessor'
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
''))
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080464105444703319)
,p_name=>'P578_PERMALINK'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Permalink'
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'_10288',
''))
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080464456224703319)
,p_name=>'P578_UMSETZUNGVERFOLGUNG'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Umsetzungverfolgung'
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'_10598',
'',
''))
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080464926755703319)
,p_name=>'P578_LAENDER'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>unistr('L\00E4nder')
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'feld_16470',
'',
''))
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select land d,  landid r  from t_land;'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080465264226703320)
,p_name=>'P578_STICHWOERTER'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>unistr('Stichw\00F6rter')
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Systemfeld',
'',
''))
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080465733053703320)
,p_name=>'P578_MFV_ID'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'MFV ID'
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'feld_11670',
'',
''))
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080466126021703320)
,p_name=>'P578_BETEILIGTE_OES'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Beteiligte OEs'
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'feld_13070',
'',
'',
''))
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080466469002703320)
,p_name=>'P578_ARBEITSKREIS'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'Arbeitskreis kurz'
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Systemfeld',
'',
'',
'',
''))
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2080466847470703320)
,p_name=>'P578_OE_LEITER'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_imp.id(924343798030487400)
,p_prompt=>'OE Leiter'
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Systemfeld',
'',
'',
'',
''))
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1577530613445546316)
,p_validation_name=>'Vorschriften-nr'
,p_validation_sequence=>10
,p_validation=>'(:P578_VORSCHRIFTENNR is not null) and (:P578_THEMA_VON_MFV is not null)'
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Vorschriftnummer und Thema von MFV m\00FCssen gef\00FCllt werden')
,p_when_button_pressed=>wwv_flow_imp.id(2080454425023703289)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1577530643841546317)
,p_validation_name=>'Jira Key'
,p_validation_sequence=>20
,p_validation=>':P578_JIRA_KEY is not null'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Jira Key muss gef\00FCllt werden')
,p_when_button_pressed=>wwv_flow_imp.id(1577530124053546311)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1577529731201546307)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Erstelle Jira Ticket'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lDaten varchar2(32000) ; ',
'  ',
'   lResponse varchar2(32000);',
'   lKey varchar2(16);',
'   lJiraid varchar2(16);',
'   lst_jira_land_code varchar2(250);',
'   lst_Ak_IDs varchar2(250);',
'begin ',
'  select listagg(jira_code, '':'') into lst_jira_land_code from T_LAND where landid in  (',
'    select column_value from table (apex_string.split_numbers( :P578_LAENDER ,'':''))',
'    );',
'    with cte_akk as ( ',
'           select column_value as ak from table (apex_string.split( :P578_ARBEITSKREIS ,'':'')) where column_value is not null',
'     )',
'    select listagg(bak.et_b_akid,'':'') within group (order by bak.et_b_akid) into lst_Ak_IDs',
'      from T_ET_B_AK bak, cte_akk  where cte_akk.ak = bak.kurz;',
'        ',
'lResponse := fErstelleJiraTicket ( ',
'         :P578_PROJEKT_ID , :P578_MFV_TYPE  ',
'        , :P578_VORSCHRIFTENNR , :P578_THEMA_VON_MFV , lst_jira_land_code  --:P578_LAENDER',
'        , lst_Ak_IDs       --:P578_ARBEITSKREIS',
'        , :P578_DESCPIPTION);',
'        ',
'    select TRIM( ''"'' from TRIM(leading ''['' from TRIM(trailing '']'' from ',
'     (select JSON_QUERY(lResponse, ''$[*].key'' with wrapper) as val from dual)',
'     ))) stri into :P578_JIRA_KEY from dual;',
'     debug('':P578_JIRA_KEY'', :P578_JIRA_KEY);',
'     ',
'     select TRIM( ''"'' from  TRIM(leading ''['' from TRIM(trailing '']'' from ',
'     (select JSON_QUERY(lResponse, ''$[*].id'' with wrapper) as val from dual)',
'     ))) stri into :P578_JIRA_ID from dual;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2080454425023703289)
,p_security_scheme=>wwv_flow_imp.id(5845833221081384791)
,p_internal_uid=>5249742047100934542
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1577530181295546312)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Lese Jira Ticket'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'select distinct jiraid,     issuetype_id,  Vorschr_Nr, ',
'     Thema ,               Beteiligte_OES         ',
'  into  ',
'    :P578_JIRA_ID, :P578_MFV_TYPE, :P578_Vorschriftennr,  :P578_THEMA_VON_MFV , :P578_BETEILIGTE_OES ',
'    from json_table (',
'                pck_ri_jira.fJiraJqlRequest('' key = "''|| :P578_JIRA_KEY|| ''"'') , ''$.issues[*]''',
'              columns (  ',
'                   jiraid varchar2(250) path ''$.id'' -- jirakey varchar2(32) path ''$.key''',
'                   --Mfv_name varchar2(250) path ''$.fields.customfield_11670'',',
'                   , Vorschr_Nr varchar2(250) path ''$.fields.customfield_19470''  --VorschNum',
'                   -- , cf10288 varchar2(250) path ''$.fields.customfield_10288''',
'                   ',
'                   --MFV_teil varchar2(250) path ''$.fields.customfield_11406.value''      --  Teil',
'                           , Thema varchar2(250) path ''$.fields.summary''            -- Thema der MfV',
'                            , Beteiligte_OES  varchar2(250) path ''$.fields.customfield_13070''   -- abteilung OE',
'                   --, Status_Umgebung    varchar2(250)  path ''$.fields.environment''        -- Umgeb',
'                   --, LinkSammelOrdner  varchar2(250) path ''$.fields.customfield_11814'',',
'                           --  , Kommentars varchar2(250) path ''$.fields.customfield_18170'' ',
'                   ',
'                   --,     varchar2(250) path ''$.fields.customfield_10698  -- attachments description',
'                    , mfvid    varchar2(250) path ''$.fields.customfield_11670''',
'                    , issuetype_id  varchar2(16) path ''$.fields.issuetype.id'', issuetype_nam  varchar2(30) path ''$.fields.issuetype.name''',
'                      ',
'                   -- ,   varchar2(250) path ''$.fields.customfield_10698',
'             )',
'    ) x;',
'    ',
' /*  ',
'    SELECT  listagg(AK_kurz, '':'') within group (order by AK_kurz) aks,',
'             listagg(labels, '', '') within group (order by labels) keywords ',
'             --, listagg(Landid, '':'') within group (order by Landid) laender',
'    into      :P578_ARBEITSKREIS,  :P578_STICHWOERTER --, :P578_LAENDER_FIELD   --, :P578_LAENDER',
'    from json_table (',
'                pck_ri_jira.fJiraJqlRequest('' key = "''|| :P578_JIRA_KEY|| ''"'') , ''$.issues[*]''',
'              columns (  ',
'                   jiraid varchar2(250) path ''$.id'', -- jirakey varchar2(32) path ''$.key''',
'                   -- cf10288 varchar2(250) path ''$.fields.customfield_10288'',',
'                    nested path ''$.fields.customfield_16470[*]''                   -- Land',
'                         columns ( Landid varchar2(100) path ''$.id'' )',
'                   --MFV_teil varchar2(250) path ''$.fields.customfield_11406.value''      --  Teil',
'                         --   Thema varchar2(250) path ''$.fields.summary''            -- Thema der MfV',
'                          --  , Beteiligte_OES  varchar2(250) path ''$.fields.customfield_13070''   -- abteilung OE',
'                   , nested path ''$.fields.components[*]''                   -- AK',
'                         columns ( AK_kurz varchar2(250) path ''$.name'',    AK_Id varchar2(250) path ''$.id'' )',
'                   ',
'                   --,     varchar2(250) path ''$.fields.customfield_10698  -- attachments description',
'                 --   , issuetype_id  varchar2(16) path ''$.fields.issuetype.id'', issuetype_nam  varchar2(30) path ''$.fields.issuetype.name''',
'',
unistr('                  , nested path ''$.fields.labels[*]''                   -- Stichw\00F6rter'),
'                            columns (  labels varchar2(250) path ''$''     )',
'             )',
'    ) ;',
' */   ',
'  /*  with cte_l as (',
'        select  column_value as jcod from table(apex_string.split_numbers(:P578_LAENDER_FIELD, '':''))',
'        )',
'        select listagg(landid, '':'') within group (order by landid) into :P578_LAENDER',
'        from t_land, cte_l where t_land.jira_code = cte_l.jcod;',
'        */',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1577530124053546311)
,p_process_when=>':P578_JIRA_KEY is not null'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'SQL'
,p_internal_uid=>5249742497194934547
);
wwv_flow_imp.component_end;
end;
/
