prompt --application/pages/page_00701
begin
--   Manifest
--     PAGE: 00701
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>701
,p_name=>'MS Parameter Report'
,p_alias=>'MS-PARAMETER-REPORT'
,p_step_title=>'MS Parameter Report'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.col .rel-col {',
'    width: 30%;',
'    float: left;',
'',
'}',
'',
'',
'/* #IG1 .a-IRR-headerLink[data-fht-column-idx="19"],',
'#IG1 .a-IRR-headerLink[data-fht-column-idx="22"],',
'#IG1 .a-IRR-headerLink[data-fht-column-idx="25"],',
'#IG1 .a-IRR-headerLink[data-fht-column-idx="27"],',
'#IG1 .a-IRR-headerLink[data-fht-column-idx="45"],',
'#IG1 .a-IRR-headerLink[data-fht-column-idx="48"],',
'#IG1 .a-IRR-headerLink[data-fht-column-idx="52"],',
'#IG1 .a-IRR-headerLink[data-fht-column-idx="54"] {',
'    background-color: darkred !important;',
'    color: black;',
'}',
' */',
' /* #FFFF00 - yellow */',
'',
'/* th#SVS, th#SVE, th#EVS, th#EVE, th#SVD, th#SVN, th#SVA, th#AKL {',
'   background-color: #bb0a31 !important;',
'   color: white !important; ',
'} */',
'',
'',
'th#IR1 {',
'    background-color: #bb0a31 !important;',
'}',
'',
'',
'/* th#IR1 a {',
'    color: lightgrey !important;',
'} */',
'',
'',
'',
'th#IR2, th#IR3 {',
'   background-color: #FFFF00 !important;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2386433562243780389)
,p_plug_name=>'MS Parameter'
,p_region_name=>'IG1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ausgabe as(',
'    select pra.ms_parameterID ms_parameterID , --aut.ms_ausgabe_textid ms_ausgabe_textid,',
'    listagg(aut.ausgabe_text, '', '') within group (order by aut.ausgabe_text)  as ausgabe_text ',
'    from  T_MS_PARAMETER_REF_AUSGABE pra',
'    join T_MS_AUSGABE_TEXT aut on ( aut.ms_ausgabe_textid = pra.ms_ausgabe_textid) ',
' group by pra.ms_parameterID',
'   ',
')',
', bild as(',
'    select prb.ms_parameterID ms_parameterID, --bi.ms_bildid ms_bildid, ',
'   /* listagg(bi.bild_nummer, '', '') within group (order by bi.bild_nummer)  bild_nummer ,',
'    case when :FSP_LANGUAGE_PREFERENCE = ''de'' and bi.bezeichnung is not null then bi.bezeichnung',
'     when :FSP_LANGUAGE_PREFERENCE = ''en'' and bi.name_eng is not null then bi.name_eng else to_char(bi.bild_nummer) end bild_name,*/',
'    listagg( ',
'    ''<a href="'' ||  apex_page.get_url(p_page => 2010, p_clear_cache => ''2010,RP'', p_items => ''P2010_BILD_NUMMER'', p_values => bild_nummer ) || ',
'    ''"><span >'' || case when :FSP_LANGUAGE_PREFERENCE = ''de'' and bi.bezeichnung is not null then bi.bezeichnung',
'     when :FSP_LANGUAGE_PREFERENCE = ''en'' and bi.name_eng is not null then bi.name_eng else to_char(bi.bild_nummer) end  ||''</span></a>'', '', '') within group (order by bi.bild_nummer)  as bild_link',
'',
'    from T_MS_PARAMETER_REF_BILD prb',
'    join T_MS_BILD bi on (prb.ms_bildid = bi.ms_bildid)',
'    group by  prb.ms_parameterID --, bi.bezeichnung, bi.name_eng, bi.bild_nummer',
')',
'SELECT p.MS_PARAMETERID as MS_PARAMETERID, ',
'    to_char(NUMMER) NUMMER, ',
'    BEMERKUNG , ',
'	VERNETZUNGSART, ',
'	FAHRZEUGZULASSUNG,',
'    FAHRZEUGKLASSE, ',
'	THEMENGEBIET,',
'    LAND, ',
'    a.ausgabe_text, --b.bild_nummer,',
'	DATUMSANGABEN_ORIGINAL_VERNETZUNG,',
'    VORSCHRIFTEN_TYP',
'  , FBU_CKD_RELEVANTES_LAND',
'  , PARAMETER_CKD_FBU_DATUM',
'  , decode(p.PARAMETER_MJ_DATUMSFORMAT, ',
'       10, emano_util.fLang(''Datum'', ''Date''),',
'       20, emano_util.fLang(''Jahreszahl'', ''Year''),',
'       30, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'       null',
'            ) as PARAMETER_MJ_DATUMSFORMAT  -- 10-> SOP   20 -> MJ    30 -> nicht relevant',
'    , decode(p.SUPPLEMENT,',
'                1, emano_util.fLang(''ja'', ''yes''),',
'                0, emano_util.fLang(''nein'', ''No''),',
'                2, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'                null',
'            ) as SUPPLEMENT',
'    , decode(upper(p.INTERNER_DB_STATUS),',
'                        20, emano_util.fLang(''Sichtbar in Regulation Index DB'', ''Visible in Regulation Index DB''),',
unistr('                        10, emano_util.fLang(''nicht relevant f\00FCr Audi AG; in Bearbeitung; Import is running'', ''not relevant for Audi AG; in process; import is running''),'),
'                        30, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'                        null',
'            ) as INTERNER_DB_STATUS',
'    , decode( p.STATUS, 20, ''Draft'',  ',
'                40, ''Enacted'', 30, ''Final document'', ',
'                50, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'                60, ''Draft, Final document'', '''') as STATUS',
'    , decode(p.PROGNOSE_QUALITAET,',
'                        0, emano_util.fLang(''offen'', ''open''),',
'                        10, emano_util.fLang(''sicher'', ''certain''),',
unistr('                        20, emano_util.fLang(''absch\00E4tzbar'', ''estimable''),'),
unistr('                        30, emano_util.fLang(''best\00E4tigt'', ''confirmed''),'),
'                        40, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'                        50, emano_util.fLang(''leer'', ''empty''), '''' ) as PROGNOSE_QUALITAET',
'  , QUELLVORSCHRIFT_GUELTIG',
'    , decode(p.SOP_IST_VOR_DATUM_IN_KRAFT,   0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as SOP_IST_VOR_DATUM_IN_KRAFT',
'  , decode(p.SOP_GLEICH_ODER_NACH_DATUM_IN_KRAFT,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as SOP_GLEICH_ODER_NACH_DATUM_IN_KRAFT  ',
'  ,	decode(p.SOP_IST_VOR_DATUM_NEUE_TYPEN,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as  SOP_IST_VOR_DATUM_NEUE_TYPEN',
'  , decode(p.SOP_IST_NACH_ODER_GLEICH_DATUM_NEUE_TYPEN,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as SOP_IST_NACH_ODER_GLEICH_DATUM_NEUE_TYPEN',
'	, decode(p.SOP_IST_VOR_DATUM_ALLE_FAHRZEUGE,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as   SOP_IST_VOR_DATUM_ALLE_FAHRZEUGE',
'	, decode(p.SOP_IST_NACH_ODER_GLECIH_DATUM_ALLE_FAHRZEUGE_ ,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as SOP_IST_NACH_ODER_GLECIH_DATUM_ALLE_FAHRZEUGE_',
'  , decode(p.SOP_IST_VOR_DATUM_AUSSER_KRAFT ,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as  SOP_IST_VOR_DATUM_AUSSER_KRAFT',
'  , decode(p.SOP_IST_NACH_ODER_GLEICH_DATUM_AUSSER_KRAFT,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as   SOP_IST_NACH_ODER_GLEICH_DATUM_AUSSER_KRAFT',
'	, decode(p.EOP_LIEGT_VOR_DATUM_ALLE_FAHRZEUGE ,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as  EOP_LIEGT_VOR_DATUM_ALLE_FAHRZEUGE',
'	, decode(p.EOP_LIEGT_NACH_ODER_GLEICH_DATUM_ALLE_FAHRZEUGE ,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as  EOP_LIEGT_NACH_ODER_GLEICH_DATUM_ALLE_FAHRZEUGE',
'	, decode(p.EOP_LIEGT_VOR_DATUM_IN_KRAFT,   0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''')  as   EOP_LIEGT_VOR_DATUM_IN_KRAFT',
'	, decode(p.EOP_LIEGT_NACH_ODER_GLEICH_DATUM_IN_KRAFT,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as EOP_LIEGT_NACH_ODER_GLEICH_DATUM_IN_KRAFT ',
'   ',
'',
'    , DECODE(p.HOEHERE_SERIE_MOEGLICH,',
'    0,emano_util.fLang(''nein'', ''no''),',
'    1, emano_util.fLang(''ja'', ''yes''),',
'    2, emano_util.fLang(''nicht relevant'',''not relevant''),',
'    null',
'    ) as HOEHERE_SERIE_MOEGLICH',
'  , case p.DECKELUNG_DER_HOEHEREN_SERIE ',
unistr('  WHEN 1 THEN emano_util.fLang(''Kleiner oder gleich "Letzte m\00F6gliche Vorschrift zur Homologation"'', ''Less than or equal to "Last possible regulation for homologation"'')'),
unistr('    WHEN 2 THEN emano_util.fLang(''Gr\00F6\00DFer "Letzte m\00F6gliche Vorschrift zur Homologation"'', ''Greater than "Last possible regulation for homologation"'')'),
'    WHEN 0 THEN emano_util.fLang(''nicht relevant'', ''not relevant'') else  null end as DECKELUNG_DER_HOEHEREN_SERIE',
'  ',
'  	,decode(p.SOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS,   0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as SOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS  ',
'	,decode(p.SOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as SOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS   ',
'	,decode(p.EOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS,   0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as  EOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS  ',
'	,decode(p.EOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as EOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS   ',
'   ',
'	, decode(p.NACHFOLGER_ANZEIGEN, 1, emano_util.fLang(''ja'', ''yes''),  0,  emano_util.fLang(''nein'', ''no''), 2, emano_util.fLang(''nicht relevant'', ''not relevant''),    null) as NACHFOLGER_ANZEIGEN',
'    ',
'',
'	, decode(p.LESENDE_TABELLE_FUER_DATUMSANGABEN,',
'                                1, emano_util.fLang(''Vorschrift'', ''Regulation''),',
'                                2, emano_util.fLang(''Vernetzungstabelle'', ''Networkingtable''),',
'                                0, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'                                null',
'                            ) LESENDE_TABELLE_FUER_DATUMSANGABEN ',
'	--,AUSGABE_FUER_ANDERES_TOOL_ODER_FUER_MENSCH ',
'    ',
'',
'    , VERNETZUNGSARTID',
'   ',
'',
'  ',
'    ',
'',
'    -- ,DECODE(p.AUSSER_KRAFT_IST_LEER, 0, ''false'' , 1, ''true'' , 2, ''nicht relevant'', 3, ''relevant'', '''') as AUSSER_KRAFT_IST_LEER',
'    , DECODE(p.AUSSER_KRAFT_IST_LEER, ',
'        10, ''existiert'',',
'        --0, ''fehlt'',',
'        20, ''nicht relevant'',',
'        '''') as AUSSER_KRAFT_IST_LEER',
'',
'',
'    ,DECODE(p.ALLE_FAHRZEUGE_RELEVANT_EOP, ',
'        10, ''existiert'',',
'        0, ''fehlt'',',
'        20, ''nicht relevant'',',
'        '''') as ALLE_FAHRZEUGE_RELEVANT_EOP',
'',
'    , SEARCH_MODE',
'     ',
'',
'    , DECODE(p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE,',
'    1, emano_util.fLang(''ja'', ''yes''),',
'    0, emano_util.fLang(''nein'', ''no''),',
'    2, emano_util.fLang(''nicht relevant'', ''not relevant'')) as AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE',
'',
'    ,DECODE(p.MJ_EINSATZ_JAHR_KLEINER_PHASEIN_START_JAHR, 0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_EINSATZ_JAHR_KLEINER_PHASEIN_START_JAHR',
'        ,DECODE(p.MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_START_JAHR, 0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', 3, ''serie'', '''') as MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_START_JAHR',
'        ,DECODE(p.MJ_EINSATZ_JAHR_KLEINER_PHASEIN_ENDE_JAHR, 0, ''false'' , 1, ''true'' , 2, ''nicht relevant'', '''') as MJ_EINSATZ_JAHR_KLEINER_PHASEIN_ENDE_JAHR',
'        ,DECODE(p.MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_ENDE_JAHR, 0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_ENDE_JAHR',
'        ,DECODE(p.MJ_EINSATZ_JAHR_KLEINER_GLEICH_AUSSER_KRAFT_JAHR, 0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_EINSATZ_JAHR_KLEINER_GLEICH_AUSSER_KRAFT_JAHR',
'        ,DECODE(p.MJ_EINSATZ_JAHR_GROESSER_AUSSER_KRAFT_JAHR, 0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_EINSATZ_JAHR_GROESSER_AUSSER_KRAFT_JAHR',
'',
'',
'     , decode(p.MJ_SOP_VOR_PHASEIN_START_OR_PHASEIN_LEER,   0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_SOP_VOR_PHASEIN_START_OR_PHASEIN_LEER',
'    , decode(p.MJ_SOP_NACH_PHASEIN_START,  0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_SOP_NACH_PHASEIN_START',
'    , decode(p.MJ_SOP_VOR_PHASEIN_END_OR_PHASEIN_LEER,   0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_SOP_VOR_PHASEIN_END_OR_PHASEIN_LEER',
'     , decode(p.MJ_SOP_NACH_PHASEIN_END,   0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_SOP_NACH_PHASEIN_END',
'     , decode(p.MJ_EOP_VOR_PHASEIN_START_OR_PHASEIN_LEER,  0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_EOP_VOR_PHASEIN_START_OR_PHASEIN_LEER',
'     , decode(p.MJ_EOP_NACH_PHASEIN_START,  0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_EOP_NACH_PHASEIN_START',
'     , decode(p.MJ_EOP_VOR_PHASEIN_END_OR_PHASEIN_LEER,  0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_EOP_VOR_PHASEIN_END_OR_PHASEIN_LEER',
'     , decode(p.MJ_EOP_NACH_PHASEIN_END,  0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_EOP_NACH_PHASEIN_END',
'     , decode(p.MJ_SOP_VOR_ODER_GLEICH_AUSSER_KRAFT,  0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_SOP_VOR_ODER_GLEICH_AUSSER_KRAFT',
'    , decode(p.MJ_SOP_NACH_AUSSER_KRAFT,   0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_SOP_NACH_AUSSER_KRAFT',
'    ,bild_link bild_name',
'    ',
'    , DECODE(p.PHASE_IN_RELEVANT, ',
'        -- 10, ''relevant'',',
'        -- 0, ''nicht relevant'',',
'         10, ''existiert'',',
'        0, ''fehlt'',',
'        20, ''nicht relevant'',',
'',
'        '''') as PHASE_IN_RELEVANT',
'',
'       ,DECODE(p.PHASE_OUT_RELEVANT, ',
'        -- 10, emano_util.fLang(''relevant'', ''relevant''),',
'        -- 0, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'        10, ''existiert'',',
'        0, ''fehlt'',',
'        20, ''nicht relevant'',',
'',
'        '''') as PHASE_OUT_RELEVANT',
'',
'    ,DECODE(p.IN_KRAFT_RELEVANT, ',
'        10, emano_util.fLang(''existiert'', ''existiert''),',
'        0, emano_util.fLang(''fehlt'', ''fehlt''),',
'        20, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'        '''') as IN_KRAFT_RELEVANT',
'',
'       ,DECODE(p.NEUE_TYPEN_RELEVANT, ',
'        10, emano_util.fLang(''existiert'', ''existiert''),',
'        0, emano_util.fLang(''fehlt'', ''fehlt''),',
'        20, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'        '''') as NEUE_TYPEN_RELEVANT',
'        ',
' ,DECODE(p.ALLE_FAHRZEUGE_RELEVANT, ',
'        10, emano_util.fLang(''existiert'', ''existiert''),',
'        0, emano_util.fLang(''fehlt'', ''fehlt''),',
'        20, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'        '''') as ALLE_FAHRZEUGE_RELEVANT',
'',
', DECODE(p.DATUM_MJ_STATUS, ',
'        1, emano_util.fLang(''datum'', ''date''),',
'        2, emano_util.fLang(''model jahr'', ''model year''),',
'        3, emano_util.fLang(''alle'', ''all'')) as DATUM_MJ_STATUS',
',p.LETZTE_AENDERUNG_DATUM',
'-- ,p.LETZTE_AENDERUNG_BENUTZERID,',
',benutzer.nachname || '', '' || benutzer.vorname AS LETZTE_AENDERUNG_BENUTZER',
',:P701_START_TYP as status_type',
'',
'FROM T_MS_PARAMETER p',
' left outer join ausgabe a on (a.MS_PARAMETERID = p.MS_PARAMETERID)   -- (a.ms_ausgabe_textid = pra.ms_ausgabe_textid)',
' left outer join Bild b on (b.MS_PARAMETERID = p.MS_PARAMETERID)',
' --where (:P701_REGEL_NUMMER is not null and nummer = :P701_REGEL_NUMMER) or (:P701_REGEL_NUMMER is null and nummer is not null)',
' LEFT outer JOIN T_BENUTZER benutzer ON benutzer.benutzerid = p.LETZTE_AENDERUNG_BENUTZERID',
'',
'WHERE ',
'    (',
'        -- If "alle" is selected',
'        (:P701_START_TYP = 0) ',
'        OR ',
'        -- If "Datum" is selected',
'        (:P701_START_TYP = 10 AND DATUM_MJ_STATUS = 1) ',
'        OR ',
'        -- If "ModelJahr" is selected',
'        (:P701_START_TYP = 20 AND DATUM_MJ_STATUS = 2) ',
'       ',
'    )',
'ORDER BY nummer;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P701_START_TYP'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'MS Parameter'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2386433977040780389)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:706:&SESSION.::&DEBUG.:RP,:P706_MS_PARAMETERID,P706_NUMMER:\#MS_PARAMETERID#\,#NUMMER#'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>6058646292940168624
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037610757459382564)
,p_db_column_name=>'MS_PARAMETERID'
,p_display_order=>0
,p_column_identifier=>'A'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:705:&SESSION.::&DEBUG.:705:P705_MS_PARAMETERID,P705_START_TYP:#MS_PARAMETERID#,#STATUS_TYPE#'
,p_column_linktext=>'<span class="fa fa-pencil" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037610390445382563)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037609951796382563)
,p_db_column_name=>'VERNETZUNGSART'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Vernetzungsart'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037609589245382562)
,p_db_column_name=>'FAHRZEUGZULASSUNG'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Fahrzeugzulassung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037609193875382562)
,p_db_column_name=>'FAHRZEUGKLASSE'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Fahrzeugart'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037608807122382561)
,p_db_column_name=>'THEMENGEBIET'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Themengebiet'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037608391485382561)
,p_db_column_name=>'LAND'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037607948575382560)
,p_db_column_name=>'AUSGABE_TEXT'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Ausgabe Text'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037607599151382559)
,p_db_column_name=>'DATUMSANGABEN_ORIGINAL_VERNETZUNG'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Datumsangaben Original Vernetzung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037607170740382558)
,p_db_column_name=>'VORSCHRIFTEN_TYP'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Vorschriften Typ'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037606785244382558)
,p_db_column_name=>'FBU_CKD_RELEVANTES_LAND'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'FBU CKD relevantes Land'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037606403161382557)
,p_db_column_name=>'PARAMETER_CKD_FBU_DATUM'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Parameter CKD FBU Datum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037631885566382593)
,p_db_column_name=>'PARAMETER_MJ_DATUMSFORMAT'
,p_display_order=>24
,p_column_identifier=>'AZ'
,p_column_label=>'Parameter MJ Datumsformat'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037605919366382556)
,p_db_column_name=>'QUELLVORSCHRIFT_GUELTIG'
,p_display_order=>34
,p_column_identifier=>'O'
,p_column_label=>unistr('Quellvorschrift g\00FCltig')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037631049979382592)
,p_db_column_name=>'SUPPLEMENT'
,p_display_order=>44
,p_column_identifier=>'BB'
,p_column_label=>'Supplement'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037632685815382595)
,p_db_column_name=>'INTERNER_DB_STATUS'
,p_display_order=>54
,p_column_identifier=>'AX'
,p_column_label=>'Interner DB Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037632270414382593)
,p_db_column_name=>'STATUS'
,p_display_order=>64
,p_column_identifier=>'AY'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037631440749382592)
,p_db_column_name=>'PROGNOSE_QUALITAET'
,p_display_order=>74
,p_column_identifier=>'BA'
,p_column_label=>unistr('Prognose Qualit\00E4t')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037619043063382576)
,p_db_column_name=>'IN_KRAFT_RELEVANT'
,p_display_order=>84
,p_column_identifier=>'CJ'
,p_column_label=>'In Kraft Relevant'
,p_column_type=>'STRING'
,p_static_id=>'IR2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037629914310382591)
,p_db_column_name=>'SOP_IST_VOR_DATUM_IN_KRAFT'
,p_display_order=>94
,p_column_identifier=>'BE'
,p_column_label=>'SOP ist Vor Datum In Kraft'
,p_column_type=>'STRING'
,p_static_id=>'IR1'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
,p_column_comment=>'SOP ist Vor Datum In Kraft ODER In Kraft Datum ist leer'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037629437558382590)
,p_db_column_name=>'SOP_GLEICH_ODER_NACH_DATUM_IN_KRAFT'
,p_display_order=>104
,p_column_identifier=>'BF'
,p_column_label=>'SOP gleich oder Nach Datum In Kraft'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037618700279382576)
,p_db_column_name=>'NEUE_TYPEN_RELEVANT'
,p_display_order=>114
,p_column_identifier=>'CK'
,p_column_label=>'Neue Typen Relevant'
,p_column_type=>'STRING'
,p_static_id=>'IR2'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037623834932382583)
,p_db_column_name=>'SOP_IST_VOR_DATUM_NEUE_TYPEN'
,p_display_order=>124
,p_column_identifier=>'BU'
,p_column_label=>'SOP ist vor Datum Neue Typen'
,p_column_type=>'STRING'
,p_static_id=>'IR1'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
,p_column_comment=>'SOP ist vor Datum Neue Typen ODER in Kraft Datum ist leer'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037629115817382590)
,p_db_column_name=>'SOP_IST_NACH_ODER_GLEICH_DATUM_NEUE_TYPEN'
,p_display_order=>134
,p_column_identifier=>'BH'
,p_column_label=>'SOP Ist nach oder gleich Datum Neue Typen'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037618225023382575)
,p_db_column_name=>'ALLE_FAHRZEUGE_RELEVANT'
,p_display_order=>144
,p_column_identifier=>'CL'
,p_column_label=>'Alle Fahrzeuge Relevant'
,p_column_type=>'STRING'
,p_static_id=>'IR2'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037628664993382589)
,p_db_column_name=>'SOP_IST_VOR_DATUM_ALLE_FAHRZEUGE'
,p_display_order=>154
,p_column_identifier=>'BI'
,p_column_label=>'SOP Ist Vor Datum Alle Fahrzeuge'
,p_column_type=>'STRING'
,p_static_id=>'IR1'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
,p_column_comment=>'SOP Ist Vor Datum Alle Fahrzeuge ODER in Kraft Datum ist leer'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037628273117382589)
,p_db_column_name=>'SOP_IST_NACH_ODER_GLECIH_DATUM_ALLE_FAHRZEUGE_'
,p_display_order=>164
,p_column_identifier=>'BJ'
,p_column_label=>'SOP Ist Nach oder gleich Datum Alle Fahrzeuge'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037627856683382588)
,p_db_column_name=>'SOP_IST_VOR_DATUM_AUSSER_KRAFT'
,p_display_order=>174
,p_column_identifier=>'BK'
,p_column_label=>unistr('SOP ist vor Datum Au\00DFer Kraft')
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037627436481382588)
,p_db_column_name=>'SOP_IST_NACH_ODER_GLEICH_DATUM_AUSSER_KRAFT'
,p_display_order=>184
,p_column_identifier=>'BL'
,p_column_label=>unistr('SOP ist nach oder gleich Datum Au\00DFer Kraft')
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037627088776382587)
,p_db_column_name=>'EOP_LIEGT_VOR_DATUM_ALLE_FAHRZEUGE'
,p_display_order=>194
,p_column_identifier=>'BM'
,p_column_label=>'EOP liegt vor Datum Alle Fahrzeuge'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037626711534382587)
,p_db_column_name=>'EOP_LIEGT_NACH_ODER_GLEICH_DATUM_ALLE_FAHRZEUGE'
,p_display_order=>204
,p_column_identifier=>'BN'
,p_column_label=>'EOP liegt nach oder gleich Datum Alle Fahrzeuge'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037626219792382586)
,p_db_column_name=>'EOP_LIEGT_VOR_DATUM_IN_KRAFT'
,p_display_order=>214
,p_column_identifier=>'BO'
,p_column_label=>'EOP liegt vor Datum in Kraft'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037625838142382586)
,p_db_column_name=>'EOP_LIEGT_NACH_ODER_GLEICH_DATUM_IN_KRAFT'
,p_display_order=>224
,p_column_identifier=>'BP'
,p_column_label=>'EOP liegt nach oder gleich Datum in Kraft'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037617827474382575)
,p_db_column_name=>'HOEHERE_SERIE_MOEGLICH'
,p_display_order=>234
,p_column_identifier=>'CM'
,p_column_label=>unistr('H\00F6here Serie M\00F6glich')
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037625475580382585)
,p_db_column_name=>'SOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS'
,p_display_order=>244
,p_column_identifier=>'BQ'
,p_column_label=>'SOP ist vor Datum In Kraft des Nachfolgers'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037625023500382585)
,p_db_column_name=>'SOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS'
,p_display_order=>254
,p_column_identifier=>'BR'
,p_column_label=>'SOP Ist gleich oder nach Datum In Kraft des Nachfolgers'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037624673594382584)
,p_db_column_name=>'EOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS'
,p_display_order=>264
,p_column_identifier=>'BS'
,p_column_label=>'EOP ist vor Datum in Kraft des Nachfolgers'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037624243678382584)
,p_db_column_name=>'EOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS'
,p_display_order=>274
,p_column_identifier=>'BT'
,p_column_label=>'EOP ist gleich oder nach Datum In Kraft des Nachfolgers'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037630249696382591)
,p_db_column_name=>'NACHFOLGER_ANZEIGEN'
,p_display_order=>284
,p_column_identifier=>'BD'
,p_column_label=>'Nachfolger anzeigen'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037605122925382554)
,p_db_column_name=>'LESENDE_TABELLE_FUER_DATUMSANGABEN'
,p_display_order=>294
,p_column_identifier=>'AI'
,p_column_label=>unistr('Lesende Tabelle f\00FCr Datumsangaben')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037630631911382591)
,p_db_column_name=>'AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE'
,p_display_order=>304
,p_column_identifier=>'BC'
,p_column_label=>'Vorschriften Ausgabe Positiv liste vs negativ liste '
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037605534880382555)
,p_db_column_name=>'DECKELUNG_DER_HOEHEREN_SERIE'
,p_display_order=>324
,p_column_identifier=>'AC'
,p_column_label=>unistr('Deckelung der H\00F6heren Serie')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037611589444382565)
,p_db_column_name=>'VERNETZUNGSARTID'
,p_display_order=>334
,p_column_identifier=>'AL'
,p_column_label=>'Vernetzungsartid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037611185679382564)
,p_db_column_name=>'SEARCH_MODE'
,p_display_order=>344
,p_column_identifier=>'AP'
,p_column_label=>'Such Modus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037623461894382583)
,p_db_column_name=>'MJ_SOP_VOR_PHASEIN_START_OR_PHASEIN_LEER'
,p_display_order=>354
,p_column_identifier=>'BV'
,p_column_label=>'SOP vor Phase in Start'
,p_column_type=>'STRING'
,p_static_id=>'IR1'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
,p_column_comment=>'SOP vor Phase in Start ODER Phase in Start ist leer'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037623019344382583)
,p_db_column_name=>'MJ_SOP_NACH_PHASEIN_START'
,p_display_order=>364
,p_column_identifier=>'BW'
,p_column_label=>'SOP nach Phase in Start'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037622667242382582)
,p_db_column_name=>'MJ_SOP_VOR_PHASEIN_END_OR_PHASEIN_LEER'
,p_display_order=>374
,p_column_identifier=>'BX'
,p_column_label=>'SOP vor Phase in End'
,p_column_type=>'STRING'
,p_static_id=>'IR1'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
,p_column_comment=>'SOP vor Phase in End ODER Phase in ist leer'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037622291976382582)
,p_db_column_name=>'MJ_SOP_NACH_PHASEIN_END'
,p_display_order=>384
,p_column_identifier=>'BY'
,p_column_label=>'SOP nach Phase in  End'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037621910220382581)
,p_db_column_name=>'MJ_EOP_VOR_PHASEIN_START_OR_PHASEIN_LEER'
,p_display_order=>394
,p_column_identifier=>'BZ'
,p_column_label=>'EOP vor Phase in Start'
,p_column_type=>'STRING'
,p_static_id=>'IR1'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
,p_column_comment=>'EOP vor Phase in Start ODER Phase in Start ist leer'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037621494226382581)
,p_db_column_name=>'MJ_EOP_NACH_PHASEIN_START'
,p_display_order=>404
,p_column_identifier=>'CA'
,p_column_label=>'EOP nach Phase in Start'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037621064921382580)
,p_db_column_name=>'MJ_EOP_VOR_PHASEIN_END_OR_PHASEIN_LEER'
,p_display_order=>414
,p_column_identifier=>'CB'
,p_column_label=>'EOP vor Phase in End'
,p_column_type=>'STRING'
,p_static_id=>'IR1'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
,p_column_comment=>'EOP vor Phase in End ODER Phase in ist leer'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037620625948382579)
,p_db_column_name=>'MJ_EOP_NACH_PHASEIN_END'
,p_display_order=>424
,p_column_identifier=>'CC'
,p_column_label=>'EOP nach Phase in  End'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037620257151382579)
,p_db_column_name=>'MJ_SOP_VOR_ODER_GLEICH_AUSSER_KRAFT'
,p_display_order=>434
,p_column_identifier=>'CD'
,p_column_label=>unistr('SOP vor Oder gleich Au\00DFer Kraft')
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037619848523382578)
,p_db_column_name=>'MJ_SOP_NACH_AUSSER_KRAFT'
,p_display_order=>444
,p_column_identifier=>'CE'
,p_column_label=>unistr('SOP nach Au\00DFer Kraft')
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037619431807382577)
,p_db_column_name=>'BILD_NAME'
,p_display_order=>454
,p_column_identifier=>'CF'
,p_column_label=>'Bild Name'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037617458605382574)
,p_db_column_name=>'MJ_EINSATZ_JAHR_KLEINER_PHASEIN_START_JAHR'
,p_display_order=>464
,p_column_identifier=>'CN'
,p_column_label=>'Mj Einsatz Jahr Kleiner Phasein Start Jahr'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037617041808382573)
,p_db_column_name=>'MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_START_JAHR'
,p_display_order=>474
,p_column_identifier=>'CO'
,p_column_label=>unistr('Mj Einsatz Jahr Gr\00F6\00DFer Gleich Phasein Start Jahr')
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037616700309382572)
,p_db_column_name=>'MJ_EINSATZ_JAHR_KLEINER_PHASEIN_ENDE_JAHR'
,p_display_order=>484
,p_column_identifier=>'CP'
,p_column_label=>'Mj Einsatz Jahr Kleiner Phasein Ende Jahr'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037616223558382572)
,p_db_column_name=>'MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_ENDE_JAHR'
,p_display_order=>494
,p_column_identifier=>'CQ'
,p_column_label=>unistr('Mj Einsatz Jahr Gr\00F6\00DFer Gleich Phasein Ende Jahr')
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037615870101382571)
,p_db_column_name=>'MJ_EINSATZ_JAHR_KLEINER_GLEICH_AUSSER_KRAFT_JAHR'
,p_display_order=>504
,p_column_identifier=>'CR'
,p_column_label=>unistr('Mj Einsatz Jahr Kleiner Gleich Au\00DFer Kraft Jahr')
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037615455946382571)
,p_db_column_name=>'MJ_EINSATZ_JAHR_GROESSER_AUSSER_KRAFT_JAHR'
,p_display_order=>514
,p_column_identifier=>'CS'
,p_column_label=>unistr('Mj Einsatz Jahr Gr\00F6\00DFer Au\00DFer Kraft Jahr')
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037615052224382570)
,p_db_column_name=>'PHASE_IN_RELEVANT'
,p_display_order=>524
,p_column_identifier=>'CT'
,p_column_label=>'Phase In Relevant'
,p_column_type=>'STRING'
,p_static_id=>'IR3'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037614703023382570)
,p_db_column_name=>'PHASE_OUT_RELEVANT'
,p_display_order=>534
,p_column_identifier=>'CU'
,p_column_label=>'Phase Out Relevant'
,p_column_type=>'STRING'
,p_static_id=>'IR3'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037614305856382569)
,p_db_column_name=>'DATUM_MJ_STATUS'
,p_display_order=>544
,p_column_identifier=>'CV'
,p_column_label=>'Datum Mj Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037613861568382568)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>554
,p_column_identifier=>'CW'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037613450404382568)
,p_db_column_name=>'STATUS_TYPE'
,p_display_order=>564
,p_column_identifier=>'CY'
,p_column_label=>'Status Type'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037613081691382567)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>574
,p_column_identifier=>'CZ'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037612789167382567)
,p_db_column_name=>'AUSSER_KRAFT_IST_LEER'
,p_display_order=>584
,p_column_identifier=>'DA'
,p_column_label=>'Ausser Kraft Ist Leer'
,p_column_type=>'STRING'
,p_static_id=>'IR1'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037612411239382566)
,p_db_column_name=>'ALLE_FAHRZEUGE_RELEVANT_EOP'
,p_display_order=>594
,p_column_identifier=>'DB'
,p_column_label=>'Alle Fahrzeuge Relevant EOP'
,p_column_type=>'STRING'
,p_static_id=>'IR2'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P701_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1037611953911382565)
,p_db_column_name=>'NUMMER'
,p_display_order=>604
,p_column_identifier=>'DC'
,p_column_label=>'Nummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2386449375133790765)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'7895367'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'MS_PARAMETERID:NUMMER:BILD_NAME:BEMERKUNG:VERNETZUNGSART:FAHRZEUGZULASSUNG:FAHRZEUGKLASSE:THEMENGEBIET:LAND:DATUMSANGABEN_ORIGINAL_VERNETZUNG:VORSCHRIFTEN_TYP:FBU_CKD_RELEVANTES_LAND:PARAMETER_CKD_FBU_DATUM:PARAMETER_MJ_DATUMSFORMAT:SUPPLEMENT:INTERN'
||'ER_DB_STATUS:STATUS:PROGNOSE_QUALITAET:IN_KRAFT_RELEVANT:SOP_IST_VOR_DATUM_IN_KRAFT:SOP_GLEICH_ODER_NACH_DATUM_IN_KRAFT:NEUE_TYPEN_RELEVANT:SOP_IST_VOR_DATUM_NEUE_TYPEN:SOP_IST_NACH_ODER_GLEICH_DATUM_NEUE_TYPEN:ALLE_FAHRZEUGE_RELEVANT:SOP_IST_VOR_DAT'
||'UM_ALLE_FAHRZEUGE:SOP_IST_NACH_ODER_GLECIH_DATUM_ALLE_FAHRZEUGE_:AUSSER_KRAFT_IST_LEER:SOP_IST_VOR_DATUM_AUSSER_KRAFT:SOP_IST_NACH_ODER_GLEICH_DATUM_AUSSER_KRAFT:ALLE_FAHRZEUGE_RELEVANT_EOP:EOP_LIEGT_VOR_DATUM_ALLE_FAHRZEUGE:EOP_LIEGT_NACH_ODER_GLEIC'
||'H_DATUM_ALLE_FAHRZEUGE:EOP_LIEGT_VOR_DATUM_IN_KRAFT:EOP_LIEGT_NACH_ODER_GLEICH_DATUM_IN_KRAFT:HOEHERE_SERIE_MOEGLICH:SOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS:SOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS:EOP_IST_VOR_DATUM_IN_KRAFT_DES_NAC'
||'HFOLGERS:EOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS:NACHFOLGER_ANZEIGEN:LESENDE_TABELLE_FUER_DATUMSANGABEN:AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE:QUELLVORSCHRIFT_GUELTIG:PHASE_IN_RELEVANT:MJ_SOP_VOR_PHASEIN_START_OR_PHASEIN_LEER:MJ_S'
||'OP_NACH_PHASEIN_START:MJ_SOP_VOR_PHASEIN_END_OR_PHASEIN_LEER:MJ_SOP_NACH_PHASEIN_END:PHASE_OUT_RELEVANT:MJ_EOP_VOR_PHASEIN_START_OR_PHASEIN_LEER:MJ_EOP_NACH_PHASEIN_START:MJ_EOP_VOR_PHASEIN_END_OR_PHASEIN_LEER:MJ_EOP_NACH_PHASEIN_END:MJ_SOP_VOR_ODER_'
||'GLEICH_AUSSER_KRAFT:MJ_SOP_NACH_AUSSER_KRAFT:MJ_EINSATZ_JAHR_KLEINER_PHASEIN_START_JAHR:MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_START_JAHR:MJ_EINSATZ_JAHR_KLEINER_PHASEIN_ENDE_JAHR:MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_ENDE_JAHR:MJ_EINSATZ_JAHR_KLE'
||'INER_GLEICH_AUSSER_KRAFT_JAHR:MJ_EINSATZ_JAHR_GROESSER_AUSSER_KRAFT_JAHR:DATUM_MJ_STATUS:LETZTE_AENDERUNG_DATUM:LETZTE_AENDERUNG_BENUTZER:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1037604436579382531)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2386433562243780389)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:706:&SESSION.::&DEBUG.:706'
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1037604040880382529)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2386433562243780389)
,p_button_name=>'CREATE_RECORDS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1037598583778382491)
,p_branch_name=>'Go to Page 705'
,p_branch_action=>'f?p=&APP_ID.:705:&SESSION.::&DEBUG.:705:P705_START_TYP:&P701_START_TYP.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1037603643093382513)
,p_name=>'P701_START_TYP'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2386433562243780389)
,p_use_cache_before_default=>'NO'
,p_item_default=>'10'
,p_prompt=>'Start Typ'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Datum'', ''Date'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''ModelJahr'', ''ModelYear'') AS display_value,',
'        20 AS actual_value,',
'        2 AS sort_order  ',
'    FROM dual',
' UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''alle'', ''all'') AS display_value,',
'        0 AS actual_value,',
'        3 AS sort_order  ',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1037603264955382497)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2386433562243780389)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1037602777376382494)
,p_event_id=>wwv_flow_imp.id(1037603264955382497)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2386433562243780389)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1037602391463382493)
,p_name=>'on Change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P701_START_TYP'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1037601848200382493)
,p_event_id=>wwv_flow_imp.id(1037602391463382493)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P701_START_TYP'
,p_attribute_03=>'P701_START_TYP'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1037601329891382493)
,p_event_id=>wwv_flow_imp.id(1037602391463382493)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P701_NEW'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>':P701_START_TYP'
,p_attribute_07=>'P701_START_TYP'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1037600905453382493)
,p_event_id=>wwv_flow_imp.id(1037602391463382493)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2386433562243780389)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1037600489348382493)
,p_name=>'New'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P701_BILD_NUMMER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1037600015847382492)
,p_event_id=>wwv_flow_imp.id(1037600489348382493)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_name=>'Bild nummer'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P701_NEW2'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select MS_BILDID from t_MS_bild where bild_nummer=:P701_BILD_NUMMER'
,p_attribute_07=>'P701_BILD_NUMMER'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1037599568606382492)
,p_name=>'New_1'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P701_NEW2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1037599023197382492)
,p_event_id=>wwv_flow_imp.id(1037599568606382492)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P701_IMAGE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'selecT dbms_lob.getLength(BILD_1) from t_MS_bild where MS_BILDID=:P701_NEW;'
,p_attribute_07=>'P701_NEW'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
