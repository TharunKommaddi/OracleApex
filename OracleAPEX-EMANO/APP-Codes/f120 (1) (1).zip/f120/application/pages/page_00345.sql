prompt --application/pages/page_00345
begin
--   Manifest
--     PAGE: 00345
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>345
,p_name=>unistr('Funktion bearbeiten / hinzuf\00FCgen')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Funktion bearbeiten / hinzuf\00FCgen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(215652538093308205)
,p_plug_name=>'Form on T_FUNKTION'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(215653291859308205)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(842898228819854994)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(215652538093308205)
,p_button_name=>'CHOOSE_PARENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('W\00E4hlen')
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:342:&SESSION.::&DEBUG.:342:P342_SELECTED,P342_CAME_FROM:&P345_PARENTID.,345'
,p_button_condition_type=>'NEVER'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(215653669060308206)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(215653291859308205)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(215653031046308205)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(215653291859308205)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from t_funktion where rowid=:P345_ROWID',
' and status in (emano_util.fLang(''veraltet'', ''outdated''),',
'    emano_util.fLang(''in Bearbeitung'', ''in progress''))'))
,p_button_condition_type=>'NOT_EXISTS'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(842898261541854995)
,p_name=>'P345_PARENTID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(215652538093308205)
,p_use_cache_before_default=>'NO'
,p_source=>'PARENTID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(842897388032854986)
,p_name=>'P345_DISPLAY_PARENT'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(215652538093308205)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Parent'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung',
'from t_funktion',
'where funktionid = :P345_PARENTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(842897203936854984)
,p_name=>'P345_BESCHREIBUNG'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(215652538093308205)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Beschreibung'
,p_source=>'BESCHREIBUNG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(554264559933028803)
,p_name=>'P345_FUNKTIONID'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(215652538093308205)
,p_use_cache_before_default=>'NO'
,p_source=>'FUNKTIONID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(554264520632028802)
,p_name=>'P345_VORSCHRIFTEN_LIST'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(215652538093308205)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Zugeordnete Vorschriften'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(vorschriftid, '':'') within group (order by vorschriftid) ',
'from t_VORSCHRIFT_REF_FUNKTION ',
'where FUNKTIONID = :P345_FUNKTIONID'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_VORSCHRIFT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select VORSCHRIFT_NUMMER || '' - '' || VORSCHRIFT_BEZEICHNUNG d,',
'       VORSCHRIFTID as r',
'  from T_VORSCHRIFT',
' order by 1'))
,p_lov_display_null=>'YES'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213987928944655417)
,p_name=>'P345_BEZEICHNUNG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(215652538093308205)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Bezeichnung'
,p_source=>'BEZEICHNUNG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(215655922186308213)
,p_name=>'P345_ROWID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(215652538093308205)
,p_use_cache_before_default=>'NO'
,p_source=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(215656341295308229)
,p_name=>'P345_KOMMENTAR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(215652538093308205)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Kommentar'
,p_source=>'KOMMENTAR'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>512
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(215653727513308206)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(215653669060308206)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(215654508368308209)
,p_event_id=>wwv_flow_imp.id(215653727513308206)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(842897679319854989)
,p_name=>'Dialog geschlossen'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(842898228819854994)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(842897544977854988)
,p_event_id=>wwv_flow_imp.id(842897679319854989)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P345_PARENTID'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P342_SELECTED'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(842897272236854985)
,p_event_id=>wwv_flow_imp.id(842897679319854989)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P345_DISPLAY_PARENT'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lReturn varchar2(250);',
'begin',
'    select nvl(bezeichnung,''kein Parent'') into lReturn',
'    from t_funktion',
'    where funktionid = :P342_SELECTED;',
'    ',
'    return lReturn;',
'exception',
'    when no_data_found then',
'        return ''kein Parent'';',
'end;'))
,p_attribute_07=>'P345_PARENTID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(215657161183308237)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_FUNKTION'
,p_attribute_02=>'T_FUNKTION'
,p_attribute_03=>'P345_ROWID'
,p_attribute_04=>'ROWID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3887869477082696472
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(215657527127308238)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of T_FUNKTION'
,p_attribute_02=>'T_FUNKTION'
,p_attribute_03=>'P345_ROWID'
,p_attribute_04=>'ROWID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>3887869843026696473
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(554264413865028801)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save_Vorschrschriften'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--debug('':P345_VORSCHRIFTEN_LIST ='', :P345_VORSCHRIFTEN_LIST);',
' merge into T_VORSCHRIFT_REF_FUNKTION t',
'using (',
'    select :P345_FUNKTIONID as funktionid, column_value as vorschriftid',
'    from table ( apex_string.split_numbers(:P345_VORSCHRIFTEN_LIST, '':'') )',
'    where column_value is not null',
') src',
'on (t.vorschriftid = src.vorschriftid and t.funktionid = src.funktionid)',
'',
'when not matched then',
'    insert (t.vorschriftid, t.funktionid)',
'    values (src.vorschriftid, src.funktionid );',
'    ',
'    delete from T_VORSCHRIFT_REF_FUNKTION  where ',
'    funktionid = :P345_FUNKTIONID  and ',
'    vorschriftid not in (',
'        select column_value ',
'          from table ( apex_string.split_numbers(:P345_VORSCHRIFTEN_LIST, '':''))',
'          where column_value is not null',
'        );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3117947902034359434
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(215657917186308238)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3887870233085696473
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(215658331731308238)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3887870647630696473
);
wwv_flow_imp.component_end;
end;
/
