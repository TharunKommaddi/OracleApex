prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'shuttle'
,p_alias=>'SHUTTLE'
,p_page_mode=>'MODAL'
,p_step_title=>'shuttle'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''option:contains("(red)")'').addClass("red").each(function() {',
'    $(this).html($(this).html().replace("(red)",""));',
'});'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.shuttle_left .red { color: red; font-weight: bold }',
'.shuttle_right .red { color: red; font-weight: bold }'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(869474975992647884)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869474837375647883)
,p_name=>'P4_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(869474975992647884)
,p_prompt=>'New'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'   --  CASE WHEN nvl(STATUS_PRUEFUNG,0)=0 then ''(red)'' end || ',
'      ''(red)'' ||vtb.nummer || ''-'' ||vtb.bezeichnung  as d,',
'   vtb.themaid        AS r',
'FROM',
'    v_thema_baum vtb',
'',
'',
'    ',
'ORDER BY',
'    vtb.thema_sortorder;',
''))
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp.component_end;
end;
/
