prompt --application/pages/page_00400
begin
--   Manifest
--     PAGE: 00400
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>400
,p_name=>'GANTT-Chart'
,p_alias=>'GANTT'
,p_step_title=>'GANTT-Chart'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#THEME_DB_IMAGES#jquery.contextMenu#MIN#.js',
'#THEME_DB_IMAGES#jquery.ui.position#MIN#.js'))
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function fQueryRefreshState() {',
'    apex.event.trigger(document, "eventCockpitState");',
'}',
'',
'function recalcTopLeft() {',
'    var firstheight = $(''th.land'').outerHeight();',
'    $("th.landed").css("top", firstheight);',
'    var firstwidth = $(''th.themanum'').outerWidth();',
'    $("th.thema").css("left", firstwidth);',
'}',
'',
'function tgexpandall() {',
'    $(''.tgexpandable'').removeClass(''tgexpandable'').addClass(''tgcollapsible'');',
'    $(''tr.tgtr'').addClass(''tgshow'');',
'    recalcTopLeft();',
'}',
'',
'function tgcollapseall() {',
'    $(''.tgcollapsible'').removeClass(''tgcollapsible'').addClass(''tgexpandable'');',
'    $(''tr.tgtr:not([tglevel=1])'').removeClass(''tgshow'');',
'    recalcTopLeft();    ',
'}',
'',
'function tgexpand() {',
'    var id = $(this).parent().attr(''tgid'');',
'    $(''tr.tgtr[tgparent='' + id + '']'').addClass(''tgshow'');',
'    $(this).removeClass("tgexpandable").addClass("tgcollapsible");',
'    recalcTopLeft();    ',
'}',
'',
'function tgcollapse() {',
'    var id = $(this).parent().attr(''tgid'');',
'    $(''tr.tgtr[tgparent='' + id + '']'').removeClass(''tgshow'');',
'    $(''div.tg span.tg[tgparent='' + id + ''].tgcollapsible'').each(function() {',
'        $(this).trigger("click");',
'    });',
'    $(this).addClass("tgexpandable").removeClass("tgcollapsible");',
'    recalcTopLeft();    ',
'}',
'',
'function loadLinks(aVorschriftID) {',
'    var dfd = jQuery.Deferred();    ',
'    apex.server.process(',
'        ''loadLinks'',                           ',
'        { x01: aVorschriftID }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                if (pData.linkdms) {',
'                    pData.linkdms.callback = function() { apex.navigation.openInNewWindow(pData.linkdms.url); };',
'                }',
'                if (pData.linkgetex) {',
'                    pData.linkgetex.callback = function() { apex.navigation.openInNewWindow(pData.linkgetex.url); };',
'                }         ',
'                if (pData.linkwebsite) {',
'                    pData.linkwebsite.callback = function() { apex.navigation.openInNewWindow(pData.linkwebsite.url); };',
'                }                     ',
'                dfd.resolve(pData);',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'    return dfd.promise();   ',
'}',
'',
'function loadThemaDaten(aThemaID) {',
'    var dfd = jQuery.Deferred();    ',
'    apex.server.process(',
'        ''loadThemaDaten'',                           ',
'        { x01: aThemaID }, ',
'        {',
'            success: function (pData)',
'            {             ',
'                dfd.resolve(pData);',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'    return dfd.promise();   ',
'}',
'',
'function loadLaenderShuttle() {',
'    var shuttleName = ''P400_FILTER_BLAND'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadLaenderShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P400_FILTER_LAENDERGRUPPE''),',
'          x03: $v(''P400_FILTER_BLAND_PRE''),',
'          x04: $v(''P400_INCLUDE_INACT_BESTAND'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                console.log(pData);',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'function loadThemenShuttle() {',
'    console.log(''loadThemenShuttle'');',
'    var shuttleName = ''P400_FILTER_THEMEN'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadThemenShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P400_FILTER_THEMEN_PRE''),',
'          x03: $v(''P400_FILTER_THEMEN_PRE_AK'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'function redirectVorschrift(aVorschriftID) {',
'    apex.server.process(',
'        ''loadLinkVorschrift'',                           ',
'        { x01: aVorschriftID }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                ',
'                //apex.navigation.openInNewWindow(pData);',
'                javascript:window.open(pData,''_blank'');                ',
'                ',
'            },',
'            dataType: "text"                     ',
'        }',
'    );        ',
'}',
'',
'function redirectThema(aThemaID) {',
'    apex.server.process(',
'        ''loadLinkThema'',                           ',
'        { x01: aThemaID }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                ',
'                ///apex.navigation.dialog(pData);   ',
'                eval(pData);',
'                //console.log(pData);',
'                ',
'            },',
'            dataType: "text"                     ',
'        }',
'    );        ',
'}',
'',
'function redirectTree(aVorschriftID) {',
'    apex.server.process(',
'        ''loadLinkTree'',                           ',
'        { x01: aVorschriftID }, ',
'        {',
'            success: function (pData)',
'            {     ',
unistr('                // Return-Wert enth\00E4lt javascript:apex.navigation.dialog - Aufruf'),
'                eval(pData);',
'            },',
'            dataType: "text"                     ',
'        }',
'    );        ',
'}',
'',
'',
'function addItemToShuttle(aShuttle, aID, aDisplay) {',
'    var lLeft = $(''#'' + aShuttle + ''_LEFT'');',
'    var lRight = $(''#'' + aShuttle + ''_RIGHT'');',
'    lLeft.find(''option[value='' + aID + '']'').remove();',
'    lRight.append(''<option value="'' + aID + ''">'' + aDisplay + ''</option>'');',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//gTimer = window.setInterval(fQueryRefreshState, 10000);',
'',
'$(''table.tg tr'').addClass(''tgshow'');',
'',
'$(''table.tg'').on(''click'',''th.tgexpandable:not([tgisleaf="1"])'',tgexpand);',
'$(''table.tg'').on(''click'',''th.tgcollapsible:not([tgisleaf="1"])'',tgcollapse);',
'',
'$(''table.tg tbody th.tg'').each(function() {',
'    var level = parseInt($(this).parent().attr(''tglevel'')) - 1;',
'    $(this).css("padding-left",level*10 + ''px'');',
'});',
'',
'recalcTopLeft();',
'',
'',
'// Text-Item muss da sein, da sonst Submit bei Enter im Vorfilter-Feld',
'$(''#P200_TEXTFIELD'').closest(''div.row'').hide();',
'',
'',
'$(document).ready(function () {',
'        ''use strict'';',
'',
'        $.contextMenu({',
'            selector: ''table.cockpit td.vmenu'',',
'            build: function ($trigger, e) {',
'                ',
'                var vid = $trigger.attr(''vid'');',
'                var vnummer = $trigger.attr(''vnummer'');',
'                var vbezeichnung = $trigger.attr(''vbezeichnung'');',
'                var rrid = $trigger.attr(''rrid'');',
'                var rrnummer = $trigger.attr(''rrnummer'');',
'                ',
'                var items = {',
'                        "vnummer": { name: "<b>Nummer:</b> " + vnummer, isHtmlName: true, callback: function() { redirectVorschrift(vid)} }',
'                };',
'                if (vbezeichnung) {',
'                    items.vbezeichnung = { name: "<b>Bezeichnung:</b> " + vbezeichnung, className: "nohover", isHtmlName: true};',
'                }    ',
unistr('                items.tree = { name: "Baumansicht \00F6ffnen", callback: function() { redirectTree(vid)}};'),
'                items.links = {',
'                    name: "Externe Links",',
'                    icon: "fa-link",',
'                    items: loadLinks(vid)',
'                }',
'                if (rrid) {',
'                    items.rr = { name: "<b>Rahmenrichtlinie: </b> " + rrnummer, isHtmlName : true, callback: function() { redirectVorschrift(rrid)}};',
'                }',
'',
'                items.permal = { name: "Permalink", callback: function(){ ',
'                    var lPermalink = window.location.protocol + ''//'' ',
'                                  + window.location.hostname',
'                                  + '':'' + window.location.port',
'                                  + window.location.pathname',
'                                  + ''?p=&APP_ALIAS.:VORSCHRIFT::::25:P25_VORSCHRIFTID:''',
'                                  + vid;',
'                    navigator.clipboard.writeText(lPermalink);',
'                    alert(''Permalink in die Zwischenablage kopiert:\n\n'' + lPermalink);',
'                } }',
'                ',
'                return {items: items};',
'',
'            }',
'        });',
'    ',
'        $.contextMenu({',
'            selector: ''table.cockpit .tmenu'',',
'            build: function ($trigger, e) {',
'                ',
'                var tid = $trigger.attr(''tid'');',
'                var tnummer = $trigger.attr(''tnummer'');',
'                var tbezeichnung = $trigger.attr(''tname'');',
'                ',
'                var items = {',
'                        "tnummer": { name: "<b>Nummer:</b> " + tnummer, isHtmlName: true, callback: function() { redirectThema(tid)} }',
'                };',
'                if (tbezeichnung) {',
'                    items.tbezeichnung = { name: "<b>Bezeichnung:</b> " + tbezeichnung, className: "nohover", isHtmlName: true};',
'                }  ',
'                items.adddata = {',
unistr('                    name: "Zus\00E4tzliche Daten",'),
'                    items: loadThemaDaten(tid)',
'                }',
unistr('                /*items.tree = { name: "Baumansicht \00F6ffnen", callback: function() { redirectTree(vid)}};'),
'                items.links = {',
'                    name: "Externe Links",',
'                    icon: "fa-link",',
'                    items: loadLinks(vid)',
'                }*/',
'                ',
'                return {items: items};',
'',
'            }',
'        });  ',
'    $(''.oj-gantt-task.neue-typen'').attr("d", ''M-7,3L7,3L7,17L-7,17Z'');',
'',
'    });',
''))
,p_css_file_urls=>'#THEME_DB_IMAGES#jquery.contextMenu#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.oj-gantt-task.progqsicher {',
'    fill: pink;',
'}',
'',
'.oj-gantt-task.progqabschaetz {',
'    fill: orange;',
'}',
'',
'.oj-gantt-task.progqoffen {',
'    fill: lightgray;',
'}',
'',
'.oj-gantt-task.progqbestaetigt {',
'    fill: lightgreen;',
'}',
'',
'',
'.oj-gantt-task.ausser-kraft {',
'    fill: blue;',
'    d: path(''M0,0L11,22L-11,22Z'') !important',
'}',
'',
'.oj-gantt-task.in-kraft {',
'    fill: green;',
'    d: path(''M 0 0 a 11 11 0 1 0 0.01 0 Z'') !important',
'}',
'',
'.oj-gantt-task.neue-typen {',
'    fill: yellow;',
'    d: path(''M-7,4L7,4L7,18L-7,18Z'') !important',
'}',
'',
'.oj-gantt-task.alle-fzg {',
'    fill: red;',
'}',
'',
'.context-menu-root {',
'    visibility: visible;',
'}',
'',
'th.land, th.landed {',
'    position: sticky;',
'    /*border-bottom: 1px solid white;',
'    border-top: 1px solid white;    */',
'    top: 0;',
'    z-index: 2;',
'}',
'',
'th.landed {',
'    border-top: 1px solid white;',
'}',
'',
'th.thema {',
'    border-left: 1px solid white;',
'}',
'',
'div.themaBez {',
'    float: left;',
'    width: 100%;',
'}',
'',
'img.themaBeta {',
'    float: right;',
'    width: 20%;',
'    padding-left: 3px;',
'}',
'',
'',
'td.fbl, th.fbl {',
'    border-left: 4px solid white;',
'}',
'td.fbt, th.fbt {',
'    border-top: 4px solid white;',
'}',
'',
'th.themanum, th.thema {',
'    position: sticky;',
'    left: 0;',
'    z-index: 1;',
'}',
'',
'.cockpit th.thema {',
'    max-width: 200px;',
'    /*overflow: hidden;',
'    text-overflow: ellipsis;',
'    white-space: nowrap;*/     ',
'}',
'',
'',
'',
unistr('/* Kontextmen\00FC */'),
'',
unistr('/* Lade-Animation im Kontextmen\00FC */'),
'.context-menu-icon-loading::before {',
'    content: "\f110";',
'}',
'',
'.context-menu-icon--fa {',
'    font-size: 14px !important;',
'}',
'',
'.context-menu-item.context-menu-visible > .context-menu-list {',
'    max-width: none !important;',
'    width: 300px !important;',
'}',
'',
'/* Labels */',
'.context-menu-item.context-menu-hover.nohover {',
'    cursor: auto;',
'    background-color: inherit;',
'    color: black;',
'}',
'',
'.rr {',
'    border: 1px solid black;',
'    font-size: 0.8em;',
'    padding: 1px; margin-right: 3px;',
'}',
'.rr::before {',
'    content: "RR"',
'}',
'',
'',
'',
'',
'.cockpit tbody tr.tgtr:not(.tgshow) {',
'    display: none;',
'}',
'',
'',
'.tg tbody th.tg::before {',
'    font-family: ''Font APEX Small'' !important;     ',
'    font-size: 14px;    ',
'    content: "";',
'    width: 20px;',
'    padding-left: 2px;',
'    display: inline-block;',
'    font-weight: normal;',
'    white-space: nowrap;',
'}',
'',
'.tgtr:not([tgisleaf="1"]) .tgexpandable::before {',
'    content:"\f196" !important;',
'}',
'',
'.tgtr:not([tgisleaf="1"]) .tgcollapsible::before {',
'    content: "\f147" !important;',
'}',
'',
'',
'.tgtr th.tg {',
'    text-align: left;',
'    white-space: nowrap;',
'}',
'',
'',
'th.thema {',
'    text-align: right;',
'    font-weight: normal;',
'}',
'',
'div.beta::before {',
'    content: url("#APP_IMAGES#beta1.jpg");',
'    transform: scale(.2);',
'}',
'',
'div.beta {',
'    display: inline-block;',
'    position: relative;',
'    right: 0px;',
'    font-weight: bold;',
'    color: #d30b37;    ',
'    font-size: 25px;',
'    margin-left: 5px;',
'    padding: 3px;',
'    border: 1px solid #bb0a31;',
'    max-width: 50px;',
'    ',
'}',
'',
'div.laendergruppen {',
'    font-weight: normal;',
'    font-size: 10px;',
'}',
'',
'div.landcontainer {',
'    display: flex;',
'    justify-content: flex-end;',
'    align-items: center;',
'}',
'',
'div.landl {',
'    flex-grow: 1;',
'}',
'',
'div.landr {',
'    width: 80px;',
'}',
'',
'',
'div.landb img {',
'    width: 30px;',
'    margin: 5px;',
'}',
'',
'',
'span.js-maximizeButtonContainer button {',
'    display: none;   ',
'}',
'',
'button.cockpit_refresh {',
'    color: #7FFF00;',
'    margin-bottom: 0px !important;',
'    	padding: 4px;',
'	    min-width: 24px;',
'	    border-radius: 2px;   ',
'    margin-left: 5px;',
'    display:none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'04'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2752970725472791279)
,p_plug_name=>'Einstellungen &P400_FILTER_TITEL.'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2771857160564388383)
,p_plug_name=>'Info'
,p_parent_plug_id=>wwv_flow_imp.id(2752970725472791279)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('Bitte w\00E4hlen Sie ein oder mehrere L\00E4nder sowie ein oder mehrere Themengebiete und klicken Sie auf "Filtern", um zu beginnen!')
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P400_FILTER_THEMEN is null and :P400_FILTER_BLAND is null'
,p_plug_display_when_cond2=>'SQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2771857302158388384)
,p_plug_name=>'Filter'
,p_parent_plug_id=>wwv_flow_imp.id(2752970725472791279)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1019001270462290427)
,p_plug_name=>'Regulation Chain'
,p_parent_plug_id=>wwv_flow_imp.id(2771857302158388384)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1003883229984808395)
,p_plug_name=>'Trennlinie'
,p_parent_plug_id=>wwv_flow_imp.id(2771857302158388384)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<hr />'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(322032832866744856)
,p_plug_name=>unistr('Box Vorfilter L\00E4nder')
,p_parent_plug_id=>wwv_flow_imp.id(2771857302158388384)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(322032865421744857)
,p_plug_name=>unistr('Box Filter L\00E4nder')
,p_parent_plug_id=>wwv_flow_imp.id(2771857302158388384)
,p_region_template_options=>'#DEFAULT#:margin-left-md'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(322033025014744858)
,p_plug_name=>'Box Vorfilter Themen'
,p_parent_plug_id=>wwv_flow_imp.id(2771857302158388384)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>50
,p_plug_grid_column_span=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(322033077722744859)
,p_plug_name=>'Box Filter Themen'
,p_parent_plug_id=>wwv_flow_imp.id(2771857302158388384)
,p_region_template_options=>'#DEFAULT#:margin-left-md'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(322033181028744860)
,p_plug_name=>'Trennlinie'
,p_parent_plug_id=>wwv_flow_imp.id(2771857302158388384)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<hr>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2752970917213791281)
,p_plug_name=>'GANTT <span onclick="redirect(121)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P400_MODUS = 10 and (:P400_FILTER_THEMEN is not null or :P400_FILTER_BLAND is not null))',
'or (:P400_MODUS = 20 and :P400_REGULATION_CHAIN is not null)'))
,p_plug_display_when_cond2=>'SQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1003883970466808403)
,p_plug_name=>'GANTT'
,p_parent_plug_id=>wwv_flow_imp.id(2752970917213791281)
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(1003883902127808402)
,p_region_id=>wwv_flow_imp.id(1003883970466808403)
,p_chart_type=>'gantt'
,p_height=>'700'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'visible'
,p_vertical_grid=>'visible'
,p_row_axis_rendered=>'on'
,p_gantt_axis_position=>'top'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options) {',
unistr('    //Einf\00FCgen einer vertikalen Linie bei einem bestimmten Datum'),
'    ',
'    //var constantLineY = [{text:"Ref Obj", type: "line", value: 50, color: "#a0ceec", displayInLegend: "on", lineWidth: 3, location: "back", lineStyle: "dashed", shortDesc: "Samp RefLne"}];',
'    //console.log(options);',
'    ',
'    var lDateToMark = $("#P400_DATE_MARK").datepicker("getDate");',
'    var constantLine = [{value: lDateToMark.toISOString(), color: "#00FF00"}];',
'    options.referenceObjects = constantLine;',
'     ',
'    // Custom Tooltip',
'    if ( options.valueFormats.thema ) {',
'        $.extend( options.valueFormats.thema, { tooltipLabel: ''Thema'' });',
'    } else {',
'        options.valueFormats.thema = { tooltipLabel: ''Thema'' };',
'    }',
'    $.extend(options.valueFormats.thema, { tooltipLabel: ''Thema'' }); ',
'    ',
'    ',
'    options.zoomAndScroll ="liveScrollOnly";',
'    console.log(options);',
'    //console.log(JSON.stringify(options));',
'    ',
'    return options;    ',
'}'))
,p_automatic_refresh_interval=>36000000
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(1003883738887808401)
,p_chart_id=>wwv_flow_imp.id(1003883902127808402)
,p_seq=>10
,p_name=>'Vorschriften nach Themen'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_grunddaten_rr as (',
'    Select v2.vorschriftid, vt2.themaid, vtl.landid, DATUM_IN_KRAFT,DATUM_NEUE_TYPEN,DATUM_ALLE_TYPEN',
'    from  t_vorschrift v1',
'    left outer join t_vorschrift_ref_land vtl on (v1.vorschriftid = vtl.vorschriftid and vtl.geloescht = 0)',
'    join t_vorschrift_ref_vorschrift vrv on (vrv.nachfolger_vorschriftid = v1.vorschriftid and vrv.beziehung_art = 40)',
'    join t_vorschrift v2 on (vrv.vorgaenger_vorschriftid = v2.vorschriftid)',
'    left outer join t_vorschrift_ref_thema vt2 on (v2.vorschriftid = vt2.vorschriftid and vt2.geloescht = 0)',
'    where ( :P400_MODUS = 10 and',
'        v1.vorschrift_typid = 30',
'        and vtl.landid in (select column_value from table (apex_string.split_numbers(:P400_FILTER_BLAND, '':'')))',
'        and ( vt2.themaid in (select column_value from table (apex_string.split_numbers(:P400_FILTER_THEMEN, '':'')))',
'         or vt2.themaid in (select column_value from table (apex_string.split_numbers(:P400_QUERSCHNITT_THEMEN_CB, '':'')))',
'    )) or',
'    (:P400_MODUS = 20 and v1.vorschriftid in (select column_value from apex_string.split_numbers(:P400_CHAIN_MEMBERS,'':'')))',
'    ',
'    ',
'), cte_grunddaten_clean as (',
'    Select vorschriftid, themaid, landid,1000 as einsatzdatum_typid, DATUM_IN_KRAFT as einsatzdatum',
'    from cte_grunddaten_rr',
'    where datum_in_kraft is not null',
'    union all',
'    Select vorschriftid, themaid, landid,1010 as einsatzdatum_typid, DATUM_NEUE_TYPEN as einsatzdatum',
'    from cte_grunddaten_rr',
'    where DATUM_NEUE_TYPEN is not null',
'     union all',
'    Select vorschriftid, themaid, landid,1011 as einsatzdatum_typid, DATUM_ALLE_TYPEN as einsatzdatum',
'    from cte_grunddaten_rr',
'    where DATUM_ALLE_TYPEN is not null',
' ',
'),cte_meilensteine as (',
'select vl.vorschriftid, vt.themaid, vl.landid, vre.einsatzdatum_typid, vre.einsatzdatum',
'from t_vorschrift v',
'join t_vorschrift_ref_thema vt on vt.vorschriftid = v.vorschriftid',
'join t_vorschrift_ref_land vl on vl.vorschriftid = v.vorschriftid',
'join t_einsatzdatum_typ edt on (edt.einsatzdatum_modellid = v.einsatzdatum_modellid ',
'                                or edt.einsatzdatum_modellid is null)',
'join t_vorschrift_ref_einsatzdatum_typ vre on (vre.vorschriftid = v.vorschriftid',
'    and vre.einsatzdatum_typid = edt.einsatzdatum_typid)',
'where vl.geloescht = 0 and vt.geloescht = 0',
'    and ( :P400_MODUS = 10 and',
'        v.vorschrift_typid  in (10,30,40)',
'        and vl.landid in (select column_value from table (apex_string.split_numbers(:P400_FILTER_BLAND, '':'')))',
'        and ( vt.themaid in (select column_value from table (apex_string.split_numbers(:P400_FILTER_THEMEN, '':'')))',
'         or vt.themaid in (select column_value from table (apex_string.split_numbers(:P400_QUERSCHNITT_THEMEN_CB, '':'')))',
'    )) or',
'    (:P400_MODUS = 20 and v.vorschriftid in (select column_value from apex_string.split_numbers(:P400_CHAIN_MEMBERS,'':'')))',
'union all ',
'Select distinct vorschriftid, themaid, landid, einsatzdatum_typid,  einsatzdatum',
'from cte_grunddaten_clean',
'), cte_sortierung as (',
'    select column_value as vid, rownum as sortorder',
'    from apex_string.split_numbers(:P400_CHAIN_MEMBERS,'':'')',
')',
', cte_laufzeit_start as (',
'select vorschriftid, themaid, landid, min(einsatzdatum) as datum_start',
'from cte_meilensteine ',
'where einsatzdatum_typid in (1010, 1011, 1020, 1021, 1022, 1023, 1030)',
'',
'    group by vorschriftid, themaid, landid',
')',
', cte_laufzeit_ende as (',
'select vorschriftid, themaid, landid, max(einsatzdatum) as datum_ende',
'from cte_meilensteine ',
'where einsatzdatum_typid in (1031, 1041, 1060, 1063)',
'group by vorschriftid, themaid, landid',
'), cte_enddaten as (',
'    ',
'-- Thema & Vorschriften (Zeilen)',
'select distinct ''T'' || ms.themaid || ''_'' || ms.vorschriftid AS VORSCHRIFTID,',
'    t.nummer || '' ('' || ',
unistr('        -- case when length(v.vorschrift_nummer) > 40 then substr(v.vorschrift_nummer, 1, 19) || ''\2026'' || substr(v.vorschrift_nummer, -19) else v.vorschrift_nummer end || '')'' as VORSCHRIFT_NUMMER,'),
'        case when length(',
'            CASE WHEN p.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND v.dokumentendatum IS NOT NULL',
'                 THEN v.vorschrift_nummer || ''_'' || TO_CHAR(v.dokumentendatum, ''DD.MM.YYYY'')',
'                 ELSE v.vorschrift_nummer',
'            END',
'        ) > 40 then ',
'            substr(',
'                CASE WHEN p.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND v.dokumentendatum IS NOT NULL',
'                     THEN v.vorschrift_nummer || ''_'' || TO_CHAR(v.dokumentendatum, ''DD.MM.YYYY'')',
'                     ELSE v.vorschrift_nummer',
'                END, 1, 19',
unistr('            ) || ''\2026'' || substr('),
'                CASE WHEN p.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND v.dokumentendatum IS NOT NULL',
'                     THEN v.vorschrift_nummer || ''_'' || TO_CHAR(v.dokumentendatum, ''DD.MM.YYYY'')',
'                     ELSE v.vorschrift_nummer',
'                END, -19',
'            )',
'        else ',
'            CASE WHEN p.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND v.dokumentendatum IS NOT NULL',
'                 THEN v.vorschrift_nummer || ''_'' || TO_CHAR(v.dokumentendatum, ''DD.MM.YYYY'')',
'                 ELSE v.vorschrift_nummer',
'            END',
'        end || '')'' as VORSCHRIFT_NUMMER,',
'',
'    null as THEMAID,',
'    null as THEMANAME,',
'    null as DATUMSTART,',
'    null as DATUMENDE,',
'    null as CSS_CLASS,',
'    null as TOOLTIP,',
'    1 as Sortierung,',
'    nvl(to_char(s.sortorder),t.nummer) as Sortierung2',
'from cte_meilensteine ms',
'join t_thema t on t.themaid = ms.themaid',
'join t_vorschrift v on v.vorschriftid = ms.vorschriftid',
'LEFT JOIN t_publisher p ON v.publisherid = p.publisherid',
'left outer join cte_sortierung s on (v.vorschriftid = s.vid)',
'',
'-- Laufzeit',
'union all ',
'select distinct '''' || lzs.vorschriftid || '' '' || lzs.themaid || '' lzs '' AS VORSCHRIFTID, ',
'    null AS VORSCHRIFT_NUMMER,',
'    ''T'' || lzs.themaid || ''_'' || lzs.vorschriftid AS THEMAID,',
'    t.nummer || '' - '' || CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN t.bezeichnung ELSE t.name_eng END AS THEMANAME,',
'    lzs.datum_start AS DATUMSTART,',
'    -- nvl(lze.datum_ende, :P400_DATE_END) AS DATUMENDE,',
'    -- nvl(lze.datum_ende, trunc(:P400_DATE_END)) AS DATUMENDE,',
'    nvl(lze.datum_ende, TRUNC(TO_DATE(:P400_DATE_END, ''DD.MM.YYYY''))) AS DATUMENDE,',
'',
'    CASE v.prognose_qualitaetid WHEN 0 then ''progqoffen'' when 10 THEN ''progqsicher'' when 20 then ''progqabschaetz'' when 30 then ''progqbestaetigt'' else null END as CSS_CLASS,',
'    ''<table>''',
'    || ''<tr><td class="oj-gantt-tooltip-label">'' || emano_util.fLang(''Thema'', ''Topic'') || ''</td><td class="oj-gantt-tooltip-value">'' || t.nummer || '' - '' || CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN t.bezeichnung ELSE t.name_eng END || ''</td></t'
||'r>''',
'    -- || ''<tr><td class="oj-gantt-tooltip-label">'' || emano_util.fLang(''Vorschrift'', ''Regulation'') || ''</td><td class="oj-gantt-tooltip-value">'' || v.vorschrift_nummer || ''</td></tr>''',
'    || ''<tr><td class="oj-gantt-tooltip-label">'' || emano_util.fLang(''Vorschrift'', ''Regulation'') || ''</td><td class="oj-gantt-tooltip-value">'' || ',
'    CASE WHEN p.anzeige_mit_dokumentendatum = 20 AND v.dokumentendatum IS NOT NULL',
'         THEN v.vorschrift_nummer || ''_'' || TO_CHAR(v.dokumentendatum, ''DD.MM.YYYY'')',
'         ELSE v.vorschrift_nummer',
'    END || ''</td></tr>''',
'',
'    || ''<tr><td class="oj-gantt-tooltip-label">'' || emano_util.fLang(''Start'', ''Start'') || ''</td><td class="oj-gantt-tooltip-value">'' || trunc(lzs.datum_start) || ''</td></tr>''',
'    || ''<tr><td class="oj-gantt-tooltip-label">'' || emano_util.fLang(''End'', ''End'') || ''</td><td class="oj-gantt-tooltip-value">'' || trunc(lze.datum_ende) || ''</td></tr>''',
'    || ''</table>'' as TOOLTIP,',
'    2 as Sortierung,',
'    t.nummer as Sortierung2',
'from cte_laufzeit_start lzs',
'left outer join cte_laufzeit_ende lze on (lze.vorschriftid = lzs.vorschriftid',
'    and lze.themaid = lzs.themaid',
'    and lze.landid = lzs.landid)',
'join t_vorschrift v on v.vorschriftid = lzs.vorschriftid',
'LEFT JOIN t_publisher p ON v.publisherid = p.publisherid',
'join t_thema t on t.themaid = lzs.themaid    ',
'',
' -- Meilensteine',
'union all',
'select '''' || ms.vorschriftid || '' '' || ms.themaid || '' '' || ms.einsatzdatum_typid AS VORSCHRIFTID,',
'    null AS VORSCHRIFT_NUMMER,',
'    ''T'' || ms.themaid || ''_'' || ms.vorschriftid AS THEMAID,',
'    t.nummer || '' - '' || CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN t.bezeichnung ELSE t.name_eng END AS THEMANAME,',
'    ms.einsatzdatum AS DATUMSTART,',
'    null AS DATUMENDE,',
'    CASE ',
'        when ms.einsatzdatum_typid = 1000 then ''in-kraft'' ',
'        when ms.einsatzdatum_typid in (1010, 1020, 1022, 1030) then ''neue-typen'' ',
'        when ms.einsatzdatum_typid in (1011, 1021, 1023) then ''alle-fzg''',
'        when ms.einsatzdatum_typid in (1031, 1041, 1060, 1063) then ''ausser-kraft'' ',
'        else null',
'     END AS CSS_CLASS,',
'    ''<table>''',
'    || ''<tr><td class="oj-gantt-tooltip-label">'' || emano_util.fLang(''Thema'', ''Topic'') || ''</td><td class="oj-gantt-tooltip-value">'' || t.nummer || '' - ''  || CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN t.bezeichnung ELSE t.name_eng END || ''</td></'
||'tr>''',
'    -- || ''<tr><td class="oj-gantt-tooltip-label">'' || emano_util.fLang(''Vorschrift'', ''Regulation'') || ''</td><td class="oj-gantt-tooltip-value">'' || v.vorschrift_nummer || ''</td></tr>''',
'    || ''<tr><td class="oj-gantt-tooltip-label">'' || emano_util.fLang(''Vorschrift'', ''Regulation'') || ''</td><td class="oj-gantt-tooltip-value">'' || ',
'    CASE WHEN p.anzeige_mit_dokumentendatum = 20 AND v.dokumentendatum IS NOT NULL',
'         THEN v.vorschrift_nummer || ''_'' || TO_CHAR(v.dokumentendatum, ''DD.MM.YYYY'')',
'         ELSE v.vorschrift_nummer',
'    END || ''</td></tr>''',
'    || ''<tr><td class="oj-gantt-tooltip-label">'' || emano_util.fLang(''Datum'', ''Date'') || ''</td><td class="oj-gantt-tooltip-value">'' || trunc(ms.einsatzdatum)|| ''</td></tr>''',
'    || ''<tr><td class="oj-gantt-tooltip-label">'' || emano_util.fLang(''Terminart'', ''Type of Appointment'') || ''</td><td class="oj-gantt-tooltip-value">'' || edt.einsatzdatum_typ || ''</td></tr>''',
'    || ''</table>'' as TOOLTIP,',
'    3 as Sortierung,',
'    t.nummer as Sortierung2',
'from cte_meilensteine ms',
'join t_vorschrift v on v.vorschriftid = ms.vorschriftid',
'LEFT JOIN t_publisher p ON v.publisherid = p.publisherid',
'join t_thema t on t.themaid = ms.themaid   ',
'join t_einsatzdatum_typ edt on edt.einsatzdatum_typid = ms.einsatzdatum_typid',
')',
'',
'Select * from cte_enddaten',
'order by sortierung asc,sortierung2',
'--order by vorschrift_nummer '))
,p_ajax_items_to_submit=>'P400_FILTER_THEMEN,P400_FILTER_BLAND, P400_DATE_START, P400_DATE_END,P400_QUERSCHNITT_THEMEN_CB,P400_REGULATION_CHAIN'
,p_items_short_desc_column_name=>'TOOLTIP'
,p_items_label_rendered=>true
,p_gantt_start_date_source=>'ITEM'
,p_gantt_start_date_item=>'P400_DATE_START'
,p_gantt_end_date_source=>'ITEM'
,p_gantt_end_date_item=>'P400_DATE_END'
,p_gantt_row_id=>'THEMAID'
,p_gantt_task_id=>'VORSCHRIFTID'
,p_gantt_task_name=>'VORSCHRIFT_NUMMER'
,p_gantt_task_start_date=>'DATUMSTART'
,p_gantt_task_end_date=>'DATUMENDE'
,p_gantt_task_css_class=>'&CSS_CLASS.'
,p_task_label_position=>'start'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(1003883505287808398)
,p_chart_id=>wwv_flow_imp.id(1003883902127808402)
,p_axis=>'major'
,p_is_rendered=>'on'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_axis_scale=>'years'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>true
,p_zoom_order_weeks=>true
,p_zoom_order_months=>true
,p_zoom_order_quarters=>true
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(1003883422581808397)
,p_chart_id=>wwv_flow_imp.id(1003883902127808402)
,p_axis=>'minor'
,p_format_type=>'decimal'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_axis_scale=>'months'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>true
,p_zoom_order_weeks=>true
,p_zoom_order_months=>true
,p_zoom_order_quarters=>true
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(885808603511768096)
,p_plug_name=>'Legende'
,p_parent_plug_id=>wwv_flow_imp.id(2752970917213791281)
,p_region_template_options=>'#DEFAULT#:t-Form--labelsAbove'
,p_plug_template=>wwv_flow_imp.id(2707059584407204267)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1003905475040896353)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2752970725472791279)
,p_button_name=>'FILTER'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Filtern'
,p_button_position=>'CHANGE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1003905066082896353)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2752970725472791279)
,p_button_name=>'RESET'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Zur\00FCcksetzen')
,p_button_position=>'CHANGE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1003899103449896345)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2752970917213791281)
,p_button_name=>'MAXIMIZE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Vollbildansicht'
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1003898693699896345)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2752970917213791281)
,p_button_name=>'COCKPIT_REFRESH'
,p_button_static_id=>'b_REFRESH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Es stehen neue Daten zur Verf\00FCgung. Klicken Sie hier oder laden Sie die Seite neu')
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_alignment=>'RIGHT'
,p_button_css_classes=>'cockpit_refresh fa'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1036436611311186207)
,p_name=>'P400_REGULATION_CHAIN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1019001270462290427)
,p_prompt=>unistr('Vorschrift f\00FCr Vorg\00E4nger-Nachfolger-Ketten')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CASE WHEN p.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND v.dokumentendatum IS NOT NULL',
'            THEN v.vorschrift_nummer || ''_'' || TO_CHAR(v.dokumentendatum, ''DD.MM.YYYY'')',
'            ELSE v.vorschrift_nummer',
'       END as d,',
'       v.vorschriftid as r',
'FROM t_vorschrift v',
'LEFT JOIN t_publisher p ON v.publisherid = p.publisherid',
'LEFT OUTER JOIN t_vorschrift_ref_land vrl ON (v.vorschriftid = vrl.vorschriftid AND nvl(vrl.geloescht,0) = 0)',
'LEFT OUTER JOIN t_vorschrift_ref_thema vrt ON (v.vorschriftid = vrt.vorschriftid AND nvl(vrt.geloescht,0) = 0)',
'WHERE (:P400_FILTER_BLAND is null or vrl.landid in (select column_value from apex_string.split_numbers(:P400_FILTER_BLAND,'':'')))',
'AND (:P400_FILTER_THEMEN is null or vrt.themaid in (select column_value from apex_string.split_numbers(:P400_FILTER_THEMEN,'':'')))'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('- ausw\00E4hlen -')
,p_lov_cascade_parent_items=>'P400_FILTER_BLAND,P400_FILTER_THEMEN'
,p_ajax_optimize_refresh=>'N'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct v.vorschrift_nummer || CASE WHEN v.dokumentendatum IS NOT NULL THEN '' - '' || TO_CHAR(v.dokumentendatum, ''DD.MM.YYYY'') ELSE '''' END as d,',
'       v.vorschriftid as r',
'from t_vorschrift v',
'left outer join t_vorschrift_ref_land vrl on (v.vorschriftid = vrl.vorschriftid and nvl(vrl.geloescht,0) = 0)',
'left outer join t_vorschrift_ref_thema vrt on (v.vorschriftid = vrt.vorschriftid and nvl(vrt.geloescht,0) = 0)',
'where ( :P400_FILTER_BLAND is null or vrl.landid in (select column_value from apex_string.split_numbers(:P400_FILTER_BLAND,'':'')))',
'and (:P400_FILTER_THEMEN is null or vrt.themaid in (select column_value from apex_string.split_numbers(:P400_FILTER_THEMEN,'':'')))'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019001140134290426)
,p_name=>'P400_MODUS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2771857302158388384)
,p_prompt=>'Modus'
,p_post_element_text=>'<span onclick="redirect(1600)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'
,p_source=>'10'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>unistr('STATIC:Normal;10,Vorg\00E4nger-Nachfolger-Ketten;20')
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019000742918290422)
,p_name=>'P400_CHAIN_MEMBERS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1019001270462290427)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1003904722985896353)
,p_name=>'P400_FILTER_TITEL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2752970725472791279)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lReturn varchar2(2000) := '''';',
'    lAnzahl number;',
'    lQuer_Anzahl number;',
'    lLaender varchar2(2000) := :P400_FILTER_BLAND;',
'    lThemen varchar2(2000) := :P400_FILTER_THEMEN;',
'    lQuer_Themen varchar2(2000) := :P400_QUERSCHNITT_THEMEN_CB;',
'begin',
'    if (lLaender is not null or lThemen is not null or lQuer_Themen is not null) then',
'        lReturn := ''(Filter: '';',
'    end if;',
'    if (lLaender is not null) then',
'        select count(*) into lAnzahl from apex_string.split_numbers(lLaender,'':'');',
unistr('        lReturn := lReturn || lAnzahl || '' L\00E4nder'';'),
'    end if;',
'    if (lLaender is not null and (lThemen is not null or lQuer_Themen is not null)) then',
'        lReturn := lReturn || '', '';',
'    end if;',
'    if (lThemen is not null or lQuer_Themen is not null) then',
'        select count(*) into lAnzahl from apex_string.split_numbers(lThemen,'':'');',
'        select count(*) into lQuer_Anzahl from apex_string.split_numbers(lQuer_Themen,'':'');',
'        lAnzahl := lAnzahl + lQuer_Anzahl;',
'        lReturn := lReturn || lAnzahl || '' Themen'';',
'    end if;',
'',
'    if (lThemen is not null or lLaender is not null  or lQuer_Themen is not null) then',
'        lReturn := lReturn || '')'';',
'    end if;',
'    ',
'    return lReturn;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1003902993294896349)
,p_name=>'P400_FILTER_LAENDERGRUPPE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(322032832866744856)
,p_prompt=>unistr('Vorfilter L\00E4ndergruppe')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select laendergruppe, laendergruppeid',
'from t_laendergruppe where laendergruppeid!=1220',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- alle -'
,p_cHeight=>5
,p_grid_label_column_span=>4
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1003902557395896349)
,p_name=>'P400_FILTER_BLAND_PRE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(322032832866744856)
,p_prompt=>unistr('Vorfilter L\00E4nder')
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" onclick="loadLaenderShuttle()"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>4
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1003901929245896348)
,p_name=>'P400_FILTER_BLAND'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(322032865421744857)
,p_prompt=>unistr('L\00E4nder')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    b_nummer || '' - '' || ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.LAND',
'        ELSE l.LAND_ENG',
'    END AS d, ',
'    l.landid',
'FROM ',
'    t_land l',
'WHERE ',
'    :P400_FILTER_LAENDERGRUPPE IS NULL',
'    OR l.landid IN (',
'        SELECT landid ',
'        FROM t_land_ref_laendergruppe ',
'        WHERE laendergruppeid = :P400_FILTER_LAENDERGRUPPE',
'    )',
'ORDER BY ',
'    nlssort(b_nummer,''NLS_SORT=BINARY_AI'')'))
,p_lov_cascade_parent_items=>'P400_FILTER_LAENDERGRUPPE'
,p_ajax_items_to_submit=>'P400_FILTER_LAENDERGRUPPE'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'U'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1003901167155896346)
,p_name=>'P400_FILTER_THEMEN_PRE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(322033025014744858)
,p_prompt=>'Vorfilter Themengebiete'
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" onclick="loadThemenShuttle()"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>4
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1003900796820896346)
,p_name=>'P400_FILTER_THEMEN_PRE_AK'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(322033025014744858)
,p_item_default=>'-1'
,p_prompt=>'Vorfilter Arbeitskreise'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct kurz || '' '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END as d, et_b_akid as r',
'from t_et_b_ak where ',
'                    CASE',
'                    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'                            ELSE name_eng',
'                    END not in (emano_util.fLang(''Administratoren'', ''Administrators''), emano_util.fLang(''Redaktionsteam'', ''Editorial Team''))',
'and et_b_akid in (select et_b_akid from t_thema_ref_et_b_ak)',
'and et_b_akid != 1036',
'order by 1',
'',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- alle -'
,p_lov_null_value=>'-1'
,p_cHeight=>5
,p_grid_label_column_span=>4
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1003900075567896346)
,p_name=>'P400_FILTER_THEMEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(322033077722744859)
,p_prompt=>'Themengebiete'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END as d, themaid as r from v_thema_baum',
'where nvl(gueltig,0) =1 ',
'--    where  --and',
'    and themaid not in (select themaid from t_thema_ref_et_b_ak where et_b_akid =1036)',
'    order by nummer'))
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END as d, themaid as r from v_thema_baum',
'     where themaid not in (select themaid from t_thema_ref_et_b_ak where et_b_akid =1036)'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1003898286929896344)
,p_name=>'P400_LOADING_TIME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2752970917213791281)
,p_use_cache_before_default=>'NO'
,p_format_mask=>'dd.mm.yy hh24:mi:ss'
,p_source=>'to_char(sysdate,''yy:mm:dd:hh24:mi:ss'')'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1003897848864896344)
,p_name=>'P400_COCKPIT_STATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2752970917213791281)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1003883110379808394)
,p_name=>'P400_DATE_END'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2771857302158388384)
,p_prompt=>'Ende'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1003882986520808393)
,p_name=>'P400_DATE_START'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2771857302158388384)
,p_prompt=>'Start'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1003882841724808392)
,p_name=>'P400_DATE_MARK'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2771857302158388384)
,p_prompt=>'Markierung'
,p_format_mask=>'DD.MM.YYYY'
,p_source=>'select to_char(sysdate,''dd.mm.yyyy'') from dual;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(885808774557768098)
,p_name=>'P400_LEGENDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(885808603511768096)
,p_prompt=>'Legende'
,p_source=>'#APP_IMAGES#gantt_legende_breit.png'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'URL')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(872957208410003309)
,p_name=>'P400_QUERSCHNITT_THEMEN_CB'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(322033077722744859)
,p_prompt=>'<b>Querschnittsthemengebiete</b>'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.nummer || '' - '' || v.bezeichnung d, tra.Themaid r ',
'  from T_thema_ref_et_b_AK tra ',
'  join V_THEMA_BAUM v on (v.themaid = tra.themaid)   ',
' where tra.et_b_AKid = 1036 -- querschnitt Themen',
' order by v.thema_sortorder'))
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '4')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(845152367685085702)
,p_name=>'P400_THEMEN_CHILDREN_TO_ADD'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(322033077722744859)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(554261087322028768)
,p_name=>'P400_INCLUDE_INACT_BESTAND'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(322032832866744856)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(534928174627103558)
,p_name=>'P400_LAENDER_MIT_INAKTIV_BESTAND'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(322032865421744857)
,p_prompt=>unistr('Zeige L\00E4nder mit inaktivem Datenbestand')
,p_display_as=>'NATIVE_YES_NO'
,p_grid_label_column_span=>6
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Nein',
  'off_value', '0',
  'on_label', 'Ja',
  'on_value', '1',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(1019000619169290421)
,p_computation_sequence=>10
,p_computation_item=>'P400_CHAIN_MEMBERS'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pfad',
'from v_vn_ketten',
'where param_vid = :P400_REGULATION_CHAIN'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1003893871027896341)
,p_name=>unistr('change l\00E4ndergruppenfilter')
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_FILTER_LAENDERGRUPPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1003893360869896339)
,p_event_id=>wwv_flow_imp.id(1003893871027896341)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1003893022650896338)
,p_name=>'enter im Themensuchfeld'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_FILTER_THEMEN_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1003892499026896338)
,p_event_id=>wwv_flow_imp.id(1003893022650896338)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'loadThemenShuttle();',
'return false;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1003892071659896338)
,p_name=>unistr('enter im L\00E4ndersuchfeld')
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_FILTER_BLAND_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1003891613980896337)
,p_event_id=>wwv_flow_imp.id(1003892071659896338)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'loadLaenderShuttle();',
'return false;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1003891182573896337)
,p_name=>'Click Custom Maximize Button'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1003899103449896345)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1003890643375896337)
,p_event_id=>wwv_flow_imp.id(1003891182573896337)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''span.js-maximizeButtonContainer button'').click()'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1003890282767896337)
,p_name=>'checkCockpitState'
,p_event_sequence=>60
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'eventCockpitState'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1003889786266896337)
,p_event_id=>wwv_flow_imp.id(1003890282767896337)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P400_COCKPIT_STATE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select to_char(last_refresh_end_time,''yy:mm:dd:hh24:mi:ss'') from user_mviews where mview_name = ''MV_COCKPIT2_NEU'''
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1003889291683896336)
,p_event_id=>wwv_flow_imp.id(1003890282767896337)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lLT = $v(''P400_LOADING_TIME'').split('':'');',
'var dLT = new Date(lLT[0],lLT[1],lLT[2],lLT[3],lLT[4],lLT[5]);',
'',
'var lCS = $v(''P400_COCKPIT_STATE'').split('':'');',
'var dCS = new Date(lCS[0],lCS[1],lCS[2],lCS[3],lCS[4],lCS[5]);',
'',
'if (dCS > dLT) {',
'    // angezeigte Daten sind alt --> refresh button anzeigen und timer ausschalten',
'    clearInterval(gTimer);',
'    $(''#b_REFRESH'').show();',
'} '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1003888911825896335)
,p_name=>unistr('Arbeitskreise ge\00E4ndert')
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_FILTER_THEMEN_PRE_AK'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1003888349532896335)
,p_event_id=>wwv_flow_imp.id(1003888911825896335)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'loadThemenShuttle();',
'return false;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1003882826091808391)
,p_name=>'Highlight Date'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2752970917213791281)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1003882664212808390)
,p_event_id=>wwv_flow_imp.id(1003882826091808391)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var contandLineY = [ {text: "Referenece Object", type: "line", vlaue: 50, color: "#a0CEEC", displayInLegend: "on", lineWidth: 3, location: "back", lineStyle: "dashed", shortDesc: "Sample Ref Line"} ];',
'apex.item'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(931185930895163891)
,p_name=>'After Gantt Refresh'
,p_event_sequence=>90
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1003883970466808403)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(931185754546163890)
,p_event_id=>wwv_flow_imp.id(931185930895163891)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.oj-gantt-task.neue-typen'').attr("d", ''M-7,4L7,4L7,18L-7,18Z'');',
'$(''.oj-gantt-task.in-kraft'').attr("d", ''M 0 0 a 11 11 0 1 0 0.01 0 Z'');',
'$(''.oj-gantt-task.ausser-kraft'').attr("d", ''M0,0L11,22L-11,22Z'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(845151663916083227)
,p_name=>'add childThemen'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_FILTER_THEMEN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(845150740426083213)
,p_event_id=>wwv_flow_imp.id(845151663916083227)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lThemenliste apex_t_number := apex_string.split_numbers(:P400_FILTER_THEMEN,'':'');',
'     l_lst_allQSThemen varchar2(2000);',
'    l_inQuerschnittsthemen apex_t_number ;',
'begin    ',
'',
'    apex_json.initialize_clob_output;',
'    apex_json.open_array;    ',
'',
'    select listagg(themaid, '':'') into l_lst_allQSThemen from t_thema_ref_et_b_ak where et_b_akid = 1036;',
'    l_inQuerschnittsthemen  := apex_string.split_numbers(l_lst_allQSThemen,'':'');',
unistr('    -- Jedes bereits ausgew\00E4hlte Thema durchgehen und dessen Kinder selektieren'),
'    for i in 1 .. lThemenliste.count loop',
'        for childthemen in (',
'            select themaid, nummer || '' - '' || bezeichnung as d',
'            from t_thema',
'',
'            connect by parentid = prior themaid',
'            start with parentid = lThemenliste(i)',
'        ) loop',
'            -- Wenn das entsprechende Kind noch nicht im Shuttle ist, dann ',
unistr('            -- zu einer Hinzuf\00FCgungs-Liste addieren'),
'            if (childthemen.themaid not member of lThemenliste ',
'             and  childthemen.themaid  not member of l_inQuerschnittsthemen) then',
'                apex_json.open_object;',
'                apex_json.write(''id'',childthemen.themaid);',
'                apex_json.write(''display'',childthemen.d);',
'                apex_json.close_object;',
'            end if;',
'        end loop;',
'    ',
'    end loop;',
unistr('    -- Hinzuf\00FCgungs-Liste ist hidden item'),
unistr('    -- Direktes Hinzuf\00FCgen w\00FCrde zu einem Refresh der Scrollbalken des Items f\00FChren'),
'    apex_json.close_array;',
'    :P400_THEMEN_CHILDREN_TO_ADD := apex_json.get_clob_output;',
'    apex_json.free_output;',
'end;    '))
,p_attribute_02=>'P400_FILTER_THEMEN'
,p_attribute_03=>'P400_THEMEN_CHILDREN_TO_ADD'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(845151317261083214)
,p_event_id=>wwv_flow_imp.id(845151663916083227)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var items = JSON.parse($v(''P400_THEMEN_CHILDREN_TO_ADD''));',
'',
unistr('// alle Items im Shuttle hinzuf\00FCgen'),
'for (item of items) {',
'    if (item) addItemToShuttle(''P400_FILTER_THEMEN'',item.id,item.display);',
'} ',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(554260995097028767)
,p_name=>'Zeige Land switch'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_LAENDER_MIT_INAKTIV_BESTAND'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexbeforerefresh'
,p_display_when_type=>'NOT_EXISTS'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from t_benutzer_ref_rolle where benutzerid=:G_BENUTZERID and ',
'rolleid  in (1003, 1000)'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554260849565028766)
,p_event_id=>wwv_flow_imp.id(554260995097028767)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P400_LAENDER_MIT_INAKTIV_BESTAND'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(554260765345028765)
,p_name=>'Change'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_LAENDER_MIT_INAKTIV_BESTAND'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554260657423028764)
,p_event_id=>wwv_flow_imp.id(554260765345028765)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P400_INCLUDE_INACT_BESTAND'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>':P400_LAENDER_MIT_INAKTIV_BESTAND'
,p_attribute_07=>'P400_LAENDER_MIT_INAKTIV_BESTAND'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554260441120028762)
,p_event_id=>wwv_flow_imp.id(554260765345028765)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'loadLaenderShuttle();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(911276594656629664)
,p_name=>'Change_1'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_INCLUDE_INACT_BESTAND'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(911276356462629662)
,p_event_id=>wwv_flow_imp.id(911276594656629664)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'loadLaenderShuttle();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(911277087838629669)
,p_name=>'Change_2'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_LAENDER_MIT_INAKTIV_BESTAND'
,p_condition_element=>'P400_LAENDER_MIT_INAKTIV_BESTAND'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(911277003619629668)
,p_event_id=>wwv_flow_imp.id(911277087838629669)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P400_INCLUDE_INACT_BESTAND'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(911276907489629667)
,p_event_id=>wwv_flow_imp.id(911277087838629669)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P400_INCLUDE_INACT_BESTAND'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(911276813642629666)
,p_event_id=>wwv_flow_imp.id(911277087838629669)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'loadLaenderShuttle();',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(911276720874629665)
,p_event_id=>wwv_flow_imp.id(911277087838629669)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1019001082160290425)
,p_name=>'New'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_MODUS'
,p_condition_element=>'P400_MODUS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'10'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1019000923308290424)
,p_event_id=>wwv_flow_imp.id(1019001082160290425)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1019001270462290427)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1019000835759290423)
,p_event_id=>wwv_flow_imp.id(1019001082160290425)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1019001270462290427)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1003895098257896342)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'RESET'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1003905066082896353)
,p_internal_uid=>2668317217641491893
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1003897132226896343)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLinks'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lID number;',
'    lLinkDMS varchar2(250);',
'    lLinkGetex varchar2(250);',
'    lLinkWebsite varchar2(250);',
'    lNameWebsite varchar2(250);',
'BEGIN',
' ',
'    lID := apex_application.g_x01;',
'    ',
'    select link_zur_vorschrift_dms, link_zur_vorschrift_getex into lLinkDMS, lLinkGetex',
'    from t_vorschrift',
'    where vorschriftid = lID;',
'    ',
'    select v.websitelink, w.website_name into lLinkWebsite, lNameWebsite',
'    from t_vorschrift v',
'    left outer join t_website w on (v.websiteid = w.websiteid)',
'    where v.vorschriftid = lID;',
'    ',
'    ',
'    apex_json.open_object;',
'    if (lLinkDMS is not null) then',
'        apex_json.open_object(''linkdms'');',
'        apex_json.write(''name'',''DMS'');',
'        apex_json.write(''url'',lLinkDMS);',
'        apex_json.close_object;',
'    end if;',
'    if (lLinkGetex is not null) then',
'        apex_json.open_object(''linkgetex'');',
'        apex_json.write(''name'',''GETEX'');  ',
'        apex_json.write(''url'',lLinkDMS);',
'        apex_json.close_object;',
'    end if;  ',
'    if (lLinkWebsite is not null) then',
'        apex_json.open_object(''linkwebsite'');',
'        apex_json.write(''name'',nvl(lNameWebsite,''Webseite''));',
'        apex_json.write(''url'',lLinkWebsite);',
'        apex_json.close_object;',
'    end if;',
'    if (lLinkDMS is null and lLinkGETEX is null and lLinkWebsite is null) then',
'        apex_json.open_object(''nolinks'');',
'        apex_json.write(''name'',''Keine externen Links definiert'');',
'        apex_json.write(''className'',''nohover'');',
'        apex_json.close_object;',
'    end if;',
'    apex_json.close_all;',
'    ',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2668315183672491892
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1003896664145896343)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLinkVorschrift'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lID number;',
'    lRowid rowid;',
'BEGIN',
' ',
'    lID := apex_application.g_x01;',
'    ',
'    select rowid into lRowid',
'    from t_vorschrift',
'    where vorschriftid = lID;',
'    ',
'    htp.p (apex_page.get_url(p_page => 25, p_items => ''P25_ROWID'', p_values => lRowid));',
'end;    '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2668315651753491892
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1003897471194896344)
,p_process_sequence=>30
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadPermalinkVorschrift'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lID number;',
'BEGIN',
' ',
'    lID := apex_application.g_x01;',
'    ',
'    htp.p (apex_page.get_url(p_application => :APP_ALIAS',
'                             , p_session => null',
'                             , p_page => ''VORSCHRIFT''',
'                             , p_clear_cache => 25',
'                             , p_items => ''P25_VORSCHRIFTID''',
'                             , p_values => lID));',
'end;    '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2668314844704491891
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1003894310675896341)
,p_process_sequence=>40
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLinkThema'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lID number;',
'    lRowid rowid;',
'BEGIN',
' ',
'    lID := apex_application.g_x01;',
'    ',
'    select rowid into lRowid',
'    from t_thema',
'    where themaid = lID;',
'    ',
'    htp.p (apex_page.get_url(p_page => 35, p_items => ''P35_ROWID'', p_values => lRowid));',
'end;    '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2668318005223491894
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1003896285770896343)
,p_process_sequence=>50
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLinkTree'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lID number;',
'    lRowid rowid;',
'BEGIN',
' ',
'    lID := apex_application.g_x01;',
'    ',
'    htp.p (apex_page.get_url(p_page => 300, p_items => ''P300_VORSCHRIFTID'', p_values => lID));',
'end;    '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2668316030128491892
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1003895888947896342)
,p_process_sequence=>60
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLaenderShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lLaendergruppe varchar2(2000) := apex_application.g_x02;',
'    lTextfilter varchar2(2000) := apex_application.g_x03;',
'    include_land_inactiv_data number := apex_application.g_x04;',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    for l in (',
'        select b_nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN LAND',
'        ELSE LAND_ENG',
'        END AS d, landid',
'        from t_land',
'        where landid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))        ',
'        and (',
'            lLaendergruppe is null',
'            or landid in (',
'                select landid from t_land_ref_laendergruppe where laendergruppeid in (',
'                    select column_value from table(apex_string.split_numbers(lLaendergruppe,'':''))',
'                )',
'            )',
'        )',
'        and (',
'            lTextfilter is null',
'            or instr(upper(b_nummer),upper(lTextFilter)) != 0',
'            or instr(upper(land),upper(lTextFilter)) != 0',
'        )',
'        and ( include_land_inactiv_data =0 and status_datenstand <> 0  or include_land_inactiv_data =1)',
'        order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'')        ',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.landid);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'    ',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2668316426951491893
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1003895493853896342)
,p_process_sequence=>70
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadThemenShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lText varchar2(2000) := apex_application.g_x02;',
'    lArbeitskreise varchar2(2000) := apex_application.g_x03;',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    for l in (',
'        select nummer || '' - '' || bezeichnung as d, themaid as r',
'        from v_thema_baum',
'        where upper(nummer || '' - '' || bezeichnung) like ''%'' || upper(lText) || ''%''',
'        and themaid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))',
'        and  THEMAID not in ( select themaid from t_thema_ref_et_b_ak where et_b_akid = 1036 )   -- querschnittsthemen',
'   and  nvl(gueltig,0) =1    ',
'        and',
'        (',
'            lArbeitskreise = ''-1'' or themaid  in (Select themaid from t_thema_ref_et_b_ak tre where et_b_akid in (',
'                select column_value from table(apex_string.split(lArbeitskreise,'':'')))',
'            )',
'        )',
'        order by nummer     ',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.r);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'    ',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2668316822045491893
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1003894668336896341)
,p_process_sequence=>80
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadThemaDaten'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lID number;',
'BEGIN',
' ',
'    lID := apex_application.g_x01;',
'    ',
'    apex_json.open_object;',
'    ',
'    for lThema in (',
'        select aa.bezeichnung as antriebsart_vorschrift',
'        from t_thema t',
'        left outer join t_thema_ref_antriebsart trf on (trf.themaid = t.themaid)',
'        left outer join t_antriebsart aa on (aa.antriebsartid = trf.antriebsartid)',
'        where t.themaid = lID ',
'and  nvl(gueltig,0) =1 ',
'    ) ',
'    loop',
'        if (lThema.antriebsart_vorschrift is not null) then',
'            apex_json.open_object(''antriebsart'');',
'            apex_json.write(''name'',''<b>Antriebsart: </b>'' || lThema.antriebsart_vorschrift);',
'            apex_json.write(''isHtmlName'',''true'');',
'            apex_json.write(''className'',''nohover'');',
'            apex_json.close_object;        ',
'        end if;',
'            ',
'    end loop;',
'            ',
'            ',
'    apex_json.close_all;',
'',
'',
'    ',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2668317647562491894
);
wwv_flow_imp.component_end;
end;
/
