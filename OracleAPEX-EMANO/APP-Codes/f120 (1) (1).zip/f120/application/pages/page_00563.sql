prompt --application/pages/page_00563
begin
--   Manifest
--     PAGE: 00563
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>563
,p_name=>unistr('Daten \00DCberpr\00FCfen')
,p_alias=>'ZUSAMMENFASSUNG'
,p_step_title=>unistr('\00DCberpr\00FCfen')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(638171842520952500)
,p_plug_name=>'Zusammenfassung'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_imp.id(3414127510682820548)
,p_plug_display_sequence=>10
,p_list_id=>wwv_flow_imp.id(638188819932952575)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(638171788128952500)
,p_plug_name=>unistr('Ergebnis \00DCberpr\00FCfen')
,p_parent_plug_id=>wwv_flow_imp.id(638171842520952500)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(638168875614952499)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(638171842520952500)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(638168570632952499)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(638171842520952500)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(638168718608952499)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(638171842520952500)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(638167179279952499)
,p_branch_action=>'f?p=&APP_ID.:566:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(638168570632952499)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(638167899008952499)
,p_branch_action=>'f?p=&APP_ID.:559:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(638168718608952499)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(638170405101952500)
,p_name=>'P563_MFV_TYP_ANZ'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(638171788128952500)
,p_use_cache_before_default=>'NO'
,p_prompt=>'MFV-Typ'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when :P550_MFV_TYP = 1 then ''Information''',
'else ''Interpretation''',
'end from dual;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(638169991237952500)
,p_name=>'P563_ARBEITSKREISE_ANZ'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(638171788128952500)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Gew\00E4hlte Arbeitskreise')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(bezeichnung, '':'') within group (order by bezeichnung) from t_et_b_ak where et_b_akid in (',
'    select column_value from table(apex_string.split(:P553_SELECTED_AK, '':'')));'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(638169571159952499)
,p_name=>'P563_STICHWORT_ANZ'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(638171788128952500)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Gew\00E4hlte Stichworte')
,p_source=>'P559_STICHWORTE_SEL'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(638169157828952499)
,p_name=>'P563_VORSCHRIFTEN_ANZ'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(638171788128952500)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Gew\00E4hlte Vorschriften')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vorschrift_nummer  from T_Vorschrift where vorschriftid in (',
'select column_value from table(apex_string.split_numbers(:P556_VORSCHRIFTEN_SEL,'':'')));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
