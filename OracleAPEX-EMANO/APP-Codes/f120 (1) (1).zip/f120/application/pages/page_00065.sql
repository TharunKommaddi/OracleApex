prompt --application/pages/page_00065
begin
--   Manifest
--     PAGE: 00065
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>65
,p_name=>'Benutzersuche'
,p_alias=>'BENUTZERSUCHE'
,p_page_mode=>'MODAL'
,p_step_title=>'Benutzersuche'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function fUse(aGid,aNachname,aVorname,aMail) {',
'',
'    $s(''P65_NACHNAME_AUSGEWAEHLT'',aNachname);',
'    $s(''P65_VORNAME_AUSGEWAEHLT'',aVorname);',
'    $s(''P65_EMAIL_AUSGEWAEHLT'',aMail);',
'    $s(''P65_GID_CHOSEN'',aGid);    ',
'}',
'',
'function fUse2(aGid,aNachname,aVorname,aMail, aAbteilung) {',
'    ',
'    $s(''P65_NACHNAME_AUSGEWAEHLT'',aNachname);',
'    $s(''P65_VORNAME_AUSGEWAEHLT'',aVorname);',
'    $s(''P65_EMAIL_AUSGEWAEHLT'',aMail);',
'    $s(''P65_ABTEILUNG_AUSGEWAEHLT'',aAbteilung);',
'    $s(''P65_GID_CHOSEN'',aGid);',
'     ',
'}',
'',
'function fUse421(aGid,aNachname,aVorname,aMail,aAbteilung) {',
'    ',
'    $s(''P65_NACHNAME_AUSGEWAEHLT'',aNachname);',
'    $s(''P65_VORNAME_AUSGEWAEHLT'',aVorname);',
'    $s(''P65_EMAIL_AUSGEWAEHLT'',aMail);',
'    $s(''P65_ABTEILUNG_AUSGEWAEHLT'',aAbteilung);',
'    $s(''P65_GID_CHOSEN'',aGid);',
'     ',
'}',
'',
'function fUse423(aGid,aNachname,aVorname,aMail,aAbteilung) {',
'    ',
'    $s(''P65_NACHNAME_AUSGEWAEHLT'',aNachname);',
'    $s(''P65_VORNAME_AUSGEWAEHLT'',aVorname);',
'    $s(''P65_EMAIL_AUSGEWAEHLT'',aMail);',
'    $s(''P65_ABTEILUNG_AUSGEWAEHLT'',aAbteilung);',
'    $s(''P65_GID_CHOSEN'',aGid);',
'     ',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7099069424711034585)
,p_plug_name=>'BUTTONS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7099069529018034586)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(2155730824381164077)
,p_name=>'Suchergebnis'
,p_parent_plug_id=>wwv_flow_imp.id(7099069529018034586)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:margin-top-lg'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select x.*, x.gid as gid2, x.gid as gid3, x.gid as gid4, ',
'x.gid as gid5,',
'x.gid as gid6,',
'x.gid as gid7,',
'x.gid as gid8',
'-- AUf T und P Koala_util.',
'from table(Koala_util.fLdapSearch(:P65_NACHNAME, ',
'  :P65_VORNAME, :P65_SUBDEPARTMENT, :P65_EMAIL)) x'))
,p_display_when_condition=>'P65_NACHNAME'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(481177177041835202)
,p_query_column_id=>1
,p_column_alias=>'GID'
,p_column_display_sequence=>1
,p_column_heading=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:55:&SESSION.::&DEBUG.:RP,55:P55_GID,P55_NACHNAME,P55_VORNAME,P55_ABTEILUNG,P55_EMAIL:#GID#,#SURNAME#,#GIVENNAME#,#SUBDEPARTMENT#,#MAIL#'
,p_column_linktext=>'<span class="fa fa-check" />'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P65_CAMEFROM'
,p_display_when_condition2=>'50'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(481176764762835201)
,p_query_column_id=>2
,p_column_alias=>'SURNAME'
,p_column_display_sequence=>46
,p_column_heading=>'Nachname'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(481176348076835201)
,p_query_column_id=>3
,p_column_alias=>'GIVENNAME'
,p_column_display_sequence=>56
,p_column_heading=>'Vorname'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(481175980203835201)
,p_query_column_id=>4
,p_column_alias=>'SUBDEPARTMENT'
,p_column_display_sequence=>66
,p_column_heading=>'Abteilung'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(481175568318835200)
,p_query_column_id=>5
,p_column_alias=>'MAIL'
,p_column_display_sequence=>76
,p_column_heading=>'E-Mail'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84709534474068501)
,p_query_column_id=>6
,p_column_alias=>'PHONE'
,p_column_display_sequence=>96
,p_column_heading=>'Phone'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84709359683068500)
,p_query_column_id=>7
,p_column_alias=>'COSTCENTER'
,p_column_display_sequence=>106
,p_column_heading=>'Costcenter'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(481174410594835200)
,p_query_column_id=>8
,p_column_alias=>'EN'
,p_column_display_sequence=>86
,p_column_heading=>'En'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(481173959058835200)
,p_query_column_id=>9
,p_column_alias=>'GID2'
,p_column_display_sequence=>2
,p_column_heading=>'&nbsp;'
,p_column_link=>'javascript:fUse("#GID2#")'
,p_column_linktext=>'<span class="fa fa-check" />'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P65_CAMEFROM'
,p_display_when_condition2=>'457'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(481173541303835199)
,p_query_column_id=>10
,p_column_alias=>'GID3'
,p_column_display_sequence=>3
,p_column_heading=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:415:&SESSION.::&DEBUG.:415:P415_NACHNAME,P415_VORNAME,P415_ABTEILUNG,P415_GID,P415_EMAIL:#SURNAME#,#GIVENNAME#,#SUBDEPARTMENT#,#GID3#,#MAIL#'
,p_column_linktext=>'<span class="fa fa-check" />'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P65_CAMEFROM'
,p_display_when_condition2=>'410'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(401856052937284868)
,p_query_column_id=>11
,p_column_alias=>'GID4'
,p_column_display_sequence=>4
,p_column_heading=>'&nbsp;'
,p_column_link=>'javascript:fUse("#GID2#","#SURNAME#","#GIVENNAME#","#MAIL#")'
,p_column_linktext=>'<span class="fa fa-check" />'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P65_CAMEFROM'
,p_display_when_condition2=>'926'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(357618234338193555)
,p_query_column_id=>12
,p_column_alias=>'GID5'
,p_column_display_sequence=>5
,p_column_heading=>'&nbsp;'
,p_column_link=>'javascript:fUse2("#GID5#","#SURNAME#","#GIVENNAME#","#MAIL#","#SUBDEPARTMENT#")'
,p_column_linktext=>'<span class="fa fa-check" />'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P65_CAMEFROM'
,p_display_when_condition2=>'386'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(357618079378193554)
,p_query_column_id=>13
,p_column_alias=>'GID6'
,p_column_display_sequence=>6
,p_column_heading=>'&nbsp;'
,p_column_link=>'javascript:fUse2("#GID5#","#SURNAME#","#GIVENNAME#","#MAIL#","#SUBDEPARTMENT#")'
,p_column_linktext=>'<span class="fa fa-check" />'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P65_CAMEFROM'
,p_display_when_condition2=>'388'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(639835698912867802)
,p_query_column_id=>14
,p_column_alias=>'GID7'
,p_column_display_sequence=>26
,p_column_heading=>'&nbsp;'
,p_column_link=>'javascript:fUse421("#GID7#","#SURNAME#","#GIVENNAME#","#MAIL#")'
,p_column_linktext=>'<span class="fa fa-check" />'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P65_CAMEFROM'
,p_display_when_condition2=>'421'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1094140200548624934)
,p_query_column_id=>15
,p_column_alias=>'GID8'
,p_column_display_sequence=>36
,p_column_heading=>'Gid8'
,p_column_link=>'javascript:fUse423("#GID8#","#SURNAME#","#GIVENNAME#","#MAIL#")'
,p_column_linktext=>'<span class="fa fa-check" />'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P65_CAMEFROM'
,p_display_when_condition2=>'423'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7099069623088034587)
,p_plug_name=>'Suchergebnis (Backup)'
,p_parent_plug_id=>wwv_flow_imp.id(7099069529018034586)
,p_region_template_options=>'#DEFAULT#:margin-top-lg'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select x.*, x.gid as gid2, x.gid as gid3',
'from table(ldap_util.fLdapSearch(:P65_NACHNAME, ',
'  :P65_VORNAME, :P65_SUBDEPARTMENT, :P65_EMAIL)) x'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'NEVER'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(7099069794066034588)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'Keine Suchergebnisse'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>8211762731161168992
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(481172124299835187)
,p_db_column_name=>'GID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:55:&SESSION.::&DEBUG.:RP,55:P55_GID,P55_NACHNAME,P55_VORNAME,P55_ABTEILUNG,P55_EMAIL:#GID#,#SURNAME#,#GIVENNAME#,#SUBDEPARTMENT#,#MAIL#'
,p_column_linktext=>'<span class="fa fa-check" />'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P65_CAMEFROM'
,p_display_condition2=>'50'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(481168866951835184)
,p_db_column_name=>'GID2'
,p_display_order=>20
,p_column_identifier=>'I'
,p_column_label=>'&nbsp;'
,p_column_link=>'javascript:fUse("#GID2#")'
,p_column_linktext=>'<span class="fa fa-check" />'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P65_CAMEFROM'
,p_display_condition2=>'327'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(481172514246835187)
,p_db_column_name=>'GID3'
,p_display_order=>30
,p_column_identifier=>'J'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:415:&SESSION.::&DEBUG.:415:P415_NACHNAME,P415_VORNAME,P415_ABTEILUNG,P415_GID,P415_EMAIL:#SURNAME#,#GIVENNAME#,#SUBDEPARTMENT#,#GID3#,#MAIL#'
,p_column_linktext=>'<span class="fa fa-check" />'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P65_CAMEFROM'
,p_display_condition2=>'410'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(481171727539835187)
,p_db_column_name=>'SURNAME'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Nachname'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(481171275115835186)
,p_db_column_name=>'GIVENNAME'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Vorname'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(481170902384835185)
,p_db_column_name=>'SUBDEPARTMENT'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Abteilung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(481170454620835185)
,p_db_column_name=>'MAIL'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'E-Mail'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(481170044748835185)
,p_db_column_name=>'PHONE'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'Telefon'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(481169701510835184)
,p_db_column_name=>'COSTCENTER'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Costcenter'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(481169320389835184)
,p_db_column_name=>'EN'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>'En'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(7099111024349800525)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'6315244'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'GID:SURNAME:GIVENNAME:SUBDEPARTMENT:MAIL:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(481180496072835223)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(7099069424711034585)
,p_button_name=>'SEARCH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Suchen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(481179910465835211)
,p_name=>'P65_CAMEFROM'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(7099069529018034586)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(481179465337835209)
,p_name=>'P65_NACHNAME'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(7099069529018034586)
,p_prompt=>'Nachname'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'Y',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(481179098405835209)
,p_name=>'P65_VORNAME'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(7099069529018034586)
,p_prompt=>'Vorname'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'Y',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(481178700241835209)
,p_name=>'P65_SUBDEPARTMENT'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(7099069529018034586)
,p_prompt=>'Abteilung'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'Y',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(481178255290835209)
,p_name=>'P65_EMAIL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(7099069529018034586)
,p_prompt=>'E-Mail'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'Y',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(481177860664835209)
,p_name=>'P65_GID_CHOSEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(7099069529018034586)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401854973003284857)
,p_name=>'P65_NACHNAME_AUSGEWAEHLT'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(7099069529018034586)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401854924115284856)
,p_name=>'P65_VORNAME_AUSGEWAEHLT'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(7099069529018034586)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(380765633077058800)
,p_name=>'P65_EMAIL_AUSGEWAEHLT'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(7099069529018034586)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(346700931143268690)
,p_name=>'P65_ABTEILUNG_AUSGEWAEHLT'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(7099069529018034586)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(481167655364835156)
,p_name=>unistr('GID gew\00E4hlt')
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P65_GID_CHOSEN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P65_CAMEFROM'
,p_display_when_cond2=>'457'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(481167161610835155)
,p_event_id=>wwv_flow_imp.id(481167655364835156)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
,p_attribute_01=>'P65_GID_CHOSEN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(401855674209284864)
,p_name=>unistr('GID gew\00E4hlt (926)')
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P65_GID_CHOSEN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P65_CAMEFROM'
,p_display_when_cond2=>'926'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401855536378284862)
,p_event_id=>wwv_flow_imp.id(401855674209284864)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P65_NACHNAME_AUSGEWAEHLT,P65_VORNAME_AUSGEWAEHLT,P65_GID_CHOSEN,P65_EMAIL_AUSGEWAEHLT'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(380765675210058801)
,p_event_id=>wwv_flow_imp.id(401855674209284864)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(346701974478268701)
,p_name=>unistr('GID gew\00E4hlt(386)')
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P65_GID_CHOSEN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P65_CAMEFROM'
,p_display_when_cond2=>'386'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(346701916258268700)
,p_event_id=>wwv_flow_imp.id(346701974478268701)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P65_NACHNAME_AUSGEWAEHLT,P65_VORNAME_AUSGEWAEHLT,P65_GID_CHOSEN,P65_EMAIL_AUSGEWAEHLT,P65_ABTEILUNG_AUSGEWAEHLT'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(346701763812268699)
,p_event_id=>wwv_flow_imp.id(346701974478268701)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(346699464262268676)
,p_name=>unistr('GID gew\00E4hlt(388)')
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P65_GID_CHOSEN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P65_CAMEFROM'
,p_display_when_cond2=>'388'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(346699370141268675)
,p_event_id=>wwv_flow_imp.id(346699464262268676)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P65_NACHNAME_AUSGEWAEHLT,P65_VORNAME_AUSGEWAEHLT,P65_GID_CHOSEN,P65_EMAIL_AUSGEWAEHLT,P65_ABTEILUNG_AUSGEWAEHLT'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(346699247011268674)
,p_event_id=>wwv_flow_imp.id(346699464262268676)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3163690484584928907)
,p_name=>unistr('GID gew\00E4hlt(421)')
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P65_GID_CHOSEN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P65_CAMEFROM'
,p_display_when_cond2=>'421'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3163690320009928906)
,p_event_id=>wwv_flow_imp.id(3163690484584928907)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P65_NACHNAME_AUSGEWAEHLT,P65_VORNAME_AUSGEWAEHLT,P65_GID_CHOSEN,P65_EMAIL_AUSGEWAEHLT,P65_ABTEILUNG_AUSGEWAEHLT'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3163690222888928905)
,p_event_id=>wwv_flow_imp.id(3163690484584928907)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1072843417444081024)
,p_name=>unistr('GID gew\00E4hlt(423)')
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P65_GID_CHOSEN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P65_CAMEFROM'
,p_display_when_cond2=>'423'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1072843366260081023)
,p_event_id=>wwv_flow_imp.id(1072843417444081024)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P65_NACHNAME_AUSGEWAEHLT,P65_VORNAME_AUSGEWAEHLT,P65_GID_CHOSEN,P65_EMAIL_AUSGEWAEHLT,P65_ABTEILUNG_AUSGEWAEHLT'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1072843306112081022)
,p_event_id=>wwv_flow_imp.id(1072843417444081024)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(739322600440286563)
,p_name=>'Dialog 55 closed --> Close this dialog as well'
,p_event_sequence=>70
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data.dialogPageId == 55'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(739322510325286562)
,p_event_id=>wwv_flow_imp.id(739322600440286563)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp.component_end;
end;
/
