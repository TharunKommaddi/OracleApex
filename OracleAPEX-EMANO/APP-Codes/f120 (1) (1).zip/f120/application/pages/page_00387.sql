prompt --application/pages/page_00387
begin
--   Manifest
--     PAGE: 00387
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>387
,p_name=>'Anwender einem Arbeitskreis zuordnen'
,p_alias=>'ANWENDER-EINEM-ARBEITSKREIS-ZUORDNEN'
,p_page_mode=>'MODAL'
,p_step_title=>'Anwender einem Arbeitskreis zuordnen'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('var htmldb_delete_message=''"M\00F6chten Sie die Zuordnung des Benutzers als Experte zum Thema entfernen?"'';'),
'function diolguehead() {',
'    ',
'    if ($(''#P387_JS_LANG'').val() === ''en'') {',
'        apex.util.getTopApex().jQuery(".ui-dialog-title").html(''Assign users to a working group <span onclick="redirect(305)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'    }',
'    if ($(''#P387_JS_LANG'').val() === ''de'') {',
'        apex.util.getTopApex().jQuery(".ui-dialog-title").html(''Anwender einem Arbeitskreis zuordnen <span onclick="redirect(305)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'    }',
'    ',
'}'))
,p_javascript_code_onload=>'diolguehead();'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(854988725108302025)
,p_plug_name=>'Anwender einem Arbeitskreis zuordnen'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_ET_B_AK_REF_THEMA_BENUTZER'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_ajax_items_to_submit=>'P387_JS_LANG'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(854982066302301942)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(339789507631834819)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_button_name=>'SEARCH_LDAP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'In LDAP suchen'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:65:&SESSION.::&DEBUG.:65:P65_CAMEFROM:387'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(userId => PCK_RI.fGetUserId, ',
'                      pageId => :APP_PAGE_ID,',
'                      accessMode => 200))'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(854981700414301940)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(854982066302301942)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(854980037308301927)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(854982066302301942)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Entfernen'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P387_ET_B_AK_REF_THEMA_BENUTZERID is not null',
'and (',
'    pck_ri.fIsUserInRolle(listRolleId => 1003) > 0 --Anzeige wenn Admin',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(854979777993301926)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(854982066302301942)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P387_ET_B_AK_REF_THEMA_BENUTZERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(854979353966301926)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(854982066302301942)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P387_ET_B_AK_REF_THEMA_BENUTZERID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(941832462072351402)
,p_name=>'P387_JS_LANG'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_item_default=>':FSP_LANGUAGE_PREFERENCE'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(854988415357302024)
,p_name=>'P387_ET_B_AK_REF_THEMA_BENUTZERID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_item_source_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_source=>'ET_B_AK_REF_THEMA_BENUTZERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(854987966613301995)
,p_name=>'P387_ET_B_AKID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_item_source_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_source=>'ET_B_AKID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(854987143042301976)
,p_name=>'P387_BEMERKUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_item_source_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_prompt=>'Bemerkung'
,p_source=>'BEMERKUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>200
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(854986022349301957)
,p_name=>'P387_THEMA_REF_ET_B_AKID'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_prompt=>'Thema'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(t.THEMA_REF_ET_B_AKID, '':'')',
'from T_ET_B_AK_REF_THEMA_BENUTZER_REF_ET_B_AK_REF_THEMA t',
'where t.ET_B_AK_REF_THEMA_BENUTZERID = :P387_ET_B_AK_REF_THEMA_BENUTZERID'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'     with cte_387 as(',
'            select t.nummer || '' '' || CASE ',
'                WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' ',
'               THEN  concat(t.bezeichnung, case when (nvl(t.gueltig,0)=0) then '' (in GETEX inaktiv)'' else '' '' end )',
'                ELSE concat(t.name_eng, case when (nvl(t.gueltig,0)=0) then '' (in GETEX inactive)'' else '' '' end )',
'            END as d, trak.THEMA_REF_ET_B_AKID as r,  vt.thema_sortorder',
'        from t_THEMA_REF_ET_B_AK trak',
'        inner join t_thema t on t.themaid = trak.themaid',
'        inner join v_thema_baum vt on (t.themaid = vt.themaid)',
'        where trak.ET_B_AKID = :P387_ET_B_AKID',
'        UNION',
'         -- damit die bereits zugewiesene inaktive Themen angezeigt werden',
'            select t.nummer || '' '' || CASE ',
'                WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' ',
'               THEN  concat(t.bezeichnung, case when (nvl(t.gueltig,0)=0) then '' (in GETEX inaktiv)'' else '' '' end )',
'                ELSE concat(t.name_eng, case when (nvl(t.gueltig,0)=0) then '' (in GETEX inactive)'' else '' '' end )',
'            END as d, trak.THEMA_REF_ET_B_AKID as r,  vt.thema_sortorder',
'        from t_THEMA_REF_ET_B_AK trak',
'        inner join t_thema t on t.themaid = trak.themaid',
'        inner join v_thema_baum vt on (t.themaid = vt.themaid)',
'        where trak.THEMA_REF_ET_B_AKID in ( select column_value from apex_string.split_numbers(:P387_THEMA_REF_ET_B_AKID, '':'') )',
'        --trak.ET_B_AKID = :P387_ET_B_AKID',
')',
' select d, r from cte_387',
'order by cte_387.thema_sortorder',
'',
'',
''))
,p_lov_cascade_parent_items=>'P387_ET_B_AKID'
,p_ajax_items_to_submit=>'P387_ET_B_AKID'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>32
,p_cMaxlength=>255
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'    pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') = 0 --ReadOnly, wenn kein Admin',
')'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(854985619788301951)
,p_name=>'P387_BEREICH'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_item_source_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_prompt=>'Vertretener Bereich'
,p_source=>'BEREICH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>200
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_inline_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Beispiel Mehrere Bereiche: I/EM-X, I/EM-1 <br>',
'Beispiel ein Bereich: I/EM-X'))
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(854985231688301945)
,p_name=>'P387_APPROVED'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_item_source_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_prompt=>unistr('Best\00E4tigt')
,p_source=>'APPROVED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'    pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') = 0 --ReadOnly, wenn kein Admin',
'    and pck_ri.fIsUserInRolle(listRolleId => ''1002'') = 0',
')'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Nein',
  'off_value', '0',
  'on_label', 'Ja',
  'on_value', '20',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(854970273923138201)
,p_name=>'P387_BENUTZER_COLOR'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(845779701442438292)
,p_name=>'P387_ROLLE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_item_source_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_prompt=>'Rolle'
,p_source=>'ROLLEID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rolle as d, rolleid as r --brf.benutzer_ref_rolleid as r',
'from t_rolle ',
'   where rolleid in (',
'    1001 -- ZVEX',
'    , 1002 -- VEX',
'    , 1006 -- FbEx',
'    , 1040 -- KFEx',
'    )'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'(keine)'
,p_lov_cascade_parent_items=>'P387_JS_LANG'
,p_ajax_items_to_submit=>'P387_JS_LANG'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'    pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') = 0 --ReadOnly, wenn kein Admin',
')'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(772173712460661002)
,p_name=>'P387_BENUTZERNAME_FREITEXT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_item_source_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_prompt=>'ODER Direkteingabe Benutzername'
,p_source=>'BENUTZERNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct benutzername from t_et_b_ak_ref_thema_benutzer',
'order by benutzername'))
,p_lov_cascade_parent_items=>'P387_JS_LANG'
,p_ajax_items_to_submit=>'P387_JS_LANG'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_cMaxlength=>248
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'fetch_on_type', 'N',
  'match_type', 'CONTAINS_IGNORE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(346700222304268683)
,p_name=>'P387_NACHNAME'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_prompt=>'Nachname'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(346699840388268680)
,p_name=>'P387_VORNAME'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_prompt=>'Vorname'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(346699794659268679)
,p_name=>'P387_EMAIL'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(346699731791268678)
,p_name=>'P387_ABTEILUNG'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(346699545079268677)
,p_name=>'P387_BENUTZER_GID'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'B'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(346698661328268668)
,p_name=>'P387_R_BENUTZERID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_item_source_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_source=>'BENUTZERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(337626413445617297)
,p_name=>'P387_BETREUERID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_item_source_plug_id=>wwv_flow_imp.id(854988725108302025)
,p_prompt=>'Betreuung durch VEX'
,p_source=>'BETREUERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct b.nachname||'',''||b.vorname as d, ET_B_AK_REF_THEMA_BENUTZERID r ',
'  from t_ET_B_AK_REF_THEMA_BENUTZER artb',
'  join t_benutzer b on (b.benutzerid = artb.benutzerid )',
' where RolleId = 1002  ',
' order by 1',
'',
' '))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P387_JS_LANG'
,p_ajax_items_to_submit=>'P387_JS_LANG'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(845778699366438282)
,p_validation_name=>'V_AK_HAS_THEMEN'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from t_THEMA_REF_ET_B_AK trak',
'inner join t_thema t on t.themaid = trak.themaid',
'where trak.ET_B_AKID = :P387_ET_B_AKID'))
,p_validation_type=>'EXISTS'
,p_error_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Der Arbeitskreis ist noch keinem Thema zugeordnet.',
unistr('Die Zuordnung erfolgt in der Maske "Thema bearbeiten / hinzuf\00FCgen" der Themenverwaltung.')))
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(854986022349301957)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(337625710996617290)
,p_validation_name=>'Wert Gesetzt'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'nvl(:P387_ROLLE, 0) !=1006 or',
'(nvl(:P387_ROLLE, 0)=1006 and ( :P387_BETREUERID is not null or nvl(:P387_APPROVED, 0) =0) )'))
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Betreuer muss gew\00E4hlt werden!')
,p_always_execute=>'Y'
,p_validation_condition=>'SAVE, CREATE'
,p_validation_condition_type=>'REQUEST_IN_CONDITION'
,p_associated_item=>wwv_flow_imp.id(337626413445617297)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1036496262272372585)
,p_validation_name=>'Wert Gesetzt_FBEx_Create'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'nvl(:P387_ROLLE, 0) !=1006 or',
'( nvl(:P387_ROLLE, 0)=1006 and ( :P387_BETREUERID is not null ) )'))
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Betreuer muss gew\00E4hlt werden!')
,p_always_execute=>'Y'
,p_validation_condition=>'CREATE'
,p_validation_condition_type=>'REQUEST_IN_CONDITION'
,p_associated_item=>wwv_flow_imp.id(337626413445617297)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(854981620693301940)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(854981700414301940)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(854980790828301930)
,p_event_id=>wwv_flow_imp.id(854981620693301940)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(863758686402305654)
,p_name=>'change_color'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P387_ROLLE,P387_APPROVED,P387_BENUTZERNAME_FREITEXT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(854970209984138200)
,p_event_id=>wwv_flow_imp.id(863758686402305654)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P387_APPROVED := case',
'       when :P387_ROLLE is null AND (:P387_NACHNAME is null and :P387_BENUTZERNAME_FREITEXT is null) then 0',
'       else :P387_APPROVED',
'  end;'))
,p_attribute_02=>'P387_ROLLE,P387_APPROVED,P387_BENUTZERNAME_FREITEXT'
,p_attribute_03=>'P387_APPROVED'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(854970494253138203)
,p_event_id=>wwv_flow_imp.id(863758686402305654)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  :P387_BENUTZER_COLOR := case',
'       when :P387_ROLLE is null AND :P387_NACHNAME is null AND :P387_BENUTZERNAME_FREITEXT is null then ''pink''',
'       when (:P387_ROLLE is not null OR :P387_BENUTZERNAME_FREITEXT is not null OR :P387_NACHNAME is not null) and :P387_APPROVED = 0 then ''yellow''',
'       when (:P387_ROLLE is not null OR :P387_BENUTZERNAME_FREITEXT is not null OR :P387_NACHNAME is not null) and :P387_APPROVED = 20 then ''lightgreen''',
'       else ''none''',
'  end;',
''))
,p_attribute_02=>'P387_ROLLE,P387_NACHNAME,P387_APPROVED'
,p_attribute_03=>'P387_BENUTZER_COLOR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(852830539439138195)
,p_name=>'benutzer_color_changed'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P387_BENUTZER_COLOR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(852830414028138193)
,p_event_id=>wwv_flow_imp.id(852830539439138195)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#P387_ROLLE'').css(''background-color'', $v(''P387_BENUTZER_COLOR''));',
'$(''#P387_NACHNAME'').css(''background-color'', $v(''P387_BENUTZER_COLOR''));'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(841242528640151003)
,p_name=>'Ist AK einemThema zugeordnet'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NOT_EXISTS'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from t_THEMA_REF_ET_B_AK trak',
'inner join t_thema t on t.themaid = trak.themaid',
'where trak.ET_B_AKID = :P387_ET_B_AKID'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(841242374961151002)
,p_event_id=>wwv_flow_imp.id(841242528640151003)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Der Arbeitskreis ist noch keinem Thema zugeordnet.',
unistr('Die Zuordnung erfolgt in der Maske &quot;Thema bearbeiten / hinzuf\00FCgen&quot; der Themenverwaltung.')))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(346700043178268682)
,p_name=>'Dialog Closed'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(339789507631834819)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(346700025531268681)
,p_event_id=>wwv_flow_imp.id(346700043178268682)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' l_co number :=0;',
'begin',
' if (:P65_GID_CHOSEN is not null) then',
'   select :P65_NACHNAME_AUSGEWAEHLT, :P65_VORNAME_AUSGEWAEHLT, :P65_EMAIL_AUSGEWAEHLT, :P65_ABTEILUNG_AUSGEWAEHLT, :P65_GID_CHOSEN ',
'     into     :P387_NACHNAME,      :P387_VORNAME,         :P387_EMAIL,            :P387_ABTEILUNG,    :P387_BENUTZER_GID',
'     from dual;',
'  end if;',
'',
'--  :P387_R_BENUTZERID := PCK_RI.fCreatePlaceHolderUser(:P65_GID_CHOSEN);',
' if (:P387_BENUTZER_GID is not null) then',
'     select count(*) into l_co   from t_benutzer where GID = :P65_GID_CHOSEN;',
'     if(l_co >0) then',
'         select  Benutzerid into  :P387_R_BENUTZERID from t_benutzer ',
'         where GID = :P387_BENUTZER_GID fetch  first 1 rows only;',
'        -- debug (''exist benutz id=''||:P387_R_BENUTZERID);',
'     else',
'       insert into t_benutzer (gid, nachname, vorname, email, abteilung)',
'       values ( :P65_GID_CHOSEN, :P65_NACHNAME_AUSGEWAEHLT, :P65_VORNAME_AUSGEWAEHLT, :P65_EMAIL_AUSGEWAEHLT, :P65_ABTEILUNG_AUSGEWAEHLT )',
'       returning benutzerid into :P387_R_BENUTZERID;',
'       --debug (''erstellt benutz id=''||:P387_R_BENUTZERID);',
'     end if;',
'     ',
'  end if;   ',
'  if(:P387_BENUTZER_GID is not null) then',
'      :P387_BENUTZERNAME_FREITEXT := '''';',
'  end if;',
'end;'))
,p_attribute_02=>'P387_JS_LANG'
,p_attribute_03=>'P65_NACHNAME_AUSGEWAEHLT,P65_VORNAME_AUSGEWAEHLT,P65_EMAIL_AUSGEWAEHLT,P65_GID_CHOSEN,P387_NACHNAME,P387_VORNAME,P387_EMAIL,P387_BENUTZER_GID,P65_ABTEILUNG_AUSGEWAEHLT,P387_ABTEILUNG,P387_BENUTZERNAME_FREITEXT,P387_R_BENUTZERID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(346698551908268667)
,p_name=>'Enter in'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P387_BENUTZERNAME_FREITEXT'
,p_condition_element=>'P387_BENUTZERNAME_FREITEXT'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseleave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(346698523514268666)
,p_event_id=>wwv_flow_imp.id(346698551908268667)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  '''',            '''',                  '''',             '''' ,             '''',           '''' ',
'into :P387_BENUTZER_GID, :P387_R_BENUTZERID, :P387_NACHNAME, :P387_VORNAME, :P387_EMAIL, :P387_ABTEILUNG from dual;'))
,p_attribute_02=>'P387_JS_LANG'
,p_attribute_03=>'P387_BENUTZER_GID,P387_R_BENUTZERID,P387_NACHNAME,P387_VORNAME,P387_EMAIL,P387_ABTEILUNG'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(337626150744617295)
,p_name=>'Betreuer Visibility'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P387_ROLLE'
,p_condition_element=>'P387_ROLLE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1006'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(337626014760617293)
,p_event_id=>wwv_flow_imp.id(337626150744617295)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P387_BETREUERID'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(337626105472617294)
,p_event_id=>wwv_flow_imp.id(337626150744617295)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P387_BETREUERID'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(337625526295617288)
,p_event_id=>wwv_flow_imp.id(337626150744617295)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P387_BETREUERID'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'l_co number :=0;',
'l_betreuerid number :=0;',
'begin',
'  --set Betreuer automatic to user if he has VEX role',
'    select count(*) into l_co from t_et_b_ak_ref_thema_benutzer where benutzerid = pck_ri.fGetUserid and rolleid = 1002;',
'    if (l_co > 0) then',
'        select et_b_ak_ref_thema_benutzerid ',
'          into l_betreuerid ',
'          from t_et_b_ak_ref_thema_benutzer ',
'         where  benutzerid = pck_ri.fGetUserid  --1280  --',
'           and rolleid = 1002 fetch first 1 rows only;',
'           --debug(''from Dyn Act  p387 betreuerid=''|| l_betreuerid);',
'        return l_betreuerid;',
'    end if;',
'    return null;',
' end;'))
,p_attribute_07=>'P387_JS_LANG'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_server_condition_type=>'EXPRESSION'
,p_server_condition_expr1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsUserInRolle(pck_ri.fGetUSerId, ''1003:1000'') >0',
'OR ',
'( :P387_ET_B_AK_REF_THEMA_BENUTZERID is NULL and ',
' pck_ri.fIsUserInRolle(pck_ri.fGetUSerId, ''1002'') > 0 )',
''))
,p_server_condition_expr2=>'PLSQL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(339769043887561901)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'erstelle Benutzer'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_co number :=0;',
'begin',
'    --debug(''P386_ET_B_AK_REF_BENUTZERID=''|| :P386_ET_B_AK_REF_BENUTZERID);',
'    --debug(''save/create process :P387_R_BENUTZERID=''|| :P387_R_BENUTZERID);',
'     select count(*) into l_co from t_benutzer where gid = :P387_BENUTZER_GID;',
'    if (:P387_R_BENUTZERID is null and l_co =0 and :P387_NACHNAME is not null ) then',
'      insert into t_benutzer (gid,   nachname,        vorname,              email,   abteilung)',
'       values (  :P387_BENUTZER_GID, :P387_NACHNAME, :P387_VORNAME, :P387_EMAIL, :P387_ABTEILUNG )',
'       returning benutzerid into :P387_R_BENUTZERID;',
'      -- debug('' after insert :P387_R_BENUTZERID=''|| :P387_R_BENUTZERID);',
'       commit;',
'     end if;',
' end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Fehler im Prozess "erstelle Benutzer"'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3332443272011826334
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(929250933550458754)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'BASIS_Rolle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (:P387_R_BENUTZERID is not null) then',
unistr('    -- Recht f\00FCr Suche'),
'    insert into t_benutzer_ref_rolle (benutzerid, rolleid)',
'        select :P387_R_BENUTZERID, 1004 from dual',
'        where not exists (',
'            select 1 from t_benutzer_ref_rolle',
'            where benutzerid = :P387_R_BENUTZERID',
'        );',
'    -- Basisrecht',
'    insert into t_benutzer_ref_rolle (benutzerid, rolleid)',
'        select :P387_R_BENUTZERID, 1010 from dual',
'        where not exists (',
'            select 1 from t_benutzer_ref_rolle',
'            where benutzerid = :P387_R_BENUTZERID and rolleid = 1010',
'        );',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2742961382348929481
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(845779228976438287)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Process L\00F6sche Themen des Anwenders')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from T_ET_B_AK_REF_THEMA_BENUTZER_REF_ET_B_AK_REF_THEMA',
'where ET_B_AK_REF_THEMA_BENUTZERID = :P387_ET_B_AK_REF_THEMA_BENUTZERID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(854980037308301927)
,p_internal_uid=>2826433086922949948
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(337625554305617289)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'remove Betreuer'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (:P387_ROLLE !=1006 ) then',
'  :P387_BETREUERID := null;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3334586761593770946
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(337625026851617283)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Disapprove FBEX rolles on DELETE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- wenn Vex gel\00F6scht wird setze  die von ihm betreuenden FBEX auf null und approve status auf 0'),
'if( :P387_ROLLE =1002) then',
'    update T_ET_B_AK_REF_THEMA_BENUTZER',
'       set betreuerid = '''', approved = 0  ',
'     where betreuerid = :P387_ET_B_AK_REF_THEMA_BENUTZERID;',
' end if;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'null;'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(854980037308301927)
,p_internal_uid=>3334587289047770952
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(337624897249617282)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Disapprove FBEX rolles on SAVE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- wenn ein Satz gespeichert wird  und rolle nicht VEX  => konnte sein das es ver\00E4ndert ist und ursprunglich = VEX'),
'-- dann setze  die von ihm betreuenden FBEX auf null und approve status auf 0',
'if( :P387_ROLLE != 1002) then',
'    update T_ET_B_AK_REF_THEMA_BENUTZER',
'       set betreuerid = '''', approved = 0  ',
'     where betreuerid = :P387_ET_B_AK_REF_THEMA_BENUTZERID;',
' end if;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'null;'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(854979777993301926)
,p_internal_uid=>3334587418649770953
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(854978614947301922)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(854988725108302025)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Anwender einem Arbeitskreis zuordnen'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2817233700952086313
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(845779607288438291)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process Themen dem Anwender zuordnen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'merge into T_ET_B_AK_REF_THEMA_BENUTZER_REF_ET_B_AK_REF_THEMA dest',
'using (select :P387_ET_B_AK_REF_THEMA_BENUTZERID as ET_B_AK_REF_THEMA_BENUTZERID, column_value as THEMA_REF_ET_B_AKID ',
'       from table(apex_string.split_numbers(:P387_THEMA_REF_ET_B_AKID, '':''))) src',
'on (src.ET_B_AK_REF_THEMA_BENUTZERID = dest.ET_B_AK_REF_THEMA_BENUTZERID',
'   and src.THEMA_REF_ET_B_AKID = dest.THEMA_REF_ET_B_AKID)',
'when not matched then ',
'insert (ET_B_AK_REF_THEMA_BENUTZERID, THEMA_REF_ET_B_AKID)',
'values (src.ET_B_AK_REF_THEMA_BENUTZERID, src.THEMA_REF_ET_B_AKID);',
'',
'delete from T_ET_B_AK_REF_THEMA_BENUTZER_REF_ET_B_AK_REF_THEMA ',
'where ET_B_AK_REF_THEMA_BENUTZERID = :P387_ET_B_AK_REF_THEMA_BENUTZERID',
'    and THEMA_REF_ET_B_AKID not in (select column_value from TABLE(APEX_STRING.split_numbers(:P387_THEMA_REF_ET_B_AKID, '':'')));',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE, CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2826432708610949944
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(854978173407301922)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_01=>'P387_JS_LANG'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2817234142492086313
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(854978968491301923)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(854988725108302025)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Anwender einem Arbeitskreis zuordnen'
,p_attribute_01=>'P387_JS_LANG'
,p_attribute_02=>'P387_JS_LANG'
,p_attribute_03=>'P387_JS_LANG'
,p_internal_uid=>2817233347408086312
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(346699162519268673)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Benutzerdaten'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_co number :=0;',
'begin',
'  if(:P387_R_BENUTZERID is  null and :P387_ET_B_AK_REF_THEMA_BENUTZERID is not null) then',
'     select benutzerid into  :P387_R_BENUTZERID  from  T_ET_B_AK_REF_THEMA_BENUTZER  ',
'     where  ET_B_AK_REF_THEMA_BENUTZERID = :P387_ET_B_AK_REF_THEMA_BENUTZERID fetch first 1 rows only ;',
'    ',
'  end if;',
'   --debug( ''Render :P387_R_BENUTZERID=''||:P387_R_BENUTZERID);',
'  --debug( '':P387_ET_B_AKID=''||:P387_ET_B_AKID);',
'  if(:P387_R_BENUTZERID is not null ) then',
'      select b.gid,            b.nachname,           b.vorname,      b.email, b.Abteilung',
'      into :P387_BENUTZER_GID,  :P387_NACHNAME, :P387_VORNAME, :P387_EMAIL, :P387_ABTEILUNG',
'      from t_benutzer b',
'      where b.benutzerid =  nvl(:P387_R_BENUTZERID, -1);',
'   end if;',
'',
'  -- wenn  benutzer is VEX und nicht gleichzeitig VKO oder Fachadmin, dann  Vorbelege Rolle als FBEx',
'  select count(*) into l_co from dual ',
'     where --1280 not in ( select distinct benutzerid from t_et_b_ak_ref_Benutzer) and ',
'        pck_ri.fgetUserid in ( select distinct benutzerid from t_benutzer_ref_Rolle where rolleid =1002)',
'        and pck_ri.fgetUserid not in ( select distinct benutzerid from t_benutzer_ref_Rolle where rolleid in (1003, 1000) );',
'   if(l_co > 0 and :P387_ET_B_AK_REF_THEMA_BENUTZERID is null) then --   lege  Rolle auf FBEX fest',
'      :P387_ROLLE := 1006;',
'      :P387_APPROVED := 0;',
'   end if;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>3325513153380119562
);
wwv_flow_imp.component_end;
end;
/
