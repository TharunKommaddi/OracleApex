prompt --application/pages/page_00465
begin
--   Manifest
--     PAGE: 00465
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>465
,p_name=>unistr('Fehlende Vorschrift hinzuf\00FCgen/bearbeiten')
,p_alias=>unistr('FEHLENDE-VORSCHRIFT-HINZUF\00DCGEN-BEARBEITEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Fehlende Vorschrift hinzuf\00FCgen/bearbeiten')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Function to select regulation from table',
'// function selectRegulation(vorschriftId, vorschriftNummer, publisher) {',
'//     console.log(''Selected regulation:'', vorschriftId, vorschriftNummer, publisher);',
'    ',
'//     // Set the selected regulation',
'//     apex.item(''P465_VORSCHRIFT_NUMMER'').setValue(vorschriftId);',
'    ',
'//     // Set the publisher',
'//     apex.item(''P465_PUBLISHER'').setValue(publisher || '''');',
'    ',
'//     // Hide selection region, show form',
'//     $(''.regulation-selection-region'').hide();',
'//     $(''.regulation-form-region'').show();',
'',
'//     // class to show back button',
'//     $(''.ui-dialog'').addClass(''show-form'');',
'//     $(''body'').addClass(''show-form'');',
'    ',
'//     // Show success message',
unistr('//     apex.message.showPageSuccess(''Vorschrift "'' + vorschriftNummer + ''" ausgew\00E4hlt'');'),
'    ',
'//     // Auto-populate title field',
'//     // if (!apex.item(''P465_THEMABEZEICHNUNG'').getValue()) {',
unistr('//     //     apex.item(''P465_THEMABEZEICHNUNG'').setValue(''Manuelle Eingabe f\00FCr '' + vorschriftNummer);'),
'//     // }',
'// }',
'',
'',
'// Function to select regulation from table',
'function selectRegulation(vorschriftId, vorschriftNummer, publisher) {',
'    console.log(''Selected regulation:'', vorschriftId, vorschriftNummer, publisher);',
'    ',
'    // Set the ID (hidden field) - this is what gets saved to database',
'    apex.item(''P465_VORSCHRIFT_ID'').setValue(vorschriftId);',
'    ',
'    // Set the display value (shows the regulation number to user)',
'    apex.item(''P465_VORSCHRIFT_NUMMER'').setValue(vorschriftNummer);',
'    ',
'    // Set the publisher',
'    apex.item(''P465_PUBLISHER'').setValue(publisher || '''');',
'    ',
'    // Hide selection region, show form',
'    $(''.regulation-selection-region'').hide();',
'    $(''.regulation-form-region'').show();',
'',
'    // class to show back button',
'    $(''.ui-dialog'').addClass(''show-form'');',
'    $(''body'').addClass(''show-form'');',
'    ',
'    // Show success message',
unistr('    apex.message.showPageSuccess(''Vorschrift "'' + vorschriftNummer + ''" ausgew\00E4hlt'');'),
'}',
'',
'',
'',
'// Function to go back to selection',
'function backToSelection() {',
'    $(''.regulation-selection-region'').show();',
'    $(''.regulation-form-region'').hide();',
'    ',
'    // Clear form values',
'    apex.item(''P465_VORSCHRIFT_NUMMER'').setValue('''');',
'    apex.item(''P465_THEMABEZEICHNUNG'').setValue('''');',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(document).ready(function() {',
'    if ($v(''P465_MODE'') === ''CREATE'') {',
'        // Show regulation selection first for CREATE mode',
'        $(''.regulation-selection-region'').show();',
'        $(''.regulation-form-region'').hide();',
'    } else {',
'        // Edit mode - show form',
'        $(''.regulation-selection-region'').hide();',
'        $(''.regulation-form-region'').show();',
'    }',
'});',
'',
'',
'// Make Vorschrift Nummer read-only',
'// apex.item("P465_VORSCHRIFT_NUMMER").disable();',
'',
'',
'// apex.item("P465_VORSCHRIFT_NUMMER").node.readOnly = true;'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Selection button styling */',
'.regulation-select-btn {',
'    margin: 2px;',
'}',
'',
'/* Hide back button initially (when selection table is shown) */',
'.t-Button[data-action="BACK_TO_SELECTION"] {',
'    display: none;',
'}',
'',
'/* Show back button only when form is visible */',
'.show-form .t-Button[data-action="BACK_TO_SELECTION"] {',
'    display: inline-block !important;',
'}',
'',
'',
'',
'',
'',
'tr:hover .t-Button {',
'    background-color: black !important;',
'    color: white !important;',
'}',
'',
'',
'',
'',
'',
'',
'/* Hide Erstellen button initially */',
'#btn_erstellen {',
'    display: none !important;',
'}',
'',
'/* Show Erstellen button only when form is visible */',
'.show-form #btn_erstellen,',
'body.show-form #btn_erstellen {',
'    display: inline-block !important;',
'}'))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Region visibility control */',
'.regulation-selection-region {',
'    display: block;',
'}',
'',
'.regulation-form-region {',
'    display: none;',
'}',
'',
'',
'/* When form is shown */',
'.show-form .regulation-selection-region {',
'    display: none;',
'}',
'',
'.show-form .regulation-form-region {',
'    display: block;',
'}',
'',
'/* Selection button styling */',
'.regulation-select-btn {',
'    margin: 2px;',
'}',
'',
'',
'/* Hide back button initially (when selection table is shown) */',
'.t-Button[data-action="BACK_TO_SELECTION"] {',
'    display: none;',
'}',
'',
'/* Show back button only when form is visible */',
'.show-form .t-Button[data-action="BACK_TO_SELECTION"] {',
'    display: inline-block !important;',
'}'))
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8791271941088982340)
,p_plug_name=>unistr('Vorschrift ausw\00E4hlen')
,p_region_css_classes=>'regulation-selection-region'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    v.VORSCHRIFTID,',
'    -- v.VORSCHRIFT_NUMMER,',
'    CASE ',
'        WHEN tp.ANZEIGE_MIT_DOKUMENTENDATUM = 20 ',
'             AND v.DOKUMENTENDATUM IS NOT NULL ',
'        THEN v.VORSCHRIFT_NUMMER || ''_'' || TO_CHAR(v.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'        ELSE v.VORSCHRIFT_NUMMER ',
'    END AS VORSCHRIFT_NUMMER,',
'    v.VORSCHRIFT_BEZEICHNUNG,',
'    v.PUBLISHER,',
'    TO_CHAR(v.DOKUMENTENDATUM, ''DD.MM.YYYY'') AS DOKUMENTENDATUM,',
'    ',
'    -- ''<button type="button" class="t-Button t-Button--small t-Button--hot" ',
'    --         onclick="selectRegulation('' || v.VORSCHRIFTID || '', '''''' || ',
'    --         REPLACE(v.VORSCHRIFT_NUMMER, '''''''', '''''''''''') || '''''')" ',
unistr('    --         title="Ausw\00E4hlen">'),
unistr('    --     <span class="fa fa-plus"></span> Ausw\00E4hlen'),
'    -- </button>'' AS SELECT_ACTION',
'',
'    ''<button type="button" class="t-Button t-Button--small t-Button--hot" ',
'        onclick="selectRegulation('' || v.VORSCHRIFTID || '', '''''' || ',
'        REPLACE(v.VORSCHRIFT_NUMMER, '''''''', '''''''''''') || '''''', '''''' || ',
'        REPLACE(NVL(v.PUBLISHER, ''''), '''''''', '''''''''''') || '''''')" ',
unistr('        title="Ausw\00E4hlen">'),
unistr('        <span class="fa fa-plus"></span> Ausw\00E4hlen'),
'    </button>'' AS SELECT_ACTION',
'',
'',
'FROM t_vorschrift v',
'LEFT OUTER JOIN t_publisher tp ON (v.publisherid = tp.publisherid)',
'WHERE (v.FLAG_KONSOLIDIERTE_FASSUNGEN IS NULL OR v.FLAG_KONSOLIDIERTE_FASSUNGEN != 1)',
'AND v.VORSCHRIFT_NUMMER IS NOT NULL',
'-- ORDER BY v.VORSCHRIFT_NUMMER',
'ORDER BY ',
'    CASE ',
'        WHEN tp.ANZEIGE_MIT_DOKUMENTENDATUM = 20 ',
'             AND v.DOKUMENTENDATUM IS NOT NULL ',
'        THEN v.VORSCHRIFT_NUMMER || ''_'' || TO_CHAR(v.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'        ELSE v.VORSCHRIFT_NUMMER ',
'    END'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P465_MODE'
,p_plug_display_when_cond2=>'CREATE'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Vorschrift ausw\00E4hlen')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(8791271996318982341)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>12463484312218370576
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964071865088418428)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Vorschrift ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964071501912418427)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Vorschriften Nummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964071085866418426)
,p_db_column_name=>'PUBLISHER'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Publisher'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964070675336418426)
,p_db_column_name=>'DOKUMENTENDATUM'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Dokumentendatum'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964070294401418425)
,p_db_column_name=>'SELECT_ACTION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('Vorschrift ausw\00E4hlen')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964069845611418425)
,p_db_column_name=>'VORSCHRIFT_BEZEICHNUNG'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Vorschrift Bezeichnung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(8791692640900616710)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5482472'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'VORSCHRIFTID:VORSCHRIFT_NUMMER:PUBLISHER:DOKUMENTENDATUM:VORSCHRIFT_BEZEICHNUNG:SELECT_ACTION:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8791273765023982359)
,p_plug_name=>'Form Region'
,p_region_css_classes=>'regulation-form-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8788799561680429147)
,p_plug_name=>'Regulation Form'
,p_parent_plug_id=>wwv_flow_imp.id(8791273765023982359)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21451844155561394912)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964068826831418423)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(8791273765023982359)
,p_button_name=>'BACK_TO_SELECTION'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Zur\00FCck zur Auswahl')
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P465_MODE = ''CREATE'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_css_classes=>'form-only-button'
,p_icon_css_classes=>'fa-arrow-left'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964061832048418415)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(21451844155561394912)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964061464624418415)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(21451844155561394912)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>unistr('javascript:apex.confirm(''Soll die Getex Mapping Norm gel\00F6scht werden?'',''DELETE'');')
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'itme is not nnull ',
'',
'P465_CARD_NUM'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964061060063418415)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(21451844155561394912)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P465_SPECIFIC_REG_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964060668369418414)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(21451844155561394912)
,p_button_name=>'CREATE'
,p_button_static_id=>'btn_erstellen'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_condition=>'P465_SPECIFIC_REG_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964068213140418422)
,p_name=>'P465_ROW_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8788799561680429147)
,p_prompt=>'Row Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964067788202418422)
,p_name=>'P465_MODE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(8788799561680429147)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964067407478418421)
,p_name=>'P465_MANUAL_MODE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(8788799561680429147)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964066948472418421)
,p_name=>'P465_SPECIFIC_REG_ID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(8788799561680429147)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964066606099418420)
,p_name=>'P465_CARD_NUM'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(8788799561680429147)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964066149419418420)
,p_name=>'P465_SEARCH_SELECTION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(8788799561680429147)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964065721740418420)
,p_name=>'P465_MILESTONE_SELECTION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(8788799561680429147)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964065414364418419)
,p_name=>'P465_LANDIDS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(8788799561680429147)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964065007408418419)
,p_name=>'P465_LAND'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(8788799561680429147)
,p_prompt=>'Land'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    l.B_NUMMER || '' - '' || l.LAND as display_value,',
'    l.LANDID as return_value',
'FROM t_land l',
'WHERE l.LANDID IN (',
'    SELECT DISTINCT landid_value',
'    FROM (',
'        -- Workflow from Page 461 (has CARD_NUM)',
'        SELECT DISTINCT split.LANDID as landid_value',
'        FROM T_MS_SUCHE_SPLIT split',
'        WHERE :P465_CARD_NUM IS NOT NULL ',
'        AND :P465_CARD_NUM > 0',
'        AND split.CARD_NUMBER = :P465_CARD_NUM',
'        -- AND split.BENUTZERID = :G_BENUTZERID',
'        AND (split.BENUTZERID = :G_BENUTZERID -- PRI user check',
'     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                WHERE brr.benutzerid = :G_BENUTZERID ',
'                AND brr.rolleid = 1001)',
'    )',
'        AND split.SUCHEID = :P465_SEARCH_SELECTION',
'        AND split.MEILENSTEIN = :P465_MILESTONE_SELECTION',
'        ',
'        UNION',
'        ',
'        -- Workflow from Page 450 (no CARD_NUM, use JSON data)',
'        SELECT DISTINCT TO_NUMBER(column_value) as landid_value',
'        FROM t_suche_json t,',
'        JSON_TABLE(t.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            laender VARCHAR2(4000) PATH ''$.LAENDER''',
'        )) jt,',
'        TABLE(apex_string.split(jt.laender, '':''))',
'        WHERE (:P465_CARD_NUM IS NULL OR :P465_CARD_NUM = 0)',
'        AND t.sucheid = :P465_SEARCH_SELECTION',
'        AND jt.meilenstein = :P465_MILESTONE_SELECTION',
'    )',
')',
'ORDER BY display_value',
''))
,p_lov_cascade_parent_items=>'P465_CARD_NUM,P465_SEARCH_SELECTION,P465_MILESTONE_SELECTION'
,p_ajax_optimize_refresh=>'Y'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Restricted to Current Search',
unistr('-- Land ausw\00E4hlen --'),
'',
'SELECT DISTINCT ',
'    l.B_NUMMER || '' - '' || l.LAND as display_value,',
'    l.LANDID as return_value',
'FROM t_land l',
'WHERE (:P465_MANUAL_MODE = ''N'' ',
'       OR l.LANDID IN (',
'           SELECT DISTINCT ms.landid ',
'           FROM t_ms_suchergebniss ms ',
'           WHERE ms.sucheid = :P465_SEARCH_SELECTION',
'           AND ms.meilenstein = :P465_MILESTONE_SELECTION',
'       ))',
'ORDER BY display_value',
'',
'',
'SELECT DISTINCT ',
'    l.B_NUMMER || '' - '' || l.LAND as display_value,',
'    l.LANDID as return_value',
'FROM t_land l',
'WHERE l.LANDID IN (',
'    -- Only show countries that are part of the current search',
'    SELECT DISTINCT ms.LANDID',
'    FROM T_MS_SUCHERGEBNISS ms',
'    WHERE ms.SUCHEID = :P465_SEARCH_SELECTION',
'    AND ms.MEILENSTEIN = :P465_MILESTONE_SELECTION',
'    AND ms.MANUELLER_EINTRAG != 10  -- Exclude other manual entries',
')',
'ORDER BY display_value',
'',
'',
'',
'SELECT DISTINCT ',
'    l.B_NUMMER || '' - '' || l.LAND as display_value,',
'    l.LANDID as return_value',
'FROM t_land l',
'WHERE l.LANDID IN (',
'    -- Only show countries that are part of the current search',
'    SELECT DISTINCT ms.LANDID',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT OUTER JOIN T_MS_SUCHE_SPLIT split ON (',
'        split.SUCHEID = ms.sucheid ',
'        AND split.MEILENSTEIN = ms.meilenstein ',
'        AND split.LANDID = ms.landid ',
'    )',
'    WHERE ms.SUCHEID = :P465_SEARCH_SELECTION',
'    AND ms.MEILENSTEIN = :P465_MILESTONE_SELECTION',
'    AND ms.MANUELLER_EINTRAG != 10   -- Exclude other manual entries',
'    AND split.CARD_NUMBER = :P465_CARD_NUM -- Dynamic',
')',
'ORDER BY display_value',
'',
'',
'',
'SELECT DISTINCT ',
'    l.B_NUMMER || '' - '' || l.LAND as display_value,',
'    l.LANDID as return_value',
'FROM t_land l',
'WHERE l.LANDID IN (',
'    SELECT DISTINCT split.LANDID',
'    FROM T_MS_SUCHE_SPLIT split',
'    WHERE split.CARD_NUMBER =',
'    CASE ',
'        WHEN :P465_MODE = ''CREATE'' THEN :P465_CARD_NUM',
'        WHEN :P465_MODE = ''EDIT'' THEN :P465_CARD_NUM',
'        ELSE :P465_CARD_NUM',
'    END',
'    AND split.BENUTZERID = :G_BENUTZERID',
'    AND split.SUCHEID = :P465_SEARCH_SELECTION',
'    AND split.MEILENSTEIN = :P465_MILESTONE_SELECTION',
')',
'ORDER BY display_value',
'',
'',
'',
'-- working 22 julk 20256 all tme',
'',
'SELECT DISTINCT ',
'    l.B_NUMMER || '' - '' || l.LAND as display_value,',
'    l.LANDID as return_value',
'FROM t_land l',
'WHERE l.LANDID IN (',
'    SELECT DISTINCT split.LANDID',
'    FROM T_MS_SUCHE_SPLIT split',
'    WHERE split.CARD_NUMBER =',
'    CASE ',
'        WHEN :P465_MODE = ''CREATE'' THEN :P465_CARD_NUM',
'        WHEN :P465_MODE = ''EDIT'' THEN :P465_CARD_NUM',
'        ELSE :P465_CARD_NUM',
'    END',
'    AND split.BENUTZERID = :G_BENUTZERID',
'    AND split.SUCHEID = :P465_SEARCH_SELECTION',
'    AND split.MEILENSTEIN = :P465_MILESTONE_SELECTION',
')',
'ORDER BY display_value',
'',
'',
'',
'-- working partilaly for 450 ',
'',
'',
'',
'',
'',
'SELECT DISTINCT ',
'    l.B_NUMMER || '' - '' || l.LAND as display_value,',
'    l.LANDID as return_value',
'FROM t_land l',
'WHERE l.LANDID IN (',
'    CASE ',
'        -- When coming from Page 461 (has CARD_NUM)',
'        WHEN :P465_CARD_NUM IS NOT NULL AND :P465_CARD_NUM > 0 THEN (',
'            SELECT DISTINCT split.LANDID',
'            FROM T_MS_SUCHE_SPLIT split',
'            WHERE split.CARD_NUMBER = ',
'                CASE ',
'                    WHEN :P465_MODE = ''CREATE'' THEN :P465_CARD_NUM',
'                    WHEN :P465_MODE = ''EDIT'' THEN :P465_CARD_NUM',
'                    ELSE :P465_CARD_NUM',
'                END',
'            AND split.BENUTZERID = :G_BENUTZERID',
'            AND split.SUCHEID = :P465_SEARCH_SELECTION',
'            AND split.MEILENSTEIN = :P465_MILESTONE_SELECTION',
'        )',
'        -- When coming from Page 450 (no CARD_NUM)',
'        ELSE (',
'            SELECT DISTINCT ms.LANDID',
'            FROM T_MS_SUCHERGEBNISS ms',
'            WHERE ms.SUCHEID = :P465_SEARCH_SELECTION',
'            AND ms.MEILENSTEIN = :P465_MILESTONE_SELECTION',
'        )',
'    END',
')',
'ORDER BY display_value',
'',
'',
'',
'',
'',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964064583591418417)
,p_name=>'P465_VORSCHRIFT_NUMMER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(8788799561680429147)
,p_prompt=>'Vorschrift Nummer'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'readonly="readonly" style="background-color:#f0f0f0;"'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    v.vorschrift_nummer as display_value,',
'    v.vorschriftid as return_value  ',
'FROM t_vorschrift v',
'WHERE v.vorschrift_nummer IS NOT NULL',
'ORDER BY v.vorschrift_nummer'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964064191489418417)
,p_name=>'P465_THEMABEZEICHNUNG'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(8788799561680429147)
,p_prompt=>'Themabezeichnung'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'readonly="readonly"'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964063724018418417)
,p_name=>'P465_THEMABEZEICHNUNG_1'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(8788799561680429147)
,p_prompt=>'Themabezeichnung'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    NUMMER || '' - '' || BEZEICHNUNG as display_value,',
'    BEZEICHNUNG as return_value',
'FROM T_THEMA',
'ORDER BY NUMMER'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964063411322418416)
,p_name=>'P465_ALTERNATIVE_VORSCHRIFTENNUMMER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(8788799561680429147)
,p_prompt=>'Alternative Vorschriftennummer'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    v.vorschrift_nummer as display_value,',
'    v.vorschriftid as return_value',
'FROM t_vorschrift v',
'WHERE v.vorschrift_nummer IS NOT NULL',
'ORDER BY v.vorschrift_nummer'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964062971907418416)
,p_name=>'P465_PUBLISHER'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(8788799561680429147)
,p_prompt=>'Publisher'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'readonly="readonly"'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964062602906418416)
,p_name=>'P465_RETURN_PAGE'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(8788799561680429147)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(951938943957316314)
,p_name=>'P465_VORSCHRIFT_ID'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(8788799561680429147)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(964060193714418413)
,p_validation_name=>'Check Status Before Edit/Delete'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_status VARCHAR2(50);',
'    l_count NUMBER;',
'BEGIN',
'    -- Check if we''re in edit mode and if status allows editing',
'    IF :P465_MODE = ''EDIT'' THEN',
'        -- Get the status from the search results',
'        SELECT COUNT(*)',
'        INTO l_count',
'        FROM T_MS_SUCHERGEBNISS ms',
'        JOIN T_MS_SUCHE_SPLIT split ON (',
'            split.SUCHEID = ms.sucheid ',
'            AND split.MEILENSTEIN = ms.meilenstein ',
'            AND split.LANDID = ms.landid',
'        )',
'        WHERE split.CARD_NUMBER = :P465_CARD_NUM',
'        AND split.BENUTZERID = :G_BENUTZERID',
'        AND ms.STATUS_VORSCHRIFT = ''finished'';',
'        ',
'        -- If any record has finished status, prevent edit',
'        IF l_count > 0 THEN',
'            RETURN FALSE;',
'        END IF;',
'    END IF;',
'    ',
'    RETURN TRUE;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('Bearbeitung und L\00F6schung nur bis zum Status finished m\00F6glich.')
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(964059803820418413)
,p_validation_name=>'Required Fields Check'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Check if regulation is selected',
'    -- IF :P465_VORSCHRIFT_NUMMER IS NULL AND :P465_ALTERNATIVE_VORSCHRIFTENNUMMER IS NULL THEN',
'    --     RETURN FALSE;',
'    -- END IF;',
'    ',
'    -- Check if at least one country is selected',
'    IF :P465_LAND IS NULL THEN',
'        RETURN FALSE;',
'    END IF;',
'    ',
'    -- -- Check if theme description is provided',
'    -- IF :P465_THEMABEZEICHNUNG IS NULL THEN',
'    --     RETURN FALSE;',
'    -- END IF;',
'    ',
'    RETURN TRUE;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('Bitte f\00FCllen Sie alle erforderlichen Felder aus: Vorschrift, Land und Themabezeichnung.')
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964055495927418405)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(964061832048418415)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964054986988418404)
,p_event_id=>wwv_flow_imp.id(964055495927418405)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964054557021418404)
,p_name=>'Back to Selection'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(964068826831418423)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964054048796418404)
,p_event_id=>wwv_flow_imp.id(964054557021418404)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Go back to regulation selection',
'backToSelection();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964053660663418403)
,p_name=>'Set Theme Based on Regulation'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P465_VORSCHRIFT_NUMMER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964053147031418403)
,p_event_id=>wwv_flow_imp.id(964053660663418403)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_theme VARCHAR2(4000);',
'BEGIN',
'    -- Get theme based on selected regulation',
'    SELECT LISTAGG(t.BEZEICHNUNG, ''; '') WITHIN GROUP (ORDER BY t.BEZEICHNUNG)',
'    INTO l_theme',
'    FROM T_VORSCHRIFT_REF_THEMA vrt',
'    JOIN T_THEMA t ON (vrt.THEMAID = t.THEMAID)',
'    WHERE vrt.VORSCHRIFTID = :P465_VORSCHRIFT_ID',
'    AND vrt.GELOESCHT = 0;',
'    ',
'    :P465_THEMABEZEICHNUNG := l_theme;',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        :P465_THEMABEZEICHNUNG := NULL;',
'END;'))
,p_attribute_02=>'P465_VORSCHRIFT_ID'
,p_attribute_03=>'P465_THEMABEZEICHNUNG'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964059442205418413)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create Regulation_ExistingCARD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'DECLARE',
'    l_selected_countries VARCHAR2(4000) := :P465_LAND;',
'    l_card_number        NUMBER;',
'    l_search_id          NUMBER := :P465_SEARCH_SELECTION;',
'    l_milestone          NUMBER := :P465_MILESTONE_SELECTION;',
'    l_vorschrift_id      NUMBER;',
'    l_themaid            NUMBER;',
'BEGIN',
'    l_vorschrift_id := :P465_VORSCHRIFT_ID;',
'',
'    IF l_vorschrift_id IS NULL THEN',
unistr('        raise_application_error(-20001, ''Bitte w\00E4hlen Sie eine Vorschrift aus'');'),
'    END IF;',
'',
'    -- Get THEMAID for this regulation',
'    BEGIN',
'        SELECT vrt.THEMAID',
'        INTO l_themaid',
'        FROM t_vorschrift_ref_thema vrt',
'        WHERE vrt.VORSCHRIFTID = l_vorschrift_id',
'        AND vrt.GELOESCHT = 0',
'        AND ROWNUM = 1;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_themaid := NULL;',
'    END;',
'',
'    -- Check P465_CARD_NUM, which is populated by the URL',
'    -- from either Page 461 or is NULL if from Page 450.',
'    IF :P465_CARD_NUM IS NOT NULL THEN',
'        -- Context is from Page 461, use the existing card number.',
'        l_card_number := :P465_CARD_NUM;',
'        apex_debug.message(''Using existing card number from Page 461: %s'', l_card_number);',
'    ELSE',
'        -- Context is from Page 450, create a new card number.',
'        SELECT NVL(MAX(CARD_NUMBER), 0) + 1',
'        INTO l_card_number',
'        FROM T_MS_SUCHE_SPLIT',
'        WHERE BENUTZERID = :G_BENUTZERID;',
'        apex_debug.message(''Creating new card number: %s'', l_card_number);',
'    END IF;',
'',
'    -- Insert a record for each selected country',
'    FOR rec IN (',
'        SELECT TO_NUMBER(TRIM(column_value)) as landid',
'        FROM TABLE(apex_string.split(l_selected_countries, '':''))',
'        WHERE TRIM(column_value) IS NOT NULL',
'    ) LOOP',
'        -- Insert into the main results table',
'        INSERT INTO T_MS_SUCHERGEBNISS (',
'            SUCHEID, VORSCHRIFTID, VORSCHRIFTNUMMER, THEMABEZEICHNUNG,',
'            THEMAID, REGELNUMMER,',
'            LANDID, LANDBEZEICHNUNG, LANDNUMMER, MEILENSTEIN,',
'            ZEITPUNKT, MANUELLER_EINTRAG',
'        )',
'        SELECT',
'            l_search_id, ',
'            l_vorschrift_id, ',
'            v.VORSCHRIFT_NUMMER, ',
'            :P465_THEMABEZEICHNUNG,',
'            l_themaid,',
'            999,  -- CHANGED: Set REGELNUMMER = 999 for manual entries',
'            rec.landid, ',
'            l.LAND, ',
'            l.B_NUMMER, ',
'            l_milestone,',
'            SYSDATE, ',
'            10',
'        FROM t_vorschrift v, t_land l',
'        WHERE v.VORSCHRIFTID = l_vorschrift_id',
'          AND l.LANDID = rec.landid;',
'',
'        -- Check if this country is already part of the card',
'        DECLARE',
'            l_exists NUMBER;',
'        BEGIN',
'            SELECT COUNT(*)',
'            INTO l_exists',
'            FROM T_MS_SUCHE_SPLIT',
'            WHERE SUCHEID = l_search_id',
'              AND MEILENSTEIN = l_milestone',
'              AND CARD_NUMBER = l_card_number',
'              AND LANDID = rec.landid',
'              AND (BENUTZERID = :G_BENUTZERID',
'                   OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                              WHERE brr.benutzerid = :G_BENUTZERID ',
'                              AND brr.rolleid = 1001)',
'                  );',
'',
'            -- If not, add it to the card definition table',
'            IF l_exists = 0 THEN',
'                INSERT INTO T_MS_SUCHE_SPLIT (',
'                    SUCHEID, MEILENSTEIN, CARD_NUMBER, LANDID,',
'                    BENUTZERID, LETZTE_AENDERUNG_DATUM, LETZTE_AENDERUNG_BENUTZERID',
'                ) VALUES (',
'                    l_search_id, l_milestone, l_card_number, rec.landid,',
'                    :G_BENUTZERID, SYSDATE, :G_BENUTZERID',
'                );',
'            END IF;',
'        END;',
'    END LOOP;',
'',
'    COMMIT;',
'    apex_debug.message(''CREATE Process Complete - Card: %s, ThemaID: %s'', l_card_number, l_themaid);',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        apex_debug.error(''CREATE Process Error: %s'', SQLERRM);',
'        RAISE;',
'END;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(964060668369418414)
,p_process_when=>'P465_MODE'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'CREATE'
,p_internal_uid=>2708152873693969822
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964056240941418407)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create Regulation_ExistingCARD_Backup 25 Jul_without 450'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_selected_countries VARCHAR2(4000) := :P465_LAND;',
'    l_card_number NUMBER;',
'    l_search_id NUMBER := :P465_SEARCH_SELECTION;',
'    l_milestone NUMBER := :P465_MILESTONE_SELECTION;',
'    l_vorschrift_id NUMBER;',
'    ',
'BEGIN',
'    -- Debug',
'    apex_debug.message(''CREATE Process Start - Countries: %s, Search: %s, Milestone: %s'', ',
'                       l_selected_countries, l_search_id, l_milestone);',
'    ',
'    -- Get the selected VORSCHRIFTID (from the popup LOV)',
'    l_vorschrift_id := :P465_VORSCHRIFT_NUMMER;',
'    ',
'    IF l_vorschrift_id IS NULL THEN',
unistr('        raise_application_error(-20001, ''Bitte w\00E4hlen Sie eine Vorschrift aus'');'),
'    END IF;',
'    ',
'    --  Use existing card number if coming from Page 461',
'    IF :P461_CARD_NUM IS NOT NULL THEN',
'        -- Coming from Page 461 - use existing card',
'        l_card_number := :P461_CARD_NUM;',
'        apex_debug.message(''Using existing card number from Page 461: %s'', l_card_number);',
'    ELSE',
'        -- Not coming from Page 461 - create new card',
'        SELECT NVL(MAX(CARD_NUMBER), 0) + 1 ',
'        INTO l_card_number',
'        FROM T_MS_SUCHE_SPLIT ',
'        WHERE BENUTZERID = :G_BENUTZERID;',
'        apex_debug.message(''Creating new card number: %s'', l_card_number);',
'    END IF;',
'    ',
'    -- Insert for each selected country',
'    FOR rec IN (',
'        SELECT TO_NUMBER(TRIM(column_value)) as landid',
'        FROM TABLE(apex_string.split(l_selected_countries, '':''))',
'        WHERE TRIM(column_value) IS NOT NULL',
'    ) LOOP',
'        ',
'        -- Insert into T_MS_SUCHERGEBNISS',
'        INSERT INTO T_MS_SUCHERGEBNISS (',
'            SUCHEID,',
'            VORSCHRIFTID,',
'            VORSCHRIFTNUMMER,',
'            THEMABEZEICHNUNG,',
'            LANDID,',
'            LANDBEZEICHNUNG,',
'            LANDNUMMER,',
'            MEILENSTEIN,',
'            ZEITPUNKT,',
'            MANUELLER_EINTRAG',
'        ) ',
'        SELECT ',
'            l_search_id,',
'            l_vorschrift_id,',
'            v.VORSCHRIFT_NUMMER,',
'            :P465_THEMABEZEICHNUNG,',
'            rec.landid,',
'            l.LAND,',
'            l.B_NUMMER,',
'            l_milestone,',
'            SYSDATE,',
'            10  -- Manual entry flag',
'        FROM t_vorschrift v, t_land l',
'        WHERE v.VORSCHRIFTID = l_vorschrift_id',
'        AND l.LANDID = rec.landid;',
'        ',
'        -- Check if this country already exists in the card',
'        DECLARE',
'            l_exists NUMBER;',
'        BEGIN',
'            SELECT COUNT(*)',
'            INTO l_exists',
'            FROM T_MS_SUCHE_SPLIT',
'            WHERE SUCHEID = l_search_id',
'            AND MEILENSTEIN = l_milestone',
'            AND CARD_NUMBER = l_card_number',
'            AND LANDID = rec.landid',
'            AND BENUTZERID = :G_BENUTZERID;',
'            ',
'            -- Only insert if not already in the card',
'            IF l_exists = 0 THEN',
'                INSERT INTO T_MS_SUCHE_SPLIT (',
'                    SUCHEID,',
'                    MEILENSTEIN,',
'                    CARD_NUMBER,',
'                    LANDID,',
'                    BENUTZERID,',
'                    LETZTE_AENDERUNG_DATUM,',
'                    LETZTE_AENDERUNG_BENUTZERID',
'                ) VALUES (',
'                    l_search_id,',
'                    l_milestone,',
'                    l_card_number,',
'                    rec.landid,',
'                    :G_BENUTZERID,',
'                    SYSDATE,',
'                    :G_BENUTZERID',
'                );',
'            END IF;',
'        END;',
'        ',
'    END LOOP;',
'    ',
'    COMMIT;',
'    ',
'    apex_debug.message(''CREATE Process Complete - Card: %s'', l_card_number);',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        apex_debug.error(''CREATE Process Error: %s'', SQLERRM);',
'        RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(964060668369418414)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2708156074957969828
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964057051847418408)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create Regulation_NewCARD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_selected_countries VARCHAR2(4000) := :P465_LAND;',
'    l_new_card_number NUMBER;',
'    l_search_id NUMBER := :P465_SEARCH_SELECTION;',
'    l_milestone NUMBER := :P465_MILESTONE_SELECTION;',
'    l_vorschrift_id NUMBER;',
'    ',
'BEGIN',
'    -- Debug',
'    apex_debug.message(''CREATE Process Start - Countries: %s, Search: %s, Milestone: %s'', ',
'                       l_selected_countries, l_search_id, l_milestone);',
'    ',
'    -- Get the selected VORSCHRIFTID (from the popup LOV)',
'    l_vorschrift_id := :P465_VORSCHRIFT_NUMMER;',
'    ',
'    IF l_vorschrift_id IS NULL THEN',
unistr('        raise_application_error(-20001, ''Bitte w\00E4hlen Sie eine Vorschrift aus'');'),
'    END IF;',
'    ',
'    -- Get next card number for this user',
'    SELECT NVL(MAX(CARD_NUMBER), 0) + 1 ',
'    INTO l_new_card_number',
'    FROM T_MS_SUCHE_SPLIT ',
'    WHERE BENUTZERID = :G_BENUTZERID;',
'    ',
'    -- Insert for each selected country',
'    FOR rec IN (',
'        SELECT TO_NUMBER(TRIM(column_value)) as landid',
'        FROM TABLE(apex_string.split(l_selected_countries, '':''))',
'        WHERE TRIM(column_value) IS NOT NULL',
'    ) LOOP',
'        ',
'        -- Insert into T_MS_SUCHERGEBNISS',
'        INSERT INTO T_MS_SUCHERGEBNISS (',
'            SUCHEID,',
'            VORSCHRIFTID,',
'            VORSCHRIFTNUMMER,',
'            THEMABEZEICHNUNG,',
'            LANDID,',
'            LANDBEZEICHNUNG,',
'            LANDNUMMER,',
'            MEILENSTEIN,',
'            ZEITPUNKT,',
'            MANUELLER_EINTRAG',
'            -- ALTERNATIVE_VORSCHRIFTID',
'        ) ',
'        SELECT ',
'            l_search_id,',
'            l_vorschrift_id,',
'            v.VORSCHRIFT_NUMMER,',
'            :P465_THEMABEZEICHNUNG,',
'            rec.landid,',
'            l.LAND,',
'            l.B_NUMMER,',
'            l_milestone,',
'            SYSDATE,',
'            10  -- Manual entry flag',
'            -- CASE ',
'            --     WHEN :P465_ALTERNATIVE_VORSCHRIFTENNUMMER IS NOT NULL ',
'            --     THEN :P465_ALTERNATIVE_VORSCHRIFTENNUMMER ',
'            --     ELSE NULL ',
'            -- END',
'        FROM t_vorschrift v, t_land l',
'        WHERE v.VORSCHRIFTID = l_vorschrift_id',
'        AND l.LANDID = rec.landid;',
'        ',
'        -- Insert into T_MS_SUCHE_SPLIT',
'        INSERT INTO T_MS_SUCHE_SPLIT (',
'            SUCHEID,',
'            MEILENSTEIN,',
'            CARD_NUMBER,',
'            LANDID,',
'            BENUTZERID,',
'            LETZTE_AENDERUNG_DATUM,',
'            LETZTE_AENDERUNG_BENUTZERID',
'        ) VALUES (',
'            l_search_id,',
'            l_milestone,',
'            l_new_card_number,',
'            rec.landid,',
'            :G_BENUTZERID,',
'            SYSDATE,',
'            :G_BENUTZERID',
'        );',
'        ',
'    END LOOP;',
'    ',
'    COMMIT;',
'    ',
'    apex_debug.message(''CREATE Process Complete - Created card: %s'', l_new_card_number);',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        apex_debug.error(''CREATE Process Error: %s'', SQLERRM);',
'        RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(964060668369418414)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2708155264051969827
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964057467257418409)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save Regulation'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_selected_countries VARCHAR2(4000) := :P465_LAND;',
'    l_card_number NUMBER := :P465_CARD_NUM;',
'    l_search_id NUMBER := :P465_SEARCH_SELECTION;',
'    l_milestone NUMBER := :P465_MILESTONE_SELECTION;',
'    l_specific_reg_id NUMBER := :P465_SPECIFIC_REG_ID;',
'    l_vorschrift_id NUMBER;',
'    l_themaid NUMBER;',
'BEGIN',
'    apex_debug.message(''SAVE Process Start - Card: %s, Countries: %s'', l_card_number, l_selected_countries);',
'    ',
'    l_vorschrift_id := NVL(:P465_VORSCHRIFT_ID, l_specific_reg_id);',
'    ',
'    -- Get THEMAID for this regulation',
'    BEGIN',
'        SELECT vrt.THEMAID',
'        INTO l_themaid',
'        FROM t_vorschrift_ref_thema vrt',
'        WHERE vrt.VORSCHRIFTID = l_vorschrift_id',
'        AND vrt.GELOESCHT = 0',
'        AND ROWNUM = 1;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_themaid := NULL;',
'    END;',
'    ',
'    -- Delete ONLY the specific regulation being edited',
'    DELETE FROM T_MS_SUCHERGEBNISS ms',
'    WHERE ms.SUCHEID = l_search_id',
'    AND ms.MEILENSTEIN = l_milestone',
'    AND ms.MANUELLER_EINTRAG = 10',
'    AND CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END = l_specific_reg_id',
'    AND EXISTS (',
'        SELECT 1 ',
'        FROM T_MS_SUCHE_SPLIT split',
'        WHERE split.CARD_NUMBER = l_card_number',
'        AND (split.BENUTZERID = :G_BENUTZERID',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001)',
'            )',
'        AND split.SUCHEID = ms.SUCHEID',
'        AND split.MEILENSTEIN = ms.MEILENSTEIN',
'        AND split.LANDID = ms.LANDID',
'    );',
'    ',
'    -- Get current countries that are part of this card',
'    DECLARE',
'        l_current_countries VARCHAR2(4000);',
'    BEGIN',
'        SELECT LISTAGG(DISTINCT split.LANDID, '':'') WITHIN GROUP (ORDER BY split.LANDID)',
'        INTO l_current_countries',
'        FROM T_MS_SUCHE_SPLIT split',
'        WHERE split.CARD_NUMBER = l_card_number',
'        AND (split.BENUTZERID = :G_BENUTZERID',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001)',
'            );',
'        ',
'        -- Countries that are no longer selected need to be removed from the split',
'        FOR rec IN (',
'            SELECT TO_NUMBER(TRIM(column_value)) as landid',
'            FROM TABLE(apex_string.split(l_current_countries, '':''))',
'            WHERE TRIM(column_value) IS NOT NULL',
'            AND TO_NUMBER(TRIM(column_value)) NOT IN (',
'                SELECT TO_NUMBER(TRIM(column_value))',
'                FROM TABLE(apex_string.split(l_selected_countries, '':''))',
'                WHERE TRIM(column_value) IS NOT NULL',
'            )',
'        ) LOOP',
'            DECLARE',
'                l_other_regs NUMBER;',
'            BEGIN',
'                SELECT COUNT(*)',
'                INTO l_other_regs',
'                FROM T_MS_SUCHERGEBNISS ms',
'                WHERE ms.SUCHEID = l_search_id',
'                AND ms.MEILENSTEIN = l_milestone',
'                AND ms.LANDID = rec.landid',
'                AND EXISTS (',
'                    SELECT 1 ',
'                    FROM T_MS_SUCHE_SPLIT split',
'                    WHERE split.CARD_NUMBER = l_card_number',
'                    AND (split.BENUTZERID = :G_BENUTZERID',
'                         OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                                    WHERE brr.benutzerid = :G_BENUTZERID ',
'                                    AND brr.rolleid = 1001)',
'                        )',
'                    AND split.SUCHEID = ms.SUCHEID',
'                    AND split.MEILENSTEIN = ms.MEILENSTEIN',
'                    AND split.LANDID = ms.LANDID',
'                );',
'                ',
'                IF l_other_regs = 0 THEN',
'                    DELETE FROM T_MS_SUCHE_SPLIT',
'                    WHERE CARD_NUMBER = l_card_number',
'                    AND (BENUTZERID = :G_BENUTZERID ',
'                         OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                                    WHERE brr.benutzerid = :G_BENUTZERID ',
'                                    AND brr.rolleid = 1001)',
'                        )',
'                    AND LANDID = rec.landid;',
'                END IF;',
'            END;',
'        END LOOP;',
'    END;',
'    ',
'    -- Re-insert with updated data for selected countries',
'    FOR rec IN (',
'        SELECT TO_NUMBER(TRIM(column_value)) as landid',
'        FROM TABLE(apex_string.split(l_selected_countries, '':''))',
'        WHERE TRIM(column_value) IS NOT NULL',
'    ) LOOP',
'        INSERT INTO T_MS_SUCHERGEBNISS (',
'            SUCHEID, VORSCHRIFTID, VORSCHRIFTNUMMER, THEMABEZEICHNUNG,',
'            THEMAID, REGELNUMMER,',
'            LANDID, LANDBEZEICHNUNG, LANDNUMMER, MEILENSTEIN,',
'            ZEITPUNKT, MANUELLER_EINTRAG',
'        ) ',
'        SELECT ',
'            l_search_id, ',
'            l_vorschrift_id, ',
'            v.VORSCHRIFT_NUMMER, ',
'            :P465_THEMABEZEICHNUNG,',
'            l_themaid,',
'            999,  --  Set REGELNUMMER = 999 for manual entries',
'            rec.landid, ',
'            l.LAND, ',
'            l.B_NUMMER, ',
'            l_milestone,',
'            SYSDATE, ',
'            10',
'        FROM t_vorschrift v, t_land l',
'        WHERE v.VORSCHRIFTID = l_vorschrift_id',
'        AND l.LANDID = rec.landid;',
'        ',
'        DECLARE',
'            l_split_exists NUMBER;',
'        BEGIN',
'            SELECT COUNT(*)',
'            INTO l_split_exists',
'            FROM T_MS_SUCHE_SPLIT',
'            WHERE SUCHEID = l_search_id',
'            AND MEILENSTEIN = l_milestone',
'            AND CARD_NUMBER = l_card_number',
'            AND LANDID = rec.landid',
'            AND (BENUTZERID = :G_BENUTZERID',
'                 OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                            WHERE brr.benutzerid = :G_BENUTZERID ',
'                            AND brr.rolleid = 1001)',
'                );',
'            ',
'            IF l_split_exists = 0 THEN',
'                INSERT INTO T_MS_SUCHE_SPLIT (',
'                    SUCHEID, MEILENSTEIN, CARD_NUMBER, LANDID,',
'                    BENUTZERID, LETZTE_AENDERUNG_DATUM, LETZTE_AENDERUNG_BENUTZERID',
'                ) VALUES (',
'                    l_search_id, l_milestone, l_card_number, rec.landid,',
'                    :G_BENUTZERID, SYSDATE, :G_BENUTZERID',
'                );',
'            END IF;',
'        END;',
'    END LOOP;',
'    ',
'    COMMIT;',
'    ',
'    apex_debug.message(''SAVE Process Complete - Updated card: %s, ThemaID: %s'', l_card_number, l_themaid);',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        apex_debug.error(''SAVE Process Error: %s'', SQLERRM);',
'        RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(964061060063418415)
,p_process_when=>'P465_MODE'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'EDIT'
,p_internal_uid=>2708154848641969826
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964055881196418406)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save Regulation_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_selected_countries VARCHAR2(4000) := :P465_LAND;',
'    l_card_number NUMBER := :P465_CARD_NUM;',
'    l_search_id NUMBER := :P465_SEARCH_SELECTION;',
'    l_milestone NUMBER := :P465_MILESTONE_SELECTION;',
'    l_specific_reg_id NUMBER := :P465_SPECIFIC_REG_ID;',
'    l_vorschrift_id NUMBER;',
'    ',
'BEGIN',
'    apex_debug.message(''SAVE Process Start - Card: %s, Countries: %s'', l_card_number, l_selected_countries);',
'    ',
'    -- Get the VORSCHRIFTID from selection',
'    l_vorschrift_id := NVL(:P465_VORSCHRIFT_NUMMER, l_specific_reg_id);',
'    ',
'    -- First check if status allows editing',
'    FOR rec IN (',
'        SELECT DISTINCT ms.STATUS_VORSCHRIFT',
'        FROM T_MS_SUCHERGEBNISS ms',
'        JOIN T_MS_SUCHE_SPLIT split ON (',
'            split.SUCHEID = ms.SUCHEID ',
'            AND split.MEILENSTEIN = ms.MEILENSTEIN ',
'            AND split.LANDID = ms.LANDID',
'        )',
'        WHERE split.CARD_NUMBER = l_card_number',
'        AND split.BENUTZERID = :G_BENUTZERID',
'        AND ms.VORSCHRIFTID = l_specific_reg_id  -- Only check the specific regulation',
'    ) LOOP',
'        IF rec.STATUS_VORSCHRIFT = ''finished'' THEN',
unistr('            raise_application_error(-20002, ''Bearbeitung nur bis zum Status finished m\00F6glich'');'),
'        END IF;',
'    END LOOP;',
'    ',
'    -- Delete ONLY the specific regulation being edited',
'    DELETE FROM T_MS_SUCHERGEBNISS ms',
'    WHERE ms.SUCHEID = l_search_id',
'    AND ms.MEILENSTEIN = l_milestone',
'    AND ms.MANUELLER_EINTRAG = 10',
'    AND CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END = l_specific_reg_id',
'    AND EXISTS (',
'        SELECT 1 ',
'        FROM T_MS_SUCHE_SPLIT split',
'        WHERE split.CARD_NUMBER = l_card_number',
'        -- AND split.BENUTZERID = :G_BENUTZERID',
'        AND (split.BENUTZERID = :G_BENUTZERID',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001)',
'            )',
'        AND split.SUCHEID = ms.SUCHEID',
'        AND split.MEILENSTEIN = ms.MEILENSTEIN',
'        AND split.LANDID = ms.LANDID',
'    );',
'    ',
'    -- Get current countries that are part of this card',
'    DECLARE',
'        l_current_countries VARCHAR2(4000);',
'        l_countries_to_remove VARCHAR2(4000);',
'        l_countries_to_add VARCHAR2(4000);',
'    BEGIN',
'        -- Get current countries for this card',
'        SELECT LISTAGG(DISTINCT split.LANDID, '':'') WITHIN GROUP (ORDER BY split.LANDID)',
'        INTO l_current_countries',
'        FROM T_MS_SUCHE_SPLIT split',
'        WHERE split.CARD_NUMBER = l_card_number',
'        AND split.BENUTZERID = :G_BENUTZERID;',
'        ',
'        -- Countries that are no longer selected need to be removed from the split',
'        FOR rec IN (',
'            SELECT TO_NUMBER(TRIM(column_value)) as landid',
'            FROM TABLE(apex_string.split(l_current_countries, '':''))',
'            WHERE TRIM(column_value) IS NOT NULL',
'            AND TO_NUMBER(TRIM(column_value)) NOT IN (',
'                SELECT TO_NUMBER(TRIM(column_value))',
'                FROM TABLE(apex_string.split(l_selected_countries, '':''))',
'                -- FROM TABLE(apex_string.split(l_selected_countries, '';''))',
'',
'                WHERE TRIM(column_value) IS NOT NULL',
'            )',
'        ) LOOP',
'            -- Check if this country has any other regulations in this card',
'            DECLARE',
'                l_other_regs NUMBER;',
'            BEGIN',
'                SELECT COUNT(*)',
'                INTO l_other_regs',
'                FROM T_MS_SUCHERGEBNISS ms',
'                WHERE ms.SUCHEID = l_search_id',
'                AND ms.MEILENSTEIN = l_milestone',
'                AND ms.LANDID = rec.landid',
'                AND EXISTS (',
'                    SELECT 1 ',
'                    FROM T_MS_SUCHE_SPLIT split',
'                    WHERE split.CARD_NUMBER = l_card_number',
'                    AND split.BENUTZERID = :G_BENUTZERID',
'                    AND split.SUCHEID = ms.SUCHEID',
'                    AND split.MEILENSTEIN = ms.MEILENSTEIN',
'                    AND split.LANDID = ms.LANDID',
'                );',
'                ',
'                -- If no other regulations for this country, remove from split',
'                IF l_other_regs = 0 THEN',
'                    DELETE FROM T_MS_SUCHE_SPLIT',
'                    WHERE CARD_NUMBER = l_card_number',
'                    -- AND BENUTZERID = :G_BENUTZERID',
'                    AND (BENUTZERID = :G_BENUTZERID ',
'                         OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                                    WHERE brr.benutzerid = :G_BENUTZERID ',
'                                    AND brr.rolleid = 1001) -- PRI USER',
'                        )',
'                    AND LANDID = rec.landid;',
'                END IF;',
'            END;',
'        END LOOP;',
'    END;',
'    ',
'    -- Re-insert with updated data for selected countries',
'    FOR rec IN (',
'        SELECT TO_NUMBER(TRIM(column_value)) as landid',
'        FROM TABLE(apex_string.split(l_selected_countries, '':''))',
'        -- FROM TABLE(apex_string.split(l_selected_countries, '';''))',
'        WHERE TRIM(column_value) IS NOT NULL',
'    ) LOOP',
'        ',
'        -- Insert into T_MS_SUCHERGEBNISS',
'        INSERT INTO T_MS_SUCHERGEBNISS (',
'            SUCHEID,',
'            VORSCHRIFTID,',
'            VORSCHRIFTNUMMER,',
'            THEMABEZEICHNUNG,',
'            LANDID,',
'            LANDBEZEICHNUNG,',
'            LANDNUMMER,',
'            MEILENSTEIN,',
'            ZEITPUNKT,',
'            MANUELLER_EINTRAG',
'        ) ',
'        SELECT ',
'            l_search_id,',
'            l_vorschrift_id,',
'            v.VORSCHRIFT_NUMMER,',
'            :P465_THEMABEZEICHNUNG,',
'            rec.landid,',
'            l.LAND,',
'            l.B_NUMMER,',
'            l_milestone,',
'            SYSDATE,',
'            10  -- Manual entry flag',
'        FROM t_vorschrift v, t_land l',
'        WHERE v.VORSCHRIFTID = l_vorschrift_id',
'        AND l.LANDID = rec.landid;',
'        ',
'        -- Check if this country is already in the split for this card',
'        DECLARE',
'            l_split_exists NUMBER;',
'        BEGIN',
'            SELECT COUNT(*)',
'            INTO l_split_exists',
'            FROM T_MS_SUCHE_SPLIT',
'            WHERE SUCHEID = l_search_id',
'            AND MEILENSTEIN = l_milestone',
'            AND CARD_NUMBER = l_card_number',
'            AND LANDID = rec.landid',
'            AND BENUTZERID = :G_BENUTZERID;',
'            ',
'            -- Only insert if not already in the split',
'            IF l_split_exists = 0 THEN',
'                INSERT INTO T_MS_SUCHE_SPLIT (',
'                    SUCHEID,',
'                    MEILENSTEIN,',
'                    CARD_NUMBER,',
'                    LANDID,',
'                    BENUTZERID,',
'                    LETZTE_AENDERUNG_DATUM,',
'                    LETZTE_AENDERUNG_BENUTZERID',
'                ) VALUES (',
'                    l_search_id,',
'                    l_milestone,',
'                    l_card_number,',
'                    rec.landid,',
'                    :G_BENUTZERID,',
'                    SYSDATE,',
'                    :G_BENUTZERID',
'                );',
'            END IF;',
'        END;',
'        ',
'    END LOOP;',
'    ',
'    COMMIT;',
'    ',
'    apex_debug.message(''SAVE Process Complete - Updated card: %s'', l_card_number);',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        apex_debug.error(''SAVE Process Error: %s'', SQLERRM);',
'        RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2708156434702969829
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964059097646418412)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete Regulation'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := :P465_CARD_NUM;',
'    l_search_id NUMBER := :P465_SEARCH_SELECTION;',
'    l_milestone NUMBER := :P465_MILESTONE_SELECTION;',
'    l_specific_reg_id NUMBER := :P465_SPECIFIC_REG_ID;',
'    ',
'BEGIN',
'    debug(''DELETE Process Start'', ''Card: '' || l_card_number || '', Search: '' || l_search_id || '', Milestone: '' || l_milestone);',
'    ',
'    -- Delete the regulation records',
'    DELETE FROM T_MS_SUCHERGEBNISS ms',
'    WHERE EXISTS (',
'        SELECT 1 ',
'        FROM T_MS_SUCHE_SPLIT split',
'        WHERE split.CARD_NUMBER = l_card_number',
'        -- AND split.BENUTZERID = :G_BENUTZERID',
'        AND (split.BENUTZERID = :G_BENUTZERID ',
'         OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                    WHERE brr.benutzerid = :G_BENUTZERID ',
'                    AND brr.rolleid = 1001)',
'        )',
'        AND split.SUCHEID = ms.SUCHEID',
'        AND split.MEILENSTEIN = ms.MEILENSTEIN',
'        AND split.LANDID = ms.LANDID',
'    );',
'    ',
'    -- Delete the split records',
'    DELETE FROM T_MS_SUCHE_SPLIT',
'    WHERE CARD_NUMBER = l_card_number',
'    -- AND BENUTZERID = :G_BENUTZERID;',
'    AND (BENUTZERID = :G_BENUTZERID',
'     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                WHERE brr.benutzerid = :G_BENUTZERID ',
'                AND brr.rolleid = 1001)',
'    );',
'    ',
' ',
'',
'    debug(''DELETE Process Complete'', ''Deleted card: '' || l_card_number);',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        debug(''DELETE Process Error'', ''Error: '' || SQLERRM);',
'        RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(964061464624418415)
,p_internal_uid=>2708153218252969823
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964058678549418411)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2708153637349969824
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964057889298418410)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Create Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Clear all fields for new entry',
'    :P465_SPECIFIC_REG_ID := NULL;',
'    :P465_VORSCHRIFT_NUMMER := NULL;',
'    :P465_PUBLISHER := NULL;',
'    :P465_THEMABEZEICHNUNG := NULL;',
'    :P465_LAND := NULL;',
'    ',
'    -- Set the manual mode flag',
'    :P465_MANUAL_MODE := ''Y'';',
'    ',
'    -- Determine workflow source and set context appropriately',
'    IF :P465_RETURN_PAGE = ''461'' OR :P465_CARD_NUM IS NOT NULL THEN',
'        -- Coming from Page 461 (Regulation Details for a specific card)',
'        -- Card Number is already set in P465_CARD_NUM from URL parameters',
'        apex_debug.message(''CREATE Mode from Page 461. Card Num: %s'', :P465_CARD_NUM);',
'        ',
'        -- Verify the card exists and get search context if missing',
'        IF :P465_SEARCH_SELECTION IS NULL OR :P465_MILESTONE_SELECTION IS NULL THEN',
'            BEGIN',
'                SELECT DISTINCT split.SUCHEID, split.MEILENSTEIN',
'                INTO :P465_SEARCH_SELECTION, :P465_MILESTONE_SELECTION',
'                FROM T_MS_SUCHE_SPLIT split',
'                WHERE split.CARD_NUMBER = :P465_CARD_NUM',
'                AND split.BENUTZERID = :G_BENUTZERID',
'                AND ROWNUM = 1;',
'            EXCEPTION',
'                WHEN NO_DATA_FOUND THEN',
'                    apex_debug.error(''Card not found: %s'', :P465_CARD_NUM);',
'                    raise_application_error(-20001, ''Card not found'');',
'            END;',
'        END IF;',
'        ',
'    ELSIF :P465_RETURN_PAGE = ''450'' THEN',
'        -- Coming from Page 450 (Search Hub)',
'        -- No Card Number exists yet for this context',
'        :P465_CARD_NUM := NULL;',
'        apex_debug.message(''CREATE Mode from Page 450. Search ID: %s'', :P465_SEARCH_SELECTION);',
'        ',
'    ELSE',
'        -- Fallback: try to determine context from available parameters',
'        IF :P465_CARD_NUM IS NOT NULL THEN',
'            -- Has card number, treat as Page 461 workflow',
'            apex_debug.message(''CREATE Mode (fallback) - using card workflow'');',
'        ELSE',
'            -- No card number, treat as Page 450 workflow',
'            apex_debug.message(''CREATE Mode (fallback) - using search workflow'');',
'        END IF;',
'    END IF;',
'    ',
'    -- Ensure we have required search context',
'    IF :P465_SEARCH_SELECTION IS NULL OR :P465_MILESTONE_SELECTION IS NULL THEN',
'        apex_debug.error(''Missing search context. Search: %s, Milestone: %s'', ',
'                        :P465_SEARCH_SELECTION, :P465_MILESTONE_SELECTION);',
'        raise_application_error(-20002, ''Missing search context'');',
'    END IF;',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_debug.error(''CREATE Load Error: %s'', SQLERRM);',
'        RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P465_MODE'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'CREATE'
,p_internal_uid=>2708154426600969825
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964058252281418411)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Edit Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := :P465_CARD_NUM;',
'    l_specific_reg_id NUMBER := :P465_SPECIFIC_REG_ID;',
'    l_countries VARCHAR2(4000);',
'    ',
'BEGIN',
'    apex_debug.message(''EDIT Load Start - Card: %s, Reg ID: %s'', l_card_number, l_specific_reg_id);',
'    ',
'    -- Get search and milestone info',
'    SELECT DISTINCT',
'        split.SUCHEID,',
'        split.MEILENSTEIN',
'    INTO ',
'        :P465_SEARCH_SELECTION,',
'        :P465_MILESTONE_SELECTION',
'    FROM T_MS_SUCHE_SPLIT split',
'    WHERE split.CARD_NUMBER = l_card_number',
'    AND (split.BENUTZERID = :G_BENUTZERID',
'         OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                    WHERE brr.benutzerid = :G_BENUTZERID ',
'                    AND brr.rolleid = 1001)',
'        )',
'    AND ROWNUM = 1;',
'    ',
'    -- Load regulation data for this SPECIFIC regulation ID',
'    BEGIN',
'        SELECT ',
'            ms.THEMABEZEICHNUNG,',
'            ms.VORSCHRIFTID,',
'            -- Get the display format of regulation number with date if applicable',
'            CASE ',
'                WHEN tp.ANZEIGE_MIT_DOKUMENTENDATUM = 20 ',
'                     AND v.DOKUMENTENDATUM IS NOT NULL ',
'                THEN v.VORSCHRIFT_NUMMER || ''_'' || TO_CHAR(v.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'                ELSE v.VORSCHRIFT_NUMMER ',
'            END AS VORSCHRIFT_NUMMER_DISPLAY,',
'            v.PUBLISHER',
'        INTO ',
'            :P465_THEMABEZEICHNUNG,',
'            :P465_VORSCHRIFT_ID,',
'            :P465_VORSCHRIFT_NUMMER,',
'            :P465_PUBLISHER',
'        FROM T_MS_SUCHERGEBNISS ms',
'        JOIN t_vorschrift v ON v.VORSCHRIFTID = ms.VORSCHRIFTID',
'        LEFT OUTER JOIN t_publisher tp ON v.publisherid = tp.publisherid',
'        WHERE ms.SUCHEID = :P465_SEARCH_SELECTION',
'        AND ms.MEILENSTEIN = :P465_MILESTONE_SELECTION',
'        AND ms.MANUELLER_EINTRAG = 10',
'        AND CASE ',
'            WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'            ELSE ms.VORSCHRIFTID',
'        END = l_specific_reg_id',
'        AND EXISTS (',
'            SELECT 1 ',
'            FROM T_MS_SUCHE_SPLIT split',
'            WHERE split.CARD_NUMBER = l_card_number',
'            AND (split.BENUTZERID = :G_BENUTZERID',
'                 OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                            WHERE brr.benutzerid = :G_BENUTZERID ',
'                            AND brr.rolleid = 1001)',
'                )',
'            AND split.SUCHEID = ms.SUCHEID',
'            AND split.MEILENSTEIN = ms.MEILENSTEIN',
'            AND split.LANDID = ms.LANDID',
'        )',
'        AND ROWNUM = 1;  -- Get the first match for this specific regulation',
'        ',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            apex_debug.error(''No manual entry found for card: %s, reg: %s'', l_card_number, l_specific_reg_id);',
'            raise_application_error(-20003, ''Kein manueller Eintrag gefunden'');',
'    END;',
'',
'    -- Get selected countries for THIS specific regulation',
'    SELECT LISTAGG(DISTINCT ms.landid, '':'') WITHIN GROUP (ORDER BY ms.landnummer)',
'    INTO :P465_LAND',
'    FROM T_MS_SUCHERGEBNISS ms',
'    WHERE ms.SUCHEID = :P465_SEARCH_SELECTION',
'    AND ms.MEILENSTEIN = :P465_MILESTONE_SELECTION',
'    AND ms.MANUELLER_EINTRAG = 10',
'    AND CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END = l_specific_reg_id',
'    AND ms.LANDID IN (',
'        SELECT split.LANDID',
'        FROM T_MS_SUCHE_SPLIT split',
'        WHERE split.CARD_NUMBER = l_card_number',
'        AND (split.BENUTZERID = :G_BENUTZERID',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001)',
'            )',
'    );',
'',
'    -- Set LANDIDS for display',
'    :P465_LANDIDS := REPLACE(:P465_LAND, '':'', '';'');',
'    ',
'    apex_debug.message(''EDIT Load Complete - VorID: %s, VorNummer: %s, Theme: %s, Countries: %s'', ',
'                       :P465_VORSCHRIFT_ID, :P465_VORSCHRIFT_NUMMER, :P465_THEMABEZEICHNUNG, :P465_LAND);',
'        ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_debug.error(''EDIT Load Error: %s'', SQLERRM);',
'        RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P465_MODE'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'EDIT'
,p_internal_uid=>2708154063617969824
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964056666020418407)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Create Data_25jul '
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Clear all fields for new entry',
'    :P465_SPECIFIC_REG_ID := NULL;',
'    :P465_VORSCHRIFT_NUMMER := NULL;',
'    -- :P465_ALTERNATIVE_VORSCHRIFTENNUMMER := NULL;',
'    :P465_PUBLISHER := NULL;',
'    :P465_THEMABEZEICHNUNG := NULL;',
'    :P465_LAND := NULL; ',
'    ',
'    -- Get search context from previous page (Page 461)',
'    :P465_SEARCH_SELECTION := :P461_SEARCH_SELECTION;',
'    :P465_MILESTONE_SELECTION := :P461_MILESTONE_SELECTION;',
'    :P465_LANDIDS := :P461_LANDIDS;',
'    ',
'    ',
'',
'    ',
'    -- Set manual mode flag',
'    :P465_MANUAL_MODE := ''Y'';',
'',
'    :P465_CARD_NUM := :P461_CARD_NUM;',
'    ',
'    -- Debug',
'    apex_debug.message(''CREATE Mode Load - Search: %s, Milestone: %s, LandIDs: %s'', ',
'                       :P465_SEARCH_SELECTION, ',
'                       :P465_MILESTONE_SELECTION,',
'                       :P465_LANDIDS);',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_debug.error(''CREATE Load Error: %s'', SQLERRM);',
'        RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2708155649878969828
);
wwv_flow_imp.component_end;
end;
/
