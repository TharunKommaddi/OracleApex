prompt --application/pages/page_00601
begin
--   Manifest
--     PAGE: 00601
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>601
,p_name=>'MS Suchergebnisse Dialoganzeige'
,p_alias=>'MS-SUCHERGEBNISSE-DIALOGANZEIGE'
,p_page_mode=>'MODAL'
,p_step_title=>'Suchergebnisse'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'900'
,p_dialog_width=>'1600'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(394297759305385558)
,p_plug_name=>'&nbsp;'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(376102736593059304)
,p_plug_name=>'Suchergebnisse'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_base_regel as ( Select t.vorschriftid, t.MS_PARAMETERID, row_number() over ( partition by t.vorschriftid order by kritikalitaet, ALTERNATIVE_VORSCHRIFTID desc) as xrow',
'        from t_ms_suchergebniss t ',
'        join t_ms_parameter pm on (t.MS_PARAMETERID =pm.MS_PARAMETERID)',
'left join T_MS_PARAMETER_REF_AUSGABE tpr on (t.MS_PARAMETERID =tpr.MS_PARAMETERID)',
'left join T_MS_AUSGABE_TEXT ta on(tpr.MS_AUSGABE_TEXTID= ta.MS_AUSGABE_TEXTID)',
'where sucheid = :P601_SUCHEID and meilenstein = :P601_MEILENSTEIN',
'),',
'ausgabe as(',
'    select pra.ms_parameterID ms_parameterID, aut.ms_ausgabe_textid ms_ausgabe_textid,',
'    aut.ausgabe_text ausgabe_text ',
'    from  T_MS_AUSGABE_TEXT aut',
'    join T_MS_PARAMETER_REF_AUSGABE pra on (pra.ms_ausgabe_textid = aut.ms_ausgabe_textid) ',
'),',
'landgr as ( select  lrg.landid landid, l.b_nummer b_nummer',
'             , listagg(lg.laendergruppe, '', '') within group (order by lg.laendergruppe) lg_list',
'           , listagg(lg.laendergruppeid, '':'') within group (order by lg.laendergruppeid) lg_id_list',
'             from t_land_ref_laendergruppe lrg',
'             join t_laendergruppe lg on (lg.laendergruppeid = lrg.laendergruppeid)',
'             join t_land l  on (l.landid = lrg.landid )',
'            group by lrg.landid , l.b_nummer ',
'),',
'bild as(',
'    select prb.ms_parameterID ms_parameterID, --bi.ms_bildid ms_bildid, ',
'   /* listagg(bi.bild_nummer, '', '') within group (order by bi.bild_nummer)  bild_nummer ,',
'    case when :FSP_LANGUAGE_PREFERENCE = ''de'' and bi.bezeichnung is not null then bi.bezeichnung',
'     when :FSP_LANGUAGE_PREFERENCE = ''en'' and bi.name_eng is not null then bi.name_eng else to_char(bi.bild_nummer) end bild_name,*/',
'    listagg( ',
'    ''<a href="'' ||  apex_page.get_url(p_page => 2010, p_clear_cache => ''2010,RP'', p_items => ''P2010_BILD_NUMMER'', p_values => bild_nummer ) || ',
'    ''"><span >'' || case when :FSP_LANGUAGE_PREFERENCE = ''de'' and bi.bezeichnung is not null then bi.bezeichnung',
'     when :FSP_LANGUAGE_PREFERENCE = ''en'' and bi.name_eng is not null then bi.name_eng else to_char(bi.bild_nummer) end  ||''</span></a>'', '', '') within group (order by bi.bild_nummer)  as bild_link',
'',
'    from T_MS_PARAMETER_REF_BILD prb',
'    join T_MS_BILD bi on (prb.ms_bildid = bi.ms_bildid)',
'    group by  prb.ms_parameterID --, bi.bezeichnung, bi.name_eng, bi.bild_nummer',
'),',
'sucherg as (',
'select  se.Vorschriftnummer as Vorschriftnummer, vorschrifttitel,   --THEMAID, ',
'  THEMANUMMER || ''-''|| THEMABEZEICHNUNG THEMA,     --LANDBEZEICHNUNG,',
'  LANDNUMMER, ',
'  landgr.lg_list laendergruppen,',
'  REGELNUMMER Regel',
', STATUS_VORSCHRIFT "Vorschrift status"',
unistr(', se.PROGNOSE_QUALITAET "Prognose Qualit\00E4t"'),
', case se.SW_RELEVANT  WHEN ''0'' THEN emano_util.fLang(''nein'', ''no'')',
'    WHEN ''10'' THEN emano_util.fLang(''ja'', ''yes'')',
unistr('    WHEN ''20'' THEN emano_util.fLang(''nicht gepr\00FCft'', ''not checked'')'),
unistr('    ELSE emano_util.fLang(''nicht gepr\00FCft'', ''not checked'')  end'),
'as "SW relevant", se.RISIKO ',
',  p.VERNETZUNGSART',
'  ,  p.FAHRZEUGZULASSUNG',
'  ,  p.FAHRZEUGKLASSE',
'  ,  p.DATUMSANGABEN_ORIGINAL_VERNETZUNG',
'  ,  p.VORSCHRIFTEN_TYP',
'  ,  p.FBU_CKD_RELEVANTES_LAND',
'  ,  p.PARAMETER_CKD_FBU_DATUM',
'  ,  p.QUELLVORSCHRIFT_GUELTIG',
'',
' ',
'',
'  , decode(p.SOP_IST_VOR_DATUM_IN_KRAFT,   0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as SOP_IST_VOR_DATUM_IN_KRAFT',
'  , decode(p.SOP_GLEICH_ODER_NACH_DATUM_IN_KRAFT,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as SOP_GLEICH_ODER_NACH_DATUM_IN_KRAFT  ',
'  ,	decode(p.SOP_IST_VOR_DATUM_NEUE_TYPEN,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as  SOP_IST_VOR_DATUM_NEUE_TYPEN',
'  , decode(p.SOP_IST_NACH_ODER_GLEICH_DATUM_NEUE_TYPEN,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as SOP_IST_NACH_ODER_GLEICH_DATUM_NEUE_TYPEN',
'	, decode(p.SOP_IST_VOR_DATUM_ALLE_FAHRZEUGE,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as   SOP_IST_VOR_DATUM_ALLE_FAHRZEUGE',
'	, decode(p.SOP_IST_NACH_ODER_GLECIH_DATUM_ALLE_FAHRZEUGE_ ,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as SOP_IST_NACH_ODER_GLECIH_DATUM_ALLE_FAHRZEUGE_',
'  , decode(p.SOP_IST_VOR_DATUM_AUSSER_KRAFT ,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as  SOP_IST_VOR_DATUM_AUSSER_KRAFT',
'  , decode(p.SOP_IST_NACH_ODER_GLEICH_DATUM_AUSSER_KRAFT,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as   SOP_IST_NACH_ODER_GLEICH_DATUM_AUSSER_KRAFT',
'	, decode(p.EOP_LIEGT_VOR_DATUM_ALLE_FAHRZEUGE ,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as  EOP_LIEGT_VOR_DATUM_ALLE_FAHRZEUGE',
'	, decode(p.EOP_LIEGT_NACH_ODER_GLEICH_DATUM_ALLE_FAHRZEUGE ,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as  EOP_LIEGT_NACH_ODER_GLEICH_DATUM_ALLE_FAHRZEUGE',
'	, decode(p.EOP_LIEGT_VOR_DATUM_IN_KRAFT,   0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''')  as   EOP_LIEGT_VOR_DATUM_IN_KRAFT',
'	, decode(p.EOP_LIEGT_NACH_ODER_GLEICH_DATUM_IN_KRAFT,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as EOP_LIEGT_NACH_ODER_GLEICH_DATUM_IN_KRAFT ',
'  , DECODE(p.HOEHERE_SERIE_MOEGLICH,',
'    0,emano_util.fLang(''nein'', ''no''),',
'    1, emano_util.fLang(''ja'', ''yes''),',
'    2, emano_util.fLang(''nicht relevant'',''not relevant''),',
'    null',
'    ) as HOEHERE_SERIE_MOEGLICH',
'  , case p.DECKELUNG_DER_HOEHEREN_SERIE ',
unistr('  WHEN 1 THEN emano_util.fLang(''Kleiner oder gleich "Letzte m\00F6gliche Vorschrift zur Homologation"'', ''Less than or equal to "Last possible regulation for homologation"'')'),
unistr('    WHEN 2 THEN emano_util.fLang(''Gr\00F6\00DFer "Letzte m\00F6gliche Vorschrift zur Homologation"'', ''Greater than "Last possible regulation for homologation"'')'),
'    WHEN 0 THEN emano_util.fLang(''nicht relevant'', ''not relevant'') else  null end as DECKELUNG_DER_HOEHEREN_SERIE',
'',
'  	,decode(p.SOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS,   0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as SOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS  ',
'	,decode(p.SOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as SOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS   ',
'	,decode(p.EOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS,   0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as  EOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS  ',
'	,decode(p.EOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS,    0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as EOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS   ',
'',
' ',
'',
'    , a.AUSGABE_TEXT Kommentar',
'	, decode(p.NACHFOLGER_ANZEIGEN, 1, emano_util.fLang(''ja'', ''yes''),  0,  emano_util.fLang(''nein'', ''no''), 2, emano_util.fLang(''nicht relevant'', ''not relevant''),    null) as NACHFOLGER_ANZEIGEN',
'	, decode(p.LESENDE_TABELLE_FUER_DATUMSANGABEN,',
'                                1, emano_util.fLang(''Vorschrift'', ''Regulation''),',
'                                2, emano_util.fLang(''Vernetzungstabelle'', ''Networkingtable''),',
'                                0, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'                                null',
'                            ) LESENDE_TABELLE_FUER_DATUMSANGABEN ',
'	--,AUSGABE_FUER_ANDERES_TOOL_ODER_FUER_MENSCH ',
'    , decode(p.SUPPLEMENT,',
'            1, emano_util.fLang(''ja'', ''yes''),',
'            0, emano_util.fLang(''nein'', ''No''),',
'            2, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'            null',
'        ) as SUPPLEMENT',
'    , p.VERNETZUNGSARTID',
'    , decode(upper(p.INTERNER_DB_STATUS),',
'                        20, emano_util.fLang(''Sichtbar in Regulation Index DB'', ''Visible in Regulation Index DB''),',
unistr('                        10, emano_util.fLang(''nicht relevant f\00FCr Audi AG; in Bearbeitung; Import is running'', ''not relevant for Audi AG; in process; import is running''),'),
'                        30, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'                        null',
'                    ) as INTERNER_DB_STATUS',
'    , decode( p.STATUS, 20, ''Draft'',  ',
'                40, ''Enacted'', 30, ''Final document'', ',
'                50, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'                60, ''Draft, Final document'', '''') as STATUS',
'    , decode(p.PROGNOSE_QUALITAET,',
'                        0, emano_util.fLang(''offen'', ''open''),',
'                        10, emano_util.fLang(''sicher'', ''certain''),',
unistr('                        20, emano_util.fLang(''absch\00E4tzbar'', ''estimable''),'),
unistr('                        30, emano_util.fLang(''best\00E4tigt'', ''confirmed''),'),
'                        40, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'                        50, emano_util.fLang(''leer'', ''empty''), '''' ) as PROGNOSE_QUALITAET',
'    , p.SEARCH_MODE',
'     , decode(p.PARAMETER_MJ_DATUMSFORMAT, ',
'       10, emano_util.fLang(''Datum'', ''Date''),',
'       20, emano_util.fLang(''Jahreszahl'', ''Year''),',
'       30, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'       null',
') as PARAMETER_MJ_DATUMSFORMAT  -- 10-> SOP   20 -> MJ    30 -> nicht relevant',
'',
' ',
'',
' , DECODE(p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE,',
'    1, emano_util.fLang(''ja'', ''yes''),',
'    0, emano_util.fLang(''nein'', ''no''),',
'    2, emano_util.fLang(''nicht relevant'', ''not relevant'')) as AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE',
'',
' ',
'',
'        ,DECODE(p.MJ_EINSATZ_JAHR_KLEINER_PHASEIN_START_JAHR, 0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_EINSATZ_JAHR_KLEINER_PHASEIN_START_JAHR',
'        ,DECODE(p.MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_START_JAHR, 0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', 3, ''serie'', '''') as MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_START_JAHR',
'        ,DECODE(p.MJ_EINSATZ_JAHR_KLEINER_PHASEIN_ENDE_JAHR, 0, ''false'' , 1, ''true'' , 2, ''nicht relevant'', '''') as MJ_EINSATZ_JAHR_KLEINER_PHASEIN_ENDE_JAHR',
'        ,DECODE(p.MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_ENDE_JAHR, 0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_ENDE_JAHR',
'        ,DECODE(p.MJ_EINSATZ_JAHR_KLEINER_GLEICH_AUSSER_KRAFT_JAHR, 0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_EINSATZ_JAHR_KLEINER_GLEICH_AUSSER_KRAFT_JAHR',
'        ,DECODE(p.MJ_EINSATZ_JAHR_GROESSER_AUSSER_KRAFT_JAHR, 0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_EINSATZ_JAHR_GROESSER_AUSSER_KRAFT_JAHR',
'',
' ',
'',
' ',
'',
'     , decode(p.MJ_SOP_VOR_PHASEIN_START_OR_PHASEIN_LEER,   0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_SOP_VOR_PHASEIN_START_OR_PHASEIN_LEER',
'    , decode(p.MJ_SOP_NACH_PHASEIN_START,  0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_SOP_NACH_PHASEIN_START',
'    , decode(p.MJ_SOP_VOR_PHASEIN_END_OR_PHASEIN_LEER,   0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_SOP_VOR_PHASEIN_END_OR_PHASEIN_LEER',
'     , decode(p.MJ_SOP_NACH_PHASEIN_END,   0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_SOP_NACH_PHASEIN_END',
'     , decode(p.MJ_EOP_VOR_PHASEIN_START_OR_PHASEIN_LEER,  0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_EOP_VOR_PHASEIN_START_OR_PHASEIN_LEER',
'     , decode(p.MJ_EOP_NACH_PHASEIN_START,  0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_EOP_NACH_PHASEIN_START',
'     , decode(p.MJ_EOP_VOR_PHASEIN_END_OR_PHASEIN_LEER,  0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_EOP_VOR_PHASEIN_END_OR_PHASEIN_LEER',
'     , decode(p.MJ_EOP_NACH_PHASEIN_END,  0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_EOP_NACH_PHASEIN_END',
'     , decode(p.MJ_SOP_VOR_ODER_GLEICH_AUSSER_KRAFT,  0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_SOP_VOR_ODER_GLEICH_AUSSER_KRAFT',
'    , decode(p.MJ_SOP_NACH_AUSSER_KRAFT,   0, ''false'' ,   1, ''true'' , 2, ''nicht relevant'', '''') as MJ_SOP_NACH_AUSSER_KRAFT',
'    , DECODE(p.PHASE_IN_RELEVANT, ',
'        10, ''relevant'',',
'        0, ''nicht relevant'',',
'        '''') as PHASE_IN_RELEVANT',
'',
' ',
'',
'       ,DECODE(p.PHASE_OUT_RELEVANT, ',
'        10, emano_util.fLang(''relevant'', ''relevant''),',
'        0, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'        '''') as PHASE_OUT_RELEVANT',
'',
' ',
'',
'    ,DECODE(p.IN_KRAFT_RELEVANT, ',
'        10, ''relevant'',',
'        0, ''nicht relevant'',',
'        '''') as IN_KRAFT_RELEVANT',
'',
' ',
'',
'       ,DECODE(p.NEUE_TYPEN_RELEVANT, ',
'        10, emano_util.fLang(''relevant'', ''relevant''),',
'        0, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'        '''') as NEUE_TYPEN_RELEVANT',
'',
',DECODE(p.ALLE_FAHRZEUGE_RELEVANT, ',
'        10, emano_util.fLang(''relevant'', ''relevant''),',
'        0, emano_util.fLang(''nicht relevant'', ''not relevant''),',
'        '''') as ALLE_FAHRZEUGE_RELEVANT',
'',
' ,  DECODE(p.DATUM_MJ_STATUS, ',
'        1, emano_util.fLang(''datum'', ''date''),',
'        2, emano_util.fLang(''model jahr'', ''model year''),',
'        3, emano_util.fLang(''alle'', ''all'')) as DATUM_MJ_STATUS',
'',
'    , tv.vorschrift_nummer as Alternative_Vorschrift',
'    ,tb.NACHNAME,',
'se.themaid,',
'p.MS_PARAMETERID',
'',
'',
'',
' ',
'',
'  FROM t_ms_suchergebniss se',
'join cte_base_regel cbr on (se.vorschriftid = cbr.vorschriftid and se.MS_PARAMETERID =cbr.MS_PARAMETERID and cbr.xrow =1)',
'  JOIN t_MS_parameter p on (p.ms_parameterid = se.ms_parameterid)',
'   left outer join ausgabe a on (a.MS_PARAMETERID = p.MS_PARAMETERID)',
'   left join landgr  on (landgr.b_nummer = se.landnummer)',
'   left join t_benutzer tb on (se.ANSPRECHPARTNERID = tb.benutzerid)',
'   left outer join t_vorschrift tv on (se.ALTERNATIVE_VORSCHRIFTID = tv.vorschriftid)',
'  -- left outer join v_thema_bereich tb on (se.themaid = tb.themaid)',
'',
'where (Sucheid = :P601_SUCHEID) and (meilenstein = :P601_MEILENSTEIN)',
'  /* and ( :P601_LAENDERGRUPPE_ID_SEL is null or :P601_LAENDERGRUPPE_ID_SEL',
'                         in ( select column_value from table ( apex_string.split_numbers(landgr.lg_id_list, '':'')) ) )*/',
'',
' ',
'',
'    and nvl(p.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE, 0) = :P601_SWITCH_AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE',
'  and (:P601_DATUM_TYP is null or ',
'              se.vorschriftid in (select distinct  vorschriftid from t_vorschrift where einsatzdatum_modellid = to_number(:P601_DATUM_TYP)) )',
'',
'  AND (',
'        (:P601_START_TYP = 0) ',
'        OR (:P601_START_TYP = 10 AND DATUM_MJ_STATUS = 1)',
'        OR (:P601_START_TYP = 20 AND DATUM_MJ_STATUS = 2)',
'    )',
')',
unistr('Select t."VORSCHRIFTNUMMER",t."VORSCHRIFTTITEL",t."THEMA",t."LANDNUMMER",t."LAENDERGRUPPEN",t."REGEL",t."Vorschrift status",t."Prognose Qualit\00E4t",t."SW relevant",t."RISIKO",t."VERNETZUNGSART",t."FAHRZEUGZULASSUNG",t."FAHRZEUGKLASSE",t."DATUMSANGABEN_')
||'ORIGINAL_VERNETZUNG",t."VORSCHRIFTEN_TYP",t."FBU_CKD_RELEVANTES_LAND",t."PARAMETER_CKD_FBU_DATUM",t."QUELLVORSCHRIFT_GUELTIG",t."SOP_IST_VOR_DATUM_IN_KRAFT",t."SOP_GLEICH_ODER_NACH_DATUM_IN_KRAFT",t."SOP_IST_VOR_DATUM_NEUE_TYPEN",t."SOP_IST_NACH_ODER'
||'_GLEICH_DATUM_NEUE_TYPEN",t."SOP_IST_VOR_DATUM_ALLE_FAHRZEUGE",t."SOP_IST_NACH_ODER_GLECIH_DATUM_ALLE_FAHRZEUGE_",t."SOP_IST_VOR_DATUM_AUSSER_KRAFT",t."SOP_IST_NACH_ODER_GLEICH_DATUM_AUSSER_KRAFT",t."EOP_LIEGT_VOR_DATUM_ALLE_FAHRZEUGE",t."EOP_LIEGT_N'
||'ACH_ODER_GLEICH_DATUM_ALLE_FAHRZEUGE",t."EOP_LIEGT_VOR_DATUM_IN_KRAFT",t."EOP_LIEGT_NACH_ODER_GLEICH_DATUM_IN_KRAFT",t."HOEHERE_SERIE_MOEGLICH",t."DECKELUNG_DER_HOEHEREN_SERIE",t."SOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS",t."SOP_IST_GLEICH_ODER_NAC'
||'H_DATUM_IN_KRAFT_DES_NACHFOLGERS",t."EOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS",t."EOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS",t."KOMMENTAR",t."NACHFOLGER_ANZEIGEN",t."LESENDE_TABELLE_FUER_DATUMSANGABEN",t."SUPPLEMENT",t."VERNETZUNGSART'
||'ID",t."INTERNER_DB_STATUS",t."STATUS",t."PROGNOSE_QUALITAET",t."SEARCH_MODE",t."PARAMETER_MJ_DATUMSFORMAT",t."AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE",t."MJ_EINSATZ_JAHR_KLEINER_PHASEIN_START_JAHR",t."MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_START_'
||'JAHR",t."MJ_EINSATZ_JAHR_KLEINER_PHASEIN_ENDE_JAHR",t."MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_ENDE_JAHR",t."MJ_EINSATZ_JAHR_KLEINER_GLEICH_AUSSER_KRAFT_JAHR",t."MJ_EINSATZ_JAHR_GROESSER_AUSSER_KRAFT_JAHR",t."MJ_SOP_VOR_PHASEIN_START_OR_PHASEIN_LEER"'
||',t."MJ_SOP_NACH_PHASEIN_START",t."MJ_SOP_VOR_PHASEIN_END_OR_PHASEIN_LEER",t."MJ_SOP_NACH_PHASEIN_END",t."MJ_EOP_VOR_PHASEIN_START_OR_PHASEIN_LEER",t."MJ_EOP_NACH_PHASEIN_START",t."MJ_EOP_VOR_PHASEIN_END_OR_PHASEIN_LEER",t."MJ_EOP_NACH_PHASEIN_END",t.'
||'"MJ_SOP_VOR_ODER_GLEICH_AUSSER_KRAFT",t."MJ_SOP_NACH_AUSSER_KRAFT",t."PHASE_IN_RELEVANT",t."PHASE_OUT_RELEVANT",t."IN_KRAFT_RELEVANT",t."NEUE_TYPEN_RELEVANT",',
'       t."ALLE_FAHRZEUGE_RELEVANT",t."ALTERNATIVE_VORSCHRIFT",t."NACHNAME", t.DATUM_MJ_STATUS, listagg(tb.bereich,'', '') within group (order by tb.bereich asc)  bereich,b.bild_link as bildname',
'from sucherg t',
'left outer join v_thema_bereich tb on (t.themaid = tb.themaid)',
'left outer join bild b on (b.MS_PARAMETERID = t.MS_PARAMETERID)',
unistr('group by t."VORSCHRIFTNUMMER",t."VORSCHRIFTTITEL",t."THEMA",t."LANDNUMMER",t."LAENDERGRUPPEN",t."REGEL",t."Vorschrift status",t."Prognose Qualit\00E4t",t."SW relevant",t."RISIKO",t."VERNETZUNGSART",t."FAHRZEUGZULASSUNG",t."FAHRZEUGKLASSE",t."DATUMSANGABE')
||'N_ORIGINAL_VERNETZUNG",t."VORSCHRIFTEN_TYP",t."FBU_CKD_RELEVANTES_LAND",t."PARAMETER_CKD_FBU_DATUM",t."QUELLVORSCHRIFT_GUELTIG",t."SOP_IST_VOR_DATUM_IN_KRAFT",t."SOP_GLEICH_ODER_NACH_DATUM_IN_KRAFT",t."SOP_IST_VOR_DATUM_NEUE_TYPEN",t."SOP_IST_NACH_OD'
||'ER_GLEICH_DATUM_NEUE_TYPEN",t."SOP_IST_VOR_DATUM_ALLE_FAHRZEUGE",t."SOP_IST_NACH_ODER_GLECIH_DATUM_ALLE_FAHRZEUGE_",t."SOP_IST_VOR_DATUM_AUSSER_KRAFT",t."SOP_IST_NACH_ODER_GLEICH_DATUM_AUSSER_KRAFT",t."EOP_LIEGT_VOR_DATUM_ALLE_FAHRZEUGE",t."EOP_LIEGT'
||'_NACH_ODER_GLEICH_DATUM_ALLE_FAHRZEUGE",t."EOP_LIEGT_VOR_DATUM_IN_KRAFT",t."EOP_LIEGT_NACH_ODER_GLEICH_DATUM_IN_KRAFT",t."HOEHERE_SERIE_MOEGLICH",t."DECKELUNG_DER_HOEHEREN_SERIE",t."SOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS",t."SOP_IST_GLEICH_ODER_N'
||'ACH_DATUM_IN_KRAFT_DES_NACHFOLGERS",t."EOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS",t."EOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS",t."KOMMENTAR",t."NACHFOLGER_ANZEIGEN",t."LESENDE_TABELLE_FUER_DATUMSANGABEN",t."SUPPLEMENT",t."VERNETZUNGSA'
||'RTID",t."INTERNER_DB_STATUS",t."STATUS",t."PROGNOSE_QUALITAET",t."SEARCH_MODE",t."PARAMETER_MJ_DATUMSFORMAT",t."AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE",t."MJ_EINSATZ_JAHR_KLEINER_PHASEIN_START_JAHR",t."MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_STAR'
||'T_JAHR",t."MJ_EINSATZ_JAHR_KLEINER_PHASEIN_ENDE_JAHR",t."MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_ENDE_JAHR",t."MJ_EINSATZ_JAHR_KLEINER_GLEICH_AUSSER_KRAFT_JAHR",t."MJ_EINSATZ_JAHR_GROESSER_AUSSER_KRAFT_JAHR",t."MJ_SOP_VOR_PHASEIN_START_OR_PHASEIN_LEE'
||'R",t."MJ_SOP_NACH_PHASEIN_START",t."MJ_SOP_VOR_PHASEIN_END_OR_PHASEIN_LEER",t."MJ_SOP_NACH_PHASEIN_END",t."MJ_EOP_VOR_PHASEIN_START_OR_PHASEIN_LEER",t."MJ_EOP_NACH_PHASEIN_START",t."MJ_EOP_VOR_PHASEIN_END_OR_PHASEIN_LEER",t."MJ_EOP_NACH_PHASEIN_END",'
||'t."MJ_SOP_VOR_ODER_GLEICH_AUSSER_KRAFT",t."MJ_SOP_NACH_AUSSER_KRAFT",t."PHASE_IN_RELEVANT",t."PHASE_OUT_RELEVANT",t."IN_KRAFT_RELEVANT",t."NEUE_TYPEN_RELEVANT",t."ALLE_FAHRZEUGE_RELEVANT",t."ALTERNATIVE_VORSCHRIFT",t."NACHNAME",t."THEMAID", t."DATUM_'
||'MJ_STATUS", b.bild_link--, listagg(tb.bereich,'', '') within group (order by tb.bereich asc)  bereich',
'order by 3, 4'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P601_MEILENSTEIN,P601_SUCHEID,P601_SWITCH_AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE,P601_START_TYP'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Suchergebnisse'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(376102575320059304)
,p_name=>'MS Suchergebnisse Dialoganzeige'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>true
,p_show_detail_link=>'N'
,p_download_formats=>'CSV'
,p_enable_mail_download=>'N'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>736590361775075100
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(376101381153059283)
,p_db_column_name=>'VORSCHRIFTNUMMER'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Vorschriftnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(376100963044059282)
,p_db_column_name=>'VORSCHRIFTTITEL'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Vorschrifttitel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(376098220114059280)
,p_db_column_name=>'RISIKO'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Risiko'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(394298386093385564)
,p_db_column_name=>'THEMA'
,p_display_order=>22
,p_column_identifier=>'N'
,p_column_label=>'Thema'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(394297533492385555)
,p_db_column_name=>'REGEL'
,p_display_order=>32
,p_column_identifier=>'T'
,p_column_label=>'Regel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(376100220527059281)
,p_db_column_name=>'LANDNUMMER'
,p_display_order=>42
,p_column_identifier=>'F'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(323217406647066483)
,p_db_column_name=>'LAENDERGRUPPEN'
,p_display_order=>52
,p_column_identifier=>'BB'
,p_column_label=>unistr('L\00E4ndergruppen')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(394297429528385554)
,p_db_column_name=>'Vorschrift status'
,p_display_order=>62
,p_column_identifier=>'U'
,p_column_label=>'Vorschrift Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(375333640805175303)
,p_db_column_name=>unistr('Prognose Qualit\00E4t')
,p_display_order=>72
,p_column_identifier=>'V'
,p_column_label=>unistr('Prognose Qualit\00E4t')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(375333633900175302)
,p_db_column_name=>'SW relevant'
,p_display_order=>82
,p_column_identifier=>'W'
,p_column_label=>'SW relevant'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(375332928832175295)
,p_db_column_name=>'VERNETZUNGSART'
,p_display_order=>92
,p_column_identifier=>'AD'
,p_column_label=>'Vernetzungsart'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(375332811590175294)
,p_db_column_name=>'FAHRZEUGZULASSUNG'
,p_display_order=>102
,p_column_identifier=>'AE'
,p_column_label=>'Fahrzeugzulassung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(375332692554175293)
,p_db_column_name=>'FAHRZEUGKLASSE'
,p_display_order=>112
,p_column_identifier=>'AF'
,p_column_label=>'Fahrzeugart'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(375332548784175292)
,p_db_column_name=>'DATUMSANGABEN_ORIGINAL_VERNETZUNG'
,p_display_order=>122
,p_column_identifier=>'AG'
,p_column_label=>'Datumsangaben Original Vernetzung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(375332517989175291)
,p_db_column_name=>'VORSCHRIFTEN_TYP'
,p_display_order=>132
,p_column_identifier=>'AH'
,p_column_label=>'Vorschriften Typ'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(375332340414175290)
,p_db_column_name=>'FBU_CKD_RELEVANTES_LAND'
,p_display_order=>142
,p_column_identifier=>'AI'
,p_column_label=>'FBU CKD Relevantes Land'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(375332240135175289)
,p_db_column_name=>'PARAMETER_CKD_FBU_DATUM'
,p_display_order=>152
,p_column_identifier=>'AJ'
,p_column_label=>'Parameter CKD FBU Datum'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(375332225408175288)
,p_db_column_name=>'QUELLVORSCHRIFT_GUELTIG'
,p_display_order=>162
,p_column_identifier=>'AK'
,p_column_label=>unistr('Quellvorschrift g\00FCltig')
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(960722082392392402)
,p_db_column_name=>'ALTERNATIVE_VORSCHRIFT'
,p_display_order=>662
,p_column_identifier=>'DB'
,p_column_label=>'Alternative Vorschrift'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(953284512474841403)
,p_db_column_name=>'NACHNAME'
,p_display_order=>672
,p_column_identifier=>'DC'
,p_column_label=>'Nachname'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(953284403051841402)
,p_db_column_name=>'BEREICH'
,p_display_order=>682
,p_column_identifier=>'DD'
,p_column_label=>'Bereich'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(928837925199396969)
,p_db_column_name=>'SOP_IST_VOR_DATUM_IN_KRAFT'
,p_display_order=>702
,p_column_identifier=>'DF'
,p_column_label=>'Sop Ist Vor Datum In Kraft'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(928837801942396968)
,p_db_column_name=>'SOP_GLEICH_ODER_NACH_DATUM_IN_KRAFT'
,p_display_order=>712
,p_column_identifier=>'DG'
,p_column_label=>'Sop Gleich Oder Nach Datum In Kraft'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(928837733213396967)
,p_db_column_name=>'SOP_IST_VOR_DATUM_NEUE_TYPEN'
,p_display_order=>722
,p_column_identifier=>'DH'
,p_column_label=>'Sop Ist Vor Datum Neue Typen'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(928837586054396966)
,p_db_column_name=>'SOP_IST_NACH_ODER_GLEICH_DATUM_NEUE_TYPEN'
,p_display_order=>732
,p_column_identifier=>'DI'
,p_column_label=>'Sop Ist Nach Oder Gleich Datum Neue Typen'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(928837524266396965)
,p_db_column_name=>'SOP_IST_VOR_DATUM_ALLE_FAHRZEUGE'
,p_display_order=>742
,p_column_identifier=>'DJ'
,p_column_label=>'Sop Ist Vor Datum Alle Fahrzeuge'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(928837338514396964)
,p_db_column_name=>'SOP_IST_NACH_ODER_GLECIH_DATUM_ALLE_FAHRZEUGE_'
,p_display_order=>752
,p_column_identifier=>'DK'
,p_column_label=>'Sop Ist Nach Oder Gleich Datum Alle Fahrzeuge'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(928837322574396963)
,p_db_column_name=>'SOP_IST_VOR_DATUM_AUSSER_KRAFT'
,p_display_order=>762
,p_column_identifier=>'DL'
,p_column_label=>'Sop Ist Vor Datum Ausser Kraft'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(928837186122396962)
,p_db_column_name=>'SOP_IST_NACH_ODER_GLEICH_DATUM_AUSSER_KRAFT'
,p_display_order=>772
,p_column_identifier=>'DM'
,p_column_label=>'Sop Ist Nach Oder Gleich Datum Ausser Kraft'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(928837127883396961)
,p_db_column_name=>'EOP_LIEGT_VOR_DATUM_ALLE_FAHRZEUGE'
,p_display_order=>782
,p_column_identifier=>'DN'
,p_column_label=>'Eop Liegt Vor Datum Alle Fahrzeuge'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(928836974161396960)
,p_db_column_name=>'EOP_LIEGT_NACH_ODER_GLEICH_DATUM_ALLE_FAHRZEUGE'
,p_display_order=>792
,p_column_identifier=>'DO'
,p_column_label=>'Eop Liegt Nach Oder Gleich Datum Alle Fahrzeuge'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(928836884189396959)
,p_db_column_name=>'EOP_LIEGT_VOR_DATUM_IN_KRAFT'
,p_display_order=>802
,p_column_identifier=>'DP'
,p_column_label=>'Eop Liegt Vor Datum In Kraft'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(928836831816396958)
,p_db_column_name=>'EOP_LIEGT_NACH_ODER_GLEICH_DATUM_IN_KRAFT'
,p_display_order=>812
,p_column_identifier=>'DQ'
,p_column_label=>'Eop Liegt Nach Oder Gleich Datum In Kraft'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(928836551903396956)
,p_db_column_name=>'DECKELUNG_DER_HOEHEREN_SERIE'
,p_display_order=>832
,p_column_identifier=>'DS'
,p_column_label=>unistr('Deckelung Der H\00F6heren Serie')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(928836456248396955)
,p_db_column_name=>'SOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS'
,p_display_order=>842
,p_column_identifier=>'DT'
,p_column_label=>'Sop Ist Vor Datum In Kraft Des Nachfolgers'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(928836396896396954)
,p_db_column_name=>'SOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS'
,p_display_order=>852
,p_column_identifier=>'DU'
,p_column_label=>'Sop Ist Gleich Oder Nach Datum In Kraft Des Nachfolgers'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914510965290931903)
,p_db_column_name=>'EOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS'
,p_display_order=>862
,p_column_identifier=>'DV'
,p_column_label=>'Eop Ist Vor Datum In Kraft Des Nachfolgers'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914510909214931902)
,p_db_column_name=>'EOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS'
,p_display_order=>872
,p_column_identifier=>'DW'
,p_column_label=>'Eop Ist Gleich Oder Nach Datum In Kraft Des Nachfolgers'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914510802447931901)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>882
,p_column_identifier=>'DX'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914510691632931900)
,p_db_column_name=>'NACHFOLGER_ANZEIGEN'
,p_display_order=>892
,p_column_identifier=>'DY'
,p_column_label=>'Nachfolger Anzeigen'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914510601698931899)
,p_db_column_name=>'LESENDE_TABELLE_FUER_DATUMSANGABEN'
,p_display_order=>902
,p_column_identifier=>'DZ'
,p_column_label=>'Lesende Tabelle Fuer Datumsangaben'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914510481641931898)
,p_db_column_name=>'SUPPLEMENT'
,p_display_order=>912
,p_column_identifier=>'EA'
,p_column_label=>'Supplement'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914510432356931897)
,p_db_column_name=>'VERNETZUNGSARTID'
,p_display_order=>922
,p_column_identifier=>'EB'
,p_column_label=>'Vernetzungsartid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914510308162931896)
,p_db_column_name=>'INTERNER_DB_STATUS'
,p_display_order=>932
,p_column_identifier=>'EC'
,p_column_label=>'Interner Db Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914510139436931895)
,p_db_column_name=>'STATUS'
,p_display_order=>942
,p_column_identifier=>'ED'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914510132558931894)
,p_db_column_name=>'PROGNOSE_QUALITAET'
,p_display_order=>952
,p_column_identifier=>'EE'
,p_column_label=>unistr('PrognoseQualit\00E4t')
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914509948902931893)
,p_db_column_name=>'SEARCH_MODE'
,p_display_order=>962
,p_column_identifier=>'EF'
,p_column_label=>'Search Mode'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914509898162931892)
,p_db_column_name=>'PARAMETER_MJ_DATUMSFORMAT'
,p_display_order=>972
,p_column_identifier=>'EG'
,p_column_label=>'Parameter Mj Datumsformat'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914509069149931884)
,p_db_column_name=>'MJ_SOP_VOR_PHASEIN_START_OR_PHASEIN_LEER'
,p_display_order=>1052
,p_column_identifier=>'EO'
,p_column_label=>'Mj Sop Vor Phasein Start Or Phasein Leer'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914508999781931883)
,p_db_column_name=>'MJ_SOP_NACH_PHASEIN_START'
,p_display_order=>1062
,p_column_identifier=>'EP'
,p_column_label=>'Mj Sop Nach Phasein Start'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914508935871931882)
,p_db_column_name=>'MJ_SOP_VOR_PHASEIN_END_OR_PHASEIN_LEER'
,p_display_order=>1072
,p_column_identifier=>'EQ'
,p_column_label=>'Mj Sop Vor Phasein End Or Phasein Leer'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914508774884931881)
,p_db_column_name=>'MJ_SOP_NACH_PHASEIN_END'
,p_display_order=>1082
,p_column_identifier=>'ER'
,p_column_label=>'Mj Sop Nach Phasein End'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914508689837931880)
,p_db_column_name=>'MJ_EOP_VOR_PHASEIN_START_OR_PHASEIN_LEER'
,p_display_order=>1092
,p_column_identifier=>'ES'
,p_column_label=>'Mj Eop Vor Phasein Start Or Phasein Leer'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914508563547931879)
,p_db_column_name=>'MJ_EOP_NACH_PHASEIN_START'
,p_display_order=>1102
,p_column_identifier=>'ET'
,p_column_label=>'Mj Eop Nach Phasein Start'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914508516991931878)
,p_db_column_name=>'MJ_EOP_VOR_PHASEIN_END_OR_PHASEIN_LEER'
,p_display_order=>1112
,p_column_identifier=>'EU'
,p_column_label=>'Mj Eop Vor Phasein End Or Phasein Leer'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914508428919931877)
,p_db_column_name=>'MJ_EOP_NACH_PHASEIN_END'
,p_display_order=>1122
,p_column_identifier=>'EV'
,p_column_label=>'Mj Eop Nach Phasein End'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914508282468931876)
,p_db_column_name=>'MJ_SOP_VOR_ODER_GLEICH_AUSSER_KRAFT'
,p_display_order=>1132
,p_column_identifier=>'EW'
,p_column_label=>unistr('Mj Sop Vor Oder Gleich Au\00DFer Kraft')
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914508181088931875)
,p_db_column_name=>'MJ_SOP_NACH_AUSSER_KRAFT'
,p_display_order=>1142
,p_column_identifier=>'EX'
,p_column_label=>unistr('Mj Sop Nach Au\00DFer Kraft')
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914508001599931873)
,p_db_column_name=>'AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE'
,p_display_order=>1152
,p_column_identifier=>'EZ'
,p_column_label=>'Ausgabe Der Vorschrift Bei Report Baureihe'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914507266786931866)
,p_db_column_name=>'MJ_EINSATZ_JAHR_KLEINER_PHASEIN_START_JAHR'
,p_display_order=>1162
,p_column_identifier=>'FA'
,p_column_label=>'Mj Einsatz Jahr Kleiner Phasein Start Jahr'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914507178406931865)
,p_db_column_name=>'MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_START_JAHR'
,p_display_order=>1172
,p_column_identifier=>'FB'
,p_column_label=>unistr('Mj Einsatz Jahr Gr\00F6\00DFer Gleich Phasein Start Jahr')
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914507114380931864)
,p_db_column_name=>'MJ_EINSATZ_JAHR_KLEINER_PHASEIN_ENDE_JAHR'
,p_display_order=>1182
,p_column_identifier=>'FC'
,p_column_label=>'Mj Einsatz Jahr Kleiner Phasein Ende Jahr'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914506963585931863)
,p_db_column_name=>'MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_ENDE_JAHR'
,p_display_order=>1192
,p_column_identifier=>'FD'
,p_column_label=>unistr('Mj Einsatz Jahr Gr\00F6\00DFer Gleich Phasein Ende Jahr')
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914506897626931862)
,p_db_column_name=>'MJ_EINSATZ_JAHR_KLEINER_GLEICH_AUSSER_KRAFT_JAHR'
,p_display_order=>1202
,p_column_identifier=>'FE'
,p_column_label=>unistr('Mj Einsatz Jahr Kleiner Gleich Au\00DFer Kraft Jahr')
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914506836842931861)
,p_db_column_name=>'MJ_EINSATZ_JAHR_GROESSER_AUSSER_KRAFT_JAHR'
,p_display_order=>1212
,p_column_identifier=>'FF'
,p_column_label=>unistr('Mj Einsatz Jahr Gr\00F6\00DFer Au\00DFer Kraft Jahr')
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914506680546931860)
,p_db_column_name=>'PHASE_IN_RELEVANT'
,p_display_order=>1222
,p_column_identifier=>'FG'
,p_column_label=>'Phase In Relevant'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914506579094931859)
,p_db_column_name=>'PHASE_OUT_RELEVANT'
,p_display_order=>1232
,p_column_identifier=>'FH'
,p_column_label=>'Phase Out Relevant'
,p_column_type=>'STRING'
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P601_START_TYP'
,p_display_condition2=>'0:20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914506484607931858)
,p_db_column_name=>'HOEHERE_SERIE_MOEGLICH'
,p_display_order=>1242
,p_column_identifier=>'FI'
,p_column_label=>unistr('H\00F6here Serie M\00F6glich')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914506341544931857)
,p_db_column_name=>'IN_KRAFT_RELEVANT'
,p_display_order=>1252
,p_column_identifier=>'FJ'
,p_column_label=>'In Kraft Relevant'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914506256694931856)
,p_db_column_name=>'NEUE_TYPEN_RELEVANT'
,p_display_order=>1262
,p_column_identifier=>'FK'
,p_column_label=>'Neue Typen Relevant'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(914506212775931855)
,p_db_column_name=>'ALLE_FAHRZEUGE_RELEVANT'
,p_display_order=>1272
,p_column_identifier=>'FL'
,p_column_label=>'Alle Fahrzeuge Relevant'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(907590658224692599)
,p_db_column_name=>'DATUM_MJ_STATUS'
,p_display_order=>1282
,p_column_identifier=>'FM'
,p_column_label=>'Datum Mj Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(883687838345223172)
,p_db_column_name=>'BILDNAME'
,p_display_order=>1292
,p_column_identifier=>'FN'
,p_column_label=>'Bildname'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(376096096180015666)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'7365969'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'VORSCHRIFTNUMMER:KOMMENTAR:VORSCHRIFTTITEL:Vorschrift status:REGEL:BILDNAME:RISIKO:VERNETZUNGSART:FAHRZEUGZULASSUNG:FAHRZEUGKLASSE:THEMA:LANDNUMMER:DATUMSANGABEN_ORIGINAL_VERNETZUNG:VORSCHRIFTEN_TYP:FBU_CKD_RELEVANTES_LAND:PARAMETER_CKD_FBU_DATUM:PAR'
||unistr('AMETER_MJ_DATUMSFORMAT:QUELLVORSCHRIFT_GUELTIG:SUPPLEMENT:INTERNER_DB_STATUS:STATUS:PROGNOSE_QUALITAET:Prognose Qualit\00E4t:IN_KRAFT_RELEVANT:SOP_IST_VOR_DATUM_IN_KRAFT:SOP_GLEICH_ODER_NACH_DATUM_IN_KRAFT:NEUE_TYPEN_RELEVANT:SOP_IST_VOR_DATUM_NEUE_TYPEN')
||':SOP_IST_NACH_ODER_GLEICH_DATUM_NEUE_TYPEN:ALLE_FAHRZEUGE_RELEVANT:SOP_IST_VOR_DATUM_ALLE_FAHRZEUGE:SOP_IST_NACH_ODER_GLECIH_DATUM_ALLE_FAHRZEUGE_:SOP_IST_VOR_DATUM_AUSSER_KRAFT:SOP_IST_NACH_ODER_GLEICH_DATUM_AUSSER_KRAFT:EOP_LIEGT_VOR_DATUM_IN_KRAFT'
||':EOP_LIEGT_NACH_ODER_GLEICH_DATUM_IN_KRAFT:EOP_LIEGT_VOR_DATUM_ALLE_FAHRZEUGE:EOP_LIEGT_NACH_ODER_GLEICH_DATUM_ALLE_FAHRZEUGE:HOEHERE_SERIE_MOEGLICH:DECKELUNG_DER_HOEHEREN_SERIE:SOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS:SOP_IST_GLEICH_ODER_NACH_DATU'
||'M_IN_KRAFT_DES_NACHFOLGERS:EOP_IST_VOR_DATUM_IN_KRAFT_DES_NACHFOLGERS:EOP_IST_GLEICH_ODER_NACH_DATUM_IN_KRAFT_DES_NACHFOLGERS:NACHFOLGER_ANZEIGEN:LESENDE_TABELLE_FUER_DATUMSANGABEN:AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE:PHASE_IN_RELEVANT:MJ_SOP_V'
||'OR_PHASEIN_START_OR_PHASEIN_LEER:MJ_SOP_NACH_PHASEIN_START:MJ_SOP_VOR_PHASEIN_END_OR_PHASEIN_LEER:MJ_SOP_NACH_PHASEIN_END:MJ_EOP_VOR_PHASEIN_START_OR_PHASEIN_LEER:MJ_EOP_NACH_PHASEIN_START:PHASE_OUT_RELEVANT:MJ_EOP_VOR_PHASEIN_END_OR_PHASEIN_LEER:MJ_'
||'EOP_NACH_PHASEIN_END:MJ_SOP_VOR_ODER_GLEICH_AUSSER_KRAFT:MJ_SOP_NACH_AUSSER_KRAFT:MJ_EINSATZ_JAHR_KLEINER_PHASEIN_START_JAHR:MJ_EINSATZ_JAHR_GROESSER_GLEICH_PHASEIN_START_JAHR:MJ_EINSATZ_JAHR_KLEINER_PHASEIN_ENDE_JAHR:MJ_EINSATZ_JAHR_GROESSER_GLEICH_'
||'PHASEIN_ENDE_JAHR:MJ_EINSATZ_JAHR_KLEINER_GLEICH_AUSSER_KRAFT_JAHR:MJ_EINSATZ_JAHR_GROESSER_AUSSER_KRAFT_JAHR:BEREICH:LAENDERGRUPPEN:NACHNAME:SW relevant:SEARCH_MODE:ALTERNATIVE_VORSCHRIFT:DATUM_MJ_STATUS:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(394297641329385557)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(394297759305385558)
,p_button_name=>'CLOSE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1078792582761398587)
,p_name=>'P601_DATUM_TYP'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(376102736593059304)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1078792473520398586)
,p_name=>'P601_START_TYP'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(376102736593059304)
,p_item_default=>'10'
,p_prompt=>'&nbsp;'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Datum'', ''Date'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''ModelJahr'', ''ModelYear'') AS display_value,',
'        20 AS actual_value,',
'        2 AS sort_order  ',
'    FROM dual',
' UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''alle'', ''all'') AS display_value,',
'        0 AS actual_value,',
'        3 AS sort_order  ',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>8
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(914507570127931869)
,p_name=>'P601_SWITCH_AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(376102736593059304)
,p_item_default=>'1'
,p_prompt=>'&nbsp'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Negativliste',
  'off_value', '0',
  'on_label', 'Positivliste',
  'on_value', '1',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(394298549125385566)
,p_name=>'P601_SUCHEID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(376102736593059304)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(394298477418385565)
,p_name=>'P601_MEILENSTEIN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(376102736593059304)
,p_prompt=>'Meilenstein'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(323217331960066482)
,p_name=>'P601_LAENDERGRUPPE_FILTER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(376102736593059304)
,p_prompt=>'Laendergruppe'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct laendergruppe d , laendergruppeid r',
'  from t_laendergruppe ',
' where laendergruppe_typ != ''Schattengruppe'''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('- w\00E4hlen -')
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(323216908000066478)
,p_name=>'P601_LAENDERGRUPPE_ID_SEL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(376102736593059304)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(323217185042066481)
,p_name=>'on Change'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P601_LAENDERGRUPPE_FILTER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(323217005298066479)
,p_event_id=>wwv_flow_imp.id(323217185042066481)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'select :P601_LAENDERGRUPPE_FILTER into :P601_LAENDERGRUPPE_ID_SEL from dual;'
,p_attribute_02=>'P601_LAENDERGRUPPE_FILTER'
,p_attribute_03=>'P601_LAENDERGRUPPE_ID_SEL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(323217077597066480)
,p_event_id=>wwv_flow_imp.id(323217185042066481)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(376102736593059304)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1078792383484398585)
,p_name=>'on_Change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P601_START_TYP'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1078792184044398583)
,p_event_id=>wwv_flow_imp.id(1078792383484398585)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P601_START_TYP'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1078792268551398584)
,p_event_id=>wwv_flow_imp.id(1078792383484398585)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(376102736593059304)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(914507472255931868)
,p_name=>'Switch Refresh'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P601_SWITCH_AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(914507366558931867)
,p_event_id=>wwv_flow_imp.id(914507472255931868)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Report'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(376102736593059304)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(394297622749385556)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dlg'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(394297641329385557)
,p_internal_uid=>3277914693150002679
);
wwv_flow_imp.component_end;
end;
/
