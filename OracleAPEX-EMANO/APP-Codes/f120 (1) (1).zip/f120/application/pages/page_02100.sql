prompt --application/pages/page_02100
begin
--   Manifest
--     PAGE: 02100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>2100
,p_name=>'GETEX Blacklist'
,p_alias=>'GETEX-BLACKLIST'
,p_step_title=>'GETEX Blacklist'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(739324639158286584)
,p_plug_name=>'GETEX Blacklist'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    t.*,',
'    -- pck_ri.fcreateLinkIfUrl(v.url_getex_vorschrift, 512) AS getex_vorschrift_link',
'    -- v.url_getex_vorschrift AS getex_vorschrift_link',
'    CASE WHEN v.url_getex_vorschrift IS NOT NULL ',
'            THEN ''<a href="'' || v.url_getex_vorschrift || ''" title="'' || v.url_getex_vorschrift || ''"><span class="fa fa-link"></span></a>''',
'            ELSE null',
'    END AS getex_vorschrift_link',
'       ',
'from t_getex_blacklist gb,',
'json_table (gb.daten, ''$[*]'' columns (',
'    datensatz clob format json path ''$'',',
'    id number path ''$.id'',',
'    sourceregulationid number path ''$.sourceRegulationId'',',
'    sourceregulationnumber varchar2(250) path ''$.sourceRegulationNumber'',',
'    targetregulationid number path ''$.targetRegulationId'',',
'    targetregulationnumber varchar2(250) path ''$.targetRegulationNumber'',',
'    relationtype varchar2(250) path ''$.relationType'',',
'    reason varchar2(250) path ''$.reason'',',
'    status varchar2(250) path ''$.status''',
')) t',
'LEFT OUTER JOIN',
't_vorschrift v',
'ON ',
'    t.sourceregulationid = v.vorschriftid'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'GETEX Blacklist'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(739324562914286583)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#SOURCEREGULATIONID#'
,p_detail_link_text=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_description=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="fa fa-search" aria-hidden="true"></span>',
'',
'',
'(PCK_RI.fIsAuthorized(pageId => 25,',
'                      accessMode => 100))'))
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>373368374180847821
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(739324499919286582)
,p_db_column_name=>'DATENSATZ'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Datensatz'
,p_column_type=>'CLOB'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(719008893811233102)
,p_db_column_name=>'GETEX_VORSCHRIFT_LINK'
,p_display_order=>20
,p_column_identifier=>'J'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(739324378651286581)
,p_db_column_name=>'ID'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(739324244672286580)
,p_db_column_name=>'SOURCEREGULATIONID'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Sourceregulationid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(739324162069286579)
,p_db_column_name=>'SOURCEREGULATIONNUMBER'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Source'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(739324102195286578)
,p_db_column_name=>'TARGETREGULATIONID'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Targetregulationid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(739323956124286577)
,p_db_column_name=>'TARGETREGULATIONNUMBER'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Target'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(739323890081286576)
,p_db_column_name=>'RELATIONTYPE'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Relationtype'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(739323823434286575)
,p_db_column_name=>'REASON'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Reason'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(739323709385286574)
,p_db_column_name=>'STATUS'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(728298036246845357)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3843950'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'GETEX_VORSCHRIFT_LINK:ID:SOURCEREGULATIONNUMBER:TARGETREGULATIONNUMBER:RELATIONTYPE:REASON:STATUS:'
);
wwv_flow_imp.component_end;
end;
/
