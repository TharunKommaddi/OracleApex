prompt --application/pages/page_00053
begin
--   Manifest
--     PAGE: 00053
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>53
,p_name=>'Automatismus Nicht-Relevant - Regeln'
,p_alias=>'AUTOMATISMUS-NICHT-RELEVANT-REGELN'
,p_step_title=>'Automatismus Nicht-Relevant - Regeln'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(910485956844829146)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414126953447820548)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3414151185686820583)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(3414145144550820567)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(910485398594828034)
,p_plug_name=>'Automatismus Nicht-Relevant - Regeln'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    r.REGELID,',
'    r.BEZEICHNUNG,',
'    r.BESCHREIBUNG,',
'    CASE r.AKTIV_FLAG WHEN 1 THEN ''Ja'' ELSE ''Nein'' END AS AKTIV,',
'    LISTAGG(DISTINCT t.NUMMER || '' - '' || t.BEZEICHNUNG, '', '')',
'        WITHIN GROUP (ORDER BY t.NUMMER) AS THEMEN,',
'    LISTAGG(DISTINCT f.BEZEICHNUNG, '', '')',
'        WITHIN GROUP (ORDER BY f.BEZEICHNUNG) AS AUSGESCHLOSSENE_FZG_KLASSEN,',
'    r.LETZTE_AENDERUNG_DATUM,',
'    b.VORNAME || '', '' || b.NACHNAME AS LETZTE_AENDERUNG_BENUTZERID',
'FROM T_REGEL r',
'LEFT JOIN T_REGEL_REF_THEMA      rrt ON r.REGELID = rrt.REGELID',
'LEFT JOIN T_THEMA                t   ON rrt.THEMAID = t.THEMAID',
'LEFT JOIN T_REGEL_REF_FZG_KLASSE rfk ON r.REGELID = rfk.REGELID',
'LEFT JOIN T_FAHRZEUGKLASSE       f   ON rfk.FAHRZEUGKLASSEID = f.FAHRZEUGKLASSEID',
'LEFT JOIN T_BENUTZER             b   ON r.LETZTE_AENDERUNG_BENUTZERID = b.BENUTZERID',
'GROUP BY',
'    r.REGELID,',
'    r.BEZEICHNUNG,',
'    r.BESCHREIBUNG,',
'    r.AKTIV_FLAG,',
'    r.LETZTE_AENDERUNG_DATUM,',
'    b.VORNAME,',
'    b.NACHNAME',
'ORDER BY r.REGELID'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Automatismus Nicht-Relevant - Regeln'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(910485214923828032)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.::P54_REGELID:#REGELID#'
,p_detail_link_text=>'<span class="fa fa-pencil" aria-hidden="true"></span>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>2761727100975560203
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(910485020672828031)
,p_db_column_name=>'REGELID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Regel ID'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(910484954819828030)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Regelname'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(910484884914828029)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Beschreibung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(910484257641828023)
,p_db_column_name=>'AKTIV'
,p_display_order=>40
,p_column_identifier=>'I'
,p_column_label=>'Aktiv'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(910484701972828027)
,p_db_column_name=>'THEMEN'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Themen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_help_text=>'Vorschrift muss GENAU diese Themen haben - nicht mehr, nicht weniger'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(910484569852828026)
,p_db_column_name=>'AUSGESCHLOSSENE_FZG_KLASSEN'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Ausgeschlossene Fahrzeugklassen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_help_text=>'Wenn Vorschrift eine dieser Klassen hat, greift die Regel NICHT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(910484492825828025)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(910484163850828022)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZERID'
,p_display_order=>90
,p_column_identifier=>'J'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(910472997319767486)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'27617394'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'REGELID:BEZEICHNUNG:BESCHREIBUNG:AKTIV:THEMEN:AUSGESCHLOSSENE_FZG_KLASSEN:LETZTE_AENDERUNG_DATUM:LETZTE_AENDERUNG_BENUTZERID'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(910484052175828021)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(910485398594828034)
,p_button_name=>'BTN_PRUEFE_ALLE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Alle Vorschriften pr\00FCfen')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(910483841502828019)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(910485398594828034)
,p_button_name=>'BTN_NEUE_REGEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Neue Regel anlegen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.:54:P54_REGELID:'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(910146019831306125)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(910485398594828034)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(910145626499306106)
,p_event_id=>wwv_flow_imp.id(910146019831306125)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(910485398594828034)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(910145260455304718)
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(910483841502828019)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(910144908863304717)
,p_event_id=>wwv_flow_imp.id(910145260455304718)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(910484005768828020)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Alle Vorschriften pr\00FCfen')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    PCK_RI_NICHT_RELEVANT.P_PRUEFE_ALLE_VORSCHRIFTEN;',
unistr('    -- APEX_APPLICATION.G_PRINT_SUCCESS_MESSAGE := ''Alle Vorschriften wurden erfolgreich gepr\00FCft.'';'),
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_process_success_message=>unistr('Alle Vorschriften wurden erfolgreich gepr\00FCft.')
,p_internal_uid=>2761728310130560215
);
wwv_flow_imp.component_end;
end;
/
