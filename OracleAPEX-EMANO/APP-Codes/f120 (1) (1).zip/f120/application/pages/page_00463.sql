prompt --application/pages/page_00463
begin
--   Manifest
--     PAGE: 00463
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>463
,p_name=>'Einstellungen laden/verwalten'
,p_alias=>'EINSTELLUNGEN-LADEN-VERWALTEN'
,p_page_mode=>'MODAL'
,p_step_title=>'Einstellungen laden/verwalten'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'function confirmDelete(aId,aItem,aText) {',
'    check = confirm(aText);',
'    if (check) {',
'        $(''#''+aItem).val(aId);',
'        apex.submit(''DELETE'');        ',
'    }',
'}',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Move the icon slightly to the right on hover with a smooth transition effect */',
'.filterladen {',
'    position: relative;',
'    transition: all 0.2s ease;',
'}',
'',
'.filterladen:hover {',
'    transform: translateX(3px); ',
'}',
'',
'',
'/* Cursor Pointer Style */',
'.cursor-pointer {',
'    cursor: pointer;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'600'
,p_dialog_width=>'700'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2220537301449470544)
,p_plug_name=>'Filter&VIew Profile 03.07.2025 Backup'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ''<span aria-hidden="true" class="fa fa-share-square-o filterladen" title="Load Filter Profile" FilterId="''',
'    || FILTER_VIEW_PROFILEID ||''" style="cursor: pointer;"></span>'' AS Load,',
'    FILTER_VIEW_PROFILEID AS NEW_LINK,',
'    FILTER_VIEW_PROFILEID,',
'    F.BENUTZERID,',
'    NAME,',
'    PAGE,',
'    -- apex_item.radiogroup(1, FILTER_VIEW_PROFILEID, ',
'    --                      CASE WHEN START_PROFILE = 1 THEN ',
'    --                          FILTER_VIEW_PROFILEID ',
'    --                      ELSE NULL END, ',
'    --                      p_onchange => ''$s(''''P463_SET_START_PROFILE'''',this.value)'') AS radio_start_profile,',
'    -- ''<a href="javascript:confirmDelete('' || FILTER_VIEW_PROFILEID || '',''''P463_DELETE'''',''''Do you really want to delete this entry?'''');"><span aria-hidden="true" alt="Delete entry" title="Delete entry" class="fa fa-trash-o" style="font-size:18px" />'
||'</a>'' AS DEL,',
'    -- CASE WHEN F.LETZTE_AENDERUNG_BENUTZERID IS NOT NULL THEN',
'    --     U.NACHNAME || '', '' || U.VORNAME || '' ('' || U.EMAIL || '')'' ',
'    -- ELSE',
'    --     NULL',
'    -- END AS created_by_user',
'',
'',
'    apex_item.radiogroup(',
'           p_idx => 1,',
'           p_value => FILTER_VIEW_PROFILEID, ',
'           p_selected_value => case when START_PROFILE = 1 then FILTER_VIEW_PROFILEID else null end,',
'           p_display => null,',
'           p_attributes => ''class="cursor-pointer"'',',
'           p_onblur => null,',
'           p_onchange => ''$s(''''P463_SET_START_PROFILE'''',this.value)'',',
'           p_onfocus => null,',
'           p_item_id => null,',
'           p_item_label => null',
'       ) as radio_startprofil,',
unistr('       ''<a href="javascript:confirmDelete('' || FILTER_VIEW_PROFILEID || '',''''P463_DELETE'''',''''M\00F6chten Sie diesen Filterprofileintrag l\00F6schen?'''');">'),
unistr('                <span aria-hidden="true" alt="Eintrag l\00F6schen" title="Eintrag l\00F6schen" class="fa fa-trash-o" style="font-size:18px" /></a>'' as DEL,'),
'       CASE WHEN F.LETZTE_AENDERUNG_BENUTZERID IS NOT NULL THEN',
'        U.NACHNAME || '', '' || U.VORNAME || '' ('' || U.EMAIL || '')'' ',
'    ELSE',
'        NULL',
'    END AS created_by_user,',
'',
'    F.LETZTE_AENDERUNG_DATUM AS last_modified_date,',
'    nvl2(F.LETZTE_AENDERUNG_BENUTZERID, U.nachname || '', '' || U.vorname, null) as LETZTE_AENDERUNG_BENUTZER',
'',
'',
'',
'',
'FROM T_FILTER_VIEW_PROFILE F',
'LEFT OUTER JOIN T_BENUTZER U ON F.LETZTE_AENDERUNG_BENUTZERID = U.BENUTZERID',
'WHERE F.BENUTZERID = :G_BENUTZERID',
'AND PAGE = :P463_FILTER_VIEW_PAGE',
'ORDER BY F.LETZTE_AENDERUNG_DATUM desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P463_SET_START_PROFILE'
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2220537385562470545)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>5892749701461858780
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002138723242535415)
,p_db_column_name=>'LOAD'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002138330347535415)
,p_db_column_name=>'NEW_LINK'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'New Link'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002138008359535414)
,p_db_column_name=>'FILTER_VIEW_PROFILEID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Filter View Profileid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002137600065535414)
,p_db_column_name=>'BENUTZERID'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Benutzerid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002137122707535413)
,p_db_column_name=>'NAME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('Name der Filter\00ADeinstellung')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002136724592535413)
,p_db_column_name=>'PAGE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Page'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002136342834535412)
,p_db_column_name=>'RADIO_STARTPROFIL'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Startprofil'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002135959088535412)
,p_db_column_name=>'DEL'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002135550570535411)
,p_db_column_name=>'CREATED_BY_USER'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Created By User'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002135194742535411)
,p_db_column_name=>'LAST_MODIFIED_DATE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002134718285535410)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5372285041895157889)
,p_plug_name=>'Filter&VIew Profile'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'   ''<span aria-hidden="true" class="fa fa-share-square-o filterladen" title="Load Filter Profile" FilterId="''',
'   || FILTER_VIEW_PROFILEID ||''" style="cursor: pointer;"></span>'' AS Load,',
'   FILTER_VIEW_PROFILEID AS NEW_LINK,',
'   FILTER_VIEW_PROFILEID,',
'   F.BENUTZERID,',
'   NAME,',
'   PAGE,',
'   -- Show owner information for ALL profiles in both modes',
'   OWNER_U.NACHNAME || '', '' || OWNER_U.VORNAME AS PROFILE_OWNER,',
'   ',
'   -- Show sharing status',
'   CASE ',
'       WHEN F.SHARED = 1 THEN ''Geteilt'' ',
'       ELSE ''Privat'' ',
'   END AS FREIGABE_STATUS,',
'   ',
'   -- Only allow setting start profile for own profiles',
'   CASE WHEN F.BENUTZERID = :G_BENUTZERID THEN',
'       apex_item.radiogroup(',
'              p_idx => 1,',
'              p_value => FILTER_VIEW_PROFILEID, ',
'              p_selected_value => case when START_PROFILE = 1 then FILTER_VIEW_PROFILEID else null end,',
'              p_display => null,',
'              p_attributes => ''class="cursor-pointer"'',',
'              p_onblur => null,',
'              p_onchange => ''$s(''''P463_SET_START_PROFILE'''',this.value)'',',
'              p_onfocus => null,',
'              p_item_id => null,',
'              p_item_label => null',
'          )',
'   ELSE',
'       NULL',
'   END as radio_startprofil,',
'   ',
'   -- Only show delete for own profiles',
'   CASE WHEN F.BENUTZERID = :G_BENUTZERID THEN',
unistr('       ''<a href="javascript:confirmDelete('' || FILTER_VIEW_PROFILEID || '',''''P463_DELETE'''',''''M\00F6chten Sie diesen Filterprofileintrag l\00F6schen?'''');">'),
unistr('               <span aria-hidden="true" alt="Eintrag l\00F6schen" title="Eintrag l\00F6schen" class="fa fa-trash-o" style="font-size:18px" /></a>'''),
'   ELSE',
'       NULL',
'   END as DEL,',
'   ',
'   CASE WHEN F.LETZTE_AENDERUNG_BENUTZERID IS NOT NULL THEN',
'       U.NACHNAME || '', '' || U.VORNAME || '' ('' || U.EMAIL || '')'' ',
'   ELSE',
'       NULL',
'   END AS created_by_user,',
'   ',
'   TO_CHAR(F.LETZTE_AENDERUNG_DATUM, ''DD.MM.YYYY HH24:MI'') AS last_modified_date,',
'   nvl2(F.LETZTE_AENDERUNG_BENUTZERID, U.nachname || '', '' || U.vorname, null) as LETZTE_AENDERUNG_BENUTZER',
'   ',
'FROM T_FILTER_VIEW_PROFILE F',
'LEFT OUTER JOIN T_BENUTZER U ON F.LETZTE_AENDERUNG_BENUTZERID = U.BENUTZERID',
'LEFT OUTER JOIN T_BENUTZER OWNER_U ON F.BENUTZERID = OWNER_U.BENUTZERID',
'WHERE ',
'   (',
'       -- MINE mode: Show only my profiles (both private and shared)',
'       (:P463_VIEW_MODE = ''MINE'' AND F.BENUTZERID = :G_BENUTZERID) ',
'       OR',
'       -- ALL mode: Different logic for PRI users vs regular users',
'       (:P463_VIEW_MODE = ''ALL'' AND (',
'           -- For PRI users: Show ALL profiles from ALL users',
'           (EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                    WHERE brr.benutzerid = :G_BENUTZERID ',
'                    AND brr.rolleid = 1001))',
'           OR',
'           -- For regular users: Show my profiles + other users'' SHARED profiles only',
'           (NOT EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001)',
'            AND ((F.BENUTZERID = :G_BENUTZERID) OR ',
'                 (F.BENUTZERID != :G_BENUTZERID AND F.SHARED = 1)))',
'       ))',
'   )',
'AND PAGE = :P463_FILTER_VIEW_PAGE',
'ORDER BY F.LETZTE_AENDERUNG_DATUM desc;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P463_SET_START_PROFILE,P463_VIEW_MODE'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Filter&VIew Profile'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(5384254130986635207)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>9056466446886023442
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002134025358535409)
,p_db_column_name=>'LOAD'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002133699498535408)
,p_db_column_name=>'NEW_LINK'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'New Link'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002133260782535407)
,p_db_column_name=>'FILTER_VIEW_PROFILEID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Filter View Profileid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002132824188535407)
,p_db_column_name=>'BENUTZERID'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Benutzerid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002132418465535406)
,p_db_column_name=>'NAME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('Name der Filter\00ADeinstellung')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002132019644535406)
,p_db_column_name=>'PAGE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Page'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002131698747535405)
,p_db_column_name=>'RADIO_STARTPROFIL'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Startprofil'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002131243950535405)
,p_db_column_name=>'DEL'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002130901738535404)
,p_db_column_name=>'CREATED_BY_USER'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Created By User'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002130439969535404)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002130113318535403)
,p_db_column_name=>'PROFILE_OWNER'
,p_display_order=>120
,p_column_identifier=>'O'
,p_column_label=>'Profil Besitzer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002129635311535403)
,p_db_column_name=>'LAST_MODIFIED_DATE'
,p_display_order=>130
,p_column_identifier=>'R'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1002129267609535402)
,p_db_column_name=>'FREIGABE_STATUS'
,p_display_order=>140
,p_column_identifier=>'T'
,p_column_label=>'Freigabe Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(5384282281281644636)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'26406424'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LOAD:NAME:RADIO_STARTPROFIL:DEL:PROFILE_OWNER:FREIGABE_STATUS:LETZTE_AENDERUNG_BENUTZER:LAST_MODIFIED_DATE:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5372285643081157895)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1002125838959535400)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5372285643081157895)
,p_button_name=>'Close'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Close'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-window-close-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1002125476627535399)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(5372285643081157895)
,p_button_name=>'RESET_START_PROFILE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'Reset Start Profile'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from T_FILTER_VIEW_PROFILE',
'where BENUTZERID = :G_BENUTZERID',
'and PAGE = :P463_FILTER_VIEW_PAGE',
'and START_PROFILE = 1'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1002114216539535391)
,p_branch_name=>'Go To Page 460'
,p_branch_action=>'f?p=&APP_ID.:460:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002128543884535401)
,p_name=>'P463_DELETE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(5372285041895157889)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002128153421535401)
,p_name=>'P463_SET_START_PROFILE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(5372285041895157889)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002127755081535401)
,p_name=>'P463_FILTER_VIEW_PAGE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(5372285041895157889)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002127344131535401)
,p_name=>'P463_CLICKED_FILTER_VIEW_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(5372285041895157889)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002126975971535400)
,p_name=>'P463_URL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(5372285041895157889)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002126602617535400)
,p_name=>'P463_VIEW_MODE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(5372285041895157889)
,p_item_default=>'MINE'
,p_prompt=>unistr('Ansicht w\00E4hlen')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT d, r FROM (',
'    SELECT ''Meine PRI Profile'' as d, ''MINE'' as r FROM dual',
'    UNION ALL',
'    SELECT ''Alle gespeicherten PRI Profile'' as d, ''ALL'' as r FROM dual',
')',
'ORDER BY r'))
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1002123907488535398)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1002125838959535400)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002123388798535397)
,p_event_id=>wwv_flow_imp.id(1002123907488535398)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1002122943581535396)
,p_name=>'StartProfile changed'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P463_SET_START_PROFILE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002122472749535396)
,p_event_id=>wwv_flow_imp.id(1002122943581535396)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Only allow setting start profile for own profiles',
'IF :P463_VIEW_MODE = ''MINE'' THEN',
'    UPDATE T_FILTER_VIEW_PROFILE',
'    SET START_PROFILE = CASE WHEN FILTER_VIEW_PROFILEID = :P463_SET_START_PROFILE THEN 1 ELSE 0 END',
'    WHERE BENUTZERID = :G_BENUTZERID',
'    AND PAGE = :P463_FILTER_VIEW_PAGE;',
'ELSE',
'    -- Don''t allow setting start profile for other users'' profiles',
'    NULL;',
'END IF;'))
,p_attribute_02=>'P463_SET_START_PROFILE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002121991690535396)
,p_event_id=>wwv_flow_imp.id(1002122943581535396)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1002121611833535395)
,p_name=>'Edit Dialog closed'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(5372285041895157889)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002121092582535395)
,p_event_id=>wwv_flow_imp.id(1002121611833535395)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5372285041895157889)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1002120633589535395)
,p_name=>'Click on Load filter'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.filterladen'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002120199313535395)
,p_event_id=>wwv_flow_imp.id(1002120633589535395)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'step1'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'console.log("step1: Starting filter load process");'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002119678147535394)
,p_event_id=>wwv_flow_imp.id(1002120633589535395)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'Set Clicked Filter ID'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Get the filter ID from the clicked icon',
'var filterId = $(this.triggeringElement).attr(''FilterId'');',
'console.log("Set Clicked Filter ID: " + filterId);',
'',
'// Set the page item',
'$s(''P463_CLICKED_FILTER_VIEW_ID'', filterId);',
'console.log("P463_CLICKED_FILTER_VIEW_ID set to: " + $v(''P463_CLICKED_FILTER_VIEW_ID''));'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002119144783535394)
,p_event_id=>wwv_flow_imp.id(1002120633589535395)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'step2'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'console.log("step2: Moving to URL creation");'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002118698729535394)
,p_event_id=>wwv_flow_imp.id(1002120633589535395)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_name=>'Create URL and set page items of the target page'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- BEGIN',
'--     DBMS_OUTPUT.PUT_LINE(''Creating URL and setting page items...'');',
'    ',
'--     SELECT APEX_PAGE.GET_URL (',
'--                 p_page   => :P463_FILTER_VIEW_PAGE,',
'--                 p_items  => ''P'' || :P463_FILTER_VIEW_PAGE || ''_FILTER_VIEW_PROFILE_ID'',',
'--                 p_values => :P463_CLICKED_FILTER_VIEW_ID) ',
'--     INTO :P463_URL',
'--     FROM DUAL;',
'    ',
'--     if :P463_FILTER_VIEW_PAGE = 460 then',
'--         :P460_FILTER_VIEW_PROFILE_ID := :P463_CLICKED_FILTER_VIEW_ID;',
'--         DBMS_OUTPUT.PUT_LINE(''Set P460_FILTER_VIEW_PROFILE_ID to '' || :P463_CLICKED_FILTER_VIEW_ID);',
'--     end if;',
'    ',
'--     DBMS_OUTPUT.PUT_LINE(''URL created: '' || :P463_URL);',
'-- END;',
'',
'',
'BEGIN',
'    -- Set the target page''s filter profile ID ',
'    :P460_FILTER_VIEW_PROFILE_ID := :P463_CLICKED_FILTER_VIEW_ID;',
'    ',
'    -- For debugging',
'    DBMS_OUTPUT.PUT_LINE(''Set P460_FILTER_VIEW_PROFILE_ID to '' || :P463_CLICKED_FILTER_VIEW_ID);',
'    ',
'    -- URL ',
'    :P463_URL := ''f?p='' || :APP_ID || '':460:'' || :APP_SESSION || ''::NO:RP:P460_FILTER_VIEW_PROFILE_ID:'' || :P463_CLICKED_FILTER_VIEW_ID;',
'    ',
'    DBMS_OUTPUT.PUT_LINE(''URL created: '' || :P463_URL);',
'END;'))
,p_attribute_02=>'P463_CLICKED_FILTER_VIEW_ID,P463_FILTER_VIEW_PAGE'
,p_attribute_03=>'P463_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002118169890535394)
,p_event_id=>wwv_flow_imp.id(1002120633589535395)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_name=>'step3'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log("step3: URL created: " + $v(''P463_URL''));',
'console.log("P460_FILTER_VIEW_PROFILE_ID set to: " + $v(''P460_FILTER_VIEW_PROFILE_ID''));'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002117655239535393)
,p_event_id=>wwv_flow_imp.id(1002120633589535395)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_name=>'Refers to P460'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    DBMS_OUTPUT.PUT_LINE(''Setting up page 460 items...'');',
'    ',
'    SELECT ',
'       JSON_VALUE(DATA, ''$.search_selection''),',
'       JSON_VALUE(DATA, ''$.milestone_selection''),',
'       JSON_VALUE(DATA, ''$.filter_laendergruppe''),',
'       JSON_VALUE(DATA, ''$.filter_land''),',
'       JSON_VALUE(DATA, ''$.card_countries''),',
'       JSON_VALUE(DATA, ''$.card_numbers''),',
'       name',
'    INTO ',
'       :P460_SEARCH_SELECTION,',
'       :P460_MILESTONE_SELECTION,',
'       :P460_FILTER_LAENDERGRUPPE,',
'       :P460_FILTER_LAND,',
'       :P460_SAVED_CARD_COUNTRIES,',
'       :P460_SAVED_CARD_NUMBERS,',
'       :P460_START_PROFILE',
'    FROM T_FILTER_VIEW_PROFILE',
'    WHERE FILTER_VIEW_PROFILEID = :P463_CLICKED_FILTER_VIEW_ID;',
'    ',
'    DBMS_OUTPUT.PUT_LINE(''Filter profile data retrieved and items set'');',
'',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN ',
'        DBMS_OUTPUT.PUT_LINE(''Error: No data found for the given user ID and start profile.'');',
'END;'))
,p_attribute_02=>'P463_CLICKED_FILTER_VIEW_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002117165832535393)
,p_event_id=>wwv_flow_imp.id(1002120633589535395)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_name=>'step4'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log("step4: Ready for redirect");',
'console.log("Filter profile data loaded for: " + $v(''P460_START_PROFILE''));'))
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P463_FILTER_VIEW_PAGE'
,p_client_condition_expression=>'460'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002116621868535393)
,p_event_id=>wwv_flow_imp.id(1002120633589535395)
,p_event_result=>'TRUE'
,p_action_sequence=>100
,p_execute_on_page_init=>'N'
,p_name=>'Redirect to URL'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log(''Filter laden - Attempting redirect'');',
'try {',
'    var url = $v("P463_URL");',
'    console.log("Redirecting to URL: " + url);',
'    apex.navigation.redirect(url);',
'    console.log("Redirect command executed");',
'} catch (e) {',
'    console.error("Redirect failed:", e);',
'}'))
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P463_FILTER_VIEW_PAGE'
,p_client_condition_expression=>'460'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002116144984535392)
,p_event_id=>wwv_flow_imp.id(1002120633589535395)
,p_event_result=>'TRUE'
,p_action_sequence=>110
,p_execute_on_page_init=>'N'
,p_name=>'step5'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'console.log("step5: Final step - closing dialog");'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P463_FILTER_VIEW_PAGE'
,p_client_condition_expression=>'460'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002115616622535392)
,p_event_id=>wwv_flow_imp.id(1002120633589535395)
,p_event_result=>'TRUE'
,p_action_sequence=>120
,p_execute_on_page_init=>'N'
,p_name=>'Close the Dialog Page 463'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log("Closing dialog and redirecting...");',
'try {',
'    // Close dialog first',
'    $(''.ui-dialog-content'').dialog(''close'');',
'    console.log("Dialog closed");',
'    ',
'    // Then redirect to page 460 with the filter ID',
'    var url = $v(''P463_URL'');',
'    console.log("Redirecting to: " + url);',
'    window.parent.location.href = url;',
'} catch (e) {',
'    console.error("Error in close/redirect:", e);',
'    // Fallback',
'    try {',
'        parent.apex.navigation.redirect($v(''P463_URL''));',
'    } catch (e2) {',
'        console.error("Fallback redirect also failed:", e2);',
'    }',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1002115227140535392)
,p_name=>'Change'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P463_VIEW_MODE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002114801141535392)
,p_event_id=>wwv_flow_imp.id(1002115227140535392)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5372285041895157889)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1002125018358535399)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reset start profile'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update T_FILTER_VIEW_PROFILE',
'set START_PROFILE = 0',
'where BENUTZERID = :G_BENUTZERID',
'and PAGE = :P463_FILTER_VIEW_PAGE;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1002125476627535399)
,p_internal_uid=>2670087297540852836
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1002124679727535398)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DELETE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_profile_name VARCHAR2(255);',
'    l_was_start_profile NUMBER := 0;',
'BEGIN',
'    -- Retrieve the name of the profile before deleting',
'    BEGIN',
'        SELECT NAME, START_PROFILE ',
'        INTO l_profile_name, l_was_start_profile',
'        FROM T_FILTER_VIEW_PROFILE',
'        WHERE FILTER_VIEW_PROFILEID = :P463_DELETE;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_profile_name := ''Unbekanntes Profil'';',
'    END;',
'',
'    -- Delete the profile',
'    DELETE FROM T_FILTER_VIEW_PROFILE',
'    WHERE FILTER_VIEW_PROFILEID = :P463_DELETE;',
'',
'    -- Success message with conditional text for start profile',
'    IF l_was_start_profile = 1 THEN',
'        apex_application.g_print_success_message := ',
unistr('            ''Filterprofil "'' || TRIM(l_profile_name) || ''" erfolgreich gel\00F6scht. '' ||'),
'            ''Dies war Ihr Startprofil.'';',
'    ELSE',
'        apex_application.g_print_success_message := ',
unistr('            ''Filterprofil "'' || TRIM(l_profile_name) || ''" erfolgreich gel\00F6scht.'';'),
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DELETE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>2670087636171852837
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
'',
'declare',
'    lProfileName varchar2(255);',
'begin',
'    -- Retrieve the name of the profile before deleting',
'    begin',
'        select NAME into lProfileName ',
'        from T_FILTER_VIEW_PROFILE ',
'        where FILTER_VIEW_PROFILEID = :P463_DELETE;',
'    exception',
'        when no_data_found then',
'            lProfileName := ''Unbekanntes Profil'';',
'    end;',
'',
'    -- Delete the profile',
'    delete from T_FILTER_VIEW_PROFILE',
'    where FILTER_VIEW_PROFILEID = :P463_DELETE;',
'',
'    -- Provide success message',
'    apex_application.g_print_success_message := ',
unistr('        ''Filter-Profil "'' || trim(lProfileName) || ''" erfolgreich gel\00F6scht'';'),
'',
'exception',
'    when others then',
'        -- Handle any potential errors',
'        apex_application.g_print_success_message := ',
unistr('            ''Fehler beim L\00F6schen des Filter-Profils: '' || sqlerrm;'),
'end;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1002124308969535398)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set new filters to known'
,p_process_sql_clob=>'update T_FILTER_VIEW_PROFILE set NEW = 0 where NEW= 1 and PAGE = :P463_FILTER_VIEW_PAGE and BENUTZERID = :G_BENUTZER_ID;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2670088006929852837
);
wwv_flow_imp.component_end;
end;
/
