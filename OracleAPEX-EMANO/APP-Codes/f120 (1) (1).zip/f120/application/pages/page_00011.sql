prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'300 BackuP'
,p_alias=>'300-BACKUP'
,p_step_title=>'300 BackuP'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'function redirectVorschrift(aVorschriftID) {',
'    apex.server.process(',
'        ''loadLinkVorschrift'',                           ',
'        { x01: aVorschriftID }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                javascript:window.open(pData,''_blank'');            ',
'                ',
'            },',
'            dataType: "text"                     ',
'        }',
'    );        ',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.mermaid'').on(''click'',''.node'', function() {',
'    var id = $(this).attr("id").split(''-'')[1];',
'    redirectVorschrift(id.substring(2));',
'});',
'',
'$(''#mermaidheader'').css(''height'',''0px'').css(''width'',''0px'').appendTo(''.t-Header .t-Header-branding'');',
'$(''.t-Body-main'').css(''margin-top'',''48px'');'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.mermaid {width: 1400px}',
'',
'.node {cursor: pointer}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2331924062252442949)
,p_plug_name=>'New'
,p_region_name=>'mermaidheader'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_07'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!-- Hier muss jetzt leider ein x-beliebiges Diagramm und der Aufruf von mermaid rein, weil sonst das Hauptdiagramm',
'     keine Pfeile hat. Fragt mich bitte nicht, wieso. Im Execute on Page Load stehen noch ein paar Anweisungen, ',
unistr('     die das hier verstecken, da vollst\00E4ndiges Ausblenden leider dazu f\00FChrt, das auch das Hauptdiagramm keine Pfeile'),
'     mehr hat',
'     TsTh, 30.03.2023 -->',
'<pre class="hide mermaid">',
'            graph TD ',
'            A[Client] --> B[Load Balancer] ',
'            B --> C[Server1] ',
'            B --> D[Server2]',
'    </pre>',
'',
'   ',
'',
'    <script type="module">',
'      import mermaid from ''https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.esm.min.mjs'';',
'      mermaid.initialize({ startOnLoad: true });',
'    </script>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4125724434926887041)
,p_plug_name=>'Legende'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4318073351323605474)
,p_plug_name=>'Filter'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4318073518874605475)
,p_plug_name=>'Baumansicht'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lSuchtiefe number := nvl(:P11_SUCHTIEFE,2);',
'    lStart number := :P11_VORSCHRIFTID;',
'    lUsedNodes varchar2(2000) := :P11_VORSCHRIFTID;    ',
'    lLoopIndex number := 1;',
'    lSupplementsAnzeigen number := :P11_SUPPLEMENTS;',
'',
'begin',
'',
'    htp.p(''<div class="mermaid">  flowchart LR'');',
'    ',
'    for s in (',
'        select v.vorschriftid id, pck_ri.fSanitizeForTree(vn.vorschrift_nummer_erw || '' - '' || vs.status) label, v.vorschrift_typid typ',
'        from t_vorschrift v',
'        join t_vorschrift_status vs on (v.vorschrift_statusid = vs.vorschrift_statusid)',
'        join v_vorschrift_nummer_erweitert vn on (v.vorschriftid = vn.vorschriftid)        ',
'        where v.vorschriftid = :P11_VORSCHRIFTID',
'        and ( (:P11_EXPIRED_AUS=1 and (v.VORSCHRIFT_STATUSID is null or v.VORSCHRIFT_STATUSID != 100 ) )',
'                OR :P11_EXPIRED_AUS=0 ',
'            )',
'    ) loop',
'            htp.p(''id'' || s.id ||',
'                  case s.typ when 30 then ''{'' when 20 then ''(['' else ''['' end ||          ',
'                  case s.typ when 20 then '''' end || ''"'' || s.label || ''"'' ||',
'                  case s.typ when 30 then ''}'' when 20 then ''])'' else '']'' end || chr(10));    ',
'    end loop;',
'    ',
'    ',
'    for l in 1..lSuchtiefe',
'    loop',
'        for n in (',
'            select v.vorschriftid id, pck_ri.fSanitizeForTree(vn.vorschrift_nummer_erw || '' - '' || vs.status) label, v.vorschrift_typid typ',
'            from t_vorschrift_ref_vorschrift vrv',
'            join t_vorschrift v on (vrv.nachfolger_vorschriftid = v.vorschriftid)',
'            join t_vorschrift_status vs on (v.vorschrift_statusid = vs.vorschrift_statusid)',
'            join v_vorschrift_nummer_erweitert vn on (v.vorschriftid = vn.vorschriftid)',
'            where v.vorschriftid not in (select column_value from table(apex_string.split_numbers(lUsedNodes,'':'')))',
'            and vrv.vorgaenger_vorschriftid in (select column_value from table(apex_string.split_numbers(lUsedNodes,'':''))) ',
'            and (lSupplementsAnzeigen = 10 or v.vorschrift_typid in (10, 30, 40))',
'            and vrv.beziehung_art in (select column_value from table(apex_string.split_numbers(:P11_BEZIEHUNG_ART,'':'')))',
'            and ( (:P11_EXPIRED_AUS=1 and (v.VORSCHRIFT_STATUSID is null or v.VORSCHRIFT_STATUSID != 100 ) )',
'                OR :P11_EXPIRED_AUS=0 ',
'            )',
'            union',
'            ',
'            select v.vorschriftid id, pck_ri.fSanitizeForTree(vn.vorschrift_nummer_erw || '' - '' || vs.status) label, v.vorschrift_typid typ',
'            from t_vorschrift_ref_vorschrift vrv',
'            join t_vorschrift v on (vrv.vorgaenger_vorschriftid = v.vorschriftid)',
'            join t_vorschrift_status vs on (v.vorschrift_statusid = vs.vorschrift_statusid)            ',
'            join v_vorschrift_nummer_erweitert vn on (v.vorschriftid = vn.vorschriftid)            ',
'            where v.vorschriftid not in (select column_value from table(apex_string.split_numbers(lUsedNodes,'':'')))',
'            and vrv.nachfolger_vorschriftid in (select column_value from table(apex_string.split_numbers(lUsedNodes,'':'')))',
'            and (lSupplementsAnzeigen = 10 or v.vorschrift_typid in (10, 30, 40))           ',
'            and vrv.beziehung_art in (select column_value from table(apex_string.split_numbers(:P11_BEZIEHUNG_ART,'':'')))',
'            and ( (:P11_EXPIRED_AUS=1 and (v.VORSCHRIFT_STATUSID is null or v.VORSCHRIFT_STATUSID != 100 ) )',
'                OR :P11_EXPIRED_AUS=0 ',
'            )             ',
'        ) loop',
'            htp.p(''id'' || n.id ||',
'                  case n.typ when 30 then ''{'' when 20 then ''(['' else ''['' end ||          ',
'                  case n.typ when 20 then '''' end || ''"'' || n.label || ''"'' ||',
'                  case n.typ when 30 then ''}'' when 20 then ''])'' else '']'' end || chr(10));',
'            if (l < lSuchtiefe) then',
'                lUsedNodes := lUsedNodes || '':'' || n.id;                  ',
'            end if;',
'        ',
'        end loop;',
'    ',
'    end loop;',
'    ',
'    for k in (',
'        select vrv.vorgaenger_vorschriftid von, vrv.nachfolger_vorschriftid nach, ba.beziehung_art, ba.beziehung_artid',
'        from t_vorschrift_ref_vorschrift vrv',
'        join t_vorschrift vv on (vrv.vorgaenger_vorschriftid = vv.vorschriftid)',
'        join t_vorschrift nv on (vrv.nachfolger_vorschriftid = nv.vorschriftid)',
'        join t_beziehung_art ba on (vrv.beziehung_art = ba.beziehung_artid)',
'        where (',
'            vrv.vorgaenger_vorschriftid in (select column_value from table(apex_string.split_numbers(lUsedNodes,'':'')))',
'            or vrv.nachfolger_vorschriftid in (select column_value from table(apex_string.split_numbers(lUsedNodes,'':'')))',
'        ) ',
'        and (lSupplementsAnzeigen = 10 or (nv.vorschrift_typid in (10, 30, 40)) and vv.vorschrift_typid in (10, 30, 40))',
'        and vrv.beziehung_art in (select column_value from table(apex_string.split_numbers(:P11_BEZIEHUNG_ART,'':'')))',
'        and ( (:P11_EXPIRED_AUS=1 and (vv.VORSCHRIFT_STATUSID is null or vv.VORSCHRIFT_STATUSID != 100 ) )',
'                OR :P11_EXPIRED_AUS=0 ',
'            )        ',
'    ) loop',
'        if (k.beziehung_artid = 10) then',
'            htp.p(''id'' ||  k.von || '' -- Predecessor >> Successor --> '' || ''id'' ||k.nach);',
'        elsif (k.beziehung_artid = 60) then',
'            htp.p(''id'' ||  k.nach || '' -- '' || k.beziehung_art || '' --- '' || ''id'' ||k.von);        ',
'        else',
'            htp.p(''id'' ||  k.nach || '' -- '' || k.beziehung_art || '' --> '' || ''id'' ||k.von);',
'        end if;',
'        htp.p(chr(10));      ',
'    end loop;',
'',
'    htp.p(''</div>'');',
'end;    '))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002480730056654931)
,p_name=>'P11_LEG_BILD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4125724434926887041)
,p_source=>'#APP_IMAGES#vorsch_baum_legende.png'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'alternative_text', 'Legende',
  'based_on', 'URL')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002480049305654925)
,p_name=>'P11_VORSCHRIFTID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4318073351323605474)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002479650622654924)
,p_name=>'P11_SUCHTIEFE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(4318073351323605474)
,p_prompt=>'Suchtiefe'
,p_source=>'1'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select level as d, level as r',
'from dual',
'connect by level <= 3'))
,p_cHeight=>1
,p_colspan=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'Y',
  'page_action_on_selection', 'SUBMIT')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002479267560654923)
,p_name=>'P11_SUPPLEMENTS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(4318073351323605474)
,p_prompt=>'Supplements anzeigen'
,p_source=>'20'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Nein',
  'off_value', '20',
  'on_label', 'Ja',
  'on_value', '10',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002478881187654923)
,p_name=>'P11_EXPIRED_AUS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4318073351323605474)
,p_item_default=>'1'
,p_prompt=>'Expired ausblenden'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', '1',
  'unchecked_value', '0',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1002478434144654923)
,p_name=>'P11_BEZIEHUNG_ART'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(4318073351323605474)
,p_prompt=>'Beziehungs-Arten'
,p_source=>'30:10:102:40:60:200'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select beziehung_art, beziehung_artid',
'from t_beziehung_art',
'order by 1'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1002477327175654896)
,p_name=>'refresh'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P11_SUPPLEMENTS,P11_BEZIEHUNG_ART'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002476860607654891)
,p_event_id=>wwv_flow_imp.id(1002477327175654896)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1002476510901654890)
,p_name=>'change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P11_EXPIRED_AUS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1002476002864654889)
,p_event_id=>wwv_flow_imp.id(1002476510901654890)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'submit page'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1002477764650654898)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLinkVorschrift'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lID number;',
'    lRowid rowid;',
'BEGIN',
' ',
'    lID := apex_application.g_x01;',
'    ',
'    select rowid into lRowid',
'    from t_vorschrift',
'    where vorschriftid = lID;',
'    ',
'    htp.p (apex_page.get_url(p_page => 25, p_items => ''P25_VORSCHRIFTID'', p_values => lID, p_clear_cache => 25));',
'end;    '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2669734551248733337
);
wwv_flow_imp.component_end;
end;
/
