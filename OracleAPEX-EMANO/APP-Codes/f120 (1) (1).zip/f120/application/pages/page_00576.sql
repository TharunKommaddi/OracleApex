prompt --application/pages/page_00576
begin
--   Manifest
--     PAGE: 00576
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>576
,p_name=>'JIRA Ticket Status'
,p_alias=>'JIRA-TICKET-STATUS'
,p_page_mode=>'MODAL'
,p_step_title=>'JIRA Ticket Status'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_dialog_width=>'1000'
,p_dialog_chained=>'N'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1006140896386638721)
,p_plug_name=>'Ticket Status'
,p_region_name=>'ticket-status'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12773486494129084920)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12773496596382847973)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>5
,p_location=>null
,p_list_id=>wwv_flow_imp.id(637561291400734979)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1005986497372989248)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(12773486494129084920)
,p_button_name=>'CLOSE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Schlie\00DFen')
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1005986019031989248)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(12773486494129084920)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ticket erstellen'
,p_button_position=>'NEXT'
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1005985638631989247)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(12773486494129084920)
,p_button_name=>'New'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Beenden'
,p_button_position=>'NEXT'
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1005985281846989247)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(12773486494129084920)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006141441191638727)
,p_name=>'P576_JIRA_POST_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1006140896386638721)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006141376193638726)
,p_name=>'P576_STATUS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1006140896386638721)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Ticket Status'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CASE ',
'    WHEN POST_STATUS = 0 THEN ''Ticket wird erstellt... Bitte warten.''',
'    WHEN POST_STATUS = 10 THEN ''Ticket wird verarbeitet...''',
'    WHEN POST_STATUS = 20 THEN ''Ticket erfolgreich erstellt!''',
'    WHEN POST_STATUS = 30 THEN ''Fehler beim Erstellen des Tickets''',
unistr('    ELSE ''Status wird gepr\00FCft...'''),
'END AS status_text',
'FROM T_JIRA_POST ',
'WHERE JIRA_POST_ID = :P576_JIRA_POST_ID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:margin-top-lg'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006141306328638725)
,p_name=>'P576_JIRA_KEY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1006140896386638721)
,p_use_cache_before_default=>'NO'
,p_prompt=>'JIRA Ticket Nummer'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT JIRA_KEY',
'FROM T_JIRA_POST ',
'WHERE POST_STATUS = 20 AND JIRA_POST_ID = :P576_JIRA_POST_ID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006141213369638724)
,p_name=>'P576_JIRA_LINK'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1006140896386638721)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Jira Ticket Link'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ''<a href="https://cicd.cloud.audi/jira/browse/'' || JIRA_KEY || ''" target="_blank" class="t-Button t-Button--hot t-Button--small">',
'<span class="t-Icon t-Icon--left fa fa-external-link"></span>',
unistr(''' || JIRA_KEY || '' \00F6ffnen'),
'</a>'' AS jira_link',
'FROM T_JIRA_POST ',
'WHERE POST_STATUS = 20',
'AND JIRA_KEY IS NOT NULL AND JIRA_POST_ID = :P576_JIRA_POST_ID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(946468278087772934)
,p_name=>'P576_HINWEIS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1006140896386638721)
,p_item_default=>'Falls kein Ticket in einer akzeptablen Zeit erstellt wurde, bitte kein weiteres Ticket erstellen. Gehen bitte auf den fachlichen Jira Administrator von ET-B zu.'
,p_prompt=>'Hinweis'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(914715781731462734)
,p_name=>'P576_CLONE_INFO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1006140896386638721)
,p_prompt=>'Clone Info'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P581_CLONE_SOURCE_TICKET'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(914715685721462733)
,p_computation_sequence=>10
,p_computation_item=>'P576_CLONE_INFO'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--  -- Computation for P576_CLONE_INFO',
'   BEGIN',
'       IF :P581_IS_CLONE = 1 THEN',
'           RETURN ''<div class="alert-success">'' ||',
'                  ''<h3> Ticket erfolgreich geklont!</h3>'' ||',
'                  ''<p>Quelle: <strong>'' || :P581_CLONE_SOURCE_TICKET || ''</strong></p>'' ||',
unistr('                  ''<p>Alle verf\00FCgbaren Arbeitsergebnisse wurden kopiert.</p>'' ||'),
'                  ''</div>'';',
'       ELSE',
'           RETURN NULL;',
'       END IF;',
'   END;',
'',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1006140655802638719)
,p_name=>'Auto Refresh Status'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006140546091638718)
,p_event_id=>wwv_flow_imp.id(1006140655802638719)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log(''Starting ticket status monitor...'');',
'',
'var checkCount = 0;',
'var maxChecks = 60; // Maximum 5 minutes',
'',
'// Function to check ticket status',
'function checkTicketStatus() {',
'    checkCount++;',
'    console.log(''Checking ticket status... (attempt '' + checkCount + '')'');',
'    ',
'    apex.server.process(''CHECK_TICKET_STATUS'', {',
'        pageItems: [''P576_JIRA_POST_ID'']',
'    }, {',
'        success: function(data) {',
'            console.log(''Status update:'', data);',
'            ',
'            // Update page items directly with the returned data',
'            if (data.status_text) {',
'                apex.item(''P576_STATUS'').setValue(data.status_text);',
'            }',
'            ',
'            if (data.jira_key) {',
'                apex.item(''P576_JIRA_KEY'').setValue(data.jira_key);',
'            } else {',
'                apex.item(''P576_JIRA_KEY'').setValue('''');',
'            }',
'            ',
'            if (data.jira_link) {',
'                apex.item(''P576_JIRA_LINK'').setValue(data.jira_link);',
'            } else {',
'                apex.item(''P576_JIRA_LINK'').setValue('''');',
'            }',
'            ',
'            // Show success message if ticket is created',
'            if (data.post_status === 20 && data.jira_key) {',
'                apex.message.showPageSuccess(''Ticket '' + data.jira_key + '' wurde erfolgreich erstellt!'');',
'            }',
'            ',
'            // Show error message if creation failed',
'            if (data.post_status === 30) {',
'                apex.message.showPageError(''Fehler beim Erstellen des Tickets: '' + (data.error_msg || ''Unbekannter Fehler''));',
'            }',
'            ',
'            // Stop checking if ticket is done or error occurred',
'            if (!data.continue_checking || checkCount >= maxChecks) {',
'                clearInterval(window.statusCheckInterval);',
'                console.log(''Stopped status checking. Final status:'', data.post_status);',
'            }',
'        },',
'        error: function(xhr, status, error) {',
'            console.error(''Error checking ticket status:'', error);',
'            clearInterval(window.statusCheckInterval);',
unistr('            apex.message.showPageError(''Fehler beim Pr\00FCfen des Ticket-Status'');'),
'        }',
'    });',
'}',
'',
'// Start checking immediately',
'checkTicketStatus();',
'',
'// Then check every 5 seconds',
'window.statusCheckInterval = setInterval(checkTicketStatus, 5000);',
'',
'// Clean up when page is unloaded',
'$(window).on(''beforeunload'', function() {',
'    if (window.statusCheckInterval) {',
'        clearInterval(window.statusCheckInterval);',
'    }',
'});'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3119269430247164292)
,p_event_id=>wwv_flow_imp.id(1006140655802638719)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log(''Starting ticket status monitor...'');',
'',
'var checkCount = 0;',
'var maxChecks = 60; // Maximum 5 minutes',
'',
'// Function to check ticket status',
'function checkTicketStatus() {',
'    checkCount++;',
'    console.log(''Checking ticket status... (attempt '' + checkCount + '')'');',
'    ',
'    apex.server.process(''CHECK_TICKET_STATUS'', {',
'        pageItems: [''P576_JIRA_POST_ID'']',
'    }, {',
'        success: function(data) {',
'            console.log(''Status update:'', data);',
'            ',
'            // Refresh the region to show updated status',
'            apex.region(''ticket-status'').refresh();',
'            ',
'            // Show success message if ticket is created',
'            if (data.post_status === 20 && data.jira_key) {',
'                apex.message.showPageSuccess(''Ticket '' + data.jira_key + '' wurde erfolgreich erstellt!'');',
'            }',
'            ',
'            // Show error message if creation failed',
'            if (data.post_status === 30) {',
'                apex.message.showPageError(''Fehler beim Erstellen des Tickets: '' + (data.error_msg || ''Unbekannter Fehler''));',
'            }',
'            ',
'            // Stop checking if ticket is done or error occurred',
'            if (!data.continue_checking || checkCount >= maxChecks) {',
'                clearInterval(window.statusCheckInterval);',
'                console.log(''Stopped status checking. Final status:'', data.post_status);',
'            }',
'        },',
'        error: function(xhr, status, error) {',
'            console.error(''Error checking ticket status:'', error);',
'            clearInterval(window.statusCheckInterval);',
unistr('            apex.message.showPageError(''Fehler beim Pr\00FCfen des Ticket-Status'');'),
'        }',
'    });',
'}',
'',
'// Start checking immediately',
'checkTicketStatus();',
'',
'// Then check every 5 seconds',
'window.statusCheckInterval = setInterval(checkTicketStatus, 5000);',
'',
'// Clean up when page is unloaded',
'$(window).on(''beforeunload'', function() {',
'    if (window.statusCheckInterval) {',
'        clearInterval(window.statusCheckInterval);',
'    }',
'});'))
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3119269537403164293)
,p_event_id=>wwv_flow_imp.id(1006140655802638719)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1006140504982638717)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1005986497372989248)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006140388269638716)
,p_event_id=>wwv_flow_imp.id(1006140504982638717)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1006140057896638713)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'New'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1005986497372989248)
,p_internal_uid=>2666072258002749522
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1004851327640201434)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1005986497372989248)
,p_internal_uid=>2667360988259186801
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1006140719123638720)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CHECK_TICKET_STATUS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_status NUMBER;',
'    l_jira_key VARCHAR2(100);',
'    l_error_msg CLOB;',
'    l_post_datum DATE;',
'    l_status_text VARCHAR2(500);',
'    l_jira_link VARCHAR2(1000);',
'BEGIN',
'    -- Get current status',
'    SELECT POST_STATUS, JIRA_KEY, ERROR_MSG, POST_DATUM',
'    INTO l_status, l_jira_key, l_error_msg, l_post_datum',
'    FROM T_JIRA_POST',
'    WHERE JIRA_POST_ID = TO_NUMBER(:P576_JIRA_POST_ID);',
'    ',
'    -- Generate status text',
'    CASE l_status',
'        WHEN 0 THEN l_status_text := ''Ticket wird erstellt... Bitte warten.'';',
'        WHEN 10 THEN l_status_text := ''Ticket wird verarbeitet...'';',
'        WHEN 20 THEN l_status_text := ''Ticket erfolgreich erstellt!'';',
'        WHEN 30 THEN l_status_text := ''Fehler beim Erstellen des Tickets'';',
unistr('        ELSE l_status_text := ''Status wird gepr\00FCft...'';'),
'    END CASE;',
'    ',
'    -- Generate JIRA link if status is 20 and JIRA_KEY exists',
'    IF l_status = 20 AND l_jira_key IS NOT NULL THEN',
'        l_jira_link := ''<a href="https://cicd.cloud.audi/jira/browse/'' || l_jira_key || ''" target="_blank" class="t-Button t-Button--hot t-Button--small">'' ||',
'                      ''<span class="t-Icon t-Icon--left fa fa-external-link"></span>&nbsp;'' ||',
unistr('                      l_jira_key || '' \00F6ffnen</a>'';'),
'    END IF;',
'    ',
'    -- Return JSON response',
'    apex_json.open_object;',
'    apex_json.write(''post_status'', l_status);',
'    apex_json.write(''jira_key'', l_jira_key);',
'    apex_json.write(''error_msg'', l_error_msg);',
'    apex_json.write(''post_datum'', TO_CHAR(nvl(l_post_datum, sysdate), ''DD.MM.YYYY HH24:MI:SS''));',
'    apex_json.write(''status_text'', l_status_text);',
'    apex_json.write(''jira_link'', l_jira_link);',
'    ',
'    -- Determine if we should continue checking',
'    IF l_status IN (20, 30) THEN',
'        apex_json.write(''continue_checking'', false);',
'    ELSE',
'        apex_json.write(''continue_checking'', true);',
'    END IF;',
'    ',
'    apex_json.close_object;',
'    ',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        apex_json.open_object;',
'        apex_json.write(''post_status'', -1);',
'        apex_json.write(''error'', ''Ticket nicht gefunden'');',
'        apex_json.write(''continue_checking'', false);',
'        apex_json.close_object;',
'    WHEN OTHERS THEN',
'        apex_json.open_object;',
'        apex_json.write(''post_status'', -1);',
'        apex_json.write(''error'', ''Fehler: '' || SQLERRM);',
'        apex_json.write(''continue_checking'', false);',
'        apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2666071596775749515
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3119269404522164291)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CHECK_TICKET_STATUS_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_status NUMBER;',
'    l_jira_key VARCHAR2(100);',
'    l_error_msg CLOB;',
'    l_post_datum DATE;',
'BEGIN',
'    -- Get current status',
'    SELECT POST_STATUS, JIRA_KEY, ERROR_MSG, POST_DATUM',
'    INTO l_status, l_jira_key, l_error_msg, l_post_datum',
'    FROM T_JIRA_POST',
'    WHERE JIRA_POST_ID = TO_NUMBER(:P576_JIRA_POST_ID);',
'    ',
'    -- Return JSON response',
'    apex_json.open_object;',
'    apex_json.write(''post_status'', l_status);',
'    apex_json.write(''jira_key'', l_jira_key);',
'    apex_json.write(''error_msg'', l_error_msg);',
'    apex_json.write(''post_datum'', TO_CHAR(l_post_datum, ''DD.MM.YYYY HH24:MI:SS''));',
'    ',
'    -- Determine if we should continue checking',
'    IF l_status IN (20, 30) THEN',
'        apex_json.write(''continue_checking'', false);',
'    ELSE',
'        apex_json.write(''continue_checking'', true);',
'    END IF;',
'    ',
'    apex_json.close_object;',
'    ',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        apex_json.open_object;',
'        apex_json.write(''post_status'', -1);',
'        apex_json.write(''error'', ''Ticket nicht gefunden'');',
'        apex_json.write(''continue_checking'', false);',
'        apex_json.close_object;',
'    WHEN OTHERS THEN',
'        apex_json.open_object;',
'        apex_json.write(''post_status'', -1);',
'        apex_json.write(''error'', ''Fehler: '' || SQLERRM);',
'        apex_json.write(''continue_checking'', false);',
'        apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>552942911377223944
);
wwv_flow_imp.component_end;
end;
/
