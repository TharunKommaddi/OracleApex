prompt --application/pages/page_00048
begin
--   Manifest
--     PAGE: 00048
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>48
,p_name=>'461 Backup - 18.08.2025'
,p_alias=>'461-BACKUP-18-08-2025'
,p_step_title=>'461 Backup - 18.08.2025'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Status configurations',
'const STATUS_CONFIGS = {',
'''not-started'': {',
'icon: ''<span class="fa fa-clock-o" style="font-size: 16px;"></span>'',',
unistr('title: ''Nicht begonnen - Klicken zum \00C4ndern'','),
'message: ''Nicht begonnen''',
'},',
'''in-progress'': {',
'icon: ''<span class="fa fa-spinner" style="font-size: 16px;"></span>'',',
unistr('title: ''In Bearbeitung - Klicken zum \00C4ndern'','),
'message: ''In Bearbeitung''',
'},',
'''completed'': {',
'icon: ''<span class="fa fa-check-circle" style="font-size: 16px;"></span>'',',
unistr('title: ''Bearbeitung abgeschlossen - Klicken zum \00C4ndern'','),
'message: ''Abgeschlossen''',
'}',
'};',
'',
'// Initialize status indicator',
'function initDetailPageStatus() {',
'const cardNum = $v(''P461_CARD_NUM'');',
'const status = $v(''P461_CARD_STATUS'') || ''not-started'';',
'',
'console.log(''Initializing status for card:'', cardNum, ''Status:'', status);',
'',
'// Find or create status indicator',
'let statusIndicator = document.querySelector(''.status-indicator'');',
'if (!statusIndicator) {',
'statusIndicator = document.createElement(''span'');',
'statusIndicator.className = ''status-indicator'';',
'',
'// Find download and back buttons',
'const downloadButton = document.getElementById(''DownloadExcelReport'');',
'const backButton = document.getElementById(''BACK_TO_OVERVIEW'');',
'',
'// Insert before download button',
'if (downloadButton) {',
'    const buttonContainer = downloadButton.closest(''.a-IRR-buttons'');',
'    if (buttonContainer) {',
'        ',
'        buttonContainer.insertBefore(statusIndicator, downloadButton);',
'    }',
'} else if (backButton) {',
'',
'    backButton.after(statusIndicator);',
'} else {',
'',
'    const buttonContainer = document.querySelector(''.a-IRR-buttons'');',
'    if (buttonContainer) {',
'        buttonContainer.prepend(statusIndicator);',
'    } else {',
'        document.body.prepend(statusIndicator);',
'    }',
'}',
'}',
'',
'// Update indicator',
'statusIndicator.classList.remove(''not-started'', ''in-progress'', ''completed'');',
'statusIndicator.classList.add(status);',
'statusIndicator.setAttribute(''data-card'', cardNum);',
'',
'// Set icon and title',
'const config = STATUS_CONFIGS[status];',
'statusIndicator.innerHTML = config.icon;',
'statusIndicator.title = config.title;',
'',
'statusIndicator.onclick = () => cycleDetailStatus(cardNum);',
'',
'console.log(''Status indicator initialized'');',
'}',
'',
'function cycleDetailStatus(cardNumber) {',
'const statusIndicator = document.querySelector(''.status-indicator'');',
'if (!statusIndicator) {',
'console.error(''Status indicator not found'');',
'return;',
'}',
'',
'// Determine current and next status',
'const currentStatus = ',
'statusIndicator.classList.contains(''not-started'') ? ''not-started'' : ',
'statusIndicator.classList.contains(''in-progress'') ? ''in-progress'' : ',
'''completed'';',
'',
'const statusOrder = [''not-started'', ''in-progress'', ''completed''];',
'const currentIndex = statusOrder.indexOf(currentStatus);',
'const nextStatus = statusOrder[(currentIndex + 1) % statusOrder.length];',
'',
'console.log(`Cycling status from ${currentStatus} to ${nextStatus}`);',
'',
'statusIndicator.classList.remove(''not-started'', ''in-progress'', ''completed'');',
'statusIndicator.classList.add(nextStatus);',
'',
'// Update icon and title',
'const config = STATUS_CONFIGS[nextStatus];',
'statusIndicator.innerHTML = config.icon;',
'statusIndicator.title = config.title;',
'',
'apex.item(''P461_CARD_STATUS'').setValue(nextStatus);',
'console.log(`Page item P461_CARD_STATUS set to: ${nextStatus}`);',
'',
'// Save to database',
'saveDetailStatus(cardNumber, nextStatus);',
'}',
'',
'',
'',
'function saveDetailStatus(cardNumber, status) {',
'console.log(`Saving status for card ${cardNumber}: ${status}`);',
'',
'let msgTimeout = apex.item("P461_MSG_TIMEOUT").getValue();',
'if (!msgTimeout || isNaN(msgTimeout)) {',
'    msgTimeout = 3;',
'}',
'',
'apex.server.process(',
'    ''UPDATE_CARD_STATUS'',',
'    {',
'        x01: cardNumber,',
'        x02: status,',
'        x03: $v(''P461_SEARCH_SELECTION''),',
'        x04: $v(''P461_MILESTONE_SELECTION'')',
'    },',
'    {',
'        success: function(data) {',
'            const config = STATUS_CONFIGS[status];',
'            $(''.t-Alert--success'').remove();',
'            apex.message.showPageSuccess(`Karte ${cardNumber} Status aktualisiert: ${config.message}`);',
'            ',
'            setTimeout(function() {',
'                $(''.t-Alert--success'').fadeOut(function() { $(this).remove(); });',
'            }, msgTimeout * 1000);',
'            ',
'            $s(''P461_CARD_STATUS'', status);',
'            $s(''P460_JUST_UPDATED_CARD'', cardNumber);',
'            $s(''P460_JUST_UPDATED_STATUS'', status);',
'        },',
'        error: function(xhr, status, error) {',
'            console.error(''Error updating card status:'', error);',
'            // **THIS IS THE FIX**: Changed showPageError to showErrors',
'            apex.message.showErrors([{',
'                type: "error",',
'                location: "page",',
'                message: "Fehler beim Aktualisieren des Status: " + error,',
'                unsafe: false',
'            }]);',
'        },',
'        dataType: "json" // This was missing and is CRITICAL',
'    }',
');',
'}',
'',
'',
'// Card Download Function',
'function downloadCardData(landids) {',
'if (!landids) {',
'console.error(''No landids provided for download'');',
'return;',
'}',
'',
'// Use P461_LANDIDS if no landids parameter is provided',
'if (!landids) {',
'landids = $v(''P461_LANDIDS'');',
'}',
'',
'// Check again if we have landids',
'if (!landids) {',
'console.error(''No landids available for download'');',
'apex.message.showPageError(''No country data available for download'');',
'return;',
'}',
'',
'console.log(''Initiating download with landids:'', landids);',
'',
'const url = ''wwv_flow.show'';',
'const params = {',
'p_request: ''APPLICATION_PROCESS=DOWNLOAD_CARD_DATA'',',
'p_flow_id: $v(''pFlowId''),',
'p_flow_step_id: $v(''pFlowStepId''),',
'p_instance: $v(''pInstance''),',
'x01: landids,',
'x02: $v(''P461_SEARCH_SELECTION''),',
'x03: $v(''P461_MILESTONE_SELECTION'')',
'};',
'',
'const $form = $(''<form>'', {',
'action: url,',
'method: ''POST'',',
'target: ''_blank''',
'});',
'',
'$.each(params, function (key, value) {',
'$form.append($(''<input>'', {',
'    type: ''hidden'',',
'    name: key,',
'    value: value',
'}));',
'});',
'',
'$(''body'').append($form);',
'$form.submit();',
'$form.remove();',
'console.log(''Download form submitted with landids: '' + landids);',
'}',
'',
'',
'// Sets up header truncation for page 461',
'',
'function setupPage461HeaderTruncation() {',
'console.log(''Running header truncation function'');',
'',
'// Find the title element',
'const titleElement = document.querySelector(''.t-Region-title'');',
'if (!titleElement) {',
'console.log(''Title element not found'');',
'return;',
'}',
'',
'// Check if title editing is already applied',
'if (titleElement.querySelector(''.title-container'')) {',
'console.log(''Title editing already set up, skipping truncation'');',
'return; // Exit early to avoid conflicts',
'}',
'',
'// Get title text content',
'const fullText = titleElement.textContent.trim();',
'console.log(''Title text:'', fullText);',
'',
'// Check if it contains country list (with semicolons)',
'if (fullText && fullText.includes('';'')) {',
'// Split by semicolons',
'const countries = fullText.split('';'').map(c => c.trim()).filter(c => c);',
'console.log(''Found countries:'', countries);',
'',
'const totalCount = countries.length;',
'console.log(''Total countries:'', totalCount);',
'',
'// Only truncate if more than 2 countries',
'if (totalCount > 2) {',
'console.log(''Truncating to 2 countries'');',
'',
'// Create truncated with first 2 countries',
'const truncatedText = countries.slice(0, 2).join(''; '');',
'',
'// Store the full list for later',
'titleElement.setAttribute(''data-full-list'', fullText);',
'',
'// Update HTML with show more button',
'titleElement.innerHTML = truncatedText + ',
''' <span class="show-more-btn" style="color: #bb0a31; cursor: pointer; display: inline-block; vertical-align: middle; margin-left: 5px; font-size: 13px; white-space: nowrap; margin-bottom: 5px; border: 1px solid #e0e0e0; padding: 2px 6px; border-radiu'
||'s: 3px">'' +',
unistr('''<i class="fa fa-plus-circle" style="margin-right: 4px; vertical-align: middle; position: relative; top: -1px;"></i> alle L\00E4nder anzeigen ('' + totalCount + '')'' +'),
'''</span>'';',
'',
'// click event to the show more button',
'const showMoreBtn = titleElement.querySelector(''.show-more-btn'');',
'if (showMoreBtn) {',
'showMoreBtn.onclick = function(e) {',
'e.stopPropagation();',
'e.preventDefault();',
'',
'console.log(''Show more clicked'');',
'',
'// Show full list with show less button',
'titleElement.innerHTML = fullText + ',
'    '' <span class="show-less-btn" style="color: #bb0a31; cursor: pointer; display: inline-block; vertical-align: middle; margin-left: 5px; font-size: 13px; white-space: nowrap; margin-bottom: 5px; border: 1px solid #e0e0e0; padding: 2px 6px; border-r'
||'adius: 3px">'' +',
unistr('    ''<i class="fa fa-minus-circle" style="margin-right: 4px; vertical-align: middle; position: relative; top: -1px;"></i> weniger L\00E4nder anzeigen'' +'),
'    ''</span>'';',
'',
'// click event to the show less button',
'const showLessBtn = titleElement.querySelector(''.show-less-btn'');',
'if (showLessBtn) {',
'    showLessBtn.onclick = function(e) {',
'        e.stopPropagation();',
'        e.preventDefault();',
'        ',
'        console.log(''Show less clicked'');',
'        ',
'        // Restore truncated view',
'        titleElement.innerHTML = truncatedText + ',
'            '' <span class="show-more-btn" style="color: #bb0a31; cursor: pointer; display: inline-block; vertical-align: middle; margin-left: 5px; font-size: 13px; white-space: nowrap; margin-bottom: 5px; border: 1px solid #e0e0e0; padding: 2px 6px; '
||'border-radius: 3px">'' +',
unistr('            ''<i class="fa fa-plus-circle" style="margin-right: 4px; vertical-align: middle; position: relative; top: -1px;"></i> alle L\00E4nder anzeigen ('' + totalCount + '')'' +'),
'            ''</span>'';',
'        ',
'        // Restore click handler for show more',
'        const newShowMoreBtn = titleElement.querySelector(''.show-more-btn'');',
'        if (newShowMoreBtn) {',
'            newShowMoreBtn.onclick = showMoreBtn.onclick;',
'        }',
'    };',
'}',
'};',
'}',
'}',
'}',
'}',
'',
'',
'/**',
' * Title editing for page 461',
' * This function is modified to display countries on a new line after the custom title',
' */',
'function addTitleEditingToPage461() {',
'console.log(''Setting up title editing for page 461'');',
'',
'// Find the title element',
'const titleElement = document.querySelector(''.t-Region-title'');',
'if (!titleElement) {',
'console.log(''Title element not found for editing'');',
'return;',
'}',
'',
'// Get current card number from page item',
'const cardNumber = $v(''P461_CARD_NUM'');',
'if (!cardNumber) {',
'console.log(''Card number not found in page item'');',
'return;',
'}',
'',
'// Check if setup is already done to prevent duplicate processing',
'if (titleElement.querySelector(''.title-container'')) {',
'console.log(''Title editing already set up'');',
'return;',
'}',
'',
'// Check if custom title exists from passed parameter',
'let customTitle = $v(''P461_CUSTOM_TITLE'') || '''';',
'console.log(''Retrieved custom title:'', customTitle);',
'',
'// Save full text before we modify anything',
'let originalTitle = titleElement.textContent.trim();',
'let fullText = originalTitle;',
'',
'// If header truncation has already been applied, get the full list',
'if (titleElement.hasAttribute(''data-full-list'')) {',
'fullText = titleElement.getAttribute(''data-full-list'');',
'console.log(''Retrieved full country list from truncation:'', fullText);',
'}',
'',
'// Clear the title element to prepare for the new container',
'titleElement.innerHTML = '''';',
'',
'// Create a container for the title that we can manipulate',
'const titleContainer = document.createElement(''div'');',
'titleContainer.id = ''title-container-'' + cardNumber;',
'titleContainer.className = ''title-container'';',
'titleContainer.style.display = ''flex'';',
'titleContainer.style.flexDirection = ''column''; // Changed to column layout',
'titleContainer.style.width = ''100%'';',
'',
'// Create a top row for edit icons and custom title',
'const topRow = document.createElement(''div'');',
'topRow.className = ''title-top-row'';',
'topRow.style.display = ''flex'';',
'topRow.style.alignItems = ''center'';',
'topRow.style.marginBottom = ''8px''; // Space between rows',
'topRow.style.width = ''100%''; // to take full width',
'topRow.style.justifyContent = ''flex-start''; // Align contents to the left',
'',
'// Create edit icon',
'const editIcon = document.createElement(''span'');',
'editIcon.className = ''edit-icon'';',
'editIcon.title = ''Title bearbeiten'';',
'editIcon.innerHTML = ''<span class="fa fa-edit" style="font-size: 14px; color: #666;"></span>'';',
'editIcon.onclick = function() {',
'makeEditable(cardNumber);',
'};',
'',
'// Create reset icon (only visible when custom title exists)',
'const resetIcon = document.createElement(''span'');',
'resetIcon.className = ''reset-icon'';',
unistr('resetIcon.title = ''Zur\00FCcksetzen auf Standardtitel'';'),
'resetIcon.innerHTML = ''<span class="fa fa-undo" style="font-size: 14px; color: #666;"></span>'';',
'resetIcon.onclick = function() {',
'resetTitle(cardNumber, fullText);',
'};',
'resetIcon.style.display = customTitle ? '''' : ''none'';',
'',
'// Create custom title indicator (if exists)',
'let customTitleIndicator = null;',
'if (customTitle) {',
'customTitleIndicator = document.createElement(''div'');',
'customTitleIndicator.className = ''custom-title-indicator'';',
'customTitleIndicator.textContent = customTitle;',
'customTitleIndicator.style.textAlign = ''left''; // Align text to the left',
'customTitleIndicator.style.width = ''auto''; ',
'customTitleIndicator.style.marginLeft = ''8px''; // Add some spacing after icons',
'}',
'',
'// Add icons and custom title to top row',
'topRow.appendChild(editIcon);',
'topRow.appendChild(resetIcon);',
'if (customTitleIndicator) {',
'topRow.appendChild(customTitleIndicator);',
'}',
'',
'// Create a bottom row for the country list',
'const bottomRow = document.createElement(''div'');',
'bottomRow.className = ''title-bottom-row'';',
'bottomRow.style.width = ''100%'';',
'',
'// Create a span to hold the title text (countries)',
'const titleText = document.createElement(''span'');',
'titleText.id = ''card-title-'' + cardNumber;',
'titleText.className = ''title-text'';',
'titleText.textContent = fullText;',
'titleText.setAttribute(''data-custom-title'', customTitle || '''');',
'titleText.setAttribute(''data-original-title'', fullText);',
'titleText.setAttribute(''data-full-list'', fullText);',
'',
'// Add countries list to the bottom row',
'bottomRow.appendChild(titleText);',
'',
'// add both rows to the container',
'titleContainer.appendChild(topRow);',
'titleContainer.appendChild(bottomRow);',
'',
'// Replace the original title with our new container',
'titleElement.appendChild(titleContainer);',
'',
'// After we''ve set up title editing, apply truncation',
'applyTruncationToTitleText(titleText);',
'}',
'',
'/**',
' * card title editable for page 461',
' * ',
' */',
'function makeEditable(cardNumber) {',
'const titleContainer = document.getElementById(''title-container-'' + cardNumber);',
'if (!titleContainer) {',
'console.error(''Title container not found for card '' + cardNumber);',
'return;',
'}',
'',
'const titleText = document.getElementById(''card-title-'' + cardNumber);',
'const topRow = titleContainer.querySelector(''.title-top-row'');',
'const bottomRow = titleContainer.querySelector(''.title-bottom-row'');',
'',
'if (!titleText || !topRow || !bottomRow) {',
'console.error(''Required elements not found for card '' + cardNumber);',
'return;',
'}',
'',
'// Check if we''re already in edit mode',
'if (document.getElementById(''edit-title-'' + cardNumber)) {',
'return; // Already in edit mode',
'}',
'',
'// Get the custom title',
'const customTitle = titleText.getAttribute(''data-custom-title'') || '''';',
'',
'// Hide elements in top row',
'const editIcon = titleContainer.querySelector(''.edit-icon'');',
'const resetIcon = titleContainer.querySelector(''.reset-icon'');',
'const customTitleIndicator = titleContainer.querySelector(''.custom-title-indicator'');',
'',
'if (editIcon) editIcon.style.display = ''none'';',
'if (resetIcon) resetIcon.style.display = ''none'';',
'if (customTitleIndicator) customTitleIndicator.style.display = ''none'';',
'',
'// Hide the show-more and show-less buttons if present',
'const showMoreBtn = titleText.querySelector(''.show-more-btn'');',
'const showLessBtn = titleText.querySelector(''.show-less-btn'');',
'if (showMoreBtn) showMoreBtn.style.display = ''none'';',
'if (showLessBtn) showLessBtn.style.display = ''none'';',
'',
'// Create edit controls for the top row',
'const editInput = document.createElement(''input'');',
'editInput.type = ''text'';',
'editInput.id = ''edit-title-'' + cardNumber;',
'editInput.className = ''title-edit-input'';',
'editInput.value = customTitle;',
'editInput.placeholder = ''Titel eingeben'';',
'',
'const saveButton = document.createElement(''span'');',
'saveButton.className = ''save-icon'';',
'saveButton.setAttribute(''title'', ''Speichern'');',
'saveButton.innerHTML = ''<span class="fa fa-save" style="font-size: 14px; color: #bb0a31;"></span>'';',
'saveButton.onclick = function() {',
'saveTitle(cardNumber);',
'};',
'',
'const cancelButton = document.createElement(''span'');',
'cancelButton.className = ''cancel-icon'';',
'cancelButton.setAttribute(''title'', ''Abbrechen'');',
'cancelButton.innerHTML = ''<span class="fa fa-times" style="font-size: 14px; color: #666;"></span>'';',
'cancelButton.onclick = function() {',
'cancelTitleEdit(cardNumber);',
'};',
'',
'// Insert at the beginning of the top row',
'topRow.insertBefore(cancelButton, topRow.firstChild);',
'topRow.insertBefore(saveButton, topRow.firstChild);',
'topRow.insertBefore(editInput, topRow.firstChild);',
'',
'// Add Enter key handler',
'editInput.addEventListener(''keydown'', function(e) {',
'if (e.key === ''Enter'') {',
'    saveTitle(cardNumber);',
'    e.preventDefault();',
'}',
'});',
'',
'// Focus input',
'editInput.focus();',
'}',
'',
'/**',
' * Cancel title edit mode for page 461',
' */',
'function cancelTitleEdit(cardNumber) {',
'const titleContainer = document.getElementById(''title-container-'' + cardNumber);',
'if (!titleContainer) return;',
'',
'const topRow = titleContainer.querySelector(''.title-top-row'');',
'const titleText = document.getElementById(''card-title-'' + cardNumber);',
'',
'if (!topRow || !titleText) {',
'console.error(''Required elements not found for canceling edit'');',
'return;',
'}',
'',
'// Remove the editing elements',
'const editInput = document.getElementById(''edit-title-'' + cardNumber);',
'const saveButton = topRow.querySelector(''.save-icon'');',
'const cancelButton = topRow.querySelector(''.cancel-icon'');',
'',
'if (editInput) editInput.remove();',
'if (saveButton) saveButton.remove();',
'if (cancelButton) cancelButton.remove();',
'',
'// Show the edit icon',
'const editIcon = topRow.querySelector(''.edit-icon'');',
'if (editIcon) editIcon.style.display = '''';',
'',
'// Show the reset icon if a custom title exists',
'if (titleText && titleText.getAttribute(''data-custom-title'')) {',
'const resetIcon = topRow.querySelector(''.reset-icon'');',
'if (resetIcon) resetIcon.style.display = '''';',
'}',
'',
'// Show the custom title indicator if it exists',
'const customTitleIndicator = topRow.querySelector(''.custom-title-indicator'');',
'if (customTitleIndicator) {',
'customTitleIndicator.style.display = '''';',
'}',
'',
'// Re-apply truncation if needed',
'applyTruncationToTitleText(titleText);',
'}',
'',
'/**',
' * Save the custom title for page 461',
' */',
'function saveTitle(cardNumber) {',
'const editInput = document.getElementById(''edit-title-'' + cardNumber);',
'if (!editInput) {',
'console.error(''Edit input not found for card '' + cardNumber);',
'return;',
'}',
'',
'const newTitle = editInput.value.trim();',
'const titleContainer = document.getElementById(''title-container-'' + cardNumber);',
'const titleText = document.getElementById(''card-title-'' + cardNumber);',
'const topRow = titleContainer.querySelector(''.title-top-row'');',
'',
'if (!titleContainer || !titleText || !topRow) {',
'console.error(''Required elements not found for card '' + cardNumber);',
'return;',
'}',
'',
'// Show saving indicator',
'const saveIcon = topRow.querySelector(''.save-icon .fa'');',
'if (saveIcon) {',
'saveIcon.className = ''fa fa-spinner fa-spin'';',
'}',
'',
'apex.server.process(',
'''SAVE_CARD_TITLE'',',
'{',
'    x01: cardNumber,',
'    x02: newTitle',
'},',
'{',
'    success: function(data) {',
'        // Update data attribute',
'        titleText.setAttribute(''data-custom-title'', newTitle);',
'        ',
'        // Remove editing controls',
'        const editInput = document.getElementById(''edit-title-'' + cardNumber);',
'        const saveButton = topRow.querySelector(''.save-icon'');',
'        const cancelButton = topRow.querySelector(''.cancel-icon'');',
'        ',
'        if (editInput) editInput.remove();',
'        if (saveButton) saveButton.remove();',
'        if (cancelButton) cancelButton.remove();',
'        ',
'        // Show the edit icon',
'        const editIcon = topRow.querySelector(''.edit-icon'');',
'        if (editIcon) editIcon.style.display = '''';',
'        ',
'        // Handle custom title indicator',
'        if (newTitle) {',
'            // Find or create custom title indicator',
'            let customTitleIndicator = topRow.querySelector(''.custom-title-indicator'');',
'            if (!customTitleIndicator) {',
'                customTitleIndicator = document.createElement(''div'');',
'                customTitleIndicator.className = ''custom-title-indicator'';',
'                ',
'                // Insert after edit and reset icons',
'                const resetIcon = topRow.querySelector(''.reset-icon'');',
'                if (resetIcon) {',
'                    topRow.insertBefore(customTitleIndicator, resetIcon.nextSibling);',
'                } else if (editIcon) {',
'                    topRow.insertBefore(customTitleIndicator, editIcon.nextSibling);',
'                } else {',
'                    topRow.insertBefore(customTitleIndicator, topRow.firstChild);',
'                }',
'            } else {',
'                customTitleIndicator.style.display = '''';',
'            }',
'            ',
'            // Update custom title text',
'            customTitleIndicator.textContent = newTitle;',
'            ',
'            // Show reset icon',
'            const resetIcon = topRow.querySelector(''.reset-icon'');',
'            if (resetIcon) resetIcon.style.display = '''';',
'        } else {',
'            // Remove custom title indicator if title is empty',
'            const customTitleIndicator = topRow.querySelector(''.custom-title-indicator'');',
'            if (customTitleIndicator) {',
'                customTitleIndicator.remove();',
'            }',
'            ',
'            // Hide reset icon if title is empty',
'            const resetIcon = topRow.querySelector(''.reset-icon'');',
'            if (resetIcon) resetIcon.style.display = ''none'';',
'        }',
'        ',
'        // Show success message',
'        apex.message.showPageSuccess(''Title updated successfully'');',
'        ',
'        // Update P461_CUSTOM_TITLE item for passing back to page 460',
'        apex.item(''P461_CUSTOM_TITLE'').setValue(newTitle);',
'        ',
'        // Re-apply truncation if needed',
'        applyTruncationToTitleText(titleText);',
'    },',
'    error: function(xhr, status, error) {',
'        console.error("AJAX Error:", error);',
'        console.error("Response Text:", xhr.responseText);',
'        apex.message.showPageError("Error saving title: " + error);',
'        ',
'        // Restore save icon',
'        if (saveIcon) {',
'            saveIcon.className = ''fa fa-save'';',
'        }',
'    },',
'    dataType: "json"',
'}',
');',
'}',
'',
'/**',
' * Reset the title for page 461',
' */',
'function resetTitle(cardNumber, originalTitle) {',
'const titleContainer = document.getElementById(''title-container-'' + cardNumber);',
'if (!titleContainer) {',
'console.error(''Title container not found for card '' + cardNumber);',
'return;',
'}',
'',
'const topRow = titleContainer.querySelector(''.title-top-row'');',
'',
'console.log(''Resetting title for card'', cardNumber, ''to original:'', originalTitle);',
'',
'// Show spinner on reset icon',
'const resetIcon = topRow.querySelector(''.reset-icon .fa'');',
'if (resetIcon) {',
'resetIcon.className = ''fa fa-spinner fa-spin'';',
'}',
'',
'apex.server.process(',
'''SAVE_CARD_TITLE'',',
'{',
'    x01: cardNumber,',
'    x02: '''', ',
'    x03: ''RESET'' ',
'},',
'{',
'    success: function(data) {',
'        console.log(''Reset title success for card'', cardNumber);',
'        ',
'        // Clear custom title',
'        const titleText = document.getElementById(''card-title-'' + cardNumber);',
'        if (titleText) {',
'            titleText.setAttribute(''data-custom-title'', '''');',
'            ',
'            // Reset to original title',
'            titleText.textContent = originalTitle;',
'        }',
'        ',
'        // Remove custom title indicator',
'        const customTitleIndicator = topRow.querySelector(''.custom-title-indicator'');',
'        if (customTitleIndicator) {',
'            customTitleIndicator.remove();',
'        }',
'        ',
'        // Hide reset icon',
'        const resetIcon = topRow.querySelector(''.reset-icon'');',
'        if (resetIcon) {',
'            resetIcon.style.display = ''none'';',
'        }',
'        ',
'        // Show success message',
'        apex.message.showPageSuccess(''Title reset to default'');',
'        ',
'        // Update P461_CUSTOM_TITLE item for passing back to page 460',
'        apex.item(''P461_CUSTOM_TITLE'').setValue('''');',
'        ',
'        // Re-apply the header truncation',
'        applyTruncationToTitleText(titleText);',
'    },',
'    error: function(xhr, status, error) {',
'        console.error("Reset Error:", error);',
'        console.error("Response Text:", xhr.responseText);',
'        apex.message.showPageError("Error resetting title: " + error);',
'        ',
'        // Restore reset icon',
'        if (resetIcon) {',
'            resetIcon.className = ''fa fa-undo'';',
'        }',
'    },',
'    dataType: "json"',
'}',
');',
'}',
'',
'/**',
' * Apply truncation to the title text element',
' */',
'function applyTruncationToTitleText(titleTextElement) {',
'if (!titleTextElement) return;',
'',
'// If there''s an edit input visible, don''t apply truncation',
'const cardNumber = titleTextElement.id.replace(''card-title-'', '''');',
'if (document.getElementById(''edit-title-'' + cardNumber)) {',
'return;',
'}',
'',
'// Get the text content to truncate',
'const fullText = titleTextElement.getAttribute(''data-full-list'') || titleTextElement.textContent;',
'if (!fullText || !fullText.includes('';'')) return;',
'',
'// Parse countries (preserve any newlines in the format)',
'const countries = fullText.split('';'').map(c => c.trim()).filter(c => c);',
'const totalCount = countries.length;',
'',
'// Only apply truncation if more than 2 countries',
'if (totalCount > 2) {',
'// Create truncated content',
'const truncatedText = countries.slice(0, 2).join(''; '');',
'',
'// Update with truncated content and show-more button',
'titleTextElement.innerHTML = truncatedText + ',
'    '' <span class="show-more-btn" style="color: #bb0a31; cursor: pointer; display: inline-block; vertical-align: middle; margin-left: 5px; font-size: 13px; white-space: nowrap; margin-bottom: 5px; border: 1px solid #e0e0e0; padding: 2px 6px; border-r'
||'adius: 3px">'' +',
unistr('    ''<i class="fa fa-plus-circle" style="margin-right: 4px; vertical-align: middle; position: relative; top: -1px;"></i> alle L\00E4nder anzeigen ('' + totalCount + '')'' +'),
'    ''</span>'';',
'',
'// Add click event to the show more button',
'const showMoreBtn = titleTextElement.querySelector(''.show-more-btn'');',
'if (showMoreBtn) {',
'    showMoreBtn.onclick = function(e) {',
'        e.stopPropagation();',
'        e.preventDefault();',
'        ',
'        // Show full content',
'        titleTextElement.innerHTML = fullText + ',
'            '' <span class="show-less-btn" style="color: #bb0a31; cursor: pointer; display: inline-block; vertical-align: middle; margin-left: 5px; font-size: 13px; white-space: nowrap; margin-bottom: 5px; border: 1px solid #e0e0e0; padding: 2px 6px; '
||'border-radius: 3px">'' +',
unistr('            ''<i class="fa fa-minus-circle" style="margin-right: 4px; vertical-align: middle; position: relative; top: -1px;"></i> weniger L\00E4nder anzeigen'' +'),
'            ''</span>'';',
'        ',
'        // Add click for show less',
'        const showLessBtn = titleTextElement.querySelector(''.show-less-btn'');',
'        if (showLessBtn) {',
'            showLessBtn.onclick = function(e) {',
'                e.stopPropagation();',
'                e.preventDefault();',
'                ',
'                // Back to truncated view',
'                titleTextElement.innerHTML = truncatedText + ',
'                    '' <span class="show-more-btn" style="color: #bb0a31; cursor: pointer; display: inline-block; vertical-align: middle; margin-left: 5px; font-size: 13px; white-space: nowrap; margin-bottom: 5px; border: 1px solid #e0e0e0; padding: 2'
||'px 6px; border-radius: 3px">'' +',
unistr('                    ''<i class="fa fa-plus-circle" style="margin-right: 4px; vertical-align: middle; position: relative; top: -1px;"></i> alle L\00E4nder anzeigen ('' + totalCount + '')'' +'),
'                    ''</span>'';',
'                ',
'                // Restore click handler',
'                const newShowMoreBtn = titleTextElement.querySelector(''.show-more-btn'');',
'                if (newShowMoreBtn) {',
'                    newShowMoreBtn.onclick = showMoreBtn.onclick;',
'                }',
'            };',
'        }',
'    };',
'}',
'}',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'// Delete confirmation function',
'function confirmDeleteCard(cardNumber, specificRegId) {',
'apex.message.confirm(',
unistr('    ''Soll der manuelle Eintrag gel\00F6scht werden?'','),
'    function(isOk) {',
'        if (isOk) {',
'            deleteManualEntry(cardNumber, specificRegId);',
'        }',
'    }',
');',
'}',
'',
'// Delete function',
'function deleteManualEntry(cardNumber, specificRegId) {',
'apex.server.process(',
'    ''DELETE_MANUAL_ENTRY'',',
'    {',
'        x01: cardNumber,',
'        x02: $v(''P461_SEARCH_SELECTION''),',
'        x03: $v(''P461_MILESTONE_SELECTION''),',
'        x04: specificRegId',
'    },',
'    {',
'        success: function(data) {',
'            if (data.status === ''success'') {',
unistr('                apex.message.showPageSuccess(''Eintrag erfolgreich gel\00F6scht'');'),
'                // Refresh the region',
'                apex.region(''R45756756756575'').refresh();',
'            } else {',
'                apex.message.showPageError(''Fehler: '' + data.message);',
'            }',
'        },',
'        error: function(xhr, status, error) {',
unistr('            apex.message.showPageError(''Fehler beim L\00F6schen: '' + error);'),
'        },',
'        dataType: ''json''',
'    }',
');',
'}',
'',
'',
'',
'',
'/* beginn - check Box */',
'',
unistr('// /* Erm\00F6glicht bei APEX-Checkbox-Items einen Quicklink um alle auszuw\00E4hlen */'),
'// function fSelectAll(elem) {',
'',
'//     var apexItem = $(elem).closest(''.t-Form-fieldContainer'');',
'//     var itemValue = apexItem.find(''input'').map(function() {',
'//         return this.value;',
'//     }).get().join('':'');',
'//     var itemName = apexItem.find(''label'').attr(''for'');',
'//     $s(itemName,itemValue);',
'',
'// }',
'',
'',
'// /* Click auf Checkbox in Tabellenheader: alle selektieren ',
'',
unistr('//    Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('//    f\00FCr partial page refresh definiert. */'),
'// // Checkbox handling for bulk operations',
'// $(''#R45756756756575'').on(''click'', ''th input'', function() {',
'//     var check_all = $("#R45756756756575").find("th input:checked").is(":checked");',
'',
unistr('//     // alle Zeilen ausw\00E4hlen/abw\00E4hlen'),
'//     $("#R45756756756575").find("td input").each(function() {',
'//         this.checked = check_all;',
'//     });',
'',
'//     // Button aktivieren/deaktivieren',
'//     if (check_all) {',
'//         $("#b_MB").removeClass("apex_disabled");',
'//     } else {',
'//         $("#b_MB").addClass("apex_disabled");',
'//     }',
'',
'//     $("#b_MB").prop(''disabled'', !check_all);',
'',
unistr('//     // alle ausgew\00E4hlten Zeilen-IDs in das Item P461_SELECTED_ROWS'),
'//     var sel_rows = apex.item(''P461_SELECTED_ROWS'');',
'//     sel_rows.setValue("");',
'//     $("#R45756756756575").find("td input:checked").each(function() {',
'//       if(sel_rows.getValue().length > 0) {',
'//         sel_rows.setValue(sel_rows.getValue() + ":");    ',
'//       }',
'//       sel_rows.setValue(sel_rows.getValue() + this.value);',
'//     });',
'//     apex.server.process(''MY_PROCESS'', {',
'//         pageItems: ''#P461_SELECTED_ROWS''',
'//     },{dataType: ''text''});',
'// });',
'',
'',
'',
'/* ende - check Box */',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(document).ready(function() {',
'    console.log(''Page 461 - Document ready'');',
'    ',
'    // Initialize the status indicator',
'    try {',
'        initDetailPageStatus();',
'    } catch (error) {',
'        console.error(''Error initializing status:'', error);',
'    }',
'    ',
'    if (!apex.item("P461_MSG_TIMEOUT").node) {',
'        console.log("Creating hidden P461_MSG_TIMEOUT item");',
'        ',
'        const timeoutInput = document.createElement(''input'');',
'        timeoutInput.type = ''hidden'';',
'        timeoutInput.id = ''P461_MSG_TIMEOUT'';',
'        timeoutInput.name = ''P461_MSG_TIMEOUT'';',
'        timeoutInput.value = ''3''; ',
'        ',
'        document.body.appendChild(timeoutInput);',
'    }',
'    ',
'    console.log("P461_LANDIDS value:", $v("P461_LANDIDS"));',
'    console.log("P461_LANDIDS length:", $v("P461_LANDIDS").length);',
'    console.log("Contains colons?", $v("P461_LANDIDS").includes(";"));',
'    var landIds = $v("P461_LANDIDS").split(";");',
'    console.log("Number of land IDs:", landIds.length);',
'    console.log("Land IDs array:", landIds);',
'    ',
'    // Get the card title value',
'    console.log("P461_CARD_TITLE value:", $v("P461_CARD_TITLE"));',
'    apex.server.process(',
'        "GET_CARD_TITLE",',
'        {',
'            x01: $v("P461_LANDIDS")',
'        },',
'        {',
'            success: function(data) {',
'                console.log("Query result:", data);',
'            },',
'            error: function(jqXHR, textStatus, errorThrown) {',
'                console.error("Error executing query:", textStatus, errorThrown);',
'            }',
'        }',
'    );',
'    ',
'    // Call ONLY addTitleEditingToPage461()',
'    addTitleEditingToPage461();',
'    ',
'    // Handle page refreshes',
'    $(document).on(''apexafterrefresh'', function() {',
'        console.log(''Page refreshed, running setup again'');',
'        // Call ONLY addTitleEditingToPage461() on refresh',
'        addTitleEditingToPage461();',
'    });',
'});',
'',
'',
'',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/**********************************************************',
' * Countries Header List Expand or Collapse',
' **********************************************************/',
'',
'.show-more-btn, .show-less-btn {',
'    color: #bb0a31; ',
'    cursor: pointer; ',
'    display: inline-block; ',
'    vertical-align: middle; ',
'    margin-left: 5px; ',
'    font-size: 13px; ',
'    white-space: nowrap; ',
'    margin-bottom: 5px; ',
'    border: 1px solid #e0e0e0; ',
'    padding: 2px 6px; ',
'    border-radius: 3px;',
'}',
'',
'.show-more-btn:hover, .show-less-btn:hover {',
'    color: #d01a45;',
'    background-color: #efefef;',
'    border-color: #ccc;',
'    text-decoration: underline;',
'}',
'',
'/**********************************************************',
' * Card Title Editing',
' **********************************************************/',
'',
'.title-container {',
'    display: flex;',
'    flex-wrap: wrap;',
'    align-items: center;',
'    flex-grow: 1;',
'    overflow: hidden;',
'}',
'',
'.edit-icon, .reset-icon, .save-icon, .cancel-icon {',
'    cursor: pointer;',
'    padding: 4px;',
'    margin-right: 4px;',
'    border-radius: 50%;',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    background-color: #f5f5f5;',
'    width: 24px;',
'    height: 24px;',
'    transition: all 0.2s;',
'    flex-shrink: 0;',
'}',
'',
'.edit-icon:hover, .reset-icon:hover, .save-icon:hover, .cancel-icon:hover {',
'    background-color: #e0e0e0;',
'    transform: scale(1.1);',
'}',
'',
'.custom-title-indicator {',
'    font-weight: bold;',
'    color: #2563EB;',
'    background-color: rgba(37, 99, 235, 0.08);',
'    padding: 4px 10px;',
'    margin-right: 10px;',
'    border-left: 3px solid #2563EB;',
'    border-radius: 0 4px 4px 0;',
'    font-size: 14px;',
'    flex-shrink: 0;',
'    transition: all 0.2s ease;',
'    box-shadow: 0 1px 2px rgba(37, 99, 235, 0.15);',
'    text-shadow: 0 1px 0 rgba(255, 255, 255, 0.8);',
'    letter-spacing: 0.3px;',
'}',
'',
'.custom-title-indicator:hover {',
'    background-color: rgba(37, 99, 235, 0.12);',
'    box-shadow: 0 2px 4px rgba(37, 99, 235, 0.25);',
'}',
'',
'.title-edit-input {',
'    flex-grow: 0;',
'    width: 200px;',
'    padding: 4px 8px;',
'    border: 1px solid #ccc;',
'    border-radius: 3px;',
'    margin-right: 4px;',
'    font-size: 14px;',
'}',
'',
'.title-edit-input::placeholder {',
'    font-size: 12px;',
'    color: #999;',
'}',
'',
'/**********************************************************',
' * Status Indicator Styles',
' **********************************************************/',
'',
'.status-indicator {',
'    display: inline-flex;',
'    align-items: center;',
'    justify-content: center;',
'    width: 30px; ',
'    height: 30px; ',
'    border-radius: 50%;',
'    margin-right: 10px;',
'    cursor: pointer;',
'    transition: all 0.3s ease;',
'    box-shadow: 0 2px 4px rgba(0,0,0,0.2);',
'    border: 2px solid #ddd;',
'}',
'',
'.status-indicator.not-started {',
'    background-color: #e8f5e9;',
'    border: 2px solid #c8e6c9;',
'    color: #388e3c;',
'}',
'',
'.status-indicator.in-progress {',
'    background-color: #f39c12;',
'    color: white;',
'    border: 2px solid #e67e22;',
'}',
'',
'.status-indicator.completed {',
'    background-color: #2ecc71;',
'    color: white;',
'    border: 2px solid #27ae60;',
'}',
'',
'.status-indicator:hover {',
'    transform: scale(1.1);',
'    box-shadow: 0 3px 6px rgba(0,0,0,0.3);',
'}',
'',
'',
'',
'/**********************************************************',
' * Change only the success icon to green',
' **********************************************************/',
'',
'',
'.t-Alert--success .t-Alert-icon .t-Icon {',
'    color: #2ecc71 !important;',
'}',
'',
'.t-Alert--success .t-Button--closeAlert .t-Icon {',
'    color: inherit !important; ',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'/* Disabled button styling */',
'.apex_disabled {',
'    opacity: 0.5;',
'    cursor: not-allowed !important;',
'}',
'',
'/* Checkbox column width',
'#R45756756756575 th:first-child,',
'#R45756756756575 td:first-child {',
'    width: 35px !important;',
'    min-width: 35px !important;',
'    max-width: 35px !important;',
'    text-align: center;',
'} */',
'',
'',
'',
'/***********************',
' * Checkbox and Popup Styles',
' ***********************/',
'.apex-item-single-checkbox input:checked+.u-checkbox:after, ',
'.apex-item-single-checkbox input:checked+label:after, ',
'.u-checkbox.is-checked:after {',
'    opacity: 1;',
'    background-color: #bb0a31;',
'}',
'',
'.apex-item-single-checkbox {',
'    margin-top: 13px;',
'}',
'',
'.a-PopupLOV-clearButton:hover {',
'    background-color: #bb0a31;',
'}',
'',
'',
'',
'',
'',
'/***********************',
' * MANUELLER_EINTRAG',
' ***********************/',
'',
'/* Make Entry Type column text WHITE when row is hovered */',
'/* tr:hover .manual-entry-indicator span,',
'tr:hover .auto-entry-indicator span {',
'    color: #ffffff !important;',
'} */',
'',
'/* Make Entry Type column icons WHITE when row is hovered */',
'tr:hover .manual-entry-indicator i,',
'tr:hover .auto-entry-indicator i {',
'    color: #ffffff !important;',
'}',
'',
'',
'',
'',
'',
'/***********************',
' * Delete Icons',
' ***********************/',
'',
'tr:hover .delete-icon,',
'tr:hover .fa-ban {',
'    color: #ffffff !important;',
'}',
'',
'',
'tr:hover .edit-icon,',
'tr:hover .fa-pencil {',
'    color: rgb(0, 0, 0) !important;',
'}',
'',
'',
'',
'/* Hover state - all turn white */',
'',
'tr:hover .et-ja,',
'tr:hover .et-nein,',
'tr:hover .et-nicht-bewertet,',
'tr:hover .fb-ja,',
'tr:hover .fb-nein,',
'tr:hover .fb-nicht-bewertet {',
'    color: #ffffff !important;',
'}',
'',
'tr:hover .et-ja i,',
'tr:hover .et-nein i,',
'tr:hover .fb-ja i,',
'tr:hover .fb-nein i {',
'    color: #ffffff !important;',
'}',
'',
'',
'',
'',
'/* SWITCH*/',
'',
'',
'',
'',
'',
'',
'/* SWITCH - END */',
'',
'',
'',
'',
'',
'/***********************',
' * Single Row Edit Link Icon',
' ***********************/',
'.single-edit-link .fa-external-link {',
'',
'    color: #bb0a31;',
'}',
'',
'tr:hover .single-edit-link .fa-external-link {',
'    color: #ffffff !important;',
'    ',
'}',
'',
'',
'',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'.show-more, .show-less {',
'    display: inline-block;',
'    cursor: pointer;',
'    color: #bb0a31;',
'    margin-left: 5px;',
'    margin-top: 8px !important;',
'    font-size: 13px;',
'    vertical-align: middle;',
'}',
'',
'.show-more:hover, .show-less:hover {',
'    color: #d01a45;',
'    text-decoration: underline;',
'}',
'',
'.show-more i, .show-less i {',
'    margin-right: 4px;',
'    font-size: 14px;',
'    vertical-align: middle;',
'    position: relative;',
'    top: -1px;',
'}',
'',
'.country-name {',
'    display: block;',
'    line-height: 1.5;',
'}',
'',
'',
'.fa-plus-circle-o, .fa-minus-circle-o {',
'    width: 14px;',
'    text-align: center;',
'}',
''))
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1695351323779767402)
,p_plug_name=>'&P48_CARD_TITLE.j'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>90
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH cte_lrsa AS (',
'    SELECT vrt.vorschriftid,',
'           LISTAGG(DISTINCT l.lrsa_nummer || '' - '' || l.bezeichnung, '', '') ',
'           WITHIN GROUP (ORDER BY l.bezeichnung ASC) AS lrsa',
'    FROM t_vorschrift_ref_thema vrt',
'    JOIN T_THEMA_REF_LRSA ref ON (vrt.themaid = ref.themaid)',
'    JOIN T_LRSA l ON (l.LRSA_ID = ref.LRSAID)',
'    WHERE vrt.geloescht = 0',
'    GROUP BY vrt.vorschriftid',
'),',
'',
'cte_homologationseigenschaften AS (   ',
'    SELECT vrt.vorschriftid, ',
'           REPLACE(',
'               LISTAGG(DISTINCT e.EIGENSCHAFT_KENNUNG || ''-'' || et.kuerzel || ''-'' || e.eigenschaft, '', '') ',
'               WITHIN GROUP (ORDER BY e.eigenschaft), ',
'               '', '', ',
'               ''<br>''',
'           ) AS homologationseigenschaften',
'    FROM t_vorschrift_ref_thema vrt',
'    JOIN carmah2_admin.t_eigenschaft_ref_regindexthemen err ON (vrt.themaid = err.regindex_themen_id)',
'    JOIN carmah2_admin.t_eigenschaft e ON (err.eigenschaft_id = e.eigenschaft_id)',
'    JOIN carmah2_admin.t_eigenschaft_typ et ON (e.eigenschaft_typ_id = et.eigenschaft_typ_id)',
'    WHERE vrt.geloescht = 0',
'    GROUP BY vrt.vorschriftid',
'),',
'',
'cte_nachfolger AS (',
'    SELECT vorgaenger_vorschriftid,',
'           REPLACE(',
'               LISTAGG(DISTINCT vorschrift_info, ''; '') ',
'               WITHIN GROUP (ORDER BY vorschrift_nummer), ',
'               ''; '', ',
'               ''<br>''',
'           ) || ',
'           CASE WHEN total_count > 1 THEN ''<br>...(+'' || (total_count - 1) || '' weitere)'' ELSE '''' END AS nachfolger_vorschrift',
'    FROM (',
'        SELECT vrv.vorgaenger_vorschriftid,',
'               nv.vorschrift_nummer,',
'               nv.vorschrift_nummer || '' - '' || nv.vorschrift_bezeichnung AS vorschrift_info,',
'               COUNT(*) OVER (PARTITION BY vrv.vorgaenger_vorschriftid) AS total_count,',
'               ROW_NUMBER() OVER (PARTITION BY vrv.vorgaenger_vorschriftid ORDER BY nv.vorschrift_nummer) AS rn',
'        FROM t_vorschrift_ref_vorschrift vrv',
'        JOIN t_vorschrift nv ON nv.vorschriftid = vrv.nachfolger_vorschriftid',
'        WHERE vrv.beziehung_art != 20',
'    )',
'    WHERE rn <= 1  -- Only show first successor',
'    GROUP BY vorgaenger_vorschriftid, total_count',
'),',
'',
'cte_regelnummer_kritikalitaet AS (',
'    SELECT ',
'        ms.sucheid,',
'        ms.meilenstein,',
'        ms.landid,',
'        CASE ',
'            WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'            ELSE ms.VORSCHRIFTID',
'        END as specific_vorschrift_id,',
'        LISTAGG(DISTINCT TO_CHAR(ms.regelnummer), ''; '') ',
'        WITHIN GROUP (ORDER BY ms.regelnummer) AS regelnummer_list,',
'        LISTAGG(DISTINCT ',
'            CASE ',
'                WHEN mat.KRITIKALITAET IS NOT NULL THEN TO_CHAR(mat.KRITIKALITAET)',
'                ELSE NULL ',
'            END, ''; '') ',
'        WITHIN GROUP (ORDER BY mat.KRITIKALITAET) AS kritikalitaet_von_regelnummer,',
'        LISTAGG(DISTINCT ',
'            CASE ',
'                WHEN mat.AUSGABE_TEXT IS NOT NULL THEN mat.AUSGABE_TEXT',
'                ELSE NULL ',
'            END, ''<br>'') ',
'        WITHIN GROUP (ORDER BY mat.AUSGABE_TEXT) AS ausgabe_text_von_regelnummer',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN T_MS_PARAMETER p ON ms.regelnummer = p.nummer',
'    LEFT JOIN T_MS_PARAMETER_REF_AUSGABE pra ON p.MS_PARAMETERID = pra.MS_PARAMETERID',
'    LEFT JOIN T_MS_AUSGABE_TEXT mat ON pra.MS_AUSGABE_TEXTID = mat.MS_AUSGABE_TEXTID',
'    GROUP BY ms.sucheid, ms.meilenstein, ms.landid,',
'        CASE ',
'            WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'            ELSE ms.VORSCHRIFTID',
'        END',
')',
'',
'SELECT',
'    1 as checkbox,',
'',
'    ''<a href="'' || ',
'    apex_util.prepare_url(',
'        p_url => ''f?p='' || :APP_ID || '':466:'' || :APP_SESSION || '':::466:'' ||',
'        ''P466_SEARCH_SELECTION,P466_MILESTONE_SELECTION,P466_CARD_NUM,P466_SINGLE_REG_ID:'' ||',
'        :P48_SEARCH_SELECTION || '','' || :P48_MILESTONE_SELECTION || '','' || :P48_CARD_NUM || '','' ||',
'        CASE ',
'            WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'            ELSE ms.VORSCHRIFTID',
'        END',
'    ) || ',
'    ''" title="Bewertung bearbeiten" class="single-edit-link">'' ||',
'        ''<span class="fa fa-external-link" style="font-size: 16px; color: #007bff;"></span>'' ||',
'    ''</a>'' AS ROW_EDIT_LINK,',
'',
'    split.CARD_NUMBER,',
'    ',
'    -- SPECIFIC_REG_ID',
'    CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END as SPECIFIC_REG_ID,',
'    ',
'    -- EDIT ICON',
'    CASE ',
'        WHEN MAX(ms.MANUELLER_EINTRAG) = 10 THEN',
'        ''<a href="'' || ',
'            apex_util.prepare_url(',
'                p_url => ''f?p='' || :APP_ID || '':465:'' || :APP_SESSION || '':::465:'' ||',
'                ''P465_CARD_NUM,P465_MODE,P465_SEARCH_SELECTION,P465_MILESTONE_SELECTION,P465_LANDIDS,P465_SPECIFIC_REG_ID:'' ||',
'                split.CARD_NUMBER ||'',EDIT,'' || ',
'                ms.sucheid || '','' || ',
'                ms.meilenstein || '','' || ',
'                LISTAGG(DISTINCT ms.landid, '';'') WITHIN GROUP (ORDER BY ms.landnummer) || '','' ||',
'                ms.VORSCHRIFTID',
'            ) || ',
'            ''" title="Bearbeiten (Manueller Eintrag)" class="edit-link">',
'                <span class="fa fa-pencil edit-icon" style="font-size: 16px; color: #333;"></span>',
'        </a>''',
'        ELSE',
unistr('            ''<span class="fa fa-pencil" style="color: #ccc; font-size: 16px;" title="Automatischer Eintrag - Bearbeiten nicht m\00F6glich"></span>'''),
'    END AS EDIT_ACTION,',
'',
'    -- DELETE ICON',
'    CASE ',
'        WHEN MAX(ms.MANUELLER_EINTRAG) = 10 THEN',
'            ''<a href="javascript:confirmDeleteCard('' || split.CARD_NUMBER || '', '' || ',
'            CASE ',
'                WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'                ELSE ms.VORSCHRIFTID',
unistr('            END || '')" title="Manueller Eintrag - L\00F6schen ist m\00F6glich" class="delete-link">'),
'                <span class="fa fa-trash delete-icon" style="color: #bb0a31; font-size: 16px;"></span>',
'            </a>''',
'        ELSE',
unistr('            ''<span class="fa fa-trash" style="color: #ccc; font-size: 16px;" title="Automatischer Eintrag - L\00F6schen nicht m\00F6glich"></span>'''),
'    END AS DELETE_ACTION,',
'',
'    -- MANUAL/AUTO INDICATOR',
'    CASE ',
'        WHEN MAX(ms.MANUELLER_EINTRAG) = 10 THEN',
'            ''<span class="manual-entry-indicator" title="Manueller Eintrag">',
'                <i class="fa fa-user-plus" style="color: #bb0a31; font-size: 14px; margin-right: 5px;"></i>',
'                <span>Manueller Eintrag</span>',
'            </span>''',
'        ELSE',
'            ''<span class="auto-entry-indicator" title="Automatischer Eintrag">',
'                <i class="fa fa-cog" style="color: #bb0a31; font-size: 14px; margin-right: 5px;"></i>',
'                <span>Automatischer Eintrag</span>',
'            </span>''',
'    END AS MANUELLER_EINTRAG,',
'    ',
'    -- LISTAGG FUNCTIONS',
'    LISTAGG(DISTINCT ms.landnummer, ''; '') WITHIN GROUP (ORDER BY ms.landnummer) AS B_Nummer_Liste,',
'    LISTAGG(DISTINCT ms.landid, ''; '') WITHIN GROUP (ORDER BY ms.landnummer) AS landids,',
'    LISTAGG(DISTINCT ms.landbezeichnung, ''; '') WITHIN GROUP (ORDER BY ms.landnummer) AS Land_Namen_Liste,',
'',
'    LISTAGG(DISTINCT ms.themabezeichnung, ''; '') WITHIN GROUP (ORDER BY ms.themabezeichnung) AS Themabezeichnung,',
'    ',
'    -- ms.themabezeichnung AS Themabezeichnung,',
'',
'    -- MAIN VORSCHRIFT NUMBER ',
'    CASE ',
'        WHEN NVL(tp_main.ANZEIGE_MIT_DOKUMENTENDATUM, 0) = 20 ',
'             AND tv_main.DOKUMENTENDATUM IS NOT NULL ',
'        THEN COALESCE(tv_main.vorschrift_nummer, ms.vorschriftnummer) || ''_'' || ',
'             TO_CHAR(tv_main.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'        ELSE COALESCE(tv_main.vorschrift_nummer, ms.vorschriftnummer) ',
'    END AS Vorschriftennummer,',
'',
'',
'',
'',
'    -- ALTERNATIVE VORSCHRIFT NUMBER ',
'    -- CASE ',
'    --     WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL AND tv.vorschrift_nummer IS NOT NULL THEN',
'    --         CASE ',
'    --             WHEN NVL(tp_alt.ANZEIGE_MIT_DOKUMENTENDATUM, 0) = 20 ',
'    --                  AND tv.DOKUMENTENDATUM IS NOT NULL ',
'    --             THEN tv.vorschrift_nummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'    --             ELSE tv.vorschrift_nummer ',
'    --         END',
'    --     ELSE NULL',
'    -- END AS Alternative_Vorschriftennummer,',
'',
'    LISTAGG(DISTINCT ',
'        CASE ',
'            WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL AND tv.vorschrift_nummer IS NOT NULL THEN',
'                CASE ',
'                    WHEN NVL(tp_alt.ANZEIGE_MIT_DOKUMENTENDATUM, 0) = 20 ',
'                         AND tv.DOKUMENTENDATUM IS NOT NULL ',
'                    THEN tv.vorschrift_nummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'                    ELSE tv.vorschrift_nummer ',
'                END',
'            ELSE NULL',
'        END, ''; '') ',
'    WITHIN GROUP (ORDER BY tv.vorschrift_nummer) AS Alternative_Vorschriftennummer,',
'',
'',
'',
'',
'',
'',
'    -- NVL(tv.publisher, tv_main.publisher) AS Publisher,',
'    LISTAGG(DISTINCT NVL(tv.publisher, tv_main.publisher), ''; '') ',
'    WITHIN GROUP (ORDER BY NVL(tv.publisher, tv_main.publisher)) AS Publisher,',
'',
'    -- HIDDEN COLUMNS for URL parameters ',
'    ms.sucheid AS SEARCH_ID_HIDDEN,',
'    ms.meilenstein AS MILESTONE_HIDDEN,',
'    :P48_LANDIDS AS LANDIDS_HIDDEN,',
'',
'    tv_main.rxswin as rxswin_relevant,',
'    ',
'    -- CTE COLUMNS',
'    NVL(lrsa_main.lrsa, lrsa_alt.lrsa) AS LRSA,',
'    NVL(homo_main.homologationseigenschaften, homo_alt.homologationseigenschaften) AS Homologationseigenschaft,',
'',
'    -- NACHFOLGER COLUMN',
'    NVL(nachf_main.nachfolger_vorschrift, nachf_alt.nachfolger_vorschrift) AS Nachfolger_Vorschrift,',
'',
'',
'',
'',
'    ',
'    -- REGEL_KRIT COLUMNS',
'    regel_krit.regelnummer_list AS REGELNUMMER,',
'    regel_krit.kritikalitaet_von_regelnummer AS KRITIKALITAET_VON_REGELNUMMER,',
'    regel_krit.ausgabe_text_von_regelnummer AS AUSGABE_TEXT_VON_REGELNUMMER,',
'',
'    -- BEWERTUNG COLUMNS',
'    CASE ',
'        WHEN bew.ET_VERWENDUNG = ''nicht bewertet'' THEN ''<span class="et-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>''',
'        WHEN bew.ET_VERWENDUNG = ''ja'' THEN ''<span class="et-ja" style="color: #27ae60; font-weight: bold;"><i class="fa fa-check"></i> ja</span>''',
'        WHEN bew.ET_VERWENDUNG = ''nein'' THEN ''<span class="et-nein" style="color: #e74c3c; font-weight: bold;"><i class="fa fa-times"></i> nein</span>''',
'        ELSE ''<span class="et-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>''',
'    END AS ET_VERWENDUNG,',
'    bew.ET_VORSCHLAG_VORSCHRIFT, ',
'    bew.ET_KOMMENTAR,',
'    ',
'    CASE ',
'        WHEN bew.FB_VERWENDUNG = ''nicht bewertet'' THEN ''<span class="fb-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>''',
'        WHEN bew.FB_VERWENDUNG = ''ja'' THEN ''<span class="fb-ja" style="color: #27ae60; font-weight: bold;"><i class="fa fa-check"></i> ja</span>''',
'        WHEN bew.FB_VERWENDUNG = ''nein'' THEN ''<span class="fb-nein" style="color: #e74c3c; font-weight: bold;"><i class="fa fa-times"></i> nein</span>''',
'        ELSE ''<span class="fb-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>''',
'    END AS FB_VERWENDUNG,',
'    bew.FB_VORSCHLAG_VORSCHRIFT,',
'    bew.FB_KOMMENTAR',
'',
'FROM T_MS_SUCHERGEBNISS ms',
'LEFT OUTER JOIN t_vorschrift tv ON (tv.vorschriftid = ms.alternative_vorschriftid)',
'LEFT OUTER JOIN t_vorschrift tv_main ON (tv_main.vorschriftid = ms.vorschriftid)',
'LEFT OUTER JOIN t_publisher tp_alt ON (tv.publisherid = tp_alt.publisherid)',
'LEFT OUTER JOIN t_publisher tp_main ON (tv_main.publisherid = tp_main.publisherid)',
'LEFT OUTER JOIN T_MS_SUCHE_SPLIT split ON (',
'    split.SUCHEID = ms.sucheid ',
'    AND split.MEILENSTEIN = ms.meilenstein ',
'    AND split.LANDID = ms.landid',
')',
'-- JOIN CTEs',
'LEFT OUTER JOIN cte_lrsa lrsa_main ON (lrsa_main.vorschriftid = ms.vorschriftid)',
'LEFT OUTER JOIN cte_lrsa lrsa_alt ON (lrsa_alt.vorschriftid = ms.alternative_vorschriftid)',
'LEFT OUTER JOIN cte_homologationseigenschaften homo_main ON (homo_main.vorschriftid = ms.vorschriftid)',
'LEFT OUTER JOIN cte_homologationseigenschaften homo_alt ON (homo_alt.vorschriftid = ms.alternative_vorschriftid)',
'LEFT OUTER JOIN cte_nachfolger nachf_main ON (nachf_main.vorgaenger_vorschriftid = ms.vorschriftid)',
'LEFT OUTER JOIN cte_nachfolger nachf_alt ON (nachf_alt.vorgaenger_vorschriftid = ms.alternative_vorschriftid)',
'LEFT OUTER JOIN cte_regelnummer_kritikalitaet regel_krit ON (',
'    regel_krit.sucheid = ms.sucheid ',
'    AND regel_krit.meilenstein = ms.meilenstein',
'    AND regel_krit.landid = ms.landid',
'    AND regel_krit.specific_vorschrift_id = CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END',
')',
'LEFT OUTER JOIN T_MS_BEWERTUNG bew ON (',
'    bew.SUCHEID = ms.sucheid ',
'    AND bew.MEILENSTEIN = ms.meilenstein',
'    AND bew.CARD_NUMBER = split.CARD_NUMBER',
'    AND bew.VORSCHRIFTID = CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END',
'    AND bew.BENUTZERID = :G_BENUTZERID',
')',
'',
'WHERE ms.sucheid = :P48_SEARCH_SELECTION ',
'AND ms.meilenstein = :P48_MILESTONE_SELECTION',
'AND ms.landid IN (',
'    SELECT TO_NUMBER(TRIM(column_value))',
'    FROM TABLE(apex_string.split(TRIM(:P48_LANDIDS), '';''))',
')',
'AND ms.vorschriftnummer IS NOT NULL',
'AND (',
'    :P48_PUBLISHER_FILTER IS NULL ',
'    OR ',
'    NVL(tv.publisher, tv_main.publisher) IN (',
'        SELECT TRIM(column_value) ',
'        FROM TABLE(apex_string.split(:P48_PUBLISHER_FILTER, '':''))',
'    )',
')',
'AND split.CARD_NUMBER = :P48_CARD_NUM',
'',
'GROUP BY ',
'    split.CARD_NUMBER,',
'    split.BENUTZERID,',
'    ms.ALTERNATIVE_VORSCHRIFTID,',
'    ms.VORSCHRIFTID,',
'    -- ms.themabezeichnung,',
'    ms.vorschriftnummer,',
'    tv.vorschrift_nummer,',
'    tv_main.vorschrift_nummer,',
'    tv.publisher,',
'    tv_main.publisher,',
'    tv_main.rxswin,',
'    ms.sucheid,',
'    ms.meilenstein,',
'    tp_alt.ANZEIGE_MIT_DOKUMENTENDATUM,',
'    tp_main.ANZEIGE_MIT_DOKUMENTENDATUM,',
'    tv.DOKUMENTENDATUM,',
'    tv_main.DOKUMENTENDATUM,',
'    -- CTE columns',
'    lrsa_main.lrsa,',
'    lrsa_alt.lrsa,',
'    homo_main.homologationseigenschaften,',
'    homo_alt.homologationseigenschaften,',
'    nachf_main.nachfolger_vorschrift,',
'    nachf_alt.nachfolger_vorschrift,',
'    ',
'    -- REGEL_KRIT columns',
'    regel_krit.regelnummer_list,',
'    regel_krit.kritikalitaet_von_regelnummer,',
'    regel_krit.ausgabe_text_von_regelnummer,',
'    -- BEWERTUNG columns',
'    bew.ET_VERWENDUNG,',
'    bew.ET_VORSCHLAG_VORSCHRIFT,',
'    bew.ET_KOMMENTAR,',
'    bew.FB_VERWENDUNG,',
'    bew.FB_VORSCHLAG_VORSCHRIFT,',
'    bew.FB_KOMMENTAR',
'',
'ORDER BY ',
'    MAX(ms.MANUELLER_EINTRAG) DESC,',
'    B_Nummer_Liste,',
'    Themabezeichnung,',
'    Vorschriftennummer;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P48_LANDIDS,P48_SEARCH_SELECTION,P48_MILESTONE_SELECTION,P48_PUBLISHER_FILTER'
,p_plug_display_condition_type=>'NEVER'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'&P461_CARD_TITLE.j'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    ms.landnummer||'' - ''||ms.landbezeichnung AS Land,',
'    ms.vorschriftnummer as Vorschriftennummer,',
'    ms.vorschrifttitel as Vorschrifttitel,',
'    ms.status_vorschrift as Status,',
unistr('    ms.prognose_qualitaet as Prognose_Qualit\00E4t,'),
'    ms.sw_relevant as SW_Relevant,',
'    ms.risiko as Risiko',
'FROM T_MS_SUCHERGEBNISS ms',
'WHERE ms.sucheid = :P461_SEARCH_SELECTION ',
'AND ms.meilenstein = :P461_MILESTONE_SELECTION',
'AND ms.landid IN (',
'    SELECT TO_NUMBER(column_value)',
'    FROM TABLE(apex_string.split(:P461_LANDIDS, '':''))',
')',
'AND ms.vorschriftnummer IS NOT NULL',
'ORDER BY ',
'    Land,',
'    Vorschriftennummer'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1695351362542767403)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>5367563678442155638
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985722841737712479)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'<input type="checkbox" id="selectUnselectAll" title="Select/UnselectAll" value="all" />'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_column_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'html exp ',
'',
'<input type="checkbox" value="#SPECIFIC_REG_ID#" />'))
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985722423490712478)
,p_db_column_name=>'CARD_NUMBER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Card Number'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985722035936712477)
,p_db_column_name=>'B_NUMMER_LISTE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'B Nummer Liste'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985721642551712477)
,p_db_column_name=>'LAND_NAMEN_LISTE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Land Namen Liste'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985721222601712476)
,p_db_column_name=>'THEMABEZEICHNUNG'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Themabezeichnung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985720858860712476)
,p_db_column_name=>'VORSCHRIFTENNUMMER'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985720449570712475)
,p_db_column_name=>'ALTERNATIVE_VORSCHRIFTENNUMMER'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Alternative Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985720098286712474)
,p_db_column_name=>'PUBLISHER'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Publisher'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985719691841712474)
,p_db_column_name=>'SPECIFIC_REG_ID'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Specific Reg Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985719250177712473)
,p_db_column_name=>'LANDIDS'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Landids'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985718899539712472)
,p_db_column_name=>'LRSA'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'LRSA'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985718439616712472)
,p_db_column_name=>'HOMOLOGATIONSEIGENSCHAFT'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Homologationseigenschaft'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985718037955712471)
,p_db_column_name=>'ROW_EDIT_LINK'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Row Edit Link'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985717669342712471)
,p_db_column_name=>'EDIT_ACTION'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Edit Action'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985717257263712470)
,p_db_column_name=>'DELETE_ACTION'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Delete Action'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985716889325712470)
,p_db_column_name=>'MANUELLER_EINTRAG'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Manueller Eintrag'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985716495625712469)
,p_db_column_name=>'SEARCH_ID_HIDDEN'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Search Id Hidden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985716062708712469)
,p_db_column_name=>'MILESTONE_HIDDEN'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Milestone Hidden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985715685358712468)
,p_db_column_name=>'LANDIDS_HIDDEN'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Landids Hidden'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985715313538712468)
,p_db_column_name=>'RXSWIN_RELEVANT'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Rxswin Relevant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985714848864712467)
,p_db_column_name=>'NACHFOLGER_VORSCHRIFT'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Nachfolger Vorschrift'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985714505482712466)
,p_db_column_name=>'REGELNUMMER'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Regelnummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985714041420712466)
,p_db_column_name=>'KRITIKALITAET_VON_REGELNUMMER'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Kritikalitaet Von Regelnummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985713756328712465)
,p_db_column_name=>'AUSGABE_TEXT_VON_REGELNUMMER'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Ausgabe Text Von Regelnummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985713358642712463)
,p_db_column_name=>'ET_VERWENDUNG'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Et Verwendung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985712990228712463)
,p_db_column_name=>'ET_VORSCHLAG_VORSCHRIFT'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Et Vorschlag Vorschrift'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985712552139712462)
,p_db_column_name=>'ET_KOMMENTAR'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Et Kommentar'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985712189915712462)
,p_db_column_name=>'FB_VERWENDUNG'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Fb Verwendung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985711720182712461)
,p_db_column_name=>'FB_VORSCHLAG_VORSCHRIFT'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Fb Vorschlag Vorschrift'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985711357740712460)
,p_db_column_name=>'FB_KOMMENTAR'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Fb Kommentar'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1695354490057767434)
,p_plug_name=>'&P48_CARD_TITLE.j'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>100
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH cte_lrsa AS (',
'    SELECT vrt.vorschriftid,',
'           LISTAGG(l.lrsa_nummer || '' - '' || l.bezeichnung, '', '') ',
'           WITHIN GROUP (ORDER BY l.bezeichnung ASC) AS lrsa',
'    FROM t_vorschrift_ref_thema vrt',
'    JOIN T_THEMA_REF_LRSA ref ON (vrt.themaid = ref.themaid)',
'    JOIN T_LRSA l ON (l.LRSA_ID = ref.LRSAID)',
'    WHERE vrt.geloescht = 0',
'    GROUP BY vrt.vorschriftid',
'),',
'-- cte_homologationseigenschaften AS (   ',
'--     SELECT vrt.vorschriftid, ',
'--            LISTAGG(e.EIGENSCHAFT_KENNUNG || ''-'' || et.kuerzel || ''-'' || e.eigenschaft, '', '') ',
'--            WITHIN GROUP (ORDER BY e.eigenschaft) AS homologationseigenschaften',
'--     FROM t_vorschrift_ref_thema vrt',
'--     JOIN carmah2_admin.t_eigenschaft_ref_regindexthemen err ON (vrt.themaid = err.regindex_themen_id)',
'--     JOIN carmah2_admin.t_eigenschaft e ON (err.eigenschaft_id = e.eigenschaft_id)',
'--     JOIN carmah2_admin.t_eigenschaft_typ et ON (e.eigenschaft_typ_id = et.eigenschaft_typ_id)',
'--     WHERE vrt.geloescht = 0',
'--     GROUP BY vrt.vorschriftid',
'-- ),',
'',
'cte_homologationseigenschaften AS (   ',
'    SELECT vrt.vorschriftid, ',
'           -- Replace commas with HTML line breaks',
'           REPLACE(',
'               LISTAGG(e.EIGENSCHAFT_KENNUNG || ''-'' || et.kuerzel || ''-'' || e.eigenschaft, '', '') ',
'               WITHIN GROUP (ORDER BY e.eigenschaft), ',
'               '', '', ',
'               ''<br>''',
'           ) AS homologationseigenschaften',
'    FROM t_vorschrift_ref_thema vrt',
'    JOIN carmah2_admin.t_eigenschaft_ref_regindexthemen err ON (vrt.themaid = err.regindex_themen_id)',
'    JOIN carmah2_admin.t_eigenschaft e ON (err.eigenschaft_id = e.eigenschaft_id)',
'    JOIN carmah2_admin.t_eigenschaft_typ et ON (e.eigenschaft_typ_id = et.eigenschaft_typ_id)',
'    WHERE vrt.geloescht = 0',
'    GROUP BY vrt.vorschriftid',
'),',
'',
'cte_regelnummer_kritikalitaet AS (',
'    SELECT ',
'        ms.sucheid,',
'        ms.meilenstein,',
'        ms.landid,',
'        CASE ',
'            WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'            ELSE ms.VORSCHRIFTID',
'        END as specific_vorschrift_id,',
'        LISTAGG(DISTINCT TO_CHAR(ms.regelnummer), ''; '') ',
'        WITHIN GROUP (ORDER BY ms.regelnummer) AS regelnummer_list,',
'        LISTAGG(DISTINCT ',
'            CASE ',
'                WHEN mat.KRITIKALITAET IS NOT NULL THEN TO_CHAR(mat.KRITIKALITAET)',
'                ELSE NULL ',
'            END, ''; '') ',
'        WITHIN GROUP (ORDER BY mat.KRITIKALITAET) AS kritikalitaet_von_regelnummer,',
'        -- ADD THIS: AUSGABE_TEXT aggregation',
'        LISTAGG(DISTINCT ',
'            CASE ',
'                WHEN mat.AUSGABE_TEXT IS NOT NULL THEN mat.AUSGABE_TEXT',
'                ELSE NULL ',
'            END, ''<br>'') ',
'        WITHIN GROUP (ORDER BY mat.AUSGABE_TEXT) AS ausgabe_text_von_regelnummer',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN T_MS_PARAMETER p ON ms.regelnummer = p.nummer',
'    LEFT JOIN T_MS_PARAMETER_REF_AUSGABE pra ON p.MS_PARAMETERID = pra.MS_PARAMETERID',
'    LEFT JOIN T_MS_AUSGABE_TEXT mat ON pra.MS_AUSGABE_TEXTID = mat.MS_AUSGABE_TEXTID',
'    GROUP BY ms.sucheid, ms.meilenstein, ms.landid,',
'        CASE ',
'            WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'            ELSE ms.VORSCHRIFTID',
'        END',
')',
'',
'',
'-- cte_kritikalitaet AS (',
'--     SELECT ms.sucheid,',
'--            ms.meilenstein,',
'--            LISTAGG(DISTINCT mat.KRITIKALITAET, ''; '') ',
'--            WITHIN GROUP (ORDER BY mat.KRITIKALITAET) AS kritikalitaet_text',
'--     FROM T_MS_SUCHERGEBNISS ms',
'--     LEFT JOIN T_MS_AUSGABE_TEXT mat ON (mat.MS_AUSGABE_TEXTID = ms.sucheid)',
'--     GROUP BY ms.sucheid, ms.meilenstein',
'-- )',
'',
'',
'',
'-- cte_nachfolger AS (',
'--     SELECT vrv.vorgaenger_vorschriftid,',
'--            LISTAGG(nv.vorschrift_nummer || '' - '' || nv.vorschrift_bezeichnung, ''; '') ',
'--            WITHIN GROUP (ORDER BY nv.vorschrift_nummer) AS nachfolger_vorschrift',
'--     FROM t_vorschrift_ref_vorschrift vrv',
'--     JOIN t_vorschrift nv ON nv.vorschriftid = vrv.nachfolger_vorschriftid',
'--     WHERE vrv.beziehung_art != 20  -- Exclude Amendments',
'--     GROUP BY vrv.vorgaenger_vorschriftid',
'-- )',
'',
'/*',
'cte_nachfolger AS (',
'    SELECT vrv.vorgaenger_vorschriftid,',
'           -- Replace semicolons with HTML line breaks',
'           REPLACE(',
'               LISTAGG(nv.vorschrift_nummer || '' - '' || nv.vorschrift_bezeichnung, ''; '') ',
'               WITHIN GROUP (ORDER BY nv.vorschrift_nummer), ',
'               ''; '', ',
'               ''<br>''',
'           ) AS nachfolger_vorschrift',
'    FROM t_vorschrift_ref_vorschrift vrv',
'    JOIN t_vorschrift nv ON nv.vorschriftid = vrv.nachfolger_vorschriftid',
'    WHERE vrv.beziehung_art != 20  -- Exclude Amendments',
'    GROUP BY vrv.vorgaenger_vorschriftid',
')',
'',
'*/',
'',
'',
'-- cte_themabezeichnung AS (',
'--     SELECT ',
'--         ms.sucheid,',
'--         ms.meilenstein,',
'--         ms.landid,  -- Add landid to group properly',
'--         CASE ',
'--             WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'--             ELSE ms.VORSCHRIFTID',
'--         END as vorschrift_id,',
'--         -- Replace commas with HTML line breaks for multiple themes',
'--         REPLACE(',
'--             LISTAGG(DISTINCT ms.themabezeichnung, '', '') ',
'--             WITHIN GROUP (ORDER BY ms.themabezeichnung), ',
'--             '', '', ',
'--             ''<br>''',
'--         ) AS themabezeichnung_combined',
'--     FROM T_MS_SUCHERGEBNISS ms',
'--     WHERE ms.vorschriftnummer IS NOT NULL  -- Keep only this basic filter',
'--     GROUP BY ',
'--         ms.sucheid,',
'--         ms.meilenstein,',
'--         ms.landid,  -- Add landid to group',
'--         CASE ',
'--             WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'--             ELSE ms.VORSCHRIFTID',
'--         END',
'-- )',
'',
'',
'-- cte_themabezeichnung AS (',
'--     SELECT ',
'--         ms.sucheid,',
'--         ms.meilenstein,',
'--         CASE ',
'--             WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'--             ELSE ms.VORSCHRIFTID',
'--         END as vorschrift_id,',
'--         CASE ',
'--             WHEN COUNT(DISTINCT ms.themabezeichnung) = 1 THEN MAX(ms.themabezeichnung)',
'--             ELSE COUNT(DISTINCT ms.themabezeichnung) || '' verschiedene Themen''',
'--         END AS themabezeichnung_combined',
'--     FROM T_MS_SUCHERGEBNISS ms',
'--     GROUP BY ',
'--         ms.sucheid,',
'--         ms.meilenstein,',
'--         CASE ',
'--             WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'--             ELSE ms.VORSCHRIFTID',
'--         END',
'-- )',
'',
'',
'',
'',
'SELECT',
'',
'    1 as checkbox,',
'',
'    ''<a href="'' || ',
'    apex_util.prepare_url(',
'        p_url => ''f?p='' || :APP_ID || '':466:'' || :APP_SESSION || '':::466:'' ||',
'        ''P466_SEARCH_SELECTION,P466_MILESTONE_SELECTION,P466_CARD_NUM,P466_SINGLE_REG_ID:'' ||',
'        :P48_SEARCH_SELECTION || '','' || :P48_MILESTONE_SELECTION || '','' || :P48_CARD_NUM || '','' ||',
'        CASE ',
'            WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'            ELSE ms.VORSCHRIFTID',
'        END',
'    ) || ',
'    ''" title="Bewertung bearbeiten" class="single-edit-link">'' ||',
'        ''<span class="fa fa-external-link" style="font-size: 16px; color: #007bff;"></span>'' ||',
'    ''</a>'' AS ROW_EDIT_LINK,',
'',
'',
'    ',
'    split.CARD_NUMBER,',
'    ',
'    -- SPECIFIC_REG_ID calculation',
'    CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END as SPECIFIC_REG_ID,',
'    ',
'    -- EDIT ICON - Gray disabled pencil',
'    CASE ',
'        WHEN MAX(ms.MANUELLER_EINTRAG) = 10 THEN',
'            -- Editable pencil for manual entries',
'        ''<a href="'' || ',
'            apex_util.prepare_url(',
'                p_url => ''f?p='' || :APP_ID || '':465:'' || :APP_SESSION || '':::465:'' ||',
'                ''P465_CARD_NUM,P465_MODE,P465_SEARCH_SELECTION,P465_MILESTONE_SELECTION,P465_LANDIDS,P465_SPECIFIC_REG_ID:'' ||',
'                split.CARD_NUMBER ||'',EDIT,'' || ',
'                ms.sucheid || '','' || ',
'                ms.meilenstein || '','' || ',
'                LISTAGG(DISTINCT ms.landid, '';'') WITHIN GROUP (ORDER BY ms.landnummer) || '','' ||',
'                -- CASE ',
'                --     WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'                --     ELSE ms.VORSCHRIFTID',
'                -- END',
'',
'                ',
'                     ms.VORSCHRIFTID',
'              ',
'            ) || ',
'            ''" title="Bearbeiten (Manueller Eintrag)" class="edit-link">',
'                <span class="fa fa-pencil edit-icon" style="font-size: 16px; color: #333;"></span>',
'        </a>''',
'        ELSE',
'            -- Gray disabled pencil',
unistr('            ''<span class="fa fa-pencil" style="color: #ccc; font-size: 16px;" title="Automatischer Eintrag - Bearbeiten nicht m\00F6glich"></span>'''),
'    END AS EDIT_ACTION,',
'',
'    -- DELETE ICON - Gray disabled trash',
'    CASE ',
'        WHEN MAX(ms.MANUELLER_EINTRAG) = 10 THEN',
'            ''<a href="javascript:confirmDeleteCard('' || split.CARD_NUMBER || '', '' || ',
'            CASE ',
'                WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'                ELSE ms.VORSCHRIFTID',
unistr('            END || '')" title="Manueller Eintrag - L\00F6schen ist m\00F6glich" class="delete-link">'),
'                <span class="fa fa-trash delete-icon" style="color: #bb0a31; font-size: 16px;"></span>',
'            </a>''',
'        ELSE',
unistr('            ''<span class="fa fa-trash" style="color: #ccc; font-size: 16px;" title="Automatischer Eintrag - L\00F6schen nicht m\00F6glich"></span>'''),
'    END AS DELETE_ACTION,',
'',
'    -- MANUAL/AUTO INDICATOR',
'    CASE ',
'        WHEN MAX(ms.MANUELLER_EINTRAG) = 10 THEN',
'            ''<span class="manual-entry-indicator" title="Manueller Eintrag">',
'                <i class="fa fa-user-plus" style="color: #bb0a31; font-size: 14px; margin-right: 5px;"></i>',
'                <span>Manueller Eintrag</span>',
'            </span>''',
'        ELSE',
'            ''<span class="auto-entry-indicator" title="Automatischer Eintrag">',
'                <i class="fa fa-cog" style="color: #bb0a31; font-size: 14px; margin-right: 5px;"></i>',
'                <span>Automatischer Eintrag</span>',
'            </span>''',
'    END AS MANUELLER_EINTRAG,',
'    ',
'    -- DATA COLUMNS',
'    LISTAGG(DISTINCT ms.landnummer, ''; '') WITHIN GROUP (ORDER BY ms.landnummer) AS B_Nummer_Liste,',
'    LISTAGG(DISTINCT ms.landid, ''; '') WITHIN GROUP (ORDER BY ms.landnummer) AS landids,',
'    LISTAGG(DISTINCT ms.landbezeichnung, ''; '') WITHIN GROUP (ORDER BY ms.landnummer) AS Land_Namen_Liste,',
'    ms.themabezeichnung AS Themabezeichnung,',
'    -- NVL(thema.themabezeichnung_combined, ms.themabezeichnung) AS Themabezeichnung,',
'    -- thema.themabezeichnung_combined AS Themabezeichnung,',
'    -- LISTAGG(DISTINCT ms.themabezeichnung, ''; '') WITHIN GROUP (ORDER BY ms.themabezeichnung) AS Themabezeichnung,',
'--     CASE ',
'--     WHEN COUNT(DISTINCT ms.themabezeichnung) = 1 THEN MAX(ms.themabezeichnung)',
'--     ELSE COUNT(DISTINCT ms.themabezeichnung) || '' verschiedene Themen''',
'-- END AS Themabezeichnung,',
'    -- ms.vorschriftnummer AS Vorschriftennummer,',
'',
'    CASE ',
'        WHEN NVL(tp_alt.ANZEIGE_MIT_DOKUMENTENDATUM, tp_main.ANZEIGE_MIT_DOKUMENTENDATUM) = 20 ',
'             AND NVL(tv.DOKUMENTENDATUM, tv_main.DOKUMENTENDATUM) IS NOT NULL ',
'        THEN NVL(tv.vorschrift_nummer, ms.vorschriftnummer) || ''_'' || ',
'             TO_CHAR(NVL(tv.DOKUMENTENDATUM, tv_main.DOKUMENTENDATUM), ''DD.MM.YYYY'')',
'        ELSE NVL(tv.vorschrift_nummer, ms.vorschriftnummer) ',
'    END AS Vorschriftennummer,',
'',
'    nvl(tv.vorschrift_nummer, '''') AS Alternative_Vorschriftennummer,',
'    -- tv.publisher AS Publisher,',
'',
'    NVL(tv.publisher, tv_main.publisher) AS Publisher,',
'',
'    -- HIDDEN COLUMNS for URL parameters ',
'    ms.sucheid AS SEARCH_ID_HIDDEN,',
'    ms.meilenstein AS MILESTONE_HIDDEN,',
'    :P48_LANDIDS AS LANDIDS_HIDDEN,',
'',
'    -- NEW COLUMNS',
'    tv_main.rxswin as rxswin_relevant,',
'',
'    -- NEW COLUMNS FROM CTEs',
'    -- 1. LRSA',
'    NVL(lrsa_main.lrsa, lrsa_alt.lrsa) AS LRSA,',
'    ',
'    -- 2. Homologationseigenschaft  ',
'    NVL(homo_main.homologationseigenschaften, homo_alt.homologationseigenschaften) AS Homologationseigenschaft,',
'    ',
'    -- 3. Nachfolger Vorschrift',
'    -- NVL(nachf_main.nachfolger_vorschrift, nachf_alt.nachfolger_vorschrift) AS Nachfolger_Vorschrift,',
'    ',
unistr('    -- 4. Text der Kritikalit\00E4t'),
'    -- krit.kritikalitaet_text AS Text_Kritikalitaet,',
'',
'  ',
'    regel_krit.regelnummer_list AS REGELNUMMER,',
'    regel_krit.kritikalitaet_von_regelnummer AS KRITIKALITAET_VON_REGELNUMMER,',
'    regel_krit.ausgabe_text_von_regelnummer AS AUSGABE_TEXT_VON_REGELNUMMER,',
'',
'',
'',
'',
'   ',
'    CASE ',
'    WHEN bew.ET_VERWENDUNG = ''nicht bewertet'' THEN ''<span class="et-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>''',
'    WHEN bew.ET_VERWENDUNG = ''ja'' THEN ''<span class="et-ja" style="color: #27ae60; font-weight: bold;"><i class="fa fa-check"></i> ja</span>''',
'    WHEN bew.ET_VERWENDUNG = ''nein'' THEN ''<span class="et-nein" style="color: #e74c3c; font-weight: bold;"><i class="fa fa-times"></i> nein</span>''',
'    ELSE ''<span class="et-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>''',
'END AS ET_VERWENDUNG,',
'    bew.ET_VORSCHLAG_VORSCHRIFT, ',
'    bew.ET_KOMMENTAR,',
'    ',
'CASE ',
'    WHEN bew.FB_VERWENDUNG = ''nicht bewertet'' THEN ''<span class="fb-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>''',
'    WHEN bew.FB_VERWENDUNG = ''ja'' THEN ''<span class="fb-ja" style="color: #27ae60; font-weight: bold;"><i class="fa fa-check"></i> ja</span>''',
'    WHEN bew.FB_VERWENDUNG = ''nein'' THEN ''<span class="fb-nein" style="color: #e74c3c; font-weight: bold;"><i class="fa fa-times"></i> nein</span>''',
'    ELSE ''<span class="fb-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>''',
'END AS FB_VERWENDUNG,',
'    bew.FB_VORSCHLAG_VORSCHRIFT,',
'    bew.FB_KOMMENTAR',
'',
'   ',
'',
'',
'FROM T_MS_SUCHERGEBNISS ms',
'LEFT OUTER JOIN t_vorschrift tv ON (tv.vorschriftid = ms.alternative_vorschriftid)',
'LEFT OUTER JOIN t_vorschrift tv_main ON (tv_main.vorschriftid = ms.vorschriftid)',
'LEFT OUTER JOIN t_publisher tp_alt ON (tv.publisherid = tp_alt.publisherid)',
'LEFT OUTER JOIN t_publisher tp_main ON (tv_main.publisherid = tp_main.publisherid)',
'LEFT OUTER JOIN T_MS_SUCHE_SPLIT split ON (',
'    split.SUCHEID = ms.sucheid ',
'    AND split.MEILENSTEIN = ms.meilenstein ',
'    AND split.LANDID = ms.landid',
')',
'-- JOIN CTEs',
'LEFT OUTER JOIN cte_lrsa lrsa_main ON (lrsa_main.vorschriftid = ms.vorschriftid)',
'LEFT OUTER JOIN cte_lrsa lrsa_alt ON (lrsa_alt.vorschriftid = ms.alternative_vorschriftid)',
'LEFT OUTER JOIN cte_homologationseigenschaften homo_main ON (homo_main.vorschriftid = ms.vorschriftid)',
'LEFT OUTER JOIN cte_homologationseigenschaften homo_alt ON (homo_alt.vorschriftid = ms.alternative_vorschriftid)',
'-- LEFT OUTER JOIN cte_nachfolger nachf_main ON (nachf_main.vorgaenger_vorschriftid = ms.vorschriftid)',
'-- LEFT OUTER JOIN cte_nachfolger nachf_alt ON (nachf_alt.vorgaenger_vorschriftid = ms.alternative_vorschriftid)',
'-- LEFT OUTER JOIN cte_kritikalitaet krit ON (krit.sucheid = ms.sucheid AND krit.meilenstein = ms.meilenstein)',
'LEFT OUTER JOIN cte_regelnummer_kritikalitaet regel_krit ON (',
'    regel_krit.sucheid = ms.sucheid ',
'    AND regel_krit.meilenstein = ms.meilenstein',
'    AND regel_krit.landid = ms.landid',
'    AND regel_krit.specific_vorschrift_id = CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END',
')',
'',
'LEFT OUTER JOIN T_MS_BEWERTUNG bew ON (',
'    bew.SUCHEID = ms.sucheid ',
'    AND bew.MEILENSTEIN = ms.meilenstein',
'    AND bew.CARD_NUMBER = split.CARD_NUMBER',
'    AND bew.VORSCHRIFTID = CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END',
'    AND bew.BENUTZERID = :G_BENUTZERID',
')',
'',
'-- LEFT OUTER JOIN cte_themabezeichnung thema ON (',
'--     thema.sucheid = ms.sucheid ',
'--     AND thema.meilenstein = ms.meilenstein ',
'--     AND thema.landid = ms.landid  -- Add this line',
'--     AND thema.vorschrift_id = CASE ',
'--         WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'--         ELSE ms.VORSCHRIFTID',
'--     END',
'-- )',
'-- LEFT OUTER JOIN cte_themabezeichnung thema ON (',
'--     thema.sucheid = ms.sucheid ',
'--     AND thema.meilenstein = ms.meilenstein ',
'--     AND thema.vorschrift_id = CASE ',
'--         WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'--         ELSE ms.VORSCHRIFTID',
'--     END',
'-- )',
'',
'WHERE ms.sucheid = :P48_SEARCH_SELECTION ',
'AND ms.meilenstein = :P48_MILESTONE_SELECTION',
'AND ms.landid IN (',
'    SELECT TO_NUMBER(TRIM(column_value))',
'    FROM TABLE(apex_string.split(TRIM(:P48_LANDIDS), '';''))',
')',
'AND ms.vorschriftnummer IS NOT NULL',
'',
'',
'',
'-- AND (',
'--     :P48_PUBLISHER_FILTER IS NULL ',
'--     OR ',
'--     EXISTS (',
'--         SELECT 1 ',
'--         FROM t_vorschrift tv_check',
'--         WHERE tv_check.vorschriftid = ms.alternative_vorschriftid',
'--         AND tv_check.publisher IN (',
'--             SELECT TRIM(column_value) ',
'--             FROM TABLE(apex_string.split(:P48_PUBLISHER_FILTER, '':''))',
'--         )',
'--     )',
'--     OR',
'--     NOT EXISTS (',
'--         SELECT 1 ',
'--         FROM t_vorschrift tv_check',
'--         WHERE tv_check.publisher IN (',
'--             SELECT TRIM(column_value) ',
'--             FROM TABLE(apex_string.split(:P48_PUBLISHER_FILTER, '':''))',
'--         )',
'--     )',
'-- )',
'',
'AND (',
'    :P48_PUBLISHER_FILTER IS NULL ',
'    OR ',
'    NVL(tv.publisher, tv_main.publisher) IN (',
'        SELECT TRIM(column_value) ',
'        FROM TABLE(apex_string.split(:P48_PUBLISHER_FILTER, '':''))',
'    )',
')',
'AND split.CARD_NUMBER = :P48_CARD_NUM',
'GROUP BY ',
'    split.CARD_NUMBER, ',
'    split.BENUTZERID,',
'    CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END,',
'    ms.themabezeichnung,',
'    -- NVL(thema.themabezeichnung_combined, ms.themabezeichnung),',
'    -- thema.themabezeichnung_combined,',
'    ms.vorschriftnummer,',
'    tv.vorschrift_nummer,',
'    tv.publisher,',
'    tv_main.publisher,',
'    ms.VORSCHRIFTID,',
'    ms.sucheid,',
'    ms.meilenstein,',
'    tv_main.rxswin,',
'    -- CTE columns to GROUP BY',
'    NVL(lrsa_main.lrsa, lrsa_alt.lrsa),',
'    NVL(homo_main.homologationseigenschaften, homo_alt.homologationseigenschaften),',
'    -- NVL(nachf_main.nachfolger_vorschrift, nachf_alt.nachfolger_vorschrift),',
'    -- krit.kritikalitaet_text,',
'    regel_krit.regelnummer_list,',
'    regel_krit.kritikalitaet_von_regelnummer,',
'    regel_krit.ausgabe_text_von_regelnummer,',
'    bew.ET_VERWENDUNG,',
'    bew.ET_VORSCHLAG_VORSCHRIFT, ',
'    bew.ET_KOMMENTAR,',
'    bew.FB_VERWENDUNG,',
'    bew.FB_VORSCHLAG_VORSCHRIFT,',
'    bew.FB_KOMMENTAR,',
'    tp_alt.ANZEIGE_MIT_DOKUMENTENDATUM,',
'    tp_main.ANZEIGE_MIT_DOKUMENTENDATUM,',
'    tv.DOKUMENTENDATUM,',
'    tv_main.DOKUMENTENDATUM',
'ORDER BY ',
'    MAX(ms.MANUELLER_EINTRAG) DESC,',
'    B_Nummer_Liste,',
'    Themabezeichnung,',
'    Vorschriftennummer;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P48_LANDIDS,P48_SEARCH_SELECTION,P48_MILESTONE_SELECTION,P48_PUBLISHER_FILTER'
,p_plug_display_condition_type=>'NEVER'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'&P461_CARD_TITLE.j'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    ms.landnummer||'' - ''||ms.landbezeichnung AS Land,',
'    ms.vorschriftnummer as Vorschriftennummer,',
'    ms.vorschrifttitel as Vorschrifttitel,',
'    ms.status_vorschrift as Status,',
unistr('    ms.prognose_qualitaet as Prognose_Qualit\00E4t,'),
'    ms.sw_relevant as SW_Relevant,',
'    ms.risiko as Risiko',
'FROM T_MS_SUCHERGEBNISS ms',
'WHERE ms.sucheid = :P461_SEARCH_SELECTION ',
'AND ms.meilenstein = :P461_MILESTONE_SELECTION',
'AND ms.landid IN (',
'    SELECT TO_NUMBER(column_value)',
'    FROM TABLE(apex_string.split(:P461_LANDIDS, '':''))',
')',
'AND ms.vorschriftnummer IS NOT NULL',
'ORDER BY ',
'    Land,',
'    Vorschriftennummer'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1695354546974767435)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>5367566862874155670
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985734758351712503)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'<input type="checkbox" id="selectUnselectAll" title="Select/UnselectAll" value="all" />'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_column_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'html exp ',
'',
'<input type="checkbox" value="#SPECIFIC_REG_ID#" />'))
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985734393896712502)
,p_db_column_name=>'ROW_EDIT_LINK'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985733971215712501)
,p_db_column_name=>'EDIT_ACTION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985733558829712500)
,p_db_column_name=>'CARD_NUMBER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Card Number'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985733165520712500)
,p_db_column_name=>'B_NUMMER_LISTE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'B Nummer Liste'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985732726079712499)
,p_db_column_name=>'LAND_NAMEN_LISTE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Land Namen Liste'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985732329500712498)
,p_db_column_name=>'THEMABEZEICHNUNG'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Themabezeichnung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985731980360712497)
,p_db_column_name=>'VORSCHRIFTENNUMMER'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985731546283712497)
,p_db_column_name=>'ALTERNATIVE_VORSCHRIFTENNUMMER'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Alternative Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985731144564712496)
,p_db_column_name=>'PUBLISHER'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Publisher'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985730734416712495)
,p_db_column_name=>'MANUELLER_EINTRAG'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Eintrag Typ'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P48_BEWERTUNG_ANSICHT = ''ET'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985730343393712494)
,p_db_column_name=>'DELETE_ACTION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985729929962712493)
,p_db_column_name=>'SPECIFIC_REG_ID'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Specific Reg Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985729575628712493)
,p_db_column_name=>'SEARCH_ID_HIDDEN'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Search Id Hidden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985729178868712492)
,p_db_column_name=>'MILESTONE_HIDDEN'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Milestone Hidden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985728749772712492)
,p_db_column_name=>'LANDIDS_HIDDEN'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Landids Hidden'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985728399956712491)
,p_db_column_name=>'LANDIDS'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Landids'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985728013385712490)
,p_db_column_name=>'RXSWIN_RELEVANT'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'potentiell SUMS-Relevant'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(958135905312245351)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985727561073712489)
,p_db_column_name=>'LRSA'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'LRSA'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985727144966712489)
,p_db_column_name=>'HOMOLOGATIONSEIGENSCHAFT'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Homologationseigenschaft'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985726802489712488)
,p_db_column_name=>'ET_KOMMENTAR'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'ET Kommentar'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P48_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985726402426712487)
,p_db_column_name=>'ET_VERWENDUNG'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'ET Verwendung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P48_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985725942952712487)
,p_db_column_name=>'ET_VORSCHLAG_VORSCHRIFT'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'ET Vorschlag Vorschrift'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P48_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985725591454712486)
,p_db_column_name=>'FB_KOMMENTAR'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'FB Kommentar'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P48_BEWERTUNG_ANSICHT IN (''FB'', ''ET'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985725177789712485)
,p_db_column_name=>'FB_VERWENDUNG'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'FB Verwendung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P48_BEWERTUNG_ANSICHT IN (''FB'', ''ET'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985724720935712484)
,p_db_column_name=>'FB_VORSCHLAG_VORSCHRIFT'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'FB Vorschlag Vorschrift'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P48_BEWERTUNG_ANSICHT IN (''FB'', ''ET'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985724386541712484)
,p_db_column_name=>'REGELNUMMER'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Regelnummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985723954343712483)
,p_db_column_name=>'KRITIKALITAET_VON_REGELNUMMER'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Kritikalitaet Von Regelnummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985723536382712482)
,p_db_column_name=>'AUSGABE_TEXT_VON_REGELNUMMER'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Ausgabe Text Von Regelnummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4916838317560314738)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>140
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'-- 1 as checkbox,',
'''Publisher Nation oder Alt'' as auswahl,',
'   listagg(distinct  ms.landbezeichnung , '', '') within group(order by ms.landnummer) AS Land,',
'   listagg(distinct  ms.landnummer , '', '') within group(order by ms.landnummer) AS Landnummer,',
'    ms.themabezeichnung AS Themabezeichnung,',
'    ms.vorschriftnummer AS Vorschriftennummer,',
'   ''UN-R 123/4, UN-R 123/3'' /*nvl(tv.vorschrift_nummer, '''') */ AS Alternative_Vorschriftennummer,',
'    listagg(distinct ms.regelnummer , '', '') within group(order by ms.landnummer) AS regelnummer,',
'    listagg(distinct tmat.ausgabe_text , '', '' ON OVERFLOW TRUNCATE ) within group(order by ms.landnummer)  as regeltext,',
'    -- ms.vorschrifttitel AS Vorschrifttitel,',
'    -- ms.status_vorschrift AS Status,',
unistr('    -- ms.prognose_qualitaet AS Prognose_Qualit\00E4t,'),
'    -- ms.sw_relevant AS SW_Relevant,',
'    -- ms.risiko AS Risiko,',
'    tv.publisher AS Publisher',
'FROM T_MS_SUCHERGEBNISS ms',
'LEFT OUTER JOIN t_vorschrift tv ON (tv.vorschriftid = ms.alternative_vorschriftid)',
' left outer join t_ms_parameter tmp on (ms.regelnummer = tmp.nummer)',
'  left outer join t_ms_parameter_ref_ausgabe tmpra on (tmp.MS_PARAMETERID = tmpra.MS_PARAMETERID)',
'  left outer join t_ms_ausgabe_text tmat on (tmpra.MS_AUSGABE_TEXTID = tmat.MS_AUSGABE_TEXTID)',
'WHERE ms.sucheid = :P48_SEARCH_SELECTION ',
'AND ms.meilenstein = :P48_MILESTONE_SELECTION',
'AND ms.landid IN (',
'    SELECT TO_NUMBER(TRIM(column_value))',
'    FROM TABLE(apex_string.split(TRIM(:P48_LANDIDS), '';''))',
')',
'AND ms.vorschriftnummer IS NOT NULL',
'AND (',
'    :P48_PUBLISHER_FILTER IS NULL ',
'    OR ',
'    EXISTS (',
'        -- Check if any alternative regulation exists for this publisher',
'        SELECT 1 ',
'        FROM t_vorschrift tv_check',
'        WHERE tv_check.vorschriftid = ms.alternative_vorschriftid',
'        AND tv_check.publisher IN (',
'            SELECT TRIM(column_value) ',
'            FROM TABLE(apex_string.split(:P48_PUBLISHER_FILTER, '':''))',
'        )',
'    )',
'    OR',
'    NOT EXISTS (',
'        -- Show main regulation if NO alternative regulation exists for this publisher',
'        SELECT 1 ',
'        FROM t_vorschrift tv_check',
'        WHERE tv_check.publisher IN (',
'            SELECT TRIM(column_value) ',
'            FROM TABLE(apex_string.split(:P48_PUBLISHER_FILTER, '':''))',
'        )',
'    )',
')',
'group by ',
' 1,''Publisher Nation oder Alt'',ms.themabezeichnung ,',
'    ms.vorschriftnummer ,',
'    ''UN-R 123/4, UN-R 123/3'' , tv.publisher',
'ORDER BY ',
'    Land,',
'    Themabezeichnung,',
'    Vorschriftennummer'))
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4920013713385618277)
,p_plug_name=>'&P48_CARD_TITLE. - Backup - 11 June 2025'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>130
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'',
'--  1 as checkbox,',
'    LISTAGG(DISTINCT ms.landnummer, ''; '') WITHIN GROUP (ORDER BY ms.landnummer) AS B_Nummer_Liste,',
'    LISTAGG(DISTINCT ms.landbezeichnung, ''; '') WITHIN GROUP (ORDER BY ms.landnummer) AS Land_Namen_Liste,',
'    ms.themabezeichnung AS Themabezeichnung,',
'    ms.vorschriftnummer AS Vorschriftennummer,',
'    nvl(tv.vorschrift_nummer, '''') AS Alternative_Vorschriftennummer,',
'    tv.publisher AS Publisher',
'FROM T_MS_SUCHERGEBNISS ms',
'LEFT OUTER JOIN t_vorschrift tv ON (tv.vorschriftid = ms.alternative_vorschriftid)',
'WHERE ms.sucheid = :P48_SEARCH_SELECTION ',
'AND ms.meilenstein = :P48_MILESTONE_SELECTION',
'AND ms.landid IN (',
'    SELECT TO_NUMBER(TRIM(column_value))',
'    FROM TABLE(apex_string.split(TRIM(:P48_LANDIDS), '';''))',
')',
'AND ms.vorschriftnummer IS NOT NULL',
'AND (',
'    :P48_PUBLISHER_FILTER IS NULL ',
'    OR ',
'    EXISTS (',
'        -- Check if any alternative regulation exists for this publisher',
'        SELECT 1 ',
'        FROM t_vorschrift tv_check',
'        WHERE tv_check.vorschriftid = ms.alternative_vorschriftid',
'        AND tv_check.publisher IN (',
'            SELECT TRIM(column_value) ',
'            FROM TABLE(apex_string.split(:P48_PUBLISHER_FILTER, '':''))',
'        )',
'    )',
'    OR',
'    NOT EXISTS (',
'        -- Show main regulation if NO alternative regulation exists for this publisher',
'        SELECT 1 ',
'        FROM t_vorschrift tv_check',
'        WHERE tv_check.publisher IN (',
'            SELECT TRIM(column_value) ',
'            FROM TABLE(apex_string.split(:P48_PUBLISHER_FILTER, '':''))',
'        )',
'    )',
')',
'GROUP BY ',
'    ms.themabezeichnung,',
'    ms.vorschriftnummer,',
'    tv.vorschrift_nummer,',
'    tv.publisher',
'ORDER BY ',
'    B_Nummer_Liste,',
'    Themabezeichnung,',
'    Vorschriftennummer'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P48_LANDIDS,P48_SEARCH_SELECTION,P48_MILESTONE_SELECTION,P48_PUBLISHER_FILTER'
,p_plug_display_condition_type=>'NEVER'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'&P461_CARD_TITLE. - Backup - 11 June 2025'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    ms.landnummer||'' - ''||ms.landbezeichnung AS Land,',
'    ms.vorschriftnummer as Vorschriftennummer,',
'    ms.vorschrifttitel as Vorschrifttitel,',
'    ms.status_vorschrift as Status,',
unistr('    ms.prognose_qualitaet as Prognose_Qualit\00E4t,'),
'    ms.sw_relevant as SW_Relevant,',
'    ms.risiko as Risiko',
'FROM T_MS_SUCHERGEBNISS ms',
'WHERE ms.sucheid = :P461_SEARCH_SELECTION ',
'AND ms.meilenstein = :P461_MILESTONE_SELECTION',
'AND ms.landid IN (',
'    SELECT TO_NUMBER(column_value)',
'    FROM TABLE(apex_string.split(:P461_LANDIDS, '':''))',
')',
'AND ms.vorschriftnummer IS NOT NULL',
'ORDER BY ',
'    Land,',
'    Vorschriftennummer'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(4920013783403618278)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>8592226099303006513
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985779999955712646)
,p_db_column_name=>'B_NUMMER_LISTE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'B Nummer Liste'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985779524483712644)
,p_db_column_name=>'LAND_NAMEN_LISTE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Land Namen Liste'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985779119224712644)
,p_db_column_name=>'THEMABEZEICHNUNG'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Themabezeichnung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985778791890712644)
,p_db_column_name=>'VORSCHRIFTENNUMMER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985778382266712644)
,p_db_column_name=>'ALTERNATIVE_VORSCHRIFTENNUMMER'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Alternative Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985778008119712643)
,p_db_column_name=>'PUBLISHER'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Publisher'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4922487569841171485)
,p_plug_name=>'&P48_CARD_TITLE.03 Juli BaCKUP'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>120
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    split.CARD_NUMBER,',
'    ',
'    -- SPECIFIC_REG_ID calculation',
'    CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END as SPECIFIC_REG_ID,',
'    ',
'',
'',
'    -- EDIT ICON - Gray disabled pencil',
'    CASE ',
'        WHEN MAX(ms.MANUELLER_EINTRAG) = 10 THEN',
'            -- Editable pencil for manual entries',
'            ''<a href="'' || ',
'            apex_util.prepare_url(',
'                p_url => ''f?p='' || :APP_ID || '':465:'' || :APP_SESSION || '':::465:'' ||',
'               -- ''P465_ROW_ID,P465_MODE,P465_SEARCH_SELECTION,P465_MILESTONE_SELECTION,P465_LANDIDS,P465_SPECIFIC_REG_ID:'' ||',
'                ''P465_ROW_ID,P465_MODE,P465_SEARCH_SELECTION,P465_MILESTONE_SELECTION,P465_SPECIFIC_REG_ID:'' ||',
'                -- split.CARD_NUMBER || ',
'                split.CARD_NUMBER ||'',EDIT,'' || ',
'                ms.sucheid || '','' || ',
'                ms.meilenstein || '','' || ',
'              --  :P48_LANDIDS || '','' ||',
'                CASE ',
'                    WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'                    ELSE ms.VORSCHRIFTID',
'                END',
'            ) || ',
'            ''" title="Bearbeiten (Manueller Eintrag)" class="edit-link">',
'                <span class="fa fa-pencil edit-icon" style="font-size: 16px; color: #333;"></span>',
'            </a>''',
'        ELSE',
'            -- Gray disabled pencil',
unistr('            ''<span class="fa fa-pencil" style="color: #ccc; font-size: 16px;" title="Automatischer Eintrag - Bearbeiten nicht m\00F6glich"></span>'''),
'    END AS EDIT_ACTION,',
'',
'    -- DELETE ICON - Gray disabled trash',
'',
'    CASE ',
'        WHEN MAX(ms.MANUELLER_EINTRAG) = 10 THEN',
'            ''<a href="javascript:confirmDeleteCard('' || split.CARD_NUMBER || '', '' || ',
'            CASE ',
'                WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'                ELSE ms.VORSCHRIFTID',
unistr('            END || '')" title="Manueller Eintrag - L\00F6schen ist m\00F6glich" class="delete-link">'),
'                <span class="fa fa-trash delete-icon" style="color: #bb0a31; font-size: 16px;"></span>',
'            </a>''',
'        ELSE',
unistr('            ''<span class="fa fa-trash" style="color: #ccc; font-size: 16px;" title="Automatischer Eintrag - L\00F6schen nicht m\00F6glich"></span>'''),
'    END AS DELETE_ACTION,',
'',
'    ',
'    -- MANUAL/AUTO INDICATOR',
'    CASE ',
'        WHEN MAX(ms.MANUELLER_EINTRAG) = 10 THEN',
'            ''<span class="manual-entry-indicator" title="Manueller Eintrag">',
'                <i class="fa fa-user-plus" style="color: #bb0a31; font-size: 14px; margin-right: 5px;"></i>',
'                <span>Manueller Eintrag</span>',
'            </span>''',
'        ELSE',
'            ''<span class="auto-entry-indicator" title="Automatischer Eintrag">',
'                <i class="fa fa-cog" style="color: #bb0a31; font-size: 14px; margin-right: 5px;"></i>',
'                <span>Automatischer Eintrag</span>',
'            </span>''',
'    END AS MANUELLER_EINTRAG,',
'    ',
'    -- DATA COLUMNS',
'    LISTAGG(DISTINCT ms.landnummer, ''; '') WITHIN GROUP (ORDER BY ms.landnummer) AS B_Nummer_Liste,',
'     LISTAGG(DISTINCT ms.landid, ''; '') WITHIN GROUP (ORDER BY ms.landnummer) AS landids,',
'    LISTAGG(DISTINCT ms.landbezeichnung, ''; '') WITHIN GROUP (ORDER BY ms.landnummer) AS Land_Namen_Liste,',
'    ms.themabezeichnung AS Themabezeichnung,',
'    ms.vorschriftnummer AS Vorschriftennummer,',
'    nvl(tv.vorschrift_nummer, '''') AS Alternative_Vorschriftennummer,',
'    tv.publisher AS Publisher,',
'    ',
'    -- HIDDEN COLUMNS for URL parameters ',
'    ms.sucheid AS SEARCH_ID_HIDDEN,',
'    ms.meilenstein AS MILESTONE_HIDDEN,',
'    :P48_LANDIDS AS LANDIDS_HIDDEN',
'',
'FROM T_MS_SUCHERGEBNISS ms',
'LEFT OUTER JOIN t_vorschrift tv ON (tv.vorschriftid = ms.alternative_vorschriftid)',
'LEFT OUTER JOIN T_MS_SUCHE_SPLIT split ON (',
'    split.SUCHEID = ms.sucheid ',
'    AND split.MEILENSTEIN = ms.meilenstein ',
'    AND split.LANDID = ms.landid',
')',
'WHERE ms.sucheid = :P48_SEARCH_SELECTION ',
'AND ms.meilenstein = :P48_MILESTONE_SELECTION',
'AND ms.landid IN (',
'    SELECT TO_NUMBER(TRIM(column_value))',
'    FROM TABLE(apex_string.split(TRIM(:P48_LANDIDS), '';''))',
')',
'AND ms.vorschriftnummer IS NOT NULL',
'AND (',
'    :P48_PUBLISHER_FILTER IS NULL ',
'    OR ',
'    EXISTS (',
'        SELECT 1 ',
'        FROM t_vorschrift tv_check',
'        WHERE tv_check.vorschriftid = ms.alternative_vorschriftid',
'        AND tv_check.publisher IN (',
'            SELECT TRIM(column_value) ',
'            FROM TABLE(apex_string.split(:P48_PUBLISHER_FILTER, '':''))',
'        )',
'    )',
'    OR',
'    NOT EXISTS (',
'        SELECT 1 ',
'        FROM t_vorschrift tv_check',
'        WHERE tv_check.publisher IN (',
'            SELECT TRIM(column_value) ',
'            FROM TABLE(apex_string.split(:P48_PUBLISHER_FILTER, '':''))',
'        )',
'    )',
')',
'and split.CARD_NUMBER =:P48_CARD_NUM',
'GROUP BY ',
'    split.CARD_NUMBER, ',
'    split.BENUTZERID,',
'',
'    CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END,',
'    ms.themabezeichnung,',
'    ms.vorschriftnummer,',
'    tv.vorschrift_nummer,',
'    tv.publisher,',
'    ms.sucheid,',
'    ms.meilenstein',
'',
'ORDER BY ',
'    MAX(ms.MANUELLER_EINTRAG) DESC,',
'    B_Nummer_Liste,',
'    Themabezeichnung,',
'    Vorschriftennummer;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P48_LANDIDS,P48_SEARCH_SELECTION,P48_MILESTONE_SELECTION,P48_PUBLISHER_FILTER'
,p_plug_display_condition_type=>'NEVER'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'&P461_CARD_TITLE.03 Juli BaCKUP'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    ms.landnummer||'' - ''||ms.landbezeichnung AS Land,',
'    ms.vorschriftnummer as Vorschriftennummer,',
'    ms.vorschrifttitel as Vorschrifttitel,',
'    ms.status_vorschrift as Status,',
unistr('    ms.prognose_qualitaet as Prognose_Qualit\00E4t,'),
'    ms.sw_relevant as SW_Relevant,',
'    ms.risiko as Risiko',
'FROM T_MS_SUCHERGEBNISS ms',
'WHERE ms.sucheid = :P461_SEARCH_SELECTION ',
'AND ms.meilenstein = :P461_MILESTONE_SELECTION',
'AND ms.landid IN (',
'    SELECT TO_NUMBER(column_value)',
'    FROM TABLE(apex_string.split(:P461_LANDIDS, '':''))',
')',
'AND ms.vorschriftnummer IS NOT NULL',
'ORDER BY ',
'    Land,',
'    Vorschriftennummer'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(4922487671402171486)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:465:&SESSION.::&DEBUG.:465:P465_ROW_ID,P465_MODE,P465_SEARCH_SELECTION,P465_MILESTONE_SELECTION,P465_LANDIDS:#CARD_NUMBER#,EDIT,&P461_SEARCH_SELECTION.,&P461_MILESTONE_SELECTION.,&P461_LANDIDS.'
,p_detail_link_text=>'<span class="fa fa-pencil" aria-hidden="true" alt="Bearbeiten" title="Bearbeiten"></span>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>8594699987301559721
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985777259385712619)
,p_db_column_name=>'CARD_NUMBER'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Card Number'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985776845087712618)
,p_db_column_name=>'B_NUMMER_LISTE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'B Nummer Liste'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985776489063712617)
,p_db_column_name=>'LAND_NAMEN_LISTE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Land Namen Liste'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985776062154712617)
,p_db_column_name=>'THEMABEZEICHNUNG'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Themabezeichnung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985775707421712616)
,p_db_column_name=>'VORSCHRIFTENNUMMER'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985775227813712616)
,p_db_column_name=>'ALTERNATIVE_VORSCHRIFTENNUMMER'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Alternative Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985774838679712615)
,p_db_column_name=>'PUBLISHER'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Publisher'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985774465077712615)
,p_db_column_name=>'MANUELLER_EINTRAG'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Eintrag Typ'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985774061290712615)
,p_db_column_name=>'DELETE_ACTION'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985773706413712614)
,p_db_column_name=>'SPECIFIC_REG_ID'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Specific Reg Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985773239037712614)
,p_db_column_name=>'EDIT_ACTION'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Edit Action'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985772862547712613)
,p_db_column_name=>'SEARCH_ID_HIDDEN'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Search Id Hidden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985772471237712613)
,p_db_column_name=>'MILESTONE_HIDDEN'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Milestone Hidden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985772054649712612)
,p_db_column_name=>'LANDIDS_HIDDEN'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Landids Hidden'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985771656548712612)
,p_db_column_name=>'LANDIDS'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Landids'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4928943145657586866)
,p_plug_name=>'&P48_CARD_TITLE. 0 Nackup 9 jul  THEMA NO GROUP'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>110
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH cte_lrsa AS (',
'    SELECT vrt.vorschriftid,',
'           LISTAGG(l.lrsa_nummer || '' - '' || l.bezeichnung, '', '') ',
'           WITHIN GROUP (ORDER BY l.bezeichnung ASC) AS lrsa',
'    FROM t_vorschrift_ref_thema vrt',
'    JOIN T_THEMA_REF_LRSA ref ON (vrt.themaid = ref.themaid)',
'    JOIN T_LRSA l ON (l.LRSA_ID = ref.LRSAID)',
'    WHERE vrt.geloescht = 0',
'    GROUP BY vrt.vorschriftid',
'),',
'-- cte_homologationseigenschaften AS (   ',
'--     SELECT vrt.vorschriftid, ',
'--            LISTAGG(e.EIGENSCHAFT_KENNUNG || ''-'' || et.kuerzel || ''-'' || e.eigenschaft, '', '') ',
'--            WITHIN GROUP (ORDER BY e.eigenschaft) AS homologationseigenschaften',
'--     FROM t_vorschrift_ref_thema vrt',
'--     JOIN carmah2_admin.t_eigenschaft_ref_regindexthemen err ON (vrt.themaid = err.regindex_themen_id)',
'--     JOIN carmah2_admin.t_eigenschaft e ON (err.eigenschaft_id = e.eigenschaft_id)',
'--     JOIN carmah2_admin.t_eigenschaft_typ et ON (e.eigenschaft_typ_id = et.eigenschaft_typ_id)',
'--     WHERE vrt.geloescht = 0',
'--     GROUP BY vrt.vorschriftid',
'-- ),',
'',
'cte_homologationseigenschaften AS (   ',
'    SELECT vrt.vorschriftid, ',
'           -- Replace commas with HTML line breaks',
'           REPLACE(',
'               LISTAGG(e.EIGENSCHAFT_KENNUNG || ''-'' || et.kuerzel || ''-'' || e.eigenschaft, '', '') ',
'               WITHIN GROUP (ORDER BY e.eigenschaft), ',
'               '', '', ',
'               ''<br>''',
'           ) AS homologationseigenschaften',
'    FROM t_vorschrift_ref_thema vrt',
'    JOIN carmah2_admin.t_eigenschaft_ref_regindexthemen err ON (vrt.themaid = err.regindex_themen_id)',
'    JOIN carmah2_admin.t_eigenschaft e ON (err.eigenschaft_id = e.eigenschaft_id)',
'    JOIN carmah2_admin.t_eigenschaft_typ et ON (e.eigenschaft_typ_id = et.eigenschaft_typ_id)',
'    WHERE vrt.geloescht = 0',
'    GROUP BY vrt.vorschriftid',
'),',
'cte_kritikalitaet AS (',
'    SELECT ms.sucheid,',
'           ms.meilenstein,',
'           LISTAGG(DISTINCT mat.KRITIKALITAET, ''; '') ',
'           WITHIN GROUP (ORDER BY mat.KRITIKALITAET) AS kritikalitaet_text',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN T_MS_AUSGABE_TEXT mat ON (mat.MS_AUSGABE_TEXTID = ms.sucheid)',
'    GROUP BY ms.sucheid, ms.meilenstein',
'),',
'-- cte_nachfolger AS (',
'--     SELECT vrv.vorgaenger_vorschriftid,',
'--            LISTAGG(nv.vorschrift_nummer || '' - '' || nv.vorschrift_bezeichnung, ''; '') ',
'--            WITHIN GROUP (ORDER BY nv.vorschrift_nummer) AS nachfolger_vorschrift',
'--     FROM t_vorschrift_ref_vorschrift vrv',
'--     JOIN t_vorschrift nv ON nv.vorschriftid = vrv.nachfolger_vorschriftid',
'--     WHERE vrv.beziehung_art != 20  -- Exclude Amendments',
'--     GROUP BY vrv.vorgaenger_vorschriftid',
'-- )',
'cte_nachfolger AS (',
'    SELECT vrv.vorgaenger_vorschriftid,',
'           -- Replace semicolons with HTML line breaks',
'           REPLACE(',
'               LISTAGG(nv.vorschrift_nummer || '' - '' || nv.vorschrift_bezeichnung, ''; '') ',
'               WITHIN GROUP (ORDER BY nv.vorschrift_nummer), ',
'               ''; '', ',
'               ''<br>''',
'           ) AS nachfolger_vorschrift',
'    FROM t_vorschrift_ref_vorschrift vrv',
'    JOIN t_vorschrift nv ON nv.vorschriftid = vrv.nachfolger_vorschriftid',
'    WHERE vrv.beziehung_art != 20  -- Exclude Amendments',
'    GROUP BY vrv.vorgaenger_vorschriftid',
')',
'',
'SELECT',
'',
'    1 as checkbox,',
'    ',
'    split.CARD_NUMBER,',
'    ',
'    -- SPECIFIC_REG_ID calculation',
'    CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END as SPECIFIC_REG_ID,',
'    ',
'    -- EDIT ICON - Gray disabled pencil',
'    CASE ',
'        WHEN MAX(ms.MANUELLER_EINTRAG) = 10 THEN',
'            -- Editable pencil for manual entries',
'        ''<a href="'' || ',
'            apex_util.prepare_url(',
'                p_url => ''f?p='' || :APP_ID || '':465:'' || :APP_SESSION || '':::465:'' ||',
'                ''P465_CARD_NUM,P465_MODE,P465_SEARCH_SELECTION,P465_MILESTONE_SELECTION,P465_LANDIDS,P465_SPECIFIC_REG_ID:'' ||',
'                split.CARD_NUMBER ||'',EDIT,'' || ',
'                ms.sucheid || '','' || ',
'                ms.meilenstein || '','' || ',
'                LISTAGG(DISTINCT ms.landid, '';'') WITHIN GROUP (ORDER BY ms.landnummer) || '','' ||',
'                -- CASE ',
'                --     WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'                --     ELSE ms.VORSCHRIFTID',
'                -- END',
'',
'                ',
'                     ms.VORSCHRIFTID',
'              ',
'            ) || ',
'            ''" title="Bearbeiten (Manueller Eintrag)" class="edit-link">',
'                <span class="fa fa-pencil edit-icon" style="font-size: 16px; color: #333;"></span>',
'        </a>''',
'        ELSE',
'            -- Gray disabled pencil',
unistr('            ''<span class="fa fa-pencil" style="color: #ccc; font-size: 16px;" title="Automatischer Eintrag - Bearbeiten nicht m\00F6glich"></span>'''),
'    END AS EDIT_ACTION,',
'',
'    -- DELETE ICON - Gray disabled trash',
'    CASE ',
'        WHEN MAX(ms.MANUELLER_EINTRAG) = 10 THEN',
'            ''<a href="javascript:confirmDeleteCard('' || split.CARD_NUMBER || '', '' || ',
'            CASE ',
'                WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'                ELSE ms.VORSCHRIFTID',
unistr('            END || '')" title="Manueller Eintrag - L\00F6schen ist m\00F6glich" class="delete-link">'),
'                <span class="fa fa-trash delete-icon" style="color: #bb0a31; font-size: 16px;"></span>',
'            </a>''',
'        ELSE',
unistr('            ''<span class="fa fa-trash" style="color: #ccc; font-size: 16px;" title="Automatischer Eintrag - L\00F6schen nicht m\00F6glich"></span>'''),
'    END AS DELETE_ACTION,',
'',
'    -- MANUAL/AUTO INDICATOR',
'    CASE ',
'        WHEN MAX(ms.MANUELLER_EINTRAG) = 10 THEN',
'            ''<span class="manual-entry-indicator" title="Manueller Eintrag">',
'                <i class="fa fa-user-plus" style="color: #bb0a31; font-size: 14px; margin-right: 5px;"></i>',
'                <span>Manueller Eintrag</span>',
'            </span>''',
'        ELSE',
'            ''<span class="auto-entry-indicator" title="Automatischer Eintrag">',
'                <i class="fa fa-cog" style="color: #bb0a31; font-size: 14px; margin-right: 5px;"></i>',
'                <span>Automatischer Eintrag</span>',
'            </span>''',
'    END AS MANUELLER_EINTRAG,',
'    ',
'    -- DATA COLUMNS',
'    LISTAGG(DISTINCT ms.landnummer, ''; '') WITHIN GROUP (ORDER BY ms.landnummer) AS B_Nummer_Liste,',
'    LISTAGG(DISTINCT ms.landid, ''; '') WITHIN GROUP (ORDER BY ms.landnummer) AS landids,',
'    LISTAGG(DISTINCT ms.landbezeichnung, ''; '') WITHIN GROUP (ORDER BY ms.landnummer) AS Land_Namen_Liste,',
'    ms.themabezeichnung AS Themabezeichnung,',
'    ms.vorschriftnummer AS Vorschriftennummer,',
'    nvl(tv.vorschrift_nummer, '''') AS Alternative_Vorschriftennummer,',
'    -- tv.publisher AS Publisher,',
'',
'    NVL(tv.publisher, tv_main.publisher) AS Publisher,',
'',
'    -- HIDDEN COLUMNS for URL parameters ',
'    ms.sucheid AS SEARCH_ID_HIDDEN,',
'    ms.meilenstein AS MILESTONE_HIDDEN,',
'    :P48_LANDIDS AS LANDIDS_HIDDEN,',
'',
'    -- NEW COLUMNS',
'    tv_main.rxswin as rxswin_relevant,',
'',
'    -- NEW COLUMNS FROM CTEs',
'    -- 1. LRSA',
'    NVL(lrsa_main.lrsa, lrsa_alt.lrsa) AS LRSA,',
'    ',
'    -- 2. Homologationseigenschaft  ',
'    NVL(homo_main.homologationseigenschaften, homo_alt.homologationseigenschaften) AS Homologationseigenschaft,',
'    ',
'    -- 3. Nachfolger Vorschrift',
'    NVL(nachf_main.nachfolger_vorschrift, nachf_alt.nachfolger_vorschrift) AS Nachfolger_Vorschrift,',
'    ',
unistr('    -- 4. Text der Kritikalit\00E4t'),
'    krit.kritikalitaet_text AS Text_Kritikalitaet,',
'',
'',
'   ',
'    CASE ',
'    WHEN bew.ET_VERWENDUNG = ''nicht bewertet'' THEN ''<span class="et-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>''',
'    WHEN bew.ET_VERWENDUNG = ''ja'' THEN ''<span class="et-ja" style="color: #27ae60; font-weight: bold;"><i class="fa fa-check"></i> ja</span>''',
'    WHEN bew.ET_VERWENDUNG = ''nein'' THEN ''<span class="et-nein" style="color: #e74c3c; font-weight: bold;"><i class="fa fa-times"></i> nein</span>''',
'    ELSE ''<span class="et-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>''',
'END AS ET_VERWENDUNG,',
'    bew.ET_VORSCHLAG_VORSCHRIFT, ',
'    bew.ET_KOMMENTAR,',
'    ',
'CASE ',
'    WHEN bew.FB_VERWENDUNG = ''nicht bewertet'' THEN ''<span class="fb-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>''',
'    WHEN bew.FB_VERWENDUNG = ''ja'' THEN ''<span class="fb-ja" style="color: #27ae60; font-weight: bold;"><i class="fa fa-check"></i> ja</span>''',
'    WHEN bew.FB_VERWENDUNG = ''nein'' THEN ''<span class="fb-nein" style="color: #e74c3c; font-weight: bold;"><i class="fa fa-times"></i> nein</span>''',
'    ELSE ''<span class="fb-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>''',
'END AS FB_VERWENDUNG,',
'    bew.FB_VORSCHLAG_VORSCHRIFT,',
'    bew.FB_KOMMENTAR',
'',
'   ',
'',
'',
'FROM T_MS_SUCHERGEBNISS ms',
'LEFT OUTER JOIN t_vorschrift tv ON (tv.vorschriftid = ms.alternative_vorschriftid)',
'LEFT OUTER JOIN t_vorschrift tv_main ON (tv_main.vorschriftid = ms.vorschriftid)',
'LEFT OUTER JOIN T_MS_SUCHE_SPLIT split ON (',
'    split.SUCHEID = ms.sucheid ',
'    AND split.MEILENSTEIN = ms.meilenstein ',
'    AND split.LANDID = ms.landid',
')',
'-- JOIN CTEs',
'LEFT OUTER JOIN cte_lrsa lrsa_main ON (lrsa_main.vorschriftid = ms.vorschriftid)',
'LEFT OUTER JOIN cte_lrsa lrsa_alt ON (lrsa_alt.vorschriftid = ms.alternative_vorschriftid)',
'LEFT OUTER JOIN cte_homologationseigenschaften homo_main ON (homo_main.vorschriftid = ms.vorschriftid)',
'LEFT OUTER JOIN cte_homologationseigenschaften homo_alt ON (homo_alt.vorschriftid = ms.alternative_vorschriftid)',
'LEFT OUTER JOIN cte_nachfolger nachf_main ON (nachf_main.vorgaenger_vorschriftid = ms.vorschriftid)',
'LEFT OUTER JOIN cte_nachfolger nachf_alt ON (nachf_alt.vorgaenger_vorschriftid = ms.alternative_vorschriftid)',
'LEFT OUTER JOIN cte_kritikalitaet krit ON (krit.sucheid = ms.sucheid AND krit.meilenstein = ms.meilenstein)',
'',
'LEFT OUTER JOIN T_MS_BEWERTUNG bew ON (',
'    bew.SUCHEID = ms.sucheid ',
'    AND bew.MEILENSTEIN = ms.meilenstein',
'    AND bew.CARD_NUMBER = split.CARD_NUMBER',
'    AND bew.VORSCHRIFTID = CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END',
'    AND bew.BENUTZERID = :G_BENUTZERID',
')',
'',
'',
'',
'WHERE ms.sucheid = :P48_SEARCH_SELECTION ',
'AND ms.meilenstein = :P48_MILESTONE_SELECTION',
'AND ms.landid IN (',
'    SELECT TO_NUMBER(TRIM(column_value))',
'    FROM TABLE(apex_string.split(TRIM(:P48_LANDIDS), '';''))',
')',
'AND ms.vorschriftnummer IS NOT NULL',
'-- AND (',
'--     :P48_PUBLISHER_FILTER IS NULL ',
'--     OR ',
'--     EXISTS (',
'--         SELECT 1 ',
'--         FROM t_vorschrift tv_check',
'--         WHERE tv_check.vorschriftid = ms.alternative_vorschriftid',
'--         AND tv_check.publisher IN (',
'--             SELECT TRIM(column_value) ',
'--             FROM TABLE(apex_string.split(:P48_PUBLISHER_FILTER, '':''))',
'--         )',
'--     )',
'--     OR',
'--     NOT EXISTS (',
'--         SELECT 1 ',
'--         FROM t_vorschrift tv_check',
'--         WHERE tv_check.publisher IN (',
'--             SELECT TRIM(column_value) ',
'--             FROM TABLE(apex_string.split(:P48_PUBLISHER_FILTER, '':''))',
'--         )',
'--     )',
'-- )',
'',
'AND (',
'    :P48_PUBLISHER_FILTER IS NULL ',
'    OR ',
'    NVL(tv.publisher, tv_main.publisher) IN (',
'        SELECT TRIM(column_value) ',
'        FROM TABLE(apex_string.split(:P48_PUBLISHER_FILTER, '':''))',
'    )',
')',
'AND split.CARD_NUMBER = :P48_CARD_NUM',
'GROUP BY ',
'    split.CARD_NUMBER, ',
'    split.BENUTZERID,',
'    CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END,',
'    ms.themabezeichnung,',
'    ms.vorschriftnummer,',
'    tv.vorschrift_nummer,',
'    tv.publisher,',
'    tv_main.publisher,',
'    ms.VORSCHRIFTID,',
'    ms.sucheid,',
'    ms.meilenstein,',
'    tv_main.rxswin,',
'    -- CTE columns to GROUP BY',
'    NVL(lrsa_main.lrsa, lrsa_alt.lrsa),',
'    NVL(homo_main.homologationseigenschaften, homo_alt.homologationseigenschaften),',
'    NVL(nachf_main.nachfolger_vorschrift, nachf_alt.nachfolger_vorschrift),',
'    krit.kritikalitaet_text,',
'    bew.ET_VERWENDUNG,',
'    bew.ET_VORSCHLAG_VORSCHRIFT, ',
'    bew.ET_KOMMENTAR,',
'    bew.FB_VERWENDUNG,',
'    bew.FB_VORSCHLAG_VORSCHRIFT,',
'    bew.FB_KOMMENTAR',
'',
'ORDER BY ',
'    MAX(ms.MANUELLER_EINTRAG) DESC,',
'    B_Nummer_Liste,',
'    Themabezeichnung,',
'    Vorschriftennummer;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P48_LANDIDS,P48_SEARCH_SELECTION,P48_MILESTONE_SELECTION,P48_PUBLISHER_FILTER'
,p_plug_display_condition_type=>'NEVER'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'&P461_CARD_TITLE. 0 Nackup 9 jul  THEMA NO GROUP'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    ms.landnummer||'' - ''||ms.landbezeichnung AS Land,',
'    ms.vorschriftnummer as Vorschriftennummer,',
'    ms.vorschrifttitel as Vorschrifttitel,',
'    ms.status_vorschrift as Status,',
unistr('    ms.prognose_qualitaet as Prognose_Qualit\00E4t,'),
'    ms.sw_relevant as SW_Relevant,',
'    ms.risiko as Risiko',
'FROM T_MS_SUCHERGEBNISS ms',
'WHERE ms.sucheid = :P461_SEARCH_SELECTION ',
'AND ms.meilenstein = :P461_MILESTONE_SELECTION',
'AND ms.landid IN (',
'    SELECT TO_NUMBER(column_value)',
'    FROM TABLE(apex_string.split(:P461_LANDIDS, '':''))',
')',
'AND ms.vorschriftnummer IS NOT NULL',
'ORDER BY ',
'    Land,',
'    Vorschriftennummer'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(4928943206774586867)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>8601155522673975102
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985770958962712609)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'<input type="checkbox" id="selectUnselectAll" title="Select/UnselectAll" value="all" />'
,p_column_html_expression=>'<input type="checkbox" value="#SPECIFIC_REG_ID#" />'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985770558506712608)
,p_db_column_name=>'EDIT_ACTION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985770138650712607)
,p_db_column_name=>'CARD_NUMBER'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Card Number'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985769743341712606)
,p_db_column_name=>'B_NUMMER_LISTE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'B Nummer Liste'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985769398681712605)
,p_db_column_name=>'LAND_NAMEN_LISTE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Land Namen Liste'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985768930590712605)
,p_db_column_name=>'THEMABEZEICHNUNG'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Themabezeichnung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985768537904712603)
,p_db_column_name=>'VORSCHRIFTENNUMMER'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985768135975712602)
,p_db_column_name=>'ALTERNATIVE_VORSCHRIFTENNUMMER'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Alternative Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985767791958712601)
,p_db_column_name=>'PUBLISHER'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Publisher'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985767387293712599)
,p_db_column_name=>'MANUELLER_EINTRAG'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Eintrag Typ'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985767001052712597)
,p_db_column_name=>'DELETE_ACTION'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985766594597712597)
,p_db_column_name=>'SPECIFIC_REG_ID'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Specific Reg Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985766181567712596)
,p_db_column_name=>'SEARCH_ID_HIDDEN'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Search Id Hidden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985765782754712595)
,p_db_column_name=>'MILESTONE_HIDDEN'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Milestone Hidden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985765320092712595)
,p_db_column_name=>'LANDIDS_HIDDEN'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Landids Hidden'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985764916947712593)
,p_db_column_name=>'LANDIDS'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Landids'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985764533705712593)
,p_db_column_name=>'RXSWIN_RELEVANT'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'potentiell SUMS-Relevant'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(958135905312245351)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985764140243712592)
,p_db_column_name=>'NACHFOLGER_VORSCHRIFT'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Nachfolger Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985763739644712590)
,p_db_column_name=>'LRSA'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Lrsa'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985763382600712589)
,p_db_column_name=>'HOMOLOGATIONSEIGENSCHAFT'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Homologationseigenschaft'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985762997004712588)
,p_db_column_name=>'TEXT_KRITIKALITAET'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Text Kritikalitaet'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985762584425712587)
,p_db_column_name=>'ET_VERWENDUNG'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'ET Verwendung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985762159280712586)
,p_db_column_name=>'ET_VORSCHLAG_VORSCHRIFT'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'ET Vorschlag Vorschrift'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985761771127712585)
,p_db_column_name=>'ET_KOMMENTAR'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'ET Kommentar'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985761337958712584)
,p_db_column_name=>'FB_VERWENDUNG'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'FB Verwendung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985760983065712583)
,p_db_column_name=>'FB_VORSCHLAG_VORSCHRIFT'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'FB Vorschlag Vorschrift'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985760532384712581)
,p_db_column_name=>'FB_KOMMENTAR'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'FB Kommentar'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5977191245343524109)
,p_plug_name=>'&P48_CARD_TITLE.'
,p_region_name=>'R45756756756575'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>80
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH cte_lrsa AS (',
'    SELECT vrt.vorschriftid,',
'           LISTAGG(DISTINCT l.lrsa_nummer || '' - '' || l.bezeichnung, '', '') ',
'           WITHIN GROUP (ORDER BY l.bezeichnung ASC) AS lrsa',
'    FROM t_vorschrift_ref_thema vrt',
'    JOIN T_THEMA_REF_LRSA ref ON (vrt.themaid = ref.themaid)',
'    JOIN T_LRSA l ON (l.LRSA_ID = ref.LRSAID)',
'    WHERE vrt.geloescht = 0',
'    GROUP BY vrt.vorschriftid',
'),',
'',
'cte_homologationseigenschaften AS (   ',
'    SELECT vrt.vorschriftid, ',
'           REPLACE(',
'               LISTAGG(DISTINCT e.EIGENSCHAFT_KENNUNG || ''-'' || et.kuerzel || ''-'' || e.eigenschaft, '', '') ',
'               WITHIN GROUP (ORDER BY e.eigenschaft), ',
'               '', '', ',
'               ''<br>''',
'           ) AS homologationseigenschaften',
'    FROM t_vorschrift_ref_thema vrt',
'    JOIN carmah2_admin.t_eigenschaft_ref_regindexthemen err ON (vrt.themaid = err.regindex_themen_id)',
'    JOIN carmah2_admin.t_eigenschaft e ON (err.eigenschaft_id = e.eigenschaft_id)',
'    JOIN carmah2_admin.t_eigenschaft_typ et ON (e.eigenschaft_typ_id = et.eigenschaft_typ_id)',
'    WHERE vrt.geloescht = 0',
'    GROUP BY vrt.vorschriftid',
'),',
'',
'cte_nachfolger AS (',
'    SELECT vorgaenger_vorschriftid,',
'           REPLACE(',
'               LISTAGG(DISTINCT vorschrift_info, ''; '') ',
'               WITHIN GROUP (ORDER BY vorschrift_nummer), ',
'               ''; '', ',
'               ''<br>''',
'           ) || ',
'           CASE WHEN total_count > 1 THEN ''<br>...(+'' || (total_count - 1) || '' weitere)'' ELSE '''' END AS nachfolger_vorschrift',
'    FROM (',
'        SELECT vrv.vorgaenger_vorschriftid,',
'               nv.vorschrift_nummer,',
'               nv.vorschrift_nummer || '' - '' || nv.vorschrift_bezeichnung AS vorschrift_info,',
'               COUNT(*) OVER (PARTITION BY vrv.vorgaenger_vorschriftid) AS total_count,',
'               ROW_NUMBER() OVER (PARTITION BY vrv.vorgaenger_vorschriftid ORDER BY nv.vorschrift_nummer) AS rn',
'        FROM t_vorschrift_ref_vorschrift vrv',
'        JOIN t_vorschrift nv ON nv.vorschriftid = vrv.nachfolger_vorschriftid',
'        WHERE vrv.beziehung_art != 20',
'    )',
'    WHERE rn <= 1  -- Only show first successor',
'    GROUP BY vorgaenger_vorschriftid, total_count',
'),',
'',
'cte_regelnummer_kritikalitaet AS (',
'    SELECT ',
'        ms.sucheid,',
'        ms.meilenstein,',
'        ms.landid,',
'        CASE ',
'            WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'            ELSE ms.VORSCHRIFTID',
'        END as specific_vorschrift_id,',
'        LISTAGG(DISTINCT TO_CHAR(ms.regelnummer), ''; '') ',
'        WITHIN GROUP (ORDER BY ms.regelnummer) AS regelnummer_list,',
'        LISTAGG(DISTINCT ',
'            CASE ',
'                WHEN mat.KRITIKALITAET IS NOT NULL THEN TO_CHAR(mat.KRITIKALITAET)',
'                ELSE NULL ',
'            END, ''; '') ',
'        WITHIN GROUP (ORDER BY mat.KRITIKALITAET) AS kritikalitaet_von_regelnummer,',
'        LISTAGG(DISTINCT ',
'            CASE ',
'                WHEN mat.AUSGABE_TEXT IS NOT NULL THEN mat.AUSGABE_TEXT',
'                ELSE NULL ',
'            END, ''<br>'') ',
'        WITHIN GROUP (ORDER BY mat.AUSGABE_TEXT) AS ausgabe_text_von_regelnummer',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT JOIN T_MS_PARAMETER p ON ms.regelnummer = p.nummer',
'    LEFT JOIN T_MS_PARAMETER_REF_AUSGABE pra ON p.MS_PARAMETERID = pra.MS_PARAMETERID',
'    LEFT JOIN T_MS_AUSGABE_TEXT mat ON pra.MS_AUSGABE_TEXTID = mat.MS_AUSGABE_TEXTID',
'    GROUP BY ms.sucheid, ms.meilenstein, ms.landid,',
'        CASE ',
'            WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'            ELSE ms.VORSCHRIFTID',
'        END',
')',
'',
'SELECT',
'    1 as checkbox,',
'',
'    ''<a href="'' || ',
'    apex_util.prepare_url(',
'        p_url => ''f?p='' || :APP_ID || '':466:'' || :APP_SESSION || '':::466:'' ||',
'        ''P466_SEARCH_SELECTION,P466_MILESTONE_SELECTION,P466_CARD_NUM,P466_SINGLE_REG_ID:'' ||',
'        :P48_SEARCH_SELECTION || '','' || :P48_MILESTONE_SELECTION || '','' || :P48_CARD_NUM || '','' ||',
'        ms.VORSCHRIFTID',
'    ) || ',
'    ''" title="Bewertung bearbeiten" class="single-edit-link">'' ||',
'        ''<span class="fa fa-external-link" style="font-size: 16px; color: #007bff;"></span>'' ||',
'    ''</a>'' AS ROW_EDIT_LINK,',
'',
'    MAX(split.CARD_NUMBER) AS CARD_NUMBER,',
'    ',
'    -- SPECIFIC_REG_ID - now just use the main VORSCHRIFTID since we''re grouping',
'    ms.VORSCHRIFTID as SPECIFIC_REG_ID,',
'',
'    ms.VORSCHRIFTID,',
'',
'    -- ALTERNATIVE_VORSCHRIFT_ID_GROUPED - comma separated list',
'    LISTAGG(DISTINCT ',
'        CASE ',
'            WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN TO_CHAR(ms.ALTERNATIVE_VORSCHRIFTID)',
'            ELSE NULL ',
'        END, '', '') ',
'    WITHIN GROUP (ORDER BY ms.ALTERNATIVE_VORSCHRIFTID) AS ALTERNATIVE_VORSCHRIFTID,',
'    ',
'    -- EDIT ICON',
'    CASE ',
'        WHEN MAX(ms.MANUELLER_EINTRAG) = 10 THEN',
'        ''<a href="'' || ',
'            apex_util.prepare_url(',
'                p_url => ''f?p='' || :APP_ID || '':465:'' || :APP_SESSION || '':::465:'' ||',
'                ''P465_CARD_NUM,P465_MODE,P465_SEARCH_SELECTION,P465_MILESTONE_SELECTION,P465_LANDIDS,P465_SPECIFIC_REG_ID:'' ||',
'                MAX(split.CARD_NUMBER) ||'',EDIT,'' || ',
'                ms.sucheid || '','' || ',
'                ms.meilenstein || '','' || ',
'                LISTAGG(DISTINCT ms.landid, '';'') WITHIN GROUP (ORDER BY ms.landnummer) || '','' ||',
'                ms.VORSCHRIFTID',
'            ) || ',
'            ''" title="Bearbeiten (Manueller Eintrag)" class="edit-link">',
'                <span class="fa fa-pencil edit-icon" style="font-size: 16px; color: #333;"></span>',
'        </a>''',
'        ELSE',
unistr('            ''<span class="fa fa-pencil" style="color: #ccc; font-size: 16px;" title="Automatischer Eintrag - Bearbeiten nicht m\00F6glich"></span>'''),
'    END AS EDIT_ACTION,',
'',
'    -- DELETE ICON',
'    CASE ',
'        WHEN MAX(ms.MANUELLER_EINTRAG) = 10 THEN',
'            ''<a href="javascript:confirmDeleteCard('' || MAX(split.CARD_NUMBER) || '', '' || ',
unistr('            ms.VORSCHRIFTID || '')" title="Manueller Eintrag - L\00F6schen ist m\00F6glich" class="delete-link">'),
'                <span class="fa fa-trash delete-icon" style="color: #bb0a31; font-size: 16px;"></span>',
'            </a>''',
'        ELSE',
unistr('            ''<span class="fa fa-trash" style="color: #ccc; font-size: 16px;" title="Automatischer Eintrag - L\00F6schen nicht m\00F6glich"></span>'''),
'    END AS DELETE_ACTION,',
'',
'    -- MANUAL/AUTO INDICATOR',
'    CASE ',
'        WHEN MAX(ms.MANUELLER_EINTRAG) = 10 THEN',
'            ''<span class="manual-entry-indicator" title="Manueller Eintrag">',
'                <i class="fa fa-user-plus" style="color: #bb0a31; font-size: 14px; margin-right: 5px;"></i>',
'                <span>Manueller Eintrag</span>',
'            </span>''',
'        ELSE',
'            ''<span class="auto-entry-indicator" title="Automatischer Eintrag">',
'                <i class="fa fa-cog" style="color: #bb0a31; font-size: 14px; margin-right: 5px;"></i>',
'                <span>Automatischer Eintrag</span>',
'            </span>''',
'    END AS MANUELLER_EINTRAG,',
'    ',
'    -- LISTAGG FUNCTIONS',
'    LISTAGG(DISTINCT ms.landnummer, ''; '') WITHIN GROUP (ORDER BY ms.landnummer) AS B_Nummer_Liste,',
'    LISTAGG(DISTINCT ms.landid, ''; '') WITHIN GROUP (ORDER BY ms.landnummer) AS landids,',
'    LISTAGG(DISTINCT ms.landbezeichnung, ''; '') WITHIN GROUP (ORDER BY ms.landnummer) AS Land_Namen_Liste,',
'',
'    LISTAGG(DISTINCT ms.themabezeichnung, ''; '') WITHIN GROUP (ORDER BY ms.themabezeichnung) AS Themabezeichnung,',
'    ',
'    -- MAIN VORSCHRIFT NUMBER (using MAX since tv_main should be same for all)',
'    MAX(CASE ',
'        WHEN NVL(tp_main.ANZEIGE_MIT_DOKUMENTENDATUM, 0) = 20 ',
'             AND tv_main.DOKUMENTENDATUM IS NOT NULL ',
'        THEN COALESCE(tv_main.vorschrift_nummer, ms.vorschriftnummer) || ''_'' || ',
'             TO_CHAR(tv_main.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'        ELSE COALESCE(tv_main.vorschrift_nummer, ms.vorschriftnummer) ',
'    END) AS Vorschriftennummer,',
'',
'    -- ALTERNATIVE VORSCHRIFT NUMBER - grouped with comma separator',
'    LISTAGG(DISTINCT ',
'        CASE ',
'            WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL AND tv.vorschrift_nummer IS NOT NULL THEN',
'                CASE ',
'                    WHEN NVL(tp_alt.ANZEIGE_MIT_DOKUMENTENDATUM, 0) = 20 ',
'                         AND tv.DOKUMENTENDATUM IS NOT NULL ',
'                    THEN tv.vorschrift_nummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'                    ELSE tv.vorschrift_nummer ',
'                END',
'            ELSE NULL',
'        END, '', '') ',
'    WITHIN GROUP (ORDER BY tv.vorschrift_nummer) AS Alternative_Vorschriftennummer,',
'',
'    -- PUBLISHER - grouped with LISTAGG',
'    LISTAGG(DISTINCT NVL(tv.publisher, tv_main.publisher), ''; '') ',
'    WITHIN GROUP (ORDER BY NVL(tv.publisher, tv_main.publisher)) AS Publisher,',
'',
'    -- HIDDEN COLUMNS for URL parameters ',
'    ms.sucheid AS SEARCH_ID_HIDDEN,',
'    ms.meilenstein AS MILESTONE_HIDDEN,',
'    :P48_LANDIDS AS LANDIDS_HIDDEN,',
'',
'    MAX(tv_main.rxswin) as rxswin_relevant,',
'    ',
'    -- CTE COLUMNS (using MAX since there should be one main match)',
'    MAX(NVL(lrsa_main.lrsa, lrsa_alt.lrsa)) AS LRSA,',
'    MAX(NVL(homo_main.homologationseigenschaften, homo_alt.homologationseigenschaften)) AS Homologationseigenschaft,',
'',
'    -- NACHFOLGER COLUMN',
'    MAX(NVL(nachf_main.nachfolger_vorschrift, nachf_alt.nachfolger_vorschrift)) AS Nachfolger_Vorschrift,',
'    ',
'    -- REGEL_KRIT COLUMNS - this might need multiple values, so use LISTAGG',
'    LISTAGG(DISTINCT regel_krit.regelnummer_list, ''; '') WITHIN GROUP (ORDER BY regel_krit.regelnummer_list) AS REGELNUMMER,',
'    LISTAGG(DISTINCT regel_krit.kritikalitaet_von_regelnummer, ''; '') WITHIN GROUP (ORDER BY regel_krit.kritikalitaet_von_regelnummer) AS KRITIKALITAET_VON_REGELNUMMER,',
'    LISTAGG(DISTINCT regel_krit.ausgabe_text_von_regelnummer, ''<br>'') WITHIN GROUP (ORDER BY regel_krit.ausgabe_text_von_regelnummer) AS AUSGABE_TEXT_VON_REGELNUMMER,',
'',
'    -- BEWERTUNG COLUMNS - use LISTAGG to combine multiple evaluations',
'    LISTAGG(DISTINCT CASE ',
'        WHEN bew.ET_VERWENDUNG = ''nicht bewertet'' THEN ''<span class="et-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>''',
'        WHEN bew.ET_VERWENDUNG = ''ja'' THEN ''<span class="et-ja" style="color: #27ae60; font-weight: bold;"><i class="fa fa-check"></i> ja</span>''',
'        WHEN bew.ET_VERWENDUNG = ''nein'' THEN ''<span class="et-nein" style="color: #e74c3c; font-weight: bold;"><i class="fa fa-times"></i> nein</span>''',
'        ELSE ''<span class="et-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>''',
'    END, ''; '') WITHIN GROUP (ORDER BY bew.ET_VERWENDUNG) AS ET_VERWENDUNG,',
'    LISTAGG(DISTINCT bew.ET_VORSCHLAG_VORSCHRIFT, ''; '') WITHIN GROUP (ORDER BY bew.ET_VORSCHLAG_VORSCHRIFT) AS ET_VORSCHLAG_VORSCHRIFT, ',
'    ',
'    LISTAGG(DISTINCT bew.ET_KOMMENTAR, ''; '') WITHIN GROUP (ORDER BY bew.ET_KOMMENTAR) AS ET_KOMMENTAR,',
'    ',
'    LISTAGG(DISTINCT CASE ',
'        WHEN bew.FB_VERWENDUNG = ''nicht bewertet'' THEN ''<span class="fb-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>''',
'        WHEN bew.FB_VERWENDUNG = ''ja'' THEN ''<span class="fb-ja" style="color: #27ae60; font-weight: bold;"><i class="fa fa-check"></i> ja</span>''',
'        WHEN bew.FB_VERWENDUNG = ''nein'' THEN ''<span class="fb-nein" style="color: #e74c3c; font-weight: bold;"><i class="fa fa-times"></i> nein</span>''',
'        ELSE ''<span class="fb-nicht-bewertet" style="color: #666; font-style: italic;">nicht bewertet</span>''',
'    END, ''; '') WITHIN GROUP (ORDER BY bew.FB_VERWENDUNG) AS FB_VERWENDUNG,',
'    LISTAGG(DISTINCT bew.FB_VORSCHLAG_VORSCHRIFT, ''; '') WITHIN GROUP (ORDER BY bew.FB_VORSCHLAG_VORSCHRIFT) AS FB_VORSCHLAG_VORSCHRIFT,',
'    LISTAGG(DISTINCT bew.FB_KOMMENTAR, ''; '') WITHIN GROUP (ORDER BY bew.FB_KOMMENTAR) AS FB_KOMMENTAR',
'',
'FROM T_MS_SUCHERGEBNISS ms',
'LEFT OUTER JOIN t_vorschrift tv ON (tv.vorschriftid = ms.alternative_vorschriftid)',
'LEFT OUTER JOIN t_vorschrift tv_main ON (tv_main.vorschriftid = ms.vorschriftid)',
'LEFT OUTER JOIN t_publisher tp_alt ON (tv.publisherid = tp_alt.publisherid)',
'LEFT OUTER JOIN t_publisher tp_main ON (tv_main.publisherid = tp_main.publisherid)',
'LEFT OUTER JOIN T_MS_SUCHE_SPLIT split ON (',
'    split.SUCHEID = ms.sucheid ',
'    AND split.MEILENSTEIN = ms.meilenstein ',
'    AND split.LANDID = ms.landid',
')',
'-- JOIN CTEs',
'LEFT OUTER JOIN cte_lrsa lrsa_main ON (lrsa_main.vorschriftid = ms.vorschriftid)',
'LEFT OUTER JOIN cte_lrsa lrsa_alt ON (lrsa_alt.vorschriftid = ms.alternative_vorschriftid)',
'LEFT OUTER JOIN cte_homologationseigenschaften homo_main ON (homo_main.vorschriftid = ms.vorschriftid)',
'LEFT OUTER JOIN cte_homologationseigenschaften homo_alt ON (homo_alt.vorschriftid = ms.alternative_vorschriftid)',
'LEFT OUTER JOIN cte_nachfolger nachf_main ON (nachf_main.vorgaenger_vorschriftid = ms.vorschriftid)',
'LEFT OUTER JOIN cte_nachfolger nachf_alt ON (nachf_alt.vorgaenger_vorschriftid = ms.alternative_vorschriftid)',
'LEFT OUTER JOIN cte_regelnummer_kritikalitaet regel_krit ON (',
'    regel_krit.sucheid = ms.sucheid ',
'    AND regel_krit.meilenstein = ms.meilenstein',
'    AND regel_krit.landid = ms.landid',
'    AND regel_krit.specific_vorschrift_id = CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END',
')',
'',
'/*',
'LEFT OUTER JOIN T_MS_BEWERTUNG bew ON (',
'    bew.SUCHEID = ms.sucheid ',
'    AND bew.MEILENSTEIN = ms.meilenstein',
'    AND bew.CARD_NUMBER = split.CARD_NUMBER',
'    AND bew.VORSCHRIFTID = CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END',
'    AND bew.BENUTZERID = :G_BENUTZERID',
')',
'*/',
'',
'LEFT OUTER JOIN T_MS_BEWERTUNG bew ON (',
'    bew.SUCHEID = ms.sucheid ',
'    AND bew.MEILENSTEIN = ms.meilenstein',
'    AND bew.CARD_NUMBER = split.CARD_NUMBER',
'    AND bew.VORSCHRIFTID = CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END',
'    AND (bew.BENUTZERID = :G_BENUTZERID ',
'         OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                    WHERE brr.benutzerid = :G_BENUTZERID ',
'                    AND brr.rolleid = 1001))',
')',
'',
'',
'WHERE ms.sucheid = :P48_SEARCH_SELECTION ',
'AND ms.meilenstein = :P48_MILESTONE_SELECTION',
'AND ms.landid IN (',
'    SELECT TO_NUMBER(TRIM(column_value))',
'    FROM TABLE(apex_string.split(TRIM(:P48_LANDIDS), '';''))',
')',
'AND ms.vorschriftnummer IS NOT NULL',
'AND (',
'    :P48_PUBLISHER_FILTER IS NULL ',
'    OR ',
'    NVL(tv.publisher, tv_main.publisher) IN (',
'        SELECT TRIM(column_value) ',
'        FROM TABLE(apex_string.split(:P48_PUBLISHER_FILTER, '':''))',
'    )',
')',
'AND split.CARD_NUMBER = :P48_CARD_NUM',
'',
'-- CLEAN GROUP BY - Only group by main regulation ID and manual/automatic type',
'GROUP BY ',
'    ms.VORSCHRIFTID,',
'    ms.MANUELLER_EINTRAG,  -- This creates 2 groups: manual vs automatic',
'    ms.sucheid,',
'    ms.meilenstein,',
'    ms.vorschriftnummer',
'',
'ORDER BY ',
'    MAX(ms.MANUELLER_EINTRAG) DESC,',
'    B_Nummer_Liste,',
'    Themabezeichnung,',
'    Vorschriftennummer;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P48_LANDIDS,P48_SEARCH_SELECTION,P48_MILESTONE_SELECTION,P48_PUBLISHER_FILTER'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'&P461_CARD_TITLE.'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    ms.landnummer||'' - ''||ms.landbezeichnung AS Land,',
'    ms.vorschriftnummer as Vorschriftennummer,',
'    ms.vorschrifttitel as Vorschrifttitel,',
'    ms.status_vorschrift as Status,',
unistr('    ms.prognose_qualitaet as Prognose_Qualit\00E4t,'),
'    ms.sw_relevant as SW_Relevant,',
'    ms.risiko as Risiko',
'FROM T_MS_SUCHERGEBNISS ms',
'WHERE ms.sucheid = :P461_SEARCH_SELECTION ',
'AND ms.meilenstein = :P461_MILESTONE_SELECTION',
'AND ms.landid IN (',
'    SELECT TO_NUMBER(column_value)',
'    FROM TABLE(apex_string.split(:P461_LANDIDS, '':''))',
')',
'AND ms.vorschriftnummer IS NOT NULL',
'ORDER BY ',
'    Land,',
'    Vorschriftennummer'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(7023433742125785783)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>10695646058025174018
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985752378755712554)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>10
,p_column_identifier=>'AE'
,p_column_label=>'<input type="checkbox" id="selectUnselectAll" title="Select/UnselectAll" value="all" />'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_column_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'html exp ',
'',
'<input type="checkbox" value="#SPECIFIC_REG_ID#" />'))
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985751979221712553)
,p_db_column_name=>'ROW_EDIT_LINK'
,p_display_order=>20
,p_column_identifier=>'AG'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985757469589712570)
,p_db_column_name=>'EDIT_ACTION'
,p_display_order=>30
,p_column_identifier=>'M'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985759018966712574)
,p_db_column_name=>'CARD_NUMBER'
,p_display_order=>40
,p_column_identifier=>'G'
,p_column_label=>'Card Number'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985750390536712549)
,p_db_column_name=>'B_NUMMER_LISTE'
,p_display_order=>50
,p_column_identifier=>'A'
,p_column_label=>'B Nummer Liste'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985749988821712549)
,p_db_column_name=>'LAND_NAMEN_LISTE'
,p_display_order=>60
,p_column_identifier=>'B'
,p_column_label=>'Land Namen Liste'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985749524240712548)
,p_db_column_name=>'THEMABEZEICHNUNG'
,p_display_order=>70
,p_column_identifier=>'C'
,p_column_label=>'Themabezeichnung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985749167282712547)
,p_db_column_name=>'VORSCHRIFTENNUMMER'
,p_display_order=>80
,p_column_identifier=>'D'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985759840030712577)
,p_db_column_name=>'ALTERNATIVE_VORSCHRIFTENNUMMER'
,p_display_order=>90
,p_column_identifier=>'E'
,p_column_label=>'Alternative Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985759433419712576)
,p_db_column_name=>'PUBLISHER'
,p_display_order=>100
,p_column_identifier=>'F'
,p_column_label=>'Publisher'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985758706874712573)
,p_db_column_name=>'MANUELLER_EINTRAG'
,p_display_order=>110
,p_column_identifier=>'I'
,p_column_label=>'Eintrag Typ'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P48_BEWERTUNG_ANSICHT = ''ET'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985758286754712572)
,p_db_column_name=>'DELETE_ACTION'
,p_display_order=>120
,p_column_identifier=>'J'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985757901879712571)
,p_db_column_name=>'SPECIFIC_REG_ID'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Specific Vorschrift ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985757016304712569)
,p_db_column_name=>'SEARCH_ID_HIDDEN'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Search Id Hidden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985756673206712568)
,p_db_column_name=>'MILESTONE_HIDDEN'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Milestone Hidden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985756229223712567)
,p_db_column_name=>'LANDIDS_HIDDEN'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Landids Hidden'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985755879238712566)
,p_db_column_name=>'RXSWIN_RELEVANT'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'potentiell SUMS-Relevant'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(958135905312245351)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985755561296712565)
,p_db_column_name=>'LRSA'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'LRSA'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985755160975712563)
,p_db_column_name=>'HOMOLOGATIONSEIGENSCHAFT'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Homologationseigenschaft'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985753952772712559)
,p_db_column_name=>'ET_KOMMENTAR'
,p_display_order=>220
,p_column_identifier=>'Y'
,p_column_label=>'ET Kommentar'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P48_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985754785265712561)
,p_db_column_name=>'ET_VERWENDUNG'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'ET Verwendung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P48_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985754400523712560)
,p_db_column_name=>'ET_VORSCHLAG_VORSCHRIFT'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'ET Vorschlag Vorschrift'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P48_BEWERTUNG_ANSICHT IN (''ET'', ''ANDERE'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985752722024712555)
,p_db_column_name=>'FB_KOMMENTAR'
,p_display_order=>250
,p_column_identifier=>'AB'
,p_column_label=>'FB Kommentar'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P48_BEWERTUNG_ANSICHT IN (''FB'', ''ET'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985753537855712558)
,p_db_column_name=>'FB_VERWENDUNG'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'FB Verwendung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P48_BEWERTUNG_ANSICHT IN (''FB'', ''ET'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985753197874712556)
,p_db_column_name=>'FB_VORSCHLAG_VORSCHRIFT'
,p_display_order=>280
,p_column_identifier=>'AA'
,p_column_label=>'FB Vorschlag Vorschrift'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P48_BEWERTUNG_ANSICHT IN (''FB'', ''ET'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985751540639712553)
,p_db_column_name=>'REGELNUMMER'
,p_display_order=>290
,p_column_identifier=>'AH'
,p_column_label=>'Regelnummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985751135861712552)
,p_db_column_name=>'KRITIKALITAET_VON_REGELNUMMER'
,p_display_order=>300
,p_column_identifier=>'AI'
,p_column_label=>'Kritikalitaet Von Regelnummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985750806831712550)
,p_db_column_name=>'AUSGABE_TEXT_VON_REGELNUMMER'
,p_display_order=>310
,p_column_identifier=>'AJ'
,p_column_label=>'Ausgabe Text Von Regelnummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985748734251712546)
,p_db_column_name=>'LANDIDS'
,p_display_order=>320
,p_column_identifier=>'AK'
,p_column_label=>'Landids'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985748323004712545)
,p_db_column_name=>'NACHFOLGER_VORSCHRIFT'
,p_display_order=>330
,p_column_identifier=>'AL'
,p_column_label=>'Nachfolger Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985747942721712544)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>340
,p_column_identifier=>'AM'
,p_column_label=>'Vorschrift ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985747544619712543)
,p_db_column_name=>'ALTERNATIVE_VORSCHRIFTID'
,p_display_order=>350
,p_column_identifier=>'AO'
,p_column_label=>'Alternative Vorschrift ID'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(4917389214549101696)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5427309'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EDIT_ACTION:DELETE_ACTION:ROW_EDIT_LINK:CARD_NUMBER:SPECIFIC_REG_ID:VORSCHRIFTID:ALTERNATIVE_VORSCHRIFTID:B_NUMMER_LISTE:LAND_NAMEN_LISTE:THEMABEZEICHNUNG:VORSCHRIFTENNUMMER:ALTERNATIVE_VORSCHRIFTENNUMMER:PUBLISHER:LRSA:HOMOLOGATIONSEIGENSCHAFT:NACHF'
||'OLGER_VORSCHRIFT:REGELNUMMER:KRITIKALITAET_VON_REGELNUMMER:AUSGABE_TEXT_VON_REGELNUMMER:RXSWIN_RELEVANT:MANUELLER_EINTRAG:ET_KOMMENTAR:ET_VERWENDUNG:ET_VORSCHLAG_VORSCHRIFT:FB_KOMMENTAR:FB_VERWENDUNG:FB_VORSCHLAG_VORSCHRIFT:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8078928608724045139)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="header-actions" style="display: flex; align-items: center;">',
'    <!-- Status indicator -->',
'    <span id="detailPageStatus" class="status-indicator &P48_CARD_STATUS." ',
'          data-card="&P48_CARD_NUM." ',
'          onclick="cycleDetailStatus(&P48_CARD_NUM.)" ',
unistr('          title="Status \00E4ndern">'),
'        <!-- Status icon  -->',
'    </span>',
'    ',
'    ',
'</div>'))
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(8081013629022956338)
,p_name=>'New'
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>150
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ''Checking parameters:'' as debug_msg,',
'    :P48_LANDIDS as landids_param,',
'    LENGTH(:P48_LANDIDS) as landids_length,',
'    REGEXP_REPLACE(:P48_LANDIDS, '':'', '', '') as landids_formatted,',
'    REGEXP_COUNT(:P48_LANDIDS, '':'') + 1 as landids_count,',
'    :P48_CARD_NUM as card_num_param,',
'    :P48_SEARCH_SELECTION as search_param,',
'    :P48_MILESTONE_SELECTION as milestone_param,',
'',
'    CASE ',
'        WHEN :P48_LANDIDS IS NULL THEN ''NULL''',
'        WHEN TRIM(:P48_LANDIDS) = '''' THEN ''Empty String''',
'        ELSE ''Has Value''',
'    END as landids_status',
'FROM dual'))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(985738633683712511)
,p_query_column_id=>1
,p_column_alias=>'DEBUG_MSG'
,p_column_display_sequence=>10
,p_column_heading=>'Debug Msg'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(985738300812712509)
,p_query_column_id=>2
,p_column_alias=>'LANDIDS_PARAM'
,p_column_display_sequence=>20
,p_column_heading=>'Landids Param'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(985737898522712508)
,p_query_column_id=>3
,p_column_alias=>'LANDIDS_LENGTH'
,p_column_display_sequence=>60
,p_column_heading=>'Landids Length'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(985737419367712508)
,p_query_column_id=>4
,p_column_alias=>'LANDIDS_FORMATTED'
,p_column_display_sequence=>70
,p_column_heading=>'Landids Formatted'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(985737074590712508)
,p_query_column_id=>5
,p_column_alias=>'LANDIDS_COUNT'
,p_column_display_sequence=>80
,p_column_heading=>'Landids Count'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(985736647491712507)
,p_query_column_id=>6
,p_column_alias=>'CARD_NUM_PARAM'
,p_column_display_sequence=>30
,p_column_heading=>'Card Num Param'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(985736268756712507)
,p_query_column_id=>7
,p_column_alias=>'SEARCH_PARAM'
,p_column_display_sequence=>40
,p_column_heading=>'Search Param'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(985735893097712507)
,p_query_column_id=>8
,p_column_alias=>'MILESTONE_PARAM'
,p_column_display_sequence=>50
,p_column_heading=>'Milestone Param'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(985735428761712506)
,p_query_column_id=>9
,p_column_alias=>'LANDIDS_STATUS'
,p_column_display_sequence=>90
,p_column_heading=>'Landids Status'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(985710618715712435)
,p_button_sequence=>50
,p_button_name=>'BACK_TO_OVERVIEW'
,p_button_static_id=>'B1681487548999'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--pillEnd:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Zur\00FCck zur \00DCbersicht')
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-long-arrow-left'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'f?p=&APP_ID.:460:&SESSION.::&DEBUG.:RP,460:P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION,P460_REFRESH_CARDS:&P461_SEARCH_SELECTION.,&P461_MILESTONE_SELECTION.,Y',
'',
'',
'f?p=&APP_ID.:460:&SESSION.::&DEBUG.:RP,460:P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION,P460_REFRESH_CARDS,P460_JUST_UPDATED_CARD,P460_JUST_UPDATED_STATUS:&P461_SEARCH_SELECTION.,&P461_MILESTONE_SELECTION.,Y,&P461_CARD_NUM.,&P461_CARD_STATUS.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(985746828547712526)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_button_name=>'SelectedFilterName'
,p_button_static_id=>'selectedfilter461'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('<b style=" font-size:14px">Ausgew\00E4hlter Filtername</b> <b><u><i><span style="color:#bb0a31; font-size:14px">&P48_FILTER_PROFILE.</span></i></u></b>')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-user-check'
,p_button_comment=>'<b font-size:16px>Selected Filter Name</b> <b><u><i><span style="color:#bb0a31; font-size:16px">&P461_FILTER_PROFILE.</span></i></u></b>'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(985746475331712525)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_button_name=>'DownloadExcelReport'
,p_button_static_id=>'DownloadExcelReport1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Daten herunterladen f\00FCr Aller L\00E4nder Vorschriften')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-download-alt'
,p_button_comment=>'B3485834934459875'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(985746099570712525)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_button_name=>'DownloadExcelReport_1'
,p_button_static_id=>'DownloadExcelReport'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Daten herunterladen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-download-alt'
,p_button_comment=>'B3485834934459875'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(985745708369712524)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Fehlende Vorschrift hinzuf\00FCgen')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:465:&SESSION.::&DEBUG.:465:P465_MODE,P465_MANUAL_MODE,P465_SEARCH_SELECTION,P465_MILESTONE_SELECTION,P465_LANDIDS,P465_CARD_NUM,P465_RETURN_PAGE:CREATE,Y,&P48_SEARCH_SELECTION.,&P48_MILESTONE_SELECTION.,&P48_LANDIDS.,&P48_CARD_NUM.,461'
,p_icon_css_classes=>'fa-gears'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(985745259386712523)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_button_name=>'BTN_MEHRFACHBEARBEITUNG'
,p_button_static_id=>'b_MB'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'ET/FB Bewertungen bearbeiten'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:466:&SESSION.::&DEBUG.:RP,466:P466_LOAD_FROM,P466_SEARCH_SELECTION,P466_MILESTONE_SELECTION,P466_CARD_NUM:"P48_SELECTED_ROWS",&P48_SEARCH_SELECTION.,&P48_MILESTONE_SELECTION.,&P48_CARD_NUM.'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-user-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(985744836105712523)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_button_name=>'BTN_COPY_PERMALINK'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Permalink in Zwischenablage kopieren'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa fa-link'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(985693517224712400)
,p_branch_name=>'Go To Page 465'
,p_branch_action=>'f?p=&APP_ID.:465:&SESSION.::&DEBUG.:465:P465_MODE,P465_MANUAL_MODE,P465_SEARCH_SELECTION,P465_MILESTONE_SELECTION,P465_LANDIDS,P465_CARD_NUM,P465_RETURN_PAGE:CREATE,Y,&P48_SEARCH_SELECTION.,&P48_MILESTONE_SELECTION.,&P48_LANDIDS.,&P48_CARD_NUM.,461'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(985744515818712523)
,p_name=>'P48_CARD_TITLE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CASE ',
'        WHEN COUNT(*) = 1 THEN',
'            MAX(l.B_NUMMER || '' - '' || l.LAND)',
'        ELSE',
'            LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '') ',
'            WITHIN GROUP (ORDER BY l.B_NUMMER)',
'    END AS card_title',
'FROM t_land l',
'WHERE l.LANDID IN (',
'    SELECT TO_NUMBER(column_value)',
'    FROM TABLE(apex_string.split(:P48_LANDIDS, '';''))',
')'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(985744085119712520)
,p_name=>'P48_CARD_STATUS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(985743690256712520)
,p_name=>'P48_LANDIDS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(985743222518712520)
,p_name=>'P48_CARD_NUM'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(985742901581712520)
,p_name=>'P48_SEARCH_SELECTION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(985742422534712519)
,p_name=>'P48_MILESTONE_SELECTION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(985742058677712519)
,p_name=>'P48_STATUS_INDICATOR'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(985741708352712519)
,p_name=>'P48_MSG_TIMEOUT'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(985741243707712519)
,p_name=>'P48_CUSTOM_TITLE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(985740834929712518)
,p_name=>'P48_SELECTED_ROWS'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(985740452213712518)
,p_name=>'P48_PUBLISHER_FILTER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_prompt=>'Publisher'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    publisher as d,',
'    publisher as r',
'FROM (',
'    -- Publishers from alternative regulations',
'    SELECT tv_alt.publisher',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT OUTER JOIN t_vorschrift tv_alt ON (tv_alt.vorschriftid = ms.alternative_vorschriftid)',
'    WHERE ms.sucheid = :P48_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P48_MILESTONE_SELECTION',
'    AND ms.landid IN (',
'        SELECT TO_NUMBER(TRIM(column_value))',
'        FROM TABLE(apex_string.split(TRIM(:P48_LANDIDS), '';''))',
'    )',
'    AND tv_alt.publisher IS NOT NULL',
'    ',
'    UNION',
'    ',
'    -- Publishers from main regulations (for manual entries)',
'    SELECT tv_main.publisher',
'    FROM T_MS_SUCHERGEBNISS ms',
'    LEFT OUTER JOIN t_vorschrift tv_main ON (tv_main.vorschriftid = ms.vorschriftid)',
'    WHERE ms.sucheid = :P48_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P48_MILESTONE_SELECTION',
'    AND ms.landid IN (',
'        SELECT TO_NUMBER(TRIM(column_value))',
'        FROM TABLE(apex_string.split(TRIM(:P48_LANDIDS), '';''))',
'    )',
'    AND tv_main.publisher IS NOT NULL',
')',
'WHERE publisher IS NOT NULL',
'ORDER BY publisher'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Ausw\00E4hlen --')
,p_lov_cascade_parent_items=>'P48_SEARCH_SELECTION,P48_MILESTONE_SELECTION,P48_LANDIDS'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>25
,p_colspan=>2
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:margin-top-none'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    v.publisher as d,',
'    v.publisher as r',
'FROM T_MS_SUCHERGEBNISS ms',
'LEFT OUTER JOIN t_vorschrift tv ON (tv.vorschriftid = ms.alternative_vorschriftid)',
'LEFT OUTER JOIN t_vorschrift v ON (v.vorschriftid = ms.alternative_vorschriftid)',
'WHERE ms.sucheid = :P48_SEARCH_SELECTION ',
'AND ms.meilenstein = :P48_MILESTONE_SELECTION',
'AND ms.landid IN (',
'    SELECT TO_NUMBER(TRIM(column_value))',
'    FROM TABLE(apex_string.split(TRIM(:P48_LANDIDS), '';''))',
')',
'AND v.publisher IS NOT NULL',
'ORDER BY v.publisher'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(985740040892712517)
,p_name=>'P48_BEWERTUNG_ANSICHT'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_item_default=>'ET'
,p_prompt=>'<b>Bewertung Ansicht</b>'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'SELECT display_value as d, return_value as r',
'FROM (',
'    SELECT ''ET-B Abstimmung'' as display_value, ''ET'' as return_value, 1 as sort_order FROM dual',
'    UNION ALL',
'    SELECT ''ET-A Vorschlag'', ''FB'', 2 FROM dual',
'    UNION ALL',
'    SELECT ''ET-G Vorschlag'', ''ANDERE'', 3 FROM dual',
')',
'ORDER BY sort_order'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:margin-top-none:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(985739648904712517)
,p_name=>'P48_PERMALINK'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(5977191245343524109)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.host_url(''SCRIPT'') ||',
'apex_page.get_url(',
'    p_application => :APP_ALIAS,',
'    p_page => ''PRI'',',
'    p_items => ''P48_LANDIDS,P48_CARD_NUM,P48_SEARCH_SELECTION,P48_MILESTONE_SELECTION,P48_CARD_STATUS,P48_FILTER_PROFILE,P48_CUSTOM_TITLE'',',
'    p_values => :P48_LANDIDS || '','' || :P48_CARD_NUM || '','' || :P48_SEARCH_SELECTION || '','' || :P48_MILESTONE_SELECTION || '','' || :P48_CARD_STATUS || '','' || :P48_FILTER_PROFILE || '','' || :P48_CUSTOM_TITLE,',
'    p_session => null,',
'    p_clear_cache => ''461''',
')'))
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.host_url(''SCRIPT'') || apex_page.get_url(',
'    p_application => :APP_ALIAS',
'    , p_page => ''VORSCHRIFT''',
'    , p_items => ''P25_VORSCHRIFTID''',
'    , p_values => :P25_VORSCHRIFTID',
'    , p_session => null',
'    , p_clear_cache => ''25''',
')'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(985710298164712434)
,p_name=>'P48_FILTER_PROFILE'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(985704674856712419)
,p_name=>'Dialog Titel'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(985704176229712415)
,p_event_id=>wwv_flow_imp.id(985704674856712419)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(window.parent.document).find(''.ui-dialog-title'').text($v(''P48_CARD_TITLE''));'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(985703753898712414)
,p_name=>'Back to Overview'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(985710618715712435)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(985703254778712413)
,p_event_id=>wwv_flow_imp.id(985703753898712414)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// // Prevent default button action',
'// this.browserEvent.preventDefault();',
'',
'// // Get the current status reliably from database',
'// apex.server.process(',
'//     ''GET_CURRENT_CARD_STATUS'',',
'//     {',
'//         x01: $v(''P48_CARD_NUM''),',
'//         x02: $v(''P48_SEARCH_SELECTION''),',
'//         x03: $v(''P48_MILESTONE_SELECTION'')',
'//     },',
'//     {',
'//         success: function(data) {',
'//             // Use database status or fallback to current page status',
'//             const currentStatus = data.status || $v(''P48_CARD_STATUS'') || ''not-started'';',
'            ',
'//             console.log(`Returning to overview with status: ${currentStatus}`);',
'            ',
'//             // Build the URL with reliable status',
'//             const url = ''f?p='' + $v(''pFlowId'') + '':460:'' + $v(''pInstance'') + ',
'//                 ''::'' + $v(''pDebug'') + '':RP,460:'' + ',
'//                 ''P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION,P460_REFRESH_CARDS,'' + ',
'//                 ''P460_JUST_UPDATED_CARD,P460_JUST_UPDATED_STATUS:'' + ',
'//                 $v(''P48_SEARCH_SELECTION'') + '','' + ',
'//                 $v(''P48_MILESTONE_SELECTION'') + '','' + ',
'//                 ''Y,'' + ',
'//                 $v(''P48_CARD_NUM'') + '','' + ',
'//                 currentStatus;',
'            ',
'//             // Navigate to the URL',
'//             apex.navigation.redirect(url);',
'//         },',
'//         error: function(xhr, status, error) {',
'//             console.error(''Error getting current status:'', error);',
'            ',
'//             // Fallback to using the page item directly',
'//             const currentStatus = $v(''P48_CARD_STATUS'') || ''not-started'';',
'            ',
'//             const url = ''f?p='' + $v(''pFlowId'') + '':460:'' + $v(''pInstance'') + ',
'//                 ''::'' + $v(''pDebug'') + '':RP,460:'' + ',
'//                 ''P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION,P460_REFRESH_CARDS,'' + ',
'//                 ''P460_JUST_UPDATED_CARD,P460_JUST_UPDATED_STATUS:'' + ',
'//                 $v(''P48_SEARCH_SELECTION'') + '','' + ',
'//                 $v(''P48_MILESTONE_SELECTION'') + '','' + ',
'//                 ''Y,'' + ',
'//                 $v(''P48_CARD_NUM'') + '','' + ',
'//                 currentStatus;',
'            ',
'//             apex.navigation.redirect(url);',
'//         },',
'//         dataType: ''json''',
'//     }',
'// );',
'',
'',
'',
'',
'// Get the current status directly from the page item',
'var currentStatus = apex.item(''P48_CARD_STATUS'').getValue();',
'',
'// Prevent default button action',
'this.browserEvent.preventDefault();',
'',
'// Build the URL manually',
'var url = ''f?p='' + $v(''pFlowId'') + '':460:'' + $v(''pInstance'') + ',
'          ''::'' + $v(''pDebug'') + '':RP,460:'' + ',
'          ''P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION,P460_REFRESH_CARDS,'' + ',
'          ''P460_JUST_UPDATED_CARD,P460_JUST_UPDATED_STATUS:'' + ',
'          $v(''P48_SEARCH_SELECTION'') + '','' + ',
'          $v(''P48_MILESTONE_SELECTION'') + '','' + ',
'          ''Y,'' + ',
'          $v(''P48_CARD_NUM'') + '','' + ',
'          currentStatus;',
'',
'// Navigate to the URL',
'apex.navigation.redirect(url);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(985702900928712413)
,p_name=>'Excel Report 2'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(985746099570712525)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(985702327885712412)
,p_event_id=>wwv_flow_imp.id(985702900928712413)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'downloadCardData($v(''P48_LANDIDS''));'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(985701956338712412)
,p_name=>'Publisher Filter Changed'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P48_PUBLISHER_FILTER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(985701499425712410)
,p_event_id=>wwv_flow_imp.id(985701956338712412)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5977191245343524109)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(985701022517712410)
,p_name=>'Rows Selector'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'td input'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#R45756756756575'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_da_event_comment=>'td input, th input'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(985700545905712409)
,p_event_id=>wwv_flow_imp.id(985701022517712410)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var any_checked = $("#R45756756756575").find("td input:checked").length > 0;',
'',
'if (any_checked) {',
'    $("#b_MB").removeClass("apex_disabled");',
'} else {',
'    $("#b_MB").addClass("apex_disabled");',
'}',
'',
'$("#b_MB").prop(''disabled'', !any_checked);',
'',
'var sel_rows = apex.item(''P48_SELECTED_ROWS'');',
'sel_rows.setValue("");',
'$("#R45756756756575").find("td input:checked").each(function() {',
'  if(sel_rows.getValue().length > 0) {',
'    sel_rows.setValue(sel_rows.getValue() + ":");    ',
'  }',
'  sel_rows.setValue(sel_rows.getValue() + this.value);',
'});'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(985700100420712409)
,p_event_id=>wwv_flow_imp.id(985701022517712410)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P48_SELECTED_ROWS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(985699698847712409)
,p_name=>'Dialog Closed - Page 465'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(5977191245343524109)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId == ''465'''
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(985699198921712408)
,p_event_id=>wwv_flow_imp.id(985699698847712409)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5977191245343524109)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(985698811011712408)
,p_name=>'Mehrfachbearbeitung - Dialog Closed - Page 466'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(5977191245343524109)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId == ''466'''
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(985698217210712407)
,p_event_id=>wwv_flow_imp.id(985698811011712408)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5977191245343524109)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(985697756114712407)
,p_event_id=>wwv_flow_imp.id(985698811011712408)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(985697412417712406)
,p_name=>'hide Mehrfachbearbeitung button'
,p_event_sequence=>80
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(985696846882712405)
,p_event_id=>wwv_flow_imp.id(985697412417712406)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(985745259386712523)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(985696483253712404)
,p_name=>'copy permalink'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(985744836105712523)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(985695989070712404)
,p_event_id=>wwv_flow_imp.id(985696483253712404)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'navigator.clipboard.writeText($v("P48_PERMALINK"));',
'alert(''Der Permalink wurde in die Zwischenablage kopiert:\n\n'' + $v("P48_PERMALINK"));'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(985695528749712404)
,p_name=>'Show / Hide Columns'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P48_BEWERTUNG_ANSICHT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(985695106803712404)
,p_event_id=>wwv_flow_imp.id(985695528749712404)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P48_BEWERTUNG_ANSICHT'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(985694575018712403)
,p_event_id=>wwv_flow_imp.id(985695528749712404)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Store switch value before refresh',
'var switchValue = $v(''P48_BEWERTUNG_ANSICHT'');',
'sessionStorage.setItem(''P48_SWITCH_VALUE'', switchValue);'))
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(985694054844712403)
,p_event_id=>wwv_flow_imp.id(985695528749712404)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5977191245343524109)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(985709817457712430)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Custom XLSX Export - All Countries Result'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_context apex_exec.t_context;',
'    l_print_config    apex_data_export.t_print_config;',
'    l_export apex_data_export.t_export;',
'    l_name VARCHAR2(255);',
'    lTitle varchar2(250);',
'BEGIN',
'    -- Get user name',
'    SELECT b.nachname || '' '' || b.vorname',
'    INTO l_name',
'    FROM t_benutzer b',
'    WHERE benutzerid = :G_BENUTZERID;',
'    ',
'    -- Set title',
unistr('    lTitle := ''Aller L\00E4nder - Vorschriften'';'),
'    ',
'    -- Create query context',
'    l_context := apex_exec.open_query_context(',
'        p_location => apex_exec.c_location_local_db,',
'        p_sql_query => q''[',
'            SELECT DISTINCT ',
'                ms.landnummer||'' - ''||ms.landbezeichnung AS Land,',
'                ms.vorschrifttitel as Vorschrifttitel,',
'                ms.vorschriftnummer as Vorschriftennummer',
'                ',
'                -- ms.status_vorschrift as Status,',
unistr('                -- ms.prognose_qualitaet as Prognose_Qualit\00E4t,'),
'                -- ms.sw_relevant as SW_Relevant,',
'                -- ms.risiko as Risiko',
'            FROM T_MS_SUCHERGEBNISS ms',
'            WHERE ms.sucheid = :P48_SEARCH_SELECTION ',
'            AND ms.meilenstein = :P48_MILESTONE_SELECTION',
'            AND ms.landid IN (',
'                SELECT TO_NUMBER(column_value)',
'                FROM TABLE(apex_string.split(:P48_LANDIDS, '':''))',
'            )',
'            AND ms.vorschriftnummer IS NOT NULL',
'            ORDER BY ',
'                Land,',
'                Vorschriftennummer',
'        ]''',
'    );',
'    ',
'    -- Configure print settings',
'    l_print_config := apex_data_export.get_print_config(',
'        p_page_header => lTitle,',
'        p_header_font_family => ''Audi Type'',',
'        p_header_font_size => 10,',
'        p_body_font_family => ''Audi Type'',',
'        p_body_font_size => 10,',
'        p_border_width => 0.5,',
'        p_page_footer_font_family => ''Audi Type'',',
'        p_page_footer_font_size => 10,',
'        p_header_bg_color => ''#D0D0D0''',
'    );',
'',
'',
'',
'',
'        ',
'    -- Create export',
'    l_export := apex_data_export.export(',
'        p_context => l_context,',
'        p_print_config => l_print_config,',
'        p_format => apex_data_export.c_format_xlsx,',
unistr('        p_file_name => ''Aller L\00E4nder - Vorschriften'' || ''-'' || l_name || ''-'' || TO_CHAR(SYSDATE, ''DD.MM.YYYY HH24:MI:SS'') || ''.xlsx'''),
'    );',
'    ',
'    -- Close context and download',
'    apex_exec.close(l_context);',
'    apex_data_export.download(p_export => l_export);',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_exec.close(l_context);',
'        RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(985746475331712525)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2686502498441675805
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_context apex_exec.t_context;',
'    l_print_config    apex_data_export.t_print_config;',
'    l_export apex_data_export.t_export;',
'    l_name VARCHAR2(255);',
'    lTitle varchar2(250);',
'BEGIN',
'    -- Get user name',
'    SELECT b.nachname || '' '' || b.vorname',
'    INTO l_name',
'    FROM t_benutzer b',
'    WHERE benutzerid = :G_BENUTZERID;',
'',
'    -- Set title',
unistr('    lTitle := ''Aller L\00E4nder - Vorschriften'';'),
'',
'    -- Create query context',
'    l_context := apex_exec.open_query_context(',
'        p_location => apex_exec.c_location_local_db,',
'        p_sql_query => q''[',
'            WITH search_countries AS (',
'                SELECT ',
'                    DISTINCT sucheid,',
'                    to_number(COLUMN_VALUE) as landid',
'                FROM t_suche_json,',
'                TABLE(apex_string.split(',
'                    json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                    '':''',
'                ))',
'                WHERE BENUTZERID = ]'' || v(''G_BENUTZERID'') || q''[',
'            )',
'            SELECT DISTINCT',
'                ms.landnummer||'' - ''||ms.landbezeichnung AS Landbezeichnung,   ',
'                ms.vorschriftnummer as Vorschriftennummer',
'            FROM search_countries sc',
'            LEFT JOIN T_MS_SUCHERGEBNISS ms ON (',
'                ms.sucheid = sc.sucheid ',
'                AND ms.landid = sc.landid',
'                AND sc.landid NOT IN (',
'                    SELECT column_value ',
'                    FROM table(apex_string.split_numbers('']'' || v(''P460_FILTER_LAND'') || q''['', '':''))',
'                )',
'            )',
'            WHERE VORSCHRIFTID IS NOT NULL ',
'            GROUP BY ',
'                ms.vorschriftnummer,',
'                ms.VORSCHRIFTID,',
'                ms.landnummer,',
'                ms.landbezeichnung,',
'                sc.sucheid',
'            ORDER BY ',
'                Landbezeichnung,',
'                Vorschriftennummer',
'        ]''',
'    );',
'',
'    -- Configure print settings',
'    l_print_config := apex_data_export.get_print_config(',
'        p_page_header => lTitle,',
'        p_header_font_family => ''Audi Type'',',
'        p_header_font_size => 10,',
'        p_body_font_family => ''Audi Type'',',
'        p_body_font_size => 10,',
'        p_border_width => 0.5,',
'        p_page_footer_font_family => ''Audi Type'',',
'        p_page_footer_font_size => 10,',
'        p_header_bg_color => ''#D0D0D0''',
'    );',
'        ',
'    -- Create export',
'    l_export := apex_data_export.export(',
'        p_context => l_context,',
'        p_print_config => l_print_config,',
'        p_format => apex_data_export.c_format_xlsx,',
unistr('        p_file_name => ''Aller L\00E4nder - Vorschriften'' || ''-'' || l_name || ''-'' || TO_CHAR(SYSDATE, ''DD.MM.YYYY HH24:MI:SS'') || ''.xlsx'''),
'    );',
'',
'    -- Close context and download',
'    apex_exec.close(l_context);',
'    apex_data_export.download(p_export => l_export);',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_exec.close(l_context);',
'        RAISE;',
'END;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(985707821745712426)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'',
'  :P48_CARD_STATUS := :P48_CARD_STATUS;',
'  :P48_SEARCH_SELECTION := :P48_SEARCH_SELECTION;',
'  :P48_MILESTONE_SELECTION := :P48_MILESTONE_SELECTION;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2686504494153675809
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(985709423503712428)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UPDATE_CARD_STATUS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number       NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_status            VARCHAR2(20) := apex_application.g_x02;',
'    l_search_id         NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_milestone         NUMBER := TO_NUMBER(apex_application.g_x04);',
'    ',
'    l_json_clob         CLOB;',
'    l_milestone_count   PLS_INTEGER;',
'    l_inprogress_count  NUMBER;',
'    l_new_locked_value  NUMBER;',
'',
'BEGIN',
'    -- Step A: Update the status for the specific card',
'    MERGE INTO t_ms_card_status cs',
'    USING (SELECT :G_BENUTZERID as benutzerid, l_card_number as card_number, ',
'             l_search_id as sucheid, l_milestone as meilenstein FROM dual) src',
'    ON (cs.benutzerid = src.benutzerid AND cs.card_number = src.card_number ',
'        AND cs.sucheid = src.sucheid AND cs.meilenstein = src.meilenstein)',
'    WHEN MATCHED THEN',
'        UPDATE SET status = l_status, letzte_aenderung_datum = SYSDATE',
'    WHEN NOT MATCHED THEN',
'        INSERT (benutzerid, card_number, sucheid, meilenstein, status, erstelldatum, letzte_aenderung_datum)',
'        VALUES (src.benutzerid, src.card_number, src.sucheid, src.meilenstein, ',
'                l_status, SYSDATE, SYSDATE);',
'',
'    -- Step B: Determine what the new lock value should be',
'    IF l_status = ''in-progress'' THEN',
'        l_new_locked_value := 1;',
'    ELSE',
'        SELECT COUNT(*) INTO l_inprogress_count',
'        FROM t_ms_card_status',
'        WHERE sucheid = l_search_id',
'          AND meilenstein = l_milestone',
'          AND status = ''in-progress''',
'          AND benutzerid = :G_BENUTZERID;',
'          ',
'        IF l_inprogress_count = 0 THEN',
'            l_new_locked_value := 0;',
'        ELSE',
'            l_new_locked_value := 1;',
'        END IF;',
'    END IF;',
'',
'    -- Step C: Read and rebuild the JSON with the updated LOCKED value',
'    SELECT suchdaten INTO l_json_clob FROM t_suche_json WHERE sucheid = l_search_id;',
'    apex_json.parse(l_json_clob);',
'    apex_json.initialize_clob_output;',
'    apex_json.open_array;',
'    l_milestone_count := apex_json.get_count(p_path => ''.'');',
'    FOR i IN 1..l_milestone_count LOOP',
'        apex_json.open_object;',
'        apex_json.write(''MEILENSTEIN'',       apex_json.get_number(p_path => ''[%d].MEILENSTEIN'', p0 => i));',
'        apex_json.write(''LAENDER'',           apex_json.get_varchar2(p_path => ''[%d].LAENDER'', p0 => i));',
'        apex_json.write(''THEMEN'',            apex_json.get_varchar2(p_path => ''[%d].THEMEN'', p0 => i));',
'        apex_json.write(''LOW_RISK'',          apex_json.get_number(p_path => ''[%d].LOW_RISK'', p0 => i));',
'        apex_json.write(''HIGH_RISK'',         apex_json.get_number(p_path => ''[%d].HIGH_RISK'', p0 => i));',
'        apex_json.write(''CKD_FBU_MODE'',      apex_json.get_number(p_path => ''[%d].CKD_FBU_MODE'', p0 => i));',
'        apex_json.write(''DATUM_SOP'',         apex_json.get_varchar2(p_path => ''[%d].DATUM_SOP'', p0 => i));',
'        apex_json.write(''DATUM_EOP'',         apex_json.get_varchar2(p_path => ''[%d].DATUM_EOP'', p0 => i));',
'        apex_json.write(''DATUM_MEILENSTEIN'', apex_json.get_varchar2(p_path => ''[%d].DATUM_MEILENSTEIN'', p0 => i));',
'        apex_json.write(''SUCHTYP'',           apex_json.get_varchar2(p_path => ''[%d].SUCHTYP'', p0 => i));',
'        apex_json.write(''MJ_ANFANG'',         apex_json.get_varchar2(p_path => ''[%d].MJ_ANFANG'', p0 => i));',
'        apex_json.write(''MJ_ENDE'',           apex_json.get_varchar2(p_path => ''[%d].MJ_ENDE'', p0 => i));',
'        IF apex_json.get_number(p_path => ''[%d].MEILENSTEIN'', p0 => i) = l_milestone THEN',
'            apex_json.write(''LOCKED'', l_new_locked_value);',
'        ELSE',
'            apex_json.write(''LOCKED'', apex_json.get_number(p_path => ''[%d].LOCKED'', p0 => i));',
'        END IF;',
'        apex_json.close_object;',
'    END LOOP;',
'    apex_json.close_array;',
'    l_json_clob := apex_json.get_clob_output;',
'    apex_json.free_output;',
'',
'    -- Step D: Write the updated JSON back to the table',
'    UPDATE t_suche_json SET suchdaten = l_json_clob WHERE sucheid = l_search_id;',
'    COMMIT;',
'',
'    -- Step E: Return a success message',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
'    apex_json.write(''message'', ''Status updated successfully'');',
'    apex_json.close_object;',
'',
'    -- Print the JSON to the output buffer',
'    htp.p(apex_json.get_clob_output); ',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;',
'        -- Also print the JSON error message',
'        htp.p(apex_json.get_clob_output); ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2686502892395675807
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(985705429659712423)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UPDATE_CARD_STATUS_23 jul'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_status VARCHAR2(20) := apex_application.g_x02;',
'    l_search_id NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_milestone NUMBER := TO_NUMBER(apex_application.g_x04);',
'BEGIN',
'    -- Update or insert status in the profile table',
'    MERGE INTO t_ms_card_status cs',
'    USING (SELECT :G_BENUTZERID as benutzerid, l_card_number as card_number, ',
'             l_search_id as sucheid, l_milestone as meilenstein FROM dual) src',
'    ON (cs.benutzerid = src.benutzerid AND cs.card_number = src.card_number ',
'        AND cs.sucheid = src.sucheid AND cs.meilenstein = src.meilenstein)',
'    WHEN MATCHED THEN',
'        UPDATE SET status = l_status, letzte_aenderung_datum = SYSDATE',
'    WHEN NOT MATCHED THEN',
'        INSERT (benutzerid, card_number, sucheid, meilenstein, status, erstelldatum, letzte_aenderung_datum)',
'        VALUES (src.benutzerid, src.card_number, src.sucheid, src.meilenstein, ',
'                l_status, SYSDATE, SYSDATE);',
'                ',
'    -- Explicitly set the page items for the return to page 460',
'    :P48_CARD_STATUS := l_status;',
'    ',
'    -- Also explicitly set these to ensure they are passed back to page 460',
'    :P460_JUST_UPDATED_CARD := l_card_number;',
'    :P460_JUST_UPDATED_STATUS := l_status;',
'                ',
'    -- Return success response',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
'    apex_json.write(''message'', ''Status updated successfully'');',
'    apex_json.close_object;',
'                ',
'    COMMIT;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Return error response',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;',
'        ',
'        ROLLBACK;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2686506886239675812
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(985708618143712427)
,p_process_sequence=>30
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_CURRENT_CARD_STATUS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_search_id NUMBER := TO_NUMBER(apex_application.g_x02);',
'    l_milestone NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_status VARCHAR2(20) := ''not-started'';',
'BEGIN',
'    -- Get status from database',
'    BEGIN',
'        SELECT status INTO l_status',
'        FROM t_ms_card_status',
'        WHERE benutzerid = :G_BENUTZERID',
'        AND card_number = l_card_number',
'        AND sucheid = l_search_id',
'        AND meilenstein = l_milestone;',
'        ',
'',
'        apex_debug.info(''Status found for card %s: %s'', l_card_number, l_status);',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_status := ''not-started'';',
'            apex_debug.info(''No status found for card %s, using default: %s'', l_card_number, l_status);',
'    END;',
'    ',
'    -- Return as JSON',
'    apex_json.open_object;',
'    apex_json.write(''status'', l_status);',
'    apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2686503697755675808
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(985708272455712426)
,p_process_sequence=>40
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_CARD_TITLE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_result VARCHAR2(4000);',
'BEGIN',
'    SELECT',
'        CASE ',
'            WHEN COUNT(*) = 1 THEN',
'                MAX(l.B_NUMMER || '' - '' || l.LAND)',
'            ELSE',
'                LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '') ',
'                WITHIN GROUP (ORDER BY l.B_NUMMER)',
'        END',
'    INTO l_result',
'    FROM t_land l',
'    WHERE l.LANDID IN (',
'        SELECT TO_NUMBER(TRIM(column_value))',
'        FROM TABLE(apex_string.split(TRIM(apex_application.g_x01), '';''))',
'    );',
'    ',
'    apex_json.open_object;',
'    apex_json.write(''card_title'', l_result);',
'    apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2686504043443675809
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(985707017440712425)
,p_process_sequence=>50
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DOWNLOAD_CARD_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_query         CLOB;',
'    l_excel         BLOB;',
'    l_filename      VARCHAR2(4000);',
'    l_name          VARCHAR2(4000);',
'    lTitle          VARCHAR2(4000);',
'    l_landids       VARCHAR2(4000) := apex_application.g_x01;',
'    l_search_id     NUMBER := TO_NUMBER(apex_application.g_x02);',
'    l_milestone     NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_count         NUMBER;',
'BEGIN',
'    -- Get user name',
'    SELECT b.nachname || ''_'' || b.vorname',
'    INTO l_name',
'    FROM t_benutzer b',
'    WHERE benutzerid = :G_BENUTZERID;',
'    ',
'    -- Count the number of selected countries',
'    SELECT COUNT(*)',
'    INTO l_count',
'    FROM t_land l',
'    WHERE l.LANDID IN (',
'        SELECT TO_NUMBER(TRIM(column_value))',
'        FROM TABLE(apex_string.split(TRIM(l_landids), '';''))',
'    );',
'    ',
'    -- Determine title based on the number of countries selected',
'    IF l_count > 15 THEN',
unistr('        lTitle := ''L\00E4nder Vorschriften'';'),
'    ELSIF l_count >= 5 THEN',
'        SELECT LISTAGG(l.B_NUMMER, ''; '') WITHIN GROUP (ORDER BY l.B_NUMMER)',
'        INTO lTitle',
'        FROM t_land l',
'        WHERE l.LANDID IN (',
'            SELECT TO_NUMBER(TRIM(column_value))',
'            FROM TABLE(apex_string.split(TRIM(l_landids), '';''))',
'        );',
'    ELSE',
'        SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '') ',
'               WITHIN GROUP (ORDER BY l.B_NUMMER)',
'        INTO lTitle',
'        FROM t_land l',
'        WHERE l.LANDID IN (',
'            SELECT TO_NUMBER(TRIM(column_value))',
'            FROM TABLE(apex_string.split(TRIM(l_landids), '';''))',
'        );',
'    END IF;',
'    ',
'    -- Get SQL query using page_461_excel_export function',
'    l_query := page_461_excel_export(',
'        p_search_id => l_search_id,',
'        p_milestone => l_milestone,',
'        p_landids => l_landids,',
'        p_card_num => :P48_CARD_NUM,',
'        p_publisher_filter => :P48_PUBLISHER_FILTER,',
'        p_benutzerid => :G_BENUTZERID',
'    );',
'    ',
'    -- Generate Excel using the page_461_excel_export function',
'    l_excel := emano_report.fMakeExcelsingleSheet_page461(',
'        aSheetName => ''Card Details'',',
'        aTitleName => lTitle || '' - Vorschriften'',',
'        aQuery     => l_query',
'    );',
'    ',
'    -- Set filename',
'    l_filename := REPLACE(REPLACE(REPLACE(REPLACE(',
'        lTitle || '' - Vorschriften'' || ''-'' || l_name || ''-'' || ',
'        TO_CHAR(SYSDATE, ''DD.MM.YYYY HH24:MI:SS'') || ''.xlsx'', ',
'        ''/'', ''_''), '':'', ''_''), ''"'', ''_''), CHR(10), ''_'');',
'    ',
'    -- Download file',
'    sys.htp.init;',
'    sys.owa_util.mime_header(''application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'', FALSE);',
'    sys.htp.p(''Content-Length: '' || DBMS_LOB.GETLENGTH(l_excel));',
'    sys.htp.p(''Content-Disposition: attachment; filename="'' || l_filename || ''"'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(l_excel);',
'    apex_application.stop_apex_engine;',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        htp.p(''Error generating Excel file: '' || SQLERRM);',
'        apex_debug.error(''Excel Download Error: '' || SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2686505298458675810
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(985705017311712422)
,p_process_sequence=>60
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DOWNLOAD_CARD_DATA_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_query         CLOB;',
'    l_excel         BLOB;',
'    l_filename      VARCHAR2(4000);',
'    l_name          VARCHAR2(4000);',
'    lTitle          VARCHAR2(4000);',
'    l_landids       VARCHAR2(4000) := apex_application.g_x01;',
'    l_formatted_landids VARCHAR2(4000);',
'    l_count         NUMBER;',
'BEGIN',
'',
'',
'    -- Convert semicolons to colons for processing',
'    l_formatted_landids := REPLACE(l_landids, '';'', '':'');',
'    ',
'    -- Get user name',
'    SELECT b.nachname || ''_'' || b.vorname',
'      INTO l_name',
'      FROM t_benutzer b',
'     WHERE benutzerid = :G_BENUTZERID;',
'',
'    -- Count the number of selected countries',
'    SELECT COUNT(*)',
'      INTO l_count',
'      FROM t_land l',
'     WHERE l.LANDID IN (',
'           SELECT TO_NUMBER(COLUMN_VALUE)',
'             FROM TABLE(apex_string.split(l_formatted_landids, '':''))',
'     );',
'',
'    -- Determine title based on the number of countries selected',
'    IF l_count > 15 THEN',
'        -- More than 15 countries: use a general title',
unistr('        lTitle := ''L\00E4nder Vorschriften'';'),
'    ELSIF l_count >= 5 THEN',
'        -- Between 5 and 15 countries: use only B_NUMMER',
'        SELECT LISTAGG(l.B_NUMMER, ''; '') WITHIN GROUP (ORDER BY l.B_NUMMER)',
'          INTO lTitle',
'          FROM t_land l',
'         WHERE l.LANDID IN (',
'               SELECT TO_NUMBER(COLUMN_VALUE)',
'                 FROM TABLE(apex_string.split(l_formatted_landids, '':''))',
'         );',
'    ELSE',
'        -- Fewer than 5 countries: use B_NUMMER and the country name',
'        SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '') WITHIN GROUP (ORDER BY l.B_NUMMER)',
'          INTO lTitle',
'          FROM t_land l',
'         WHERE l.LANDID IN (',
'               SELECT TO_NUMBER(COLUMN_VALUE)',
'                 FROM TABLE(apex_string.split(l_formatted_landids, '':''))',
'         );',
'    END IF;',
'',
'    -- Get SQL query with EXCEL format',
'    l_query := country_vorschrift_card_detail(',
'                 p_search_id => :P48_SEARCH_SELECTION,',
'                 p_milestone => :P48_MILESTONE_SELECTION,',
'                 p_landid    => l_formatted_landids,',
'                 p_format    => ''EXCEL''',
'               );',
'',
'    -- Generate Excel using emano_report',
'    l_excel := emano_report.fMakeExcelsingleSheet_land(',
'                   aSheetName => ''3MS Gefilterte Ergebnisse'',',
'                   aTitleName => lTitle || '' - Vorschriften'',',
'                   aQuery     => l_query',
'               );',
'',
'    -- Set filename',
'    l_filename := lTitle || '' - Vorschriften'' || ''-'' || l_name || ''-'' ||',
'                  TO_CHAR(SYSDATE, ''DD.MM.YYYY HH24:MI:SS'') || ''.xlsx'';',
'',
'    -- Download file',
'    sys.htp.init;',
'    sys.owa_util.mime_header(''application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'', FALSE);',
'    sys.htp.p(''Content-Length: '' || DBMS_LOB.GETLENGTH(l_excel));',
'    sys.htp.p(''Content-Disposition: attachment; filename="'' || l_filename || ''"'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(l_excel);',
'',
'    apex_application.stop_apex_engine;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        htp.p(''Error: '' || SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2686507298587675813
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(985706646428712424)
,p_process_sequence=>70
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_CARD_TITLE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_title VARCHAR2(200) := apex_application.g_x02;',
'    l_action VARCHAR2(20) := apex_application.g_x03;',
'    l_country_list CLOB;',
'    l_landids VARCHAR2(4000);',
'BEGIN',
'    -- Get the landids for this card to construct the original title',
'    BEGIN',
'        SELECT LISTAGG(landid, '':'') WITHIN GROUP (ORDER BY landid)',
'        INTO l_landids',
'        FROM t_ms_suche_split',
'        WHERE card_number = l_card_number',
'        AND ROWNUM = 1;',
'    ',
'        -- Get the original country list',
'        SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '') ',
'               WITHIN GROUP (ORDER BY l.B_NUMMER)',
'        INTO l_country_list',
'        FROM t_land l',
'        WHERE l.LANDID IN (',
'            SELECT TO_NUMBER(COLUMN_VALUE)',
'            FROM TABLE(apex_string.split(l_landids, '':''))',
'        );',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_country_list := '''';',
'    END;',
'    ',
'    -- Update title based on action',
'    IF l_action = ''RESET'' OR l_title IS NULL OR l_title = '''' THEN',
'        -- Reset to default - set to NULL',
'        UPDATE t_ms_suche_split',
'        SET custom_card_title = NULL',
'        WHERE card_number = l_card_number',
'        AND benutzerid = :G_BENUTZERID;',
'    ELSE',
'        -- Set to custom title',
'        UPDATE t_ms_suche_split',
'        SET custom_card_title = l_title',
'        WHERE card_number = l_card_number',
'        AND benutzerid = :G_BENUTZERID;',
'    END IF;',
'    ',
'    COMMIT;',
'    ',
'    -- JSON response',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
'    apex_json.write(''message'', ''Title updated successfully'');',
'    apex_json.write(''original_title'', l_country_list);',
'    apex_json.close_object;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Return error as JSON',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;     ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2686505669470675811
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(985706314208712424)
,p_process_sequence=>80
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_CARD_CUSTOM_TITLE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_custom_title VARCHAR2(200);',
'BEGIN',
'    -- Get the custom title for this card',
'    BEGIN',
'        SELECT custom_card_title ',
'        INTO l_custom_title',
'        FROM t_ms_suche_split',
'        WHERE card_number = l_card_number',
'        AND ROWNUM = 1',
'        AND custom_card_title IS NOT NULL;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_custom_title := NULL;',
'    END;',
'    ',
'    -- Return as JSON response',
'    apex_json.open_object;',
'    apex_json.write(''custom_title'', l_custom_title);',
'    apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2686506001690675811
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(985709077451712427)
,p_process_sequence=>90
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UPDATE_CARD_STATUS_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_status VARCHAR2(20) := apex_application.g_x02;',
'    l_search_id NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_milestone NUMBER := TO_NUMBER(apex_application.g_x04);',
'BEGIN',
'    -- Update or insert status in the profile table',
'    MERGE INTO t_ms_card_status cs',
'    USING (SELECT :G_BENUTZERID as benutzerid, l_card_number as card_number, ',
'                 l_search_id as sucheid, l_milestone as meilenstein FROM dual) src',
'    ON (cs.benutzerid = src.benutzerid AND cs.card_number = src.card_number ',
'        AND cs.sucheid = src.sucheid AND cs.meilenstein = src.meilenstein)',
'    WHEN MATCHED THEN',
'        UPDATE SET status = l_status, letzte_aenderung_datum = SYSDATE',
'    WHEN NOT MATCHED THEN',
'        INSERT (benutzerid, card_number, sucheid, meilenstein, status, erstelldatum, letzte_aenderung_datum)',
'        VALUES (src.benutzerid, src.card_number, src.sucheid, src.meilenstein, ',
'                l_status, SYSDATE, SYSDATE);',
'                ',
'    -- Return success response',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
'    apex_json.write(''message'', ''Status updated successfully'');',
'    apex_json.close_object;',
'                ',
'    COMMIT;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Return error response',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;',
'        ',
'        ROLLBACK;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2686503238447675808
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(985707430954712425)
,p_process_sequence=>100
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DOWNLOAD_CARD_DATA-Colons'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_query         CLOB;',
'    l_excel         BLOB;',
'    l_filename      VARCHAR2(4000);',
'    l_name          VARCHAR2(4000);',
'    lTitle          VARCHAR2(4000);',
'    l_landids       VARCHAR2(4000) := apex_application.g_x01;',
'    l_count         NUMBER;',
'BEGIN',
'    -- Get user name',
'    SELECT b.nachname || ''_'' || b.vorname',
'      INTO l_name',
'      FROM t_benutzer b',
'     WHERE benutzerid = :G_BENUTZERID;',
'',
'    -- Count the number of selected countries',
'    SELECT COUNT(*)',
'      INTO l_count',
'      FROM t_land l',
'     WHERE l.LANDID IN (',
'           SELECT TO_NUMBER(COLUMN_VALUE)',
'             FROM TABLE(apex_string.split(l_landids, '';'')) -- :',
'     );',
'',
'    -- Determine title based on the number of countries selected',
'    IF l_count > 15 THEN',
'        -- More than 15 countries: use a general title',
unistr('        lTitle := ''L\00E4nder Vorschriften'';'),
'    ELSIF l_count >= 5 THEN',
'        -- Between 5 and 15 countries: use only B_NUMMER',
'        SELECT LISTAGG(l.B_NUMMER, ''; '') WITHIN GROUP (ORDER BY l.B_NUMMER)',
'          INTO lTitle',
'          FROM t_land l',
'         WHERE l.LANDID IN (',
'               SELECT TO_NUMBER(COLUMN_VALUE)',
'                 FROM TABLE(apex_string.split(l_landids, '';''))  -- :',
'         );',
'    ELSE',
'        -- Fewer than 5 countries: use B_NUMMER and the country name',
'        SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '') WITHIN GROUP (ORDER BY l.B_NUMMER)',
'          INTO lTitle',
'          FROM t_land l',
'         WHERE l.LANDID IN (',
'               SELECT TO_NUMBER(COLUMN_VALUE)',
'                 FROM TABLE(apex_string.split(l_landids, '';'')) -- :',
'         );',
'    END IF;',
'',
'    -- Get SQL query with EXCEL format',
'    l_query := country_vorschrift_card_detail(',
'                 p_search_id => :P48_SEARCH_SELECTION,',
'                 p_milestone => :P48_MILESTONE_SELECTION,',
'                 p_landid    => l_landids,',
'                 p_format    => ''EXCEL''',
'               );',
'',
'    -- Generate Excel using emano_report',
'    l_excel := emano_report.fMakeExcelsingleSheet_land(',
'                   aSheetName => ''3MS Gefilterte Ergebnisse'',',
'                   aTitleName => lTitle || '' - Vorschriften'',',
'                   aQuery     => l_query',
'               );',
'',
'    -- Set filename',
'    l_filename := lTitle || '' - Vorschriften'' || ''-'' || l_name || ''-'' ||',
'                  TO_CHAR(SYSDATE, ''DD.MM.YYYY HH24:MI:SS'') || ''.xlsx'';',
'',
'    -- Download file',
'    sys.htp.init;',
'    sys.owa_util.mime_header(''application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'', FALSE);',
'    sys.htp.p(''Content-Length: '' || DBMS_LOB.GETLENGTH(l_excel));',
'    sys.htp.p(''Content-Disposition: attachment; filename="'' || l_filename || ''"'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(l_excel);',
'',
'    apex_application.stop_apex_engine;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        htp.p(''Error: '' || SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2686504884944675810
,p_process_comment=>'R45756756756575'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(985705837829712423)
,p_process_sequence=>110
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DELETE_MANUAL_ENTRY'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_search_id NUMBER := TO_NUMBER(apex_application.g_x02);',
'    l_milestone NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_specific_reg_id NUMBER := TO_NUMBER(apex_application.g_x04);',
'    l_count NUMBER;',
'BEGIN',
'    -- Check if it''s a manual entry',
'    SELECT COUNT(*)',
'    INTO l_count',
'    FROM T_MS_SUCHERGEBNISS ms',
'    WHERE ms.SUCHEID = l_search_id',
'    AND ms.MEILENSTEIN = l_milestone',
'    AND ms.MANUELLER_EINTRAG = 10',
'    AND CASE ',
'        WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'        ELSE ms.VORSCHRIFTID',
'    END = l_specific_reg_id',
'    AND ms.LANDID IN (',
'        SELECT LANDID ',
'        FROM T_MS_SUCHE_SPLIT ',
'        WHERE CARD_NUMBER = l_card_number',
'        AND BENUTZERID = :G_BENUTZERID',
'    );',
'    ',
'    IF l_count = 0 THEN',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
unistr('        apex_json.write(''message'', ''Nur manuelle Eintr\00E4ge k\00F6nnen gel\00F6scht werden'');'),
'        apex_json.close_object;',
'        RETURN;',
'    END IF;',
'    ',
'    -- Delete only the specific regulation from T_MS_SUCHERGEBNISS',
'    DELETE FROM T_MS_SUCHERGEBNISS',
'    WHERE SUCHEID = l_search_id',
'    AND MEILENSTEIN = l_milestone',
'    AND MANUELLER_EINTRAG = 10',
'    AND CASE ',
'        WHEN ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ALTERNATIVE_VORSCHRIFTID',
'        ELSE VORSCHRIFTID',
'    END = l_specific_reg_id',
'    AND LANDID IN (',
'        SELECT LANDID ',
'        FROM T_MS_SUCHE_SPLIT ',
'        WHERE CARD_NUMBER = l_card_number',
'        AND BENUTZERID = :G_BENUTZERID',
'    );',
'    ',
'    -- Check if this was the last regulation for this card',
'    SELECT COUNT(*)',
'    INTO l_count',
'    FROM T_MS_SUCHERGEBNISS ms',
'    WHERE EXISTS (',
'        SELECT 1',
'        FROM T_MS_SUCHE_SPLIT split',
'        WHERE split.CARD_NUMBER = l_card_number',
'        AND split.BENUTZERID = :G_BENUTZERID',
'        AND split.SUCHEID = ms.SUCHEID',
'        AND split.MEILENSTEIN = ms.MEILENSTEIN',
'        AND split.LANDID = ms.LANDID',
'    );',
'    ',
'    -- If no more regulations for this card, delete the split records too',
'    IF l_count = 0 THEN',
'        DELETE FROM T_MS_SUCHE_SPLIT',
'        WHERE CARD_NUMBER = l_card_number',
'        AND BENUTZERID = :G_BENUTZERID;',
'    END IF;',
'    ',
'    COMMIT;',
'    ',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
unistr('    apex_json.write(''message'', ''Eintrag erfolgreich gel\00F6scht'');'),
'    apex_json.close_object;',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2686506478069675812
);
wwv_flow_imp.component_end;
end;
/
