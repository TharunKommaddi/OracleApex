prompt --application/pages/page_00180
begin
--   Manifest
--     PAGE: 00180
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>180
,p_name=>'Jira Tickets'
,p_alias=>'JIRA-TICKETS'
,p_step_title=>'Jira Tickets'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(581754485142809337)
,p_plug_name=>'Jira Tickets'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select m.JIRA_MFVID,',
'    m.Mfv_name, m.MFV_teil,',
'    m.MFV_Thema, m.Beteiligte_OES, ',
'    m.Status_Umgebung, m.AK_kurz, m.jira_key,',
'    listagg(distinct joe.assignee,  '', '') within group (order by joe.assignee) as oe_leiter,',
'    listagg(distinct js.schlagwort,  '', '') within group (order by js.schlagwort) as schlagwort',
'from T_JIRA_MFV m',
' join T_JIRA_MFV_SCHLAGWORT js on (m.JIRA_MFVID = js.JIRA_MFVID)',
' join T_JIRA_MFV_OE_LEITER  joe on(m.JIRA_MFVID  = joe.JIRAID_AUS_MFV)',
' group by m.JIRA_MFVID ',
' , m.Mfv_name, m.MFV_teil,',
'    m.MFV_Thema, m.Beteiligte_OES, ',
'    m.Status_Umgebung, m.AK_kurz, m.jira_key;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_page_header=>'Jira Tickets'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(581754344994809337)
,p_name=>'Jira Tickets'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>530938592100325067
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(581753987153809327)
,p_db_column_name=>'JIRA_MFVID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Jira Mfvid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(581753556815809320)
,p_db_column_name=>'MFV_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Mfv Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(581753197529809319)
,p_db_column_name=>'MFV_TEIL'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Mfv Teil'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(581752813016809319)
,p_db_column_name=>'MFV_THEMA'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Mfv Thema'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(581752392058809318)
,p_db_column_name=>'BETEILIGTE_OES'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Beteiligte OE'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(581751971034809318)
,p_db_column_name=>'STATUS_UMGEBUNG'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Status Umgebung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(581751604431809318)
,p_db_column_name=>'AK_KURZ'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Arbeitskreis'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(581751159279809318)
,p_db_column_name=>'JIRA_KEY'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Jira Key'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(591079119889850454)
,p_db_column_name=>'OE_LEITER'
,p_display_order=>18
,p_column_identifier=>'I'
,p_column_label=>'OE Leiter'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(581726214224660003)
,p_db_column_name=>'SCHLAGWORT'
,p_display_order=>28
,p_column_identifier=>'J'
,p_column_label=>'Schlagwort'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(581749162542781505)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5309438'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JIRA_MFVID:MFV_NAME:MFV_TEIL:MFV_THEMA:BETEILIGTE_OES:STATUS_UMGEBUNG:AK_KURZ:JIRA_KEY:OE_LEITER:SCHLAGWORT'
);
wwv_flow_imp.component_end;
end;
/
