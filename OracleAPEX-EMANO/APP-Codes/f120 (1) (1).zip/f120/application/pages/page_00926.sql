prompt --application/pages/page_00926
begin
--   Manifest
--     PAGE: 00926
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>926
,p_name=>unistr('Ansprechpartner bearbeiten/hinzuf\00FCgen')
,p_alias=>'ANSPRECHPARTNER-BEARBEITEN'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Ansprechpartner bearbeiten/hinzuf\00FCgen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>unistr('var htmldb_delete_message=''"M\00F6chten Sie den Ansprechpartner l\00F6schen?"'';')
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3969054159116384123)
,p_plug_name=>'Ansprechpartner'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_ANSPRECHPARTNER'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3969054909297384123)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(448289399645572073)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3969054159116384123)
,p_button_name=>'P926_LDAP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'LDAP-Suche'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:65:&SESSION.::&DEBUG.:65:P65_CAMEFROM:926'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(448234351094049234)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3969054909297384123)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(448288998578572069)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3969054909297384123)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P926_ANSPRECHPARTNERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(448133616821049233)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(3969054909297384123)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Speichern & Schlie\00DFen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(448289927567572078)
,p_name=>'P926_GID'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(3969054159116384123)
,p_prompt=>'GID'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>3
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(448289810543572077)
,p_name=>'P926_R_VKO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(3969054159116384123)
,p_prompt=>'Rolle R-VKO'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Rolle R-VKO;10'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(448289719490572076)
,p_name=>'P926_SPOC'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(3969054159116384123)
,p_prompt=>'Rolle SPOC'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Rolle SPOC;10'
,p_begin_on_new_line=>'N'
,p_grid_column=>3
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(448289571818572075)
,p_name=>'P926_CLUSTER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(3969054159116384123)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_clusterids varchar2(4000);',
'begin',
'    select LISTAGG(kc.konzern_clusterid, '':'') WITHIN GROUP (ORDER BY bezeichnung)',
'    into l_clusterids',
'    from t_konzern_cluster kc',
'    join t_ansprechpartner_ref_konzern_cluster ref on kc.konzern_clusterid = ref.konzern_clusterid',
'    where ref.ansprechpartnerid = :P926_ANSPRECHPARTNERID;',
'    return l_clusterids;',
'end;    '))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Cluster'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung d, konzern_clusterid s',
'from t_konzern_cluster',
'order by d'))
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(448289445570572074)
,p_name=>'P926_IMPORTEURID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(3969054159116384123)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(447283554792940503)
,p_name=>'P926_ANSPRECHPARTNERID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3969054159116384123)
,p_item_source_plug_id=>wwv_flow_imp.id(3969054159116384123)
,p_source=>'ANSPRECHPARTNERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(447283403354940501)
,p_name=>'P926_NACHNAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(3969054159116384123)
,p_item_source_plug_id=>wwv_flow_imp.id(3969054159116384123)
,p_prompt=>'Nachname'
,p_source=>'NACHNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>50
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(447283244065940500)
,p_name=>'P926_VORNAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(3969054159116384123)
,p_item_source_plug_id=>wwv_flow_imp.id(3969054159116384123)
,p_prompt=>'Vorname'
,p_source=>'VORNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>50
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(447283079314940498)
,p_name=>'P926_EMAIL_ADRESSE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(3969054159116384123)
,p_item_source_plug_id=>wwv_flow_imp.id(3969054159116384123)
,p_prompt=>'E-Mail-Adresse'
,p_source=>'EMAIL_ADRESSE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(380765536838058799)
,p_name=>'P926_TELEFON'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(3969054159116384123)
,p_prompt=>'Telefon'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327612144865252377)
,p_name=>'P926_KOMMENTAR'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(3969054159116384123)
,p_prompt=>'Kommentar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(429933016065891595)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(448234351094049234)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(429932852680891594)
,p_event_id=>wwv_flow_imp.id(429933016065891595)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(401855372474284861)
,p_name=>'Dialog closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(448289399645572073)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401855186792284859)
,p_event_id=>wwv_flow_imp.id(401855372474284861)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P926_NACHNAME := :P65_NACHNAME_AUSGEWAEHLT;',
':P926_VORNAME := :P65_VORNAME_AUSGEWAEHLT;',
':P926_EMAIL_ADRESSE := :P65_EMAIL_AUSGEWAEHLT;',
':P926_GID := :P65_GID_CHOSEN;'))
,p_attribute_03=>'P926_NACHNAME,P926_VORNAME,P926_GID,P926_EMAIL_ADRESSE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(448131838298049232)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_rvko number := :P926_R_VKO;',
'    l_spoc number := :P926_SPOC;',
'begin',
'    if l_rvko is null then',
'        l_rvko := 20;',
'    end if;',
'    if l_spoc is null then',
'        l_spoc := 20;',
'    end if;',
'    ',
'if :P926_ANSPRECHPARTNERID is null then',
'    insert into T_ANSPRECHPARTNER (nachname, vorname, gid, importeurid, email_adresse, r_vko, spoc, telefon, LETZTE_AENDERUNG_DATUM, LETZTE_AENDERUNG_BENUTZER_ID, kommentar)',
'    values (:P926_NACHNAME, :P926_VORNAME, :P926_GID, :P926_IMPORTEURID, :P926_EMAIL_ADRESSE, l_rvko, l_spoc, :P926_TELEFON, sysdate, PCK_RI.fGetUserId, :P926_KOMMENTAR)',
'    returning ansprechpartnerid into :P926_ANSPRECHPARTNERID;',
'else',
'    update T_ANSPRECHPARTNER',
'    set nachname = :P926_NACHNAME,',
'    vorname = :P926_VORNAME,',
'    gid = :P926_GID,',
'    importeurid = :P926_IMPORTEURID,',
'    email_adresse = :P926_EMAIL_ADRESSE,',
'    r_vko = l_rvko,',
'    spoc = l_spoc,',
'    telefon = :P926_TELEFON,',
'    LETZTE_AENDERUNG_DATUM = sysdate,',
'    LETZTE_AENDERUNG_BENUTZER_ID = PCK_RI.fGetUserId,',
'    kommentar = :P926_KOMMENTAR',
'    where ANSPRECHPARTNERID = :P926_ANSPRECHPARTNERID;',
'    ',
'    delete from t_ansprechpartner_ref_konzern_cluster ',
'    where ansprechpartnerid = :P926_ANSPRECHPARTNERID;',
'',
'end if;',
'    insert into t_ansprechpartner_ref_konzern_cluster (ansprechpartnerid, konzern_clusterid)',
'    select :P926_ANSPRECHPARTNERID, column_value from apex_string.split(:P926_CLUSTER, '':'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(448133616821049233)
,p_process_success_message=>'Die Daten wurden gespeichert.'
,p_internal_uid=>3224080477601339003
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(448288895880572068)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from t_ansprechpartner_ref_konzern_cluster',
'where ansprechpartnerid = :P926_ANSPRECHPARTNERID;',
'',
'delete from t_ansprechpartner',
'where ansprechpartnerid = :P926_ANSPRECHPARTNERID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(448288998578572069)
,p_internal_uid=>3223923420018816167
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(448130641463049231)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3224081674436339004
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(448132272311049232)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Initialize form Ansprechpartner bearbeiten/hinzuf\00FCgen')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P926_ANSPRECHPARTNERID is not null then',
'    select nachname, vorname, email_adresse, gid, r_vko, spoc, kommentar',
'    into :P926_NACHNAME, :P926_VORNAME, :P926_EMAIL_ADRESSE, :P926_GID, :P926_R_VKO, :P926_SPOC, :P926_KOMMENTAR',
'    from t_ANSPRECHPARTNER',
'    where ANSPRECHPARTNERID = :P926_ANSPRECHPARTNERID;',
'    if :P926_R_VKO = 20 then',
'        :P926_R_VKO := null;',
'    end if;',
'    if :P926_SPOC = 20 then',
'        :P926_SPOC := null;',
'    end if;',
'    select listagg(konzern_clusterid, '':'') within group (order by konzern_clusterid) ',
'    into :P926_CLUSTER',
'    from t_ansprechpartner_ref_konzern_cluster',
'    where ansprechpartnerid = :P926_ANSPRECHPARTNERID;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3224080043588339003
);
wwv_flow_imp.component_end;
end;
/
