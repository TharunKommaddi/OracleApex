prompt --application/pages/page_00160
begin
--   Manifest
--     PAGE: 00160
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>160
,p_name=>'Hilfe'
,p_step_title=>'Hilfe'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2684487638751686889)
,p_plug_name=>'Hilfstexte  <span onclick="redirect(1200)" class="fa fa-question-square-o"></span>'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    "ROWID", ',
'    hilfeid,',
'    "TITEL",',
'    "TOOLTIP",',
'   -- dbms_lob.substr("HILFETEXT", 2000, 1) "HILFETEXT",',
'    substr(HILFETEXT, 1, 2000)  "HILFETEXT",',
'    "TITEL_ENGLISCH",',
'    "TOOLTIP_ENGLISCH",',
'   -- dbms_lob.substr("HILFETEXT_ENGLISCH", 2000, 1) "HILFETEXT_ENGLISCH",',
'    substr(HILFETEXT_ENGLISCH, 1, 2000) "HILFETEXT_ENGLISCH",',
'    ''<a href="'' || url_video || ''" target="_blank">'' || URL_VIDEO || ''</a>'' AS url_video,',
'    (SELECT Titel FROM T_HILFE WHERE hilfeid = h.BASISEINTRAGID) Basiseintrag',
'FROM "#OWNER#"."T_HILFE" h;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_col_allignments=>'CENTER : : : '
,p_plug_query_number_formats=>'<url>f?p=#APP_ID#\58165\58#APP_SESSION#\58\58\58\58P165_ROWID\58#ROWID#</url><txt><img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit"></txt>: : : : '
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2683383529383290839)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:166:&SESSION.::&DEBUG.:RP,166:P166_HILFEID:#HILFEID#'
,p_detail_link_text=>'<span class="fa fa-pencil" aria-hidden="true"></span>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>194036963425018603
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2683383597910290840)
,p_db_column_name=>'ROWID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Rowid'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1455206840511506578)
,p_db_column_name=>'HILFEID'
,p_display_order=>20
,p_column_identifier=>'F'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2683383755670290841)
,p_db_column_name=>'TITEL'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Titel'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXISTS'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual',
'where :FSP_LANGUAGE_PREFERENCE = ''de'''))
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2683383772794290842)
,p_db_column_name=>'TOOLTIP'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Tooltip'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXISTS'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual',
'where :FSP_LANGUAGE_PREFERENCE = ''de'''))
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2683384000423290844)
,p_db_column_name=>'URL_VIDEO'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'URL Video'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(370182670918936065)
,p_db_column_name=>'BASISEINTRAG'
,p_display_order=>70
,p_column_identifier=>'I'
,p_column_label=>'Referenzeintrag'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(962881167044665179)
,p_db_column_name=>'TITEL_ENGLISCH'
,p_display_order=>80
,p_column_identifier=>'M'
,p_column_label=>'Titel'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXISTS'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual',
'where :FSP_LANGUAGE_PREFERENCE = ''en'''))
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(962881102695665178)
,p_db_column_name=>'TOOLTIP_ENGLISCH'
,p_display_order=>90
,p_column_identifier=>'N'
,p_column_label=>'Tooltip'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXISTS'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual',
'where :FSP_LANGUAGE_PREFERENCE = ''en'''))
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(669153836101068782)
,p_db_column_name=>'HILFETEXT'
,p_display_order=>100
,p_column_identifier=>'P'
,p_column_label=>'Hilfetext'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_rpt_show_filter_lov=>'N'
,p_display_condition_type=>'EXISTS'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dual',
'where :FSP_LANGUAGE_PREFERENCE = ''de'''))
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(669153601086068780)
,p_db_column_name=>'HILFETEXT_ENGLISCH'
,p_display_order=>110
,p_column_identifier=>'Q'
,p_column_label=>'Hilfetext Englisch'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2684503060730699331)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1951565'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'HILFEID:TITEL:TOOLTIP:TITEL_ENGLISCH:TOOLTIP_ENGLISCH:URL_VIDEO:BASISEINTRAG'
,p_sort_column_1=>'HILFEID'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(212980585679029301)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2684487638751686889)
,p_button_name=>'HILFEBILDER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Hilfebilder bearbeiten'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:190:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2684492381886686906)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2684487638751686889)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Eintrag hinzuf\00FCgen')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:166:&SESSION.::&DEBUG.:166::'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2684491536443686904)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2684487638751686889)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2684492013468686905)
,p_event_id=>wwv_flow_imp.id(2684491536443686904)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2684487638751686889)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2684492783076686906)
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2684492381886686906)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2684493287544686906)
,p_event_id=>wwv_flow_imp.id(2684492783076686906)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2684487638751686889)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
