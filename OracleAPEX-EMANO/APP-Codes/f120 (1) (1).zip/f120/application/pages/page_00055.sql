prompt --application/pages/page_00055
begin
--   Manifest
--     PAGE: 00055
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>55
,p_name=>'Benutzer bearbeiten'
,p_alias=>'BENUTZER-BEARBEITEN'
,p_page_mode=>'MODAL'
,p_step_title=>'Benutzer bearbeiten'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>unistr('var htmldb_delete_message=''"M\00F6chten sie den Nutzer l\00F6schen?"'';')
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.apex-item-single-checkbox input:checked+.u-checkbox, .apex-item-single-checkbox input:checked+label, .u-checkbox.is-checked {',
'    --a-checkbox-background-color: #bb0a31 !important;',
'    --a-checkbox-text-color: var(--a-checkbox-checked-text-color);',
'    border-color: black !important;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_comment=>'a'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(2089620034116146173)
,p_name=>unistr('Zugeordnete L\00E4nder')
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_new_grid_column=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_benutzer as (select benutzerid ',
'                     from t_benutzer',
'                     where rowid = :P55_ROWID),',
'cte_land as (select l.landid, ',
'            CASE ',
'                WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.LAND',
'                ELSE l.LAND_ENG',
'            END as land',
'             from t_benutzer_ref_land ref',
'             join t_land l on l.landid = ref.landid',
'             join cte_benutzer b on b.benutzerid = ref.benutzerid),',
'cte_hap as (select b. benutzerid, nachname, vorname, l.landid',
'            from t_benutzer_ref_land ref',
'            join t_benutzer b on b.benutzerid = ref.benutzerid',
'            join cte_land l on l.landid = ref.landid ',
'            where haupt_ansprechpartner = 10)',
'select distinct benutzer_ref_landid, ref.benutzerid, 2 as link, land, case haupt_ansprechpartner when 10 then emano_util.fLang(''Ja'', ''Yes'') else null end as hauptansprechpartner, kontroll_datum',
'from cte_land l',
'--left join cte_hap hap on hap.landid = l.landid',
'join t_benutzer_ref_land ref on ref.landid = l.landid',
'join cte_benutzer b on b.benutzerid = ref.benutzerid',
'',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(704607999498079655)
,p_query_column_id=>1
,p_column_alias=>'BENUTZER_REF_LANDID'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(704607619742079654)
,p_query_column_id=>2
,p_column_alias=>'BENUTZERID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(704607198493079654)
,p_query_column_id=>3
,p_column_alias=>'LINK'
,p_column_display_sequence=>3
,p_column_heading=>'Link'
,p_column_link=>'f?p=&APP_ID.:56:&SESSION.::&DEBUG.::P56_BENUTZER_REF_LANDID:#BENUTZER_REF_LANDID#'
,p_column_linktext=>'<span aria-label="Eintrag bearbeiten"><span class="fa fa-edit" aria-hidden="true" title="Eintrag bearbeiten"></span></span>'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(704606809357079654)
,p_query_column_id=>4
,p_column_alias=>'LAND'
,p_column_display_sequence=>4
,p_column_heading=>'Land'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(704606417589079654)
,p_query_column_id=>5
,p_column_alias=>'HAUPTANSPRECHPARTNER'
,p_column_display_sequence=>5
,p_column_heading=>'Hauptansprechpartner'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(704605956863079654)
,p_query_column_id=>6
,p_column_alias=>'KONTROLL_DATUM'
,p_column_display_sequence=>6
,p_column_heading=>'Kontrolldatum'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5179842486706695703)
,p_plug_name=>'Form on T_BENUTZER'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5179843241175695710)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(704599423851079650)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5179843241175695710)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(704605591393079654)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2089620034116146173)
,p_button_name=>unistr('CREATE_L\00C4NDERZUORDNUNG')
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Land zuordnen'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:56:&SESSION.::&DEBUG.:56:P56_ROWID:&P55_ROWID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(704598964967079650)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(5179843241175695710)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P55_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(704598617004079649)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(5179843241175695710)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P55_ROWID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(704592163875079645)
,p_branch_name=>'Go To Page 50'
,p_branch_action=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.:50::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(704598617004079649)
,p_branch_sequence=>10
,p_branch_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(704604922582079653)
,p_name=>'P55_RREROLE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(5179842486706695703)
,p_use_cache_before_default=>'NO'
,p_source=>'case WHEN pck_ri.fIsUserInRolle(:G_BENUTZERID, ''1050'') > 0 and  pck_ri.fIsUserInRolle(:G_BENUTZERID, ''1005'') <=0 then 1 else 0 end'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(704604484762079652)
,p_name=>'P55_ROWID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(5179842486706695703)
,p_use_cache_before_default=>'NO'
,p_source=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(704604086292079652)
,p_name=>'P55_NACHNAME'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(5179842486706695703)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Nachname'
,p_source=>'NACHNAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>120
,p_read_only_when=>'P55_RREROLE'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(704603696683079652)
,p_name=>'P55_VORNAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(5179842486706695703)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Vorname'
,p_source=>'VORNAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>120
,p_begin_on_new_line=>'N'
,p_read_only_when=>'P55_RREROLE'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(704603241927079652)
,p_name=>'P55_ABTEILUNG'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(5179842486706695703)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Abteilung'
,p_source=>'ABTEILUNG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>80
,p_read_only_when=>'P55_RREROLE'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(704602874638079652)
,p_name=>'P55_GID'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(5179842486706695703)
,p_use_cache_before_default=>'NO'
,p_prompt=>'GID'
,p_source=>'GID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>128
,p_begin_on_new_line=>'N'
,p_read_only_when=>'P55_RREROLE'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(704602437714079651)
,p_name=>'P55_TELEFON'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(5179842486706695703)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Telefon'
,p_source=>'TELEFON'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>100
,p_read_only_when=>'P55_RREROLE'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(704602090111079651)
,p_name=>'P55_EMAIL'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(5179842486706695703)
,p_use_cache_before_default=>'NO'
,p_prompt=>'E-Mail'
,p_source=>'EMAIL'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>140
,p_begin_on_new_line=>'N'
,p_read_only_when=>'P55_RREROLE'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(704601707481079651)
,p_name=>'P55_STATUS'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(5179842486706695703)
,p_use_cache_before_default=>'NO'
,p_item_default=>'10'
,p_prompt=>'Status'
,p_source=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''aktiv'', ''active'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''inaktiv'', ''inactive'') AS display_value,',
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(704601317556079651)
,p_name=>'P55_RRE_KVKO_STATUS'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(5179842486706695703)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Rolle K-VKO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lCount number;',
'begin',
'',
'    if (:P55_ROWID is null) then',
'        return 20; -- Wenn neuer Benutzer angelegt wird, dann Checkbox leer',
'    else',
'',
'        select count(*) into lCount',
'        from t_benutzer b',
'        join t_benutzer_ref_rolle brr on (b.benutzerid = brr.benutzerid)',
'        where b.rowid = :P55_ROWID and brr.rolleid = 1060;',
'',
'        if (lCount = 0) then',
'            return 20;',
'        else',
'            return 10;',
'        end if;',
'    end if;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_display_when=>'P55_RREROLE'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:margin-top-md'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', '10',
  'unchecked_value', '20',
  'use_defaults', 'N')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_count number;',
'begin',
'begin ',
'select count(1) into v_count from t_benutzer_ref_rolle where BENUTZERID = ( select benutzerid from t_benutzer where rowid = :P55_ROWID)',
'and ROLLEID	=1060;',
' exception when no_data_found then v_count :=null;   ',
' end;',
' return (v_count);',
' end;'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(704600864876079651)
,p_name=>'P55_ROLLEN'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(5179842486706695703)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Rollen'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select brr.rolleid ',
'from t_benutzer b',
'join t_benutzer_ref_rolle brr on (brr.benutzerid = b.benutzerid)',
'where b.rowid = :P55_ROWID',
'    and brr.rolleid <> 1004'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rolle, rolleid',
'from t_rolle',
'where rolleid not in ( 1004, 1010) -- Rolle ''Suche'', ''Basisrechte''',
'order by 1'))
,p_cHeight=>4
,p_begin_on_new_line=>'N'
,p_display_when=>'P55_RREROLE'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(704600450305079650)
,p_name=>'P55_MANUELLE_ZUWEISUNG'
,p_is_required=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(5179842486706695703)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>'Manuelle Zuweisung'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select max(manuelle_zuweisung) from T_Benutzer_ref_rolle brr',
' join t_benutzer b on ( brr.benutzerid= b.benutzerid and b.gid =:P55_GID)'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_YES_NO'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'inaktiv',
  'off_value', '0',
  'on_label', 'aktiv',
  'on_value', '1',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(704600065043079650)
,p_name=>'P55_KONZERN_CLUSTER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(5179842486706695703)
,p_prompt=>'Konzern-Cluster'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(konzern_clusterid, '':'') within group (order by konzern_clusterid) ',
'from t_benutzer_ref_konzern_cluster bkc',
'join t_benutzer b on b.benutzerid = bkc.benutzerid',
'where b.rowid = :P55_ROWID;'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct bezeichnung d, konzern_clusterid s',
'from t_konzern_cluster',
'order by d'))
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(704598056495079649)
,p_validation_name=>'V_GID_IS_UNIQUE'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from t_benutzer',
'where (rowid <> :P55_ROWID ',
'       AND gid = :P55_GID);'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Es existiert bereits ein anderer Benutzer mit dieser GID.'
,p_validation_condition=>'P55_ROWID'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(704594971144079647)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(704599423851079650)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(704594509542079647)
,p_event_id=>wwv_flow_imp.id(704594971144079647)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(704594099571079646)
,p_name=>'Create - Page 56 Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(704605591393079654)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(704593616937079646)
,p_event_id=>wwv_flow_imp.id(704594099571079646)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2089620034116146173)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(704593186876079646)
,p_name=>'Edit - Page 56 Closed'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2089620034116146173)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(704592683289079646)
,p_event_id=>wwv_flow_imp.id(704593186876079646)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2089620034116146173)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(704597409855079649)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Reset Konzern_Cluster'
,p_attribute_01=>'CLEAR_CACHE_FOR_ITEMS'
,p_attribute_03=>'P55_KONZERN_CLUSTER'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2967614906044308586
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(704596941846079648)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_BENUTZER'
,p_attribute_02=>'T_BENUTZER'
,p_attribute_03=>'P55_ROWID'
,p_attribute_04=>'ROWID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2967615374053308587
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(704596619939079648)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process Row of T_BENUTZER'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_GidExists number := 0;',
'',
'begin',
'    select count(*) into l_GidExists ',
'    from T_BENUTZER b',
'    where b.gid = :P55_GID;',
'',
'if :P55_ROWID is not null then',
'    update t_benutzer ',
'    set nachname = :P55_NACHNAME, ',
'         vorname = :P55_VORNAME,',
'         abteilung = :P55_ABTEILUNG,',
'         gid = :P55_GID,',
'         telefon = :P55_TELEFON,',
'         email = :P55_EMAIL,',
'         status = :P55_STATUS',
'    where rowid = :P55_ROWID;',
'',
'elsif l_GidExists = 1 then',
'    ',
'    update t_benutzer',
'    set nachname = :P55_NACHNAME, ',
'         vorname = :P55_VORNAME,',
'         abteilung = :P55_ABTEILUNG,',
'         telefon = :P55_TELEFON,',
'         email = :P55_EMAIL,',
'         status = :P55_STATUS',
'    where gid = :P55_GID',
'    returning rowid into :P55_ROWID;',
'    ',
'else ',
'    insert into t_benutzer (nachname, vorname,',
'                           abteilung, gid,',
'                            telefon, email,',
'                            status)',
'    values (:P55_NACHNAME, :P55_VORNAME,',
'           :P55_ABTEILUNG, :P55_GID,',
'           :P55_TELEFON, :P55_EMAIL,',
'           :P55_STATUS)',
'     returning rowid into :P55_ROWID;',
'end if;',
'',
'',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Benutzer gespeichert.'
,p_internal_uid=>2967615695960308587
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(704595427737079648)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ROLLEN'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_benutzerid number;',
'begin',
'    select benutzerid into l_benutzerid',
'    from t_benutzer',
'    where rowid = :P55_ROWID;',
'    ',
'    if :P55_RREROLE !=1 then ',
'    -- neue Rollen einfuegen',
'    merge into t_benutzer_ref_rolle dest',
'    using (select l_benutzerid as benutzerid, column_value as rolleid from table(APEX_STRING.split_numbers(:P55_ROLLEN, '':''))) src',
'    on (src.benutzerid = dest.benutzerid ',
'       and src.rolleid = dest.rolleid)',
'    when not matched then',
'    insert (benutzerid, rolleid)',
'    values (src.benutzerid, src.rolleid);',
'    ',
'    ',
'    -- entfernte rollen loeschen',
'    -- zuerst Abhaengigkeiten',
'    update t_et_b_ak_ref_thema_benutzer ',
'    set benutzer_ref_rolleid = null',
'    where benutzer_ref_rolleid in (    ',
'        select brf.benutzer_ref_rolleid ',
'        from t_benutzer_ref_rolle brf',
'        where brf.benutzerid = l_benutzerid',
'            and brf.rolleid not in (select column_value from table(APEX_STRING.split_numbers(:P55_ROLLEN, '':'')))',
'    );',
'',
'    -- dann Datensatz',
'    delete from t_benutzer_ref_rolle brf',
'    where brf.benutzerid = l_benutzerid',
'        and brf.rolleid not in (select column_value from table(APEX_STRING.split_numbers(:P55_ROLLEN, '':'')))',
'        and  brf.rolleid !=1010;',
'',
'',
'    ',
'    -- Rolle ''Suche'' einfuegen, wenn keine andere Rolle zugewiesen ist',
'    insert into t_benutzer_ref_rolle (benutzerid, rolleid)',
'    select l_benutzerid, 1004 from dual',
'    where not exists (',
'        select 1 from t_benutzer_ref_rolle',
'        where benutzerid = l_benutzerid',
'    );',
'    -- basisrechte',
'     insert into t_benutzer_ref_rolle (benutzerid, rolleid)',
'    select l_benutzerid, 1010 from dual',
'    where not exists (',
'        select 1 from t_benutzer_ref_rolle',
'        where benutzerid = l_benutzerid and rolleid = 1010',
'    );',
'else --when RRE login',
'',
'    if :P55_RRE_KVKO_STATUS = 10 then',
'        insert into t_benutzer_ref_rolle (benutzerid, rolleid)',
'        select l_benutzerid, 1060',
'        from dual',
'        where not exists (select 1 from t_benutzer_ref_rolle where benutzerid = l_benutzerid and rolleid = 1060);',
'    else ',
'        delete from t_benutzer_ref_rolle where benutzerid = l_benutzerid and rolleid =1060;',
'    end if;',
'end if;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2967616888162308587
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'declare ',
'    l_benutzerid number;',
'begin',
'    select benutzerid into l_benutzerid',
'    from t_benutzer',
'    where rowid = :P55_ROWID;',
'    ',
'    -- neue Rollen einfuegen',
'    merge into t_benutzer_ref_rolle dest',
'    using (select l_benutzerid as benutzerid, column_value as rolleid from table(APEX_STRING.split_numbers(:P55_ROLLEN, '':''))) src',
'    on (src.benutzerid = dest.benutzerid ',
'       and src.rolleid = dest.rolleid)',
'    when not matched then',
'    insert (benutzerid, rolleid)',
'    values (src.benutzerid, src.rolleid);',
'    ',
'    ',
'    -- entfernte rollen loeschen',
'    -- zuerst Abhaengigkeiten',
'    update t_et_b_ak_ref_thema_benutzer ',
'    set benutzer_ref_rolleid = null',
'    where benutzer_ref_rolleid in (    ',
'        select brf.benutzer_ref_rolleid ',
'        from t_benutzer_ref_rolle brf',
'        where brf.benutzerid = l_benutzerid',
'            and brf.rolleid not in (select column_value from table(APEX_STRING.split_numbers(:P55_ROLLEN, '':'')))',
'    );',
'',
'    -- dann Datensatz',
'    delete from t_benutzer_ref_rolle brf',
'    where brf.benutzerid = l_benutzerid',
'        and brf.rolleid not in (select column_value from table(APEX_STRING.split_numbers(:P55_ROLLEN, '':'')))',
'        and  brf.rolleid !=1010;',
'',
'',
'    ',
'    -- Rolle ''Suche'' einfuegen, wenn keine andere Rolle zugewiesen ist',
'    insert into t_benutzer_ref_rolle (benutzerid, rolleid)',
'    select l_benutzerid, 1004 from dual',
'    where not exists (',
'        select 1 from t_benutzer_ref_rolle',
'        where benutzerid = l_benutzerid',
'    );',
'    -- basisrechte',
'     insert into t_benutzer_ref_rolle (benutzerid, rolleid)',
'    select l_benutzerid, 1010 from dual',
'    where not exists (',
'        select 1 from t_benutzer_ref_rolle',
'        where benutzerid = l_benutzerid and rolleid = 1010',
'    );',
'',
'',
'end;',
'',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(704597796312079649)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save Konzern_Cluster'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_benutzerid number;',
'begin',
'    select benutzerid into l_benutzerid',
'    from t_benutzer',
'    where rowid = :P55_ROWID;',
'    ',
'    -- neue Konzern_Cluster einfuegen',
'    merge into t_benutzer_ref_konzern_cluster dest',
'    using (select l_benutzerid as benutzerid, column_value as konzern_clusterid from table(APEX_STRING.split_numbers(:P55_KONZERN_CLUSTER, '':''))) src',
'    on (src.benutzerid = dest.benutzerid ',
'       and src.konzern_clusterid = dest.konzern_clusterid)',
'    when not matched then',
'    insert (benutzerid, konzern_clusterid)',
'    values (src.benutzerid, src.konzern_clusterid);',
'    ',
'    -- entfernte Konzern_Cluster loeschen',
'    delete from t_benutzer_ref_konzern_cluster bkc',
'    where bkc.benutzerid = l_benutzerid',
'        and bkc.konzern_clusterid not in (select column_value from table(APEX_STRING.split_numbers(:P55_KONZERN_CLUSTER, '':'')));',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2967614519587308586
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(704596220666079648)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2967616095233308587
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(704595794742079648)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2967616521157308587
,p_process_comment=>'CREATE,SAVE,DELETE'
);
wwv_flow_imp.component_end;
end;
/
