prompt --application/pages/page_00541
begin
--   Manifest
--     PAGE: 00541
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>541
,p_name=>unistr('Verkn\00FCpfungen')
,p_alias=>unistr('VERKN\00DCPFUNGEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Verkn\00FCpfungen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Click auf Checkbox in Tabellenheader: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'$(''#report-verknuepfungen'').on(''click'', ''th input'', function() {',
'    var check_all = $("#report-verknuepfungen").find("th input:checked").is(":checked");',
'',
'    $("#report-verknuepfungen").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'    setSelecteVerknuepfungen();',
'});',
'',
'/* Click auf Checkbox in Tabellenzeile: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'',
'$(''#report-verknuepfungen'').on(''click'', ''td input'', function() {',
'    setSelecteVerknuepfungen();',
'});',
'',
'function setSelecteVerknuepfungen() {',
'    var sel_rows = $("#P541_SELECTED_VERKNUEPFUNGEN");',
'    sel_rows.val("");',
'    $("#report-verknuepfungen").find("td input:checked").each(function() {',
'      // alert(this.value);',
'      if(sel_rows !=null && sel_rows.val() !=null && sel_rows.val().length > 0) {',
'        sel_rows.val(sel_rows.val() + ":");    ',
'      }',
'      sel_rows.val(sel_rows.val() + this.value);',
'    });',
'    //alert(sel_rows.val());',
'}',
'',
'$(''#ig_verknuepfungen'').on(''click'', ''th input'', function() {',
'    var check_all = $("#ig_verknuepfungen").find("th input:checked").is(":checked");',
'',
'    $("#ig_verknuepfungen").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'    setSelectedIGVerknuepfungen();',
'});',
'//',
'$(''#ig_verknuepfungen'').on(''click'', ''td input'', function() {',
'    setSelectedIGVerknuepfungen();',
'});',
'',
'function setSelectedIGVerknuepfungen() {',
'    var sel_rows = $("#P541_NEUE_VERKNUEPFUNGEN");',
'    sel_rows.val("");',
'    $("#ig_verknuepfungen").find("td input:checked").each(function() {',
'      // alert(this.value);',
'      if(sel_rows !=null && sel_rows.val() !=null && sel_rows.val().length > 0) {',
'        sel_rows.val(sel_rows.val() + ":");    ',
'      }',
'      sel_rows.val(sel_rows.val() + this.value);',
'    });',
'    //alert(sel_rows.val());',
'}',
'',
'//',
'function store_verknuepfungen() {',
'',
'var model = apex.region("ig_verknuepfungen").call("getViews").grid.model;',
'',
'var keyVorgaenger = model.getFieldKey("VORGAENGER");',
'var keyBeziehungart = model.getFieldKey("BEZIEHUNG_ART");',
'var keyNachfolger = model.getFieldKey("NACHFOLGER");',
'',
'var keyDatumInKraft = model.getFieldKey("DATUM_IN_KRAFT");',
'var keyDatumAlleTypen = model.getFieldKey("DATUM_ALLE_TYPEN");',
'var keyDatumNeueTypen = model.getFieldKey("DATUM_NEUE_TYPEN");',
'var keyhomologationSerie = model.getFieldKey("HOMOLOGATION_SERIE");',
'var keyhomologationMaxRef = model.getFieldKey("MAX_REF");',
'',
'var keyKommentar = model.getFieldKey("KOMMENTAR");',
'',
'var anzRecords = model.getTotalRecords();',
'var array = [];',
'',
'//console.log(anzRecords);',
'',
'model.forEach(function(record, index, identity){',
'	var row = {',
'		vorgeanger: record[keyVorgaenger],',
'		beziehungart: record[keyBeziehungart],',
'        nachfolger: record[keyNachfolger],',
'		datuminkraft: record[keyDatumInKraft],',
'        datumAlleTypen: record[keyDatumAlleTypen],',
'        datumNeueTypen: record[keyDatumNeueTypen],',
'        homologationSerie: record[keyhomologationSerie],',
'        homologationMaxRef: record[keyhomologationMaxRef],',
'		ommentar: record[keyKommentar]',
'	};',
'		',
'	array.push(row);',
'});',
'',
'  $s("P541_VERKNUEPFUNGEN", JSON.stringify(array));',
'  apex.page.submit(''PREVIOUS'');',
'}',
'//console.log($v("P544_EINSATZDATEN"));',
''))
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_dialog_height=>'400'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(628092560825742863)
,p_plug_name=>unistr('Verkn\00FCpfungen')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(990118378023731673)
,p_plug_name=>'IG_VERKNUEPFUNGEN'
,p_region_name=>'ig_verknuepfungen'
,p_parent_plug_id=>wwv_flow_imp.id(628092560825742863)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' with ctl_b_nummern as (',
'    select vorschriftid, listagg(b_nummer, '', '') within group (order by b_nummer) as b_nummern',
'    from ( select distinct vrl.vorschriftid, l.b_nummer',
'             from t_vorschrift_ref_land vrl ',
'             join t_land l on l.landid = vrl.landid',
'            where vrl.geloescht = 0)',
'    group by vorschriftid',
' )',
' select  vrv.rowid as x_rowid,',
'    case when vv.vorschriftid != :P540_SOURCE_VORSCHRIFTID then',
'          vv.vorschrift_nummer || '' - '' || vv.vorschrift_bezeichnung',
'          else :P540_NEW_VORSCHRIFTNUMMER || '' - '' || :P540_NEW_VORSCHRIFT_BEZEICHNUNG',
'    end  as vorgaenger,  vv.vorschriftid vorg_id, ',
'     -- :P540_VORSCHRIFTENNUMMER  -- ersetzt      -- as vorgaenger_vorschrift,',
'    ',
'    case when nv.vorschriftid != :P540_SOURCE_VORSCHRIFTID then',
'             nv.vorschrift_nummer || '' - '' || nv.vorschrift_bezeichnung ',
'             else :P540_NEW_VORSCHRIFTNUMMER || '' - '' || :P540_NEW_VORSCHRIFT_BEZEICHNUNG',
'    end as  nachfolger,   nv.vorschriftid nachf_id , ',
'    -- :P540_VORSCHRIFTENNUMMER  -- ersetzt    --as nachfolger_vorschrift,',
'',
'    vrv.beziehung_art as beziehung_art, ',
'    to_char(vrv.DATUM_IN_KRAFT) as DATUM_IN_KRAFT,   ',
'    to_char(vrv.DATUM_NEUE_TYPEN) as DATUM_NEUE_TYPEN,    to_char(vrv.DATUM_ALLE_TYPEN) as DATUM_ALLE_TYPEN,',
'        vrv.homologation_serie,',
'    vrv.kommentar,',
'    case when vrv.beziehung_art = 40 and vv.vorschriftid != :P540_SOURCE_VORSCHRIFTID and vv.vorschrift_typid = 30 then',
'            (select bn.b_nummern ',
'            from ctl_b_nummern bn',
'            where bn.vorschriftid = vv.vorschriftid)',
'        when vrv.beziehung_art = 40 and nv.vorschriftid != :P540_SOURCE_VORSCHRIFTID and nv.vorschrift_typid = 30 then',
'            (select bn.b_nummern ',
'            from ctl_b_nummern bn',
'            where bn.vorschriftid = nv.vorschriftid)',
'      end as B_NUMMERN',
'   --, vrv.letzte_aenderung_datum,',
'   , mref.vorschrift_nummer as Max_Ref',
'    , '''' as benutzer,  --, b.nachname || '', '' || b.vorname',
'    APEX_ITEM.CHECKBOX2(1,vrv.vorschrift_ref_vorschriftid,null,:P541_ALTE_VERKNUEPFUNGEN,'':'') as ig_checkbox',
' from t_vorschrift_ref_vorschrift vrv',
'  --left outer join t_benutzer b on b.benutzerid = vrv.letzte_aenderung_benutzerid',
' join t_vorschrift vv on vv.vorschriftid = vrv.vorgaenger_vorschriftid',
' join t_vorschrift nv on nv.vorschriftid = vrv.nachfolger_vorschriftid',
' left outer join t_vorschrift mref on (vrv.max_homologation_vorschriftid = mref.vorschriftid)',
' where (vrv.vorgaenger_vorschriftid = :P540_SOURCE_VORSCHRIFTID',
'        or vrv.nachfolger_vorschriftid = :P540_SOURCE_VORSCHRIFTID)',
'    -- Beziehung ist nicht Supplement und andere Vorschrift ist nicht typ Supplement UN-R',
'    and vrv.beziehung_art != 10',
'    /*and (vrv.BEZIEHUNG_ART NOT IN (10, 20, 30) or ( 20 not in (vv.vorschrift_typid, nv.vorschrift_typid) or( vrv.BEZIEHUNG_ART IN (10) and vv.vorschriftid = :P540_SOURCE_VORSCHRIFTID) )',
'                            )*/',
'   -- and :P541_NEUE_VERKNUEPFUNGEN IS NULL  -- immer anzeigen mit vorbelegten checkbox ',
'--order by 1',
'',
'/* UNION ALL',
' ',
'SELECT chartorowid(x_rowid) as x_rowid, ',
'     vorgaenger , vorg_id,  nachfolger , nachf_id',
'    , beziehung_art , DATUM_IN_KRAFT ',
'    , DATUM_NEUE_TYPEN , DATUM_ALLE_TYPEN ',
'   , homologation_serie , kommentar , B_NUMMERN , Max_Ref , benutzer ',
'     --case when vrv',
'FROM   JSON_TABLE(',
'     :P541_NEUE_VERKNUEPFUNGEN , ''$[*]'' ',
'      COLUMNS ( x_rowid varchar2(18 CHAR) PATH ''$.x_rowid''',
'             ,  vorgaenger VARCHAR2(120 CHAR) PATH ''$.vorgaenger'' ',
'          , vorg_id      NUMBER PATH ''$.vorg_id''',
'          ,  nachfolger  VARCHAR2(120 CHAR) PATH ''$.nachfolger''',
'          , nachf_id      NUMBER PATH ''$.nachf_id'' ',
'          , beziehung_art NUMBER PATH ''$.beziehung_art'' ',
'          , datum_in_kraft VARCHAR2(40 CHAR) PATH ''$.datum_in_kraft''',
'          , datum_neue_typen VARCHAR2(40 CHAR) PATH ''$.datum_neue_typen'' ',
'          , datum_alle_typen VARCHAR2(40 CHAR) PATH ''$.datum_alle_typen''  ',
'          , homologation_serie  NUMBER PATH ''$.homologation_serie'' ',
'          , kommentar  VARCHAR2(256 CHAR) PATH ''$.kommentar''  ',
'          , b_nummern  VARCHAR2(250 CHAR) PATH ''$.b_nummern'' ',
'          , max_ref  VARCHAR2(250 CHAR) PATH ''$.max_ref''    ',
'          , benutzer VARCHAR2(64 CHAR) PATH ''$.benutzer''  -- b.nachname || '', '' || b.vorname    ',
'        )',
' )',
' where :P541_NEUE_VERKNUEPFUNGEN IS NOT NULL',
' */',
' ;'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P541_SELECTED_ROWS,P541_NEUE_VERKNUEPFUNGEN,P541_FOLGEVORSCHRIFT'
,p_plug_display_condition_type=>'NEVER'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'IG_VERKNUEPFUNGEN'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(978725655611585573)
,p_name=>'X_ROWID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'X_ROWID'
,p_data_type=>'ROWID'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(978725570237585572)
,p_name=>'VORGAENGER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORGAENGER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Vorgaenger'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(978725474780585571)
,p_name=>'VORG_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORG_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(978725383460585570)
,p_name=>'NACHFOLGER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NACHFOLGER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Nachfolger'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(978725276889585569)
,p_name=>'NACHF_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NACHF_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(978725213129585568)
,p_name=>'BEZIEHUNG_ART'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BEZIEHUNG_ART'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Beziehung Art'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(978725118337585567)
,p_name=>'DATUM_IN_KRAFT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DATUM_IN_KRAFT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Datum In Kraft'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'CENTER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(978725009750585566)
,p_name=>'DATUM_NEUE_TYPEN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DATUM_NEUE_TYPEN'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Datum Neue Typen'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'CENTER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(978724906096585565)
,p_name=>'DATUM_ALLE_TYPEN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DATUM_ALLE_TYPEN'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Datum Alle Typen'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>90
,p_value_alignment=>'CENTER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(978724823064585564)
,p_name=>'HOMOLOGATION_SERIE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HOMOLOGATION_SERIE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Homologation Serie'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>100
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(978724723003585563)
,p_name=>'KOMMENTAR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'KOMMENTAR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Kommentar'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(978724576266585562)
,p_name=>'B_NUMMERN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'B_NUMMERN'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'B Nummern'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(978724493531585561)
,p_name=>'MAX_REF'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MAX_REF'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Max Ref'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>1000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(978724339238585560)
,p_name=>'BENUTZER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BENUTZER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Benutzer'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(978724285805585559)
,p_name=>'IG_CHECKBOX'
,p_source_type=>'NONE'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_HTML_EXPRESSION'
,p_heading=>'<input type="checkbox" />'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'html_expression', '<input type="checkbox" />')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(978725824262585574)
,p_internal_uid=>133967112832548830
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(977089828701369214)
,p_interactive_grid_id=>wwv_flow_imp.id(978725824262585574)
,p_static_id=>'1356032'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(977089537707369213)
,p_report_id=>wwv_flow_imp.id(977089828701369214)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(977089093345369211)
,p_view_id=>wwv_flow_imp.id(977089537707369213)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(978725655611585573)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(977088233923369207)
,p_view_id=>wwv_flow_imp.id(977089537707369213)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(978725570237585572)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(977087266210369204)
,p_view_id=>wwv_flow_imp.id(977089537707369213)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(978725474780585571)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(977086390390369201)
,p_view_id=>wwv_flow_imp.id(977089537707369213)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(978725383460585570)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(977085460964369197)
,p_view_id=>wwv_flow_imp.id(977089537707369213)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(978725276889585569)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(977084552145369195)
,p_view_id=>wwv_flow_imp.id(977089537707369213)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(978725213129585568)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(977083675141369192)
,p_view_id=>wwv_flow_imp.id(977089537707369213)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(978725118337585567)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(977082802343369189)
,p_view_id=>wwv_flow_imp.id(977089537707369213)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(978725009750585566)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(977081882469369186)
,p_view_id=>wwv_flow_imp.id(977089537707369213)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(978724906096585565)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(977080991045369183)
,p_view_id=>wwv_flow_imp.id(977089537707369213)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(978724823064585564)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(977080106497369180)
,p_view_id=>wwv_flow_imp.id(977089537707369213)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(978724723003585563)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(977079208155369177)
,p_view_id=>wwv_flow_imp.id(977089537707369213)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(978724576266585562)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(977078316294369174)
,p_view_id=>wwv_flow_imp.id(977089537707369213)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(978724493531585561)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(977077393348369171)
,p_view_id=>wwv_flow_imp.id(977089537707369213)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(978724339238585560)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(977076442825369168)
,p_view_id=>wwv_flow_imp.id(977089537707369213)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(978724285805585559)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3145085585455176231)
,p_name=>'REPORT_VERKNUEPFUNGEN'
,p_region_name=>'report-verknuepfungen'
,p_parent_plug_id=>wwv_flow_imp.id(628092560825742863)
,p_template=>wwv_flow_imp.id(3414123142457820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' with ctl_b_nummern as (',
'    select vorschriftid, listagg(b_nummer, '', '') within group (order by b_nummer) as b_nummern',
'    from ( select distinct vrl.vorschriftid, l.b_nummer',
'             from t_vorschrift_ref_land vrl ',
'             join t_land l on l.landid = vrl.landid',
'            where vrl.geloescht = 0)',
'    group by vorschriftid',
' )',
' select  vrv.rowid as x_rowid,',
'    case when vv.vorschriftid != :P540_SOURCE_VORSCHRIFTID then',
'          vv.vorschrift_nummer || '' - '' || vv.vorschrift_bezeichnung',
'          else :P540_NEW_VORSCHRIFTNUMMER || '' - '' || :P540_NEW_VORSCHRIFT_BEZEICHNUNG',
'    end  as vorgaenger,  vv.vorschriftid vorg_id, ',
'     -- :P540_VORSCHRIFTENNUMMER  -- ersetzt      -- as vorgaenger_vorschrift,',
'    ',
'    case when nv.vorschriftid != :P540_SOURCE_VORSCHRIFTID then',
'             nv.vorschrift_nummer || '' - '' || nv.vorschrift_bezeichnung ',
'             else :P540_NEW_VORSCHRIFTNUMMER || '' - '' || :P540_NEW_VORSCHRIFT_BEZEICHNUNG',
'    end as  nachfolger,   nv.vorschriftid nachf_id , ',
'    -- :P540_VORSCHRIFTENNUMMER  -- ersetzt    --as nachfolger_vorschrift,',
'',
'    vrv.beziehung_art as beziehung_art, ',
'    to_char(vrv.DATUM_IN_KRAFT) as DATUM_IN_KRAFT,   ',
'    to_char(vrv.DATUM_NEUE_TYPEN) as DATUM_NEUE_TYPEN,    to_char(vrv.DATUM_ALLE_TYPEN) as DATUM_ALLE_TYPEN,',
'        vrv.homologation_serie,',
'    vrv.kommentar, vrv.KOMMENTAR_ENGLISCH,',
'    case when vrv.beziehung_art = 40 and vv.vorschriftid != :P540_SOURCE_VORSCHRIFTID and vv.vorschrift_typid = 30 then',
'            (select bn.b_nummern ',
'            from ctl_b_nummern bn',
'            where bn.vorschriftid = vv.vorschriftid)',
'        when vrv.beziehung_art = 40 and nv.vorschriftid != :P540_SOURCE_VORSCHRIFTID and nv.vorschrift_typid = 30 then',
'            (select bn.b_nummern ',
'            from ctl_b_nummern bn',
'            where bn.vorschriftid = nv.vorschriftid)',
'      end as B_NUMMERN',
'   --, vrv.letzte_aenderung_datum,',
'   , mref.vorschrift_nummer as Max_Ref',
'    , '''' as benutzer,  --, b.nachname || '', '' || b.vorname',
'    APEX_ITEM.CHECKBOX(1,vrv.vorschrift_ref_vorschriftid,null,:P541_ALTE_VERKNUEPFUNGEN,'':'') as checkbox',
' from t_vorschrift_ref_vorschrift vrv',
'  --left outer join t_benutzer b on b.benutzerid = vrv.letzte_aenderung_benutzerid',
' join t_vorschrift vv on vv.vorschriftid = vrv.vorgaenger_vorschriftid',
' join t_vorschrift nv on nv.vorschriftid = vrv.nachfolger_vorschriftid',
' left outer join t_vorschrift mref on (vrv.max_homologation_vorschriftid = mref.vorschriftid)',
unistr('   --  beim Kopieren von Supplements das Anzeigen von parent beziehung ausschliessen  (parent soll immer \00FCbernommen werden)'),
' where (vrv.vorgaenger_vorschriftid = :P540_SOURCE_VORSCHRIFTID ',
'        or vrv.nachfolger_vorschriftid = :P540_SOURCE_VORSCHRIFTID and :P540_NEW_VORSCHRIFT_TYPID !=20)',
'    and vrv.beziehung_art not in ( 10,30)',
'      and  (:P540_NEW_PARENT_VORSCHRIFTID is null OR vrv.vorgaenger_vorschriftid != :P540_NEW_PARENT_VORSCHRIFTID )',
'    -- Beziehung ist nicht Supplement und andere Vorschrift ist nicht typ Supplement UN-R',
'    /*and (vrv.BEZIEHUNG_ART NOT IN (10, 20, 30) or ( 20 not in (vv.vorschrift_typid, nv.vorschrift_typid) or( vrv.BEZIEHUNG_ART IN (10) and vv.vorschriftid = :P540_SOURCE_VORSCHRIFTID) )',
'                            )*/',
'   -- and :P541_NEUE_VERKNUEPFUNGEN IS NULL  -- immer anzeigen mit vorbelegten checkbox ',
'--order by 1',
'',
'/* UNION ALL',
' ',
'SELECT chartorowid(x_rowid) as x_rowid, ',
'     vorgaenger , vorg_id,  nachfolger , nachf_id',
'    , beziehung_art , DATUM_IN_KRAFT ',
'    , DATUM_NEUE_TYPEN , DATUM_ALLE_TYPEN ',
'   , homologation_serie , kommentar , B_NUMMERN , Max_Ref , benutzer ',
'     --case when vrv',
'FROM   JSON_TABLE(',
'     :P541_NEUE_VERKNUEPFUNGEN , ''$[*]'' ',
'      COLUMNS ( x_rowid varchar2(18 CHAR) PATH ''$.x_rowid''',
'             ,  vorgaenger VARCHAR2(120 CHAR) PATH ''$.vorgaenger'' ',
'          , vorg_id      NUMBER PATH ''$.vorg_id''',
'          ,  nachfolger  VARCHAR2(120 CHAR) PATH ''$.nachfolger''',
'          , nachf_id      NUMBER PATH ''$.nachf_id'' ',
'          , beziehung_art NUMBER PATH ''$.beziehung_art'' ',
'          , datum_in_kraft VARCHAR2(40 CHAR) PATH ''$.datum_in_kraft''',
'          , datum_neue_typen VARCHAR2(40 CHAR) PATH ''$.datum_neue_typen'' ',
'          , datum_alle_typen VARCHAR2(40 CHAR) PATH ''$.datum_alle_typen''  ',
'          , homologation_serie  NUMBER PATH ''$.homologation_serie'' ',
'          , kommentar  VARCHAR2(256 CHAR) PATH ''$.kommentar''  ',
'          , b_nummern  VARCHAR2(250 CHAR) PATH ''$.b_nummern'' ',
'          , max_ref  VARCHAR2(250 CHAR) PATH ''$.max_ref''    ',
'          , benutzer VARCHAR2(64 CHAR) PATH ''$.benutzer''  -- b.nachname || '', '' || b.vorname    ',
'        )',
' )',
' where :P541_NEUE_VERKNUEPFUNGEN IS NOT NULL',
' */',
' ;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P541_SELECTED_ROWS,P541_NEUE_VERKNUEPFUNGEN,P541_FOLGEVORSCHRIFT'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>unistr('Noch keine Verkn\00FCpfungen vorhanden.')
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(602811335445777367)
,p_query_column_id=>1
,p_column_alias=>'X_ROWID'
,p_column_display_sequence=>80
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(602812142662777376)
,p_query_column_id=>2
,p_column_alias=>'VORGAENGER'
,p_column_display_sequence=>5
,p_column_heading=>'Vorschrift'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(602812077242777375)
,p_query_column_id=>3
,p_column_alias=>'VORG_ID'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(602811970529777374)
,p_query_column_id=>4
,p_column_alias=>'NACHFOLGER'
,p_column_display_sequence=>2
,p_column_heading=>'Verlinkte Vorschrift'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(602811838032777373)
,p_query_column_id=>5
,p_column_alias=>'NACHF_ID'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(610570316733620432)
,p_query_column_id=>6
,p_column_alias=>'BEZIEHUNG_ART'
,p_column_display_sequence=>4
,p_column_heading=>'Art der Beziehung'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(2655378917409322525)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(602811371246777368)
,p_query_column_id=>7
,p_column_alias=>'DATUM_IN_KRAFT'
,p_column_display_sequence=>7
,p_column_heading=>unistr('In Kraftsetzung aus verkn\00FCpfter Vorschrift')
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(602811203744777366)
,p_query_column_id=>8
,p_column_alias=>'DATUM_NEUE_TYPEN'
,p_column_display_sequence=>8
,p_column_heading=>'Einsatztermin neue Typen'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(602811063559777365)
,p_query_column_id=>9
,p_column_alias=>'DATUM_ALLE_TYPEN'
,p_column_display_sequence=>9
,p_column_heading=>'Einsatztermin alle Fahrzeuge'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(610571085898620433)
,p_query_column_id=>10
,p_column_alias=>'HOMOLOGATION_SERIE'
,p_column_display_sequence=>40
,p_column_heading=>unistr('Homologation mit h\00F6herer Serie m\00F6glich')
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'STATIC:Ja;10,Nein;0'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(610568715202620430)
,p_query_column_id=>11
,p_column_alias=>'KOMMENTAR'
,p_column_display_sequence=>10
,p_column_heading=>'Kommentar'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(929251580772458761)
,p_query_column_id=>12
,p_column_alias=>'KOMMENTAR_ENGLISCH'
,p_column_display_sequence=>70
,p_column_heading=>'Kommentar Englisch'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(610568391000620429)
,p_query_column_id=>13
,p_column_alias=>'B_NUMMERN'
,p_column_display_sequence=>30
,p_column_heading=>unistr('L\00E4nder')
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(610570670133620432)
,p_query_column_id=>14
,p_column_alias=>'MAX_REF'
,p_column_display_sequence=>50
,p_column_heading=>'Maximale Homologationsvorschrift'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(602811761240777372)
,p_query_column_id=>15
,p_column_alias=>'BENUTZER'
,p_column_display_sequence=>60
,p_column_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(591083180703850495)
,p_query_column_id=>16
,p_column_alias=>'CHECKBOX'
,p_column_display_sequence=>1
,p_column_heading=>'<input type="checkbox" />'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(301912432044941416)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(712760182011977984)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(301912413165941416)
,p_plug_name=>'Vorschrift kopieren'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(301912306465941416)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(701835031755097830)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(301912306465941416)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(610466817358135116)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(628092560825742863)
,p_button_name=>'DELETE_VERKNUEPFUNG'
,p_button_static_id=>'DELETE_VERKNUEPFUNG'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Markierte Verkn\00FCpfungen l\00F6schen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition_type=>'NEVER'
,p_button_css_classes=>'apex_disabled'
,p_icon_css_classes=>'fa-trash-o'
,p_security_scheme=>wwv_flow_imp.id(756418224517528353)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(610197888173765510)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(628092560825742863)
,p_button_name=>'CREATE_VERKNUEPFUNG'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.:RP,45:P45_VORGAENGER_VORSCHRIFTID:&P25_VORSCHRIFTID.'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-plus-circle-o'
,p_security_scheme=>wwv_flow_imp.id(2645659840847340007)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(701834565117097829)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(301912306465941416)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'MfVs'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(700566016390495974)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(301912306465941416)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(701826303488097823)
,p_branch_name=>'Go To Page 542'
,p_branch_action=>'f?p=&APP_ID.:542:&SESSION.::&DEBUG.:25::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(701834565117097829)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(700565803315495972)
,p_branch_name=>'Go To Page 544'
,p_branch_action=>'f?p=&APP_ID.:544:&SESSION.::&DEBUG.:25::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(700566016390495974)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(990118516882731674)
,p_name=>'P541_VERKNUEPFUNGEN'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(3145085585455176231)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(602812252348777377)
,p_name=>'P541_NEUE_VERKNUEPFUNGEN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(3145085585455176231)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(602810980164777364)
,p_name=>'P541_SELECTED_ROWS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3145085585455176231)
,p_item_default=>'P541_SELECTED_ROWS'
,p_item_default_type=>'ITEM'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(591083472785850498)
,p_name=>'P541_FOLGEVORSCHRIFT'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(3145085585455176231)
,p_prompt=>'Neue Vorschrift als Folgevorschrift von kopierender Vorschrift'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC(,):&nbsp;1'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(591083038493850494)
,p_name=>'P541_ALTE_VERKNUEPFUNGEN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(3145085585455176231)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(701833868193097828)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(701835031755097830)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(701833359863097827)
,p_event_id=>wwv_flow_imp.id(701833868193097828)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(701829281322097824)
,p_name=>'copy nachfolger changed'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P541_COPY_NACHFOLGER'
,p_condition_element=>'P541_COPY_NACHFOLGER'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Y'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(701828785745097824)
,p_event_id=>wwv_flow_imp.id(701829281322097824)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P541_COPY_ALL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(701828310862097824)
,p_event_id=>wwv_flow_imp.id(701829281322097824)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P541_COPY_ALL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(701830698676097825)
,p_name=>'VORSCHRIFT_CHANGED'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P541_SOURCE_VORSCHRIFTID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(701830160036097825)
,p_event_id=>wwv_flow_imp.id(701830698676097825)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P541_SOURCE_VORSCHRIFTID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(701829703707097824)
,p_event_id=>wwv_flow_imp.id(701830698676097825)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P541_VORSCHRIFT_BEZEICHNUNG,P541_SOURCE_VORSCHRIFT_NUMMER'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(701831626116097826)
,p_name=>'copy all changed'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P541_COPY_ALL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(610465520950121599)
,p_name=>'DELETE_SELECTED_VERKNUEPFUNGEN'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(610466817358135116)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(610465037406121590)
,p_event_id=>wwv_flow_imp.id(610465520950121599)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('M\00F6chten Sie die ausgew\00E4hlten Verkn\00FCpfungen l\00F6schen?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(610464547736121589)
,p_event_id=>wwv_flow_imp.id(610465520950121599)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var sel_rows = $("#P541_SELECTED_ROWS");',
'sel_rows.val("");',
'$("#report-verknuepfungen").find("td input:checked").each(function() {',
'  // alert(this.value);',
'    // sel_rows.val() != null',
'  if(sel_rows.val().length > 0) {',
'    sel_rows.val(sel_rows.val() + "|");    ',
'  }',
'  sel_rows.val(sel_rows.val() + this.value);',
'  //sel_rows.val(sel_rows.val().push(this.value));',
'  //alert(sel_rows.val());',
'});',
'            '))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(610464096097121588)
,p_event_id=>wwv_flow_imp.id(610465520950121599)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  lStartIdx binary_integer;',
'  lCurIdx   binary_integer;',
'  lCurValue varchar2(1000);',
'begin',
'',
'  lStartIdx := 0;',
'  lCurIdx   := instr(:P541_SELECTED_ROWS, ''|''); ',
'',
'  while(lCurIdx > 0) loop',
'    lCurValue := substr(:P541_SELECTED_ROWS, lStartIdx+1, lCurIdx - lStartIdx - 1);',
'',
'    -- call proc here',
'    --delete from t_vorschrift_ref_vorschrift where rowid = lCurValue;',
'',
'    lStartIdx := lCurIdx;',
'    lCurIdx := instr(:P541_SELECTED_ROWS, ''|'', lStartIdx + 1);  ',
'  end loop;',
'',
'  -- Call proc here for last part (or in case of single element)',
'  lCurValue := substr(:P541_SELECTED_ROWS, lStartIdx+1);',
'  --delete from t_vorschrift_ref_vorschrift where rowid = lCurValue;',
'',
'end;'))
,p_attribute_02=>'P25_SELECTED_ROWS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(610463598921121588)
,p_event_id=>wwv_flow_imp.id(610465520950121599)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(602811646764777371)
,p_name=>'Store Verknuepfungen'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(701834565117097829)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(602811580872777370)
,p_event_id=>wwv_flow_imp.id(602811646764777371)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//var r_model = apex.region("report_verknuepfungen").call("getViews").grid.model;',
'//var c_model = apex.region("report_verknuepfungen").call("getCurrentView");',
'',
'/*var anzRecords = r_model.getTotalRecords();',
'',
'var keyRowid =  r_model.getFieldKey("X_ROWID");',
'var keyVorgaenger =  r_model.getFieldKey("VORGAENGER");',
'    //var keyVorg_id  =  r_model.getFieldKey("VORG_ID"); ',
'',
'var keyNachfolger  =  r_model.getFieldKey("NACHFOLGER");',
'     //          , nachf_id      NUMBER PATH ''$.nachf_id'' ',
'*/     ',
'//var keyBeziehung_art = r_model.getFieldKey(''BEZIEHUNG_ART''); ',
'//var keyDatumInKraft = r_model.getFieldKey(''DATUM_IN_KRAFT'');',
'//var keyDatumNeueTypen = r_model.getFieldKey(''DATUM_NEUE_TYPEN'');',
'//var keyDatumAlleTypen = r_model.getFieldKey(''DATUM_ALLE_TYPEN'');',
'',
'//var keyHomologationSerie r_model.getFieldKey(''HOMOLOGATION_SERIE''); ',
'//var keyKommentar = r_model.getFieldKey(''KOMMENTAR''); ',
'//var keyB_Nummern  = r_model.getFieldKey(''B_NUMMERN''); ',
'//var keyMax_Ref =  r_model.getFieldKey(''MAX_REF'');   ',
'//var keyBenutzer  = r_model.getFieldKey(''BENUTZER''); ',
'',
'',
'var array_v = [];',
'',
'//console.log(anzRecords);',
'',
'/*var sel_rows = $("#P541_SELECTED_ROWS");',
'sel_rows.val("");',
'$("#report-verknuepfungen").find("td input:checked").each(function() {',
'  // alert(this.value);',
'  if(sel_rows.val().length > 0) {',
'    sel_rows.val(sel_rows.val() + "|");    ',
'  }',
'  sel_rows.val(sel_rows.val() + this.value);',
'    console.log("selected Rows: " + sel_rows.val());',
'});',
'*/',
'',
'',
'var $nachfolger = $( ''td[headers=NACHFOLGER]'');',
' var $beziehung = $( ''td[headers=BEZIEHUNG_ART]'');',
'var $vorgaenger = $(''td[headers=VORGAENGER]'');',
'var $datum_in_kraft = $(''td[headers=DATUM_IN_KRAFT]'');',
'var $datum_neue_typen = $(''td[headers=DATUM_NEUE_TYPEN]'');',
'var $datum_alle_typen = $(''td[headers=DATUM_ALLE_TYPEN]'');',
'var $homologation_serie = $(''td[headers=HOMOLOGATION_SERIE]'');',
'',
'var $kommentar = $(''td[headers=KOMMENTAR]'');',
'',
'var $b_nummern = $(''td[headers=B_NUMMERN]'');',
'',
'var $max_ref = $(''td[headers=MAX_REF]'');',
'var $benutzer = $(''td[headers=BENUTZER]'');',
'',
'',
'',
'$("#report-verknuepfungen").find("td input:checked").each( function( index, E2){',
'',
'    //console.log($v("P541_NEUE_VERKNUEPFUNGEN"));',
'  //  console.log("in function:" +  "index: " + index );',
'    ',
'    console.log("in function nachfolger:" + $nachfolger.eq( index ).html( ));',
'    console.log("in function beziehung:" + $beziehung.eq( index ).html( ));',
'    console.log("in function vorgaenger:" + $vorgaenger.eq( index ).html( ));',
'   console.log("in function datum_in_kraft:" + $datum_in_kraft.eq( index ).html( ));',
'    console.log("in function benutzer:" + $benutzer.eq( index ).html( ));',
'    ',
'    var row = {',
'        //x_rowid: record[keyRowid],',
'        nachfolger: $nachfolger.eq( index ).html(),  ',
'        vorgaenger: $vorgaenger.eq( index ).html(),',
'',
'        beziehung_art: $beziehung.eq( index ).html(), ',
'        ',
'        datum_in_kraft: $datum_in_kraft.eq( index ).html(),',
'        datum_neue_typen: $datum_neue_typen.eq( index ).html(),',
'        datum_alle_typen: $datum_alle_typen.eq( index ).html(), ',
'        ',
'        homologation_serie: $homologation_serie.eq( index ).html(),',
'        kommentar: $kommentar.eq( index ).html(),',
'        b_nummern: $b_nummern.eq( index ).html(), ',
'        max_ref: $max_ref.eq( index ).html(),   ',
'        benutzer: $benutzer.eq( index ).html() ',
'	};',
'		',
'	 array_v.push(row);',
'});',
'',
'',
'$s("P541_NEUE_VERKNUEPFUNGEN", JSON.stringify(array_v));',
'console.log($v("P541_NEUE_VERKNUEPFUNGEN"));',
'',
'apex.page.submit(''NEXT'');'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(591083320393850496)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Checkboxen auslesen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--debug(''Prozess Checkboxen auslesen'',APEX_APPLICATION.G_F01.COUNT);',
'',
':P541_ALTE_VERKNUEPFUNGEN := null;',
'',
'FOR i IN 1..APEX_APPLICATION.G_F01.COUNT LOOP ',
'    --debug(''element ''||I||'' has a value of ''||APEX_APPLICATION.G_F01(i)); ',
'    :P541_ALTE_VERKNUEPFUNGEN := :P541_ALTE_VERKNUEPFUNGEN || APEX_APPLICATION.G_F01(i) || '':'';',
'END LOOP;',
'',
'--debug(''folge Vorschrift: Kopiere verknuepf.:'', :P541_FOLGEVORSCHRIFT);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3081128995505537739
);
wwv_flow_imp.component_end;
end;
/
