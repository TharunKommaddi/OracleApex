prompt --application/pages/page_00474
begin
--   Manifest
--     PAGE: 00474
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>474
,p_name=>unistr('FUKA \00DCbernehmen')
,p_alias=>unistr('FUKA-\00DCBERNEHMEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Gew\00E4hlte Funktionen zuweisen')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'400'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(988441392402471076)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(988451613722471139)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(988441311497471076)
,p_plug_name=>unistr('FUKA \00DCbernehmen')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(988441140846471076)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(988439731097471075)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(988441140846471076)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(988439554433471075)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(988441140846471076)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P474_SEL_FUNCTIONIDS'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(988439478627471075)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(988441140846471076)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Zum Auswahl der Funktionen'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(988437799041471074)
,p_branch_action=>'f?p=&APP_ID.:472:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(988439478627471075)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(990118750676731677)
,p_name=>'P474_SEL_FUNCTIONIDS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(988441311497471076)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select fu.funktionid --, fu.bezeichnung --, fu.status, fu.objecttyp',
'   from t_funktion fu',
'   join t_vorschrift_ref_funktion vrf on (vrf.funktionid = fu.funktionid)',
'   where vrf.vorschrift_ref_funktionid in (select column_value from table(apex_string.split_numbers(:P472_SELECTED_FUNCTIONS,'':'')) where column_value is not null );'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(990118689184731676)
,p_name=>'P474_FUNCTIONS_TO_COPY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(988441311497471076)
,p_use_cache_before_default=>'NO'
,p_prompt=>' <span  style="font-size: 20px;"><b> Funktionen zum Kopieren</b></span>'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--',
'select listagg (fu.funktionid ||'' - '' || fu.bezeichnung , chr(13)) within group (order by fu.funktionid)',
'   from t_funktion fu',
'   join t_vorschrift_ref_funktion vrf on (vrf.funktionid = fu.funktionid)',
'   where vrf.vorschrift_ref_funktionid in (select column_value from table(apex_string.split_numbers(:P472_SELECTED_FUNCTIONS,'':'')) )',
'   and fu.funktionid is not null;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_column=>2
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:margin-left-md'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(988439282468471075)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(988439731097471075)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(988438450921471075)
,p_event_id=>wwv_flow_imp.id(988439282468471075)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(990118837866731678)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save_Functions'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' update T_vorschrift_ref_funktion set geloescht=0                                       -- :P474_SEL_FUNCTIONIDS',
'    where Vorschriftid = :P470_ZIEL_VORSCHRIFTID ',
'    AND funktionid in (select column_value from table(apex_string.split_numbers(:P474_SEL_FUNCTIONIDS,'':'')) )',
'    and geloescht=1;',
'    ',
'    merge into T_vorschrift_ref_funktion dest',
'    using (select :P470_ZIEL_VORSCHRIFTID as Vorschriftid, column_value as funktionid from table(APEX_STRING.split_numbers(:P474_SEL_FUNCTIONIDS, '':''))) src',
'    on (src.Vorschriftid = dest.Vorschriftid ',
'       and src.funktionid = dest.funktionid )',
'    when not matched then',
'    insert (funktionid, Vorschriftid, geloescht)',
'    values (src.funktionid, src.Vorschriftid, 0);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(988439554433471075)
,p_internal_uid=>2682093478032656557
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(988437027385471073)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2683775288513917162
);
wwv_flow_imp.component_end;
end;
/
