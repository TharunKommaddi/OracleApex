prompt --application/pages/page_00330
begin
--   Manifest
--     PAGE: 00330
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>330
,p_name=>'Import MFVs'
,p_step_title=>'Import MFVs'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(214938275737579461)
,p_name=>'MFVs Vorschau'
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select MFV_ID,',
'       MFV_TEIL,',
'       VORSCHTIFT,',
'       KOMMENTAR_ZUR_VORSCHRIFT,',
'       THEMA_DER_MFV,',
'       AUDI_OE_1,',
'       LINK_ZUR_ABLAGE_IN_DMS,',
'       ET_ARBEITSKREIS,',
'       LINK,',
'       FEHLERTEXT',
'  from V_VAL_IMP_MFVS',
'  where (:P330_Only_error = 1 and fehlertext is not null) or :P330_Only_error = 0'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(214938655496579470)
,p_query_column_id=>1
,p_column_alias=>'MFV_ID'
,p_column_display_sequence=>1
,p_column_heading=>'MfV Id'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(214939063276579472)
,p_query_column_id=>2
,p_column_alias=>'MFV_TEIL'
,p_column_display_sequence=>2
,p_column_heading=>'MfV Teil'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(214939424289579473)
,p_query_column_id=>3
,p_column_alias=>'VORSCHTIFT'
,p_column_display_sequence=>3
,p_column_heading=>'Vorschtrft'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(214939827812579473)
,p_query_column_id=>4
,p_column_alias=>'KOMMENTAR_ZUR_VORSCHRIFT'
,p_column_display_sequence=>4
,p_column_heading=>'Kommentar Zur Vorschrift'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(214940214485579474)
,p_query_column_id=>5
,p_column_alias=>'THEMA_DER_MFV'
,p_column_display_sequence=>5
,p_column_heading=>'Thema der MfV'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(214940686667579474)
,p_query_column_id=>6
,p_column_alias=>'AUDI_OE_1'
,p_column_display_sequence=>6
,p_column_heading=>'Audi OE'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(214941028932579474)
,p_query_column_id=>7
,p_column_alias=>'LINK_ZUR_ABLAGE_IN_DMS'
,p_column_display_sequence=>7
,p_column_heading=>'Link Zur Ablage In GROUPDMS'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(214941437847579474)
,p_query_column_id=>8
,p_column_alias=>'ET_ARBEITSKREIS'
,p_column_display_sequence=>8
,p_column_heading=>'ET Arbeitskreis'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(214941869511579474)
,p_query_column_id=>9
,p_column_alias=>'LINK'
,p_column_display_sequence=>9
,p_column_heading=>'Link'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(214942297392579475)
,p_query_column_id=>10
,p_column_alias=>'FEHLERTEXT'
,p_column_display_sequence=>10
,p_column_heading=>'Fehlertext'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(214952226999584202)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(214938275737579461)
,p_button_name=>'IMPORT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Daten \00FCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(214952195266584201)
,p_name=>'P330_ONLY_ERROR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(214938275737579461)
,p_item_default=>'0'
,p_prompt=>unistr('Nur fehlerhafte Eintr\00E4ge anzeigen')
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Nein',
  'off_value', '0',
  'on_label', 'Ja',
  'on_value', '1',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(214952338716584203)
,p_name=>'change'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P330_ONLY_ERROR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(214952476277584204)
,p_event_id=>wwv_flow_imp.id(214952338716584203)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp.component_end;
end;
/
