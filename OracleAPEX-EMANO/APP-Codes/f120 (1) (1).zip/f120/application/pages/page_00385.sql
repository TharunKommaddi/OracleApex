prompt --application/pages/page_00385
begin
--   Manifest
--     PAGE: 00385
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>385
,p_name=>unistr('ET-B AK bearbeiten / hinzuf\00FCgen')
,p_alias=>unistr('ET-B-AK-BEARBEITEN-HINZUF\00DCGEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('ET-B AK bearbeiten / hinzuf\00FCgen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'function setCellBackground() {',
'    $("span[bg-style]").each(function() {',
'        $(this).parent().addClass($(this).attr(''bg-style''));',
'    });',
'}',
'',
'function diolguehead() {',
'    ',
'    if ($(''#P385_JS_LANG'').val() === ''en'') {',
'        apex.util.getTopApex().jQuery(".ui-dialog-title").html(''ET-B AK edit / add <span onclick="redirect(302)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');',
'    }',
'    if ($(''#P385_JS_LANG'').val() === ''de'') {',
unistr('        apex.util.getTopApex().jQuery(".ui-dialog-title").html(''ET-B AK bearbeiten / hinzuf\00FCgen <span onclick="redirect(302)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'');'),
'    }',
'    ',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'setCellBackground();',
'diolguehead();',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.lightgreen {',
'    background-color: lightgreen !important;',
'    color: black !important;',
'}',
'',
'.yellow {',
'    background-color: yellow !important;',
'    color: black !important;',
'}',
'',
'.pink {',
'    background-color: pink !important;',
'    color: black !important;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_css_classes=>'et_b_ak_Dialog '
,p_protection_level=>'C'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(userId => PCK_RI.fGetUserId, ',
'                      pageId => :APP_PAGE_ID,',
'                      accessMode => 200))',
'--and  :P388_LOGIN_USER_ROLE = 0 --and :P388_ET_B_AK_REF_THEMA_BENUTZERID is not null ',
'   and :P388_LOGIN_USER_REC !=0'))
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(917294284915928338)
,p_plug_name=>unistr('ET-B AK bearbeiten / hinzuf\00FCgen ')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_ET_B_AK'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(863762994238305697)
,p_name=>'Zugeordnete Themengebiete'
,p_parent_plug_id=>wwv_flow_imp.id(917294284915928338)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vt.nummer,',
'    --    t.bezeichnung,',
'    CASE ',
'         WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN concat(vt.bezeichnung, case when nvl(vt.gueltig, 0)=0 then '' <span class="yellow"> (in GETEX inaktiv)</span>'' else '''' END)',
'        ELSE  concat(vt.name_eng,  case when nvl(vt.gueltig, 0)=0 then '' <span class="yellow"> (in GETEX inactive)</span>'' else '''' END )',
'    END as bezeichnung,',
'    ',
'       trak.LETZTE_AENDERUNG_DATUM,',
'       nvl2(trak.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) as LETZTE_AENDERUNG_BENUTZER',
'from T_THEMA_REF_ET_B_AK trak',
'join v_thema_baum vt on (vt.themaid = trak.themaid)',
'left outer join t_Benutzer b on (b.benutzerid = trak.LETZTE_AENDERUNG_BENUTZERID)',
'where trak.et_b_akid = :P385_ET_B_AKID and gueltig = 1',
'order by vt.thema_sortorder',
''))
,p_display_when_condition=>'P385_ET_B_AKID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'Keine Daten gefunden'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(863762368430305691)
,p_query_column_id=>1
,p_column_alias=>'NUMMER'
,p_column_display_sequence=>1
,p_column_heading=>'Nummer'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(863762308298305690)
,p_query_column_id=>2
,p_column_alias=>'BEZEICHNUNG'
,p_column_display_sequence=>2
,p_column_heading=>'Bezeichnung'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(863762551643305693)
,p_query_column_id=>3
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>3
,p_column_heading=>unistr('Letzte \00C4nderung Datum')
,p_column_format=>'DD.MM.YYYY HH24:Mi'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(863762150497305689)
,p_query_column_id=>4
,p_column_alias=>'LETZTE_AENDERUNG_BENUTZER'
,p_column_display_sequence=>4
,p_column_heading=>unistr('Letzte \00C4nderung Benutzer')
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(863762072760305688)
,p_plug_name=>'Zugeordnete VKOs'
,p_parent_plug_id=>wwv_flow_imp.id(917294284915928338)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select akrb.ET_B_AK_REF_BENUTZERID,',
'       benutzer.nachname || '', '' || benutzer.vorname as BENUTZER,',
'       akrb.BEMERKUNG,  -- akrb.lead_VKO,',
'       (case when akrb.lead_VKO = 1 then emano_util.fLang(''Ja'', ''Yes'')',
'            else emano_util.fLang(''Nein'', ''No'')',
'        end) as "AK-Leiter",',
unistr('       case when akrb.land_independent =1   then emano_util.fLang(''unabh\00E4ngig'', ''independent'')'),
'           else ',
'           (select listagg(l.B_nummer, '', '') within group (order by l.B_nummer)  ',
'                 from t_land l ',
'                join  t_et_b_ak_vko_ref_land avrl on (avrl.landid = l.landid and avrl.et_b_ak_vkoid= akrb.ET_B_AK_REF_BENUTZERID))',
'               -- join T_ET_B_AK_REF_BENUTZER bakrb on (bakrb.ET_B_AK_REF_BENUTZERID = avrl.et_b_ak_vkoid)',
'               --     where  avrl.et_b_ak_vkoid = akrb.ET_B_AK_REF_BENUTZERID)',
'        end laender,',
'        (select listagg(t.nummer, '', '') within group (order by t.nummer) themen',
'          from T_THEMA t ',
'          join  t_et_b_ak_vko_ref_thema avrt on (avrt.themaid = t.themaid and avrt.et_b_ak_vkoid = akrb.ET_B_AK_REF_BENUTZERID)) themen,',
'       akrb.LETZTE_AENDERUNG_DATUM,',
'       nvl2(akrb.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) as LETZTE_AENDERUNG_BENUTZER',
'from T_ET_B_AK_REF_BENUTZER akrb',
'inner join t_benutzer benutzer on (benutzer.benutzerid = akrb.benutzerid)',
'left outer join t_benutzer b on (b.benutzerid = akrb.LETZTE_AENDERUNG_BENUTZERID)',
'where akrb.et_b_akid = :P385_ET_B_AKID',
'ORDER BY BENUTZER;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P385_ET_B_AKID'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P385_ET_B_AKID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Zugeordnete VKOs'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(863760697195305674)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'Es wurden noch keine VKOs zugeordnet.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:386:&SESSION.::&DEBUG.:386:P386_ET_B_AK_REF_BENUTZERID:#ET_B_AK_REF_BENUTZERID#'
,p_detail_link_text=>'<span aria-label="Bearbeiten/Entfernen"><span class="fa fa-pencil" aria-hidden="true" title="Bearbeiten/Entfernen"></span></span>'
,p_detail_link_condition_type=>'EXPRESSION'
,p_detail_link_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  (select count(*) from T_benutzer_ref_rolle where rolleid  in (1003, 1000)  and benutzerid =:G_BENUTZERID) >0',
''))
,p_detail_link_cond2=>'SQL'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>248932239899828730
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(863760600331305673)
,p_db_column_name=>'ET_B_AK_REF_BENUTZERID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Et B Ak Ref Benutzerid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(863760443924305672)
,p_db_column_name=>'BENUTZER'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'VKO'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(863760362027305671)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(863760301306305670)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY HH24:Mi'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(863760223034305669)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(628091814231742855)
,p_db_column_name=>'LAENDER'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('L\00E4nder')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(628091637498742854)
,p_db_column_name=>'THEMEN'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Themen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494694373276206759)
,p_db_column_name=>'AK-Leiter'
,p_display_order=>90
,p_column_identifier=>'M'
,p_column_label=>'AK-Leiter'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(855004151693591338)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2576888'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ET_B_AK_REF_BENUTZERID:BENUTZER:BEMERKUNG:LETZTE_AENDERUNG_DATUM:LETZTE_AENDERUNG_BENUTZER:LAENDER:THEMEN:AK-Leiter'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(863759944776305667)
,p_plug_name=>'Zugeordnete VEX, FbEx, KFEx'
,p_parent_plug_id=>wwv_flow_imp.id(917294284915928338)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_betreuer as (',
'    select t1.benutzerid, t1.et_b_ak_ref_thema_benutzerid, t2.benutzerid benutzerid_betreuer',
'    from t_et_b_ak_ref_thema_benutzer t1',
'    join t_et_b_ak_ref_thema_benutzer t2 on (t1.betreuerid = t2.et_b_ak_ref_thema_benutzerid)',
'    where t1.benutzerid is not null',
'), ctl_thema_benutzer as (',
'select akrb.ET_B_AK_REF_THEMA_BENUTZERID,',
'       akrb.ET_B_AKID,',
'       nvl2(b.nachname,    b.nachname || '', '' || b.vorname,   nvl(akrb.benutzername, ''(Leerstelle)'')) as BENUTZER,',
'      CASE ',
'        WHEN akrb.BENUTZERID IS NOT NULL THEN ''L''  -- LDAP user',
'        WHEN akrb.BENUTZERNAME IS NOT NULL THEN ''D''  -- Direct entry user',
'        ELSE ''D''  -- Also ''D'' when both are NULL',
'      END as ART,',
'       b.benutzerid as BENUTZERID,',
'       akrb.BEMERKUNG,',
'       akrb.LETZTE_AENDERUNG_DATUM,',
'       nvl2(akrb.LETZTE_AENDERUNG_BENUTZERID, leb.nachname || '', '' || leb.vorname, null) as LETZTE_AENDERUNG_BENUTZER,',
'       --akrb.THEMA_REF_ET_B_AKID,',
'       t.nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN t.bezeichnung',
'        ELSE t.name_eng',
'    END as thema,',
'       akrb.BEREICH,',
'       case akrb.APPROVED when 0 then emano_util.fLang(''nein'', ''no'') when 20 then emano_util.fLang(''ja'', ''yes'') else null end as approved,',
'       (case',
'          when (nvl2(b.BENUTZERID,  b.nachname || '', '' || b.vorname, nvl(akrb.benutzername, ''(Leerstelle)'')) = ''(Leerstelle)'' ',
'              or nvl2(b.BENUTZERID,  b.nachname || '', '' || b.vorname, nvl(akrb.benutzername, ''(Leerstelle)'')) = '','' ) then ''pink''',
'         when (akrb.BENUTZERID is not null or akrb.benutzername is not null) and akrb.APPROVED = 0 then ''yellow''',
'         when (akrb.BENUTZERID is not null or akrb.benutzername is not null) and akrb.APPROVED = 20 then ''lightgreen''',
'         else null   end) as cell_class,',
'       r.rolle as rolle,',
'       r.rolleid as ben_rolleid,',
'    (   case',
'        -- VKO (1000) and Fachadmin (1003) have full rights, show pencil icon for all',
'    when (  (pck_ri.fIsAuthorized01(pageId => 387, accessMode => 200) > 0 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') >0 )',
'          OR (pck_ri.fGetUserId = akrb.benutzerid and pck_ri.fIsUserInRolle(listRolleId => ''1002'') > 0  and akrb.rolleid =1002) -- VEX (1002) can edit their own records',
'          OR (pck_ri.fIsUserInRolle(listRolleId => ''1002'') > 0 and pck_ri.fGetUserId = bet.benutzerid_betreuer)   -- vex manages fbex',
'          --OR (pck_ri.fIsUserInRolle(listRolleId => ''1002'') > 0 and pck_ri.fGetUserId = akrb.LETZTE_AENDERUNG_BENUTZERID) -- VEX can edit records they created or last modified -- Changed on 28.02.2025, 10:32 pm Tharun Kommaddi',
'',
'          )',
'        then  ',
'        ''<a href="'' || case when  akrb.ET_B_AK_REF_THEMA_BENUTZERID is not null ',
'                    then apex_page.get_url(p_page => 388, p_items => ''P388_ET_B_AK_REF_THEMA_BENUTZERID'', ',
'                                              p_values => akrb.ET_B_AK_REF_THEMA_BENUTZERID, ',
'                                              p_clear_cache => 388)',
'                    else apex_page.get_url(p_page => 388, p_items => ''P388_ET_B_AKID'', ',
'                                              p_values => akrb.et_b_akid, ',
'                                              p_clear_cache => 388)',
'                    end || ''"><span  aria-label="'' || emano_util.fLang(''Zuordnung bearbeiten'', ''Edit Assignment'') || ',
'                    ''" class="fa fa-pencil" aria-hidden="true" title="'' || emano_util.fLang(''Zuordnung bearbeiten'', ''Edit Assignment'') || ''"></span></a>''',
'',
' --fbex (1006) can only see the pencil icon for fbex role',
'    when ( ( pck_ri.fGetUserId = akrb.benutzerid and pck_ri.fIsUserInRolle(listRolleId => ''1006'') > 0 and akrb.rolleid = ''1006'' ) -- KFEX (1040) can only see the pencil icon for KFEX role',
'          OR ( pck_ri.fGetUserId = akrb.benutzerid and pck_ri.fIsUserInRolle(listRolleId => ''1040'') > 0 and akrb.rolleid = ''1040'') -- ZVEX (1001) can only see the pencil icon for ZVEX role',
'        --   OR ( pck_ri.fGetUserId = akrb.benutzerid and pck_ri.fIsUserInRolle(listRolleId => ''1001'') > 0 and akrb.rolleid = ''1001'')',
'        )',
'    then ',
'        ''<a href="'' || case when  akrb.et_b_ak_ref_thema_benutzerid is not null ',
'                    then apex_page.get_url(p_page => 388, p_items => ''P388_ET_B_AK_REF_THEMA_BENUTZERID'', ',
'                                              p_values => akrb.et_b_ak_ref_thema_benutzerid, ',
'                                              p_clear_cache => 388)',
'                    else apex_page.get_url(p_page => 388, p_items => ''P388_ET_B_AKID'', ',
'                                              p_values => akrb.et_b_akid, ',
'                                              p_clear_cache => 388)',
'                    end || ''"><span  aria-label="'' || emano_util.fLang(''Zuordnung bearbeiten'', ''Edit Assignment'') || ',
'                    ''" class="fa fa-pencil" aria-hidden="true" title="'' || emano_util.fLang(''Zuordnung bearbeiten'', ''Edit Assignment'') || ''"></span></a>''',
'   else null-- No pencil icon for other cases',
'end) as link_edit',
'',
'',
' from T_ET_B_AK_REF_THEMA_BENUTZER akrb',
' --left outer join t_benutzer_ref_rolle brf on (brf.benutzer_ref_rolleid = akrb.benutzer_ref_rolleid)',
' left outer join t_Benutzer b on b.benutzerid = akrb.BENUTZERID',
' left outer join t_Benutzer leb on leb.benutzerid = akrb.LETZTE_AENDERUNG_BENUTZERID',
' left outer join cte_betreuer bet on (akrb.et_b_ak_ref_thema_benutzerid = bet.et_b_ak_ref_thema_benutzerid) ',
' left outer join t_et_b_ak_ref_thema_benutzer_ref_et_b_ak_ref_thema aktb_akt on (',
'             aktb_akt.et_b_ak_REF_THEMA_BENUTZERID = akrb.ET_B_AK_REF_THEMA_BENUTZERID',
'        )',
' left outer join t_thema_ref_et_b_ak trak on trak.THEMA_REF_ET_B_AKID = aktb_akt.THEMA_REF_ET_B_AKID',
' left outer join t_thema t on t.themaid = trak.themaid',
' ',
' left outer join t_rolle r on (r.rolleid = akrb.rolleid)',
'    ',
' where akrb.ET_B_AKID = :P385_ET_B_AKID   ',
'   and pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0 -- for VEx show all',
')',
'select ET_B_AK_REF_THEMA_BENUTZERID, ET_B_AKID, BENUTZER, ART, BEMERKUNG, ',
'    LETZTE_AENDERUNG_DATUM, LETZTE_AENDERUNG_BENUTZER, listagg(thema, ''; '') AS THEMA,',
'    BEREICH, APPROVED, CELL_CLASS, ROLLE, BENUTZERID, ben_rolleid, link_edit',
'from ctl_thema_benutzer',
'group by ET_B_AK_REF_THEMA_BENUTZERID, ET_B_AKID, BENUTZER, ART, BEMERKUNG, ',
'    LETZTE_AENDERUNG_DATUM, LETZTE_AENDERUNG_BENUTZER, ',
'    BEREICH, APPROVED, CELL_CLASS, ROLLE, BENUTZERID, ben_rolleid, link_edit',
'ORDER BY BENUTZER',
' '))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P385_ET_B_AKID'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P385_ET_B_AKID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Zugeordnete Benutzer'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ctl_thema_benutzer as (',
'select akrb.ET_B_AK_REF_THEMA_BENUTZERID,',
'       akrb.ET_B_AKID,,',
'       nvl2(b.nachname,    b.nachname || '', '' || b.vorname,   nvl(akrb.benutzername, ''(Leerstelle)'')) as BENUTZER,',
'       b.benutzerid as BENUTZERID,',
'       akrb.BEMERKUNG,',
'       akrb.LETZTE_AENDERUNG_DATUM,',
'       nvl2(akrb.LETZTE_AENDERUNG_BENUTZERID, leb.nachname || '', '' || leb.vorname, null) as LETZTE_AENDERUNG_BENUTZER,',
'       --akrb.THEMA_REF_ET_B_AKID,',
'       t.nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN t.bezeichnung',
'        ELSE t.name_eng',
'    END as thema,',
'       akrb.BEREICH,',
'       case akrb.APPROVED when 0 then emano_util.fLang(''nein'', ''no'') when 20 then emano_util.fLang(''ja'', ''yes'') else null end as approved,',
'       (case',
'          when (nvl2(b.BENUTZERID,  b.nachname || '', '' || b.vorname, nvl(akrb.benutzername, ''(Leerstelle)'')) = ''(Leerstelle)'' ',
'              or nvl2(b.BENUTZERID,  b.nachname || '', '' || b.vorname, nvl(akrb.benutzername, ''(Leerstelle)'')) = '','' ) then ''pink''',
'         when (akrb.BENUTZERID is not null or akrb.benutzername is not null) and akrb.APPROVED = 0 then ''yellow''',
'         when (akrb.BENUTZERID is not null or akrb.benutzername is not null) and akrb.APPROVED = 20 then ''lightgreen''',
'         else null   end) as cell_class,',
'       r.rolle as rolle,',
'       r.rolleid as ben_rolleid',
'    ',
' from T_ET_B_AK_REF_THEMA_BENUTZER akrb',
' --left outer join t_benutzer_ref_rolle brf on (brf.benutzer_ref_rolleid = akrb.benutzer_ref_rolleid)',
' left outer join t_Benutzer b on b.benutzerid = akrb.BENUTZERID',
' left outer join t_Benutzer leb on leb.benutzerid = akrb.LETZTE_AENDERUNG_BENUTZERID',
' left outer join t_et_b_ak_ref_thema_benutzer_ref_et_b_ak_ref_thema aktb_akt on (',
'             aktb_akt.et_b_ak_REF_THEMA_BENUTZERID = akrb.ET_B_AK_REF_THEMA_BENUTZERID',
'        )',
' left outer join t_thema_ref_et_b_ak trak on trak.THEMA_REF_ET_B_AKID = aktb_akt.THEMA_REF_ET_B_AKID',
' left outer join t_thema t on t.themaid = trak.themaid',
' ',
' left outer join t_rolle r on (r.rolleid = akrb.rolleid)',
'    ',
' where akrb.ET_B_AKID = :P385_ET_B_AKID  and ',
'     (  pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0',
'        or  pck_ri.fIsUserInRolle(listRolleId => ''1002'') > 0 -- for VEx show all',
'     )',
')',
'select ET_B_AK_REF_THEMA_BENUTZERID, ET_B_AKID, BENUTZER, BEMERKUNG, ',
'    LETZTE_AENDERUNG_DATUM, LETZTE_AENDERUNG_BENUTZER, listagg(thema, ''; '') AS THEMA,',
'    BEREICH, APPROVED, CELL_CLASS, ROLLE, BENUTZERID, ben_rolleid',
'from ctl_thema_benutzer',
'group by ET_B_AK_REF_THEMA_BENUTZERID, ET_B_AKID, BENUTZER, BEMERKUNG, ',
'    LETZTE_AENDERUNG_DATUM, LETZTE_AENDERUNG_BENUTZER, ',
'    BEREICH, APPROVED, CELL_CLASS, ROLLE, BENUTZERID, ben_rolleid',
'ORDER BY BENUTZER',
' '))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(863759933388305666)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'Es wurden noch keine Benutzer zugeordnet.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_description=>wwv_flow_string.join(wwv_flow_t_varchar2(
'exp - plsql - pck_ri.fIsUserInRolle(listRolleId =>''1000:1003'')>0',
'',
'',
'',
'',
'include link ',
'',
'wriet access ',
'',
'(select count(*) from T_benutzer_ref_rolle where rolleid  in (1003, 1000)  and benutzerid =:G_BENUTZERID) >0',
'OR',
'( (select count(*) from T_benutzer_ref_rolle where rolleid  in (1002)  and benutzerid =:G_BENUTZERID) >0',
'  --and ( :BENUTZERID = 1280 ) --OR ( :BEN_ROLLEID in (1006)   ) )  --and betreuer id = G_BENUTZERID',
')',
'',
'',
'sql expr ',
'',
'',
'',
'<span aria-label="Bearbeiten/Entfernen"><span class="fa fa-pencil" aria-hidden="true" title="Bearbeiten/Entfernen"></span></span>'))
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>248933003706828738
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(863759761490305665)
,p_db_column_name=>'ET_B_AK_REF_THEMA_BENUTZERID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Et B Ak Ref Thema Benutzerid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
,p_column_comment=>'select 1 from dual where :G_BENUTZERID = 2000;'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(863759727680305664)
,p_db_column_name=>'ET_B_AKID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Et B Akid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(845779422984438289)
,p_db_column_name=>'THEMA'
,p_display_order=>30
,p_column_identifier=>'P'
,p_column_label=>'Themen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(863759096086305658)
,p_db_column_name=>'BEREICH'
,p_display_order=>40
,p_column_identifier=>'H'
,p_column_label=>'Vertretener Bereich'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(863759494490305662)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(863759414290305661)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(863758737382305655)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>70
,p_column_identifier=>'J'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(845780770526438303)
,p_db_column_name=>'BENUTZER'
,p_display_order=>80
,p_column_identifier=>'K'
,p_column_label=>'Nachname, Vorname'
,p_column_html_expression=>'<span bg-style="#CELL_CLASS#">#BENUTZER#</span>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1055143261051317525)
,p_db_column_name=>'ART'
,p_display_order=>90
,p_column_identifier=>'U'
,p_column_label=>'Art'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(845780554971438301)
,p_db_column_name=>'APPROVED'
,p_display_order=>100
,p_column_identifier=>'M'
,p_column_label=>unistr('Best\00E4tigt')
,p_column_html_expression=>'<span bg-style="#CELL_CLASS#">#APPROVED#</div>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(845780462586438300)
,p_db_column_name=>'CELL_CLASS'
,p_display_order=>110
,p_column_identifier=>'N'
,p_column_label=>'Cell Class'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(845779300193438288)
,p_db_column_name=>'ROLLE'
,p_display_order=>120
,p_column_identifier=>'Q'
,p_column_label=>'Rolle'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(788672167155777003)
,p_db_column_name=>'BENUTZERID'
,p_display_order=>130
,p_column_identifier=>'R'
,p_column_label=>'Benutzerid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(788672080918777002)
,p_db_column_name=>'BEN_ROLLEID'
,p_display_order=>140
,p_column_identifier=>'S'
,p_column_label=>'Ben Rolleid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(834279183686992784)
,p_db_column_name=>'LINK_EDIT'
,p_display_order=>150
,p_column_identifier=>'T'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(854993919592361315)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2576991'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LINK_EDIT:THEMA:BEREICH:ROLLE:BENUTZER:ART:APPROVED:BEMERKUNG:LETZTE_AENDERUNG_DATUM:LETZTE_AENDERUNG_BENUTZER:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(917291923067928250)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(917291472745928250)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(917291923067928250)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(917290011339928216)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(917291923067928250)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>unistr('javascript:apex.confirm(''M\00F6chten Sie den Arbeitskreis mit allen verkn\00FCpften Daten l\00F6schen?'',''DELETE'');')
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(863760979219305677)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(863762072760305688)
,p_button_name=>'BTN_ADD_VKO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'VKO zuordnen'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:386:&SESSION.::&DEBUG.:386:P386_ET_B_AKID:&P385_ET_B_AKID.'
,p_icon_css_classes=>'fa-plus-circle-o'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(863758840807305656)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(863759944776305667)
,p_button_name=>'BTN_ADD_THEMA_BENUTZER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Anwender zuordnen'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:388:&SESSION.::&DEBUG.:388:P388_ET_B_AKID:&P385_ET_B_AKID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from T_ET_B_AK_REF_THEMA_BENUTZER akrb',
' --left outer join t_benutzer_ref_rolle brf on (brf.benutzer_ref_rolleid = akrb.benutzer_ref_rolleid)',
' where (akrb.ET_B_AKID = :P385_ET_B_AKID and benutzerid =:G_BENUTZERID',
'        and pck_ri.fIsUserInRolle(listRolleId => ''1002'') > 0 ) ',
' or pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002'') > 0 -- for VEx show all'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-plus-circle-o'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(917289615145928216)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(917291923067928250)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P385_ET_B_AKID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(917289217800928216)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(917291923067928250)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P385_ET_B_AKID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(949210189324439897)
,p_name=>'P385_BEZEICHNUNG_ENGLISCH'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(917294284915928338)
,p_item_source_plug_id=>wwv_flow_imp.id(917294284915928338)
,p_prompt=>'Arbeitskreis English'
,p_source=>'NAME_ENG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>250
,p_begin_on_new_line=>'N'
,p_read_only_when=>'pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') = 0'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(949208179781439877)
,p_name=>'P385_JS_LANG'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(917294284915928338)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
':FSP_LANGUAGE_PREFERENCE',
''))
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(917293892027928327)
,p_name=>'P385_ET_B_AKID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(917294284915928338)
,p_item_source_plug_id=>wwv_flow_imp.id(917294284915928338)
,p_source=>'ET_B_AKID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(917293604237928280)
,p_name=>'P385_BEZEICHNUNG'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(917294284915928338)
,p_item_source_plug_id=>wwv_flow_imp.id(917294284915928338)
,p_prompt=>'Arbeitskreis'
,p_source=>'BEZEICHNUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>250
,p_read_only_when=>'pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') = 0'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(917293209709928252)
,p_name=>'P385_KURZ'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(917294284915928338)
,p_item_source_plug_id=>wwv_flow_imp.id(917294284915928338)
,p_prompt=>'Kurzbezeichnung'
,p_source=>'KURZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_read_only_when=>'pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') = 0'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(863763391795305701)
,p_name=>'P385_KONZERN_CLUSTER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(917294284915928338)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Konzern Cluster'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select konzern_clusterid',
'from t_konzern_cluster_ref_et_b_ak',
'where et_b_akid = :P385_ET_B_AKID'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung as d, konzern_clusterid as r ',
'from t_konzern_cluster',
'order by bezeichnung asc'))
,p_cSize=>30
,p_read_only_when=>'pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') = 0'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(773132382925399302)
,p_name=>'P385_HAEUFIGKEIT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(917294284915928338)
,p_item_source_plug_id=>wwv_flow_imp.id(917294284915928338)
,p_prompt=>unistr('H\00E4ufigkeit')
,p_source=>'HAEUFIGKEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct haeufigkeit',
'from t_et_b_ak',
'order by haeufigkeit'))
,p_cSize=>30
,p_cMaxlength=>800
,p_read_only_when=>'pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') = 0'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'fetch_on_type', 'Y',
  'match_type', 'CONTAINS_IGNORE',
  'use_cache', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(917291428189928250)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(917291472745928250)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(917290593019928225)
,p_event_id=>wwv_flow_imp.id(917291428189928250)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(863760853551305676)
,p_name=>'Dialog VKO Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(863762072760305688)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(863760752638305675)
,p_event_id=>wwv_flow_imp.id(863760853551305676)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(863762072760305688)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(852829496306138184)
,p_name=>'Dialog Thema Anwender Closed'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(863759944776305667)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(852829344795138183)
,p_event_id=>wwv_flow_imp.id(852829496306138184)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(863759944776305667)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(845780344648438299)
,p_name=>'After Refresh'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(863759944776305667)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(845780299389438298)
,p_event_id=>wwv_flow_imp.id(845780344648438299)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'setCellBackground();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(554264313434028800)
,p_name=>'Switch VKO_ADD Button'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(863762072760305688)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexbeforerefresh'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>'( select count(*) from T_benutzer_ref_rolle where rolleid in (1003, 1000) and benutzerid =:G_Benutzerid ) = 0'
,p_display_when_cond2=>'SQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554264232568028799)
,p_event_id=>wwv_flow_imp.id(554264313434028800)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(863760979219305677)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(530864757372178092)
,p_name=>'switch Add Thema_Benutz_Button'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(863759944776305667)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexbeforerefresh'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'( select count(*) from T_benutzer_ref_rolle where rolleid ',
'in (1003, 1000, 1002) and benutzerid =:G_Benutzerid ) = 0'))
,p_display_when_cond2=>'SQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(530864691034178091)
,p_event_id=>wwv_flow_imp.id(530864757372178092)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(863758840807305656)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(863763228309305699)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Remove Verkn\00FCpfungen')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Konzern-Cluster',
'delete from t_konzern_cluster_ref_et_b_ak ',
'where et_b_akid = :P385_ET_B_AKID;',
'',
'-- Zugeordnete VKOs',
'delete from t_et_b_ak_ref_benutzer',
'where et_b_akid = :P385_ET_B_AKID;',
'',
unistr('-- Verantwortliche f\00FCr Themen'),
'delete from t_et_b_ak_ref_thema_benutzer_ref_et_b_ak_ref_thema ',
'where et_b_ak_ref_thema_benutzerid in (',
'    select et_b_ak_ref_thema_benutzerid',
'    from t_et_b_ak_ref_thema_benutzer',
'    where et_b_akid = :P385_ET_B_AKID',
');',
'',
'-- Verantwortliche',
'delete from t_et_b_ak_ref_thema_benutzer',
'where et_b_akid = :P385_ET_B_AKID;',
'',
'-- Zuordnung zu Vorschriften',
'delete from t_vorschrift_ref_et_b_ak ',
'where et_b_akid = :P385_ET_B_AKID;',
'',
'-- Zuordnung zu Themen',
'delete from t_thema_ref_et_b_ak',
'where et_b_akid = :P385_ET_B_AKID;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(917290011339928216)
,p_internal_uid=>2808449087590082536
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(917288350140928213)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(917294284915928338)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('Process form ET-B AK bearbeiten / hinzuf\00FCgen')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2754923965758460022
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(863763288685305700)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save ET-B AK ref Konzern Cluster'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'merge into t_konzern_cluster_ref_et_b_ak dest',
'using (select :P385_ET_B_AKID as et_b_akid, column_value as konzern_clusterid',
'      from table(apex_string.split_numbers(:P385_KONZERN_CLUSTER, '':''))',
'      ) src',
'on (src.konzern_clusterid = dest.konzern_clusterid',
'   and src.et_b_akid = dest.et_b_akid)',
'when not matched then ',
'insert(et_b_akid, konzern_clusterid)',
'values (src.et_b_akid, src.konzern_clusterid);',
'',
'',
'delete from t_konzern_cluster_ref_et_b_ak cra',
'where cra.et_b_akid = :P385_ET_B_AKID',
'    and cra.konzern_clusterid not in (select column_value from TABLE(APEX_STRING.split_numbers(:P385_KONZERN_CLUSTER, '':'')));'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE, CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2808449027214082535
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(917288016149928213)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2754924299749460022
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(917288826739928215)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(917294284915928338)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form ET-B AK bearbeiten / hinzuf\00FCgen')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2754923489159460020
);
wwv_flow_imp.component_end;
end;
/
