prompt --application/pages/page_00202
begin
--   Manifest
--     PAGE: 00202
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>202
,p_name=>'Cockpit'
,p_alias=>'COCKPIT'
,p_step_title=>'Cockpit'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#THEME_DB_IMAGES#jquery.contextMenu#MIN#.js',
'#THEME_DB_IMAGES#jquery.ui.position#MIN#.js'))
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function redirectThema(aThemaID) {',
'    apex.server.process(',
'        ''loadLinkThema'',                           ',
'        { x01: aThemaID }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                ',
'                ///apex.navigation.dialog(pData);',
'                eval(pData);',
'                //console.log(pData);',
'                ',
'            },',
'            dataType: "text"                     ',
'        }',
'    );        }',
'',
'function loadLinks(aVorschriftID) {',
'    var dfd = jQuery.Deferred();    ',
'    apex.server.process(',
'        ''loadLinks'',                           ',
'        { x01: aVorschriftID }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                if (pData.linkgetex2) {',
'                    pData.linkgetex2.callback = function() { apex.navigation.openInNewWindow(pData.linkgetex2.url); };',
'                }',
'                if (pData.linkdms) {',
'                    pData.linkdms.callback = function() { apex.navigation.openInNewWindow(pData.linkdms.url); };',
'                }      ',
'                dfd.resolve(pData);',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'    return dfd.promise();   ',
'}',
'',
'',
'',
'',
'',
'',
'function loadThemaDaten(aThemaID) {',
'    var dfd = jQuery.Deferred();    ',
'    apex.server.process(',
'        ''loadThemaDaten'',                           ',
'        { x01: aThemaID }, ',
'        {',
'            success: function (pData)',
'            {             ',
'                dfd.resolve(pData);',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'    return dfd.promise();   ',
'}',
'',
'function loadDates(aVorschriftID,aMode) {',
'    var dfd = jQuery.Deferred();    ',
'    apex.server.process(',
'        ''loadDates'',                           ',
'        { x01: aVorschriftID,',
'          x02: aMode }, ',
'        {',
'            success: function (pData)',
'            {                 ',
'                dfd.resolve(pData);',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'    return dfd.promise();   ',
'}',
'',
'function redirectVorschrift(aVorschriftID) {',
'    apex.server.process(',
'        ''loadLinkVorschrift'',                           ',
'        { x01: aVorschriftID }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                ',
'                //apex.navigation.openInNewWindow(pData);',
'                javascript:window.open(pData,''_blank'');                ',
'                ',
'            },',
'            dataType: "text"                     ',
'        }',
'    );        ',
'}',
'',
'function redirectRegel(aLandID, aThemaID) {',
'    apex.server.process(',
'        ''loadLinkRegel'',                           ',
'        { x01: parseInt(aLandID),',
'          x02: parseInt(aThemaID)',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                ',
'                //apex.navigation.openInNewWindow(pData);',
'                javascript:window.open(pData,''_blank'');                ',
'                ',
'            },',
'            dataType: "text"                     ',
'        }',
'    );        ',
'}',
'',
'function redirectTree(aVorschriftID) {',
'    apex.server.process(',
'        ''loadLinkTree'',                           ',
'        { x01: aVorschriftID }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                console.log(pData);',
'                javascript:window.open(pData,''_blank'');  ',
'            },',
'            dataType: "text"                     ',
'        }',
'    );        ',
'}',
'',
'function loadLaenderShuttle() {',
'    var shuttleName = ''P202_FILTER_BLAND'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadLaenderShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P202_FILTER_LAENDERGRUPPE''),',
'          x03: $v(''P202_FILTER_BLAND_PRE''),',
'          x04: $v(''P202_INCLUDE_INACT_BESTAND'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                console.log(pData);',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'',
'function loadThemenShuttle() {',
'    var shuttleName = ''P202_FILTER_THEMEN'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadThemenShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P202_FILTER_THEMEN_PRE''),',
'          x03: $v(''P202_FILTER_THEMEN_PRE_AK'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'function loadBemerkungen(aThemaID, aLandID, aVorschriftID) {',
'    var dfd = jQuery.Deferred();    ',
'    apex.server.process(',
'        ''loadBemerkungen'',                           ',
'        { x01: aThemaID, x02: aLandID, x03: aVorschriftID }, ',
'        {',
'            success: function (pData)',
'            {                   ',
'                dfd.resolve(pData);',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'    return dfd.promise();   ',
'}',
'',
'',
'',
'',
unistr('/* F\00FCgt ein Item anhand der ID zu einem Shuttle hinzu,'),
'   ohne dass es dabei zu einem Refresh Effekt kommt */',
'',
'function addItemToShuttle(aShuttle, aID, aDisplay) {',
'    var lLeft = $(''#'' + aShuttle + ''_LEFT'');',
'    var lRight = $(''#'' + aShuttle + ''_RIGHT'');',
'    lLeft.find(''option[value='' + aID + '']'').remove();',
'    lRight.append(''<option value="'' + aID + ''">'' + aDisplay + ''</option>'');',
'}',
'',
'function loadVorschriftInfo(aVorschriftID) {',
'    var dfd = jQuery.Deferred();    ',
'    apex.server.process(',
'        ''loadVorschriftInfo'',                           ',
'        { x01: aVorschriftID }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                console.log(pData);',
'                $(''#table_row_info'').html('''');',
'                $(''#table_row_info'').append(''<div class="table-col table-col-th">Nummer</div><div class="table-col">'' + pData.vorschrift.nummer + ''</div>'');',
'                $(''#table_row_info'').append(''<div class="table-col table-col-th">Titel</div><div class="table-col">'' + pData.vorschrift.titel + ''</div>'');',
'                $(''#table_row_date'').html('''');',
'                pData.vorschrift.daten.forEach(function(datum) { ',
'                    var str_datum = ''<div class="table-col table-col-th"><strong>'' + datum.title + ''</strong></div><div class="table-col">'' + datum.datum + ''</div>'';',
'                    $(''#table_row_date'').append(str_datum);',
'                });',
'                ',
'                $(''#table_row_date'').nextAll().remove();',
'                if (pData.vorschrift.verlinkte_objekte.length > 0) {',
'                    $(''#vinfo'').append(''<hr style="visibility: hidden;" /><div class="table-row table-col-th" id="row_et_text">Bindende Einsatztermine aus vernetzter Rahmenrichtlinie, GSR, Rahmenverodnung</div>'');//.css(''margin-top'', ''10px'');',
'                    pData.vorschrift.verlinkte_objekte.forEach(function(verl_vs) { ',
'                        var elem_ext = $(''#vinfo'').append(''<div class="table-row" id="row_et_text2"></div>'');',
'                        elem_ext.append(''<div class="table-col table-col-th" style="font-weight: bold;">Nummer</div><div class="table-col">'' + verl_vs.nummer + ''</div>'');',
'                        elem_ext.append(''<div class="table-col table-col-th" style="font-weight: bold;">Titel</div><div class="table-col">'' + verl_vs.titel + ''</div>'');',
'                    ',
'                        var elem_daten = $(''#vinfo'').append(''<div class="table-row"></div>'');',
'                        verl_vs.daten.forEach(function(datum_vs) { ',
'                            var str_datum = ''<div class="table-col table-col-th">'' + datum_vs.title + ''</div><div class="table-col">'' + datum_vs.datum + ''</div>'';',
'                            elem_daten.append(str_datum);',
'                        });',
'                    ',
'                        if (typeof verl_vs.max_homologation !== ''undefined'') ',
'                        {',
'                              var elem_row_homol = $(''#vinfo'').append(''<div class="table-row"></div>'');',
'                              elem_row_homol.append(''<div class="table-col">'' + ',
unistr('                                  ''Folgende UN-R Serien sind f\00FCr die Homolagion zugelassen</div>'');'),
'                            /*var elem_homol = $(''#vinfo'').append(''<div class="table-row"><div class="table-col">'' + ',
unistr('                              ''Folgende UN-R Serien sind f\00FCr die Homolagion zugelassen</div></div>'');      */'),
'                            ',
'                              var str_homolog_vs = ''<div class="table-col table-col-th">'' + verl_vs.max_homologation + ''</div>'';',
'                              elem_row_homol.append(str_homolog_vs);    ',
'                            ',
'                        }',
'                        $(''#vinfo'').append(''<hr style="clear: both; height: 1px; border:0; background-color: #cccccc;" />'');',
'                    });',
'                }',
'',
'                //$(''#vinfo'').append(''<div class="table-row" id="table_row_raw"><pre style="font-size: 1.0rem;"></pre></div>'');',
'                //$(''#table_row_raw pre'').text(JSON.stringify(pData, null, ''    ''));',
'                ',
'                dfd.resolve(pData);',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'    return dfd.promise();   ',
'}',
'',
'',
'/*',
'function loadMfVLinks(vid) {',
'    var dfd = jQuery.Deferred();',
'    apex.server.process(',
'        ''loadMfVLinks'',',
'        {',
'            x01: vid',
'        },',
'        {',
'            success: function(pData) {',
'                var items = [];',
'',
'                if (pData.hasOwnProperty(''message'')) {',
'                    ',
'                    items.push({',
'                        name: pData.message,',
'                        isHtmlName: true,',
'                        callback: function() {} // No action needed',
'                    });',
'                } else {',
'                    // Process the items ',
'                    for (var key in pData) {',
'                        if (pData.hasOwnProperty(key) && key !== ''url'') {',
'                            items.push({',
'                                name: pData[key].name,',
'                                // name: pData[key].name.replace(/\s+/g, '' ''),',
'                                isHtmlName: pData[key].isHtmlName,',
'                                callback: (function(url) {',
'                                    return function() {',
'                                        apex.navigation.openInNewWindow(url);',
'                                        // apex.region("rMfVs").refresh();',
'',
'                                    };',
'                                })(pData.url)',
'                            });',
'                        }',
'                    }',
'                }',
'                ',
'                dfd.resolve(items);',
'            },',
'            dataType: "json"',
'        }',
'    );',
'    return dfd.promise();',
'}',
'*/',
'',
'//  wokring mfv with cursor',
' ',
'function loadMfVLinks(vid) {',
'    var dfd = jQuery.Deferred();',
'    apex.server.process(',
'        ''loadMfVLinks'',',
'        {',
'            x01: vid',
'        },',
'        {',
'            success: function(pData) {',
'                var items = [];',
'',
'                if (pData.hasOwnProperty(''message'') && pData.message === ''Keine MfVs zugeordnet.'') {',
'                    items.push({',
'                        name: pData.message,',
'                        isHtmlName: true,',
'                        callback: function() {}, // No action needed',
'                        className: ''no-hover-hand'' // this class is added in inline css',
'                    });',
'                } else if (pData.hasOwnProperty(''counts'') && pData.hasOwnProperty(''url'')) {',
'                    items.push({',
'                        name: pData.counts.name,',
'                        isHtmlName: pData.counts.isHtmlName,',
'                        callback: function(url) {',
'                            return function() {',
'                                apex.navigation.openInNewWindow(url);',
'                            };',
'                        }(pData.url)',
'                    });',
'                }',
'                ',
'                dfd.resolve(items);',
'            },',
'            dataType: "json"',
'        }',
'    );',
'    return dfd.promise();',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'// function initVorschriftInfoHover() {',
'',
'',
'// $(''div.vorschrift .infobox'').hover(function() {',
'//     var lVorschriftId = $(this).parent().attr("vid");',
'//     $(''<div id="vinfo" class="vinfo div-table"><h2>Vorschriften Info</h2>'' +',
'//           ''<div class="table-row" id="table_row_info"></div>'' +',
'//           ''<div class="table-row" id="table_row_date"></div>'' +',
'//           ''</div>'').appendTo(document.body);',
'//     $(''#vinfo'').css({',
'//         top: $(this).offset().top + $(this).outerHeight(), left: $(this).offset().left',
'//     });',
'//     loadVorschriftInfo(lVorschriftId);',
'//     },',
'//     function() {',
'//         $(''#vinfo'').remove();',
'//     }                    ',
'// );',
'',
'',
'// }',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#P202_FLAG_KF'').detach().insertBefore(''#BTN_MANAGE_PROFILE'').wrap(''<div style="display:inline-block; margin-right:10px;"></div>'');',
unistr('$("label[for=''P202_FLAG_KF_Y'']").attr(''title'',''Blendet Vorschriften, die durch letztg\00FCltige Fassungen ersetzt worden sind, ein'');'),
unistr('$("label[for=''P202_FLAG_KF_N'']").attr(''title'',''Blendet Vorschriften, die durch letztg\00FCltige Fassungen ersetzt worden sind, aus'');'),
'$(''#P202_FLAG_KF_LABEL'').hide();',
'',
'// Text-Item muss da sein, da sonst Submit bei Enter im Vorfilter-Feld',
'$(''#P202_TEXTFIELD'').closest(''div.row'').hide();',
'',
unistr('// Damit die Mini-Buttons zum erh\00F6hen / verringern angezeigt werden'),
'$(''#P202_HIGHLIGHT_DATUM_AENDERUNG'').attr(''type'', ''number'');',
'',
'',
'',
'',
'// hover code - begin',
'// initVorschriftInfoHover();',
'',
'',
'$(document).ready(function() {',
'',
'    $(document).off(''mouseenter'', ''div.vorschrift .infobox'');',
'    $(document).off(''mouseleave'', ''div.vorschrift .infobox'');',
'    ',
'    $(document).on(''mouseenter'', ''div.vorschrift .infobox'', function() {',
'       ',
'        $(''#vinfo'').remove();',
'        ',
'        var lVorschriftId = $(this).parent().attr("vid");',
'        ',
'       ',
'        $(''<div id="vinfo" class="vinfo div-table"><h2>Vorschriften Info</h2>'' +',
'              ''<div class="table-row" id="table_row_info"></div>'' +',
'              ''<div class="table-row" id="table_row_date"></div>'' +',
'              ''</div>'').appendTo(''body'');',
'        ',
'       ',
'        var $infobox = $(this);',
'        var position = $infobox.offset();',
'        var windowHeight = $(window).height();',
'        var infoboxHeight = $infobox.outerHeight();',
'        ',
'        ',
'        $(''#vinfo'').css({',
'            ''position'': ''absolute'',',
'            ''top'': position.top + infoboxHeight,',
'            ''left'': position.left,',
'            ''z-index'': 10000,  ',
'            ''background-color'': ''white'',',
'            ''border'': ''1px solid black'',',
'            ''padding'': ''5px'',',
'            ''display'': ''block'',',
'            ''visibility'': ''visible''',
'        });',
'        ',
'        ',
'        // console.log("Info box created for VorschriftId: " + lVorschriftId);',
'        // console.log("Position: ", position);',
'        ',
'',
'        loadVorschriftInfo(lVorschriftId);',
'    });',
'    ',
'    $(document).on(''mouseleave'', ''div.vorschrift .infobox'', function() {',
'        $(''#vinfo'').remove();',
'    });',
'    ',
'    // console.log("Hover functionality initialized using event delegation");',
'});',
'',
'',
'',
'// hover code - end',
'',
'',
'',
'',
'$(''div.vorschrift .infobox'').hover(function() {',
'    var lVorschriftId = $(this).parent().attr("vid");',
'    $(''<div id="vinfo" class="vinfo div-table"><h2>Vorschriften Info</h2>'' +',
'          ''<div class="table-row" id="table_row_info"></div>'' +',
'          ''<div class="table-row" id="table_row_date"></div>'' +',
'          ''</div>'').appendTo(document.body);',
'    $(''#vinfo'').css({',
'        top: $(this).offset().top + $(this).outerHeight(), left: $(this).offset().left',
'    });',
'    loadVorschriftInfo(lVorschriftId);',
'    },',
'    function() {',
'        $(''#vinfo'').remove();',
'    }                    ',
');',
'',
'$(document).ready(function () {',
'        ''use strict'';',
'',
'        $.contextMenu({',
'            selector: ''div.vorschrift'',',
'            build: function ($trigger, e) {',
'                ',
'                var vid = $trigger.attr(''vid'');',
'                var tid = $trigger.attr(''tid'');',
'                var lid = $trigger.attr(''lid'');',
'                var vnummer = $trigger.attr(''vnummer'');',
'                var vbezeichnung = $trigger.attr(''vbezeichnung'');',
'                var rrid = $trigger.attr(''rrid'');',
'                var rrnummer = $trigger.attr(''rrnummer'');',
'                var rrvk = $trigger.attr(''rrvk'');',
'                var regelSeiteSichtbar = $v(''P202_REGELSEITE_SICHTBAR'');',
'                ',
'                var items = {};',
'                items.close = { icon: "fa-close", name: "&nbsp;", isHtmlName: true, className: "nohover", callback: function() { return true; }};',
'                ',
'                ',
'                items.vnummer = { name: "<b>Nummer:</b> " + vnummer, isHtmlName: true, callback: function() { redirectVorschrift(vid)} };',
'                ',
'                if (vbezeichnung) {',
'                    items.vbezeichnung = { name: "<b>Bezeichnung:</b> " + vbezeichnung, className: "nohover", isHtmlName: true};',
'                }    ',
'',
'                /*items.kommentar = {',
'                    name: "Bemerkung",',
'                    icon: "fa-comment",',
'                    items: loadComment(vid,lid)',
'                };*/',
'',
'                if (regelSeiteSichtbar == 1) {',
'                    items.regel = {',
'                        name: "<b>Regel:</b> " + $trigger.attr(''regel''), isHtmlName: true,',
'                        callback: function() { redirectRegel($trigger.attr(''lid''),$trigger.attr(''tid''))}',
'                    };',
'                }',
unistr('                items.tree = { name: "Baumansicht \00F6ffnen", callback: function() { redirectTree(vid)}};'),
'                items.links = {',
'                    name: "Externe Links",',
'                    icon: "fa-link",',
'                    items: loadLinks(vid)',
'                }',
'                ',
'',
'',
'',
'',
'                var itemsdates = {};',
'                itemsdates.dates1 = { name: "Vorschrift", items: loadDates(vid,1)};',
'                if (rrid) itemsdates.dates2 = { name: "Rahmenrichtlinie", items: loadDates(rrid,1)};',
unistr('                if (rrvk) itemsdates.dates3 = { name: "Verkn\00FCpfung", items: loadDates(rrvk,2)};'),
'                ',
'                items.dates = {',
'                    name: "Einsatzdaten",',
'                    icon: "fa-calendar",',
'                    items: itemsdates',
'                    ',
'                    ',
'                    /*icon: "fa-calendar",',
'                    items: loadDates(vid)*/',
'                }',
'                if (rrid) {',
'                    items.rr = { name: "<b>Rahmenrichtlinie: </b> " + rrnummer, isHtmlName : true, callback: function() { redirectVorschrift(rrid)}};',
'                }',
'                ',
unistr('                items.bemerkungen = { icon: "fa-file-text-o", name: "Bemerkung zur Verkn\00FCpfung", items: loadBemerkungen(tid, lid, vid) };'),
'',
'',
'                items.loadMfVLinks = {',
'                    name: "MfV",',
'                    icon: "fa-info",',
'                    items: loadMfVLinks(vid)',
'                };',
'                ',
'',
'                items.permal = { name: "Permalink", callback: function(){ ',
'                    var lPermalink = window.location.protocol + ''//'' ',
'                                  + window.location.hostname',
'                                  + '':'' + window.location.port',
'                                  + window.location.pathname',
'                                  + ''?p=&APP_ALIAS.:VORSCHRIFT::::25:P25_VORSCHRIFTID:''',
'                                  + vid;',
'                    navigator.clipboard.writeText(lPermalink);',
'                    alert(''Permalink in die Zwischenablage kopiert:\n\n'' + lPermalink);',
'                } };',
'                ',
'',
'                ',
'',
'                ',
'                return {items: items};',
'',
'',
'                ',
'',
'            }',
'        });',
'    ',
'        $.contextMenu({',
'            selector: ''div.tmenu'',',
'            build: function ($trigger, e) {',
'                ',
'                var tid = $trigger.attr(''tid'');',
'                var tnummer = $trigger.attr(''tnummer'');',
'                var tbezeichnung = $trigger.attr(''tname'');',
'                var tak = $trigger.attr(''tak'');',
'                ',
'                var items = {',
'                        "tnummer": { name: "<b>Nummer:</b> " + tnummer, isHtmlName: true, callback: function() { redirectThema(tid)} }',
'                };',
'                if (tbezeichnung) {',
'                    items.tbezeichnung = { name: "<b>Bezeichnung:</b> " + tbezeichnung, className: "nohover", isHtmlName: true};',
'                } ',
'                ',
'                if (tak) {',
'                    items.tak = { name: "<b>Arbeitskreis:</b> " + tak, className: "nohover", isHtmlName: true};',
'                }',
'                ',
'                ',
'                /*items.adddata = {',
unistr('                    name: "Zus\00E4tzliche Daten",'),
'                    items: loadThemaDaten(tid)',
'                }*/',
'                ',
'                return {items: items};',
'',
'            }',
'        });    ',
'',
'    });'))
,p_css_file_urls=>'#THEME_DB_IMAGES#jquery.contextMenu#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'div.highlight {',
'    background-color: yellow;',
'}',
'',
'.t-Region.is-maximized > .t-Region-bodyWrap > .t-Region-body {',
'    display: inline-block;',
'}',
'',
'.marginright {',
'    margin-right: 3px;',
'}',
'.marginleft {',
'    margin-left: 3px;',
'}',
'',
'.gridcontainer {',
'    display: grid;',
'    z-index: 2; ',
'    grid-gap: 1px;',
'    box-sizing: border-box;',
'    font-family: Audi Type;',
'    font-size: 12px;',
'}',
'.gridcontainer>div {box-shadow: 0 0 0 1px #808080; z-index: 2; padding: 2px}',
'.gridcontainer div.topleft {grid-column: 1/3; grid-row: 1/3}',
'',
'.gridcontainer div.land {grid-row: 1/2; grid-column: span 6; position: sticky; top: 0px; background-color: white; z-index: 3}',
'.gridcontainer div.subheader {position: sticky; top: 66px; background-color: white; grid-row: 2; z-index: 3}',
'',
'.gridcontainer div.themanum {grid-column: 1/2; position: sticky; left: 0px; background-color: white; z-index: 3}',
'.gridcontainer div.themaname {grid-column: 2/3; position: sticky; left: 40px; background-color: white; z-index: 3}',
'',
'.gridcontainer div.vorschrift { }',
'',
'.gridcontainer div.land {',
'    display: flex;',
'    justify-content: flex-end;',
'    align-items: center;',
'}',
'',
'',
'.gridcontainer div.bg,.gridcontainer div.bgv {',
'    z-index: 1 !important;',
'    opacity: 0.5;',
'',
'}',
'',
'.gridcontainer div.bg:nth-child(even), .gridcontainer div.themanum:nth-child(odd), .gridcontainer div.themaname:nth-child(even) {',
'    background-color: #D0D0D0;',
'}',
'.gridcontainer div.bg {',
'    box-shadow: none;',
'}',
'.gridcontainer div.bgv {',
'    box-shadow: 0 0 0 1px #808080;',
'}',
'',
'div.land div {',
'    border: none;',
'}',
'div.land div.landname {',
'    flex-grow: 1;',
'    text-align: center;',
'    font-weight: 700;',
'}',
'div.land div.landb img {',
'    width: 30px;',
'    margin: 5px;',
'}',
'div.land div.landr {',
'    width: 80px;',
'}',
'div.land div.laendergruppen {',
'    font-weight: normal;',
'    font-size: 10px;',
'}',
'',
'',
'',
'',
'.rr {',
'    border: 1px solid black;',
'    font-size: 0.8em;',
'    padding: 1px; margin-right: 3px;',
'}',
'.rr::before {',
'    content: "RR"',
'}',
'',
'.ventwurf {',
'    color:orange;',
'    display: inline-block;',
'    font-size: 14px;',
'}',
'.vnrelevant {',
'    color:red;',
'    display: inline-block;',
'    font-size: 14px;',
'}',
'.ventwurf::before, .vnrelevant::before {',
'    font-family: ''Font APEX Small'' !important;',
'    content: "\f071"',
'}',
'',
'',
'',
'',
'',
'',
'.context-menu-root {',
'    visibility: visible;',
'}',
'',
'.context-menu-icon-loading::before {',
'    content: "\f110";',
'}',
'',
'.context-menu-icon--fa {',
'    font-size: 14px !important;',
'}',
'',
'.context-menu-item.context-menu-visible > .context-menu-list {',
'    max-width: none !important;',
'    width: 300px !important;',
'}',
'',
'.context-menu-item.context-menu-hover.nohover {',
'    cursor: auto;',
'    background-color: inherit;',
'    color: black;',
'}',
'',
'.context-menu-icon.context-menu-icon--fa.context-menu-hover:before {',
'    color: #2980b9 !important;',
'    cursor: pointer !important;',
'}',
'',
'',
unistr('/* f\00FCr Icons an den Vorschriften */'),
'.vIcon {',
'    /*display: inline-block;*/',
'    width: 40px',
'}',
'',
'/* Vorschriften-Info Overlay */',
'div.vinfo {',
'    position: absolute; ',
'    z-index:3; ',
'    border: 1px solid;',
'}',
'div.div-table {',
'  display: table;         ',
'  width: auto;         ',
'  background-color: white;         ',
'  border: 1px solid #666666;         ',
'  /*border-spacing: 5px; /* cellspacing:poor IE support for  this */',
'}',
'div.table-row {',
'  display: table-row;',
'  width: auto;',
'  clear: both;',
'}',
'div.table-col {',
'  float: left; /* firefox */',
'  display: table-column;         ',
'  padding: 3px;',
'  margin: 2px;',
'}',
'div.table-col-th {',
'  background-color: #cccccc; ',
'  font-weight: bold;',
'}',
'',
'',
'.themaBeta {',
'    width: 50px;',
'    border: 1px solid black;',
'    margin-right: 5px;',
'}',
'',
'',
'.no-hover-hand {',
'    cursor: default !important;',
'}',
'',
'',
'/*',
'.gridcontainer {',
'    position: relative;',
'}',
'',
'',
'.gridcontainer > div {',
'    position: relative;',
'}',
'*/',
'',
'.gridcontainer div.separator {',
'    box-shadow: none;',
'    border-right: 3px solid #333;',
'}',
'',
'',
'',
'',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'div.highlight {',
'    background-color: yellow;',
'}',
'',
'.t-Region.is-maximized > .t-Region-bodyWrap > .t-Region-body {',
'    display: inline-block;',
'}',
'',
'.marginright {',
'    margin-right: 3px;',
'}',
'.marginleft {',
'    margin-left: 3px;',
'}',
'',
'.gridcontainer {',
'    display: grid;',
'    z-index: 2; ',
'    grid-gap: 1px;',
'    box-sizing: border-box;',
'    font-family: Audi Type;',
'    font-size: 12px;',
'}',
'.gridcontainer>div {box-shadow: 0 0 0 1px #808080; z-index: 2; padding: 2px}',
'.gridcontainer div.topleft {grid-column: 1/3; grid-row: 1/3}',
'',
'.gridcontainer div.land {grid-row: 1/2; grid-column: span 6; position: sticky; top: 0px; background-color: white; z-index: 3}',
'.gridcontainer div.subheader {position: sticky; top: 66px; background-color: white; grid-row: 2; z-index: 3}',
'',
'.gridcontainer div.themanum {grid-column: 1/2; position: sticky; left: 0px; background-color: white; z-index: 3}',
'.gridcontainer div.themaname {grid-column: 2/3; position: sticky; left: 40px; background-color: white; z-index: 3}',
'',
'.gridcontainer div.vorschrift { }',
'',
'.gridcontainer div.land {',
'    display: flex;',
'    justify-content: flex-end;',
'    align-items: center;',
'}',
'',
'',
'.gridcontainer div.bg,.gridcontainer div.bgv {',
'    z-index: 1 !important;',
'    opacity: 0.5;',
'',
'}',
'',
'.gridcontainer div.bg:nth-child(even), .gridcontainer div.themanum:nth-child(odd), .gridcontainer div.themaname:nth-child(even) {',
'    background-color: #D0D0D0;',
'}',
'.gridcontainer div.bg {',
'    box-shadow: none;',
'}',
'.gridcontainer div.bgv {',
'    box-shadow: 0 0 0 1px #808080;',
'}',
'',
'div.land div {',
'    border: none;',
'}',
'div.land div.landname {',
'    flex-grow: 1;',
'    text-align: center;',
'    font-weight: 700;',
'}',
'div.land div.landb img {',
'    width: 30px;',
'    margin: 5px;',
'}',
'div.land div.landr {',
'    width: 80px;',
'}',
'div.land div.laendergruppen {',
'    font-weight: normal;',
'    font-size: 10px;',
'}',
'',
'',
'',
'',
'.rr {',
'    border: 1px solid black;',
'    font-size: 0.8em;',
'    padding: 1px; margin-right: 3px;',
'}',
'.rr::before {',
'    content: "RR"',
'}',
'',
'.ventwurf {',
'    color:orange;',
'    display: inline-block;',
'    font-size: 14px;',
'}',
'.vnrelevant {',
'    color:red;',
'    display: inline-block;',
'    font-size: 14px;',
'}',
'.ventwurf::before, .vnrelevant::before {',
'    font-family: ''Font APEX Small'' !important;',
'    content: "\f071"',
'}',
'',
'',
'',
'',
'',
'',
'.context-menu-root {',
'    visibility: visible;',
'}',
'',
'.context-menu-icon-loading::before {',
'    content: "\f110";',
'}',
'',
'.context-menu-icon--fa {',
'    font-size: 14px !important;',
'}',
'',
'.context-menu-item.context-menu-visible > .context-menu-list {',
'    max-width: none !important;',
'    width: 300px !important;',
'}',
'',
'.context-menu-item.context-menu-hover.nohover {',
'    cursor: auto;',
'    background-color: inherit;',
'    color: black;',
'}',
'',
'.context-menu-icon.context-menu-icon--fa.context-menu-hover:before {',
'    color: #2980b9 !important;',
'    cursor: pointer !important;',
'}',
'',
'',
unistr('/* f\00FCr Icons an den Vorschriften */'),
'.vIcon {',
'    /*display: inline-block;*/',
'    width: 40px',
'}',
'',
'/* Vorschriften-Info Overlay */',
'div.vinfo {',
'    position: absolute; ',
'    z-index:3; ',
'    border: 1px solid;',
'}',
'div.div-table {',
'  display: table;         ',
'  width: auto;         ',
'  background-color: white;         ',
'  border: 1px solid #666666;         ',
'  /*border-spacing: 5px; /* cellspacing:poor IE support for  this */',
'}',
'div.table-row {',
'  display: table-row;',
'  width: auto;',
'  clear: both;',
'}',
'div.table-col {',
'  float: left; /* firefox */',
'  display: table-column;         ',
'  padding: 3px;',
'  margin: 2px;',
'}',
'div.table-col-th {',
'  background-color: #cccccc; ',
'  font-weight: bold;',
'}',
'',
'',
'.themaBeta {',
'    width: 50px;',
'    border: 1px solid black;',
'    margin-right: 5px;',
'}',
'',
'',
'.no-hover-hand {',
'    cursor: default !important;',
'}',
'',
'',
'',
'',
''))
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(264779541478585698)
,p_plug_name=>'Cockpit <span onclick="redirect(3)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody:t-Form--slimPadding'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  begin',
'if (:P202_QUERSCHNITT_THEMEN_CB is not null) then',
' ',
'  pck_ri_cockpit2.pInit(:P202_FILTER_BLAND, :P202_FILTER_THEMEN ||'':''|| :P202_QUERSCHNITT_THEMEN_CB, :P202_SUCHE_VORSCHRIFT,:P202_HIGHLIGHT_DATUM_AENDERUNG, null, :P202_FLAG_KF);',
'else',
'  pck_ri_cockpit2.pInit(:P202_FILTER_BLAND, :P202_FILTER_THEMEN ,:P202_SUCHE_VORSCHRIFT,:P202_HIGHLIGHT_DATUM_AENDERUNG, null, :P202_FLAG_KF);',
'',
'end if;',
'pck_ri_cockpit2.pDrawLaender;',
'pck_ri_cockpit2.pDrawThemen;',
'pck_ri_cockpit2.pDrawVorschriften;',
'pck_ri_cockpit2.pDrawSeparators;',
' htp.p(''</div>'');',
'end;',
''))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P202_FILTER_THEMEN is not null or :P202_FILTER_BLAND is not null'
,p_plug_display_when_cond2=>'SQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3492085051525054751)
,p_plug_name=>'Einstellungen &P202_FILTER_TITEL.'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3510971486616651855)
,p_plug_name=>'Info'
,p_parent_plug_id=>wwv_flow_imp.id(3492085051525054751)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('Bitte w\00E4hlen Sie ein oder mehrere L\00E4nder sowie ein oder mehrere Themengebiete und klicken Sie auf "Filtern", um zu beginnen!')
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P202_FILTER_THEMEN is null and :P202_FILTER_BLAND is null'
,p_plug_display_when_cond2=>'SQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3510971628210651856)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_imp.id(3492085051525054751)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(415737093062361859)
,p_plug_name=>'Highlightings'
,p_parent_plug_id=>wwv_flow_imp.id(3510971628210651856)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(395000232469270402)
,p_plug_name=>'Trennlinie'
,p_parent_plug_id=>wwv_flow_imp.id(3510971628210651856)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<hr>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1061147158919008328)
,p_plug_name=>unistr('Box Vorfilter L\00E4nder')
,p_parent_plug_id=>wwv_flow_imp.id(3510971628210651856)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>80
,p_plug_grid_column_span=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1061147191474008329)
,p_plug_name=>unistr('Box Filter L\00E4nder')
,p_parent_plug_id=>wwv_flow_imp.id(3510971628210651856)
,p_region_template_options=>'#DEFAULT#:margin-left-md'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1061147351067008330)
,p_plug_name=>'Box Vorfilter Themen'
,p_parent_plug_id=>wwv_flow_imp.id(3510971628210651856)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>110
,p_plug_grid_column_span=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1061147403775008331)
,p_plug_name=>'Box Filter Themen'
,p_parent_plug_id=>wwv_flow_imp.id(3510971628210651856)
,p_region_template_options=>'#DEFAULT#:margin-left-md'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>120
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1061147507081008332)
,p_plug_name=>'Trennlinie'
,p_parent_plug_id=>wwv_flow_imp.id(3510971628210651856)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>100
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<hr>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(869123617449346470)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1061147191474008329)
,p_button_name=>'B_KOMMENTARE_PRUEFEN'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('Kommentar bez. ausgew\00E4hlten L\00E4ndern pr\00FCfen')
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-info-square-o'
,p_button_cattributes=>'style="margin: 0px; padding: 0px; "'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(869130167152346475)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(3492085051525054751)
,p_button_name=>'FILTER'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Filtern'
,p_button_position=>'CHANGE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(869129767546346474)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(3492085051525054751)
,p_button_name=>'RESET'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Zur\00FCcksetzen')
,p_button_position=>'CHANGE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(869129345392346474)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3492085051525054751)
,p_button_name=>'BTN_MANAGE_PROFILE'
,p_button_static_id=>'BTN_MANAGE_PROFILE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Einstellungen laden/verwalten'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:210:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(869129035620346474)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3492085051525054751)
,p_button_name=>'BTN_SAVE_PROFILE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Einstellungen speichern'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1043566064135189818)
,p_name=>'P202_FLAG_KF'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(3492085051525054751)
,p_prompt=>'Flag konsolidierte Fassung vorhanden'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Wenn Benutzer VKO oder VEX ist, soll Schalter default auf einblenden',
'-- stehen, sonst auf ausblenden',
'if (pck_ri.fIsUserInRolle(listRolleId => ''1000:1002'') > 0) then',
'    return 1;',
'else',
'    return 0;',
'end if;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Normalansicht',
  'off_value', '0',
  'on_label', 'Detailansicht',
  'on_value', '1',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(966009753670351873)
,p_name=>'P202_URL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(1061147191474008329)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(875241040924362258)
,p_name=>'P202_QUERSCHNITT_THEMEN_CB'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(1061147403775008331)
,p_prompt=>'<b>Querschnittsthemengebiete</b>'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ',
'        ( v.bezeichnung || case when nvl(v.gueltig, 0) =0 then '' (in GETEX inaktiv)''  ',
'                                                          else '' '' end ',
'        )',
'        ELSE ( v.name_eng || case when nvl(v.gueltig, 0) =0 then '' (in GETEX inactive)''  ',
'                                                          else '' '' end ',
'        )',
'    END as  d,',
' tra.Themaid r ',
'  from T_thema_ref_et_b_AK tra ',
'  join V_THEMA_BAUM v on (v.themaid = tra.themaid)   ',
' where tra.et_b_AKid = 1036 -- querschnitt Themen',
' and  nvl(gueltig, 0) =1 ',
' order by v.thema_sortorder'))
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869128581988346473)
,p_name=>'P202_FILTER_PROFILE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3492085051525054751)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869128142882346473)
,p_name=>'P202_FILTER_TITEL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(3492085051525054751)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lReturn varchar2(2000) := '''';',
'    lAnzahl number;',
'    lLaender varchar2(2000) := :P202_FILTER_BLAND;',
'    lThemen varchar2(2000) := :P202_FILTER_THEMEN;',
'    lQuerschn_Themen varchar2(2000) := :P202_QUERSCHNIT_THEMEN_CB;',
'    lAnzahl_Que number;',
'    --debug(''laender:'' );',
'begin',
'    if (lLaender is not null or lThemen is not null or lQuerschn_Themen is not null) then',
'        lReturn := ''(Filter: '';',
'    end if;',
'    if (lLaender is not null) then',
'        select count(*) into lAnzahl from apex_string.split_numbers(lLaender,'':'');',
unistr('        lReturn := lReturn || lAnzahl || '' L\00E4nder'';'),
'    end if;',
'    if (lLaender is not null and lThemen is not null) then',
'        lReturn := lReturn || '', '';',
'    end if;',
'    if (lThemen is not null or lQuerschn_Themen is not null) then',
'        select count(*) into lAnzahl from apex_string.split_numbers(lThemen,'':'');',
'        select count(*) into lAnzahl_Que from apex_string.split_numbers(lQuerschn_Themen,'':'');',
'       lAnzahl := lAnzahl + lAnzahl_Que;',
'        lReturn := lReturn || lAnzahl || '' Themen'';',
'    end if;',
'',
'    if (lThemen is not null or lQuerschn_Themen is not null or lLaender is not null) then',
'        lReturn := lReturn || '')'';',
'    end if;',
'    ',
unistr('    --lReturn := ''(Filter: 5 L\00E4nder)'';'),
'    return lReturn;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869127780063346473)
,p_name=>'P202_MODAL_URL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(3492085051525054751)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869126741757346472)
,p_name=>'P202_TEXTFIELD'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(3510971628210651856)
,p_prompt=>'Textfield'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144103148820565)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869125770222346471)
,p_name=>'P202_SUCHE_VORSCHRIFT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(415737093062361859)
,p_prompt=>'Suche nach Vorschrift'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CASE WHEN p.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND v.DOKUMENTENDATUM IS NOT NULL',
'            THEN v.VORSCHRIFT_NUMMER || ''_'' || TO_CHAR(v.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'            ELSE v.VORSCHRIFT_NUMMER',
'       END as d,',
'       v.VORSCHRIFTID as r',
'FROM T_VORSCHRIFT v',
'LEFT JOIN T_PUBLISHER p ON v.PUBLISHERID = p.PUBLISHERID',
'WHERE v.vorschrift_freigabestatusid != 1 -- nicht mit status "Import" ',
'AND (:G_BENUTZERID in (select distinct benutzerid from t_benutzer_ref_rolle where rolleid in (1002, 1003, 1000)) -- ZVEX, VEX, Fachadm, VKO',
'  OR v.vorschrift_freigabestatusid not in (10, 30))',
'ORDER BY 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('- ausw\00E4hlen -')
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vorschrift_nummer, vorschriftid',
'  from t_vorschrift ',
'  ',
' where vorschrift_freigabestatusid != 1 -- nicht mit status  "Import" ',
' and (:G_BENUTZERID in (select distinct benutzerid from t_benutzer_ref_rolle where  rolleid  in ( 1002, 1003, 1000) ) -- ZVEX, VEX, Fachadm, VKO',
'  or vorschrift_freigabestatusid not in (10, 30)',
' )',
'order by 1'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869125368400346471)
,p_name=>'P202_HIGHLIGHT_DATUM_AENDERUNG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(415737093062361859)
,p_prompt=>unistr('Hervorhebung von \00C4nderungen der letzten x Monate')
,p_post_element_text=>'<span class="t-Form-inlineHelp">&nbsp;&nbsp;0 = deaktiviert</span>'
,p_source=>'0'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>2
,p_cMaxlength=>2
,p_tag_attributes=>'style="width: 50px; text-align: right"'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>4
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869124649850346471)
,p_name=>'P202_FILTER_LAENDERGRUPPE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1061147158919008328)
,p_prompt=>unistr('Vorfilter L\00E4ndergruppe')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select laendergruppe, laendergruppeid',
'from t_laendergruppe where laendergruppeid != 1220',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- alle -'
,p_cHeight=>5
,p_grid_label_column_span=>4
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869124271408346470)
,p_name=>'P202_FILTER_BLAND_PRE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1061147158919008328)
,p_prompt=>unistr('Vorfilter L\00E4nder')
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" onclick="loadLaenderShuttle()"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>4
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869123218019346470)
,p_name=>'P202_FILTER_BLAND'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1061147191474008329)
,p_prompt=>unistr('L\00E4nder')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT b_nummer || '' - '' || ',
'       CASE ',
'           WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'           ELSE land_eng ',
'       END AS d, ',
'      landid ',
'FROM t_land l ',
'WHERE (:P202_FILTER_LAENDERGRUPPE IS NULL OR landid IN (SELECT landid FROM t_land_ref_laendergruppe WHERE laendergruppeid = :P202_FILTER_LAENDERGRUPPE)) ',
'  AND status_datenstand <> 0 ',
'ORDER BY nlssort(b_nummer, ''NLS_SORT=BINARY_AI'');',
''))
,p_cHeight=>5
,p_tag_css_classes=>'margin-bottom-none padding-bottom-none'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_css_classes=>'margin-bottom-none padding-bottom-none'
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869122738576346469)
,p_name=>'P202_BESONDERHEITEN_MAERKTE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1061147191474008329)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869122337488346469)
,p_name=>'P202_URL_KOMMENTARE_PRUEFEN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1061147191474008329)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869121672084346469)
,p_name=>'P202_FILTER_THEMEN_PRE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1061147351067008330)
,p_prompt=>'Vorfilter Themengebiete'
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" onclick="loadThemenShuttle()"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>4
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869121287939346469)
,p_name=>'P202_FILTER_THEMEN_PRE_AK'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1061147351067008330)
,p_item_default=>'-1'
,p_prompt=>'Vorfilter Arbeitskreise'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select kurz||'' ''|| CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END as d, et_b_akid as r',
'from t_et_b_ak',
'where et_b_akid not in( 1200,1036)  --.. , querschnittsthem',
'and et_b_akid in (select et_b_akid from t_thema_ref_et_b_ak)',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- alle -'
,p_lov_null_value=>'-1'
,p_cHeight=>5
,p_grid_label_column_span=>4
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(869120537432346468)
,p_name=>'P202_FILTER_THEMEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1061147403775008331)
,p_prompt=>'Themengebiete'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    nummer || '' - '' || ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END as description,',
'    themaid as r ',
'FROM v_thema_baum',
'where  nvl(gueltig, 0) =1 ',
'and themaid not in  (select themaid  from t_thema_ref_et_b_ak where et_b_akid =1036)',
'order by thema_sortorder',
''))
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(763371580202749499)
,p_name=>'P202_THEMEN_CHILDREN_TO_ADD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3492085051525054751)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(554262635995028783)
,p_name=>'P202_INCLUDE_INACT_BESTAND'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1061147158919008328)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(554262484100028782)
,p_name=>'P202_LAENDER_MIT_INAKTIV_BESTAND'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1061147158919008328)
,p_prompt=>unistr('Zeige L\00E4nder mit inaktivem Datenbestand')
,p_display_as=>'NATIVE_YES_NO'
,p_grid_label_column_span=>8
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Nein',
  'off_value', '0',
  'on_label', 'Ja',
  'on_value', '1',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(132810379365615787)
,p_name=>'P202_REGELSEITE_SICHTBAR'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(3492085051525054751)
,p_use_cache_before_default=>'NO'
,p_source=>'case when (pck_ri.fIsUserInRolle(listRolleId => ''1003:1000'') > 0) then 1 else 0 end'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(869115529295346465)
,p_name=>unistr('change L\00E4ndergruppenfilter ')
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P202_FILTER_LAENDERGRUPPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869115012139346465)
,p_event_id=>wwv_flow_imp.id(869115529295346465)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(869114618121346464)
,p_name=>unistr('enter im l\00E4ndervorfilter')
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P202_FILTER_BLAND_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869114097519346464)
,p_event_id=>wwv_flow_imp.id(869114618121346464)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(869113686378346464)
,p_name=>'enter im themensuchfeld'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P202_FILTER_THEMEN_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869113147235346464)
,p_event_id=>wwv_flow_imp.id(869113686378346464)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadThemenShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(869112818887346464)
,p_name=>unistr('arbeitskreisefilter ge\00E4ndert')
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P202_FILTER_THEMEN_PRE_AK'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869112257278346464)
,p_event_id=>wwv_flow_imp.id(869112818887346464)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadThemenShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(869111924185346463)
,p_name=>'Suche nach Vorschrift'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P202_SUCHE_VORSCHRIFT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869111349442346463)
,p_event_id=>wwv_flow_imp.id(869111924185346463)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(landid,'':'') within group (order by landid) into :P202_FILTER_BLAND',
'from t_cockpit_daten cd',
'join table(apex_string.split_numbers(:P202_SUCHE_VORSCHRIFT,'':'')) x on (x.column_value = cd.vorschriftid);',
'',
'select listagg(themaid,'':'') within group (order by themaid) into :P202_FILTER_THEMEN',
'from t_cockpit_daten cd',
'join table(apex_string.split_numbers(:P202_SUCHE_VORSCHRIFT,'':'')) x on (x.column_value = cd.vorschriftid);',
'',
'select listagg(distinct themaid,'':'') within group (order by themaid) into :P202_QUERSCHNITT_THEMEN_CB',
'   from t_cockpit_daten cd           --',
' join table(apex_string.split_numbers(:P202_SUCHE_VORSCHRIFT,'':'')) x on (x.column_value = cd.vorschriftid)',
'  where themaid in (select themaid from T_thema_ref_et_b_AK  where et_b_AKid =1036) ;'))
,p_attribute_02=>'P202_SUCHE_VORSCHRIFT'
,p_attribute_03=>'P202_FILTER_BLAND,P202_FILTER_THEMEN,P202_QUERSCHNITT_THEMEN_CB'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(869111034320346462)
,p_name=>'Button Save Profile clicked'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(869129035620346474)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(130350993756775267)
,p_event_id=>wwv_flow_imp.id(869111034320346462)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var obj = new Object();',
'obj.laender = $v(''P202_FILTER_BLAND'');',
'if (typeof $v(''P202_QUERSCHNITT_THEMEN_CB'') === "string" && $v(''P202_QUERSCHNITT_THEMEN_CB'').trim().length != 0 ) {  ',
'    obj.themen = $v(''P202_QUERSCHNITT_THEMEN_CB'');',
'    if(typeof $v(''P202_FILTER_THEMEN'') === "string" && $v(''P202_FILTER_THEMEN'').trim().length !=0){',
'        obj.themen = $v(''P202_QUERSCHNITT_THEMEN_CB'').concat('':'', $v(''P202_FILTER_THEMEN''));',
'    }',
'}',
'else  {   ',
'      obj.themen = $v(''P202_FILTER_THEMEN'');',
'}',
' ',
'obj.highlight_datum = $v(''P202_HIGHLIGHT_DATUM_AENDERUNG'');',
'',
'$s(''P202_FILTER_PROFILE'', JSON.stringify(obj));',
'',
'apex.server.process(''DUMMY_PROCESS'', {',
'    pageItems: ''#P202_FILTER_PROFILE''',
'}, {',
'    dataType: "text"',
'});'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869110505118346462)
,p_event_id=>wwv_flow_imp.id(869111034320346462)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--debug(''P202_FILTER_PROFILE='' ||:P202_FILTER_PROFILE);',
':P202_MODAL_URL := APEX_PAGE.get_url(',
'    p_page => 215,',
'    p_clear_cache => 215,',
'    p_items => ''P215_DATEN,P215_BENUTZERID'',',
'    p_values => ''\'' || :P202_FILTER_PROFILE || ''\,'' || :G_BENUTZERID',
');'))
,p_attribute_02=>'P202_FILTER_PROFILE,G_BENUTZERID'
,p_attribute_03=>'P202_MODAL_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869109955995346462)
,p_event_id=>wwv_flow_imp.id(869111034320346462)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.navigation.redirect($v(''P202_MODAL_URL''));',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(869109624512346462)
,p_name=>'QS Themen Filter Changed'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P202_QUERSCHNITT_THEMEN_CB_OLD'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(869109112796346461)
,p_event_id=>wwv_flow_imp.id(869109624512346462)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P202_FILTER_PROFILE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var obj = new Object();',
'obj.laender = $v(''P202_FILTER_BLAND'');',
'if (typeof $v(''P202_QUERSCHNITT_THEMEN_CB'') === "string" && $v(''P202_QUERSCHNITT_THEMEN_CB'').trim().length != 0 ) {  ',
'    obj.themen = $v(''P202_QUERSCHNITT_THEMEN_CB'');',
'    if(typeof $v(''P202_FILTER_THEMEN'') === "string" && $v(''P202_FILTER_THEMEN'').trim().length !=0){',
'        obj.themen = $v(''P202_QUERSCHNITT_THEMEN_CB'').concat('':'', $v(''P202_FILTER_THEMEN''));',
'    }',
'}',
'else  {   ',
'      obj.themen = $v(''P202_FILTER_THEMEN'');',
'}',
' ',
'obj.highlight_datum = $v(''P202_HIGHLIGHT_DATUM_AENDERUNG'');',
'',
'$s(''P202_FILTER_PROFILE'', JSON.stringify(obj));',
'',
'apex.server.process(''DUMMY_PROCESS'', {',
'    pageItems: ''#P202_FILTER_PROFILE''',
'}, {',
'    dataType: "text"',
'});',
'                   ',
'                   '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(763371860084749502)
,p_name=>'add childThemen'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P202_FILTER_THEMEN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(763371767026749501)
,p_event_id=>wwv_flow_imp.id(763371860084749502)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lThemenliste apex_t_number := apex_string.split_numbers(:P202_FILTER_THEMEN,'':'');',
'    l_lst_allQSThemen varchar2(2000);',
'    l_inQuerschnittsthemen apex_t_number ;',
'',
'begin    ',
'',
'    apex_json.initialize_clob_output;',
'    apex_json.open_array; ',
'    ',
'    select listagg(themaid, '':'') into l_lst_allQSThemen from t_thema_ref_et_b_ak where et_b_akid = 1036;',
'    l_inQuerschnittsthemen  := apex_string.split_numbers(l_lst_allQSThemen,'':'');',
unistr('    -- Jedes bereits ausgew\00E4hlte Thema durchgehen und dessen Kinder selektieren'),
'    for i in 1 .. lThemenliste.count loop',
'          for childthemen in (',
'            select themaid, nummer || '' - '' || bezeichnung as d',
'            from t_thema',
'             where gueltig =1',
'            connect by parentid = prior themaid',
'            start with parentid = lThemenliste(i)',
'        ) loop',
'            -- Wenn das entsprechende Kind noch nicht im Shuttle ist, dann ',
unistr('            -- zu einer Hinzuf\00FCgungs-Liste addieren'),
'            if (childthemen.themaid not member of lThemenliste ',
'             and  childthemen.themaid  not member of l_inQuerschnittsthemen) then',
'                apex_json.open_object;',
'                apex_json.write(''id'',childthemen.themaid);',
'                apex_json.write(''display'',childthemen.d);',
'                apex_json.close_object;',
'            end if;',
'        end loop;',
'    ',
'    end loop;',
unistr('    -- Hinzuf\00FCgungs-Liste ist hidden item'),
unistr('    -- Direktes Hinzuf\00FCgen w\00FCrde zu einem Refresh der Scrollbalken des Items f\00FChren'),
'    apex_json.close_array;',
'    :P202_THEMEN_CHILDREN_TO_ADD := apex_json.get_clob_output;',
'    apex_json.free_output;',
'end;    '))
,p_attribute_02=>'P202_FILTER_THEMEN'
,p_attribute_03=>'P202_THEMEN_CHILDREN_TO_ADD,P202_FILTER_PROFILE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(763371492019749498)
,p_event_id=>wwv_flow_imp.id(763371860084749502)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var items = JSON.parse($v(''P202_THEMEN_CHILDREN_TO_ADD''));',
'',
unistr('// alle Items im Shuttle hinzuf\00FCgen'),
'for (item of items) {',
'    if (item) addItemToShuttle(''P202_FILTER_THEMEN'',item.id,item.display);',
'} ',
'',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(554262310697028780)
,p_name=>'Zeige Land Switch'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P202_LAENDER_MIT_INAKTIV_BESTAND'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexbeforerefresh'
,p_display_when_type=>'NOT_EXISTS'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from t_benutzer_ref_rolle where benutzerid=:G_BENUTZERID and ',
'rolleid  in (1003, 1000)'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554262203737028779)
,p_event_id=>wwv_flow_imp.id(554262310697028780)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P202_LAENDER_MIT_INAKTIV_BESTAND'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(554261816124028775)
,p_name=>'Change'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P202_LAENDER_MIT_INAKTIV_BESTAND'
,p_condition_element=>'P202_LAENDER_MIT_INAKTIV_BESTAND'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554261656930028774)
,p_event_id=>wwv_flow_imp.id(554261816124028775)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P202_INCLUDE_INACT_BESTAND'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554261591334028773)
,p_event_id=>wwv_flow_imp.id(554261816124028775)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P202_INCLUDE_INACT_BESTAND'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554261466665028772)
,p_event_id=>wwv_flow_imp.id(554261816124028775)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P202_FILTER_BLAND'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554261412468028771)
,p_event_id=>wwv_flow_imp.id(554261816124028775)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(966009947199351875)
,p_name=>'open_modal'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(869123617449346470)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(966009922048351874)
,p_event_id=>wwv_flow_imp.id(966009947199351875)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.navigation.redirect($v(''P202_URL''));',
'//window.location=$("#P202_URL").val();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(966009640208351872)
,p_name=>'FILTER_LAND_CHANGED_BESNDERHEITEN'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P202_FILTER_BLAND'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(966009634665351871)
,p_event_id=>wwv_flow_imp.id(966009640208351872)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(landid, '':'') into :P202_BESONDERHEITEN_MAERKTE',
'from t_land',
'where landid in (select column_value from table(apex_string.split_numbers(:P202_FILTER_BLAND, '':'')))',
'and besonderheiten is not null;',
'--APEX_UTIL.SET_SESSION_STATE(''P325_BESONDERHEITEN'', ''SOME VALUE'');'))
,p_attribute_02=>'P202_FILTER_BLAND'
,p_attribute_03=>'P202_BESONDERHEITEN_MAERKTE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(966009496907351870)
,p_name=>'LAENDER_MIT_BESONDERHEIT_CHANGED'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P202_BESONDERHEITEN_MAERKTE'
,p_condition_element=>'P202_BESONDERHEITEN_MAERKTE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(966009337488351869)
,p_event_id=>wwv_flow_imp.id(966009496907351870)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(869123617449346470)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(966009166608351867)
,p_event_id=>wwv_flow_imp.id(966009496907351870)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(869123617449346470)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(966009317199351868)
,p_event_id=>wwv_flow_imp.id(966009496907351870)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apeX_page.get_url (',
'    p_page => 136,',
'    p_items => ''P136_LAENDER'',',
'    p_values => ''\'' || :P202_BESONDERHEITEN_MAERKTE || ''\'',',
'    p_clear_cache => 136',
') into :P202_URL FROM DUAL;'))
,p_attribute_02=>'P202_BESONDERHEITEN_MAERKTE'
,p_attribute_03=>'P202_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(875240941750362257)
,p_name=>'QS_THem_Filt_Change'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P202_QUERSCHNITT_THEMEN_CB'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(875240858771362256)
,p_event_id=>wwv_flow_imp.id(875240941750362257)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var obj = new Object();',
'obj.laender = $v(''P202_FILTER_BLAND'');',
'if (typeof $v(''P202_QUERSCHNITT_THEMEN_CB'') === "string" && $v(''P202_QUERSCHNITT_THEMEN_CB'').trim().length != 0 ) {  ',
'    obj.themen = $v(''P202_QUERSCHNITT_THEMEN_CB'');',
'    if(typeof $v(''P202_FILTER_THEMEN'') === "string" && $v(''P202_FILTER_THEMEN'').trim().length !=0){',
'        obj.themen = $v(''P202_QUERSCHNITT_THEMEN_CB'').concat('':'', $v(''P202_FILTER_THEMEN''));',
'    }',
'}',
'else  {   ',
'      obj.themen = $v(''P202_FILTER_THEMEN'');',
'}',
' ',
'obj.highlight_datum = $v(''P202_HIGHLIGHT_DATUM_AENDERUNG'');',
'',
'$s(''P202_FILTER_PROFILE'', JSON.stringify(obj));',
'',
'apex.server.process(''DUMMY_PROCESS'', {',
'    pageItems: ''#P202_FILTER_PROFILE''',
'}, {',
'    dataType: "text"',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1043565917287189817)
,p_name=>'Switch Filter'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P202_FLAG_KF'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1043565834051189816)
,p_event_id=>wwv_flow_imp.id(1043565917287189817)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'  apex.submit(''REFRESH'');'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(869116683125346465)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Reset'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(869129767546346474)
,p_internal_uid=>2803095632774041770
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41968893199100233)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Startprofil laden falls vorhanden'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_themenids varchar2(2000);',
'  l_startprofil number :=0;',
'begin',
'    select count(*) into  l_startprofil from t_cockpit_profile',
'    where startprofile = 1 and benutzerid = :G_BENUTZERID;',
'    if (l_startprofil > 0 ) then',
'        select',
'           JSON_VALUE(DATEN, ''$.laender''), JSON_VALUE(DATEN, ''$.themen''), JSON_VALUE(DATEN, ''$.highlight_datum'')',
'                into :P202_FILTER_BLAND,      l_themenids,              :P202_HIGHLIGHT_DATUM_AENDERUNG',
'        from t_cockpit_profile',
'       where startprofile = 1 and benutzerid = :G_BENUTZERID;',
'      -- debug(''p202 init, l_themenids=''|| l_themenids);',
'    --  get querschnittsthemen',
'        select listagg( x1.column_value, '':'') within group (order by x1.column_value) into :P202_QUERSCHNITT_THEMEN_CB',
'          from table (apex_string.split_numbers(l_themenids, '':'')) x1',
'          where x1.column_value in (select themaid from t_thema_ref_et_b_ak where et_b_akid =1036 );',
'        --',
'          select listagg( x2.column_value, '':'') within group (order by x2.column_value) into :P202_FILTER_THEMEN',
'          from table (apex_string.split_numbers(l_themenids, '':'')) x2 ',
'          where x2.column_value not in (select themaid from t_thema_ref_et_b_ak where et_b_akid =1036 );',
'     end if;',
'exception',
'    when no_data_found then',
'        -- Kein Startprofil gespeichert --> nichts passiert',
'        null;',
'        ',
'end;        '))
,p_process_clob_language=>'PLSQL'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P202_FILTER_BLAND is null and :P202_FILTER_THEMEN is null and ',
':P202_QUERSCHNITT_THEMEN_CB is null )'))
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>3714181209098488468
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(869116306520346465)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLinks'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lID number;',
'    lLinkDMS varchar2(250);',
'    lLinkGetex varchar2(250);',
'    lLinkGetex2 varchar2(250);',
'    lLinkWebsite varchar2(250);',
'    lNameWebsite varchar2(250);',
'BEGIN',
' ',
'    lID := apex_application.g_x01;',
'    ',
'    select link_zur_vorschrift_dms, link_zur_vorschrift_getex, url_getex_vorschrift into lLinkDMS, lLinkGetex, lLinkGetex2',
'    from t_vorschrift',
'    where vorschriftid = lID;',
'    ',
'    select v.websitelink, w.website_name into lLinkWebsite, lNameWebsite',
'    from t_vorschrift v',
'    left outer join t_website w on (v.websiteid = w.websiteid)',
'    where v.vorschriftid = lID;',
'    ',
'    apex_json.open_object;',
'    if (lLinkGetex2 is not null )--and pck_ri.fIsUserInRolle(:G_BENUTZERID,''1003:1100'') > 0) ',
'    then',
'        apex_json.open_object(''linkgetex2'');',
'        apex_json.write(''name'',''<b>GETEX2</b>'');',
'        apex_json.write(''isHtmlName'',true);',
'        apex_json.write(''url'',lLinkGetex2);',
'        apex_json.close_object;',
'    end if;',
'    if (lLinkDMS is not null) then',
'        apex_json.open_object(''linkdms'');',
'        apex_json.write(''name'',''DMS'');',
'        apex_json.write(''url'',lLinkDMS);',
'        apex_json.close_object;',
'    end if;',
'    if (lLinkDMS is null and lLinkGETEX is null and lLinkWebsite is null and lLinkGetex2 is null) then',
'        apex_json.open_object(''nolinks'');',
'        apex_json.write(''name'',''Keine externen Links definiert'');',
'        apex_json.write(''className'',''nohover'');',
'        apex_json.close_object;',
'    end if;',
'    apex_json.close_all;',
'    ',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2803096009379041770
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(869118326949346466)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadDates'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lID number;',
'    lMode number;',
'    lLinkDMS varchar2(250);',
'    lLinkGetex varchar2(250);',
'    lLinkWebsite varchar2(250);',
'    lNameWebsite varchar2(250);',
'BEGIN',
' ',
'    lID := apex_application.g_x01;',
'    lMode := apex_application.g_x02;',
'    ',
'    apex_json.open_object;',
'    ',
'    if (lMode = 1) then',
'        for d in (',
'            select et.einsatzdatum_typid, et.einsatzdatum_typ, to_char(vret.einsatzdatum,''dd.mm.yyyy'') datum',
'            from t_vorschrift_ref_einsatzdatum_typ vret',
'            join t_einsatzdatum_typ et on (vret.einsatzdatum_typid = et.einsatzdatum_typid)',
'            where vret.vorschriftid = lID and vret.einsatzdatum is not null',
'        )',
'        loop',
'            apex_json.open_object(d.einsatzdatum_typid);',
'            apex_json.write(''name'',''<b>'' || d.einsatzdatum_typ || '':</b> '' || d.datum);',
'            apex_json.write(''isHtmlName'', true);',
'            apex_json.close_object;   ',
'        end loop;',
'    elsif (lMode = 2) then',
'        for d in (    ',
'            select to_char(datum_alle_typen,''dd.mm.yyyy'') as datum, 1011 as typid, ''Einsatzdatum Alle Fahrzeuge'' as einsatzdatum_typ ',
'            from t_vorschrift_ref_vorschrift',
'            where vorschrift_ref_vorschriftid = lID and datum_alle_typen is not null',
'            union',
'            select to_char(datum_neue_typen,''dd.mm.yyyy'') as datum, 1010 as typid, ''Einsatzdatum Neue Typen'' as einsatzdatum_typ',
'            from t_vorschrift_ref_vorschrift',
'            where vorschrift_ref_vorschriftid = lID and datum_neue_typen is not null       ',
'        ) loop',
'            apex_json.open_object(d.typid);',
'            apex_json.write(''name'',''<b>'' || d.einsatzdatum_typ || '':</b> '' || d.datum);',
'            apex_json.write(''isHtmlName'', true);',
'            apex_json.close_object;           ',
'        end loop;',
'    ',
'    end if;',
'    ',
'        ',
'    apex_json.close_all;',
'    ',
'',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2803093988950041769
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(669647272045337960)
,p_process_sequence=>30
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadMfVLinks'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lID NUMBER;',
'    lURL VARCHAR2(4000);',
'    information_count NUMBER := 0;',
'    interpretation_count NUMBER := 0;',
'    information_teil NUMBER := 0;',
'    interpretation_teil NUMBER := 0;',
'    display_string VARCHAR2(4000);',
'',
'BEGIN',
'    lID := apex_application.g_x01;',
'    ',
'    apex_json.open_object;',
'    ',
'    FOR d IN (',
'        SELECT COUNT(DISTINCT tmrv.MFVID) cnt, ',
'        tmt.teil,',
'        tmt.BEZEICHNUNG,',
'        tmt.MFV_TEILID',
'        FROM t_mfv_ref_vorschrift tmrv ',
'        JOIN t_mfv_ref_mfv_teil tmrm ON (tmrv.MFVID = tmrm.MFVID)',
'        JOIN t_mfv_teil tmt ON (tmt.MFV_TEILID = tmrm.MFV_TEILID)',
'        JOIN T_MFV m ON (m.MFVID = tmrv.MFVID)  -- added join with T_MFV',
'        WHERE tmrv.VORSCHRIFTID = lID',
'        AND tmt.MFV_TEILID IN (1000, 1001)',
'        AND (m.JIRA_Status != 20 OR m.JIRA_Status IS NULL)  -- condition to exclude ''ohne MfV beendet''',
'        GROUP BY tmt.teil, tmt.BEZEICHNUNG, tmt.MFV_TEILID',
'    ) LOOP',
'        IF d.MFV_TEILID = 1000 THEN',
'            information_count := d.cnt;',
'            information_teil := d.teil;',
'        ELSIF d.MFV_TEILID = 1001 THEN',
'            interpretation_count := d.cnt;',
'            interpretation_teil := d.teil;',
'        END IF;',
'    END LOOP;',
'',
'    IF interpretation_count = 0 AND information_count = 0 THEN',
'        apex_json.write(''message'', ''Keine MfVs zugeordnet.'');',
'    ELSE',
'        display_string := ''<span style="white-space: normal;">'';',
'        ',
'        IF information_count > 0 THEN',
'            display_string := display_string || information_teil || ''. <b>Information:</b> '' || information_count;',
'        END IF;',
'        ',
'        IF interpretation_count > 0 THEN',
'            IF information_count > 0 THEN',
'                display_string := display_string || ''<br>'';',
'            END IF;',
'            display_string := display_string || interpretation_teil || ''. <b>Interpretation:</b> '' || interpretation_count;',
'        END IF;',
'        ',
'        display_string := display_string || ''</span>'';',
'        ',
'        apex_json.open_object(''counts'');',
'        apex_json.write(''name'', display_string);',
'        apex_json.write(''isHtmlName'', TRUE);',
'        apex_json.close_object;',
'    END IF;',
'    ',
'    lURL := apex_page.get_url(p_page => 25, p_items => ''P25_VORSCHRIFTID'', p_values => lID, p_clear_cache => 25) || ''#rMfVs'';',
'    apex_json.write(''url'', lURL);',
'    apex_json.close_all;',
'    ',
'    apex_debug.message(''Generated URL: '' || lURL);',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>3002565043854050275
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3199263761752104130)
,p_process_sequence=>40
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadMfVLinks_Backup'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lID NUMBER;',
'    lURL VARCHAR2(4000);',
'    information_count NUMBER := 0;',
'    interpretation_count NUMBER := 0;',
'    information_teil NUMBER := 0;',
'    interpretation_teil NUMBER := 0;',
'    display_string VARCHAR2(4000);',
'',
'BEGIN',
'    lID := apex_application.g_x01;',
'    ',
'    apex_json.open_object;',
'    ',
'    FOR d IN (',
'        SELECT COUNT(tmrv.MFVID) cnt, ',
'        tmt.teil,',
'        tmt.BEZEICHNUNG,',
'        tmt.MFV_TEILID',
'        FROM t_mfv_ref_vorschrift tmrv ',
'        JOIN t_mfv_ref_mfv_teil tmrm ON (tmrv.MFVID = tmrm.MFVID)',
'        JOIN t_mfv_teil tmt ON (tmt.MFV_TEILID = tmrm.MFV_TEILID)',
'        JOIN T_MFV m ON (m.MFVID = tmrv.MFVID)  -- added join with T_MFV',
'        WHERE tmrv.VORSCHRIFTID = lID',
'        AND tmt.MFV_TEILID IN (1000, 1001)',
'        AND (m.JIRA_Status != 20 OR m.JIRA_Status IS NULL)  -- condition to exclude ''ohne MfV beendet''',
'        GROUP BY tmt.teil, tmt.BEZEICHNUNG, tmt.MFV_TEILID',
'    ) LOOP',
'        IF d.MFV_TEILID = 1000 THEN',
'            information_count := d.cnt;',
'            information_teil := d.teil;',
'        ELSIF d.MFV_TEILID = 1001 THEN',
'            interpretation_count := d.cnt;',
'            interpretation_teil := d.teil;',
'        END IF;',
'    END LOOP;',
'',
'    IF interpretation_count = 0 AND information_count = 0 THEN',
'        apex_json.write(''message'', ''Keine MfVs zugeordnet.'');',
'    ELSE',
'        display_string := ''<span style="white-space: normal;">'';',
'        ',
'        IF information_count > 0 THEN',
'            display_string := display_string || information_teil || ''. <b>Information:</b> '' || information_count;',
'        END IF;',
'        ',
'        IF interpretation_count > 0 THEN',
'            IF information_count > 0 THEN',
'                display_string := display_string || ''<br>'';',
'            END IF;',
'            display_string := display_string || interpretation_teil || ''. <b>Interpretation:</b> '' || interpretation_count;',
'        END IF;',
'        ',
'        display_string := display_string || ''</span>'';',
'        ',
'        apex_json.open_object(''counts'');',
'        apex_json.write(''name'', display_string);',
'        apex_json.write(''isHtmlName'', TRUE);',
'        apex_json.close_object;',
'    END IF;',
'    ',
'    lURL := apex_page.get_url(p_page => 25, p_items => ''P25_VORSCHRIFTID'', p_values => lID, p_clear_cache => 25) || ''#rMfVs'';',
'    apex_json.write(''url'', lURL);',
'    apex_json.close_all;',
'    ',
'    apex_debug.message(''Generated URL: '' || lURL);',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>472948554147284105
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(869115878696346465)
,p_process_sequence=>50
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLinkRegel'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lLandID number;',
'    lThemaID number;',
'    lURL varchar2(4000);',
'BEGIN',
'    lLandID := apex_application.g_x01;',
'    lThemaID := apex_application.g_x02;',
'',
'    lURL := apex_page.get_url(p_page => 203, p_items => ''P203_LAND,P203_THEMA'', p_values => lLandID || '','' || lThemaID);',
'    ',
'    htp.p (lURL);',
'    apex_debug.message(''Generated URL: '' || lURL);',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2803096437203041770
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(869119873363346467)
,p_process_sequence=>60
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLinkVorschrift'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lID number;',
'    lRowid rowid;',
'BEGIN',
' ',
'    lID := apex_application.g_x01;',
'',
'    htp.p (apex_page.get_url(p_page => 25, p_items => ''P25_VORSCHRIFTID'', p_values => lID, p_clear_cache => 25));',
'end;    '))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2803092442536041768
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(869119520996346467)
,p_process_sequence=>70
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLinkTree'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lID number;',
'    lRowid rowid;',
'BEGIN',
' ',
'    lID := apex_application.g_x01;',
'    ',
'    htp.p (apex_page.get_url(p_page => 300, p_items => ''P300_VORSCHRIFTID'', p_values => lID));',
'end;    '))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2803092794903041768
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(869119085640346467)
,p_process_sequence=>80
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLaenderShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lLaendergruppe varchar2(2000) := apex_application.g_x02;',
'    lTextfilter varchar2(2000) := apex_application.g_x03;',
'    include_Land_inaktDaten number := apex_application.g_x04; -- visible with switsch (ON) for VKO & FachAdm',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    for l in (',
'        select b_nummer || '' - '' || CASE ',
'    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'    ELSE land_eng',
'END as d, landid',
'        from t_land',
'        where landid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))        ',
'        and (',
'            lLaendergruppe is null',
'            or landid in (',
'                select landid from t_land_ref_laendergruppe where laendergruppeid in (',
'                    select column_value from table(apex_string.split_numbers(lLaendergruppe,'':''))',
'                )',
'            )',
'        )',
'        and (',
'            lTextfilter is null',
'            or instr(upper(b_nummer),upper(lTextFilter)) != 0',
'            or instr(upper(land),upper(lTextFilter)) != 0',
'        )',
'        and (status_datenstand <> 0 and include_Land_inaktDaten=0 OR include_Land_inaktDaten=1 )',
'        order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'')        ',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.landid);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'    ',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2803093230259041768
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(869118699906346466)
,p_process_sequence=>90
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadThemenShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lText varchar2(2000) := apex_application.g_x02;',
'    lArbeitskreise varchar2(2000) := apex_application.g_x03;',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    for l in (',
'        select nummer || '' - '' || bezeichnung as d, themaid as r',
'        from v_thema_baum',
'        where upper(nummer || '' - '' || bezeichnung) like ''%'' || upper(lText) || ''%''',
'        and themaid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))   ',
'        and  THEMAID not in ( select themaid from t_thema_ref_et_b_ak where et_b_akid = 1036 )   -- querschnittsthemen',
'        and',
'        (',
'            lArbeitskreise = ''-1'' or themaid  in (Select themaid from t_thema_ref_et_b_ak tre where et_b_akid in (',
'                select column_value from table(apex_string.split(lArbeitskreise,'':'')))',
'            )',
'        )',
'        and nvl(gueltig, 0)=1',
'        order by thema_sortorder     ',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.r);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'    ',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2803093615993041769
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(869117904214346466)
,p_process_sequence=>100
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadThemaDaten'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lID number;',
'BEGIN',
' ',
'    lID := apex_application.g_x01;',
'    ',
'    apex_json.open_object;',
'    ',
'    for lThema in (',
'        select antriebsart_vorschrift',
'        from t_thema',
'        where themaid = lID',
'    ) ',
'    loop',
'        if (lThema.antriebsart_vorschrift is not null) then',
'            apex_json.open_object(''antriebsart'');',
'            apex_json.write(''name'',''<b>Antriebsart: </b>'' || lThema.antriebsart_vorschrift);',
'            apex_json.write(''isHtmlName'',''true'');',
'            apex_json.write(''className'',''nohover'');',
'            apex_json.close_object;        ',
'        end if;',
'            ',
'    end loop;',
'            ',
'            ',
'    apex_json.close_all;',
'',
'',
'    ',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2803094411685041769
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(869117481390346466)
,p_process_sequence=>110
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLinkThema'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lID number;',
'    lRowid rowid;',
'BEGIN',
' ',
'    lID := apex_application.g_x01;',
'    ',
'    select rowid into lRowid',
'    from t_thema',
'    where themaid = lID;',
'    ',
'    htp.p (apex_page.get_url(p_page => 35, p_items => ''P35_ROWID'', p_values => lRowid));',
'end;    '))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2803094834509041769
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(869117113400346466)
,p_process_sequence=>120
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadBemerkungenOLD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lThemaID number := apex_application.g_x01;',
'    lLandID number := apex_application.g_x02;',
'    lVorschriftID number := apex_application.g_x03;',
'    ',
'    lVTLDaten t_vorschrift_ref_thema_ref_land%rowtype;',
'BEGIN',
'',
'    apex_json.open_object;    ',
'',
'    select * into lVTLDaten',
'    from t_vorschrift_ref_thema_ref_land vtl',
'    where vtl.vorschriftid = lVorschriftID',
'    and vtl.themaid = lThemaID',
'    and vtl.landid = lLandid',
'    and geloescht = 0',
'    and bemerkung is not null;',
'',
'    apex_json.open_object(''bemerkung'');',
'    apex_json.write(''name'',''<b>Bemerkung:</b> '' || lVTLDaten.bemerkung);',
'    apex_json.write(''isHtmlName'',true);',
'    apex_json.close_object;',
'    apex_json.open_object(''last_change'');    ',
unistr('    apex_json.write(''name'',''<b>Letzte \00C4nderung:</b> '' || to_char(lVTLDaten.letzte_aenderung_datum, ''dd.mm.yyyy hh24:mi''));'),
'    apex_json.write(''isHtmlName'',true);    ',
'    apex_json.close_object;',
'',
'    ',
'    apex_json.close_all;',
'    ',
'exception',
'    when no_data_found then',
'        apex_json.open_object(''bemerkung'');',
'        apex_json.write(''name'',''Keine Bemerkung gefunden'');',
'        apex_json.close_all;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2803095202499041769
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1036497167596372594)
,p_process_sequence=>130
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadBemerkungen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lThemaID number := apex_application.g_x01;',
'    lLandID number := apex_application.g_x02;',
'    lVorschriftID number := apex_application.g_x03;',
'    lBemerkungenVorhanden boolean := false;',
'BEGIN',
'',
'    apex_json.open_object;   ',
'',
'    for x in (',
'        select *',
'        from t_vorschrift_ref_thema vt',
'        where vt.vorschriftid = lVorschriftID',
'        and vt.themaid = lThemaID',
'        and geloescht != 1',
'        and bemerkung is not null',
'    )',
'    loop',
'        lBemerkungenVorhanden := true;',
'        apex_json.open_object(''bemerkung1'');',
'        apex_json.write(''name'',''<b>Bemerkung zum Themengebiet:</b> '' || x.bemerkung);',
'        apex_json.write(''isHtmlName'',true);',
'        apex_json.close_object;',
'    end loop;',
'',
'    for x in (',
'        select *',
'        from t_vorschrift_ref_land vl',
'        where vl.vorschriftid = lVorschriftID',
'        and vl.landid = lLandid',
'        and geloescht != 1',
'        and bemerkung is not null',
'    )',
'    loop',
'        lBemerkungenVorhanden := true;',
'        apex_json.open_object(''bemerkung2'');',
'        apex_json.write(''name'',''<b>Bemerkung zum Land:</b> '' || x.bemerkung);',
'        apex_json.write(''isHtmlName'',true);',
'        apex_json.close_object;',
'    end loop;',
'',
'    if (lBemerkungenVorhanden = false) then',
'        apex_json.open_object(''bemerkung3'');',
'        apex_json.write(''name'',''Keine Bemerkung gefunden'');',
'        apex_json.close_object;',
'    end if;',
'    apex_json.close_all;',
'',
'    /* ',
'    begin',
'        select * into lVTDaten',
'        from t_vorschrift_ref_thema vt',
'        where vt.vorschriftid = lVorschriftID',
'        and vt.themaid = lThemaID',
'        and geloescht != 1',
'        and bemerkung is not null;',
'        l_VT_found := true;',
'      exception',
'        when no_data_found then',
'          l_VT_found := false; ',
'    end;',
'',
'    select * into lVLDaten',
'    from t_vorschrift_ref_land vl',
'    where vl.vorschriftid = lVorschriftID',
'    and vl.landid = lLandid',
'    and geloescht != 1',
'    and bemerkung is not null;',
'',
'    apex_json.open_object(''bemerkung'');',
'    if(l_VT_found) then',
'      apex_json.write(''name'',''<b>Bemerkung:</b> thema-bemerkung: '' || lVTDaten.bemerkung || '' land-bemerkung: ''|| lVLDaten.bemerkung);',
'    else',
'      apex_json.write(''name'',''<b>Bemerkung:</b> land-bemerkung: ''|| lVLDaten.bemerkung);',
'    end if;',
'    apex_json.write(''isHtmlName'',true);',
'    apex_json.close_object;',
'    apex_json.open_object(''last_change'');',
'    if(l_VT_found) then    ',
unistr('       apex_json.write(''name'',''<b>Letzte \00C4nderung:</b> thema:''  || to_char(lVTDaten.letzte_aenderung_datum, ''dd.mm.yyyy hh24:mi'') ||'' land:'' || to_char(lVLDaten.letzte_aenderung_datum, ''dd.mm.yyyy hh24:mi''));'),
'    else',
unistr('       apex_json.write(''name'',''<b>Letzte \00C4nderung:</b> land:'' || to_char(lVLDaten.letzte_aenderung_datum, ''dd.mm.yyyy hh24:mi''));'),
'    end if;',
'    apex_json.write(''isHtmlName'',true);    ',
'    apex_json.close_object;',
'    */',
'    ',
'    apex_json.close_all;',
'    ',
'exception',
'    when no_data_found then',
'        apex_json.open_object(''bemerkung'');',
'        apex_json.write(''name'',''Keine Bemerkung gefunden'');',
'        apex_json.close_all;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2635715148303015641
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(697275755170037090)
,p_process_sequence=>140
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadVorschriftInfo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lVorschriftId number;',
'    lVorschriftTypId number;',
'    lVorschriftTitel varchar2(500 char);',
'    lVorschriftNummer varchar2(250 char);',
'    lVorschriftHomologation varchar2 (4096 char);',
'BEGIN',
' ',
'    lVorschriftId := apex_application.g_x01;',
'    ',
'    select VORSCHRIFT_TYPID, ',
'    CASE',
'            WHEN p.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND v.DOKUMENTENDATUM IS NOT NULL',
'            THEN v.VORSCHRIFT_NUMMER || ''_'' || TO_CHAR(v.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'            ELSE v.VORSCHRIFT_NUMMER',
'        END,',
'        ',
'        v.VORSCHRIFT_BEZEICHNUNG ',
'        into lVorschriftTypId, lVorschriftNummer, lVorschriftTitel',
'    from t_vorschrift v',
'    LEFT JOIN',
'        t_publisher p ON (v.publisherid = p.publisherid)',
'',
'    where vorschriftid = lVorschriftId;',
'    ',
'    apex_json.open_object;',
'        apex_json.open_object(''vorschrift'');',
'            apex_json.write(''typId'', lVorschriftTypId);',
'            apex_json.write(''nummer'', lVorschriftNummer);',
'            apex_json.write(''titel'', nvl(lVorschriftTitel, ''n.v.''));',
'            apex_json.open_array(''daten'');',
'',
'            for rec_datum in (',
'                select et.einsatzdatum_typ, to_char(vre.einsatzdatum, ''DD.MM.YYYY'') as einsatzdatum, et.sortorder',
'                from t_vorschrift v',
'                inner join t_einsatzdatum_typ et on (et.einsatzdatum_modellid = v.einsatzdatum_modellid)',
'                inner join t_vorschrift_ref_einsatzdatum_typ vre on ',
'                                            (vre.einsatzdatum_typid = et.einsatzdatum_typid ',
'                                            and vre.vorschriftid = v.vorschriftid )',
'                where v.vorschriftid = lVorschriftId',
'                union all',
'                select et.einsatzdatum_typ, to_char(vre.einsatzdatum, ''DD.MM.YYYY'') as einsatzdatum, et.sortorder ',
'                from t_vorschrift_ref_einsatzdatum_typ vre',
'                inner join t_einsatzdatum_typ et on (et.einsatzdatum_typid = vre.einsatzdatum_typid)',
'                where vre.einsatzdatum_typid = 1000',
'                    and vre.vorschriftid = lVorschriftId',
'                order by sortorder asc)',
'            loop',
'                apex_json.open_object();',
'                    apex_json.write(''title'', rec_datum.einsatzdatum_typ);',
'                    apex_json.write(''datum'', rec_datum.einsatzdatum);',
'                apex_json.close_object;',
'            end loop;',
'',
'            apex_json.close_array();',
'',
'            apex_json.open_array(''verlinkte_objekte'');',
'            for rec_rr in (',
'                select nv.VORSCHRIFTID, nv.VORSCHRIFT_TYPID, nv.VORSCHRIFT_NUMMER, nv.VORSCHRIFT_BEZEICHNUNG, ',
'                    vrv.HOMOLOGATION_SERIE, vrv.MAX_HOMOLOGATION_VORSCHRIFTID --, hv.VORSCHRIFT_NUMMER as MAX_HOMOLOGATION_VORSCHRIFT_NUMMER',
'                from t_vorschrift_ref_vorschrift vrv',
'                join t_vorschrift nv on (nv.vorschriftid = vrv.nachfolger_vorschriftid)',
'                --left outer join t_vorschrift hv on (hv.vorschriftid = vrv.MAX_HOMOLOGATION_VORSCHRIFTID)',
'                where vrv.vorgaenger_vorschriftid = lVorschriftId',
'                    and vrv.beziehung_art = 40 -- verweist of    ',
'                    and nv.vorschrift_typid = 30 -- Rahmenrichtlinie',
'            )',
'            loop',
'                apex_json.open_object();',
'                    apex_json.write(''typId'', lVorschriftTypId);',
'                    apex_json.write(''nummer'', rec_rr.vorschrift_nummer);    ',
'                    apex_json.write(''titel'', nvl(rec_rr.vorschrift_bezeichnung, ''n.v.''));    ',
'                    if rec_rr.HOMOLOGATION_SERIE = 10 then',
'',
'                        lVorschriftHomologation := null;',
'                        with cte_homolog (NACHFOLGER_VORSCHRIFTID) as (',
'                            Select NACHFOLGER_VORSCHRIFTID',
'                            from t_vorschrift_ref_vorschrift',
'                            where beziehung_art = 10 and vorgaenger_vorschriftid = lVorschriftId',
'                            union all',
'                            Select tvr.NACHFOLGER_VORSCHRIFTID',
'                            from cte_homolog t1',
'                            join t_vorschrift_ref_vorschrift tvr on (tvr.vorgaenger_vorschriftid = t1.nachfolger_vorschriftid)',
'                            where beziehung_art = 10 and tvr.vorgaenger_vorschriftid <> rec_rr.MAX_HOMOLOGATION_VORSCHRIFTID -- max homologationsvorschrift',
'                        ) Select listagg(trim(tv.VORSCHRIFT_NUMMER), '', '' ON OVERFLOW TRUNCATE) into lVorschriftHomologation',
'                        from cte_homolog t1',
'                        join t_vorschrift tv on (t1.NACHFOLGER_VORSCHRIFTID = tv.VORSCHRIFTID);',
'                        apex_json.write(''max_homologation'', lVorschriftHomologation);',
'',
'                    end if;',
'                    ',
'                    apex_json.open_array(''daten'');',
'',
'                    for rec_datum in (',
'                        select et.einsatzdatum_typ, to_char(vre.einsatzdatum, ''DD.MM.YYYY'') as einsatzdatum, et.sortorder',
'                        from t_vorschrift v',
'                        inner join t_einsatzdatum_typ et on (et.einsatzdatum_modellid = v.einsatzdatum_modellid)',
'                        inner join t_vorschrift_ref_einsatzdatum_typ vre on ',
'                                                    (vre.einsatzdatum_typid = et.einsatzdatum_typid ',
'                                                    and vre.vorschriftid = v.vorschriftid )',
'                        where v.vorschriftid =  rec_rr.vorschriftId',
'                        union all',
'                        select et.einsatzdatum_typ, to_char(vre.einsatzdatum, ''DD.MM.YYYY'') as einsatzdatum, et.sortorder ',
'                        from t_vorschrift_ref_einsatzdatum_typ vre',
'                        inner join t_einsatzdatum_typ et on (et.einsatzdatum_typid = vre.einsatzdatum_typid)',
'                        where vre.einsatzdatum_typid = 1000',
'                            and vre.vorschriftid = rec_rr.vorschriftId',
'                        order by sortorder asc)',
'                    loop',
'                        apex_json.open_object();',
'                            apex_json.write(''title'', rec_datum.einsatzdatum_typ);',
'                            apex_json.write(''datum'', rec_datum.einsatzdatum);',
'                        apex_json.close_object;',
'                    end loop;',
'',
'                    apex_json.close_array();',
'                    ',
'                apex_json.close_object();    ',
'            end loop;',
'            apex_json.close_array();',
'',
'        apex_json.close_object;',
'    apex_json.close_object;',
'    apex_json.close_all;',
'END;',
'',
'',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2974936560729351145
);
wwv_flow_imp.component_end;
end;
/
