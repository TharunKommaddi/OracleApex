prompt --application/pages/page_00927
begin
--   Manifest
--     PAGE: 00927
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>927
,p_name=>unistr('Schulung bearbeiten/hinzuf\00FCgen')
,p_alias=>unistr('SCHULUNG-BEARBEITEN-HINZUF\00DCGEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Schulung bearbeiten/hinzuf\00FCgen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>unistr('var htmldb_delete_message=''"M\00F6chten Sie die Schulung l\00F6schen?"'';')
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4637115306310286058)
,p_plug_name=>'Schulung'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select schulungid,',
'       i.bezeichnung as importeur,',
'       st.bezeichnung as schulung,',
'       datum_schulung,',
'       status_schulung',
'from t_schulung s',
'join t_importeur i on s.importeurid = i.importeurid',
'join t_schulung_typ st on s.schulung_typid = st.schulung_typid',
'',
''))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4637116056491286058)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(444626889446232404)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4637116056491286058)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(444626050840232403)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4637116056491286058)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P927_SCHULUNGID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(444626443034232403)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(4637116056491286058)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Speichern & Schlie\00DFen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(447281562508940483)
,p_name=>'P927_SCHULUNGID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(4637115306310286058)
,p_item_source_plug_id=>wwv_flow_imp.id(4637115306310286058)
,p_source=>'SCHULUNGID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(447281448497940482)
,p_name=>'P927_IMPORTEUR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(4637115306310286058)
,p_item_source_plug_id=>wwv_flow_imp.id(4637115306310286058)
,p_prompt=>'Importeur'
,p_source=>'IMPORTEUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(447281360298940481)
,p_name=>'P927_SCHULUNG'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4637115306310286058)
,p_item_source_plug_id=>wwv_flow_imp.id(4637115306310286058)
,p_prompt=>'Schulung'
,p_source=>'SCHULUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END AS d, ',
'    schulung_typid AS r  ',
'FROM t_schulung_typ',
'ORDER BY 1;',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(447281290336940480)
,p_name=>'P927_DATUM_SCHULUNG'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(4637115306310286058)
,p_item_source_plug_id=>wwv_flow_imp.id(4637115306310286058)
,p_prompt=>'Datum der Schulung'
,p_source=>'DATUM_SCHULUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>10
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(447281186113940479)
,p_name=>'P927_STATUS_SCHULUNG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(4637115306310286058)
,p_item_source_plug_id=>wwv_flow_imp.id(4637115306310286058)
,p_prompt=>'Status Schulung'
,p_source=>'STATUS_SCHULUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Unterlagen verteilt'', ''Documents distributed'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''geplant'', ''planned'') AS display_value,',
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''durchgef\00FChrt'', ''conducted'') AS display_value,'),
'        30 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(447280950287940477)
,p_name=>'P927_IMPORTEURID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4637115306310286058)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(429932795234891593)
,p_name=>'Cancel Dialog'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(444626889446232404)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(429932734802891592)
,p_event_id=>wwv_flow_imp.id(429932795234891593)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(444623711990232377)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P927_SCHULUNGID is null then',
'    insert into T_SCHULUNG (importeurid, schulung_typid, datum_schulung, status_schulung, LETZTE_AENDERUNG_DATUM, LETZTE_AENDERUNG_BENUTZER_ID)',
'    values (:P927_IMPORTEURID, :P927_SCHULUNG, :P927_DATUM_SCHULUNG, :P927_STATUS_SCHULUNG, sysdate, PCK_RI.fGetUserId);',
'else',
'    update T_SCHULUNG',
'    set schulung_typid = :P927_SCHULUNG,',
'    datum_schulung = :P927_DATUM_SCHULUNG,',
'    status_schulung = :P927_STATUS_SCHULUNG,',
'    LETZTE_AENDERUNG_DATUM = sysdate,',
'    LETZTE_AENDERUNG_BENUTZER_ID = PCK_RI.fGetUserId',
'    where SCHULUNGID = :P927_SCHULUNGID;',
'end if;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(444626443034232403)
,p_process_success_message=>'Die Daten wurden gespeichert.'
,p_internal_uid=>3227588603909155858
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(444624508192232378)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from t_schulung',
'where schulungid = :P927_SCHULUNGID;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(444626050840232403)
,p_internal_uid=>3227587807707155857
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(444623284107232376)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3227589031792155859
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(444624118297232377)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Initialize form Schulung bearbeiten/hinzuf\00FCgen')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P927_SCHULUNGID is not null then',
'    select s.importeurid, i.bezeichnung, schulung_typid, datum_schulung, status_schulung',
'    into :P927_IMPORTEURID, :P927_IMPORTEUR, :P927_SCHULUNG, :P927_DATUM_SCHULUNG, :P927_STATUS_SCHULUNG',
'    from t_schulung s',
'    join t_importeur i on i.importeurid = s.importeurid',
'    where schulungid = :P927_SCHULUNGID;',
'else',
'    select bezeichnung',
'    into :P927_IMPORTEUR',
'    from t_importeur',
'    where importeurid = :P927_IMPORTEURID;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3227588197602155858
);
wwv_flow_imp.component_end;
end;
/
