prompt --application/pages/page_00920
begin
--   Manifest
--     PAGE: 00920
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>920
,p_name=>'Importeure'
,p_alias=>'IMPORTEURE'
,p_step_title=>'Importeure'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#IR_IMPORTEURE_toolbar'').css({',
'    ''display'': ''flex'',',
'    ''align-items'': ''center'',',
'    ''justify-content'': ''flex-start'',',
'    ''gap'': ''10px''',
'});',
'',
'$(''#P920_SHOW_HIDE_CONTAINER'').appendTo(''#IR_IMPORTEURE_toolbar'').css({',
'    ''display'': ''inline-flex'',',
'    ''align-items'': ''center'',',
'    ''white-space'': ''nowrap'',',
'    ''order'': ''2'',',
'    ''gap'': ''10px'',',
'    ''margin-left'': ''auto''',
'});',
'',
'$(''#P920_SHOW_HIDE_CONTAINER .col'').css({',
'    ''padding'': ''0'',',
'    ''margin'': ''0'',',
'    ''width'': ''auto''',
'});',
'',
'$(''.a-IRR-buttons'').css({',
'    ''margin-left'': ''10px'',',
'    ''order'': ''3''',
'});',
'',
'',
'',
'',
'',
'',
'',
'',
'$(''#IR_IMPORTEURE'').on(''click'', ''th input'', function() {',
'    var check_all = $("#IR_IMPORTEURE").find("th input:checked").is(":checked");',
'',
unistr('    // alle Zeilen ausw\00E4hlen/abw\00E4hlen'),
'    $("#IR_IMPORTEURE").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'    var searchIDs = $("td input:checkbox:checked").map(function(){',
'        return $(this).val();',
'        }).get();',
'',
'    $s(''P920_SELECTED'',searchIDs.join('':''));',
'',
'    if (searchIDs.length > 0) {',
'        $(''.email_button'').removeClass("apex_disabled");',
'    } else {',
'        $(''.email_button'').addClass("apex_disabled");        ',
'    }',
'',
'});',
'',
'',
'',
'',
'function initializeStatusTooltips() {',
'    const tooltipText = {',
'        ''schulung'': {',
unistr('            ''red'': ''<b>Achtung</b>: Mindestens eine zugeh\00F6rige Schulung ist ung\00FCltig (nicht durchgef\00FChrt oder G\00FCltigkeitsdauer abgelaufen). Bitte \00FCberpr\00FCfen Sie die Details im Schulungsbericht.'','),
unistr('            ''limegreen'': ''Alle zugeh\00F6rigen Schulungen sind g\00FCltig (entweder f\00FCr die Zukunft geplant oder innerhalb der G\00FCltigkeitsdauer)'','),
'            ''grey'': ''Schulungstyp ist nicht mehr relevant''',
'        },  ',
'        ''audit'': {',
unistr('            ''red'': ''<b>Achtung</b>: Mindestens ein zugeh\00F6riges Audit ist ung\00FCltig (nicht durchgef\00FChrt oder G\00FCltigkeitsdauer abgelaufen). Bitte \00FCberpr\00FCfen Sie die Details im Auditbericht.'','),
unistr('            ''limegreen'': ''Alle zugeh\00F6rigen Audits sind g\00FCltig (entweder f\00FCr die Zukunft geplant oder innerhalb der G\00FCltigkeitsdauer)'','),
'            ''grey'': ''Audittyp ist nicht mehr relevant''  ',
'        },',
'        ''ansprechpartner'': {',
unistr('            ''red'': ''<b>Achtung</b>: Mindestens ein Konzern Cluster ist keinem Ansprechpartner zugeordnet. Bitte \00FCberpr\00FCfen Sie die Zuordnungen.'','),
'            ''limegreen'': ''Alle Konzern Cluster sind einem Ansprechpartner zugeordnet''',
'        },',
'        ''gesamt'': {',
unistr('            ''red'': ''<b>Achtung</b>: Mindestens eine Schulung oder ein Audit ist ung\00FCltig. Bitte \00FCberpr\00FCfen Sie die Details in den jeweiligen Berichten.'','),
unistr('            ''limegreen'': ''Alle Schulungen und Audits sind g\00FCltig (entweder f\00FCr die Zukunft geplant oder innerhalb der G\00FCltigkeitsdauer)'','),
'            ''grey'': ''Status nicht relevant'' ',
'        }',
'    };',
'',
'    apex.jQuery(".status-dot").each(function() {',
'        const $dot = apex.jQuery(this);',
'        ',
'        let type;',
'        if ($dot.hasClass(''schulung-dot'')) {',
'            type = ''schulung'';',
'        } else if ($dot.hasClass(''audit-dot'')) {',
'            type = ''audit'';',
'        } else if ($dot.hasClass(''ansprechpartner-dot'')) {',
'            type = ''ansprechpartner'';',
'        } else if ($dot.hasClass(''gesamt-dot'')) {',
'            type = ''gesamt'';',
'        }',
'',
'        const backgroundColor = $dot.css(''background-color'');',
'        let tooltipContent;',
'',
'        if (backgroundColor.includes(''rgb(255, 0, 0)'') || backgroundColor.includes(''red'')) {',
'            tooltipContent = tooltipText[type].red;',
'        } else if (backgroundColor.includes(''rgb(50, 205, 50)'') || backgroundColor.includes(''limegreen'')) {',
'            tooltipContent = tooltipText[type].limegreen;',
'        } else if (backgroundColor.includes(''rgb(187, 187, 187)'') || backgroundColor.includes(''#BBBBBB'')) {',
'            tooltipContent = tooltipText[type].grey;',
'        }',
'',
'        $dot.removeAttr(''title'');',
'        ',
'        $dot.tooltip({',
'            content: tooltipContent, ',
'            show: { effect: "fade", delay: 100 },',
'            hide: { effect: "fade", delay: 100 },',
'            position: { ',
'                my: "left+10 top+20",',
'                at: "right bottom",',
'                collision: "flipfit"',
'            },',
'            tooltipClass: "status-tooltip",',
'            track: true,',
'            items: "*"',
'        });',
'    });',
'}',
'',
'apex.jQuery(document).ready(initializeStatusTooltips);',
'apex.jQuery(document).on(''apexafterrefresh'', initializeStatusTooltips);',
'',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.status-tooltip {',
'    padding: 8px;',
'    background-color: #fff;',
'    border: 1px solid #ddd;',
'    box-shadow: 0 2px 4px rgba(0,0,0,0.1);',
'    max-width: 300px;',
'    font-size: 14px;',
'    z-index: 1000;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#IR_IMPORTEURE div.a-IRR-buttons'').css({''display'': ''flex'',''justify-content'': ''flex-end'',''align-items'': ''center''});',
'',
'var $container = $(''<span>'').css({''display'': ''flex'',''align-items'': ''center'',''margin-right'': ''10px''}).prependTo(''#IR_IMPORTEURE div.a-IRR-buttons'');',
'',
'$(''#P920_SHOW_HIDE_LABEL'').detach().appendTo($container).css({''margin-right'': ''5px'',''display'': ''inline-block''});',
'$(''#P920_SHOW_HIDE'').detach().appendTo($container).css({''margin-top'': ''0''});',
'',
'$(''#P920_SHOW_HIDE_CONTAINER'').closest(''div.row'').remove();',
'',
'',
'',
'',
''))
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3317492350728370342)
,p_plug_name=>'Importeure <span onclick="redirect(920)" class="fa fa-question-square-o"></span>'
,p_region_name=>'IR_IMPORTEURE'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_ap as (select listagg(distinct nachname || '', '' || vorname, ''<br>'' on overflow truncate) within group (order by nachname) as ansprechpartner, importeurid',
'               from t_ansprechpartner',
'               group by importeurid),',
'cte_schulungen as (select listagg(distinct bezeichnung, ''<br>'' on overflow truncate) within group (order by bezeichnung) as schulungen, importeurid',
'                  from t_schulung s',
'                  join t_schulung_typ st on s.schulung_typid = st.schulung_typid',
'                  group by importeurid),',
'cte_audits as (select listagg(distinct bezeichnung, ''<br>'' on overflow truncate) within group (order by bezeichnung) as audits, importeurid',
'               from t_audit a',
'               join t_audit_typ at on a.audit_typid = at.audit_typid',
'               group by importeurid),',
'cte_imp_laender as (',
'    select irl.importeurid, listagg(distinct b_nummer || '' ('' || CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land ELSE land_eng END || '') Prio: ''|| PRIO, '', '' on overflow truncate) within group (order by b_nummer) as liste_laender',
'    from t_importeur_ref_land irl',
'    join t_land l on (irl.landid = l.landid)',
'    group by irl.importeurid',
'), ',
'cte_Konzern_marken as(Select importeurid, listagg(tkm.NAME,'', '') within group (order by tkm.name) as Konzern_Marken ',
'                      from T_IMPORTEUR_REF_KONZERN_MARKE tref',
'                   join t_KONZERN_MARKE tkm on (tref.konzern_markeid = tkm.konzern_markeid)',
'        group by importeurid',
'),',
'cte_fahrzeugklasse as (',
'    select importeurid, listagg(fk.bezeichnung,'', '') within group (order by fk.bezeichnung) as liste',
'    from t_importeur_ref_fahrzeugklasse irf',
'    join t_fahrzeugklasse fk on (irf.fahrzeugklasseid = fk.fahrzeugklasseid)',
'    group by importeurid',
'    ',
'),',
'cte_cluster as (',
'    select importeurid, listagg(kc.bezeichnung,'', '') within group (order by kc.bezeichnung) as liste',
'    from t_importeur_ref_konzern_cluster irkc',
'    join t_konzern_cluster kc on (irkc.konzern_clusterid = kc.konzern_clusterid)',
'    group by importeurid',
'),',
'cte_kommunikationsart as (',
'    select importeurid, listagg(k.name_de,'', '') within group (order by k.name_de) as liste',
'    from t_importeur_ref_kommunikationsart irk',
'    join t_kommunikationsart k on (irk.kommunikationsartid = k.kommunikationsartid)',
'    group by importeurid',
'),',
'rowid_cte AS (',
'    SELECT importeurid, ROWIDTOCHAR(rowid) as row_id ',
'    FROM t_importeur ',
'    WHERE is_deleted = 0',
'),',
'',
'',
'cte_schulung_status as (',
'    select importeurid,',
'        CASE ',
'            -- Check if any schulungen exist',
'            WHEN NOT EXISTS (',
'                SELECT 1 ',
'                FROM t_schulung s2',
'                WHERE s2.importeurid = s.importeurid',
'            ) THEN NULL  -- No schulungen, return NULL',
'',
'            -- Check for RED status (any active training is red)',
'            WHEN EXISTS (',
'                SELECT 1 ',
'                FROM t_schulung s2',
'                JOIN t_schulung_typ st ON s2.schulung_typid = st.schulung_typid',
'                WHERE s2.importeurid = s.importeurid',
'                AND st.status != 20  -- not inactive',
'                 AND   (datum_schulung IS NULL',
'                OR (datum_schulung <= TRUNC(SYSDATE) AND status_schulung != 30)',
'                ',
'                OR ( ADD_MONTHS(s2.datum_schulung, st.DAUER_GUELTIGKEIT) <= SYSDATE)',
'                ) ',
'                 AND NOT EXISTS (',
'                    SELECT 1 ',
'                    FROM t_schulung s3',
'                    WHERE s3.schulung_typid = s2.schulung_typid  ',
'                    AND s3.importeurid = s2.importeurid         ',
'                    AND s3.datum_schulung > s2.datum_schulung   ',
'                    AND s3.schulungid != s2.schulungid          ',
'                ) ',
'            )THEN ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:red;" class="status-dot schulung-dot"></span>''',
'',
'            -- Check for GREEN status (all active are green)',
'            WHEN EXISTS (',
'                SELECT 1 ',
'                FROM t_schulung s2',
'                JOIN t_schulung_typ st ON s2.schulung_typid = st.schulung_typid',
'                WHERE s2.importeurid = s.importeurid',
'                AND st.status != 20  -- not inactive',
'                AND (datum_schulung > TRUNC(SYSDATE)',
'                OR ',
'                --st.DAUER_GUELTIGKEIT<=3 AND status_schulung = 30)',
'              ADD_MONTHS(s2.datum_schulung, st.DAUER_GUELTIGKEIT) > SYSDATE AND status_schulung = 30)',
'                ',
'            ) THEN ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:limegreen;" class="status-dot schulung-dot"></span>''',
'            ',
'            -- Otherwise WHITE/GREY (all inactive)',
'            ELSE ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:#BBBBBB;" class="status-dot schulung-dot"></span>''',
'        END as schulung_status',
'    FROM t_schulung s',
'    GROUP BY importeurid',
'),',
'',
'',
'cte_audit_status as (',
'    select importeurid,',
'        CASE ',
'            -- Check if any audits exist',
'            WHEN NOT EXISTS (',
'                SELECT 1 ',
'                FROM t_audit a2',
'                WHERE a2.importeurid = a.importeurid',
'            ) THEN NULL  -- No audits, return NULL',
'',
'            -- Check for RED status (any active audit is red)',
'            WHEN EXISTS (',
'                SELECT 1 ',
'                FROM t_audit a2',
'                JOIN t_audit_typ at ON a2.audit_typid = at.audit_typid',
'                WHERE a2.importeurid = a.importeurid',
'                AND at.status != 20  -- not inactive',
'                AND (datum_audit IS NULL',
'                    OR (datum_audit <= TRUNC(SYSDATE) AND status_audit != ''20'')',
'                    OR ( ADD_MONTHS(a2.datum_audit, at.DAUER_GUELTIGKEIT) <= SYSDATE) )',
'                AND NOT EXISTS (',
'                    SELECT 1 ',
'                    FROM t_audit a3',
'                    WHERE a3.audit_typid = a2.audit_typid  ',
'                    AND a3.importeurid = a2.importeurid         ',
'                    AND a3.datum_audit > a2.datum_audit   ',
'                    AND a3.auditid != a2.auditid          ',
'                )',
'            ) THEN ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:red;" class="status-dot audit-dot"></span>''',
'',
'            -- Check for GREEN status (all active are green)',
'            WHEN EXISTS (',
'                SELECT 1 ',
'                FROM t_audit a2',
'                JOIN t_audit_typ at ON a2.audit_typid = at.audit_typid',
'                WHERE a2.importeurid = a.importeurid',
'                AND at.status != 20  -- not inactive',
'                AND (datum_audit > TRUNC(SYSDATE)',
'                    OR ( ADD_MONTHS(a2.datum_audit, at.DAUER_GUELTIGKEIT) > SYSDATE AND status_audit = ''20'') )',
'            ) THEN ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:limegreen;" class="status-dot audit-dot"></span>''',
'            ',
'            -- Otherwise WHITE/GREY (all inactive)',
'            ELSE ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:#BBBBBB;" class="status-dot audit-dot"></span>''',
'        END as audit_status',
'    FROM t_audit a',
'    GROUP BY importeurid',
'),',
'',
'',
'cte_ansprechpartner_status as (',
'    SELECT ',
'        i.importeurid,',
'        CASE ',
'            -- Check if any ansprechpartner exist',
'            WHEN NOT EXISTS (',
'                SELECT 1 FROM t_ansprechpartner ',
'                WHERE importeurid = i.importeurid',
'            ) THEN  ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:red;" class="status-dot ansprechpartner-dot"></span>''',
'',
'            -- Check for RED status (any unassigned cluster)',
'            WHEN EXISTS (',
'                SELECT 1',
'                FROM t_importeur_ref_konzern_cluster ticrk',
'                WHERE ticrk.IMPORTEURID = i.importeurid',
'                AND NOT EXISTS (',
'                    SELECT 1 ',
'                    FROM t_ansprechpartner_ref_konzern_cluster tark ',
'                    JOIN T_ANSPRECHPARTNER ta ',
'                        ON ta.ANSPRECHPARTNERID = tark.ANSPRECHPARTNERID',
'                    WHERE ta.IMPORTEURID = i.importeurid',
'                    AND tark.KONZERN_CLUSTERID = ticrk.KONZERN_CLUSTERID',
'                )',
'            ) THEN ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:red;" class="status-dot ansprechpartner-dot"></span>''',
'',
'            -- Otherwise GREEN (all clusters assigned)',
'            ELSE ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:limegreen;" class="status-dot ansprechpartner-dot"></span>''',
'        END as ansprechpartner_status',
'    FROM t_importeur i',
'    GROUP BY i.importeurid',
'),',
'',
'',
'',
'cte_gesamt_status as (',
'    SELECT ',
'        i.importeurid,',
'        CASE ',
'            -- RED case (highest priority) - if ANY is red',
'            WHEN EXISTS (',
'                -- Schulung RED check',
'                SELECT 1 FROM t_schulung s2',
'                JOIN t_schulung_typ st ON s2.schulung_typid = st.schulung_typid',
'                WHERE s2.importeurid = i.importeurid',
'                AND st.status != 20  ',
'                AND (datum_schulung IS NULL',
'                    OR (datum_schulung <= TRUNC(SYSDATE) AND status_schulung != 30)',
'                    OR (ADD_MONTHS(s2.datum_schulung, st.DAUER_GUELTIGKEIT) <= SYSDATE))',
'                AND NOT EXISTS (',
'                    SELECT 1 FROM t_schulung s3',
'                    WHERE s3.schulung_typid = s2.schulung_typid  ',
'                    AND s3.importeurid = s2.importeurid         ',
'                    AND s3.datum_schulung > s2.datum_schulung   ',
'                    AND s3.schulungid != s2.schulungid          ',
'                )',
'            )',
'            OR EXISTS (',
'                -- Audit RED check',
'                SELECT 1 FROM t_audit a2',
'                JOIN t_audit_typ at ON a2.audit_typid = at.audit_typid',
'                WHERE a2.importeurid = i.importeurid',
'                AND at.status != 20',
'                AND (datum_audit IS NULL',
'                    OR (datum_audit <= TRUNC(SYSDATE) AND status_audit != ''20'')',
'                    OR (ADD_MONTHS(a2.datum_audit, at.DAUER_GUELTIGKEIT) <= SYSDATE))',
'                AND NOT EXISTS (',
'                    SELECT 1 FROM t_audit a3',
'                    WHERE a3.audit_typid = a2.audit_typid  ',
'                    AND a3.importeurid = a2.importeurid         ',
'                    AND a3.datum_audit > a2.datum_audit   ',
'                    AND a3.auditid != a2.auditid          ',
'                )',
'            )',
'            -- Ansprechpartner RED check - if no ansprechpartner or unassigned clusters',
'            OR NOT EXISTS (',
'                SELECT 1 FROM t_ansprechpartner ',
'                WHERE importeurid = i.importeurid',
'            )',
'            OR EXISTS (',
'                SELECT 1',
'                FROM t_importeur_ref_konzern_cluster ticrk',
'                WHERE ticrk.IMPORTEURID = i.importeurid',
'                AND NOT EXISTS (',
'                    SELECT 1 ',
'                    FROM t_ansprechpartner_ref_konzern_cluster tark ',
'                    JOIN T_ANSPRECHPARTNER ta ',
'                        ON ta.ANSPRECHPARTNERID = tark.ANSPRECHPARTNERID',
'                    WHERE ta.IMPORTEURID = i.importeurid',
'                    AND tark.KONZERN_CLUSTERID = ticrk.KONZERN_CLUSTERID',
'                )',
'            )',
'            THEN ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:red;" class="status-dot gesamt-dot"></span>''',
'',
'            -- GREEN case - if ANY GREEN and no RED',
'            WHEN EXISTS (',
'                SELECT 1 ',
'                FROM (',
'                    -- Schulung GREEN',
'                    SELECT 1 FROM t_schulung s2',
'                    JOIN t_schulung_typ st ON s2.schulung_typid = st.schulung_typid',
'                    WHERE s2.importeurid = i.importeurid',
'                    AND st.status != 20',
'                    AND (datum_schulung > TRUNC(SYSDATE)',
'                        OR (ADD_MONTHS(s2.datum_schulung, st.DAUER_GUELTIGKEIT) > SYSDATE ',
'                        AND status_schulung = 30))',
'                    UNION ALL',
'                    -- Audit GREEN',
'                    SELECT 1 FROM t_audit a2',
'                    JOIN t_audit_typ at ON a2.audit_typid = at.audit_typid',
'                    WHERE a2.importeurid = i.importeurid',
'                    AND at.status != 20',
'                    AND (datum_audit > TRUNC(SYSDATE)',
'                        OR (ADD_MONTHS(a2.datum_audit, at.DAUER_GUELTIGKEIT) > SYSDATE ',
'                        AND status_audit = ''20''))',
'                    UNION ALL',
'                    -- Ansprechpartner GREEN',
'                    SELECT 1 ',
'                    FROM t_ansprechpartner',
'                    WHERE importeurid = i.importeurid',
'                    AND NOT EXISTS (',
'                        SELECT 1',
'                        FROM t_importeur_ref_konzern_cluster ticrk',
'                        WHERE ticrk.IMPORTEURID = i.importeurid',
'                        AND NOT EXISTS (',
'                            SELECT 1 ',
'                            FROM t_ansprechpartner_ref_konzern_cluster tark ',
'                            JOIN T_ANSPRECHPARTNER ta ',
'                                ON ta.ANSPRECHPARTNERID = tark.ANSPRECHPARTNERID',
'                            WHERE ta.IMPORTEURID = i.importeurid',
'                            AND tark.KONZERN_CLUSTERID = ticrk.KONZERN_CLUSTERID',
'                        )',
'                    )',
'                )',
'            ) THEN ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:limegreen;" class="status-dot gesamt-dot"></span>''',
'',
'            -- GREY case - all others',
'            ELSE ''<span style="display:inline-block;width:20px;height:20px;border-radius:50%;background-color:#BBBBBB;" class="status-dot gesamt-dot"></span>''',
'        END as gesamt_status',
'    FROM t_importeur i',
'    GROUP BY i.importeurid',
')',
'',
'',
'',
'',
'',
'',
'select 1 as checkbox,',
'    r.row_id,',
'    i.importeurid, ',
'    i.bezeichnung, ',
'    i.ghv_datum, ',
'    ap.ansprechpartner,',
'    s.schulungen,',
'    au.audits,',
'    i.letzte_aenderung_datum,   ',
'    nvl2(i.letzte_aenderung_benutzer_id, nachname || '', '' || vorname, null) as LETZTE_AENDERUNG_BENUTZER,',
'    l.liste_laender,',
'    ckm.Konzern_Marken,',
'    case i.daten_erfasst_kontrolliert ',
'                when 10 then emano_util.fLang(''offen'', ''open'')',
'                when 20 then emano_util.fLang(''in Bearbeitung'', ''in progress'')',
'                when 30 then emano_util.fLang(''ja'', ''yes'')',
'                else null',
'            end as daten_erfasst_kontrolliert,',
'',
'    fk.liste as fahrzeugklassen,',
'    case i.verantwortung_importeur ',
'                when 10 then emano_util.fLang(''Hauptverantwortlicher Importeur'', ''Main Responsible Importer'')',
'                when 20 then emano_util.fLang(''Supportimporteur'', ''Support Importer'')',
'                else null',
'            end as verantwortung_importeur,',
'    c.liste as konzern_cluster,',
'    ka.liste as kommunikationsarten,',
'',
'    ss.schulung_status,',
'    aus.audit_status,',
'    aps.ansprechpartner_status,',
'    gs.gesamt_status',
'',
'from t_importeur i',
'join rowid_cte r on r.importeurid = i.importeurid',
'left join t_benutzer b on b.benutzerid = i.letzte_aenderung_benutzer_id',
'left join cte_ap ap on ap.importeurid = i.importeurid',
'left join cte_schulungen s on s.importeurid = i.importeurid',
'left join cte_audits au on au.importeurid = i.importeurid',
'left join cte_imp_laender l on (i.importeurid = l.importeurid)',
'left join cte_Konzern_marken ckm on (i.importeurid =  ckm.importeurid )',
'left join cte_fahrzeugklasse fk on (i.importeurid = fk.importeurid)',
'left join cte_cluster c on (i.importeurid = c.importeurid)',
'left join cte_kommunikationsart ka on (i.importeurid = ka.importeurid)',
'LEFT JOIN cte_schulung_status ss ON ss.importeurid = i.importeurid',
'LEFT JOIN cte_audit_status aus ON aus.importeurid = i.importeurid',
'LEFT JOIN cte_ansprechpartner_status aps ON aps.importeurid = i.importeurid',
'LEFT JOIN cte_gesamt_status gs ON gs.importeurid = i.importeurid',
'',
'where i.is_deleted = 0',
'order by i.bezeichnung',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(3317492681650370342)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:925:&SESSION.::&DEBUG.:925:P925_IMPORTEURID:#IMPORTEURID#'
,p_detail_link_text=>'<span class="fa fa-pencil" aria-hidden="true" alt="Bearbeiten" title="Bearbeiten"></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>4430185618745504746
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(384027787003334720)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>10
,p_column_identifier=>'AD'
,p_column_label=>'<input type="checkbox" value="all" />'
,p_column_html_expression=>'<input type="checkbox" value="#IMPORTEURID#" />'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_static_id=>'selector'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(448291779506572097)
,p_db_column_name=>'IMPORTEURID'
,p_display_order=>30
,p_column_identifier=>'S'
,p_column_label=>'Importeurid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(448291671991572096)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>40
,p_column_identifier=>'T'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(401856265124284870)
,p_db_column_name=>'LISTE_LAENDER'
,p_display_order=>50
,p_column_identifier=>'AA'
,p_column_label=>unistr('L\00E4nder')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(448291634924572095)
,p_db_column_name=>'GHV_DATUM'
,p_display_order=>60
,p_column_identifier=>'U'
,p_column_label=>'Datum Geheimhaltungsvereinbarung'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(448291446868572094)
,p_db_column_name=>'ANSPRECHPARTNER'
,p_display_order=>70
,p_column_identifier=>'V'
,p_column_label=>'Ansprechpartner'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(448291356120572093)
,p_db_column_name=>'SCHULUNGEN'
,p_display_order=>80
,p_column_identifier=>'W'
,p_column_label=>'Schulungen'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(448291252627572092)
,p_db_column_name=>'AUDITS'
,p_display_order=>90
,p_column_identifier=>'X'
,p_column_label=>'Audits'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(448291196234572091)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>100
,p_column_identifier=>'Y'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(448291061586572090)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>110
,p_column_identifier=>'Z'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(363487796100991603)
,p_db_column_name=>'KONZERN_MARKEN'
,p_display_order=>120
,p_column_identifier=>'AB'
,p_column_label=>'Konzern Marken'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(327612331861252378)
,p_db_column_name=>'DATEN_ERFASST_KONTROLLIERT'
,p_display_order=>130
,p_column_identifier=>'AC'
,p_column_label=>'Daten erfasst/kontrolliert'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(384029789767334740)
,p_db_column_name=>'FAHRZEUGKLASSEN'
,p_display_order=>140
,p_column_identifier=>'AE'
,p_column_label=>'Fahrzeugklassen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(384029980225334742)
,p_db_column_name=>'KONZERN_CLUSTER'
,p_display_order=>160
,p_column_identifier=>'AG'
,p_column_label=>'Konzern Cluster'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(384030063321334743)
,p_db_column_name=>'VERANTWORTUNG_IMPORTEUR'
,p_display_order=>170
,p_column_identifier=>'AH'
,p_column_label=>'Verantwortung Importeur'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(384030262384334744)
,p_db_column_name=>'KOMMUNIKATIONSARTEN'
,p_display_order=>180
,p_column_identifier=>'AI'
,p_column_label=>'Kommunikationsarten'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1095751400756347800)
,p_db_column_name=>'SCHULUNG_STATUS'
,p_display_order=>190
,p_column_identifier=>'AJ'
,p_column_label=>'Schulung Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P920_SHOW_HIDE = 1'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1095751239226347799)
,p_db_column_name=>'AUDIT_STATUS'
,p_display_order=>200
,p_column_identifier=>'AK'
,p_column_label=>'Audit Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P920_SHOW_HIDE = 1'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1095751170735347798)
,p_db_column_name=>'ANSPRECHPARTNER_STATUS'
,p_display_order=>210
,p_column_identifier=>'AL'
,p_column_label=>'Ansprechpartner Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P920_SHOW_HIDE = 1'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1095751108542347797)
,p_db_column_name=>'GESAMT_STATUS'
,p_display_order=>220
,p_column_identifier=>'AM'
,p_column_label=>'Gesamt Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1095750558321347792)
,p_db_column_name=>'ROW_ID'
,p_display_order=>230
,p_column_identifier=>'AN'
,p_column_label=>'Row Id'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(3317498441562392045)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'6643829'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CHECKBOX:GESAMT_STATUS:SCHULUNG_STATUS:AUDIT_STATUS:ANSPRECHPARTNER_STATUS:BEZEICHNUNG:LISTE_LAENDER:DATEN_ERFASST_KONTROLLIERT:LETZTE_AENDERUNG_DATUM:LETZTE_AENDERUNG_BENUTZER:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(126010861828526603)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3317492350728370342)
,p_button_name=>'SD_SCHULUNGSTYPEN'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Schulungstypen'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:window.open(''f?p=&APP_ID.:900:&SESSION.'',''_blank'');'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(126010946991526604)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3317492350728370342)
,p_button_name=>'SD_AUDITTYPEN'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Audittypen'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:window.open(''f?p=&APP_ID.:910:&SESSION.'',''_blank'');'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(126011527686526610)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(3317492350728370342)
,p_button_name=>'SD_KONZERNMARKEN'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Konzern-Marken'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:window.open(''f?p=&APP_ID.:930:&SESSION.'',''_blank'');'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(126012435816526619)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(3317492350728370342)
,p_button_name=>'SD_RTF'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Reporting Tool & Frequency'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:window.open(''f?p=&APP_ID.:940:&SESSION.'',''_blank'');'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(401859593128284903)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(3317492350728370342)
,p_button_name=>'SD_AUFGABENTYPEN'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Arbeitsaufgaben-Typen'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:window.open(''f?p=&APP_ID.:950:&SESSION.'',''_blank'');'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(384028178882334724)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3317492350728370342)
,p_button_name=>'EMAIL_SPOC'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'E-Mail an alle SPOC'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'email_button'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(384028307260334725)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3317492350728370342)
,p_button_name=>'EMAIL_RVKO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'E-Mail an alle R-VKO'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'email_button'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(384028407695334726)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(3317492350728370342)
,p_button_name=>'EMAIL_ALLE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'E-Mail an alle AP'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'email_button'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(448309594161513491)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(3317492350728370342)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:925:&SESSION.::&DEBUG.:925:P925_CAME_FROM:920'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1095750717125347794)
,p_name=>'P920_SHOW_HIDE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(3317492350728370342)
,p_item_default=>'0'
,p_prompt=>unistr('Zus\00E4tzliche Spalten anzeigen')
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Nein',
  'off_value', '0',
  'on_label', 'Ja',
  'on_value', '1',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(384027927793334721)
,p_name=>'P920_SELECTED'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3317492350728370342)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(384028736008334729)
,p_name=>'P920_EMAIL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3317492350728370342)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(448309203449513459)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(3317492350728370342)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(448308733109513455)
,p_event_id=>wwv_flow_imp.id(448309203449513459)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3317492350728370342)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(448308325995513455)
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(448309594161513491)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(448307756983513454)
,p_event_id=>wwv_flow_imp.id(448308325995513455)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3317492350728370342)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(384027987569334722)
,p_name=>'Zeilenselektor'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'td input'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#IR_IMPORTEURE'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(384028119820334723)
,p_event_id=>wwv_flow_imp.id(384027987569334722)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var searchIDs = $("td[headers=''selector''] input:checkbox:checked").map(function(){',
'      return $(this).val();',
'    }).get();',
'',
'$s(''P920_SELECTED'',searchIDs.join('':''));',
'',
'if (searchIDs.length > 0) {',
'    $(''.email_button'').removeClass("apex_disabled");',
'} else {',
'    $(''.email_button'').addClass("apex_disabled");        ',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(384028510549334727)
,p_name=>'Klick E-Mail SPOC'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(384028178882334724)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(384028606335334728)
,p_event_id=>wwv_flow_imp.id(384028510549334727)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P920_EMAIL'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''mailto:?bcc='' || listagg(email_adresse,'';'') within group (order by email_adresse)',
'from t_ansprechpartner ap',
'join apex_string.split_numbers(:P920_SELECTED,'':'') x on (x.column_value = ap.importeurid)',
'where ap.spoc = 10'))
,p_attribute_07=>'P920_SELECTED'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(384029138912334733)
,p_event_id=>wwv_flow_imp.id(384028510549334727)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.navigation.redirect($v("P920_EMAIL"));',
'//window.location.href = $v(''P920_EMAIL'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(384029254518334734)
,p_name=>'Klick E-Mail RVKO'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(384028307260334725)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(384029274862334735)
,p_event_id=>wwv_flow_imp.id(384029254518334734)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P920_EMAIL'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''mailto:?bcc='' || listagg(email_adresse,'';'') within group (order by email_adresse)',
'from t_ansprechpartner ap',
'join apex_string.split_numbers(:P920_SELECTED,'':'') x on (x.column_value = ap.importeurid)',
'where ap.r_vko = 10'))
,p_attribute_07=>'P920_SELECTED'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(384029423642334736)
,p_event_id=>wwv_flow_imp.id(384029254518334734)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window.location.href = $v(''P920_EMAIL'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(384029536083334737)
,p_name=>'Klick E-Mail Alle'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(384028407695334726)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(384029586123334738)
,p_event_id=>wwv_flow_imp.id(384029536083334737)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P920_EMAIL'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''mailto:?bcc='' || listagg(email_adresse,'';'') within group (order by email_adresse)',
'from t_ansprechpartner ap',
'join apex_string.split_numbers(:P920_SELECTED,'':'') x on (x.column_value = ap.importeurid)'))
,p_attribute_07=>'P920_SELECTED'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(384029702197334739)
,p_event_id=>wwv_flow_imp.id(384029536083334737)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window.location.href = $v(''P920_EMAIL'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1095751005894347796)
,p_name=>'TOGGLE_STATUS_COLUMNS'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P920_SHOW_HIDE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1095750835105347795)
,p_event_id=>wwv_flow_imp.id(1095751005894347796)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P920_SHOW_HIDE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1095750715493347793)
,p_event_id=>wwv_flow_imp.id(1095751005894347796)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3317492350728370342)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
