prompt --application/pages/page_02305
begin
--   Manifest
--     PAGE: 02305
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>2305
,p_name=>'GETEX Datensatz'
,p_alias=>'GETEX-DATENSATZ'
,p_page_mode=>'MODAL'
,p_step_title=>'GETEX Datensatz'
,p_allow_duplicate_submissions=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_dialog_width=>'1000'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(589967683253770873)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(589967975211770876)
,p_plug_name=>'JSON-Quellcode'
,p_parent_plug_id=>wwv_flow_imp.id(589967683253770873)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1199403260146193337)
,p_plug_name=>'Footer'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3095365486633678231)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(589967975211770876)
,p_button_name=>'DOWNLOAD_JSON'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'Quellcode herunterladen'
,p_button_redirect_url=>'f?p=&APP_ID.:0:&SESSION.:application_process=downloadGetexJson:&DEBUG.::G_GETEX_KEY:&P2305_GETEXKEY.'
,p_icon_css_classes=>'fa-download'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(672900887960569944)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(589967683253770873)
,p_button_name=>'GETEX'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('In neuem Tab \00F6ffnen')
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:window.open(''&P2305_GETEXURL.'', ''_blank'')'
,p_icon_css_classes=>'fa-globe'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>1
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(672900502384569939)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(589967683253770873)
,p_button_name=>'KOMMENTAR_SPEICHERN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Kommentar speichern'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-save'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>1
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(672896721325569934)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1199403260146193337)
,p_button_name=>'SAVE_AS_NEW'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Als neue Vorschrift anlegen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(672896300190569934)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1199403260146193337)
,p_button_name=>'CLOSE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Schlie\00DFen')
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(672900114993569939)
,p_name=>'P2305_GETEXKEY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(589967683253770873)
,p_prompt=>unistr('GETEX Schl\00FCssel')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(672899668880569938)
,p_name=>'P2305_VORSCHRIFTID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(589967683253770873)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(672899327610569938)
,p_name=>'P2305_KOMMENTAR_ZEITPUNKT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(589967683253770873)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(672898902058569937)
,p_name=>'P2305_VORSCHRIFTNUMMER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(589967683253770873)
,p_prompt=>'Vorschriftennummer'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(672898527591569936)
,p_name=>'P2305_GETEXURL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(589967683253770873)
,p_prompt=>'Link GETEX'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(672898119672569936)
,p_name=>'P2305_KOMMENTAR'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(589967683253770873)
,p_prompt=>'Kommentar'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_inline_help_text=>'&P2305_KOMMENTAR_ZEITPUNKT.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(672897404089569935)
,p_name=>'P2305_JSON'
,p_data_type=>'CLOB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(589967975211770876)
,p_prompt=>'Json'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>10
,p_tag_attributes=>'disabled'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144103148820565)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(672895493316569933)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Kommentar speichern'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'merge into t_getex_kommentar t',
'using (',
'    select :P2305_GETEXKEY as getex_key, :P2305_KOMMENTAR as kommentar',
'    from dual',
') u',
'on (t.getex_key = u.getex_key)',
'when matched then update set kommentar = u.kommentar, kommentar_zeitpunkt = sysdate',
'when not matched then insert (getex_key, kommentar, kommentar_zeitpunkt)',
'values (u.getex_key, u.kommentar, sysdate);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(672900502384569939)
,p_internal_uid=>2999316822582818302
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(672895108212569932)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Als neue Vorschrift anlegen'
,p_process_sql_clob=>':P2305_VORSCHRIFTID := PCK_RI_GETEX_CTRL.fNeueVorschrift(:P2305_GETEXKEY);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(672896721325569934)
,p_process_success_message=>'wurde angelegt.'
,p_internal_uid=>2999317207686818303
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(672894660125569932)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog after save'
,p_attribute_01=>'P2305_VORSCHRIFTID'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':REQUEST in (''CLOSE'',''SAVE_AS_NEW'')'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>2999317655773818303
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(672895843592569933)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'init'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' ',
' select rev_displayurl, reg_num ',
'    into :P2305_GETEXURL, :P2305_VORSCHRIFTNUMMER ',
'    from mv_getex_vorschrift',
'    where reg_id = :P2305_GETEXKEY;',
'',
'  begin',
'    select  daten_json',
'    into  :P2305_JSON',
'    from mv_getex_vorschrift',
'    where reg_id = :P2305_GETEXKEY;',
'  exception',
'    when others then',
'    :P2305_JSON := '' Fehler beim lesen von JSON-Daten'';',
'  end;',
'',
' begin',
'      select kommentar, nvl2(kommentar_zeitpunkt,''Zuletzt gespeichert am '' || to_char(kommentar_zeitpunkt,''dd.mm.yy'') || '' um '' || to_char(kommentar_zeitpunkt,''hh24:mi'') || ''.'', null)',
'      into :P2305_KOMMENTAR, :P2305_KOMMENTAR_ZEITPUNKT',
'      from t_getex_kommentar',
'      where getex_key = :P2305_GETEXKEY;',
'',
' exception',
'    when no_data_found then',
'        :P2305_KOMMENTAR := null;',
'        :P2305_KOMMENTAR_ZEITPUNKT := null;',
' end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2999316472306818302
);
wwv_flow_imp.component_end;
end;
/
