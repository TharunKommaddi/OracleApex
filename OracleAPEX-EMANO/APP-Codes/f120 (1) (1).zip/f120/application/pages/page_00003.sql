prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'29GetexCopy'
,p_alias=>'29GETEXCOPY'
,p_page_mode=>'MODAL'
,p_step_title=>'29GetexCopy'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1300'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_comment=>'j'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(578073432301754550)
,p_plug_name=>'Main Region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(576828346851066011)
,p_plug_name=>'Thema'
,p_parent_plug_id=>wwv_flow_imp.id(578073432301754550)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>40
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_value clob;',
'l_condition varchar2(200) := :P3_LIST;',
'begin',
'if l_condition =''Alle'' then',
'',
'l_value :=''SELECT tv.VORSCHRIFT_NUMMER , ',
'      tvrt.THEMAID AS LocalThemaID,',
'         tt.BEZEICHNUNG AS LocalThemaName,',
'       vgt.REGINDEX_THEMAID AS GetexThemaID,',
'        vgt.THEMA_NAME AS GetexThemaName',
'  from  T_VORSCHRIFT_REF_THEMA tvrt',
'  join T_THEMA tt on ( tvrt.THEMAID = tt.THEMAID and tvrt.geloescht = 0)',
'  join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvrt.VORSCHRIFTid and tv.REGINDEXID is not null)',
'   JOIN  V_GETEX_VORSCHRIFT_THEMA vgt ON (tv.REGINDEXID = vgt.V_ID and tvrt.VORSCHRIFTid = tv.VORSCHRIFTid)',
'  WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'   AND tvrt.THEMAID  = vgt.REGINDEX_THEMAID',
'   union ',
'   SELECT tv.VORSCHRIFT_NUMMER , ',
'          tvrt.THEMAID AS LocalThemaID,',
'          tt.BEZEICHNUNG AS LocalThemaName,',
'           null as GetexThemaID,',
'           ''''null''''  AS GetexThemaName',
'     from T_VORSCHRIFT_REF_THEMA tvrt',
'     join T_THEMA tt on ( tvrt.THEMAID = tt.THEMAID and tvrt.geloescht = 0)',
'    join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvrt.VORSCHRIFTid and tv.REGINDEXID is not null)',
'    WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'      and tvrt.THEMAID not in (',
'          select REGINDEX_THEMAID from V_GETEX_VORSCHRIFT_THEMA where v_id = tv.REGINDEXID)',
'          union ',
'          SELECT tv.VORSCHRIFT_NUMMER , ',
'           null AS LocalThemaID,',
'          ''''null'''' AS LocalThemaName,',
'           vgt.REGINDEX_THEMAID AS GetexThemaID,',
'        vgt.THEMA_NAME AS GetexThemaName',
'   from V_GETEX_VORSCHRIFT_THEMA vgt  ',
' join T_THEMA tt on ( vgt.REGINDEX_THEMAID = tt.THEMAID)',
'    join T_VORSCHRIFT tv on (tv.REGINDEXID is not null and tv.regindexid = vgt.v_id)',
'  WHERE ',
'    tv.VORSCHRIFTID =:P3_VORSCHRIFTID',
'    and vgt.REGINDEX_THEMAID  not in (',
'          select THEMAID from T_VORSCHRIFT_REF_THEMA where VORSCHRIFTID =:P3_VORSCHRIFTID and geloescht = 0)',
'    '' ;',
'   ',
'',
'elsif l_condition =''Vorschrift'' then',
'',
'l_value :='' SELECT tv.VORSCHRIFT_NUMMER , ',
'      tvrt.THEMAID AS LocalThemaID,',
'         tt.BEZEICHNUNG AS LocalThemaName,',
'       vgt.REGINDEX_THEMAID AS GetexThemaID,',
'        vgt.THEMA_NAME AS GetexThemaName',
'  from  T_VORSCHRIFT_REF_THEMA tvrt',
'  join T_THEMA tt on ( tvrt.THEMAID = tt.THEMAID and tvrt.geloescht = 0)',
'  join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvrt.VORSCHRIFTid and tv.REGINDEXID is not null)',
'   JOIN  V_GETEX_VORSCHRIFT_THEMA vgt ON (tv.REGINDEXID = vgt.V_ID and tvrt.VORSCHRIFTid = tv.VORSCHRIFTid)',
'  WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID ',
'   AND tvrt.THEMAID  = vgt.REGINDEX_THEMAID  ',
'   union',
'     SELECT tv.VORSCHRIFT_NUMMER , ',
'          tvrt.THEMAID AS LocalThemaID,',
'          tt.BEZEICHNUNG AS LocalThemaName,',
'           null as GetexThemaID,',
'           ''''null''''  AS GetexThemaName',
'     from T_VORSCHRIFT_REF_THEMA tvrt',
'     join T_THEMA tt on ( tvrt.THEMAID = tt.THEMAID and tvrt.geloescht = 0)',
'    join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvrt.VORSCHRIFTid and tv.REGINDEXID is not null)',
'    WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'      and tvrt.THEMAID not in (',
'          select REGINDEX_THEMAID from V_GETEX_VORSCHRIFT_THEMA where v_id = tv.REGINDEXID)',
' '' ;',
'   else',
'   l_value :=''SELECT tv.VORSCHRIFT_NUMMER , ',
'      tvrt.THEMAID AS LocalThemaID,',
'         tt.BEZEICHNUNG AS LocalThemaName,',
'       vgt.REGINDEX_THEMAID AS GetexThemaID,',
'        vgt.THEMA_NAME AS GetexThemaName',
'  from  T_VORSCHRIFT_REF_THEMA tvrt',
'  join T_THEMA tt on ( tvrt.THEMAID = tt.THEMAID and tvrt.geloescht = 0)',
'  join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvrt.VORSCHRIFTid and tv.REGINDEXID is not null)',
'   JOIN  V_GETEX_VORSCHRIFT_THEMA vgt ON (tv.REGINDEXID = vgt.V_ID and tvrt.VORSCHRIFTid = tv.VORSCHRIFTid)',
'  WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID ',
'   AND tvrt.THEMAID  = vgt.REGINDEX_THEMAID  ',
'   union',
'    SELECT tv.VORSCHRIFT_NUMMER , ',
'           null AS LocalThemaID,',
'          ''''null'''' AS LocalThemaName,',
'           vgt.REGINDEX_THEMAID AS GetexThemaID,',
'        vgt.THEMA_NAME AS GetexThemaName',
'   from V_GETEX_VORSCHRIFT_THEMA vgt  ',
' join T_THEMA tt on ( vgt.REGINDEX_THEMAID = tt.THEMAID)',
'    join T_VORSCHRIFT tv on (tv.REGINDEXID is not null and tv.regindexid = vgt.v_id)',
'  WHERE ',
'    tv.VORSCHRIFTID =:P3_VORSCHRIFTID ',
'    and vgt.REGINDEX_THEMAID  not in (',
'          select THEMAID from T_VORSCHRIFT_REF_THEMA where VORSCHRIFTID =:P3_VORSCHRIFTID and geloescht = 0)',
'   '' ;',
'end if;',
'return(l_value);',
'end;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_VORSCHRIFTID,P3_LIST'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Thema'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    tv.REGINDEXID AS LocalRegindexID,',
'    vgt.V_ID AS GetexVID,',
'    tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'    tvrt.THEMAID AS LocalThemaID,',
'    vgt.REGINDEX_THEMAID AS GetexThemaID,',
'    tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON tv.VORSCHRIFTID = tvrt.VORSCHRIFTID',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'    AND (',
'        (:P29_LIST = ''Alle'' AND (tvrt.THEMAID != vgt.REGINDEX_THEMAID OR tvrt.THEMAID IS NULL OR vgt.REGINDEX_THEMAID IS NULL))',
'        OR (:P29_LIST = ''Getex'' AND vgt.REGINDEX_THEMAID IS NOT NULL AND tvrt.THEMAID IS NULL)',
'        OR (:P29_LIST = ''Vorschrift'' AND tvrt.THEMAID IS NOT NULL AND vgt.REGINDEX_THEMAID IS NULL)',
'    );',
'',
'',
'',
'',
'',
'',
'',
'declare',
'l_value clob;',
'begin',
'if :P29_LIST =''Alle'' then',
'',
'l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
'full outer JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE tv.REGINDEXID IS NOT NULL',
'and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'',
'elsif :P29_LIST =''Vorschrift'' then',
'',
'l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
' left outer JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE tv.REGINDEXID IS NOT NULL',
'and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'   else',
'   l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
' V_GETEX_VORSCHRIFT_THEMA vgt',
' INNER JOIN',
'    T_VORSCHRIFT tv ON tv.REGINDEXID = vgt.V_ID',
'left outer join ',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID    ',
'WHERE tv.REGINDEXID IS NOT NULL',
' and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'end if;',
'return(l_value);',
'end;'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(576828322398066010)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>535864614697068394
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839644823656013680)
,p_db_column_name=>'LOCALTHEMAID'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Localthemaid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839644435531013676)
,p_db_column_name=>'GETEXTHEMAID'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Getexthemaid'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839644032114013675)
,p_db_column_name=>'LOCALTHEMANAME'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'RegulationIndex Themaname'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839643557004013673)
,p_db_column_name=>'GETEXTHEMANAME'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Getex Themaname'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839643185137013673)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>70
,p_column_identifier=>'K'
,p_column_label=>'Vorschrift Nummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(576719597673844657)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2629273'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'GETEXTHEMANAME:LOCALTHEMANAME'
,p_sort_column_1=>'GETEXTHEMAID'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'LOCALTHEMAID'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'GETEXTHEMANAME'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'LOCALTHEMANAME'
,p_sort_direction_4=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(576724923292847536)
,p_plug_name=>'Land'
,p_parent_plug_id=>wwv_flow_imp.id(578073432301754550)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>50
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_value clob;',
'l_condition varchar2(200) := :P3_LIST;',
'begin',
'if l_condition =''Alle'' then',
'',
'l_value :=''SELECT tv.VORSCHRIFT_NUMMER , ',
'      tvrl.LANDID AS LocalLandID,',
'         tl.LAND AS LocalLandName,',
'       vgl.REGINDEX_LANDID AS GetexLandID,',
'        vgl.LAND_NAME AS GetexLandName',
'  from  T_VORSCHRIFT_REF_LAND tvrl',
'  join T_LAND tl on ( tvrl.LANDID = tl.LANDID and tvrl.geloescht = 0)',
'  join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvrl.VORSCHRIFTid and tv.REGINDEXID is not null)',
'   JOIN   V_GETEX_VORSCHRIFT_LAND vgl ON (tv.REGINDEXID = vgl.V_ID and tvrl.VORSCHRIFTid = tv.VORSCHRIFTid)',
'  WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'   AND tvrl.LANDID = vgl.REGINDEX_LANDID',
'union ',
'    SELECT tv.VORSCHRIFT_NUMMER , ',
'          tvrl.LANDID AS LocalLandID,',
'          tl.LAND AS LocalLandName,',
'           null as GetexLandID,',
'           ''''null''''  AS GetexLandName',
'     from  T_VORSCHRIFT_REF_LAND tvrl',
'    join T_LAND tl on ( tvrl.LANDID = tl.LANDID and tvrl.geloescht = 0)',
'    join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvrl.VORSCHRIFTid and tv.REGINDEXID is not null)',
'    WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'      and tvrl.LANDID not in (',
'          select REGINDEX_LANDID from V_GETEX_VORSCHRIFT_LAND where v_id = tv.REGINDEXID)',
'union ',
'  SELECT tv.VORSCHRIFT_NUMMER , ',
'   null AS LocalLandID,',
'  ''''null'''' AS LocalLandName,',
'   vgl.REGINDEX_LANDID AS GetexLandID,',
'vgl.LAND_NAME AS GetexLandName',
'from V_GETEX_VORSCHRIFT_LAND vgl',
'join T_LAND tl on ( vgl.REGINDEX_LANDID = tl.LANDID)',
'join T_VORSCHRIFT tv on (tv.REGINDEXID is not null and tv.regindexid = vgl.v_id)',
'WHERE ',
'tv.VORSCHRIFTID =:P3_VORSCHRIFTID',
'and vgl.REGINDEX_LANDID  not in (',
'  select LANDID from T_VORSCHRIFT_REF_LAND where VORSCHRIFTID =:P3_VORSCHRIFTID and geloescht = 0)',
'    '' ;',
'   ',
'',
'elsif l_condition =''Vorschrift'' then',
'',
'l_value :='' SELECT tv.VORSCHRIFT_NUMMER , ',
'      tvrl.LANDID AS LocalLandID,',
'         tl.LAND AS LocalLandName,',
'       vgl.REGINDEX_LANDID AS GetexLandID,',
'        vgl.LAND_NAME AS GetexLandName',
'  from  T_VORSCHRIFT_REF_LAND tvrl',
'  join T_LAND tl on ( tvrl.LANDID = tl.LANDID and tvrl.geloescht = 0)',
'  join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvrl.VORSCHRIFTid and tv.REGINDEXID is not null)',
'   JOIN   V_GETEX_VORSCHRIFT_LAND vgl ON (tv.REGINDEXID = vgl.V_ID and tvrl.VORSCHRIFTid = tv.VORSCHRIFTid)',
'  WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'   AND tvrl.LANDID = vgl.REGINDEX_LANDID',
'',
'union ',
'    SELECT tv.VORSCHRIFT_NUMMER , ',
'          tvrl.LANDID AS LocalLandID,',
'          tl.LAND AS LocalLandName,',
'           null as GetexLandID,',
'           ''''null''''  AS GetexLandName',
'     from  T_VORSCHRIFT_REF_LAND tvrl',
'    join T_LAND tl on ( tvrl.LANDID = tl.LANDID and tvrl.geloescht = 0)',
'    join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvrl.VORSCHRIFTid and tv.REGINDEXID is not null)',
'    WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'      and tvrl.LANDID not in (',
'          select REGINDEX_LANDID from V_GETEX_VORSCHRIFT_LAND where v_id = tv.REGINDEXID)',
' '' ;',
'   else',
'   l_value :=''SELECT tv.VORSCHRIFT_NUMMER , ',
'      tvrl.LANDID AS LocalLandID,',
'         tl.LAND AS LocalLandName,',
'       vgl.REGINDEX_LANDID AS GetexLandID,',
'        vgl.LAND_NAME AS GetexLandName',
'  from  T_VORSCHRIFT_REF_LAND tvrl',
'  join T_LAND tl on ( tvrl.LANDID = tl.LANDID and tvrl.geloescht = 0)',
'  join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvrl.VORSCHRIFTid and tv.REGINDEXID is not null)',
'   JOIN   V_GETEX_VORSCHRIFT_LAND vgl ON (tv.REGINDEXID = vgl.V_ID and tvrl.VORSCHRIFTid = tv.VORSCHRIFTid)',
'  WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'   AND tvrl.LANDID = vgl.REGINDEX_LANDID',
'',
'union ',
'  SELECT tv.VORSCHRIFT_NUMMER , ',
'   null AS LocalLandID,',
'  ''''null'''' AS LocalLandName,',
'   vgl.REGINDEX_LANDID AS GetexLandID,',
'vgl.LAND_NAME AS GetexLandName',
'from V_GETEX_VORSCHRIFT_LAND vgl',
'join T_LAND tl on ( vgl.REGINDEX_LANDID = tl.LANDID)',
'join T_VORSCHRIFT tv on (tv.REGINDEXID is not null and tv.regindexid = vgl.v_id)',
'WHERE ',
'tv.VORSCHRIFTID =:P3_VORSCHRIFTID',
'and vgl.REGINDEX_LANDID  not in (',
'  select LANDID from T_VORSCHRIFT_REF_LAND where VORSCHRIFTID =:P3_VORSCHRIFTID and geloescht = 0)',
'   '' ;',
'end if;',
'return(l_value);',
'end;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_VORSCHRIFTID,P3_LIST'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Land'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    tv.REGINDEXID AS LocalRegindexID,',
'    vgt.V_ID AS GetexVID,',
'    tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'    tvrt.THEMAID AS LocalThemaID,',
'    vgt.REGINDEX_THEMAID AS GetexThemaID,',
'    tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON tv.VORSCHRIFTID = tvrt.VORSCHRIFTID',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'    AND (',
'        (:P29_LIST = ''Alle'' AND (tvrt.THEMAID != vgt.REGINDEX_THEMAID OR tvrt.THEMAID IS NULL OR vgt.REGINDEX_THEMAID IS NULL))',
'        OR (:P29_LIST = ''Getex'' AND vgt.REGINDEX_THEMAID IS NOT NULL AND tvrt.THEMAID IS NULL)',
'        OR (:P29_LIST = ''Vorschrift'' AND tvrt.THEMAID IS NOT NULL AND vgt.REGINDEX_THEMAID IS NULL)',
'    );',
'',
'',
'',
'',
'',
'',
'',
'declare',
'l_value clob;',
'begin',
'if :P29_LIST =''Alle'' then',
'',
'l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
'full outer JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE tv.REGINDEXID IS NOT NULL',
'and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'',
'elsif :P29_LIST =''Vorschrift'' then',
'',
'l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
' left outer JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE tv.REGINDEXID IS NOT NULL',
'and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'   else',
'   l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
' V_GETEX_VORSCHRIFT_THEMA vgt',
' INNER JOIN',
'    T_VORSCHRIFT tv ON tv.REGINDEXID = vgt.V_ID',
'left outer join ',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID    ',
'WHERE tv.REGINDEXID IS NOT NULL',
' and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'end if;',
'return(l_value);',
'end;'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(576724758946847535)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>535968178148286869
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839642189070013655)
,p_db_column_name=>'LOCALLANDID'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Locallandid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839641783124013653)
,p_db_column_name=>'GETEXLANDID'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Getexlandid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839641429562013652)
,p_db_column_name=>'LOCALLANDNAME'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'RegulationIndex Landname'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839641017051013650)
,p_db_column_name=>'GETEXLANDNAME'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Getex Landname'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839640605150013649)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>140
,p_column_identifier=>'O'
,p_column_label=>'Vorschrift Nummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(575838858625251977)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2638080'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'GETEXLANDNAME:LOCALLANDNAME'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(576722241131847510)
,p_plug_name=>'Antriebsart'
,p_parent_plug_id=>wwv_flow_imp.id(578073432301754550)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>60
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_value clob;',
'l_condition varchar2(200) := :P3_LIST;',
'begin',
'if l_condition =''Alle'' then',
'',
'l_value :=''SELECT tv.VORSCHRIFT_NUMMER , ',
'      tvra.ANTRIEBSARTID AS LocalAntriebsartID,',
'         ta.BEZEICHNUNG AS LocalAntriebsartName,',
'       vga.REGINDEX_ANTRIEBSARTID AS GetexAntriebsartID,',
'        vga.ANTRIEBSART AS GetexAntriebsartName',
'  from  T_VORSCHRIFT_REF_ANTRIEBSART tvra',
'  join T_ANTRIEBSART ta on ( tvra.ANTRIEBSARTID = ta.ANTRIEBSARTID and tvra.geloescht = 0)',
'  join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvra.VORSCHRIFTid and tv.REGINDEXID is not null)',
'   JOIN  V_GETEX_VORSCHRIFT_ANTRIEBSART vga ON (tv.REGINDEXID = vga.V_ID and tvra.VORSCHRIFTid = tv.VORSCHRIFTid)',
'  WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'   AND tvra.ANTRIEBSARTID  = vga.REGINDEX_ANTRIEBSARTID',
'union ',
'   SELECT tv.VORSCHRIFT_NUMMER , ',
'          tvra.ANTRIEBSARTID AS LocalAntriebsartID,',
'          ta.BEZEICHNUNG AS LocalAntriebsartName,',
'           null as GetexAntriebsartID,',
'           ''''null''''  AS GetexAntriebsartName',
'     from  T_VORSCHRIFT_REF_ANTRIEBSART tvra',
'  join T_ANTRIEBSART ta on ( tvra.ANTRIEBSARTID = ta.ANTRIEBSARTID and tvra.geloescht = 0)',
'  join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvra.VORSCHRIFTid and tv.REGINDEXID is not null)',
'    WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'      and tvra.ANTRIEBSARTID not in (',
'          select REGINDEX_ANTRIEBSARTID from V_GETEX_VORSCHRIFT_ANTRIEBSART where v_id = tv.REGINDEXID)',
'union ',
'          SELECT tv.VORSCHRIFT_NUMMER , ',
'           null AS LocalAntriebsartID,',
'          ''''null'''' AS LocalAntriebsartName,',
'           vga.REGINDEX_ANTRIEBSARTID AS GetexAntriebsartID,',
'        vga.ANTRIEBSART AS GetexAntriebsartName',
'   from V_GETEX_VORSCHRIFT_ANTRIEBSART vga',
' join T_ANTRIEBSART ta on ( vga.REGINDEX_ANTRIEBSARTID = ta.ANTRIEBSARTID)',
'    join T_VORSCHRIFT tv on (tv.REGINDEXID is not null and tv.regindexid = vga.v_id)',
'  WHERE ',
'    tv.VORSCHRIFTID =:P3_VORSCHRIFTID',
'    and vga.REGINDEX_ANTRIEBSARTID  not in (',
'          select ANTRIEBSARTID from T_VORSCHRIFT_REF_ANTRIEBSART where VORSCHRIFTID =:P3_VORSCHRIFTID and geloescht = 0)',
'    '' ;',
'   ',
'',
'elsif l_condition =''Vorschrift'' then',
'',
'l_value :='' SELECT tv.VORSCHRIFT_NUMMER , ',
'      tvra.ANTRIEBSARTID AS LocalAntriebsartID,',
'         ta.BEZEICHNUNG AS LocalAntriebsartName,',
'       vga.REGINDEX_ANTRIEBSARTID AS GetexAntriebsartID,',
'        vga.ANTRIEBSART AS GetexAntriebsartName',
'  from  T_VORSCHRIFT_REF_ANTRIEBSART tvra',
'  join T_ANTRIEBSART ta on ( tvra.ANTRIEBSARTID = ta.ANTRIEBSARTID and tvra.geloescht = 0)',
'  join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvra.VORSCHRIFTid and tv.REGINDEXID is not null)',
'   JOIN  V_GETEX_VORSCHRIFT_ANTRIEBSART vga ON (tv.REGINDEXID = vga.V_ID and tvra.VORSCHRIFTid = tv.VORSCHRIFTid)',
'  WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'   AND tvra.ANTRIEBSARTID  = vga.REGINDEX_ANTRIEBSARTID',
'union',
'SELECT tv.VORSCHRIFT_NUMMER , ',
'          tvra.ANTRIEBSARTID AS LocalAntriebsartID,',
'          ta.BEZEICHNUNG AS LocalAntriebsartName,',
'           null as GetexAntriebsartID,',
'           ''''null''''  AS GetexAntriebsartName',
'     from  T_VORSCHRIFT_REF_ANTRIEBSART tvra',
'  join T_ANTRIEBSART ta on ( tvra.ANTRIEBSARTID = ta.ANTRIEBSARTID and tvra.geloescht = 0)',
'  join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvra.VORSCHRIFTid and tv.REGINDEXID is not null)',
'    WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'      and tvra.ANTRIEBSARTID not in (',
'          select REGINDEX_ANTRIEBSARTID from V_GETEX_VORSCHRIFT_ANTRIEBSART where v_id = tv.REGINDEXID) ',
' '' ;',
'   else',
'   l_value :=''SELECT tv.VORSCHRIFT_NUMMER , ',
'      tvra.ANTRIEBSARTID AS LocalAntriebsartID,',
'         ta.BEZEICHNUNG AS LocalAntriebsartName,',
'       vga.REGINDEX_ANTRIEBSARTID AS GetexAntriebsartID,',
'        vga.ANTRIEBSART AS GetexAntriebsartName',
'  from  T_VORSCHRIFT_REF_ANTRIEBSART tvra',
'  join T_ANTRIEBSART ta on ( tvra.ANTRIEBSARTID = ta.ANTRIEBSARTID and tvra.geloescht = 0)',
'  join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvra.VORSCHRIFTid and tv.REGINDEXID is not null)',
'   JOIN  V_GETEX_VORSCHRIFT_ANTRIEBSART vga ON (tv.REGINDEXID = vga.V_ID and tvra.VORSCHRIFTid = tv.VORSCHRIFTid)',
'  WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'   AND tvra.ANTRIEBSARTID  = vga.REGINDEX_ANTRIEBSARTID',
'union ',
'',
'SELECT tv.VORSCHRIFT_NUMMER , ',
'           null AS LocalAntriebsartID,',
'          ''''null'''' AS LocalAntriebsartName,',
'           vga.REGINDEX_ANTRIEBSARTID AS GetexAntriebsartID,',
'        vga.ANTRIEBSART AS GetexAntriebsartName',
'   from V_GETEX_VORSCHRIFT_ANTRIEBSART vga',
' join T_ANTRIEBSART ta on ( vga.REGINDEX_ANTRIEBSARTID = ta.ANTRIEBSARTID)',
'    join T_VORSCHRIFT tv on (tv.REGINDEXID is not null and tv.regindexid = vga.v_id)',
'  WHERE ',
'    tv.VORSCHRIFTID =:P3_VORSCHRIFTID',
'    and vga.REGINDEX_ANTRIEBSARTID  not in (',
'          select ANTRIEBSARTID from T_VORSCHRIFT_REF_ANTRIEBSART where VORSCHRIFTID =:P3_VORSCHRIFTID and geloescht = 0)',
'   '' ;',
'end if;',
'return(l_value);',
'end;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_VORSCHRIFTID,P3_LIST'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Antriebsart'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    tv.REGINDEXID AS LocalRegindexID,',
'    vgt.V_ID AS GetexVID,',
'    tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'    tvrt.THEMAID AS LocalThemaID,',
'    vgt.REGINDEX_THEMAID AS GetexThemaID,',
'    tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON tv.VORSCHRIFTID = tvrt.VORSCHRIFTID',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'    AND (',
'        (:P29_LIST = ''Alle'' AND (tvrt.THEMAID != vgt.REGINDEX_THEMAID OR tvrt.THEMAID IS NULL OR vgt.REGINDEX_THEMAID IS NULL))',
'        OR (:P29_LIST = ''Getex'' AND vgt.REGINDEX_THEMAID IS NOT NULL AND tvrt.THEMAID IS NULL)',
'        OR (:P29_LIST = ''Vorschrift'' AND tvrt.THEMAID IS NOT NULL AND vgt.REGINDEX_THEMAID IS NULL)',
'    );',
'',
'',
'',
'',
'',
'',
'',
'declare',
'l_value clob;',
'begin',
'if :P29_LIST =''Alle'' then',
'',
'l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
'full outer JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE tv.REGINDEXID IS NOT NULL',
'and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'',
'elsif :P29_LIST =''Vorschrift'' then',
'',
'l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
' left outer JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE tv.REGINDEXID IS NOT NULL',
'and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'   else',
'   l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
' V_GETEX_VORSCHRIFT_THEMA vgt',
' INNER JOIN',
'    T_VORSCHRIFT tv ON tv.REGINDEXID = vgt.V_ID',
'left outer join ',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID    ',
'WHERE tv.REGINDEXID IS NOT NULL',
' and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'end if;',
'return(l_value);',
'end;'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(575837352150244559)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>536855584944889845
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839639607308013644)
,p_db_column_name=>'LOCALANTRIEBSARTID'
,p_display_order=>100
,p_column_identifier=>'N'
,p_column_label=>'Localantriebsartid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839639185245013643)
,p_db_column_name=>'GETEXANTRIEBSARTID'
,p_display_order=>110
,p_column_identifier=>'O'
,p_column_label=>'Getexantriebsartid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839638816871013642)
,p_db_column_name=>'LOCALANTRIEBSARTNAME'
,p_display_order=>120
,p_column_identifier=>'P'
,p_column_label=>'RegulationIndex Antriebsartname'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839638380849013642)
,p_db_column_name=>'GETEXANTRIEBSARTNAME'
,p_display_order=>130
,p_column_identifier=>'Q'
,p_column_label=>'Getex Antriebsartname'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839637979138013642)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>140
,p_column_identifier=>'R'
,p_column_label=>'Vorschrift Nummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(575787787790668303)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2638591'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'GETEXANTRIEBSARTNAME:LOCALANTRIEBSARTNAME'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(575835837837244544)
,p_plug_name=>'Fahrzeugklasse'
,p_parent_plug_id=>wwv_flow_imp.id(578073432301754550)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>70
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_value clob;',
'l_condition varchar2(200) := :P3_LIST;',
'begin',
'if l_condition =''Alle'' then',
'',
'l_value :=''SELECT tv.VORSCHRIFT_NUMMER , tvrf.FAHRZEUGKLASSEID local_FZ_class, tfz.BEZEICHNUNG AS LocalFahrzeugklasse,',
'                             vgfz.FAHRZEUGKLASSEID getex_FZ_class, vgfz.FAHRZEUG_TYP AS GetexFahrzeugklasseTyp',
'  from T_VORSCHRIFT_REF_FAHRZEUGKLASSE tvrf',
'  join T_FAHRZEUGKLASSE tfz on (tfz.FAHRZEUGKLASSEID = tvrf.FAHRZEUGKLASSEID)',
'  join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvrf.VORSCHRIFTid and tv.REGINDEXID is not null)',
'   JOIN  V_GETEX_VORSCHRIFT_FZ_TYP vgfz ON (tv.REGINDEXID = vgfz.V_ID and tvrf.VORSCHRIFTid = tv.VORSCHRIFTid)',
'  WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'   and tvrf.FAHRZEUGKLASSEID = vgfz.FAHRZEUGKLASSEID ',
'  UNION',
'   SELECT tv.VORSCHRIFT_NUMMER , tvrf.FAHRZEUGKLASSEID local_FZ_class, tfz.BEZEICHNUNG AS LocalFahrzeugklasse,',
'                              null as getex_FZ_class, ''''null''''  AS GetexFahrzeugklasseTyp',
'     from T_VORSCHRIFT_REF_FAHRZEUGKLASSE tvrf',
'     join T_FAHRZEUGKLASSE tfz on (tfz.FAHRZEUGKLASSEID = tvrf.FAHRZEUGKLASSEID)',
'     join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvrf.VORSCHRIFTid and tv.REGINDEXID is not null)',
'    WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'      and tvrf.FAHRZEUGKLASSEID not in (',
'          select FAHRZEUGKLASSEID from V_GETEX_VORSCHRIFT_FZ_TYP where v_id = tv.REGINDEXID)',
'  UNION',
'   SELECT tv.VORSCHRIFT_NUMMER , null as local_FZ_class, ''''null'''' AS LocalFahrzeugklasse,',
'                              vgfz.FAHRZEUGKLASSEID getex_FZ_class, vgfz.FAHRZEUG_TYP AS GetexFahrzeugklasseTyp',
'   from V_GETEX_VORSCHRIFT_FZ_TYP vgfz ',
'  join T_FAHRZEUGKLASSE tfz on (tfz.FAHRZEUGKLASSEID = vgfz.FAHRZEUGKLASSEID)',
'  join T_VORSCHRIFT tv on ( tv.REGINDEXID is not null and tv.regindexid = vgfz.v_id)',
'  WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'    and vgfz.FAHRZEUGKLASSEID not in (',
'          select FAHRZEUGKLASSEID from T_VORSCHRIFT_REF_FAHRZEUGKLASSE where VORSCHRIFTID = :P3_VORSCHRIFTID) '' ;',
'',
'elsif l_condition =''Vorschrift'' then',
'',
'l_value :='' SELECT tv.VORSCHRIFT_NUMMER , tvrf.FAHRZEUGKLASSEID local_FZ_class, tfz.BEZEICHNUNG AS LocalFahrzeugklasse,',
'                             vgfz.FAHRZEUGKLASSEID getex_FZ_class, vgfz.FAHRZEUG_TYP AS GetexFahrzeugklasseTyp',
'  from T_VORSCHRIFT_REF_FAHRZEUGKLASSE tvrf',
'  join T_FAHRZEUGKLASSE tfz on (tfz.FAHRZEUGKLASSEID = tvrf.FAHRZEUGKLASSEID)',
'  join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvrf.VORSCHRIFTid and tv.REGINDEXID is not null)',
'   JOIN  V_GETEX_VORSCHRIFT_FZ_TYP vgfz ON (tv.REGINDEXID = vgfz.V_ID and tvrf.VORSCHRIFTid = tv.VORSCHRIFTid)',
'  WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'   and tvrf.FAHRZEUGKLASSEID = vgfz.FAHRZEUGKLASSEID ',
'   union ',
'   SELECT tv.VORSCHRIFT_NUMMER , tvrf.FAHRZEUGKLASSEID local_FZ_class, tfz.BEZEICHNUNG AS LocalFahrzeugklasse,',
'                              null as getex_FZ_class, ''''null''''  AS GetexFahrzeugklasseTyp',
'     from T_VORSCHRIFT_REF_FAHRZEUGKLASSE tvrf',
'     join T_FAHRZEUGKLASSE tfz on (tfz.FAHRZEUGKLASSEID = tvrf.FAHRZEUGKLASSEID)',
'     join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvrf.VORSCHRIFTid and tv.REGINDEXID is not null)',
'    WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'      and tvrf.FAHRZEUGKLASSEID not in (',
'          select FAHRZEUGKLASSEID from V_GETEX_VORSCHRIFT_FZ_TYP where v_id = tv.REGINDEXID)',
' '' ;',
'   else',
'   l_value :=''SELECT tv.VORSCHRIFT_NUMMER , tvrf.FAHRZEUGKLASSEID local_FZ_class, tfz.BEZEICHNUNG AS LocalFahrzeugklasse,',
'                             vgfz.FAHRZEUGKLASSEID getex_FZ_class, vgfz.FAHRZEUG_TYP AS GetexFahrzeugklasseTyp',
'  from T_VORSCHRIFT_REF_FAHRZEUGKLASSE tvrf',
'  join T_FAHRZEUGKLASSE tfz on (tfz.FAHRZEUGKLASSEID = tvrf.FAHRZEUGKLASSEID)',
'  join T_VORSCHRIFT tv on (tv.VORSCHRIFTid = tvrf.VORSCHRIFTid and tv.REGINDEXID is not null)',
'   JOIN  V_GETEX_VORSCHRIFT_FZ_TYP vgfz ON (tv.REGINDEXID = vgfz.V_ID and tvrf.VORSCHRIFTid = tv.VORSCHRIFTid)',
'  WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'   and tvrf.FAHRZEUGKLASSEID = vgfz.FAHRZEUGKLASSEID ',
'   union ',
'   SELECT tv.VORSCHRIFT_NUMMER , null as local_FZ_class, ''''null'''' AS LocalFahrzeugklasse,',
'                              vgfz.FAHRZEUGKLASSEID getex_FZ_class, vgfz.FAHRZEUG_TYP AS GetexFahrzeugklasseTyp',
'   from V_GETEX_VORSCHRIFT_FZ_TYP vgfz ',
'  join T_FAHRZEUGKLASSE tfz on (tfz.FAHRZEUGKLASSEID = vgfz.FAHRZEUGKLASSEID)',
'  join T_VORSCHRIFT tv on ( tv.REGINDEXID is not null and tv.regindexid = vgfz.v_id)',
'  WHERE ',
'    tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'    and vgfz.FAHRZEUGKLASSEID not in (',
'          select FAHRZEUGKLASSEID from T_VORSCHRIFT_REF_FAHRZEUGKLASSE where VORSCHRIFTID = :P3_VORSCHRIFTID)',
'   '' ;',
'end if;',
'return(l_value);',
'end;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_VORSCHRIFTID,P3_LIST'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Fahrzeugklasse'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    tv.REGINDEXID AS LocalRegindexID,',
'    vgt.V_ID AS GetexVID,',
'    tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'    tvrt.THEMAID AS LocalThemaID,',
'    vgt.REGINDEX_THEMAID AS GetexThemaID,',
'    tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON tv.VORSCHRIFTID = tvrt.VORSCHRIFTID',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'    AND (',
'        (:P29_LIST = ''Alle'' AND (tvrt.THEMAID != vgt.REGINDEX_THEMAID OR tvrt.THEMAID IS NULL OR vgt.REGINDEX_THEMAID IS NULL))',
'        OR (:P29_LIST = ''Getex'' AND vgt.REGINDEX_THEMAID IS NOT NULL AND tvrt.THEMAID IS NULL)',
'        OR (:P29_LIST = ''Vorschrift'' AND tvrt.THEMAID IS NOT NULL AND vgt.REGINDEX_THEMAID IS NULL)',
'    );',
'',
'',
'',
'',
'',
'',
'',
'declare',
'l_value clob;',
'begin',
'if :P29_LIST =''Alle'' then',
'',
'l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
'full outer JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE tv.REGINDEXID IS NOT NULL',
'and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'',
'elsif :P29_LIST =''Vorschrift'' then',
'',
'l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
' left outer JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE tv.REGINDEXID IS NOT NULL',
'and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'   else',
'   l_value :=''SELECT',
' tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  tvrt.THEMAID AS LocalThemaID,',
'  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
' V_GETEX_VORSCHRIFT_THEMA vgt',
' INNER JOIN',
'    T_VORSCHRIFT tv ON tv.REGINDEXID = vgt.V_ID',
'left outer join ',
'    T_VORSCHRIFT_REF_THEMA tvrt ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID    ',
'WHERE tv.REGINDEXID IS NOT NULL',
' and tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
'   AND  tvrt.THEMAID != vgt.REGINDEX_THEMAID'' ;',
'end if;',
'return(l_value);',
'end;   d d'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(575835792168244543)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>536857144926889861
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839636954692013638)
,p_db_column_name=>'GETEXFAHRZEUGKLASSETYP'
,p_display_order=>90
,p_column_identifier=>'U'
,p_column_label=>'Getex Fahrzeugklassename'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839636642587013637)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>100
,p_column_identifier=>'V'
,p_column_label=>'Vorschrift Nummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839636323016013637)
,p_db_column_name=>'LOCAL_FZ_CLASS'
,p_display_order=>110
,p_column_identifier=>'W'
,p_column_label=>'Local Fz Class'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839635901448013636)
,p_db_column_name=>'LOCALFAHRZEUGKLASSE'
,p_display_order=>120
,p_column_identifier=>'X'
,p_column_label=>'Localfahrzeugklasse'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839635465045013636)
,p_db_column_name=>'GETEX_FZ_CLASS'
,p_display_order=>130
,p_column_identifier=>'Y'
,p_column_label=>'Getex Fz Class'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(575749161310370033)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2638977'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'GETEXFAHRZEUGKLASSETYP:LOCALFAHRZEUGKLASSE:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(578071830032754533)
,p_plug_name=>'Getex'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(586047552919901914)
,p_plug_name=>'Getex-Thema'
,p_parent_plug_id=>wwv_flow_imp.id(578071830032754533)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--thema',
'SELECT',
'   -- tv.REGINDEXID AS LocalRegindexID,',
'    vgt.V_ID AS GetexVID,',
'  tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'  --  tvrt.THEMAID AS LocalThemaID,',
'    vgt.REGINDEX_THEMAID AS GetexThemaID,',
' --   tt.BEZEICHNUNG AS LocalThemaName,',
'    vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON tv.VORSCHRIFTID = tvrt.VORSCHRIFTID',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'    AND (',
'        tvrt.THEMAID != vgt.REGINDEX_THEMAID',
'        --OR tt.BEZEICHNUNG != vgt.THEMA_NAME',
'    );',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_VORSCHRIFTID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Getex-Thema'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(586047374158901912)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>526645562936232492
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839626092742013618)
,p_db_column_name=>'GETEXVID'
,p_display_order=>20
,p_column_identifier=>'G'
,p_column_label=>'Getexvid'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839625645270013618)
,p_db_column_name=>'GETEXTHEMAID'
,p_display_order=>50
,p_column_identifier=>'J'
,p_column_label=>'Getexthemaid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839625256056013618)
,p_db_column_name=>'GETEXTHEMANAME'
,p_display_order=>70
,p_column_identifier=>'L'
,p_column_label=>'Getexthemaname'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839624922548013617)
,p_db_column_name=>'LOCALVORSCHRIFTNUMMER'
,p_display_order=>80
,p_column_identifier=>'M'
,p_column_label=>'Localvorschriftnummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(578064421195747948)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2615825'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LOCALVORSCHRIFTNUMMER:GETEXTHEMANAME:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(578071412694754529)
,p_plug_name=>'Getex-Land'
,p_parent_plug_id=>wwv_flow_imp.id(578071830032754533)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    --tv.REGINDEXID AS LocalRegindexID,',
'    vgl.V_ID AS GetexVID,',
'    tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'    --tvrl.VORSCHRIFTID AS LocalVorschriftID,',
'    --tvrl.LANDID AS LocalLandID,',
'    --vgl.REGINDEX_LANDID AS GetexLandID,',
'    --tl.LAND AS LocalLandName,',
'    vgl.LAND_NAME AS GetexLandName',
'    ',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_LAND tvrl ON tv.VORSCHRIFTID = tvrl.VORSCHRIFTID',
'INNER JOIN',
'    T_LAND tl ON tvrl.LANDID = tl.LANDID',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_LAND vgl ON tv.REGINDEXID = vgl.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'    AND (',
'        tvrl.LANDID != vgl.REGINDEX_LANDID',
'        --OR tl.LAND != vgl.LAND_NAME',
'        ',
'    );',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_VORSCHRIFTID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Getex-Land'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(578071256049754528)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>534621681045379876
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839623889684013613)
,p_db_column_name=>'GETEXVID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Getexvid'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839623524896013612)
,p_db_column_name=>'LOCALVORSCHRIFTNUMMER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Localvorschriftnummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839623094027013612)
,p_db_column_name=>'GETEXLANDNAME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Getexlandname'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(577849340028932480)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2617975'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LOCALVORSCHRIFTNUMMER:GETEXLANDNAME:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(577847344478924859)
,p_plug_name=>'Getex-Antriebsart'
,p_parent_plug_id=>wwv_flow_imp.id(578071830032754533)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>60
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    --tv.REGINDEXID AS LocalRegindexID,',
'    --vga.V_ID AS GetexVID,',
'    tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'    --tvra.VORSCHRIFTID AS LocalVorschriftID,',
'    --tvra.ANTRIEBSARTID AS LocalAntriebsartID,',
'    --ta.BEZEICHNUNG AS LocalAntriebsartBezeichnung,',
'    vga.ANTRIEBSART AS GetexAntriebsartBezeichnung',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_ANTRIEBSART tvra ON tv.VORSCHRIFTID = tvra.VORSCHRIFTID',
'INNER JOIN',
'    T_ANTRIEBSART ta ON tvra.ANTRIEBSARTID = ta.ANTRIEBSARTID',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_ANTRIEBSART vga ON tv.REGINDEXID = vga.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'    AND (',
'        tvra.ANTRIEBSARTID != vga.REGINDEX_ANTRIEBSARTID',
'        --OR ta.BEZEICHNUNG != vga.ANTRIEBSART',
'    );',
'',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_VORSCHRIFTID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Getex-Antriebsart'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(577847288225924858)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>534845648869209546
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839622104864013611)
,p_db_column_name=>'LOCALVORSCHRIFTNUMMER'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Localvorschriftnummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839621708881013611)
,p_db_column_name=>'GETEXANTRIEBSARTBEZEICHNUNG'
,p_display_order=>30
,p_column_identifier=>'D'
,p_column_label=>'Getexantriebsartbezeichnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(577837139530890186)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2618097'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LOCALVORSCHRIFTNUMMER'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(577844361903924829)
,p_plug_name=>'Getex-Fahrzeugklasse'
,p_parent_plug_id=>wwv_flow_imp.id(578071830032754533)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    --tv.REGINDEXID AS LocalRegindexID,',
'    --vgfz.V_ID AS GetexVID,',
'    tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'    --tvrfz.VORSCHRIFTID AS LocalVorschriftID,',
'    --tvrfz.FAHRZEUGKLASSEID AS LocalFahrzeugklasseID,',
'    --tfz.BEZEICHNUNG AS LocalFahrzeugklasseBezeichnung,',
'    vgfz.FAHRZEUG_TYP AS GetexFahrzeugklasseTyp',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_FAHRZEUGKLASSE tvrfz ON tv.VORSCHRIFTID = tvrfz.VORSCHRIFTID',
'INNER JOIN',
'    T_FAHRZEUGKLASSE tfz ON tvrfz.FAHRZEUGKLASSEID = tfz.FAHRZEUGKLASSEID',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_FZ_TYP vgfz ON tv.REGINDEXID = vgfz.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'    AND (',
'        tvrfz.FAHRZEUGKLASSEID != vgfz.FAHRZEUGKLASSEID',
'        --OR tfz.BEZEICHNUNG != vgfz.FAHRZEUG_TYP',
'    );',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_VORSCHRIFTID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Getex-Fahrzeugklasse'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(577844286414924828)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>534848650680209576
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839627486482013620)
,p_db_column_name=>'LOCALVORSCHRIFTNUMMER'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Localvorschriftnummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839627064457013619)
,p_db_column_name=>'GETEXFAHRZEUGKLASSETYP'
,p_display_order=>30
,p_column_identifier=>'D'
,p_column_label=>'Getexfahrzeugklassetyp'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(577811914925728031)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2618350'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LOCALVORSCHRIFTNUMMER:GETEXFAHRZEUGKLASSETYP'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(578071633901754532)
,p_plug_name=>'Vorschrift'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(586047481416901913)
,p_plug_name=>'Vorschrift-Thema'
,p_parent_plug_id=>wwv_flow_imp.id(578071633901754532)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    tv.REGINDEXID AS LocalRegindexID,',
'   -- vgt.V_ID AS GetexVID,',
'    tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'    tvrt.THEMAID AS LocalThemaID,',
'  --  vgt.REGINDEX_THEMAID AS GetexThemaID,',
'    tt.BEZEICHNUNG AS LocalThemaName',
'   -- vgt.THEMA_NAME AS GetexThemaName',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_THEMA tvrt ON tv.VORSCHRIFTID = tvrt.VORSCHRIFTID',
'INNER JOIN',
'    T_THEMA tt ON tvrt.THEMAID = tt.THEMAID',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'    AND  (',
'        tvrt.THEMAID != vgt.REGINDEX_THEMAID',
'        --OR tt.BEZEICHNUNG != vgt.THEMA_NAME',
'    );',
'',
'',
'    ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_VORSCHRIFTID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Vorschrift-Thema'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(586047316766901911)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>526645620328232493
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839632809186013629)
,p_db_column_name=>'LOCALREGINDEXID'
,p_display_order=>10
,p_column_identifier=>'E'
,p_column_label=>'Localregindexid'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839632407974013628)
,p_db_column_name=>'LOCALVORSCHRIFTNUMMER'
,p_display_order=>30
,p_column_identifier=>'G'
,p_column_label=>'Localvorschriftnummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839631985491013628)
,p_db_column_name=>'LOCALTHEMAID'
,p_display_order=>40
,p_column_identifier=>'H'
,p_column_label=>'Localthemaid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839631546415013628)
,p_db_column_name=>'LOCALTHEMANAME'
,p_display_order=>60
,p_column_identifier=>'J'
,p_column_label=>'Localthemaname'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(578063819965747872)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2615831'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LOCALVORSCHRIFTNUMMER:LOCALTHEMANAME:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(578070092084754516)
,p_plug_name=>'Vorschrift-Land'
,p_parent_plug_id=>wwv_flow_imp.id(578071633901754532)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>60
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    --tv.REGINDEXID AS LocalRegindexID,',
'    --vgl.V_ID AS GetexVID,',
'    tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'    --tvrl.VORSCHRIFTID AS LocalVorschriftID,',
'    --tvrl.LANDID AS LocalLandID,',
'    --vgl.REGINDEX_LANDID AS GetexLandID,',
'    tl.LAND AS LocalLandName',
'    --vgl.LAND_NAME AS GetexLandName',
'    ',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_LAND tvrl ON tv.VORSCHRIFTID = tvrl.VORSCHRIFTID',
'INNER JOIN',
'    T_LAND tl ON tvrl.LANDID = tl.LANDID',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_LAND vgl ON tv.REGINDEXID = vgl.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'    AND (',
'        tvrl.LANDID != vgl.REGINDEX_LANDID',
'        --OR tl.LAND != vgl.LAND_NAME',
'        ',
'    );',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_VORSCHRIFTID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Vorschrift-Land'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(578069949603754515)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>534622987491379889
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839629155360013625)
,p_db_column_name=>'LOCALVORSCHRIFTNUMMER'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Localvorschriftnummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839628819112013624)
,p_db_column_name=>'LOCALLANDNAME'
,p_display_order=>30
,p_column_identifier=>'E'
,p_column_label=>'Locallandname'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(577848824092932451)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2617981'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LOCALVORSCHRIFTNUMMER:LOCALLANDNAME:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(577846929691924854)
,p_plug_name=>'Vorschrift-Antriebsart'
,p_parent_plug_id=>wwv_flow_imp.id(578071633901754532)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    --tv.REGINDEXID AS LocalRegindexID,',
'    --vga.V_ID AS GetexVID,',
'    tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'    --tvra.VORSCHRIFTID AS LocalVorschriftID,',
'    --tvra.ANTRIEBSARTID AS LocalAntriebsartID,',
'    ta.BEZEICHNUNG AS LocalAntriebsartBezeichnung',
'    --vga.ANTRIEBSART AS GetexAntriebsartBezeichnung',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_ANTRIEBSART tvra ON tv.VORSCHRIFTID = tvra.VORSCHRIFTID',
'INNER JOIN',
'    T_ANTRIEBSART ta ON tvra.ANTRIEBSARTID = ta.ANTRIEBSARTID',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_ANTRIEBSART vga ON tv.REGINDEXID = vga.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'    AND (',
'        tvra.ANTRIEBSARTID != vga.REGINDEX_ANTRIEBSARTID',
'        --OR ta.BEZEICHNUNG != vga.ANTRIEBSART',
'    );',
'',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_VORSCHRIFTID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Vorschrift-Antriebsart'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(577846783719924853)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>534846153375209551
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839634193096013631)
,p_db_column_name=>'LOCALVORSCHRIFTNUMMER'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Localvorschriftnummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839633785228013631)
,p_db_column_name=>'LOCALANTRIEBSARTBEZEICHNUNG'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>'Localantriebsartbezeichnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(577836591685890155)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2618103'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LOCALVORSCHRIFTNUMMER'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(577843654759924822)
,p_plug_name=>'Vorschrift-Fahrzeugklasse'
,p_parent_plug_id=>wwv_flow_imp.id(578071633901754532)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>80
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    --tv.REGINDEXID AS LocalRegindexID,',
'    --vgfz.V_ID AS GetexVID,',
'    tv.VORSCHRIFT_NUMMER AS LocalVorschriftNummer,',
'    --tvrfz.VORSCHRIFTID AS LocalVorschriftID,',
'    --tvrfz.FAHRZEUGKLASSEID AS LocalFahrzeugklasseID,',
'    tfz.BEZEICHNUNG AS LocalFahrzeugklasseBezeichnung',
'    --vgfz.FAHRZEUG_TYP AS GetexFahrzeugklasseTyp',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    T_VORSCHRIFT_REF_FAHRZEUGKLASSE tvrfz ON tv.VORSCHRIFTID = tvrfz.VORSCHRIFTID',
'INNER JOIN',
'    T_FAHRZEUGKLASSE tfz ON tvrfz.FAHRZEUGKLASSEID = tfz.FAHRZEUGKLASSEID',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_FZ_TYP vgfz ON tv.REGINDEXID = vgfz.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'    AND (',
'        tvrfz.FAHRZEUGKLASSEID != vgfz.FAHRZEUGKLASSEID',
'        --OR tfz.BEZEICHNUNG != vgfz.FAHRZEUG_TYP',
'    );',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_VORSCHRIFTID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Vorschrift-Fahrzeugklasse'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(577843590426924821)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>534849346668209583
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839630620451013626)
,p_db_column_name=>'LOCALVORSCHRIFTNUMMER'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Localvorschriftnummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(839630148507013626)
,p_db_column_name=>'LOCALFAHRZEUGKLASSEBEZEICHNUNG'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>'Localfahrzeugklassebezeichnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(577811313226728000)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2618356'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LOCALVORSCHRIFTNUMMER:LOCALFAHRZEUGKLASSEBEZEICHNUNG'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(568013873166653351)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(839620641978013609)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(568013873166653351)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(839620289614013604)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(568013873166653351)
,p_button_name=>'Save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(839590080639013530)
,p_branch_name=>'Go to Page 25'
,p_branch_action=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::P25_VORSCHRIFTID:&P3_VORSCHRIFTID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(839646268707013718)
,p_name=>'P3_VORSCHRIFTID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(578073432301754550)
,p_prompt=>'Vorschriftid'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(839645878880013708)
,p_name=>'P3_VORSCHRIFTNUMMER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(578073432301754550)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Vorschriftnummer'
,p_source=>'select VORSCHRIFT_NUMMER from t_vorschrift where VORSCHRIFTID=:P3_VORSCHRIFTID;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(839645520774013707)
,p_name=>'P3_LIST'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(578073432301754550)
,p_use_cache_before_default=>'NO'
,p_item_default=>'Alle'
,p_prompt=>'Liste'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Getex;Getex,Vorschrift;Vorschrift,Alle;Alle'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(839606388799013542)
,p_name=>'Getex Show/hide'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_LIST'
,p_condition_element=>'P3_LIST'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Getex'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839604361696013541)
,p_event_id=>wwv_flow_imp.id(839606388799013542)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(577844361903924829)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839602858444013540)
,p_event_id=>wwv_flow_imp.id(839606388799013542)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(586047552919901914)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839604854221013541)
,p_event_id=>wwv_flow_imp.id(839606388799013542)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(577847344478924859)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839603888146013540)
,p_event_id=>wwv_flow_imp.id(839606388799013542)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(578071412694754529)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839605430617013541)
,p_event_id=>wwv_flow_imp.id(839606388799013542)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(578071412694754529)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839602410338013540)
,p_event_id=>wwv_flow_imp.id(839606388799013542)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(577847344478924859)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839605884535013542)
,p_event_id=>wwv_flow_imp.id(839606388799013542)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(586047552919901914)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839603416984013540)
,p_event_id=>wwv_flow_imp.id(839606388799013542)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(577844361903924829)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(839600633536013539)
,p_name=>'Getex Show/hide_1'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_LIST'
,p_condition_element=>'P3_LIST'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Getex'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839599669227013539)
,p_event_id=>wwv_flow_imp.id(839600633536013539)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(578071830032754533)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839600128135013539)
,p_event_id=>wwv_flow_imp.id(839600633536013539)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(578071633901754532)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(839601993753013540)
,p_name=>'All Show/hide_1_1'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_LIST'
,p_condition_element=>'P3_LIST'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Alle'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839601525467013539)
,p_event_id=>wwv_flow_imp.id(839601993753013540)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(578071830032754533)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839601014109013539)
,p_event_id=>wwv_flow_imp.id(839601993753013540)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(578071633901754532)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(839595470468013535)
,p_name=>'Vorschrift Show/hide_1'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_LIST'
,p_condition_element=>'P3_LIST'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Getex'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839594938475013534)
,p_event_id=>wwv_flow_imp.id(839595470468013535)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(586047552919901914)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839594492291013534)
,p_event_id=>wwv_flow_imp.id(839595470468013535)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(577844361903924829)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839594018937013534)
,p_event_id=>wwv_flow_imp.id(839595470468013535)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(578071412694754529)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839593460276013533)
,p_event_id=>wwv_flow_imp.id(839595470468013535)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(577847344478924859)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839593005936013533)
,p_event_id=>wwv_flow_imp.id(839595470468013535)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(577847344478924859)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839592442824013533)
,p_event_id=>wwv_flow_imp.id(839595470468013535)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(578071412694754529)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839592003479013533)
,p_event_id=>wwv_flow_imp.id(839595470468013535)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(577844361903924829)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839591440754013532)
,p_event_id=>wwv_flow_imp.id(839595470468013535)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(586047552919901914)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(839599270192013538)
,p_name=>'Vorschrift Show/hide_1_1'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_LIST'
,p_condition_element=>'P3_LIST'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Vorschrift'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839598811593013538)
,p_event_id=>wwv_flow_imp.id(839599270192013538)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(578071633901754532)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839598305503013538)
,p_event_id=>wwv_flow_imp.id(839599270192013538)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(578071830032754533)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(839608744976013544)
,p_name=>'Vorschrift Show/hide'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_LIST'
,p_condition_element=>'P3_LIST'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Vorschrift'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839608251190013543)
,p_event_id=>wwv_flow_imp.id(839608744976013544)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(578071412694754529)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839607754059013543)
,p_event_id=>wwv_flow_imp.id(839608744976013544)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(578070092084754516)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839607255733013542)
,p_event_id=>wwv_flow_imp.id(839608744976013544)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(578070092084754516)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839606767912013542)
,p_event_id=>wwv_flow_imp.id(839608744976013544)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(578071412694754529)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(839615858505013556)
,p_name=>'Antriebsart Show/hide'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_LIST'
,p_condition_element=>'P3_LIST'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Antriebsart'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839615421849013551)
,p_event_id=>wwv_flow_imp.id(839615858505013556)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(577847344478924859)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839614901408013550)
,p_event_id=>wwv_flow_imp.id(839615858505013556)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(577846929691924854)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839614389757013550)
,p_event_id=>wwv_flow_imp.id(839615858505013556)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(577846929691924854)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839613904375013549)
,p_event_id=>wwv_flow_imp.id(839615858505013556)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(577847344478924859)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(839597854987013536)
,p_name=>'Fahrzeugklasse Show/hide'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_LIST'
,p_condition_element=>'P3_LIST'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Fahrzeugklasse'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839597424770013536)
,p_event_id=>wwv_flow_imp.id(839597854987013536)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(577844361903924829)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839596842148013535)
,p_event_id=>wwv_flow_imp.id(839597854987013536)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(577843654759924822)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839596431063013535)
,p_event_id=>wwv_flow_imp.id(839597854987013536)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(577843654759924822)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839595850832013535)
,p_event_id=>wwv_flow_imp.id(839597854987013536)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(577844361903924829)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(839611152489013546)
,p_name=>'Refresh List'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_LIST'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839609236285013544)
,p_event_id=>wwv_flow_imp.id(839611152489013546)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(576828346851066011)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839610202030013545)
,p_event_id=>wwv_flow_imp.id(839611152489013546)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(576724923292847536)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839610665742013545)
,p_event_id=>wwv_flow_imp.id(839611152489013546)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(576722241131847510)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839609734349013544)
,p_event_id=>wwv_flow_imp.id(839611152489013546)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(575835837837244544)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(839591127336013532)
,p_name=>'Checkbox'
,p_event_sequence=>110
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectUnselectAll'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839590634125013532)
,p_event_id=>wwv_flow_imp.id(839591127336013532)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ( $( ''#selectUnselectAll'' ).is('':checked'') ) {',
'                  $(''input[type=checkbox][name=f01]'').attr(''checked'',true);',
'                        }',
'                  else {',
'                  $(''input[type=checkbox][name=f01]'').attr(''checked'',false);    ',
'                        }'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(839613506239013549)
,p_name=>'Save Button Show/Hide'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_LIST'
,p_condition_element=>'P3_LIST'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Alle'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839613034214013548)
,p_event_id=>wwv_flow_imp.id(839613506239013549)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(839620289614013604)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839612441826013548)
,p_event_id=>wwv_flow_imp.id(839613506239013549)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(839620289614013604)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(839612136685013547)
,p_name=>'Cancel Dialog'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(839620641978013609)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(839611617174013546)
,p_event_id=>wwv_flow_imp.id(839612136685013547)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(839619935535013564)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Thema_Insert'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_count number;',
'begin',
'FOR I in (select tv.VORSCHRIFTID,',
'                 vgt.REGINDEX_THEMAID',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'   AND tv.VORSCHRIFTID =:P3_VORSCHRIFTID',
'   and vgt.REGINDEX_THEMAID not in (select tvrtl.THEMAID from T_VORSCHRIFT_REF_THEMA tvrtl where tvrtl.VORSCHRIFTID = tv.VORSCHRIFTID',
'                                     and tvrtl.geloescht = 0 and tvrtl.VORSCHRIFTID=:P3_VORSCHRIFTID)',
')',
'LOOP ',
'begin',
'select count(*) into l_count ',
'from T_VORSCHRIFT_REF_THEMA where VORSCHRIFTID =:P3_VORSCHRIFTID and THEMAID=i.REGINDEX_THEMAID;',
'exception when no_data_found then l_count:=0;',
'end;',
'',
'if l_count =0 then ',
'insert into T_VORSCHRIFT_REF_THEMA',
'(',
'    VORSCHRIFTID,',
'    THEMAID,',
'    GELOESCHT,',
'    LETZTE_AENDERUNG_DATUM,',
'    LETZTE_AENDERUNG_BENUTZERID',
'',
')',
'values( ',
' :P3_VORSCHRIFTID,',
' i.REGINDEX_THEMAID,',
' 0,',
' sysdate,',
' PCK_RI.fGetUserId',
'',
'',
');',
'else',
'UPDATE T_VORSCHRIFT_REF_THEMA SET geloescht = 0  where VORSCHRIFTID =:P3_VORSCHRIFTID and THEMAID=i.REGINDEX_THEMAID;',
'end if;',
'end loop;',
'UPDATE T_VORSCHRIFT_REF_THEMA SET geloescht = 1 WHERE VORSCHRIFT_REF_THEMAID IN (SELECT VORSCHRIFT_REF_THEMAID ',
'FROM',
'    T_VORSCHRIFT_REF_THEMA tvrt',
'INNER JOIN',
'    T_VORSCHRIFT tv ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'   AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'    AND (tvrt.THEMAID, tv.VORSCHRIFTID) NOT IN (SELECT REGINDEX_THEMAID, tva.VORSCHRIFTID FROM V_GETEX_VORSCHRIFT_THEMA vgtl ',
'                                                 INNER JOIN T_VORSCHRIFT tva ON tva.REGINDEXID = vgtl.V_ID ',
'                                                 AND tva.VORSCHRIFTID = :P3_VORSCHRIFTID)',
');',
'',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(839620289614013604)
,p_internal_uid=>2832592380364374671
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from T_VORSCHRIFT_REF_THEMA where VORSCHRIFT_REF_THEMAID  in (select VORSCHRIFT_REF_THEMAID ',
'FROM',
'   T_VORSCHRIFT_REF_THEMA tvrt',
'INNER JOIN',
'    T_VORSCHRIFT tv  ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'full OUTER JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'  AND tv.VORSCHRIFTID = :P29_VORSCHRIFTID',
' and (tvrt.THEMAID,tv.VORSCHRIFTID) not in (select REGINDEX_THEMAID,tva.VORSCHRIFTID from V_GETEX_VORSCHRIFT_THEMA vgtl inner join T_VORSCHRIFT tva ON tva.REGINDEXID = vgtl.V_ID )',
');'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(839617125815013558)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Fahrzeugklasse_Insert'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_count number;',
'begin',
'FOR I in (select tv.VORSCHRIFTID,',
'                 vgfz.FAHRZEUGKLASSEID',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    V_GETEX_VORSCHRIFT_FZ_TYP vgfz ON tv.REGINDEXID = vgfz.V_ID',
'WHERE tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'   and vgfz.FAHRZEUGKLASSEID not in (select tvrfzz.FAHRZEUGKLASSEID from T_VORSCHRIFT_REF_FAHRZEUGKLASSE tvrfzz where tvrfzz.VORSCHRIFTID = tv.VORSCHRIFTID ',
'                                        and tvrfzz.VORSCHRIFTID = :P3_VORSCHRIFTID) ',
')',
'LOOP ',
'begin',
'select count(*) into l_count ',
'from T_VORSCHRIFT_REF_FAHRZEUGKLASSE where VORSCHRIFTID =:P3_VORSCHRIFTID and FAHRZEUGKLASSEID=i.FAHRZEUGKLASSEID;',
'exception when no_data_found then l_count:=0;',
'end;',
'',
'if l_count =0 then ',
'insert into T_VORSCHRIFT_REF_FAHRZEUGKLASSE',
'(',
'    VORSCHRIFTID,',
'    FAHRZEUGKLASSEID,',
'    LETZTE_AENDERUNG_DATUM,',
'    LETZTE_AENDERUNG_BENUTZERID',
'',
')',
'values( ',
'    :P3_VORSCHRIFTID,',
'    i.FAHRZEUGKLASSEID,',
'    sysdate,',
'    PCK_RI.fGetUserId',
'',
'',
');',
'end if;',
'end loop;',
'DELETE from T_VORSCHRIFT_REF_FAHRZEUGKLASSE where VORSCHRIFT_REF_FAHRZEUGKLASSEID  in (select VORSCHRIFT_REF_FAHRZEUGKLASSEID ',
'FROM',
'   T_VORSCHRIFT_REF_FAHRZEUGKLASSE tvrfz',
'INNER JOIN',
'    T_VORSCHRIFT tv  ON (tv.VORSCHRIFTID = tvrfz.VORSCHRIFTID)',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_FZ_TYP vgfz ON tv.REGINDEXID = vgfz.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'  AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'  AND (tvrfz.FAHRZEUGKLASSEID, tv.VORSCHRIFTID) NOT IN (SELECT FAHRZEUGKLASSEID, tva.VORSCHRIFTID FROM V_GETEX_VORSCHRIFT_FZ_TYP vgfzz INNER JOIN T_VORSCHRIFT tva ON tva.REGINDEXID = vgfzz.V_ID)',
');',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(839620289614013604)
,p_internal_uid=>2832595190084374677
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(839617858243013559)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Antriebsart_Insert'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_count number;',
'begin',
'FOR I in (select tv.VORSCHRIFTID,',
'                 vga.REGINDEX_ANTRIEBSARTID',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    V_GETEX_VORSCHRIFT_ANTRIEBSART vga ON tv.REGINDEXID = vga.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'   AND tv.VORSCHRIFTID =:P3_VORSCHRIFTID',
'   and vga.REGINDEX_ANTRIEBSARTID not in (select tvraa.ANTRIEBSARTID from T_VORSCHRIFT_REF_ANTRIEBSART tvraa where tvraa.VORSCHRIFTID = tv.VORSCHRIFTID ',
'                                            and tvraa.geloescht = 0 and tvraa.VORSCHRIFTID=:P3_VORSCHRIFTID)',
')',
'LOOP ',
'begin',
'select count(*) into l_count ',
'from T_VORSCHRIFT_REF_ANTRIEBSART where VORSCHRIFTID =:P3_VORSCHRIFTID and ANTRIEBSARTID=i.REGINDEX_ANTRIEBSARTID;',
'exception when no_data_found then l_count:=0;',
'end;',
'',
'if l_count =0 then ',
'insert into T_VORSCHRIFT_REF_ANTRIEBSART',
'(',
'    VORSCHRIFTID,',
'    ANTRIEBSARTID,',
'    GELOESCHT,',
'    LETZTE_AENDERUNG_DATUM,',
'    LETZTE_AENDERUNG_BENUTZERID',
'',
')',
'values( ',
'    :P3_VORSCHRIFTID,',
'    i.REGINDEX_ANTRIEBSARTID,',
'    0,',
'    sysdate,',
'    PCK_RI.fGetUserId',
'',
'',
');',
'else',
'UPDATE T_VORSCHRIFT_REF_ANTRIEBSART SET geloescht = 0  where VORSCHRIFTID =:P3_VORSCHRIFTID and ANTRIEBSARTID=i.REGINDEX_ANTRIEBSARTID;',
'end if;',
'end loop;',
'UPDATE T_VORSCHRIFT_REF_ANTRIEBSART SET geloescht = 1 WHERE VORSCHRIFT_REF_ANTRIEBSARTID IN (SELECT VORSCHRIFT_REF_ANTRIEBSARTID ',
'FROM',
'    T_VORSCHRIFT_REF_ANTRIEBSART tvra',
'INNER JOIN',
'    T_VORSCHRIFT tv ON (tv.VORSCHRIFTID = tvra.VORSCHRIFTID and tvra.geloescht = 0)',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'    AND (tvra.ANTRIEBSARTID, tv.VORSCHRIFTID) NOT IN (SELECT REGINDEX_ANTRIEBSARTID, tva.VORSCHRIFTID FROM V_GETEX_VORSCHRIFT_ANTRIEBSART vgaa ',
'                                                       INNER JOIN T_VORSCHRIFT tva ON tva.REGINDEXID = vgaa.V_ID ',
'                                                       AND tva.VORSCHRIFTID = :P3_VORSCHRIFTID)',
');',
'end;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(839620289614013604)
,p_internal_uid=>2832594457656374676
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(839618697021013561)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Land_Insert'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_count number;',
'begin',
'FOR I in (select tv.VORSCHRIFTID,',
'                 vgl.REGINDEX_LANDID',
'FROM',
'    T_VORSCHRIFT tv',
'INNER JOIN',
'    V_GETEX_VORSCHRIFT_LAND vgl ON tv.REGINDEXID = vgl.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'   and vgl.REGINDEX_LANDID not in (select tvrll.LANDID from T_VORSCHRIFT_REF_LAND tvrll where tvrll.VORSCHRIFTID = tv.VORSCHRIFTID',
'                                    and tvrll.geloescht = 0 and tvrll.VORSCHRIFTID=:P3_VORSCHRIFTID )',
')',
'LOOP ',
'begin',
'select count(*) into l_count ',
'from T_VORSCHRIFT_REF_LAND where VORSCHRIFTID =:P3_VORSCHRIFTID and LANDID =i.REGINDEX_LANDID;',
'exception when no_data_found then l_count:=0;',
'end;',
'',
'if l_count =0 then ',
'insert into T_VORSCHRIFT_REF_LAND',
'(',
'    VORSCHRIFTID,',
'    LANDID,',
'    GELOESCHT,',
'    LETZTE_AENDERUNG_DATUM,',
'    LETZTE_AENDERUNG_BENUTZERID',
'',
')',
'values( ',
'    :P3_VORSCHRIFTID,',
'    i.REGINDEX_LANDID,',
'    0,',
'    sysdate,',
'    PCK_RI.fGetUserId',
'',
'',
');',
'else',
'UPDATE T_VORSCHRIFT_REF_LAND SET geloescht = 0  where VORSCHRIFTID =:P3_VORSCHRIFTID and LANDID=i.REGINDEX_LANDID;',
'end if;',
'end loop;',
'UPDATE T_VORSCHRIFT_REF_LAND SET geloescht = 1 WHERE VORSCHRIFT_REF_LANDID IN (SELECT VORSCHRIFT_REF_LANDID ',
'FROM',
'    T_VORSCHRIFT_REF_LAND tvrl',
'INNER JOIN',
'    T_VORSCHRIFT tv ON (tv.VORSCHRIFTID = tvrl.VORSCHRIFTID and tvrl.geloescht = 0)',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'    AND (tvrl.LANDID, tv.VORSCHRIFTID) NOT IN (SELECT REGINDEX_LANDID, tva.VORSCHRIFTID FROM V_GETEX_VORSCHRIFT_LAND vgll ',
'                                               INNER JOIN T_VORSCHRIFT tva ON tva.REGINDEXID = vgll.V_ID AND tva.VORSCHRIFTID = :P3_VORSCHRIFTID)',
');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(839620289614013604)
,p_internal_uid=>2832593618878374674
,p_process_comment=>'PCK_RI.fGetUserId'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(839619496814013561)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Thema_Delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from T_VORSCHRIFT_REF_THEMA where VORSCHRIFT_REF_THEMAID  in (select VORSCHRIFT_REF_THEMAID ',
'FROM',
'   T_VORSCHRIFT_REF_THEMA tvrt',
'INNER JOIN',
'    T_VORSCHRIFT tv  ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'full OUTER JOIN',
'    V_GETEX_VORSCHRIFT_THEMA vgt ON tv.REGINDEXID = vgt.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'  AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
' and (tvrt.THEMAID,tv.VORSCHRIFTID) not in (select REGINDEX_THEMAID,tva.VORSCHRIFTID from V_GETEX_VORSCHRIFT_THEMA vgtl inner join T_VORSCHRIFT tva ON tva.REGINDEXID = vgtl.V_ID )',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2832592819085374674
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(839619101090013561)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Thema_Update_Geloescht'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE T_VORSCHRIFT_REF_THEMA SET geloescht = 1 WHERE VORSCHRIFT_REF_THEMAID IN (SELECT VORSCHRIFT_REF_THEMAID ',
'FROM',
'    T_VORSCHRIFT_REF_THEMA tvrt',
'INNER JOIN',
'    T_VORSCHRIFT tv ON (tv.VORSCHRIFTID = tvrt.VORSCHRIFTID and tvrt.geloescht = 0)',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'   AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'    AND (tvrt.THEMAID, tv.VORSCHRIFTID) NOT IN (SELECT REGINDEX_THEMAID, tva.VORSCHRIFTID FROM V_GETEX_VORSCHRIFT_THEMA vgtl ',
'                                                 INNER JOIN T_VORSCHRIFT tva ON tva.REGINDEXID = vgtl.V_ID ',
'                                                 AND tva.VORSCHRIFTID = :P3_VORSCHRIFTID)',
');',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2832593214809374674
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(839616656948013557)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Fahrzeugklasse_Delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DELETE from T_VORSCHRIFT_REF_FAHRZEUGKLASSE where VORSCHRIFT_REF_FAHRZEUGKLASSEID  in (select VORSCHRIFT_REF_FAHRZEUGKLASSEID ',
'FROM',
'   T_VORSCHRIFT_REF_FAHRZEUGKLASSE tvrfz',
'INNER JOIN',
'    T_VORSCHRIFT tv  ON (tv.VORSCHRIFTID = tvrfz.VORSCHRIFTID)',
'FULL OUTER JOIN',
'    V_GETEX_VORSCHRIFT_FZ_TYP vgfz ON tv.REGINDEXID = vgfz.V_ID',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'  AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'  AND (tvrfz.FAHRZEUGKLASSEID, tv.VORSCHRIFTID) NOT IN (SELECT FAHRZEUGKLASSEID, tva.VORSCHRIFTID FROM V_GETEX_VORSCHRIFT_FZ_TYP vgfzz INNER JOIN T_VORSCHRIFT tva ON tva.REGINDEXID = vgfzz.V_ID)',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2832595658951374678
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(839617500963013558)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Antriebsart_Update_Geloescht'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE T_VORSCHRIFT_REF_ANTRIEBSART SET geloescht = 1 WHERE VORSCHRIFT_REF_ANTRIEBSARTID IN (SELECT VORSCHRIFT_REF_ANTRIEBSARTID ',
'FROM',
'    T_VORSCHRIFT_REF_ANTRIEBSART tvra',
'INNER JOIN',
'    T_VORSCHRIFT tv ON (tv.VORSCHRIFTID = tvra.VORSCHRIFTID and tvra.geloescht = 0)',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'    AND (tvra.ANTRIEBSARTID, tv.VORSCHRIFTID) NOT IN (SELECT REGINDEX_ANTRIEBSARTID, tva.VORSCHRIFTID FROM V_GETEX_VORSCHRIFT_ANTRIEBSART vgaa ',
'                                                       INNER JOIN T_VORSCHRIFT tva ON tva.REGINDEXID = vgaa.V_ID ',
'                                                       AND tva.VORSCHRIFTID = :P3_VORSCHRIFTID)',
');',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2832594814936374677
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(839618239261013559)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Land_Update_Geloescht'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE T_VORSCHRIFT_REF_LAND SET geloescht = 1 WHERE VORSCHRIFT_REF_LANDID IN (SELECT VORSCHRIFT_REF_LANDID ',
'FROM',
'    T_VORSCHRIFT_REF_LAND tvrl',
'INNER JOIN',
'    T_VORSCHRIFT tv ON (tv.VORSCHRIFTID = tvrl.VORSCHRIFTID and tvrl.geloescht = 0)',
'WHERE',
'    tv.REGINDEXID IS NOT NULL',
'    AND tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'    AND (tvrl.LANDID, tv.VORSCHRIFTID) NOT IN (SELECT REGINDEX_LANDID, tva.VORSCHRIFTID FROM V_GETEX_VORSCHRIFT_LAND vgll ',
'                                               INNER JOIN T_VORSCHRIFT tva ON tva.REGINDEXID = vgll.V_ID ',
'                                               AND tva.VORSCHRIFTID = :P3_VORSCHRIFTID)',
');',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2832594076638374676
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(839616320994013557)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update GETEX_IMPORT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_count number;',
'begin',
'UPDATE T_X_GETEX_IMPORT tgxi',
'    SET tgxi.STATUS = 2',
'    WHERE tgxi.GETEX_SCHLUESSEL = (',
'        SELECT tv.REGINDEXID',
'        FROM t_vorschrift tv',
'        WHERE tv.VORSCHRIFTID = :P3_VORSCHRIFTID',
'    );',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(839620289614013604)
,p_internal_uid=>2832595994905374678
);
wwv_flow_imp.component_end;
end;
/
