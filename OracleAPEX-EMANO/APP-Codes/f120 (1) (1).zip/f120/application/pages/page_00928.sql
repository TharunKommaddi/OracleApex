prompt --application/pages/page_00928
begin
--   Manifest
--     PAGE: 00928
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>928
,p_name=>unistr('Audits bearbeiten/hinzuf\00FCgen')
,p_alias=>unistr('AUDITS-BEARBEITEN-HINZUF\00DCGEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Audits bearbeiten/hinzuf\00FCgen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>unistr('var htmldb_delete_message=''"M\00F6chten Sie das Audit l\00F6schen?"'';')
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5306276781438169541)
,p_plug_name=>'Audit'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5306277531619169541)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(443528155490250850)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(5306277531619169541)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(443527424548250846)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5306277531619169541)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P928_AUDITID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(443527769811250848)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(5306277531619169541)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Speichern & Schlie\00DFen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(447280845789940476)
,p_name=>'P928_AUDITID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(5306276781438169541)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(447280684101940474)
,p_name=>'P928_DATUM_AUDIT'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(5306276781438169541)
,p_prompt=>'Datum des Audits'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(447280573306940473)
,p_name=>'P928_STATUS_AUDIT'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(5306276781438169541)
,p_prompt=>'Status Audit'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''geplant'', ''planned'') AS display_value, ',
'        10 AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''durchgef\00FChrt'', ''conducted'') AS display_value,'),
'        20 AS return_value,',
'        2 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(447280492499940472)
,p_name=>'P928_AUDITTYP'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(5306276781438169541)
,p_prompt=>'Audit'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung',
'        ELSE name_eng',
'    END AS d, ',
'    audit_typid AS r  ',
'FROM t_audit_typ',
'ORDER BY 1;',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(443530886981250865)
,p_name=>'P928_IMPORTEURID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(5306276781438169541)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(443530117295250857)
,p_name=>'P928_IMPORTEUR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(5306276781438169541)
,p_prompt=>'Importeur'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401857827153284885)
,p_name=>'P928_LEVEL_ERREICHT'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(5306276781438169541)
,p_prompt=>'Level erreicht'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>3
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'max_value', '100',
  'min_value', '0',
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401857720935284884)
,p_name=>'P928_ERGEBNIS_AUDIT'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(5306276781438169541)
,p_prompt=>'Ergebnis'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    return_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''nicht bestanden'', ''not passed'') AS display_value, ',
'        10 AS return_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''bestanden'', ''passed'') AS display_value,',
'        20 AS return_value,',
'        2 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(429932628677891591)
,p_name=>'Cancel Dialog'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(443528155490250850)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(429932507883891590)
,p_event_id=>wwv_flow_imp.id(429932628677891591)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(443524735878250814)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P928_AUDITID is null then',
'    insert into t_audit (importeurid, audit_typid, datum_audit, status_audit, LETZTE_AENDERUNG_DATUM, LETZTE_AENDERUNG_BENUTZER_ID, ergebnis_audit, level_erreicht)',
'    values (:P928_IMPORTEURID, :P928_AUDITTYP, :P928_DATUM_AUDIT, :P928_STATUS_AUDIT, sysdate, PCK_RI.fGetUserId, :P928_ERGEBNIS_AUDIT, :P928_LEVEL_ERREICHT);',
'else',
'    update t_audit',
'    set audit_typid = :P928_AUDITTYP,',
'    datum_audit = :P928_DATUM_AUDIT,',
'    status_audit = :P928_STATUS_AUDIT,',
'    LETZTE_AENDERUNG_DATUM = sysdate,',
'    LETZTE_AENDERUNG_BENUTZER_ID = PCK_RI.fGetUserId,',
'    ergebnis_audit = :P928_ERGEBNIS_AUDIT,',
'    level_erreicht = :P928_LEVEL_ERREICHT',
'    where auditid = :P928_AUDITID;',
'end if;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(443527769811250848)
,p_process_success_message=>'Die Daten wurden gespeichert.'
,p_internal_uid=>3228687580021137421
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(443525502748250815)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from t_audit',
'where auditid = :P928_AUDITID;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(443527424548250846)
,p_internal_uid=>3228686813151137420
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(443524308982250813)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3228688006917137422
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(443525111139250814)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Initialize form Audit bearbeiten/hinzuf\00FCgen')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P928_AUDITID is not null then',
'    select a.importeurid, i.bezeichnung, audit_typid, datum_audit, status_audit, ergebnis_audit, level_erreicht',
'    into :P928_IMPORTEURID, :P928_IMPORTEUR, :P928_AUDITTYP, :P928_DATUM_AUDIT, :P928_STATUS_AUDIT, :P928_ERGEBNIS_AUDIT, :P928_LEVEL_ERREICHT',
'    from t_audit a',
'    join t_importeur i on i.importeurid = a.importeurid',
'    where auditid = :P928_AUDITID;',
'else',
'    select bezeichnung',
'    into :P928_IMPORTEUR',
'    from t_importeur',
'    where importeurid = :P928_IMPORTEURID;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>3228687204760137421
);
wwv_flow_imp.component_end;
end;
/
