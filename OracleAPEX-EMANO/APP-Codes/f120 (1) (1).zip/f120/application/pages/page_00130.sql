prompt --application/pages/page_00130
begin
--   Manifest
--     PAGE: 00130
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>130
,p_name=>unistr('L\00E4nder')
,p_step_title=>unistr('L\00E4nder')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// const $container = $(''<div>'').css({''display'':''flex'',''align-items'':''center'',''margin-right'':''10px''});',
'// $(''#P130_EINSATZTERMIN_COLUMNS_LABEL'').detach().appendTo($container).css({''margin-right'':''5px'',''white-space'':''nowrap''});',
'// $(''#P130_EINSATZTERMIN_COLUMNS'').detach().appendTo($container);',
'// $(''#IR1 div.a-IRR-buttons'').prepend($container);',
'// $(''#P130_EINSATZTERMIN_COLUMNS_CONTAINER'').closest(''div.row'').remove();',
'// $(''#IR1 div.a-IRR-buttons'').css({''display'':''flex'',''align-items'':''center''});',
'',
'',
'$(''#IR1_toolbar'').css({',
'    ''display'': ''flex'',',
'    ''align-items'': ''center'',',
'    ''justify-content'': ''flex-start'',',
'    ''gap'': ''10px''',
'});',
'',
'$(''#P130_EINSATZTERMIN_COLUMNS_CONTAINER'').appendTo(''#IR1_toolbar'').css({',
'    ''display'': ''inline-flex'',',
'    ''align-items'': ''center'',',
'    ''white-space'': ''nowrap'',',
'    ''order'': ''2'',',
'    ''gap'': ''10px'',',
'    ''margin-left'': ''auto''',
'});',
'',
'$(''#P130_EINSATZTERMIN_COLUMNS_CONTAINER .col'').css({',
'    ''padding'': ''0'',',
'    ''margin'': ''0'',',
'    ''width'': ''auto''',
'});',
'',
'$(''.a-IRR-buttons'').css({',
'    ''margin-left'': ''10px'',',
'    ''order'': ''3''',
'});',
'',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2663061119836110366)
,p_plug_name=>unistr('Report L\00E4nder')
,p_region_name=>'IR1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_rre_vko as (',
'    select l.landid, listagg(distinct nachname || '', '' || vorname || '' ('' || abteilung || '')'','', '' on overflow truncate) within group (order by nachname) liste',
'    from t_land l',
'    join t_benutzer_ref_land brl on (l.landid = brl.landid)',
'    join t_benutzer_ref_rolle brr on (brr.benutzerid = brl.benutzerid)',
'    join t_benutzer b on (brr.benutzerid = b.benutzerid)',
'    where brr.rolleid in (1050,1000) -- RRE und VKO',
'    group by l.landid',
'), cte_importeure as (',
'    select irl.landid, listagg(''<a href="'' || apex_page.get_url(p_page => 925, p_items => ''P925_IMPORTEURID'', p_values => i.importeurid) || ''">'' || i.bezeichnung || ''</a>'', '', '' on overflow truncate) within group (order by i.bezeichnung) as liste',
'    from t_importeur_ref_land irl',
'    join t_importeur i on (irl.importeurid = i.importeurid and i.is_deleted = 0)',
'    group by irl.landid     ',
')',
'',
'select l."ROWID", ',
'l."LANDID",',
'"B_NUMMER",',
'CASE ',
'    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l."LAND"',
'    ELSE l."LAND_ENG" ',
'END AS Land,',
'typschild,',
'case betaflag when 1 then ''Ja'' else null end betaflag,',
'nvl2(FLAGGE, apex_page.get_url(p_page => 0, p_items => ''G_LANDID'', p_values => l.landid, p_request => ''APPLICATION_PROCESS=getFlag''), null) AS FLAGGE_URL,',
'-- em.modell as "EINSATZDATUM_MODELLID_German",',
'-- em.modell_eng as "EINSATZDATUM_MODELLID_English",',
'CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN em.modell ELSE em.modell_eng END as "EINSATZDATUM_MODELLID",',
'',
'"STARTDATUM_TYP",',
'l.ISO_CODE_2, ',
'l.ISO_CODE_3, ',
'l.ISO_ENGLISCH,',
'CASE ',
'    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l."KONTINENT"',
'    ELSE l."CONTINENT_ENG" ',
'END KONTINENT,',
'-- l.KONTINENT,',
'-- l.CONTINENT_ENG,',
'l.STATUS_DATENSTAND,',
'i.liste as liste_importeure,',
'rv.liste as liste_rri_vko,',
'-- regexp_replace(apex_escape.html(l.BESONDERHEITEN), '''' || chr(10) || ''?'' || chr(13), ''<br />'') AS "BESONDERHEITEN",',
'-- l.BESONDERHEITENMARKT_ENGLISCH,',
'CASE ',
'    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ',
'        regexp_replace(apex_escape.html(l.BESONDERHEITEN), '''' || chr(10) || ''?'' || chr(13), ''<br />'')',
'    ELSE ',
'        regexp_replace(apex_escape.html(l.BESONDERHEITENMARKT_ENGLISCH), '''' || chr(10) || ''?'' || chr(13), ''<br />'')',
'END AS "BESONDERHEITEN",',
'',
'l."LETZTE_AENDERUNG_DATUM",',
'nvl2(l.letzte_aenderung_benutzerid, b.nachname || '', '' || b.vorname, null) as "LETZTE_AENDERUNG_BENUTZERID",',
'l.prio,',
'l.BEDEUTUNG_EINSATZTERMIN,',
'l.BEMERKUNG_EINSATZTERMIN,',
'CASE l.SUMS_RELEVANT',
'        WHEN 10 THEN ''ja''',
'        WHEN 20 THEN ''nein''',
'        WHEN 30 THEN ''nicht bewertet''',
'        ',
'',
'    END AS SUMS_RELEVANT',
'from "#OWNER#"."T_LAND" l',
'left outer join t_benutzer b on b.benutzerid = l.LETZTE_AENDERUNG_BENUTZERID',
'left outer join t_einsatzdatum_modell em on em.einsatzdatum_modellid = l.einsatzdatum_modellid',
'left outer join cte_importeure i on (l.landid = i.landid)',
'left outer join cte_rre_vko rv on (l.landid = rv.landid)',
'ORDER BY NLSSORT(l.B_NUMMER, ''NLS_SORT=BINARY_AI'') ASC'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2663061467818110366)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>unistr('Es wurden keine L\00E4nder gefunden.')
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:135:&APP_SESSION.::::P135_ROWID:#ROWID#'
,p_detail_link_text=>'<span class="fa fa-pencil" aria-hidden="true"></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>173714901859838130
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2663061568261110373)
,p_db_column_name=>'ROWID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ROWID'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2663062012442110386)
,p_db_column_name=>'LANDID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Landid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2663062406937110386)
,p_db_column_name=>'B_NUMMER'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'B-Nummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2659998753938113584)
,p_db_column_name=>'FLAGGE_URL'
,p_display_order=>14
,p_column_identifier=>'T'
,p_column_label=>'Flagge'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<img src="#FLAGGE_URL#" height="12px"',
'     title="#B_NUMMER# (#LAND#)" />'))
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2659997062384113567)
,p_db_column_name=>'EINSATZDATUM_MODELLID'
,p_display_order=>24
,p_column_identifier=>'K'
,p_column_label=>'Einsatzdatum Modell'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2663064777525110389)
,p_db_column_name=>'STARTDATUM_TYP'
,p_display_order=>34
,p_column_identifier=>'I'
,p_column_label=>'Art des Startdatums'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(958133272003232078)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2663063625934110389)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>44
,p_column_identifier=>'F'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2659996917259113566)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZERID'
,p_display_order=>54
,p_column_identifier=>'J'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2679000551797443337)
,p_db_column_name=>'TYPSCHILD'
,p_display_order=>64
,p_column_identifier=>'U'
,p_column_label=>'Typschild'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(2660026449262803947)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2679000732834443339)
,p_db_column_name=>'BETAFLAG'
,p_display_order=>74
,p_column_identifier=>'W'
,p_column_label=>'Beta'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(896552827693355368)
,p_db_column_name=>'ISO_CODE_2'
,p_display_order=>84
,p_column_identifier=>'X'
,p_column_label=>'ISO Code 2 stellig'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(896552651217355367)
,p_db_column_name=>'ISO_CODE_3'
,p_display_order=>94
,p_column_identifier=>'Y'
,p_column_label=>'ISO Code 3 stellig'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(896552589743355366)
,p_db_column_name=>'ISO_ENGLISCH'
,p_display_order=>104
,p_column_identifier=>'Z'
,p_column_label=>'Name ISO Englisch'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(896552527945355365)
,p_db_column_name=>'KONTINENT'
,p_display_order=>114
,p_column_identifier=>'AA'
,p_column_label=>'Kontinent'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(896552348438355364)
,p_db_column_name=>'STATUS_DATENSTAND'
,p_display_order=>124
,p_column_identifier=>'AB'
,p_column_label=>'Umsetzungsstatus Datenbestand'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(958143930893466194)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1003882174225808385)
,p_db_column_name=>'BESONDERHEITEN'
,p_display_order=>134
,p_column_identifier=>'AC'
,p_column_label=>'Besonderheiten Markt'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(380765368143058798)
,p_db_column_name=>'LISTE_IMPORTEURE'
,p_display_order=>144
,p_column_identifier=>'AD'
,p_column_label=>'Importeure'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(380765246814058797)
,p_db_column_name=>'LISTE_RRI_VKO'
,p_display_order=>154
,p_column_identifier=>'AE'
,p_column_label=>'RRE / VKO'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(337807334559290265)
,p_db_column_name=>'PRIO'
,p_display_order=>164
,p_column_identifier=>'AF'
,p_column_label=>'Prio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(962881303937665180)
,p_db_column_name=>'LAND'
,p_display_order=>174
,p_column_identifier=>'AH'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1064037374564015305)
,p_db_column_name=>'BEDEUTUNG_EINSATZTERMIN'
,p_display_order=>184
,p_column_identifier=>'AO'
,p_column_label=>unistr('Bedeutung Erf\00FCllungszeitpunkt')
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_static_id=>'BEDEUTUNG'
,p_rpt_show_filter_lov=>'N'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P130_EINSATZTERMIN_COLUMNS = 1'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1064037298428015304)
,p_db_column_name=>'BEMERKUNG_EINSATZTERMIN'
,p_display_order=>194
,p_column_identifier=>'AP'
,p_column_label=>unistr('Bemerkung Erf\00FCllungszeitpunkt')
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_static_id=>'BEMERKUNG'
,p_rpt_show_filter_lov=>'N'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P130_EINSATZTERMIN_COLUMNS = 1'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(641415474960456594)
,p_db_column_name=>'SUMS_RELEVANT'
,p_display_order=>204
,p_column_identifier=>'AL'
,p_column_label=>'Sums Relevant'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2663075530188151509)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1737290'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'B_NUMMER:LAND:FLAGGE_URL:EINSATZDATUM_MODELLID:STARTDATUM_TYP:TYPSCHILD:BETAFLAG:ISO_CODE_2:ISO_CODE_3:ISO_ENGLISCH:KONTINENT:BESONDERHEITEN:STATUS_DATENSTAND:LETZTE_AENDERUNG_DATUM:LETZTE_AENDERUNG_BENUTZERID:LISTE_IMPORTEURE:LISTE_RRI_VKO:PRIO:BEDE'
||'UTUNG_EINSATZTERMIN:BEMERKUNG_EINSATZTERMIN:SUMS_RELEVANT:'
,p_sort_column_1=>'LAND'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2663066134430110392)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2663061119836110366)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:135:&SESSION.::&DEBUG.:135'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(682181640820328095)
,p_name=>'P130_EINSATZTERMIN_COLUMNS'
,p_item_sequence=>20
,p_item_default=>'0'
,p_prompt=>unistr('Spalten Bedeutung und Bemerkung <br> Erf\00FCllungszeitpunkt anzeigen')
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Nein',
  'off_value', '0',
  'on_label', 'Ja',
  'on_value', '1',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2663065226100110391)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2663061119836110366)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2663065718143110392)
,p_event_id=>wwv_flow_imp.id(2663065226100110391)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2663061119836110366)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2663066539552110393)
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2663066134430110392)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2663066996308110393)
,p_event_id=>wwv_flow_imp.id(2663066539552110393)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2663061119836110366)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(682181542912328094)
,p_name=>'TOGGLE_EINSATZTERMIN_COLUMNS'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P130_EINSATZTERMIN_COLUMNS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(682181187842328090)
,p_event_id=>wwv_flow_imp.id(682181542912328094)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#P130_EINSATZTERMIN_COLUMNS'').change(function() {',
'',
'    alert(''func'');',
'    if ($v(''P130_EINSATZTERMIN_COLUMNS'') == 1) {',
'        // Show both columns',
'        alert(''test'');',
'        $(''#IR1'').find(''th[id="BEDEUTUNG_EINSATZTERMIN"], td[headers="BEDEUTUNG_EINSATZTERMIN"]'').show();',
'        $(''#IR1'').find(''th[id="BEMERKUNG_EINSATZTERMIN"], td[headers="BEMERKUNG_EINSATZTERMIN"]'').show();',
'    } else {',
'        // Hide both columns',
'        alert(''else'')',
'        $(''#IR1'').find(''th[id="BEDEUTUNG_EINSATZTERMIN"], td[headers="BEDEUTUNG_EINSATZTERMIN"]'').hide();',
'        $(''#IR1'').find(''th[id="BEMERKUNG_EINSATZTERMIN"], td[headers="BEMERKUNG_EINSATZTERMIN"]'').hide();',
'    }',
'});'))
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(682180925507328087)
,p_event_id=>wwv_flow_imp.id(682181542912328094)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var switchValue = apex.item("P130_EINSATZTERMIN_COLUMNS").getValue();',
'if (switchValue == 1 ) {',
'    //alert(''test mine'');',
'   //// apex.region("#IR1").showColumn("BEDEUTUNG_EINSATZTERMIN");',
'    //apex.region("#IR1").showColumn("BEMERKUNG_EINSATZTERMIN");',
'',
'    $(''#IR1'').find(''th[id="BEDEUTUNG"], td[headers="BEDEUTUNG_EINSATZTERMIN"]'').show();',
'        $(''#IR1'').find(''th[id="BEMERKUNG"], td[headers="BEMERKUNG_EINSATZTERMIN"]'').show();',
'} else {',
'        $(''#IR1'').find(''th[id="BEDEUTUNG"], td[headers="BEDEUTUNG_EINSATZTERMIN"]'').hide();',
'        $(''#IR1'').find(''th[id="BEMERKUNG"], td[headers="BEMERKUNG_EINSATZTERMIN"]'').hide();',
'    //apex.region("#IR1").hideColumn("BEDEUTUNG_EINSATZTERMIN");',
'    //apex.region("#IR1").hideColumn("BEMERKUNG_EINSATZTERMIN");',
'}',
''))
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(682180300670328081)
,p_event_id=>wwv_flow_imp.id(682181542912328094)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P130_EINSATZTERMIN_COLUMNS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(682180971619328088)
,p_event_id=>wwv_flow_imp.id(682181542912328094)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2663061119836110366)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(682180638163328085)
,p_name=>'New'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P130_NEW'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(682180625322328084)
,p_event_id=>wwv_flow_imp.id(682180638163328085)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2663061119836110366)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
