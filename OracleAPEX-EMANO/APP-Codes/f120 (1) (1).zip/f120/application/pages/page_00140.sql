prompt --application/pages/page_00140
begin
--   Manifest
--     PAGE: 00140
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>140
,p_name=>'Mehrfachbearbeitung'
,p_alias=>'MEHRFACHBEARBEITUNG'
,p_step_title=>'Mehrfachbearbeitung'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function loadLaenderShuttle() {',
'    var shuttleName = ''P140_LAENDER_ADDED'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadLaenderShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P140_LAND_PRE''),',
'          x03: $v(''P140_SELECTED_VORSCHRIFTEN''),',
'          x04: $v(''P140_LAENDERGRUPPE'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'function loadThemenShuttle() {',
'    var shuttleName = ''P140_THEMEN_ADDED'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadThemenShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P140_THEMA_PRE''),',
'          x03: $v(''P140_SELECTED_VORSCHRIFTEN'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'function loadThemenDelShuttle() {',
'    var shuttleName = ''P140_THEMEN_DELETE'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadThemenDelShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P140_THEMA_DEL_PRE''),',
'          x03: $v(''P140_SELECTED_VORSCHRIFTEN'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'function addItemToShuttle(aShuttle, aID, aDisplay) {',
'    var lLeft = $(''#'' + aShuttle + ''_LEFT'');',
'    var lRight = $(''#'' + aShuttle + ''_RIGHT'');',
'    lLeft.find(''option[value='' + aID + '']'').remove();',
'    lRight.append(''<option value="'' + aID + ''">'' + aDisplay + ''</option>'');',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Text-Item muss da sein, da sonst Submit bei Enter im Vorfilter-Feld',
'$(''#P140_TEXT_FELD_TH_LO'').closest(''div.row'').hide();',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-HeroRegion input[type="checkbox"] {',
'    display: none',
'}',
'',
'#t_Body_content_offset {',
'    height: 90px !important;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(2652734963787598041)
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2973647384106820374)
,p_plug_name=>'Breadcrump'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>wwv_flow_imp.id(3414122116128820546)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_header=>'Mehrfachbearbeitung'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'SESSION')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5426692150637700113)
,p_plug_name=>'Content'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1720042396078566481)
,p_plug_name=>unistr('<input id="toggleRegion" region="LAENDER_ADD" type="checkbox" /> L\00E4nder hinzuf\00FCgen')
,p_parent_plug_id=>wwv_flow_imp.id(5426692150637700113)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1720042470593566482)
,p_plug_name=>unistr('Info_L\00E4nder add')
,p_parent_plug_id=>wwv_flow_imp.id(1720042396078566481)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('In diesem Bereich k\00F6nnen zus\00E4tzliche L\00E4nder zugeordnet werden.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1720042701302566484)
,p_plug_name=>unistr('L\00E4nder hinzuf\00FCgen')
,p_parent_plug_id=>wwv_flow_imp.id(1720042396078566481)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1720043651301566494)
,p_plug_name=>unistr('<input id="toggleRegion" region="THEMEN_ADD" type="checkbox" /> Themen hinzuf\00FCgen')
,p_parent_plug_id=>wwv_flow_imp.id(5426692150637700113)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1720043925779566496)
,p_plug_name=>'Info_Themen_add'
,p_parent_plug_id=>wwv_flow_imp.id(1720043651301566494)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('In diesem Bereich k\00F6nnen zus\00E4tzliche Themen zugeordnet werden.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1720044010867566497)
,p_plug_name=>unistr('Themen hinzuf\00FCgen')
,p_parent_plug_id=>wwv_flow_imp.id(1720043651301566494)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1720045061611566508)
,p_plug_name=>unistr('<input id="toggleRegion" region="THEMEN_DELETE" type="checkbox" /> Themen l\00F6schen')
,p_parent_plug_id=>wwv_flow_imp.id(5426692150637700113)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1720045163979566509)
,p_plug_name=>unistr('Info_themen_l\00F6schen')
,p_parent_plug_id=>wwv_flow_imp.id(1720045061611566508)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('In diesem Bereich k\00F6nnen zugeordnete Themen gel\00F6scht werden.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1720045237832566510)
,p_plug_name=>unistr('Themen L\00F6schen')
,p_parent_plug_id=>wwv_flow_imp.id(1720045061611566508)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2422777584074696292)
,p_plug_name=>'<input id="toggleRegion" region="LEAD_VKO" type="checkbox" /> Lead VKO'
,p_parent_plug_id=>wwv_flow_imp.id(5426692150637700113)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2422777683472696293)
,p_plug_name=>'Info'
,p_parent_plug_id=>wwv_flow_imp.id(2422777584074696292)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('In diesem Bereich kann ein Lead VKO festgelegt werden. Bereits existierende Werte werden \00FCberschrieben.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2422777811860696294)
,p_plug_name=>'Container'
,p_parent_plug_id=>wwv_flow_imp.id(2422777584074696292)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1723906261715940990)
,p_name=>'Vorschriften'
,p_parent_plug_id=>wwv_flow_imp.id(2422777811860696294)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  v.vorschrift_nummer,  nvl2(b.nachname, b.nachname || '', ''|| b.vorname, ''-'') Lead_VKO  ',
', nvl(listagg(ak.bezeichnung, '', '') within group (order by ak.bezeichnung), ''-'')  Arbeitskreise',
'--v.lead_vko_benutzerid, v.vorschriftid,',
'  from t_vorschrift v',
'  left outer join  t_VORSCHRIFT_REF_ET_B_AK vra on (vra.vorschriftid = v.vorschriftid and vra.geloescht !=1)',
'  left outer join t_et_b_ak ak on (ak.et_b_akid  = vra.et_b_akid)',
'  left outer join t_benutzer b on (b.benutzerid = v.lead_vko_benutzerid)',
' where v.vorschriftid in (',
'                 select column_value from table(apex_string.split_numbers(:P140_SELECTED_VORSCHRIFTEN, '':'')) )',
'    group by v.vorschrift_nummer, nvl2(b.nachname, b.nachname || '', ''|| b.vorname, ''-'')'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1012215851322040916)
,p_query_column_id=>1
,p_column_alias=>'VORSCHRIFT_NUMMER'
,p_column_display_sequence=>20
,p_column_heading=>'Vorschrift Nummer'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1012215471901040916)
,p_query_column_id=>2
,p_column_alias=>'LEAD_VKO'
,p_column_display_sequence=>30
,p_column_heading=>'Lead VKO'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1012215035728040916)
,p_query_column_id=>3
,p_column_alias=>'ARBEITSKREISE'
,p_column_display_sequence=>40
,p_column_heading=>'Arbeitskreise'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2971897300818599200)
,p_plug_name=>unistr('Ausgew\00E4hlte Vorschriften')
,p_parent_plug_id=>wwv_flow_imp.id(5426692150637700113)
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(2971897421643599201)
,p_name=>unistr('Ausgew\00E4hlte Vorschriften')
,p_parent_plug_id=>wwv_flow_imp.id(2971897300818599200)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select --VORSCHRIFTID,',
'       VORSCHRIFT_NUMMER,',
'       VORSCHRIFT_BEZEICHNUNG,',
'       PROGNOSE_QUALITAET,',
'       --JIRA_TICKET,',
'       --VORSCHRIFT_FREIGABESTATUSID,',
'       BEMERKUNG,',
'       --LINK_ZUR_VORSCHRIFT_DMS,',
'       --LINK_ZUR_VORSCHRIFT_GETEX,',
'       --TYPSCHILD,',
'       --LETZTE_AENDERUNG_DATUM,',
'       --LETZTE_AENDERUNG_BENUTZERID,',
'       --WEBSITEID,',
'       --WEBSITELINK,',
'       --EINSATZDATUM_MODELLID,',
'       VORSCHRIFT_TYPID,',
'       --NORMID,',
'       --HOMOLOGATION_MOEGLICH,',
'       --KSUID,',
'       VORSCHRIFT_STATUSID--,',
'       --HOMOLOGATIONSRELEVANT,',
'       --RXSWIN',
'  from T_VORSCHRIFT',
'  ',
' where vorschriftid in (',
'    select column_value ',
'    from table(apex_string.split_numbers(:P140_SELECTED_VORSCHRIFTEN, '':''))',
')',
'    '))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'\P140_SELECTED_VORSCHRIFTEN\'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>unistr('Es wurden keine bearbeitbaren Vorschriften ausgew\00E4hlt.')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1012218236780040919)
,p_query_column_id=>1
,p_column_alias=>'VORSCHRIFT_NUMMER'
,p_column_display_sequence=>1
,p_column_heading=>'Vorschriften&shy;nummer'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1012220233538040921)
,p_query_column_id=>2
,p_column_alias=>'VORSCHRIFT_BEZEICHNUNG'
,p_column_display_sequence=>2
,p_column_heading=>'Titel'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1012219879776040920)
,p_query_column_id=>3
,p_column_alias=>'PROGNOSE_QUALITAET'
,p_column_display_sequence=>5
,p_column_heading=>unistr('Prognose Qualit\00E4t')
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(958121403566083634)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1012219502981040920)
,p_query_column_id=>4
,p_column_alias=>'BEMERKUNG'
,p_column_display_sequence=>3
,p_column_heading=>'Bemerkung zur Vorschrift'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1012219045199040920)
,p_query_column_id=>5
,p_column_alias=>'VORSCHRIFT_TYPID'
,p_column_display_sequence=>4
,p_column_heading=>'Vorschrift Typ'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(2656545044559578040)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1012218653618040920)
,p_query_column_id=>6
,p_column_alias=>'VORSCHRIFT_STATUSID'
,p_column_display_sequence=>6
,p_column_heading=>'Status der Vorschrift'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(2490458092659806028)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3818623951489662497)
,p_plug_name=>'<input id="toggleRegion" region="SEARCH_REPLACE" type="checkbox" /> Suchen und Ersetzen'
,p_parent_plug_id=>wwv_flow_imp.id(5426692150637700113)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>110
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3818624033563662498)
,p_plug_name=>'Info'
,p_parent_plug_id=>wwv_flow_imp.id(3818623951489662497)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('In diesem Bereich k\00F6nnen Teile von Text-Attributen der Vorschriften ersetzt werden.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3818624194781662500)
,p_plug_name=>'Suchen & Ersetzen-Parameter'
,p_parent_plug_id=>wwv_flow_imp.id(3818623951489662497)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3818624710496662505)
,p_name=>'Vorschau'
,p_parent_plug_id=>wwv_flow_imp.id(3818623951489662497)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with selected_vorschriften as (',
'    select regexp_substr(:P140_SELECTED_VORSCHRIFTEN, ''[^:]+'', 1, level) selected_vorschriftid',
'    from dual',
'    connect by level <= regexp_count(:P140_SELECTED_VORSCHRIFTEN, '':'') + 1',
'),',
'selected_attribut as (',
'    select vorschriftid, case to_char(:P140_TEXT_ATTRIBUT)',
'        -- when ''10'' then vorschrift_nummer',
'        -- when ''20'' then vorschrift_bezeichnung',
'        when ''30'' then bemerkung',
'        when ''40'' then LINK_ZUR_VORSCHRIFT_DMS',
'        -- when ''50'' then LINK_ZUR_VORSCHRIFT_GETEX',
'        when ''60'' then WEBSITELINK',
'    end attribut_wert',
'    from t_vorschrift',
')',
'select vs.vorschrift_nummer, sa.attribut_wert Alter_Wert, case to_char(:P140_REGEX_PLAIN)',
'        when ''0'' then replace(sa.attribut_wert, :P140_SEARCH_TEXT, :P140_REPLACE_TEXT) ',
'        when ''1'' then regexp_replace(sa.attribut_wert, :P140_SEARCH_TEXT, :P140_REPLACE_TEXT) ',
'     end Neuer_Wert',
'from t_vorschrift vs',
'join selected_vorschriften sv on sv.selected_vorschriftid = vs.vorschriftid',
'join selected_attribut sa on sa.vorschriftid = vs.vorschriftid',
'',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P140_TEXT_ATTRIBUT,P140_REGEX_PLAIN,P140_SEARCH_TEXT,P140_REPLACE_TEXT'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1012211425956040912)
,p_query_column_id=>1
,p_column_alias=>'VORSCHRIFT_NUMMER'
,p_column_display_sequence=>1
,p_column_heading=>'Vorschrift Nummer'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1012211088210040911)
,p_query_column_id=>2
,p_column_alias=>'ALTER_WERT'
,p_column_display_sequence=>2
,p_column_heading=>unistr('Ausgew\00E4hlte Spalte')
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P140_TEXT_ATTRIBUT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1012210695545040911)
,p_query_column_id=>3
,p_column_alias=>'NEUER_WERT'
,p_column_display_sequence=>3
,p_column_heading=>'Neuer Wert'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P140_SEARCH_TEXT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5426692374131700115)
,p_plug_name=>'<input id="toggleRegion" region="ATTRIBUTE" type="checkbox" /> Attribute'
,p_parent_plug_id=>wwv_flow_imp.id(5426692150637700113)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5426692801375700119)
,p_plug_name=>'Info'
,p_parent_plug_id=>wwv_flow_imp.id(5426692374131700115)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('In diesem Bereich k\00F6nnen Attributwerte zugeordnet werden. Bereits existierende Werte werden \00FCberschrieben.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5426693206385700123)
,p_plug_name=>'Container left'
,p_parent_plug_id=>wwv_flow_imp.id(5426692374131700115)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5426693308429700124)
,p_plug_name=>'Container right'
,p_parent_plug_id=>wwv_flow_imp.id(5426692374131700115)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5426692483981700116)
,p_plug_name=>'<input id="toggleRegion" region="WEBSITES" type="checkbox" /> Websites'
,p_parent_plug_id=>wwv_flow_imp.id(5426692150637700113)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5426693957394700131)
,p_plug_name=>'Info'
,p_parent_plug_id=>wwv_flow_imp.id(5426692483981700116)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('In diesem Bereich k\00F6nnen Websites erg\00E4nzt werden. Bereits existierende Werte werden \00FCberschrieben.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5426694512989700136)
,p_plug_name=>'Container'
,p_parent_plug_id=>wwv_flow_imp.id(5426692483981700116)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1012210224783040910)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3818624710496662505)
,p_button_name=>'BTN_SEARCH_CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1012209881913040909)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3818624710496662505)
,p_button_name=>'BTN_SEARCH_PREVIEW'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Vorschau aktualisieren'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1012230206006040968)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2973647384106820374)
,p_button_name=>'BTN_CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Zur\00FCck zur Vorschriftenliste')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1012229736879040967)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2973647384106820374)
,p_button_name=>'APPLY'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00C4nderungen \00FCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1012166156133040869)
,p_branch_name=>'CLOSE_PAGE'
,p_branch_action=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1012229736879040967)
,p_branch_sequence=>10
,p_branch_condition_type=>'REQUEST_IN_CONDITION'
,p_branch_condition=>'APPLY'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012229185114040945)
,p_name=>'P140_LOAD_FROM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(5426692150637700113)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012228730786040943)
,p_name=>'P140_SELECTED_VORSCHRIFTEN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(5426692150637700113)
,p_use_cache_before_default=>'NO'
,p_source=>':&P140_LOAD_FROM.'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012228066915040942)
,p_name=>'P140_REGION_LAENDER_ADD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1720042396078566481)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012227115826040941)
,p_name=>'P140_LAENDERGRUPPE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1720042701302566484)
,p_prompt=>'Gruppe'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select laendergruppe, laendergruppeid',
'from t_laendergruppe',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- alle -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012226709407040941)
,p_name=>'P140_LAND_PRE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1720042701302566484)
,p_prompt=>'Suche Land'
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" id="#qPre"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012226300457040941)
,p_name=>'P140_LAENDER_ADDED'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1720042701302566484)
,p_prompt=>unistr('L\00E4nder hinzuf\00FCgen')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_l as (select distinct landid  from t_vorschrift_ref_land ',
'                                where vorschriftid in  (select column_value ',
'                                                   from table(apex_string.split_numbers(:P140_SELECTED_VORSCHRIFTEN, '':'')) )',
'                                  and geloescht !=1',
')',
'select d, r from (',
'    select distinct l.b_nummer || '' - '' || l.land as d, l.landid as r, l.land',
'            from t_land l',
'           where  ( ',
'                 :P140_LAENDERGRUPPE is null',
'                 or ( l.landid in ( select distinct landid from t_land_ref_laendergruppe where laendergruppeid = :P140_LAENDERGRUPPE)',
'                 )',
'            )',
'            and (',
'                :P140_LAND_PRE is null',
'                or ( instr(upper(l.b_nummer),upper(:P140_LAND_PRE)) != 0) --and l.landid not in ( cte_l.landid))',
'                or ( instr(upper(l.land),upper(:P140_LAND_PRE)) != 0) --and l.landid not in ( cte_l.landid))',
'            )',
unistr('         -- nur l\00E4nder die keinem der gew\00E4hlten Vorschrift zugeordnet sind.'),
'     minus',
'',
'     select distinct l.b_nummer || '' - '' || l.land as d, l.landid as r, l.land',
'            from t_land l',
'            join cte_l on (cte_l.landid = l.landid)',
'    ) order by nlssort(land,''NLS_SORT=BINARY_AI'')',
'       -- order by 2 -- nlssort(1,''NLS_SORT=BINARY_AI'') '))
,p_lov_cascade_parent_items=>'P140_LAND_PRE,P140_LAENDERGRUPPE'
,p_ajax_optimize_refresh=>'N'
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012225606289040939)
,p_name=>'P140_REGION_THEMEN_ADD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1720043651301566494)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012224591042040938)
,p_name=>'P140_THEMA_PRE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1720044010867566497)
,p_prompt=>'Suche Thema'
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" id="#zPre"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012224206287040938)
,p_name=>'P140_THEMEN_ADDED'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1720044010867566497)
,p_prompt=>unistr('Themen hinzuf\00FCgen')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_t as (select distinct themaid  from t_vorschrift_ref_thema ',
'                                where vorschriftid in  (select column_value ',
'                                                   from table(apex_string.split_numbers(:P140_SELECTED_VORSCHRIFTEN, '':'')) )',
'                                  and geloescht !=1',
')',
' select d, r from',
'    (select distinct   vt.nummer||'' '' || vt.bezeichnung as d, vt.themaid as r, vt.thema_sortorder as sorder',
'            from v_thema_baum vt',
'',
'            where (',
'                :P140_THEMA_PRE is null',
'                or ( instr(upper(vt.nummer),upper(:P140_THEMA_PRE)) != 0) ',
'                or ( instr(upper(vt.bezeichnung),upper(:P140_THEMA_PRE)) != 0) ',
'            )',
unistr('         -- nur theman, die keinem der gew\00E4hlten Vorschrift zugeordnet sind.'),
'     minus',
'',
'     select distinct vt.nummer||'' '' || vt.bezeichnung as d, vt.themaid as r, vt.thema_sortorder as sorder',
'            from v_thema_baum vt',
'            join cte_t on (cte_t.themaid = vt.themaid)',
'    )',
'      order by sorder',
'   '))
,p_lov_cascade_parent_items=>'P140_THEMA_PRE,P140_SELECTED_VORSCHRIFTEN'
,p_ajax_optimize_refresh=>'N'
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 21.05.2024',
'',
'with cte_t as (select distinct themaid  from t_vorschrift_ref_thema ',
'                                where vorschriftid in  (select column_value ',
'                                                   from table(apex_string.split_numbers(:P140_SELECTED_VORSCHRIFTEN, '':'')) )',
'                                  and geloescht !=1',
')',
' select d, r from',
'    (select distinct    /* vt.themaid ||'' '' || */  vt.nummer||'' '' || vt.bezeichnung as d, vt.themaid as r, vt.thema_sortorder as sorder',
'            from v_thema_baum vt',
'',
'            where (',
'                :P140_THEMA_PRE is null',
'                or ( instr(upper(vt.nummer),upper(:P140_THEMA_PRE)) != 0) ',
'                or ( instr(upper(vt.bezeichnung),upper(:P140_THEMA_PRE)) != 0) ',
'            )',
unistr('         -- nur theman, die keinem der gew\00E4hlten Vorschrift zugeordnet sind.'),
'     minus',
'',
'     select distinct  /* vt.themaid ||'' '' || */  vt.nummer||'' '' || vt.bezeichnung as d, vt.themaid as r, vt.thema_sortorder as sorder',
'            from v_thema_baum vt',
'            join cte_t on (cte_t.themaid = vt.themaid)',
'',
'            ',
'    )',
'      order by sorder',
'   ',
'',
'-- 20.05.2024',
'',
'',
' select d, r from',
'    (select distinct    /* vt.themaid ||'' '' || */  vt.nummer||'' '' || vt.bezeichnung as d, vt.themaid as r, vt.thema_sortorder as sorder',
'            from v_thema_baum vt',
'',
'            where (',
'                :P140_THEMA_PRE is null',
'                or ( instr(upper(vt.nummer),upper(:P140_THEMA_PRE)) != 0) ',
'                or ( instr(upper(vt.bezeichnung),upper(:P140_THEMA_PRE)) != 0) ',
'            )',
unistr('         -- nur theman, die keinem der gew\00E4hlten Vorschrift zugeordnet sind.'),
'',
'            ',
'    )',
'      order by sorder',
'   '))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012223738044040938)
,p_name=>'P140_THEMEN_CHILDREN_TO_ADD'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(1720044010867566497)
,p_prompt=>'THEMEN_CHILDREN_TO_ADD'
,p_display_as=>'NATIVE_HIDDEN'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012223048856040937)
,p_name=>'P140_REGION_THEMEN_DELETE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1720045061611566508)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012222062530040936)
,p_name=>'P140_THEMA_DEL_PRE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1720045237832566510)
,p_prompt=>'Suche'
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" id="#zPre"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012221711954040936)
,p_name=>'P140_THEMEN_DELETE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1720045237832566510)
,p_prompt=>unistr('Themen zum L\00F6schen')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_t as (select distinct themaid from t_vorschrift_ref_thema ',
'                where vorschriftid in (select column_value ',
'                                         from table(apex_string.split_numbers(:P140_SELECTED_VORSCHRIFTEN, '':'')) )',
'                  and geloescht !=1',
')',
' --select d, r from',
unistr('    --( -- nur theman, die mindest. einem der gew\00E4hlten Vorschriften zugeordnet sind.'),
'      select  vt.nummer||'' '' || vt.bezeichnung as d, vt.themaid as r --, vt.thema_sortorder as sorder',
'        from v_thema_baum vt',
'        join cte_t on (cte_t.themaid = vt.themaid)',
'       where ( :P140_THEMA_DEL_PRE is null',
'                or ( instr(upper(vt.nummer||'' '' || vt.bezeichnung),upper(:P140_THEMA_DEL_PRE)) != 0)',
'            )',
'    --)',
' --order by sorder'))
,p_lov_cascade_parent_items=>'P140_THEMA_DEL_PRE'
,p_ajax_optimize_refresh=>'N'
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012221237919040936)
,p_name=>'P140_TEXT_FELD_TH_LO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1720045237832566510)
,p_prompt=>'Th Lo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012217527798040919)
,p_name=>'P140_REGION_LEAD_VKO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2422777584074696292)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012216517967040918)
,p_name=>'P140_LEAD_VKO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2422777811860696294)
,p_prompt=>'Lead VKO'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' with cte as ( select pck_ri.fgetCommonVKOUserIds(:P140_SELECTED_VORSCHRIFTEN) as m_ids from dual )',
' select b.nachname||'', ''||b.vorname  d, column_value r ',
' from table ( select  apex_string.split_numbers(cte.m_ids, '':'') from cte ) x ',
' join t_benutzer b on b.benutzerid = x.column_value ;',
' '))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_cHeight=>1
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012214331109040915)
,p_name=>'P140_REGION_SEARCH_REPLACE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3818623951489662497)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012213341577040913)
,p_name=>'P140_TEXT_ATTRIBUT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3818624194781662500)
,p_prompt=>'Attribut/Tabellenspalte'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Bemerkung zur Vorschrift;30,Link zu DMS;40,Link zu Web Site;60'
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('W\00E4hlen Sie das Attribut/Tabellenspalte aus')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012213009743040913)
,p_name=>'P140_REGEX_PLAIN'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3818624194781662500)
,p_prompt=>'Art der Suche'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Einfacher Text',
  'off_value', '0',
  'on_label', unistr('Regul\00E4rer Ausdruck'),
  'on_value', '1',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012212576911040913)
,p_name=>'P140_SEARCH_TEXT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(3818624194781662500)
,p_prompt=>'Suchen nach'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012212155602040913)
,p_name=>'P140_REPLACE_TEXT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(3818624194781662500)
,p_prompt=>'Ersetzen durch'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012209152624040909)
,p_name=>'P140_REGION_ATTRIBUTE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(5426692374131700115)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012208185436040907)
,p_name=>'P140_EINSATZDATUM_MODELL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(5426693206385700123)
,p_prompt=>'Einsatzdatum Modell'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select modell, einsatzdatum_modellid',
'from t_einsatzdatum_modell',
'order by einsatzdatum_modellid asc'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_cHeight=>1
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012207813041040907)
,p_name=>'P140_VORSCHRIFT_BEZEICHNUNG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(5426693206385700123)
,p_prompt=>unistr('Titel (\00DCberschrift)')
,p_placeholder=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>300
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012207370840040907)
,p_name=>'P140_PROGNOSE_QUALITAET'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(5426693206385700123)
,p_prompt=>unistr('Prognose Qualit\00E4t')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VORSCHRIFT_PROGNOSE_QUALITAET'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''offen'', ''open'') AS display_value,',
'        0 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''sicher'', ''secure'') AS display_value,',
'        10 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'    ',
'    UNION ALL',
'    ',
'    SELECT ',
unistr('        emano_util.fLang(''absch\00E4tzbar'', ''estimable'') AS display_value,'),
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012206923190040906)
,p_name=>'P140_FREIGABESTATUS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(5426693206385700123)
,p_prompt=>'Interner DB Freigabestatus'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select emano_util.fLang(name_deutsch,name_englisch) as display_value, vorschrift_freigabestatusid as actual_value',
'from t_vorschrift_freigabestatus',
'where vorschrift_freigabestatusid in (1,30)',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012206548276040906)
,p_name=>'P140_RXSWIN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(5426693206385700123)
,p_prompt=>'Potentiell SUMS-relevant'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Nicht gepr\00FCft'', ''Not checked'') AS display_value,'),
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012205910332040906)
,p_name=>'P140_VORSCHRIFT_STATUS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(5426693308429700124)
,p_prompt=>'Status der Vorschrift '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VORSCHRIFT_STATUS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select Status as d,',
'       Vorschrift_statusid as r',
'  from T_vorschrift_status',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_cHeight=>1
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012205458113040905)
,p_name=>'P140_HOMOLOGATION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(5426693308429700124)
,p_prompt=>'Homologationsrelevant'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Ja;10,Nein;0'
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012205088656040905)
,p_name=>'P140_MASTER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(5426693308429700124)
,p_prompt=>'Master'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC2:Regindex;10,GETEX;20,GETEX + automatische \00DCbernahme;30')
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012204683164040905)
,p_name=>'P140_BEMERKUNG'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(5426693308429700124)
,p_prompt=>'Bemerkung'
,p_placeholder=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012204294552040905)
,p_name=>'P140_FAHRZEUGKLASSE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(5426693308429700124)
,p_prompt=>'Fahrzeugklasse'
,p_placeholder=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung, fahrzeugklasseid',
'from t_fahrzeugklasse',
'order by bezeichnung asc'))
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012203529510040904)
,p_name=>'P140_REGION_WEBSITES'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(5426692483981700116)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012202581840040903)
,p_name=>'P140_LINK_GETEX'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(5426694512989700136)
,p_prompt=>'Getex 1.0 ID'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012202171980040903)
,p_name=>'P140_LINK_DMS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(5426694512989700136)
,p_prompt=>'Link zu DMS (ein Link pro Zeile)'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>3
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012201737360040903)
,p_name=>'P140_WEBSITE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(5426694512989700136)
,p_prompt=>'Webseite'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select website_name, websiteid',
'from t_website',
'order by 2'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('urspr\00FCnglichen Wert beibehalten')
,p_cHeight=>1
,p_colspan=>4
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1012201338141040903)
,p_name=>'P140_WEBSITE_LINK'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(5426694512989700136)
,p_prompt=>'Link zu Web Site'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>120
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1012198474146040893)
,p_validation_name=>'V_EINSATZDATUM_STATUS'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from t_vorschrift v',
'left outer join T_VORSCHRIFT_REF_EINSATZDATUM_TYP vret ',
'    on vret.vorschriftid = v.vorschriftid',
'    and vret.einsatzdatum_typid = 1000',
'where v.vorschriftid in (5100, 3457)',
'  and vret.vorschriftid is null',
';'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>unistr('Alle ausgew\00E4hlten Vorschriften ben\00F6tigen ein in Kraft-Datum bevor diese den Status In Kraft erhalten k\00F6nnen.')
,p_validation_condition=>'P140_VORSCHRIFT_STATUS'
,p_validation_condition2=>'40'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(1012229736879040967)
,p_associated_item=>wwv_flow_imp.id(1012205910332040906)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1012200425877040894)
,p_validation_name=>'V_ERSETZEN_LINK_GETEX'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'    :P140_REGION_SEARCH_REPLACE <> 1',
'    or :P140_TEXT_ATTRIBUT <> 50',
'    or :P140_LINK_GETEX is null',
')'))
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Die Funktion Suchen und Ersetzen von ''Link zu GETEX'' kann nicht gleichzeitig mit der Funktion zum Setzen eines neuen Wertes f\00FCr ''Link zu GETEX'' aus dem Bereich ''Websites'' genutzt werden.')
,p_validation_condition_type=>'NEVER'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_validation_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'serbidesid econd ',
'button aply ',
'iem avleus ',
'',
'P140_REGION_WEBSITES',
'',
'1'))
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1012199712031040894)
,p_validation_name=>'V_ERSETZEN_LINK_WEBSITE'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'    :P140_REGION_SEARCH_REPLACE <> 1',
'    or :P140_TEXT_ATTRIBUT <> 60',
'    or :P140_WEBSITE_LINK is null',
')'))
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Die Funktion Suchen und Ersetzen von ''Link zu Web Site'' kann nicht gleichzeitig mit der Funktion zum Setzen eines neuen Wertes f\00FCr ''Link zu Web Site'' aus dem Bereich ''Websites'' genutzt werden.')
,p_validation_condition=>'P140_REGION_WEBSITES'
,p_validation_condition2=>'1'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(1012229736879040967)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1012200027957040894)
,p_validation_name=>'V_ERSETZEN_LINK_DMS'
,p_validation_sequence=>40
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'    :P140_REGION_SEARCH_REPLACE <> 1',
'    or :P140_TEXT_ATTRIBUT <> 40',
'    or :P140_LINK_DMS is null',
')'))
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Die Funktion Suchen und Ersetzen von ''Link zu DMS'' kann nicht gleichzeitig mit der Funktion zum Setzen eines neuen Wertes f\00FCr ''Link zu DMS'' aus dem Bereich ''Websites'' genutzt werden.')
,p_validation_condition=>'P140_REGION_WEBSITES'
,p_validation_condition2=>'1'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(1012229736879040967)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1012199256634040893)
,p_validation_name=>'V_ERSETZEN_VS_TITEL'
,p_validation_sequence=>50
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'    :P140_REGION_SEARCH_REPLACE <> 1',
'    or :P140_TEXT_ATTRIBUT <> 20',
'    or :P140_VORSCHRIFT_BEZEICHNUNG is null',
')'))
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Die Funktion Suchen und Ersetzen von ''Titel (\00DCberschrift)'' kann nicht gleichzeitig mit der Funktion zum Setzen eines neuen Wertes f\00FCr ''Titel (\00DCberschrift)'' aus dem Bereich ''Attribute'' genutzt werden.')
,p_validation_condition_type=>'NEVER'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_validation_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'serbidesid econd ',
'button aply ',
'iem avleus ',
'P140_REGION_ATTRIBUTE',
'',
'1'))
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1012198845028040893)
,p_validation_name=>'V_ERSETZEN_VS_BEMERKUNG'
,p_validation_sequence=>60
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'    :P140_REGION_SEARCH_REPLACE <> 1',
'    or :P140_TEXT_ATTRIBUT <> 30',
'    or :P140_BEMERKUNG is null',
')'))
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Die Funktion Suchen und Ersetzen von ''Bemerkung zur Vorschrift'' kann nicht gleichzeitig mit der Funktion zum Setzen eines neuen Wertes f\00FCr ''Bemerkung'' aus dem Bereich ''Attribute'' genutzt werden.')
,p_validation_condition=>'P140_REGION_ATTRIBUTE'
,p_validation_condition2=>'1'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(1012229736879040967)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1012200830326040895)
,p_validation_name=>'THEMA_VALIDATION'
,p_validation_sequence=>70
,p_validation=>'P140_THEMEN_ADDED'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Bitte w\00E4hlen Sie ein Thema aus')
,p_validation_condition_type=>'NEVER'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_validation_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'expression pl sql ',
'',
'(:P104_THEMAID is null and (:P104_NEW_CREATE is null or :P104_NEW_CREATE= 0)',
')',
'or',
'(:P104_NEW_CREATE = 1 and :P104_EDIT_THEMEN = 1)',
'',
'',
'(:P140_THEMAID is null and (:P140_NEW_CREATE is null or :P140_NEW_CREATE= 0)',
')',
'or',
'(:P140_NEW_CREATE = 1 and :P140_EDIT_THEMEN = 1)'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012170318248040872)
,p_name=>'toggleRegion'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'input#toggleRegion'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012169819568040872)
,p_event_id=>wwv_flow_imp.id(1012170318248040872)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var region = $(this.triggeringElement).attr("region");',
'var stateChecked = $(this.triggeringElement).is(":checked");',
'',
'if (stateChecked) {',
'    $s("P140_REGION_" + region,1);',
'} else {',
'    $s("P140_REGION_" + region,0);    ',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012169424151040872)
,p_name=>'toggle items attribute'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_REGION_ATTRIBUTE'
,p_condition_element=>'P140_REGION_ATTRIBUTE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012168991245040872)
,p_event_id=>wwv_flow_imp.id(1012169424151040872)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P140_FREIGABESTATUS,P140_BEMERKUNG,P140_PROGNOSE_QUALITAET,P140_MASTER,P140_RXSWIN,P140_HOMOLOGATION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012168429132040872)
,p_event_id=>wwv_flow_imp.id(1012169424151040872)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P140_FREIGABESTATUS,P140_BEMERKUNG,P140_PROGNOSE_QUALITAET,P140_MASTER,P140_RXSWIN,P140_HOMOLOGATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012168102266040871)
,p_name=>'toggle items websites'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_REGION_WEBSITES'
,p_condition_element=>'P140_REGION_WEBSITES'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012167536279040871)
,p_event_id=>wwv_flow_imp.id(1012168102266040871)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P140_LINK_GETEX,P140_LINK_DMS,P140_WEBSITE,P140_WEBSITE_LINK'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012167070387040871)
,p_event_id=>wwv_flow_imp.id(1012168102266040871)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P140_LINK_GETEX,P140_LINK_DMS,P140_WEBSITE,P140_WEBSITE_LINK'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012166646217040871)
,p_name=>'toggle items laender'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_REGION_LAENDER'
,p_condition_element=>'P140_REGION_LAENDER'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012193378311040886)
,p_name=>unistr('enter im Q L\00E4ndersuchfeld')
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_Q_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012192858660040882)
,p_event_id=>wwv_flow_imp.id(1012193378311040886)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P140_Q_PRE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012192479402040881)
,p_name=>unistr('enter im Z L\00E4ndersuchfeld')
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_Z_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012191959284040881)
,p_event_id=>wwv_flow_imp.id(1012192479402040881)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P140_Z_PRE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012191529227040881)
,p_name=>'klick suchicon Q'
,p_event_sequence=>70
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#qPre'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012191017648040880)
,p_event_id=>wwv_flow_imp.id(1012191529227040881)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012190707631040880)
,p_name=>'klick suchicon Z'
,p_event_sequence=>80
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#zPre'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012190213028040880)
,p_event_id=>wwv_flow_imp.id(1012190707631040880)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012189738083040880)
,p_name=>'toggle items themen'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_REGION_THEMEN'
,p_condition_element=>'P140_REGION_THEMEN'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012189392745040880)
,p_name=>'enter im Q Themensuchfeld'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_Q_THEMA_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012188849255040880)
,p_event_id=>wwv_flow_imp.id(1012189392745040880)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012188510663040879)
,p_name=>'enter im Z Themensuchfeld'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_Z_THEMA_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012187923824040879)
,p_event_id=>wwv_flow_imp.id(1012188510663040879)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012187563384040879)
,p_name=>'toggle items suche'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_REGION_SEARCH_REPLACE'
,p_condition_element=>'P140_REGION_SEARCH_REPLACE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012187036316040879)
,p_event_id=>wwv_flow_imp.id(1012187563384040879)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3818624194781662500)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012186577098040879)
,p_event_id=>wwv_flow_imp.id(1012187563384040879)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3818624194781662500)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012186105104040878)
,p_event_id=>wwv_flow_imp.id(1012187563384040879)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3818624710496662505)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012185543474040878)
,p_event_id=>wwv_flow_imp.id(1012187563384040879)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3818624710496662505)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012185188579040878)
,p_name=>'refresh search preview'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1012209881913040909)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012184623808040878)
,p_event_id=>wwv_flow_imp.id(1012185188579040878)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3818624710496662505)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012184233297040878)
,p_name=>'ACTION_SEARCH_PARAM_CHANGED'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_TEXT_ATTRIBUT,P140_REGEX_PLAIN,P140_SEARCH_TEXT,P140_REPLACE_TEXT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012183817479040877)
,p_name=>'A_RESET_SUE'
,p_event_sequence=>170
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1012210224783040910)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012183329333040877)
,p_event_id=>wwv_flow_imp.id(1012183817479040877)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P140_SEARCH_TEXT,P140_REPLACE_TEXT,P140_TEXT_ATTRIBUT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012182884340040877)
,p_event_id=>wwv_flow_imp.id(1012183817479040877)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3818624710496662505)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012182436778040877)
,p_name=>'toggle items Lead_VKO'
,p_event_sequence=>180
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_REGION_LEAD_VKO'
,p_condition_element=>'P140_REGION_LEAD_VKO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012181958351040877)
,p_event_id=>wwv_flow_imp.id(1012182436778040877)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1723906261715940990)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012181484416040877)
,p_event_id=>wwv_flow_imp.id(1012182436778040877)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P140_LEAD_VKO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012180928791040876)
,p_event_id=>wwv_flow_imp.id(1012182436778040877)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1723906261715940990)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012180432283040876)
,p_event_id=>wwv_flow_imp.id(1012182436778040877)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P140_LEAD_VKO'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012180100363040876)
,p_name=>unistr('enter im L\00E4ndersuchfeld')
,p_event_sequence=>190
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_LAND_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012179546087040876)
,p_event_id=>wwv_flow_imp.id(1012180100363040876)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012179161878040876)
,p_name=>'toggle items laender_add'
,p_event_sequence=>200
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_REGION_LAENDER_ADD'
,p_condition_element=>'P140_REGION_LAENDER_ADD'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012178708606040876)
,p_event_id=>wwv_flow_imp.id(1012179161878040876)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1720042701302566484)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012178166205040875)
,p_event_id=>wwv_flow_imp.id(1012179161878040876)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1720042701302566484)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012177736574040875)
,p_name=>'enter im Themensuchfeld'
,p_event_sequence=>210
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_THEMA_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012177255387040875)
,p_event_id=>wwv_flow_imp.id(1012177736574040875)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P140_THEMA_PRE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012176742134040875)
,p_event_id=>wwv_flow_imp.id(1012177736574040875)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'loadThemenShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012176365079040875)
,p_name=>'toggle items Themen_add'
,p_event_sequence=>220
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_REGION_THEMEN_ADD'
,p_condition_element=>'P140_REGION_THEMEN_ADD'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012175909327040874)
,p_event_id=>wwv_flow_imp.id(1012176365079040875)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1720044010867566497)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012175352713040874)
,p_event_id=>wwv_flow_imp.id(1012176365079040875)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1720044010867566497)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012174991561040874)
,p_name=>unistr('enter im Themasuchfield zum l\00F6schen')
,p_event_sequence=>230
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_THEMA_PRE_DEL'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012174463646040874)
,p_event_id=>wwv_flow_imp.id(1012174991561040874)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P140_THEMA_PRE_DEL'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012174109624040874)
,p_name=>'toggle_region Themen delete'
,p_event_sequence=>240
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_REGION_THEMEN_DELETE'
,p_condition_element=>'P140_REGION_THEMEN_DELETE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012173520300040874)
,p_event_id=>wwv_flow_imp.id(1012174109624040874)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1720045237832566510)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012173042854040873)
,p_event_id=>wwv_flow_imp.id(1012174109624040874)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1720045237832566510)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012172707837040873)
,p_name=>'Enter im  Thema_del Suchfeld'
,p_event_sequence=>250
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_THEMA_DEL_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012172170060040873)
,p_event_id=>wwv_flow_imp.id(1012172707837040873)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P140_THEMA_DEL_PRE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012171711146040873)
,p_event_id=>wwv_flow_imp.id(1012172707837040873)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadThemenDelShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1012171248393040873)
,p_name=>unistr('Change L\00E4ndergruppen Filter')
,p_event_sequence=>260
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_LAENDERGRUPPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1012170762504040872)
,p_event_id=>wwv_flow_imp.id(1012171248393040873)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1012194148036040889)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_ATTRIBUTE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  result boolean;',
'begin',
' -- debug(''mehrfachbearbeitung'', ''attribute'');',
'  result := pck_ri.fChangeVorschriftenAttribut(:P140_SELECTED_VORSCHRIFTEN, :P140_VORSCHRIFT_BEZEICHNUNG, ',
'        :P140_BEMERKUNG, :P140_FREIGABESTATUS, :P140_EINSATZDATUM_MODELL,',
'        :P140_PROGNOSE_QUALITAET, :P140_HOMOLOGATION, :P140_VORSCHRIFT_STATUS, :P140_RXSWIN);',
'        ',
'  result := pck_ri.fChangeVorschriftenAttributFahrzeugklasse(:P140_SELECTED_VORSCHRIFTEN , :P140_FAHRZEUGKLASSE);',
'  result := pck_ri.fChangeVorschriftenAttributMaster(:P140_SELECTED_VORSCHRIFTEN , :P140_MASTER);     ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1012229736879040967)
,p_process_when=>'P140_REGION_ATTRIBUTE'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1'
,p_process_success_message=>unistr('\00C4nderungen wurden \00FCbernommen.')
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_internal_uid=>2660018167863347346
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1012193735942040889)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_LINK'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  result boolean;',
'begin',
'  --debug(''mehrfachbearbeitung'', ''links'');',
'  result := pck_ri.fChangeVorschriftenLinks(:P140_SELECTED_VORSCHRIFTEN, :P140_LINK_GETEX, ',
'        :P140_LINK_DMS, :P140_WEBSITE, :P140_WEBSITE_LINK);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1012229736879040967)
,p_process_when=>'P140_REGION_WEBSITES'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1'
,p_process_success_message=>unistr('\00C4nderungen wurden \00FCbernommen.')
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_internal_uid=>2660018579957347346
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1012198147398040893)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ADD_LAENDER'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  result boolean;',
'begin',
'  --debug(''mehrfachbearbeitung'', '' Add Laender'');',
'  result := pck_ri.fAddLaenderToVorschriften(:P140_SELECTED_VORSCHRIFTEN, ',
'                                               :P140_LAENDER_ADDED);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1012229736879040967)
,p_process_when=>'P140_REGION_LAENDER_ADD'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_internal_uid=>2660014168501347342
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1012197741830040892)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ADD_THEMEN'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  result boolean;',
'begin',
'  --debug(''mehrfachbearbeitung'', '' Add Laender'');',
'  result := pck_ri.fAddThemenToVorschriften(:P140_SELECTED_VORSCHRIFTEN, ',
'                                               :P140_THEMEN_ADDED);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1012229736879040967)
,p_process_when=>'P140_REGION_THEMEN_ADD'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_internal_uid=>2660014574069347343
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1012197345593040891)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DELETE_THEMEN_ZUORDNUNG'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE  T_VORSCHRIFT_REF_THEMA SET geloescht =1',
'    where vorschriftID in  (select y.column_value',
'                            from table(apex_string.split_numbers(:P140_SELECTED_VORSCHRIFTEN, '':'')) y)',
'    and geloescht =0',
'    and themaid  in (select column_value  from table(apex_string.split_numbers(:P140_THEMEN_DELETE, '':'')));'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1012229736879040967)
,p_process_when=>'P140_REGION_THEMEN_DELETE'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_internal_uid=>2660014970306347344
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1012194915919040889)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SUCHEN_UND_ERSETZEN'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'     lResult number;',
'begin',
'',
'lResult := PCK_RI.fSearchAndReplaceVorschriftenAttribut(aListVorschriftId => :P140_SELECTED_VORSCHRIFTEN, ',
'                                             aAttribut => :P140_TEXT_ATTRIBUT, ',
'                                             aPlainRegexReplace => :P140_REGEX_PLAIN, ',
'                                             aSearchText => :P140_SEARCH_TEXT, ',
'                                             aReplaceText => :P140_REPLACE_TEXT);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1012229736879040967)
,p_process_when=>'P140_REGION_SEARCH_REPLACE'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1'
,p_process_success_message=>unistr('\00C4nderungen wurden \00FCbernommen.')
,p_internal_uid=>2660017399980347346
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1012194615035040889)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'refresh cockpit'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri_cockpit_refresh.pTriggerRefresh;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2660017700864347346
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1012195797856040890)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_Lead_VKO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if(:P140_LEAD_VKO is not null) then',
'    update t_Vorschrift set lead_vko_benutzerid = :P140_LEAD_VKO, REVISIONSZAEHLER = REVISIONSZAEHLER + 1',
'     where vorschriftid in (',
'          select column_value from table (apex_string.split_numbers(:P140_SELECTED_VORSCHRIFTEN, '':'') )',
'        );',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1012229736879040967)
,p_process_when=>'P140_REGION_LEAD_VKO'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1'
,p_internal_uid=>2660016518043347345
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1012195335333040890)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'load selected vorschriften'
,p_process_sql_clob=>':P140_SELECTED_VORSCHRIFTEN := :P20_SELECTED_ROWS;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2660016980566347345
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1012196943751040891)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadThemenDelShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    --lLaendergruppe number := apex_application.g_x02;',
'    lTextfilter varchar2(2000) := apex_application.g_x02;',
'    lSelectedVorschr varchar2(2000) := apex_application.g_x03;',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    for l in (',
'        select  vt.nummer||'' '' || vt.bezeichnung as d, vt.themaid as themaid, thema_sortorder',
'        from v_thema_baum vt',
'        where vt.themaid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))        ',
'',
'        and ( lTextfilter is null',
'            or instr(upper(vt.nummer||'' '' || vt.bezeichnung),upper(lTextFilter)) != 0',
'        )',
'       -- and vt.themaid in (select themaid from t_vorschrift_ref_thema ',
'        --                    where vorschriftid in (select column_value from table(apex_string.split_numbers(lSelectedVorschr,'':'')) )',
'       --                       and geloescht !=1)',
'        order by  thema_sortorder        ',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.themaid);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2660015372148347344
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1012196119070040890)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadThemenShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 21.05.2024',
'DECLARE',
'    lSelectedThemen varchar2(2000) := apex_application.g_x01;',
'    lTextfilter varchar2(2000) := apex_application.g_x02;',
'    lSelectedVorschr varchar2(2000) := apex_application.g_x03;',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    --debug(''p140_AJax, lSelectedVorschr:''|| lSelectedVorschr);',
'    for th in (',
'           select  vt.nummer||'' '' || vt.bezeichnung as d, vt.themaid as themaid, thema_sortorder',
'             from v_thema_baum vt',
'            where vt.themaid not in (select column_value from table (apex_string.split_numbers(lSelectedThemen,'':'')) where column_value is not null )        ',
'',
'            and ( lTextfilter is null',
'                or instr(upper(vt.nummer||'' '' || vt.bezeichnung), upper(lTextFilter)) != 0',
'            )',
'            and vt.themaid not in (select themaid from t_vorschrift_ref_thema ',
'                            where vorschriftid in (select column_value from table(apex_string.split_numbers(lSelectedVorschr,'':'')) )',
'                              and geloescht !=1)',
'            order by  thema_sortorder        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',th.d);',
'        apex_json.write(''r'',th.themaid);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_success_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 21.05.2024',
'DECLARE',
'    lSelectedThemen varchar2(2000) := apex_application.g_x01;',
'    lTextfilter varchar2(2000) := apex_application.g_x02;',
'    lSelectedVorschr varchar2(2000) := apex_application.g_x03;',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    --debug(''p140_AJax, lSelectedVorschr:''|| lSelectedVorschr);',
'    for th in (',
'           select  vt.nummer||'' '' || vt.bezeichnung as d, vt.themaid as themaid, thema_sortorder',
'             from v_thema_baum vt',
'            where vt.themaid not in (select column_value from table (apex_string.split_numbers(lSelectedThemen,'':'')) where column_value is not null )        ',
'',
'            and ( lTextfilter is null',
'                or instr(upper(vt.nummer||'' '' || vt.bezeichnung), upper(lTextFilter)) != 0',
'            )',
'            and vt.themaid not in (select themaid from t_vorschrift_ref_thema ',
'                            where vorschriftid in (select column_value from table(apex_string.split_numbers(lSelectedVorschr,'':'')) )',
'                              and geloescht !=1)',
'            order by  thema_sortorder        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',th.d);',
'        apex_json.write(''r'',th.themaid);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'',
'END;',
''))
,p_internal_uid=>2660016196829347345
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1012196608175040891)
,p_process_sequence=>30
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLaenderShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelectedLaender varchar2(2000) := apex_application.g_x01;',
'    lTextfilter varchar2(2000) := apex_application.g_x02;',
'    lSelectedVorschr varchar2(2000) := apex_application.g_x03;',
'    lLaendergruppe number := apex_application.g_x04;',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    for la in (',
'        select  l.b_nummer||'' '' || l.land as d,   l.landid as landid',
'        from t_land l',
'        where l.landid not in (select column_value from table(apex_string.split_numbers(lSelectedLaender,'':'')) where column_value is not null)        ',
'',
'        and ( lTextfilter is null',
'            or instr(upper(l.b_nummer||'' '' || l.land), upper(lTextFilter)) != 0',
'        )',
'        and ( lLaendergruppe is null',
'               or l.landid in (',
'                              select landid from t_land_ref_laendergruppe where laendergruppeid in (',
'                                 select column_value from table(apex_string.split_numbers(lLaendergruppe,'':''))',
'                                 )',
'                            )',
'        )',
'        --and l.landid not in (select landid from t_vorschrift_ref_land ',
'         --                   where vorschriftid in (select column_value from table(apex_string.split_numbers(lSelectedVorschr,'':'')) )',
'         --                     and geloescht !=1)',
'         order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'')   -- order by  l.land    ',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',la.d);',
'        apex_json.write(''r'',la.landid);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2660015707724347344
);
wwv_flow_imp.component_end;
end;
/
