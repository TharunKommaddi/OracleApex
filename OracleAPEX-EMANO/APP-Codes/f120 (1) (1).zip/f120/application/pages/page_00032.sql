prompt --application/pages/page_00032
begin
--   Manifest
--     PAGE: 00032
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>32
,p_name=>'Lead VKO'
,p_alias=>'LEAD-VKO'
,p_page_mode=>'MODAL'
,p_step_title=>'Lead VKO'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'600'
,p_dialog_width=>'600'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16944978459182346150)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1019072645920183630)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(16944978459182346150)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1019072306683183628)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(16944978459182346150)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019071816820183627)
,p_name=>'P32_VORSCHRIFTID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019071448804183627)
,p_name=>'P32_VORSCHRIFT_TYPID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019071077901183627)
,p_name=>'P32_VORSCHRIFT_NUMMER_DISPLAY'
,p_item_sequence=>40
,p_prompt=>'Vorschrift Nummer'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019070653758183627)
,p_name=>'P32_PARENT_VORSCHRIFT_DISPLAY'
,p_item_sequence=>50
,p_prompt=>unistr('\00DCbergeordnete Vorschrift')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P32_VORSCHRIFT_TYPID'
,p_display_when2=>'20'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1019070285429183627)
,p_name=>'P32_LEAD_VKO'
,p_item_sequence=>60
,p_prompt=>'Lead VKO'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with vko_land as (',
unistr('    -- F\00FCr jeden VKO ermitteln, f\00FCr welche L\00E4nder er zust\00E4ndig ist'),
'    select distinct  arb.benutzerid benutzerid, arb.et_b_akid et_b_akid, nvl(arb.Land_independent,0) land_independent, avrl.landid, arb.lead_vko, ET_B_AK_REF_BENUTZERID',
'    from T_ET_B_AK_REF_BENUTZER arb',
'    left outer join t_et_b_ak_vko_ref_land avrl on (avrl.et_b_ak_vkoid = arb.ET_B_AK_REF_BENUTZERID)',
'), v_land as (',
unistr('    -- L\00E4nder, die der Vorschrift zugeordnet sind'),
'    Select distinct vrtl.vorschriftid vorschriftid, vrtl.landid',
'    from T_VORSCHRIFT_REF_LAND  vrtl',
'    where vrtl.geloescht = 0 and vrtl.vorschriftid = :P32_VORSCHRIFTID',
'), vko_themen as (',
'    -- Die zugeordneten Themen der VKOs ermitteln',
'    select arb.benutzerid, arb.et_b_ak_ref_benutzerid, case when avrt.themaid is null then 1 else 0 end as themen_unabhaengig, avrt.themaid,',
'    arb.et_b_akid',
'    from t_et_b_ak_ref_benutzer arb',
'    left outer join t_et_b_ak_vko_ref_thema avrt on (avrt.et_b_ak_vkoid = arb.et_b_ak_ref_benutzerid)',
'), vko_themen2 as (',
'    -- Die Themen der VKOs mit den Themen der Vorschrift abgleichen',
'    select distinct v1.benutzerid, v1.et_b_ak_ref_benutzerid, v1.et_b_akid',
'    from vko_themen v1',
'    join t_vorschrift_ref_thema vrt on (v1.themaid = vrt.themaid or v1.themen_unabhaengig = 1)',
'    where vrt.vorschriftid = :P32_VORSCHRIFTID and vrt.geloescht = 0',
')',
' select distinct   d,   r from',
'(',
'    select  distinct  b.Nachname ||'', ''||b.Vorname || '' (''||b.Abteilung || '')'' as d,   b.benutzerid r',
'    FROM T_VORSCHRIFT_REF_ET_B_AK vra',
'          join t_et_b_ak ak on (vra.et_b_akid = ak.et_b_akid)',
'         left join vko_themen2 t2 on (t2.et_b_akid = vra.et_b_akid)',
'         left outer join t_benutzer b on (t2.benutzerid = b.benutzerid)',
'           where vra.vorschriftid = :P32_VORSCHRIFTID and vra.geloescht = 0 ',
'           and instr(UPPER(:P32_VORSCHRIFT_NUMMER_DISPLAY), ''UN-R'')>0  and b.benutzerid is not null ',
'   union all',
'    select distinct  b.Nachname ||'', ''||b.Vorname || '' (''||b.Abteilung || '')'' as d,  b.benutzerid r ',
unistr('   -- mit l\00E4nder'),
'    FROM T_VORSCHRIFT_REF_ET_B_AK vra',
'    join t_et_b_ak ak on (vra.et_b_akid = ak.et_b_akid)',
'    left outer join v_land l on (vra.vorschriftid = l.vorschriftid)',
'    left outer join vko_land vl on (vra.et_b_akid = vl.et_b_akid and (vl.land_independent = 1 or l.landid = vl.landid))',
'    left outer join t_benutzer b on (vl.benutzerid = b.benutzerid)',
'    where vra.vorschriftid = :P32_VORSCHRIFTID and vra.geloescht = 0 and vl.benutzerid is not null',
'    and (vl.benutzerid in (select benutzerid from vko_themen2) )',
'   union ',
'    select  distinct  b.Nachname ||'', ''||b.Vorname || '' (''||b.Abteilung || '')'' as d, lead_vko_benutzerid AS r ',
'      from t_vorschrift v',
'      join t_benutzer b on (b.benutzerid = v.lead_vko_benutzerid)',
'    where v.vorschriftid =:P32_VORSCHRIFTID',
'    --select  distinct  bezeichnung as d,  benutzerid r',
'  --FROM V_VORSCHRIFT_VKO where vorschriftid = :P32_VORSCHRIFTID',
')  ',
'  order by 1;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- ausw\00E4hlen --')
,p_lov_cascade_parent_items=>'P32_VORSCHRIFTID,P32_VORSCHRIFT_NUMMER_DISPLAY,P32_PARENT_VORSCHRIFT_DISPLAY'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>':P32_VORSCHRIFT_TYPID in (10,30,40)'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'P39_EDIT_MODE',
'',
'1',
'',
'itme ! = value',
'',
'',
'',
'srver ',
'',
':P39_VORSCHRIFT_TYPID in (10,30,40)',
'',
'',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1019068681293183618)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1019072645920183630)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1019068214790183613)
,p_event_id=>wwv_flow_imp.id(1019068681293183618)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1019069866857183626)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update LEAD_VKO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Purpose: Update the lead_vko_benutzerid in T_VORSCHRIFT for the current Vorschrift',
'--          Only performs the UPDATE if the selected value is different from the current value.',
'DECLARE',
'  l_current_lead_vko t_vorschrift.lead_vko_benutzerid%TYPE;',
'  l_new_lead_vko     t_vorschrift.lead_vko_benutzerid%TYPE;',
'  l_vorschriftid     t_vorschrift.vorschriftid%TYPE := :P32_VORSCHRIFTID;',
'BEGIN',
'  IF l_vorschriftid IS NULL THEN',
'     apex_debug.error(''P32 Save: P32_VORSCHRIFTID is NULL, cannot save.'');',
'     -- Optionally raise an error or add an APEX error message',
'     RETURN;',
'  END IF;',
'',
'  -- Get the new value selected in the dialog''s LOV/Select List',
'  -- Convert to number, handling potential non-numeric values or null string from select list',
'  BEGIN',
'     l_new_lead_vko := TO_NUMBER(:P32_LEAD_VKO);',
'  EXCEPTION',
'     WHEN OTHERS THEN',
'       l_new_lead_vko := NULL; -- Treat invalid selection as NULL',
'       apex_debug.warn(''P32 Save: P32_LEAD_VKO was not a valid number: '' || :P32_LEAD_VKO);',
'  END;',
'',
'  -- Get current value from DB to prevent unnecessary update',
'  SELECT lead_vko_benutzerid',
'  INTO l_current_lead_vko',
'  FROM t_vorschrift',
'  WHERE vorschriftid = l_vorschriftid;',
'',
'  -- Compare new value with current DB value, handling NULLs carefully.',
'  -- Update only if the value has actually changed.',
'  -- Using different placeholder numbers for NVL avoids issues if -999 were a valid ID.',
'  IF NVL(l_current_lead_vko, -999) != NVL(l_new_lead_vko, -998) THEN',
'     apex_debug.message(''P32: Updating Lead VKO for VorschriftID %s from %s to %s'', l_vorschriftid, l_current_lead_vko, l_new_lead_vko);',
'',
'     UPDATE t_vorschrift',
'     SET lead_vko_benutzerid = l_new_lead_vko',
'        ',
'     WHERE vorschriftid = l_vorschriftid;',
'',
'     -- success message',
'     apex_application.g_print_success_message := ''Lead VKO updated successfully.'';',
'',
'  ELSE',
'     apex_debug.message(''P32: Lead VKO unchanged for VorschriftID %s. No update performed.'', l_vorschriftid);',
'     NULL; -- No change, do nothing',
'  END IF;',
'',
'EXCEPTION',
'  WHEN NO_DATA_FOUND THEN',
'     apex_debug.error(''P32 Save: Vorschrift ID %s not found.'', l_vorschriftid);',
'     apex_error.add_error (',
'          p_message          => ''Error saving: Regulation not found.'',',
'          p_display_location => apex_error.c_inline_in_notification );',
'  WHEN OTHERS THEN',
'    apex_debug.error(''P32 Save Error: %s'', SQLERRM);',
'    apex_error.add_error (',
'          p_message          => ''An unexpected error occurred while saving.'',',
'          p_display_location => apex_error.c_inline_in_notification );',
'    -- Consider whether to RAISE here depending on desired error handling',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1019072306683183628)
,p_internal_uid=>2653142449042204609
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'   UPDATE t_vorschrift',
'      SET lead_vko_benutzerid = :P32_LEAD_VKO',
'    WHERE vorschriftid = :P32_VORSCHRIFTID;',
'END;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1019069500739183618)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1019072306683183628)
,p_internal_uid=>2653142815160204617
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1019069097326183618)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Lead VKO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Purpose: Fetch details for display and set default for LOV on page 32',
'BEGIN',
'  IF :P32_VORSCHRIFTID IS NOT NULL THEN',
'     -- Fetch Vorschrift Number and current Lead VKO',
'     SELECT vorschrift_nummer, lead_vko_benutzerid',
'     INTO :P32_VORSCHRIFT_NUMMER_DISPLAY, :P32_LEAD_VKO',
'     FROM t_vorschrift',
'     WHERE vorschriftid = :P32_VORSCHRIFTID;',
'',
'     -- Fetch Parent Vorschrift details ONLY if Type is Supplement (passed as P32_VORSCHRIFT_TYPID)',
'     IF :P32_VORSCHRIFT_TYPID = 20 THEN',
'        BEGIN',
'           SELECT vv.vorschrift_nummer || '' - '' || vv.vorschrift_bezeichnung',
'           INTO :P32_PARENT_VORSCHRIFT_DISPLAY',
'           FROM t_vorschrift_ref_vorschrift vrv',
'           JOIN t_vorschrift vv ON vrv.vorgaenger_vorschriftid = vv.vorschriftid',
'           WHERE vrv.nachfolger_vorschriftid = :P32_VORSCHRIFTID',
'             AND vrv.beziehung_art = 30 -- 30 is Supplement relationship type',
'           FETCH FIRST ROW ONLY;',
'        EXCEPTION',
'           WHEN NO_DATA_FOUND THEN',
'              :P32_PARENT_VORSCHRIFT_DISPLAY := NULL;',
'        END;',
'     ELSE',
'        :P32_PARENT_VORSCHRIFT_DISPLAY := NULL;',
'     END IF;',
'',
'  ELSE',
'     -- If no VorschriftID is passed, clear items',
'     :P32_VORSCHRIFT_NUMMER_DISPLAY := NULL;',
'     :P32_LEAD_VKO := NULL;',
'     :P32_PARENT_VORSCHRIFT_DISPLAY := NULL;',
'  END IF;',
'',
'EXCEPTION',
'   WHEN NO_DATA_FOUND THEN',
'      -- Handle case where P32_VORSCHRIFTID might be invalid if needed',
'      apex_debug.warn(''P32 Load Details: Vorschrift ID not found: '' || :P32_VORSCHRIFTID);',
'      :P32_VORSCHRIFT_NUMMER_DISPLAY := NULL;',
'      :P32_LEAD_VKO := NULL;',
'      :P32_PARENT_VORSCHRIFT_DISPLAY := NULL;',
'   WHEN OTHERS THEN',
'      apex_debug.error(''P32 Load Details Error: '' || SQLERRM);',
'      RAISE; -- Re-raise exception',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2653143218573204617
);
wwv_flow_imp.component_end;
end;
/
