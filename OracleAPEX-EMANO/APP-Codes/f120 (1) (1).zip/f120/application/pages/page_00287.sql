prompt --application/pages/page_00287
begin
--   Manifest
--     PAGE: 00287
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>287
,p_name=>'Demands Cockpit'
,p_alias=>'DEMANDS-COCKPIT'
,p_step_title=>'Demands Cockpit'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(952959408122997288)
,p_plug_name=>'Demands Cockpit'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'       vdc.V,',
'       -- clickable Vorschrift Nummer link for V',
'       ''<a href="'' || apex_page.get_url(',
'           p_page => 25, ',
'           p_clear_cache => 25, ',
'           p_items => ''P25_VORSCHRIFTID'', ',
'           p_values => vdc.V',
'       ) || ''" target="_blank">'' || tv.vorschrift_nummer || ''</a>'' as VORSCHRIFT_NUMMER,',
'       ',
'       vdc.V_VKN,',
'       -- clickable link for V_VKN (via vorschrift_ref_vorschrift)',
'       CASE ',
'           WHEN vdc.V_VKN IS NOT NULL AND vrf_vkn.vorgaenger_vorschriftid IS NOT NULL THEN',
'               ''<a href="'' || apex_page.get_url(',
'                   p_page => 25, ',
'                   p_clear_cache => 25, ',
'                   p_items => ''P25_VORSCHRIFTID'', ',
'                   p_values => vrf_vkn.vorgaenger_vorschriftid',
'               ) || ''" target="_blank">'' || tv_vkn.vorschrift_nummer || ''</a>''',
'           ELSE NULL',
'       END as V_VKN_NUMMER,',
'       ',
'       vdc.V_RR,',
'       -- clickable link for V_RR',
'       ''<a href="'' || apex_page.get_url(',
'           p_page => 25, ',
'           p_clear_cache => 25, ',
'           p_items => ''P25_VORSCHRIFTID'', ',
'           p_values => vdc.V_RR',
'       ) || ''" target="_blank">'' || tv_rr.vorschrift_nummer || ''</a>'' as V_RR_NUMMER,',
'       ',
'       vdc.V_RR_VKN,',
'       -- clickable link for V_RR_VKN (via vorschrift_ref_vorschrift)',
'       CASE ',
'           WHEN vdc.V_RR_VKN IS NOT NULL AND vrf_rr_vkn.vorgaenger_vorschriftid IS NOT NULL THEN',
'               ''<a href="'' || apex_page.get_url(',
'                   p_page => 25, ',
'                   p_clear_cache => 25, ',
'                   p_items => ''P25_VORSCHRIFTID'', ',
'                   p_values => vrf_rr_vkn.vorgaenger_vorschriftid',
'               ) || ''" target="_blank">'' || tv_rr_vkn.vorschrift_nummer || ''</a>''',
'           ELSE NULL',
'       END as V_RR_VKN_NUMMER,',
'       ',
'       vdc.PATH,',
'       -- clickable links for PATH',
'       (',
'           SELECT LISTAGG(',
'               ''<a href="'' || apex_page.get_url(',
'                   p_page => 25, ',
'                   p_clear_cache => 25, ',
'                   p_items => ''P25_VORSCHRIFTID'', ',
'                   p_values => TRIM(column_value)',
'               ) || ''" target="_blank">'' || ',
'               (SELECT vorschrift_nummer FROM t_vorschrift WHERE vorschriftid = TO_NUMBER(TRIM(column_value))) || ',
'               ''</a>'', ',
unistr('               '' \2192 '''),
'           ) WITHIN GROUP (ORDER BY ROWNUM desc)',
'           FROM TABLE(apex_string.split(substr(vdc.PATH,2), '',''))',
'       ) as PATH_LINKS,',
'       liste_themen,',
'       liste_laender,',
'       length(path)-length(replace(path,'','')) as laenge_path,',
'       vrf_vkn.datum_neue_typen, vrf_vkn.datum_alle_typen',
'       ',
'FROM V_DEMANDS_COCKPIT vdc',
'LEFT JOIN t_vorschrift tv ON tv.vorschriftid = vdc.V',
'LEFT JOIN t_vorschrift_ref_vorschrift vrf_vkn ON vrf_vkn.vorschrift_ref_vorschriftid = vdc.V_VKN',
'LEFT JOIN t_vorschrift tv_vkn ON tv_vkn.vorschriftid = vrf_vkn.vorgaenger_vorschriftid',
'LEFT JOIN t_vorschrift tv_rr ON tv_rr.vorschriftid = vdc.V_RR',
'LEFT JOIN t_vorschrift_ref_vorschrift vrf_rr_vkn ON vrf_rr_vkn.vorschrift_ref_vorschriftid = vdc.V_RR_VKN',
'LEFT JOIN t_vorschrift tv_rr_vkn ON tv_rr_vkn.vorschriftid = vrf_rr_vkn.vorgaenger_vorschriftid',
'outer apply (',
'    select listagg(t.nummer,'', '') within group (order by t.nummer) liste_themen',
'    from t_vorschrift_ref_thema vrt',
'    join t_thema t on (vrt.themaid = t.themaid)',
'    where vrt.vorschriftid = vdc.v and vrt.geloescht = 0',
')',
'outer apply (',
'    select listagg(l.b_nummer,'', '') within group (order by l.b_nummer) liste_laender',
'    from t_vorschrift_ref_land vrl',
'    join t_land l on (vrl.landid = l.landid)',
'    where vrl.vorschriftid = vdc.v_rr and vrl.geloescht = 0',
')'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Demands Cockpit'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column_group(
 p_id=>wwv_flow_imp.id(953861604760016109)
,p_heading=>'Vorschrift'
);
wwv_flow_imp_page.create_region_column_group(
 p_id=>wwv_flow_imp.id(953861511428016108)
,p_heading=>'Rahmenrichtlinie'
);
wwv_flow_imp_page.create_region_column_group(
 p_id=>wwv_flow_imp.id(953861114775016104)
,p_heading=>'Pfad'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(953862609329016119)
,p_name=>'V'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'V'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'ID'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>10
,p_value_alignment=>'RIGHT'
,p_group_id=>wwv_flow_imp.id(953861604760016109)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(953862451841016118)
,p_name=>'VORSCHRIFT_NUMMER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VORSCHRIFT_NUMMER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Nummer'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(953861604760016109)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(953862323406016117)
,p_name=>'V_VKN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'V_VKN'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(953862283114016116)
,p_name=>'V_VKN_NUMMER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'V_VKN_NUMMER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(953862152135016115)
,p_name=>'V_RR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'V_RR'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'ID'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_group_id=>wwv_flow_imp.id(953861511428016108)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(953862045896016114)
,p_name=>'V_RR_NUMMER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'V_RR_NUMMER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Nummer'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(953861511428016108)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(953862008719016113)
,p_name=>'V_RR_VKN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'V_RR_VKN'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(953861821889016112)
,p_name=>'V_RR_VKN_NUMMER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'V_RR_VKN_NUMMER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>90
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(953861759095016111)
,p_name=>'PATH'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PATH'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Pfad'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(953861114775016104)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(953861673160016110)
,p_name=>'PATH_LINKS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PATH_LINKS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Links'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(953861114775016104)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML')).to_clob
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(953861367291016107)
,p_name=>'LISTE_THEMEN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LISTE_THEMEN'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Themen'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(953861604760016109)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(953861231545016106)
,p_name=>'LISTE_LAENDER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LISTE_LAENDER'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('L\00E4nder')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(953861511428016108)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(953861211856016105)
,p_name=>'LAENGE_PATH'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAENGE_PATH'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('L\00E4nge')
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>130
,p_value_alignment=>'RIGHT'
,p_group_id=>wwv_flow_imp.id(953861114775016104)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(953860951736016103)
,p_name=>'DATUM_NEUE_TYPEN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DATUM_NEUE_TYPEN'
,p_data_type=>'DATE'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Datum Neue Typen'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>150
,p_value_alignment=>'CENTER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(953860852172016102)
,p_name=>'DATUM_ALLE_TYPEN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DATUM_ALLE_TYPEN'
,p_data_type=>'DATE'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Datum Alle Typen'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>140
,p_value_alignment=>'CENTER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(953862715609016120)
,p_internal_uid=>2718349600290372115
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(950276709954445799)
,p_interactive_grid_id=>wwv_flow_imp.id(953862715609016120)
,p_static_id=>'27219357'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(950276514648445797)
,p_report_id=>wwv_flow_imp.id(950276709954445799)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3672211224959370939)
,p_view_id=>wwv_flow_imp.id(950276514648445797)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(953861367291016107)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3672206517760350418)
,p_view_id=>wwv_flow_imp.id(950276514648445797)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(953861231545016106)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(3672205532078350415)
,p_view_id=>wwv_flow_imp.id(950276514648445797)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(953861211856016105)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>55.521000000000015
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(950275943085445788)
,p_view_id=>wwv_flow_imp.id(950276514648445797)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(953862609329016119)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>68
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(950275180471445776)
,p_view_id=>wwv_flow_imp.id(950276514648445797)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(953862451841016118)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(950274238662445772)
,p_view_id=>wwv_flow_imp.id(950276514648445797)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(953862323406016117)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(950273362854445769)
,p_view_id=>wwv_flow_imp.id(950276514648445797)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(953862283114016116)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(950272418641445767)
,p_view_id=>wwv_flow_imp.id(950276514648445797)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(953862152135016115)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>59
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(950271556512445764)
,p_view_id=>wwv_flow_imp.id(950276514648445797)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(953862045896016114)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(950270668569445760)
,p_view_id=>wwv_flow_imp.id(950276514648445797)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(953862008719016113)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(950269754325445757)
,p_view_id=>wwv_flow_imp.id(950276514648445797)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(953861821889016112)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(950268856865445754)
,p_view_id=>wwv_flow_imp.id(950276514648445797)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(953861759095016111)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>194.52100000000002
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(950268001340445751)
,p_view_id=>wwv_flow_imp.id(950276514648445797)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(953861673160016110)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>552.812
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(950243754435352060)
,p_view_id=>wwv_flow_imp.id(950276514648445797)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(953860951736016103)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>378.802
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(950242860351352057)
,p_view_id=>wwv_flow_imp.id(950276514648445797)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(953860852172016102)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp.component_end;
end;
/
