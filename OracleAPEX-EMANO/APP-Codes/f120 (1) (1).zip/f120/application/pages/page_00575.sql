prompt --application/pages/page_00575
begin
--   Manifest
--     PAGE: 00575
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>575
,p_name=>'JiraTicket Erstellt'
,p_alias=>'JIRATICKET-ERSTELLT'
,p_page_mode=>'MODAL'
,p_step_title=>'JiraTicket Erstellt'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'400'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10107260713806685934)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(637561291400734979)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10107260770320685934)
,p_plug_name=>'JiraTicket Erstellt'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10107260906852685934)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1005997812789048637)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10107260906852685934)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1005997386194048636)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(10107260906852685934)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ticket erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1005997008677048636)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(10107260906852685934)
,p_button_name=>'New'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Beenden'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1005996574495048636)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10107260906852685934)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1006140190949638714)
,p_branch_name=>'Go To Status Page'
,p_branch_action=>'f?p=&APP_ID.:576:&SESSION.::&DEBUG.:576:P576_JIRA_POST_ID:&P575_JIRA_POST_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1005997386194048636)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1005993520043048633)
,p_branch_action=>'f?p=&APP_ID.:574:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1005996574495048636)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1005993981822048634)
,p_branch_name=>'CIP_AUFRUF'
,p_branch_action=>'P575_LINK'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'BRANCH_TO_URL_IDENT_BY_ITEM'
,p_branch_sequence=>20
,p_branch_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006140247739638715)
,p_name=>'P575_JIRA_POST_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(10107260770320685934)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1005998847454048637)
,p_name=>'P575_LINK'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10107260770320685934)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select q''#javascript:var x = window.open(''#''||',
'PCK_CIP_JIRA.fCreateJiraUrlAssistent(:P572_MASTER_VORSCHRIFTID, :P570_MFV_TYP,:P571_AK_SEL,:P573_STICHWORT_SEL, :P572_VORSCHRIFTEN_SEL,:P574_MFVID, :P581_MFVS, :P582_COCOA) ||',
'q''#'',''_blank'')#'' as l',
'from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1005998509325048637)
,p_name=>'P575_LINK_DISPLAY'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(10107260770320685934)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zum CIP Jira'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select ',
'PCK_CIP_JIRA.fCreateJiraUrlAssistent(:P572_MASTER_VORSCHRIFTID, :P570_MFV_TYP,:P571_AK_SEL,:P573_STICHWORT_SEL, :P572_VORSCHRIFTEN_SEL,:P574_MFVID, :P581_MFVS, :P582_COCOA) as l',
'from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'itme in colo delimietd list ',
'',
'G_BENUTZERID',
'',
'3563:1002'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1005994963073048635)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1005997812789048637)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1005994484276048634)
,p_event_id=>wwv_flow_imp.id(1005994963073048635)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1005996151282048636)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create_JIRA_POST'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- begin',
'-- PCK_CIP_JIRA.postNewTicketinQueue(:P572_MASTER_VORSCHRIFTID, :P570_MFV_TYP,:P571_AK_SEL,:P573_STICHWORT_SEL, :P572_VORSCHRIFTEN_SEL,:P574_MFVID, :P581_MFVS, :P582_COCOA);',
'-- end;',
'',
'DECLARE',
'    l_jira_post_id NUMBER;',
'BEGIN',
'    -- Call the function that returns the JIRA_POST_ID',
'    l_jira_post_id := PCK_CIP_JIRA.postNewTicketinQueue(',
'        :P572_MASTER_VORSCHRIFTID, ',
'        :P570_MFV_TYP,',
'        :P571_AK_SEL,',
'        :P573_STICHWORT_SEL, ',
'        :P572_VORSCHRIFTEN_SEL,',
'        :P574_MFVID, ',
'        :P581_MFVS, ',
'        :P582_COCOA',
'    );',
'    ',
'    -- Store the ID for page 576',
'    :P575_JIRA_POST_ID := l_jira_post_id;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1005997386194048636)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2666216164617339599
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1005995394986048635)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2666216920913339600
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1005995807644048635)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'New'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1005997386194048636)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2666216508255339600
);
wwv_flow_imp.component_end;
end;
/
