prompt --application/pages/page_00300
begin
--   Manifest
--     PAGE: 00300
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>300
,p_name=>'Baumansicht'
,p_alias=>'BAUMANSICHT'
,p_step_title=>'Baumansicht'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function redirectVorschrift(aVorschriftID) {',
'    apex.server.process(',
'        ''loadLinkVorschrift'',                           ',
'        { x01: aVorschriftID }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                javascript:window.open(pData,''_blank'');            ',
'                ',
'            },',
'            dataType: "text"                     ',
'        }',
'    );        ',
'}',
'',
'',
'',
'// Auto-override relationship types when target regulation is selected',
'function enforceChainModeRelationships() {',
'    var targetSelected = $v(''P300_TARGET_REGULATION'');',
'    ',
'    if (targetSelected && targetSelected !== '''') {',
'        $(''input[name="P300_BEZIEHUNG_ART"]'').prop(''checked'', false);',
'        $(''input[name="P300_BEZIEHUNG_ART"][value="10"]'').prop(''checked'', true);',
'        $(''input[name="P300_BEZIEHUNG_ART"][value="40"]'').prop(''checked'', true);',
'        $(''input[name="P300_BEZIEHUNG_ART"][value="102"]'').prop(''checked'', true);',
'    }',
'}',
'',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.mermaid'').on(''click'',''.node'', function() {',
'    var id = $(this).attr("id").split(''-'')[1];',
'    redirectVorschrift(id.substring(2));',
'});',
'',
'$(''#mermaidheader'').css(''height'',''0px'').css(''width'',''0px'').appendTo(''.t-Header .t-Header-branding'');',
'$(''.t-Body-main'').css(''margin-top'',''48px'');',
'',
'',
'',
'$(document).ready(function() {',
'    // Show chain mode message if target regulation is selected after page loads',
'    setTimeout(function() {',
'        if ($v(''P300_TARGET_REGULATION'') !== '''') {',
'            apex.message.showPageSuccess(''Kettenanzeige aktiviert: Nur "Successor >> Predecessor", "Demands" und "Equivalent" Beziehungen werden verwendet.'');',
'        }',
'    }, 1600);',
'',
'});',
'',
'',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.mermaid {width: 1400px}',
'',
'.node {cursor: pointer}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2485441565575084205)
,p_plug_name=>'New'
,p_region_name=>'mermaidheader'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_07'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!-- Hier muss jetzt leider ein x-beliebiges Diagramm und der Aufruf von mermaid rein, weil sonst das Hauptdiagramm',
'     keine Pfeile hat. Fragt mich bitte nicht, wieso. Im Execute on Page Load stehen noch ein paar Anweisungen, ',
unistr('     die das hier verstecken, da vollst\00E4ndiges Ausblenden leider dazu f\00FChrt, das auch das Hauptdiagramm keine Pfeile'),
'     mehr hat',
'     TsTh, 30.03.2023 -->',
'<pre class="hide mermaid">',
'            graph TD ',
'            A[Client] --> B[Load Balancer] ',
'            B --> C[Server1] ',
'            B --> D[Server2]',
'    </pre>',
'',
'   ',
'',
'    <script type="module">',
'      import mermaid from ''https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.esm.min.mjs'';',
'      mermaid.initialize({ startOnLoad: true });',
'    </script>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4279241938249528297)
,p_plug_name=>'Legende'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4471590854646246730)
,p_plug_name=>'Filter'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4471591022197246731)
,p_plug_name=>'Baumansicht'
,p_region_name=>'baumansicht'
,p_region_template_options=>'#DEFAULT#:margin-top-lg'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lSuchtiefe number := nvl(:P300_SUCHTIEFE,10);',
'    lStart number := :P300_VORSCHRIFTID;',
'    lTarget number;',
'    lItem apex_t_varchar2;',
'    lPath varchar2(4000);',
'    lUsedNodes varchar2(4000) := :P300_VORSCHRIFTID;    ',
'    lSupplementsAnzeigen number := :P300_SUPPLEMENTS;',
'    lChainPath varchar2(4000);',
'    lChainFound number := 0;',
'    ',
'begin',
'    htp.p(''<div class="mermaid">  flowchart LR'');',
'',
'    if (:P300_TARGET_REGULATION is not null) then',
'',
'        -- The item P300_TARGET_REGULATION contains both the target regulation and the regulations in path, so first extract them',
'        lItem := apex_string.split(:P300_TARGET_REGULATION,'';'');',
'        lTarget := lItem(1);',
'        lPath := lItem(2);',
'',
'        -- Show all regulations in the path',
'        for s in (',
'                select v.vorschriftid id, ',
'                       pck_ri.fSanitizeForTree(vn.vorschrift_nummer_erw || '' - '' || vs.status) label, ',
'                       v.vorschrift_typid typ',
'                from t_vorschrift v',
'                join t_vorschrift_status vs on (v.vorschrift_statusid = vs.vorschrift_statusid)',
'                join v_vorschrift_nummer_erweitert vn on (v.vorschriftid = vn.vorschriftid)',
'                where v.vorschriftid in (select column_value from apex_string.split(lPath,'',''))',
'            ) loop',
'                htp.p(''id'' || s.id ||',
'                      case s.typ when 30 then ''{'' when 20 then ''(['' else ''['' end ||          ',
'                      case s.typ when 20 then '''' end || ''"'' || s.label || ''"'' ||',
'                      case s.typ when 30 then ''}'' when 20 then ''])'' else '']'' end || chr(10));    ',
'            end loop;',
'',
'        -- Show all connections from regulations in the path',
'        for k in (',
'            select vrv.vorgaenger_vorschriftid von, vrv.nachfolger_vorschriftid nach, vrv.beziehung_art as beziehung_artid',
'            from t_vorschrift_ref_vorschrift vrv',
'            join t_vorschrift vv on (vrv.vorgaenger_vorschriftid = vv.vorschriftid)  ',
'            join t_vorschrift nv on (vrv.nachfolger_vorschriftid = nv.vorschriftid)  ',
'            where vrv.beziehung_art IN (10, 40, 102)',
'            and vrv.vorgaenger_vorschriftid in (select column_value from apex_string.split(lPath,'',''))',
'            and vrv.nachfolger_vorschriftid in (select column_value from apex_string.split(lPath,'',''))',
'        ) loop',
'            if (k.beziehung_artid = 10) then',
'                htp.p(''id'' ||  k.von || '' -- Successor >> Predecessor --> '' || ''id'' ||k.nach);',
'            elsif (k.beziehung_artid = 40) then',
'                htp.p(''id'' || k.nach || '' -- Demands --> '' || ''id'' || k.von);',
'            elsif (k.beziehung_artid = 102) then',
'                htp.p(''id'' ||  k.von || '' -- Equivalent --> '' || ''id'' ||k.nach);',
'            end if;',
'            htp.p(chr(10));      ',
'        end loop;            ',
'',
'        ',
'',
'    else',
'        -- DEFAULT MODE: ',
'        for s in (',
'            select v.vorschriftid id, pck_ri.fSanitizeForTree(vn.vorschrift_nummer_erw || '' - '' || vs.status) label, v.vorschrift_typid typ',
'            from t_vorschrift v',
'            join t_vorschrift_status vs on (v.vorschrift_statusid = vs.vorschrift_statusid)',
'            join v_vorschrift_nummer_erweitert vn on (v.vorschriftid = vn.vorschriftid)        ',
'            where v.vorschriftid = :P300_VORSCHRIFTID',
'            and ((:P300_EXPIRED_AUS=1 and (v.VORSCHRIFT_STATUSID is null or v.VORSCHRIFT_STATUSID != 100))',
'                 OR :P300_EXPIRED_AUS=0)',
'        ) loop',
'                htp.p(''id'' || s.id ||',
'                      case s.typ when 30 then ''{'' when 20 then ''(['' else ''['' end ||          ',
'                      case s.typ when 20 then '''' end || ''"'' || s.label || ''"'' ||',
'                      case s.typ when 30 then ''}'' when 20 then ''])'' else '']'' end || chr(10));    ',
'        end loop;',
'        ',
'        for l in 1..lSuchtiefe loop',
'            for n in (',
'                select v.vorschriftid id, pck_ri.fSanitizeForTree(vn.vorschrift_nummer_erw || '' - '' || vs.status) label, v.vorschrift_typid typ',
'                from t_vorschrift_ref_vorschrift vrv',
'                join t_vorschrift v on (vrv.nachfolger_vorschriftid = v.vorschriftid)',
'                join t_vorschrift_status vs on (v.vorschrift_statusid = vs.vorschrift_statusid)',
'                join v_vorschrift_nummer_erweitert vn on (v.vorschriftid = vn.vorschriftid)',
'                where v.vorschriftid not in (select column_value from table(apex_string.split_numbers(lUsedNodes,'':'')))',
'                and vrv.vorgaenger_vorschriftid in (select column_value from table(apex_string.split_numbers(lUsedNodes,'':''))) ',
'                and (lSupplementsAnzeigen = 10 or v.vorschrift_typid in (10, 30, 40))',
'                and vrv.beziehung_art in (select column_value from table(apex_string.split_numbers(:P300_BEZIEHUNG_ART,'':'')))',
'                and ((:P300_EXPIRED_AUS=1 and (v.VORSCHRIFT_STATUSID is null or v.VORSCHRIFT_STATUSID != 100))',
'                     OR :P300_EXPIRED_AUS=0)',
'                union',
'                select v.vorschriftid id, pck_ri.fSanitizeForTree(vn.vorschrift_nummer_erw || '' - '' || vs.status) label, v.vorschrift_typid typ',
'                from t_vorschrift_ref_vorschrift vrv',
'                join t_vorschrift v on (vrv.vorgaenger_vorschriftid = v.vorschriftid)',
'                join t_vorschrift_status vs on (v.vorschrift_statusid = vs.vorschrift_statusid)            ',
'                join v_vorschrift_nummer_erweitert vn on (v.vorschriftid = vn.vorschriftid)            ',
'                where v.vorschriftid not in (select column_value from table(apex_string.split_numbers(lUsedNodes,'':'')))',
'                and vrv.nachfolger_vorschriftid in (select column_value from table(apex_string.split_numbers(lUsedNodes,'':'')))',
'                and (lSupplementsAnzeigen = 10 or v.vorschrift_typid in (10, 30, 40))           ',
'                and vrv.beziehung_art in (select column_value from table(apex_string.split_numbers(:P300_BEZIEHUNG_ART,'':'')))',
'                and ((:P300_EXPIRED_AUS=1 and (v.VORSCHRIFT_STATUSID is null or v.VORSCHRIFT_STATUSID != 100))',
'                     OR :P300_EXPIRED_AUS=0)             ',
'            ) loop',
'                htp.p(''id'' || n.id ||',
'                      case n.typ when 30 then ''{'' when 20 then ''(['' else ''['' end ||          ',
'                      case n.typ when 20 then '''' end || ''"'' || n.label || ''"'' ||',
'                      case n.typ when 30 then ''}'' when 20 then ''])'' else '']'' end || chr(10));',
'                if (l < lSuchtiefe) then',
'                    lUsedNodes := lUsedNodes || '':'' || n.id;                  ',
'                end if;',
'            end loop;',
'        end loop;',
'        ',
'        for k in (',
'            select vrv.vorgaenger_vorschriftid von, vrv.nachfolger_vorschriftid nach, ba.beziehung_art, ba.beziehung_artid',
'            from t_vorschrift_ref_vorschrift vrv',
'            join t_vorschrift vv on (vrv.vorgaenger_vorschriftid = vv.vorschriftid)',
'            join t_vorschrift nv on (vrv.nachfolger_vorschriftid = nv.vorschriftid)',
'            join t_beziehung_art ba on (vrv.beziehung_art = ba.beziehung_artid)',
'            where (vrv.vorgaenger_vorschriftid in (select column_value from table(apex_string.split_numbers(lUsedNodes,'':'')))',
'                   or vrv.nachfolger_vorschriftid in (select column_value from table(apex_string.split_numbers(lUsedNodes,'':'')))) ',
'            and (lSupplementsAnzeigen = 10 or (nv.vorschrift_typid in (10, 30, 40)) and vv.vorschrift_typid in (10, 30, 40))',
'            and vrv.beziehung_art in (select column_value from table(apex_string.split_numbers(:P300_BEZIEHUNG_ART,'':'')))',
'            and ((:P300_EXPIRED_AUS=1 and (vv.VORSCHRIFT_STATUSID is null or vv.VORSCHRIFT_STATUSID != 100))',
'                 OR :P300_EXPIRED_AUS=0)',
'            and ((:P300_EXPIRED_AUS=1 and (nv.VORSCHRIFT_STATUSID is null or nv.VORSCHRIFT_STATUSID != 100))',
'                 OR :P300_EXPIRED_AUS=0)',
'        ) loop',
'            if (k.beziehung_artid = 10) then',
'                htp.p(''id'' ||  k.von || '' -- Successor >> Predecessor --> '' || ''id'' ||k.nach);',
'            elsif (k.beziehung_artid = 60) then',
'                htp.p(''id'' ||  k.nach || '' -- '' || k.beziehung_art || '' --- '' || ''id'' ||k.von);        ',
'            else',
'                htp.p(''id'' ||  k.nach || '' -- '' || k.beziehung_art || '' --> '' || ''id'' ||k.von);',
'            end if;',
'            htp.p(chr(10));      ',
'        end loop;',
'    end if;',
'',
'    htp.p(''</div>'');',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(980798274022052321)
,p_name=>'P300_LEG_BILD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4279241938249528297)
,p_source=>'#APP_IMAGES#vorsch_baum_legende.png'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'alternative_text', 'Legende',
  'based_on', 'URL')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(980797563936052321)
,p_name=>'P300_TARGET_REGULATION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(4471590854646246730)
,p_prompt=>unistr('Zielvorschrift f\00FCr Kettenanzeige')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_con as (',
'    -- get all connections, regardless of direction',
'    select vorgaenger_vorschriftid as v1, nachfolger_vorschriftid as v2',
'    from t_vorschrift_ref_vorschrift',
'    where beziehung_art in (10,40,102)',
'    union',
'    select nachfolger_vorschriftid as v1, vorgaenger_vorschriftid as v2',
'    from t_vorschrift_ref_vorschrift',
'    where beziehung_art in (10,40,102)',
'), cte_paths as (',
'    -- from a starting regulation, get all paths',
'    select v1, v2 ende, sys_connect_by_path(v1,'','') || '','' || v2 path, level as pathlength',
'    from cte_con',
'    start with v1 = :P300_VORSCHRIFTID -- in sql developer, using a variable here causes an error, so replace the id',
'    connect by nocycle v1 = prior v2',
'    and level <= 4',
'), cte_shortest_paths as (',
'    -- get the minimum path length by ending regulation',
'    select ende, min(pathlength) min_pathlength',
'    from cte_paths o',
'    group by o.ende',
')',
'    -- get the shortest path, so we can save and use it for the mermaid diagram',
'    select --ende, min_pathlength, p.path,',
unistr('    v.vorschrift_nummer || case when p.anzeige_mit_dokumentendatum = 20 then ''_'' || to_char(v.dokumentendatum,''dd.mm.yyyy'') else null end || '' (L\00E4nge: '' || (min_pathlength + 1) || '')'' as d,'),
'    ende || '';'' || p.path as r',
'    from cte_shortest_paths o',
'    join t_vorschrift v on (ende = v.vorschriftid)',
'    left outer join t_publisher p on (v.publisherid = p.publisherid)',
'    outer apply (',
'        select path',
'        from cte_paths i',
'        where i.ende = o.ende',
'        order by pathlength asc',
'        fetch first 1 rows only',
'    ) p',
'    where ende != :P300_VORSCHRIFTID',
'',
'    order by 1;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Zielvorschrift ausw\00E4hlen --')
,p_lov_cascade_parent_items=>'P300_VORSCHRIFTID'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>100
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ''ID:'' || v.vorschriftid || '' - '' || v.vorschrift_nummer || '' - '' || ',
'nvl(v.vorschrift_bezeichnung, v.titel_kurz) as display_value,',
'v.vorschriftid as return_value',
'FROM t_vorschrift v',
'WHERE v.vorschriftid IN (',
'SELECT DISTINCT param_vid ',
'FROM v_vn_ketten',
')',
'-- AND v.vorschrift_freigabestatusid > 0',
'-- AND v.vorschrift_statusid != 100',
'ORDER BY v.vorschriftid;',
'',
'',
'',
'wokrimng ',
'',
'',
'SELECT ',
'''ID:'' || v.vorschriftid || '' - '' || vn.vorschrift_nummer_erw || '' - '' || vs.status AS display_value,',
'v.vorschriftid AS return_value',
'FROM v_vn_ketten vk',
'JOIN t_vorschrift v ON (v.vorschriftid IN (',
'SELECT column_value ',
'FROM table(apex_string.split_numbers(vk.pfad, '':''))',
'))',
'JOIN t_vorschrift_status vs ON (v.vorschrift_statusid = vs.vorschrift_statusid)',
'JOIN v_vorschrift_nummer_erweitert vn ON (v.vorschriftid = vn.vorschriftid)',
'WHERE vk.param_vid = :P300_VORSCHRIFTID',
'AND v.vorschriftid != :P300_VORSCHRIFTID',
'ORDER BY vn.vorschrift_nummer_erw;',
'',
'',
'wokrimg last 23 juu ',
'',
'',
'SELECT DISTINCT',
'''ID:'' || v.vorschriftid || '' - '' || vn.vorschrift_nummer_erw || '' - '' || vs.status AS display_value,',
'v.vorschriftid AS return_value',
'FROM v_vn_ketten vk',
'JOIN t_vorschrift v ON (v.vorschriftid IN (',
'SELECT column_value ',
'FROM table(apex_string.split_numbers(vk.pfad, '':''))',
'))',
'JOIN t_vorschrift_status vs ON (v.vorschrift_statusid = vs.vorschrift_statusid)',
'JOIN v_vorschrift_nummer_erweitert vn ON (v.vorschriftid = vn.vorschriftid)',
'WHERE vk.param_vid = :P300_VORSCHRIFTID',
'AND v.vorschriftid != :P300_VORSCHRIFTID  -- Exclude start regulation',
'AND v.vorschriftid NOT IN (',
'-- Exclude regulations that are currently being displayed in tree view',
'SELECT v2.vorschriftid',
'FROM t_vorschrift_ref_vorschrift vrv',
'JOIN t_vorschrift v2 ON (vrv.nachfolger_vorschriftid = v2.vorschriftid OR vrv.vorgaenger_vorschriftid = v2.vorschriftid)',
'WHERE (vrv.vorgaenger_vorschriftid = :P300_VORSCHRIFTID OR vrv.nachfolger_vorschriftid = :P300_VORSCHRIFTID)',
'AND vrv.beziehung_art IN (10) -- Only predecessor-successor relationships',
'',
'UNION',
'',
'-- exclude regulations found in subsequent levels based on search depth',
'SELECT v3.vorschriftid',
'FROM t_vorschrift_ref_vorschrift vrv2',
'JOIN t_vorschrift v3 ON (vrv2.nachfolger_vorschriftid = v3.vorschriftid OR vrv2.vorgaenger_vorschriftid = v3.vorschriftid)',
'JOIN t_vorschrift_ref_vorschrift vrv_parent ON (',
'(vrv_parent.vorgaenger_vorschriftid = :P300_VORSCHRIFTID OR vrv_parent.nachfolger_vorschriftid = :P300_VORSCHRIFTID)',
'AND (vrv2.vorgaenger_vorschriftid = vrv_parent.nachfolger_vorschriftid OR vrv2.vorgaenger_vorschriftid = vrv_parent.vorgaenger_vorschriftid',
'OR vrv2.nachfolger_vorschriftid = vrv_parent.nachfolger_vorschriftid OR vrv2.nachfolger_vorschriftid = vrv_parent.vorgaenger_vorschriftid)',
')',
'WHERE vrv2.beziehung_art IN (10)',
'AND nvl(:P300_SUCHTIEFE, 2) >= 2',
')',
'ORDER BY v.vorschriftid;',
'',
'',
'-- workionng code 16.07.2025, 14:03 ',
'',
'',
'SELECT DISTINCT',
'''ID:'' || v.vorschriftid || '' - '' || vn.vorschrift_nummer_erw || '' - '' || vs.status AS display_value,',
'v.vorschriftid AS return_value',
'FROM v_vn_ketten vk',
'JOIN t_vorschrift v ON (v.vorschriftid IN (',
'SELECT column_value ',
'FROM table(apex_string.split_numbers(vk.pfad, '':''))',
'))',
'JOIN t_vorschrift_status vs ON (v.vorschrift_statusid = vs.vorschrift_statusid)',
'JOIN v_vorschrift_nummer_erweitert vn ON (v.vorschriftid = vn.vorschriftid)',
'WHERE vk.param_vid = :P300_VORSCHRIFTID',
'AND v.vorschriftid != :P300_VORSCHRIFTID  -- Exclude start regulation',
'ORDER BY v.vorschriftid;',
'',
'',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(980797205428052320)
,p_name=>'P300_VORSCHRIFTID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4471590854646246730)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(980796757915052320)
,p_name=>'P300_SUCHTIEFE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4471590854646246730)
,p_prompt=>'Suchtiefe'
,p_source=>'1'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select level as d, level as r',
'from dual',
'connect by level <= 10'))
,p_cHeight=>1
,p_colspan=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'Y',
  'page_action_on_selection', 'SUBMIT')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(980796346391052320)
,p_name=>'P300_SUPPLEMENTS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(4471590854646246730)
,p_prompt=>'Supplements anzeigen'
,p_source=>'20'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Nein',
  'off_value', '20',
  'on_label', 'Ja',
  'on_value', '10',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(980795991412052319)
,p_name=>'P300_EXPIRED_AUS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(4471590854646246730)
,p_item_default=>'1'
,p_prompt=>'Expired ausblenden'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_colspan=>3
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', '1',
  'unchecked_value', '0',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(980795599931052319)
,p_name=>'P300_BEZIEHUNG_ART'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(4471590854646246730)
,p_prompt=>'Beziehungs-Arten'
,p_source=>'30:10:102:40:60:200'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select beziehung_art, beziehung_artid',
'from t_beziehung_art',
'order by 1'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(980794513316052317)
,p_name=>'submit page'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P300_SUPPLEMENTS,P300_BEZIEHUNG_ART,P300_TARGET_REGULATION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(980793971232052316)
,p_event_id=>wwv_flow_imp.id(980794513316052317)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(980793526582052316)
,p_name=>'Change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P300_EXPIRED_AUS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(980793103957052316)
,p_event_id=>wwv_flow_imp.id(980793526582052316)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'submit page'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(980792619275052315)
,p_name=>'Auto-Override Relationship Types in Target Mode'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P300_TARGET_REGULATION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(980792191177052315)
,p_event_id=>wwv_flow_imp.id(980792619275052315)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'enforceChainModeRelationships();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(980794881535052317)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLinkVorschrift'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lID number;',
'    lRowid rowid;',
'BEGIN',
' ',
'    lID := apex_application.g_x01;',
'    ',
'    select rowid into lRowid',
'    from t_vorschrift',
'    where vorschriftid = lID;',
'    ',
'    htp.p (apex_page.get_url(p_page => 25, p_items => ''P25_VORSCHRIFTID'', p_values => lID, p_clear_cache => 25));',
'end;    '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2691417434364335918
);
wwv_flow_imp.component_end;
end;
/
