prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>'Global Page - Desktop'
,p_step_title=>'Global Page - Desktop'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1455993820463153835)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="text/javascript">',
'    var isIE = !!window.MSInputMethodContext && !!document.documentMode;',
'    var currentPage = parseInt(document.getElementById("pFlowStepId").value);',
'    if (isIE && currentPage != 5) {',
'        window.location = ''f?p=&APP_ID.:5'';',
'    }',
'</script>',
'',
'',
'<style type="text/css">',
'span[onclick] {',
'    cursor: pointer',
'}',
'',
'span[onclick=""] {',
'    cursor: inherit',
'}',
'',
'h2.t-Region-title span.fa {',
'    font-size: 1.5em;',
'}',
'',
'',
'/*div.a-Menu-content li:nth-child(1), div.a-Menu-content li:nth-child(2) {',
'    display: none;',
'}*/',
'',
'.a-IRR-sortWidget-actions-item:nth-child(3), .a-IRR-sortWidget-actions-item:nth-child(4) {',
'    display: none !important;',
'}',
'',
'.apex-item-group--switch input:not(:checked) + label {background-color: lightgrey; color: darkgray}',
'.apex-item-grid.radio_group input:not(:checked) + label {background-color: lightgrey; color: darkgray}',
'',
'.t-NavigationBar-item.is-active span.t-Button-label {',
'    font-weight: bold;',
'    text-decoration: underline;',
'}',
'',
'</style>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(789495089900286999)
,p_name=>'P0_SHOW_BESTAETIGUNG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1455993820463153835)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(789495002534286998)
,p_name=>'P0_BESTAETIGUNG_URL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1455993820463153835)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(789495325789287001)
,p_name=>unistr('Check Best\00E4tigung')
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(789495224186287000)
,p_event_id=>wwv_flow_imp.id(789495325789287001)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lFrist number;',
'    lLetztesDatum date;',
'    lNaechstesDatum date;',
'    lUrl varchar2(2000);',
'begin',
'',
'    :P0_SHOW_BESTAETIGUNG := 0;',
'',
unistr('    -- Hole die k\00FCrzeste auf den angemeldeten Benutzer zutreffende Frist'),
'    begin',
'        select min(BESTAETIGUNG_FRIST)',
'        into lFrist',
'        from T_BENUTZER_REF_ROLLE brr',
'        left join T_ROLLE r on (brr.rolleid = r.rolleid)',
'        where brr.BenutzerId = :G_BENUTZERID;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN null;',
'    end;',
'    -- Falls der Benutzer keine Rolle hat nimm die Frist der ''Platzhalter''-Rolle',
'    if lFrist is null then',
'        select BESTAETIGUNG_FRIST',
'        into lFrist',
'        from T_ROLLE',
'        where ROLLEID = 1004;',
'    end if;',
'    ',
unistr('    -- Hole das Datum der letzten Best\00E4tigung des Benutzers'),
'    begin',
'        select BESTAETIGUNG_DATUM',
'        into lLetztesDatum',
'        from T_BENUTZER',
'        where BenutzerId = :G_BENUTZERID;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN null;',
'    end;',
'    ',
unistr('    -- Berechne das Datum f\00FCr die n\00E4chste Best\00E4tigung'),
'    if lLetztesDatum is not null then',
'        lNaechstesDatum := trunc(lLetztesDatum + lFrist);',
'    end if;',
'    ',
'    if lLetztesDatum is null or lNaechstesDatum <= sysdate then',
'        lUrl := APEX_UTIL.PREPARE_URL(',
'            p_url => ''f?p='' || v(''APP_ID'') || '':170:''||v(''APP_SESSION'')||''::NO::P170_HILFEID:1'',',
'            p_checksum_type => ''SESSION'',',
'            p_triggering_element => ''this'');',
'                    ',
'        :P0_SHOW_BESTAETIGUNG := 1;',
'        :P0_BESTAETIGUNG_URL := lUrl;',
'    end if;',
'    ',
'    ',
'',
'end;'))
,p_attribute_03=>'P0_SHOW_BESTAETIGUNG,P0_BESTAETIGUNG_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(789494883506286997)
,p_event_id=>wwv_flow_imp.id(789495325789287001)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lAppPageId = $v(''pFlowStepId''); // APP_PAGE_ID',
'',
unistr('// Bedingung f\00FCr Best\00E4tigungsfenster: Das Best\00E4tigungsfenster soll aufgerufen werden und ist noch nicht ge\00F6ffnet'),
'if ($v("P0_SHOW_BESTAETIGUNG") == 1 && lAppPageId != 170) {',
unistr('    // Fenster mit zu Best\00E4tigendem Inhalt \00FCber URL aufrufen '),
'    apex.navigation.redirect($v("P0_BESTAETIGUNG_URL"));',
'    //eval($v("P0_BESTAETIGUNG_URL"));',
'}',
'',
'',
'$( ".datepicker" ).datepicker( "option", "showWeek", true );',
'$("button.ui-datepicker-trigger").addClass("a-Button a-Button--calendar");',
'$(''.t-NavigationBar span.t-Button-label:contains("Support")'').closest(''li'').css(''border'',''1px solid gray'');'))
);
wwv_flow_imp.component_end;
end;
/
