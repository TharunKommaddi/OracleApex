prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>20
,p_name=>'Vorschriften'
,p_step_title=>'Vorschriften'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#P20_SHORT'').detach().prependTo(''#VSIG div.a-IRR-buttons'').css(''margin-right'',''10px'').css(''margin-top'',''-1px'');',
'$(''#P20_SUPPLEMENTS'').detach().prependTo(''#VSIG div.a-IRR-buttons'').css(''margin-right'',''10px'').css(''margin-top'',''-1px'');',
'$(''#P20_FLAG_KF'').detach().prependTo(''#VSIG div.a-IRR-buttons'').css(''margin-right'',''10px'').css(''margin-top'',''-1px'');',
unistr('$("label[for=''P20_FLAG_KF_Y'']").attr(''title'',''Blendet Vorschriften, die durch letztg\00FCltige Fassungen ersetzt worden sind, ein'');'),
unistr('$("label[for=''P20_FLAG_KF_N'']").attr(''title'',''Blendet Vorschriften, die durch letztg\00FCltige Fassungen ersetzt worden sind, aus'');'),
'$(''#VSIG div.a-IRR-buttons'').css(''display'',''flex'').css(''justify-content'',''flex-end'');',
'$(''#P20_SHORT_CONTAINER'').closest(''div.row'').remove();',
'',
'/* Click auf Checkbox in Tabellenheader: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'$(''#VSIG'').on(''click'', ''th input'', function() {',
'    var check_all = $("#VSIG").find("th input:checked").is(":checked");',
'',
unistr('    // alle Zeilen ausw\00E4hlen/abw\00E4hlen'),
'    $("#VSIG").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'    // Button aktivieren/deaktivieren',
'    if (check_all) {',
'        $("#b_MB").removeClass("apex_disabled");',
'    } else {',
'        $("#b_MB").addClass("apex_disabled");',
'    }',
'',
'    $("#b_MB").prop(''disabled'', !check_all);',
'    ',
unistr('    // alle ausgew\00E4hlten Zeilen-IDs in das Item P20_SELECTED_ROWS'),
'    var sel_rows = apex.item(''P20_SELECTED_ROWS'');',
'    sel_rows.setValue("");',
'    $("#VSIG").find("td input:checked").each(function() {',
'      if(sel_rows.getValue().length > 0) {',
'        sel_rows.setValue(sel_rows.getValue() + ":");    ',
'      }',
'      sel_rows.setValue(sel_rows.getValue() + this.value);',
'    });',
'    apex.server.process(''MY_PROCESS'', {',
'        pageItems: ''#P20_SELECTED_ROWS''',
'    },{dataType: ''text''});',
'    //alert (sel_rows.getValue());',
'});',
'',
'// Hilfe Button',
'$(''#VSIG_toolbar_controls'').append('' <span onclick="redirect(4)" style="font-size:2.7em" class="fa fa-question-square-o"></span>'');',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#VSIG .t-fht-tbody {max-height: calc(100vh - 260px)}',
'.t-Body-topButton {display: none !important}',
'.t-Body-content {padding-bottom: 3px !important}',
'.t-Body {margin-bottom: 3px !important}',
'.t-Body-contentInner {padding-bottom: 0px !important}',
'',
'#VSIG_filter_type > .a-IRR-radioIconList-item:nth-child(3) {',
'    display: none;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2641545930668267170)
,p_plug_name=>'Vorschriften <span onclick="redirect(4)" style="font-size:1.5em" class="fa fa-question-square-o"></span>'
,p_region_name=>'VSIG'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with r as (',
'        select  v.vorschriftid vorschriftid, --listagg(vv.nachname || '', '' || vv.vorname, ''; '') within group (order by vv.nachname) as verantwortlicher,',
'              listagg(distinct ak.kurz,'', '' on overflow truncate) within group (order by ak.kurz) liste_ak,',
'              -- listagg(distinct t.BETROFFENHEIT,'', '' on overflow truncate) within group (order by t.BETROFFENHEIT) liste_ffa,',
'               listagg(distinct t.nummer,'', '' on overflow truncate) within group (order by t.nummer) liste_tg   ',
'       -- listagg(DISTINCT CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN aa.bezeichnung ELSE aa.name_eng END, '', '' ON OVERFLOW TRUNCATE) ',
'        --    WITHIN GROUP (ORDER BY CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN aa.bezeichnung ELSE aa.name_eng END) AS liste_aa',
'',
'        from t_vorschrift v',
'        left outer join t_vorschrift_ref_et_b_ak vrak on (v.vorschriftid = vrak.vorschriftid and nvl(vrak.geloescht, 0) =0 )',
'         left outer join t_et_b_ak ak on (ak.et_b_akid = vrak.et_b_akid)',
'         left outer join t_vorschrift_ref_thema vtl on (vtl.vorschriftid = v.vorschriftid and vtl.geloescht = 0)',
'        left outer join t_thema t on (vtl.themaid = t.themaid)       -- 5284',
'    --    left outer join t_thema_ref_antriebsart trf on (vtl.themaid = trf.themaid)',
'    --     left outer join t_antriebsart aa on (aa.antriebsartid = trf.antriebsartid)',
'',
'        left outer join t_vorschrift_ref_antriebsart vra on (vra.vorschriftid = v.vorschriftid and vra.geloescht = 0)',
'        left outer join t_antriebsart aa on (aa.antriebsartid = vra.antriebsartid)',
'',
'        ',
'        group by v.vorschriftid',
' ), ',
' rt as (',
'         select  v.vorschriftid vorschriftid, --listagg(vv.nachname || '', '' || vv.vorname, ''; '') within group (order by vv.nachname) as verantwortlicher,',
'             -- listagg(distinct ak.kurz,'', '' on overflow truncate) within group (order by ak.kurz) liste_ak,',
'               listagg(distinct t.BETROFFENHEIT,'', '' on overflow truncate) within group (order by t.BETROFFENHEIT) liste_ffa,',
'               listagg(distinct t.nummer,'', '' on overflow truncate) within group (order by t.nummer) liste_tg   ,',
'                listagg(DISTINCT CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN aa.bezeichnung ELSE aa.name_eng END, '', '' ON OVERFLOW TRUNCATE)',
'                  WITHIN GROUP (ORDER BY CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN aa.bezeichnung ELSE aa.name_eng END) AS liste_aa',
'',
'  from t_vorschrift v',
' --left outer join t_vorschrift_ref_et_b_ak vrak on (vrak.vorschriftid = v.vorschriftid )',
'        left outer join t_vorschrift_ref_thema vtl on (vtl.vorschriftid = v.vorschriftid and vtl.geloescht = 0)',
'        left outer join t_thema t on (vtl.themaid = t.themaid)       -- 5284',
'        --left outer join t_thema_ref_et_b_ak trak on (trak.themaid = vtl.themaid  )  -- 5284   on full ->5265',
'        --left outer join t_et_b_ak ak on (ak.et_b_akid = trak.et_b_akid)    -- 5264',
'        --  left outer join t_thema_ref_antriebsart trf on (vtl.themaid = trf.themaid)',
'        -- left outer join t_antriebsart aa on (aa.antriebsartid = trf.antriebsartid)',
'',
'        left outer join t_vorschrift_ref_antriebsart vra on (vra.vorschriftid = v.vorschriftid and vra.geloescht = 0)',
'        left outer join t_antriebsart aa on (aa.antriebsartid = vra.antriebsartid)',
'  group by v.vorschriftid  -- 5615 union',
') , ',
' r2 as (',
' select r.vorschriftid,  r.liste_ak   as liste_ak, ',
'   r.liste_tg  as liste_tg,',
'    rt.liste_ffa,    rt.liste_aa',
'  from r',
'  join rt on (rt.vorschriftid = r.vorschriftid)',
'',
'),',
'rv as (',
'  select v.vorschriftid vorschriftid, --listagg(vv.nachname || '', '' || vv.vorname, '';'') within group (order by vv.nachname) as verantwortlicher',
'',
'  listagg(CASE WHEN vrv.IST_HAUPTVERANTWORTLICHER = 10 THEN ',
'  ''<span style="text-decoration: underline;">'' || vv.nachname || '', '' || vv.vorname || ''</span>''',
'  ELSE vv.nachname || '', '' || vv.vorname END, ''; '') WITHIN GROUP (ORDER BY vv.nachname) as verantwortlicher  ',
'    from t_vorschrift v',
'    join t_vorschrift_ref_verantwortlicher vrv on (vrv.vorschriftid = v.vorschriftid)',
'    join t_verantwortlicher vv on (vv.verantwortlicherid = vrv.verantwortlicherid)',
'    group by v.vorschriftid',
')',
'',
' select vs."ROWID" as xrowid,',
' 1 as checkbox,',
' vs.vorschriftid,',
unistr('case flag_konsolidierte_fassungen when 1 then ''<span title="Es existiert eine letztg\00FCltige Fassung, in welche diese \00C4nderungsvorschrift enthalten ist" class="fa fa-flag"></span>'' else null end as flag_konsolidierte_fassungen,'),
' vs.vorschriftid as link_netz,',
' "VORSCHRIFT_NUMMER",',
' "VORSCHRIFT_BEZEICHNUNG",',
' "VORSCHRIFT_TYPID",',
' vs.PROGNOSE_QUALITAETID "PROGNOSE_QUALITAET",',
'-- PCK_RI.fJiraTicketsToLinks("JIRA_TICKET") AS "JIRA_TICKET",',
'--x.list_land,',
'vre.einsatzdatum as in_kraft,',
'r2.liste_ak as etb_ak,',
'-- r.liste_ffa as ffa, apex name  - Betroffen&shy;heit',
'r2.liste_tg as themengebiete,',
'vs.VORSCHRIFT_STATUSID,',
'vs.rxswin as rxswin_relevant,',
'',
'rv.verantwortlicher as Regulierungs_verantwortlicher,',
'vs.rev_notwendig,',
'apex_util.host_url(''SCRIPT'') || apex_page.get_url(',
'    p_application => :APP_ALIAS',
'    , p_page => ''VORSCHRIFT''',
'    , p_items => ''P25_VORSCHRIFTID''',
'    , p_values => vs.vorschriftid',
'    , p_session => null',
'    , p_clear_cache => ''25''',
') as permalink,',
'r2.liste_aa antriebsart,',
'nvl2(vs.lead_VKO_Benutzerid, b2.nachname ||'', '' || b2.vorname, '''') as Lead_VKO,',
'case when (vs.status_update_getex is null) then ''-''',
'                 when vs.status_update_getex  =10 then ''aktuell'' ',
'            when vs.status_update_getex  =20 then ''nicht aktuell'' ',
'            when vs.status_update_getex  =30 then  ''nicht in Getex''  end  as status_update_getex,',
'vs.LETZTE_AENDERUNG_GETEX_ATTR,',
'vs.DOKUMENTENDATUM',
'-- mj.MJ_Phasein_start , apex name - Einsatzzeitpunkt',
'from "#OWNER#"."T_VORSCHRIFT" vs   -- "#OWNER#"."T_VORSCHRIFT" vs',
'left join r2 on (r2.vorschriftid = vs.vorschriftid)',
'left outer join t_vorschrift_ref_einsatzdatum_typ vre on (vre.vorschriftid = vs.vorschriftid and vre.einsatzdatum_typid = 1000)',
'left outer join T_BENUTZER b on b.benutzerid = vs.letzte_aenderung_benutzerid',
'left outer join T_BENUTZER b2 on (b2.benutzerid = vs.lead_VKO_Benutzerid)',
'left outer join T_WEBSITE ws on ws.websiteid = vs.websiteid',
'left join rv on (rv.vorschriftid = vs.vorschriftid ) ',
'       --left outer join T_KSU k on k.ksuid = vs.ksuid',
'outer apply (',
'    select einsatzdatum MJ_Phasein_start',
'    from t_vorschrift_ref_einsatzdatum_typ vre',
'    where vre.vorschriftid = vs.vorschriftid',
'    and vre.einsatzdatum_typid = 1030',
'    fetch first 1 rows only',
') mj',
'where (vs.vorschrift_typid in (10, 30, 40) -- Supplements nicht anzeigen',
'       or vs.vorschrift_typid in (select case when (:P20_SUPPLEMENTS = 20) then 20 else 0 end from dual)  --:P20_SUPPLEMENTS ',
'      )',
'and (',
unistr('    (vs.vorschrift_freigabestatusid = 10 and pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002:1001:1040:1006'') > 0) -- Wenn Status "in Bearbeitung" dann sichtbar f\00FCr Fachadmin, VKO, VEX, ZVEX, KFEX, GBEX'),
unistr('    or vs.vorschrift_freigabestatusid = 20 -- Wenn Status "freigegeben", dann sichtbar f\00FCr alle'),
unistr('    or (vs.vorschrift_freigabestatusid = 30 and pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002:1001'') > 0) -- Wenn Status "nicht relevant", dann sichtbar f\00FCr Fachadmin, VKO, VEX, ZVEX'),
')',
'',
'',
'',
'and (vs.flag_konsolidierte_fassungen = 0 or :P20_FLAG_KF = 1)',
'ORDER BY  "VORSCHRIFT_NUMMER";',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P20_SHORT,P20_SUPPLEMENTS,P20_FLAG_KF'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2641546277016267170)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'Keine Vorschriften gefunden.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>1000
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV'
,p_enable_mail_download=>'N'
,p_detail_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:RP,25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_detail_link_text=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_detail_link_condition_type=>'EXPRESSION'
,p_detail_link_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 25,',
'                      accessMode => 100))'))
,p_detail_link_cond2=>'PLSQL'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>152199711057994934
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2677609322766722051)
,p_db_column_name=>'XROWID'
,p_display_order=>10
,p_column_identifier=>'T'
,p_column_label=>'Xrowid'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2660101020224816450)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>20
,p_column_identifier=>'P'
,p_column_label=>'Vorschriften ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
,p_column_comment=>'SELECT * FROM t_benutzer WHERE BENUTZERID IN (15643, 10304)'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2666276884553341737)
,p_db_column_name=>'CHECKBOX'
,p_display_order=>30
,p_column_identifier=>'R'
,p_column_label=>'<input type="checkbox" value="all" />'
,p_column_html_expression=>'<input type="checkbox" value="#VORSCHRIFTID#" />'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_rpt_show_filter_lov=>'N'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 1003 = Fachadmin, 1000 = VKO, 1200 = Redaktionsteam',
'pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1200'') > 0'))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2678819902412556038)
,p_db_column_name=>'LINK_NETZ'
,p_display_order=>40
,p_column_identifier=>'W'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:RP,300:P300_VORSCHRIFTID:#LINK_NETZ#'
,p_column_linktext=>unistr('<span class="fa fa-network-hub" title="Vernetzungsansicht \00F6ffnen" alt="Vernetzungsansicht \00F6ffnen"></span>')
,p_column_link_attr=>'target="_blank"'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1062778315855220796)
,p_db_column_name=>'PERMALINK'
,p_display_order=>50
,p_column_identifier=>'AM'
,p_column_label=>'<span title="Permalink">&nbsp;</span>'
,p_column_html_expression=>'<span class="fa fa-link" title="Permalink in Zwischenablage kopieren" alt="Permalink in Zwischenablage kopieren" onClick="javascript:navigator.clipboard.writeText(''#PERMALINK#'');alert(''Der Permalink wurde in die Zwischenablage kopiert:\n\n#PERMALINK#'
||''');"></span>'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1043565499127189812)
,p_db_column_name=>'FLAG_KONSOLIDIERTE_FASSUNGEN'
,p_display_order=>60
,p_column_identifier=>'AW'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P20_FLAG_KF'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2641546853858267180)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>70
,p_column_identifier=>'B'
,p_column_label=>'Vorschriften&shy;nummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2641547181133267180)
,p_db_column_name=>'VORSCHRIFT_BEZEICHNUNG'
,p_display_order=>80
,p_column_identifier=>'C'
,p_column_label=>'Titel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2659997308688113570)
,p_db_column_name=>'VORSCHRIFT_TYPID'
,p_display_order=>90
,p_column_identifier=>'Q'
,p_column_label=>'Vorschrift Typ'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(2656545044559578040)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2641547624220267180)
,p_db_column_name=>'PROGNOSE_QUALITAET'
,p_display_order=>100
,p_column_identifier=>'D'
,p_column_label=>unistr('Prognose Qualit\00E4t')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(958121403566083634)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2490438859468743546)
,p_db_column_name=>'VORSCHRIFT_STATUSID'
,p_display_order=>110
,p_column_identifier=>'AB'
,p_column_label=>'Status der Vorschrift'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(2490458092659806028)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2678820250027556041)
,p_db_column_name=>'ETB_AK'
,p_display_order=>120
,p_column_identifier=>'Y'
,p_column_label=>'ET-B AK'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2678820020451556039)
,p_db_column_name=>'IN_KRAFT'
,p_display_order=>140
,p_column_identifier=>'X'
,p_column_label=>'Datum Inkraftsetzung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>' DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2678820385536556043)
,p_db_column_name=>'THEMENGEBIETE'
,p_display_order=>150
,p_column_identifier=>'AA'
,p_column_label=>'Themengebiete'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1058221322330348922)
,p_db_column_name=>'RXSWIN_RELEVANT'
,p_display_order=>160
,p_column_identifier=>'AC'
,p_column_label=>'potentiell SUMS-Relevant'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(958135905312245351)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(978994257331260303)
,p_db_column_name=>'ANTRIEBSART'
,p_display_order=>170
,p_column_identifier=>'AN'
,p_column_label=>'Antriebsart'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(628091997576742857)
,p_db_column_name=>'REGULIERUNGS_VERANTWORTLICHER'
,p_display_order=>180
,p_column_identifier=>'AQ'
,p_column_label=>'Regulierungs&shy;verantwortlicher'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(130350120882775258)
,p_db_column_name=>'LEAD_VKO'
,p_display_order=>190
,p_column_identifier=>'AT'
,p_column_label=>'Lead VKO'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(826731258018794366)
,p_db_column_name=>'STATUS_UPDATE_GETEX'
,p_display_order=>200
,p_column_identifier=>'AR'
,p_column_label=>'Status Update Getex'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(130350382070775261)
,p_db_column_name=>'LETZTE_AENDERUNG_GETEX_ATTR'
,p_display_order=>210
,p_column_identifier=>'AS'
,p_column_label=>unistr('Letzte \00C4nderung GETEX Attribute (EDAG) ')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'pck_ri.fIsUserInRolle(listRolleId => ''1100:1003'') > 0'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(646446517105314696)
,p_db_column_name=>'REV_NOTWENDIG'
,p_display_order=>220
,p_column_identifier=>'AU'
,p_column_label=>'REV Notwendig'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(646432047862271176)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1111698025220193120)
,p_db_column_name=>'DOKUMENTENDATUM'
,p_display_order=>230
,p_column_identifier=>'AV'
,p_column_label=>'Dokumentendatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2641553980095272522)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1522075'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LINK_NETZ:PERMALINK:CHECKBOX:FLAG_KONSOLIDIERTE_FASSUNGEN:VORSCHRIFTID:VORSCHRIFT_NUMMER:DOKUMENTENDATUM:VORSCHRIFT_BEZEICHNUNG:VORSCHRIFT_TYPID:IN_KRAFT:PROGNOSE_QUALITAET:VORSCHRIFT_STATUSID:ETB_AK:THEMENGEBIETE:ANTRIEBSART:RXSWIN_RELEVANT:REGULIER'
||'UNGS_VERANTWORTLICHER:REV_NOTWENDIG:LEAD_VKO:STATUS_UPDATE_GETEX:LETZTE_AENDERUNG_GETEX_ATTR:'
,p_sort_column_1=>'VORSCHRIFT_NUMMER'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2678820793102556047)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2707059584407204267)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1043965146079715975)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2641545930668267170)
,p_button_name=>'LAENDER_INFO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('L\00E4nder')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-info-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(637525394270644003)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2641545930668267170)
,p_button_name=>'CREATE_JIRA_TICKET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Jira Ticket Assistent'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:570:&SESSION.::&DEBUG.:570, 571, 572,,573, 574:P25_VORSCHRIFTID:'
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2666289531568386537)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2641545930668267170)
,p_button_name=>'MEHRFACHBEARBEITUNG'
,p_button_static_id=>'b_MB'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Mehrfachbearbeitung'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:140:&SESSION.::&DEBUG.:RP,140:P140_LOAD_FROM:"P20_SELECTED_ROWS"'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- 1003 = Fachadmin, 1000 = VKO, 1200 = Redaktionsteam',
'pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1200'') > 0'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2641552115012267185)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(2641545930668267170)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:31:P31_VORSCHRIFT_FREIGABESTATUSID:1'
,p_button_condition=>'pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1043565716534189815)
,p_name=>'P20_FLAG_KF'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2678820793102556047)
,p_prompt=>'Flag konsolidierte Fassung vorhanden'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Wenn Benutzer VKO oder VEX ist, soll Schalter default auf einblenden',
'-- stehen, sonst auf ausblenden',
'if (pck_ri.fIsUserInRolle(listRolleId => ''1000:1002'') > 0) then',
'    return 1;',
'else',
'    return 0;',
'end if;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Normalansicht',
  'off_value', '0',
  'on_label', 'Detailansicht',
  'on_value', '1',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(634294715010589903)
,p_name=>'P20_SUPPLEMENTS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2678820793102556047)
,p_item_default=>'10'
,p_prompt=>'Supplenments'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(3414144103148820565)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'ohne Supplements',
  'off_value', '10',
  'on_label', ' mit Supplements',
  'on_value', '20',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2677393890671635652)
,p_name=>'P20_SELECTED_ROWS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2641545930668267170)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2677394780415635661)
,p_name=>'P20_URL_MEHRFACHBEARBEITUNG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2641545930668267170)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2678820529717556044)
,p_name=>'P20_SHORT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2678820793102556047)
,p_item_default=>'10'
,p_prompt=>'Anzeige'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(3414144103148820565)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Langversion',
  'off_value', '20',
  'on_label', 'Kurzversion',
  'on_value', '10',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2641551178978267183)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2641545930668267170)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2641551708299267184)
,p_event_id=>wwv_flow_imp.id(2641551178978267183)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2641545930668267170)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2641552549731267185)
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2641552115012267185)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2641552985603267185)
,p_event_id=>wwv_flow_imp.id(2641552549731267185)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2641545930668267170)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2677394129851635654)
,p_name=>'Backup OPEN_MEHRFACHBEARBEITUNG_DIALOG'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2666289531568386537)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'NEVER'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2677394216053635655)
,p_event_id=>wwv_flow_imp.id(2677394129851635654)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var sel_rows = apex.item(''P20_SELECTED_ROWS'');',
'sel_rows.setValue("");',
'$("#VSIG").find("td input:checked").each(function() {',
'  if(sel_rows.getValue().length > 0) {',
'    sel_rows.setValue(sel_rows.getValue() + ":");    ',
'  }',
'  sel_rows.setValue(sel_rows.getValue() + this.value);',
'});',
'            '))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2677394866972635662)
,p_event_id=>wwv_flow_imp.id(2677394129851635654)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :P20_URL_MEHRFACHBEARBEITUNG := APEX_UTIL.PREPARE_URL (',
'        APEX_PAGE.GET_URL (',
'            p_page => 140,',
'            --p_triggering_element => ''#b_MB'',',
'            p_items => ''P140_SELECTED_VORSCHRIFTEN'',',
'            p_values => ''\'' || :P20_SELECTED_ROWS || ''\'',',
'            p_clear_cache => 140),',
'        p_triggering_element => ''$(''''body'''')'');',
'            ',
'END;',
'',
'',
''))
,p_attribute_02=>'P20_SELECTED_ROWS'
,p_attribute_03=>'P20_URL_MEHRFACHBEARBEITUNG'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2677394980229635663)
,p_event_id=>wwv_flow_imp.id(2677394129851635654)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'eval($(''#P20_URL_MEHRFACHBEARBEITUNG'').val())',
' '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2677395529145635668)
,p_name=>'Mehrfachbearbeitung - Dialog Closed'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'body'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2677395723503635670)
,p_event_id=>wwv_flow_imp.id(2677395529145635668)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'//alert(''TEST'');'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2677395591816635669)
,p_event_id=>wwv_flow_imp.id(2677395529145635668)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2641545930668267170)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2678820568114556045)
,p_name=>'Change Variante'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P20_SHORT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2678820762175556046)
,p_event_id=>wwv_flow_imp.id(2678820568114556045)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.util.showSpinner();',
'window.location=''f?p=&APP_ID.:21:&APP_SESSION.'''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(213245700551506808)
,p_name=>'Zeilenselektor'
,p_event_sequence=>70
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'td input'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#VSIG'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213245804991506809)
,p_event_id=>wwv_flow_imp.id(213245700551506808)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var any_checked = $("#VSIG").find("td input:checked").length > 0;',
'',
'if (any_checked) {',
'    $("#b_MB").removeClass("apex_disabled");',
'} else {',
'    $("#b_MB").addClass("apex_disabled");',
'}',
'',
'$("#b_MB").prop(''disabled'', !any_checked);',
'',
'var sel_rows = apex.item(''P20_SELECTED_ROWS'');',
'sel_rows.setValue("");',
'$("#VSIG").find("td input:checked").each(function() {',
'  if(sel_rows.getValue().length > 0) {',
'    sel_rows.setValue(sel_rows.getValue() + ":");    ',
'  }',
'  sel_rows.setValue(sel_rows.getValue() + this.value);',
'});',
'            '))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(213245997981506810)
,p_event_id=>wwv_flow_imp.id(213245700551506808)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P20_SELECTED_ROWS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1049339277611202202)
,p_name=>unistr('L\00E4nderinfo')
,p_event_sequence=>80
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'button#b_laender_info'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1049339190455202201)
,p_event_id=>wwv_flow_imp.id(1049339277611202202)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'apex.server.process(',
'    ''prepare_laender'',                           ',
'    {',
'        x01: ''Mehrfachbearbeitung'',',
'        x02: $v(''P10_SELECTED_IDS'').replace(/:/g, "|")',
'    }, ',
'    {',
'        success: function (pData)',
'        {           ',
'            apex.navigation.redirect(pData);',
'        },',
'        dataType: "text"                     ',
'    }',
');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1043965069282715974)
,p_name=>unistr('Klick Button L\00E4nder Info')
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1043965146079715975)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1043964938579715973)
,p_event_id=>wwv_flow_imp.id(1043965069282715974)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'javascript:window.open(''f?p=&APP_ID.:130:&SESSION.'',''_blank'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(634294614939589902)
,p_name=>'Switch Filter'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P20_SUPPLEMENTS,P20_FLAG_KF'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(634294503381589901)
,p_event_id=>wwv_flow_imp.id(634294614939589902)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2641545930668267170)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44055512572412462)
,p_name=>'hide create Jira ticket button'
,p_event_sequence=>110
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NOT_EXISTS'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from t_benutzer_ref_rolle where benutzerid=:G_BENUTZERID',
'AND rolleid in (1200,1003,1000 )'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44055432567412461)
,p_event_id=>wwv_flow_imp.id(44055512572412462)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(637525394270644003)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(988068839392880411)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'rebuild_text_Indexes'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN ',
'    FOR idx IN ( SELECT index_name FROM user_indexes WHERE index_type = ''DOMAIN'' and Table_name like ''T_VORSCHRIFT%'' ) LOOP ',
'        BEGIN ',
'            EXECUTE IMMEDIATE ''DROP INDEX '' || idx.index_name || '' FORCE''; ',
'        EXCEPTION ',
'        WHEN OTHERS THEN NULL; ',
'        END; ',
'    END LOOP; ',
'    -- Create basic Oracle Text index',
'    EXECUTE IMMEDIATE ''CREATE INDEX RI_VORSCHRIFT_TEXT_FTX ON T_VORSCHRIFT(VORSCHRIFT_NUMMER) INDEXTYPE IS ctxsys.context'';',
'    EXECUTE IMMEDIATE ''CREATE INDEX RI_VORSCHRIFT_TEXT_BEZEICHN_FTX ON  T_VORSCHRIFT(VORSCHRIFT_BEZEICHNUNG) INDEXTYPE IS ctxsys.context'';',
'    apex_application.g_print_success_message := ''Oracle Text index created successfully!'';',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_application.g_print_success_message := ''Error creating index: '' || SQLERRM;',
'        RAISE;',
' END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2684143476506507824
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1049339064430202200)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'prepare_laender'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_url varchar2(2000);',
'    l_app number := v(''APP_ID'');',
'    l_session number := v(''APP_SESSION'');',
'',
'    --l_page_item VARCHAR2(2000) := case when apex_application.g_x01 = ''Einzelbearbeitung'' then ''P15_BEWERTUNG_ID'' when apex_application.g_x01 = ''Mehrfachbearbeitung'' then ''P15_SELECTED_IDS'' end;',
'BEGIN',
'    l_url := APEX_UTIL.PREPARE_URL(',
'        p_url => ''f?p='' || l_app || '':300:'' || l_session || ''::NO:300::'' || apex_application.g_x02,',
'        p_checksum_type => ''SESSION'');',
'    htp.p(l_url);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2622873251469186035
);
wwv_flow_imp.component_end;
end;
/
