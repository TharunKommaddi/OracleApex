prompt --application/pages/page_00410
begin
--   Manifest
--     PAGE: 00410
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>410
,p_name=>'Regulierungsverantwortliche'
,p_alias=>'REGULIERUNGSVERANTWORTLICHE'
,p_step_title=>'Regulierungsverantwortliche'
,p_reload_on_submit=>'A'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#RVIR_toolbar_controls'').append('' <span onclick="redirect(183)" style="font-size:2.7em" class="fa fa-question-square-o"></span>'');',
'',
'$(''#RVIR'').on(''click'', ''th input'', function() {',
'    var check_all = $("#RVIR").find("th input:checked").is(":checked");',
'',
unistr('    // alle Zeilen ausw\00E4hlen/abw\00E4hlen'),
'    $("#RVIR").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'    // Button aktivieren/deaktivieren',
'    if (check_all) {',
'        $("#b_KG").removeClass("apex_disabled");',
'    } else {',
'        $("#b_KG").addClass("apex_disabled");',
'    }',
'',
'    $("#b_KG").prop(''disabled'', !check_all);',
'    ',
unistr('    // alle ausgew\00E4hlten Zeilen-IDs in das Item P20_SELECTED_ROWS'),
'    var sel_rows = apex.item(''P410_SELECTED'');',
'    sel_rows.setValue("");',
'    $("#RVIR").find("td input:checked").each(function() {',
'      if(sel_rows.getValue().length > 0) {',
'        sel_rows.setValue(sel_rows.getValue() + ":");    ',
'      }',
'      sel_rows.setValue(sel_rows.getValue() + this.value);',
'    });',
'    apex.server.process(''MY_PROCESS'', {',
'        pageItems: ''#P410_SELECTED''',
'    },{dataType: ''text''});',
'    //alert (sel_rows.getValue());',
'});'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2033585399293344554)
,p_plug_name=>'Neue Kontrollgruppe erstellen'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'pck_ri.fIsUserInRolle(listRolleId => ''1200:1003'') > 0'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2959057726928973163)
,p_plug_name=>'Regulierungsverantwortliche'
,p_region_name=>'RVIR'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    select verantwortlicherid,',
'        listagg(case when vrv.ist_hauptverantwortlicher = 10 then ''<span style="text-decoration: underline;">'' else ''<span>'' end || vo.vorschrift_nummer || ''</span>'', '', '') within group (order by vrv.VORSCHRIFT_REF_VERANTWORTLICHERID) as liste_vorsch'
||'riften,',
'    -- listagg(distinct trim(vo.swr_hauptumsetzende_oe||''-''||vo.vorschriftid), '', '') within group (order by vrv.VORSCHRIFT_REF_VERANTWORTLICHERID)  as liste_hauptumsetzende_oe',
'    listagg(distinct trim(vo.swr_hauptumsetzende_oe), '', '') within group (order by vrv.VORSCHRIFT_REF_VERANTWORTLICHERID)  as liste_hauptumsetzende_oe',
'    from t_vorschrift_ref_verantwortlicher vrv',
'    left outer join t_vorschrift vo on (vrv.vorschriftid = vo.vorschriftid)',
'    group by vrv.verantwortlicherid    ',
')',
'',
'',
'select ',
'       v.ROWID,',
'       v.VERANTWORTLICHERID,',
'       v.verantwortlicherid as verantwortlicherid_fuer_linkspalte,',
'       NACHNAME,',
'       VORNAME,',
'       ABTEILUNG,',
'       EMAIL,',
'       GID,',
'       cte1.liste_vorschriften,',
'       cte1.liste_hauptumsetzende_oe',
'       ',
'  from T_VERANTWORTLICHER v',
'  left outer join cte1 on (v.verantwortlicherid = cte1.verantwortlicherid)',
'ORDER BY NACHNAME, VORNAME, liste_vorschriften, liste_hauptumsetzende_oe',
'',
'  '))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Regulierungsverantwortliche'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2959058088098973163)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:415:&SESSION.::&DEBUG.:415:P415_VERANTWORTLICHERID:#VERANTWORTLICHERID_FUER_LINKSPALTE#'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-pencil" aria-hidden="true" title="Edit"></span></span>'
,p_detail_link_condition_type=>'EXPRESSION'
,p_detail_link_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(userId => PCK_RI.fGetUserId, ',
'                      pageId => :APP_PAGE_ID,',
'                      accessMode => 200))'))
,p_detail_link_cond2=>'PLSQL'
,p_description=>wwv_flow_string.join(wwv_flow_t_varchar2(
'P415_ROWID    \#ROWID#\ ',
'',
'',
'<span aria-label="Edit"><span class="fa fa-pencil" aria-hidden="true" title="Edit"></span></span>',
'',
'',
'(PCK_RI.fIsAuthorized(userId => PCK_RI.fGetUserId, ',
'                      pageId => :APP_PAGE_ID,',
'                      accessMode => 200))'))
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>6631270403998361398
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1073558964719238711)
,p_db_column_name=>'ROWID'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Rowid'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1073558544134238710)
,p_db_column_name=>'VERANTWORTLICHERID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'<input type="checkbox" value="all" />'
,p_column_html_expression=>'<input type="checkbox" value="#VERANTWORTLICHERID#" />'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_rpt_show_filter_lov=>'N'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'pck_ri.fIsUserInRolle(listRolleId => ''1200:1003'') > 0'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1073558169949238710)
,p_db_column_name=>'NACHNAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Nachname'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1073557778836238710)
,p_db_column_name=>'VORNAME'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Vorname'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1073557333802238709)
,p_db_column_name=>'ABTEILUNG'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Abteilung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1073556945199238709)
,p_db_column_name=>'EMAIL'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'E-Mail'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1073556607898238708)
,p_db_column_name=>'GID'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'GID'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1073556144530238708)
,p_db_column_name=>'LISTE_VORSCHRIFTEN'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'zugeordnete Vorschriften'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1073555789378238708)
,p_db_column_name=>'LISTE_HAUPTUMSETZENDE_OE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'OE2 des REV'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3161597645994801217)
,p_db_column_name=>'VERANTWORTLICHERID_FUER_LINKSPALTE'
,p_display_order=>100
,p_column_identifier=>'K'
,p_column_label=>'Verantwortlicherid Fuer Linkspalte'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2959077018543023043)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4170289'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1000
,p_report_columns=>'VERANTWORTLICHERID:NACHNAME:VORNAME:ABTEILUNG:EMAIL:GID:LISTE_VORSCHRIFTEN:LISTE_HAUPTUMSETZENDE_OE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1073553182470238696)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2033585399293344554)
,p_button_name=>'ERSTELLEN'
,p_button_static_id=>'b_KG'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1073552785776238696)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2033585399293344554)
,p_button_name=>'ZUR_LISTE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Zur Liste der Kontrollgruppen'
,p_button_position=>'COPY'
,p_button_redirect_url=>'f?p=&APP_ID.:425:&SESSION.::&DEBUG.:425::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1072843130580081021)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2033585399293344554)
,p_button_name=>'ZUR_AELISTE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Zur \00C4nderungsliste')
,p_button_position=>'COPY'
,p_button_redirect_url=>'f?p=&APP_ID.:423:&SESSION.::&DEBUG.:423::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1073555052595238698)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2959057726928973163)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:415:&SESSION.::&DEBUG.:415'
,p_button_condition_type=>'NEVER'
,p_button_comment=>unistr('Ausgeblendet, weil manuelle Anlage nicht vorgesehen ist, sondern neue Verantwortliche \00FCber LDAP gesucht werden sollen')
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1073554648506238697)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2959057726928973163)
,p_button_name=>'EXPORT_VORSCHRIFT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'Export Nach Vorschriften'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-file-excel-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1073554221707238697)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2959057726928973163)
,p_button_name=>'EXPORT_REV'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'Export Nach Regulierungsverantwortliche'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-file-excel-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1073553876484238696)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(2959057726928973163)
,p_button_name=>'SEARCH_LDAP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'In LDAP suchen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:65:&SESSION.::&DEBUG.:65:P65_CAMEFROM:410'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(userId => PCK_RI.fGetUserId, ',
'                      pageId => :APP_PAGE_ID,',
'                      accessMode => 200))'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1073552335670238695)
,p_name=>'P410_NAME'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2033585399293344554)
,p_prompt=>'Name der Kontrollgruppe'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1073551921575238695)
,p_name=>'P410_SELECTED'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2033585399293344554)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1073550333102238693)
,p_name=>'Refresh Regulierungs region'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2959057726928973163)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1073549822326238693)
,p_event_id=>wwv_flow_imp.id(1073550333102238693)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2959057726928973163)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1073549422869238693)
,p_name=>'Refresh Search LDAP button'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1073553876484238696)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1073548952954238692)
,p_event_id=>wwv_flow_imp.id(1073549422869238693)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2959057726928973163)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1073548559868238692)
,p_name=>'Zeilenselektor'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'td input'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#RVIR'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1073548044877238692)
,p_event_id=>wwv_flow_imp.id(1073548559868238692)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var any_checked = $("#RVIR").find("td input:checked").length > 0;',
'',
'if (any_checked) {',
'    $("#b_KG").removeClass("apex_disabled");',
'} else {',
'    $("#b_KG").addClass("apex_disabled");',
'}',
'',
'$("#b_KG").prop(''disabled'', !any_checked);',
'',
'var sel_rows = apex.item(''P410_SELECTED'');',
'sel_rows.setValue("");',
'$("#RVIR").find("td input:checked").each(function() {',
'  if(sel_rows.getValue().length > 0) {',
'    sel_rows.setValue(sel_rows.getValue() + ":");    ',
'  }',
'  sel_rows.setValue(sel_rows.getValue() + this.value);',
'});',
'            '))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1073547570264238692)
,p_event_id=>wwv_flow_imp.id(1073548559868238692)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P410_SELECTED'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1073551572582238695)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Export_Vorschrift'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lContext apex_exec.t_context; ',
'    l_print_config    apex_data_export.t_print_config;',
'    lExport  apex_data_export.t_export; ',
'    lColumns apex_data_export.t_columns; ',
'    lColumnGroups apex_data_export.t_column_groups;',
'    lGroup1 number;',
'    l_name VARCHAR2(255);',
'    lTitle varchar2(250);',
'BEGIN',
'    -- Retrieve the user''s name',
'    SELECT b.nachname || ''_'' || b.vorname',
'    INTO l_name',
'    FROM t_benutzer b',
'    WHERE benutzerid = :G_BENUTZERID;',
'',
'    lTitle := ''Liste Vorschriften'';',
'',
'    lContext := apex_exec.open_query_context(',
'            p_location    => apex_exec.c_location_local_db,',
'            p_sql_query   => q''[',
'        with cte1 as (',
'            SELECT vrv.vorschriftid,',
'                    LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 10 then (verant.vorname || '' '' ||verant.nachname) end, '', '') within group (order by verant.nachname, verant.vorname)as Hauptverantwortliche_REV_Name,',
'                    LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 10 then (verant.email) end, '', '') within group (order by verant.nachname)as Hauptverantwortliche_REV_Mail,',
'                    LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 10 then (verant.abteilung) end, '', '') within group (order by verant.nachname)as Hauptverantwortliche_REV_Abteilung,',
'                    LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 20 then (verant.vorname || '' '' ||verant.nachname) end, '', '') within group (order by verant.nachname, verant.vorname)as Stellvertreter_REV_Name,',
'                    LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 20 then (verant.email) end, '', '') within group (order by verant.nachname)as Stellvertreter_REV_Mail,',
'                    LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 20 then (verant.abteilung) end, '', '') within group (order by verant.nachname)as Stellvertreter_REV_Abteilung',
'            FROM t_vorschrift_ref_verantwortlicher vrv',
'            left outer join t_verantwortlicher verant ON verant.verantwortlicherid = vrv.verantwortlicherid',
'            group by vrv.vorschriftid',
'        )',
'        SELECT vor.vorschrift_nummer,',
'                verantw.Hauptverantwortliche_REV_Name,',
'                verantw.Hauptverantwortliche_REV_Mail,',
'                verantw.Hauptverantwortliche_REV_Abteilung,',
'                vor.swr_hauptumsetzende_oe,',
'                verantw.Stellvertreter_REV_Name,',
'                verantw.Stellvertreter_REV_Mail,',
'                verantw.Stellvertreter_REV_Abteilung,',
'                case when vor.rxswin = 10 then ''Ja'' end as RXSWIN,',
'                decode(vor.rev_notwendig,10,''Nicht bewertet'',20,''Ja'',30,''Nein'') as REV_NOTWENDIG',
'                FROM t_vorschrift vor',
'                left outer JOIN cte1 verantw ON vor.vorschriftid = verantw.vorschriftid',
'                WHERE',
'                    vor.rxswin = 10',
'                order by vor.vorschrift_nummer;',
'        ]'');',
'',
'       l_print_config := apex_data_export.get_print_config(',
'            p_page_header => lTitle,',
'            p_header_font_family => ''Audi Type'',',
'            p_header_font_size => 10,',
'            p_body_font_family => ''Audi Type'',',
'            p_body_font_size => 10,',
'            p_border_width    => 0.5,',
'            p_page_footer_font_family => ''Audi Type'',',
'            p_page_footer_font_size => 10,',
'            p_header_bg_color => ''#D0D0D0''',
'        );',
'',
'        apex_data_export.add_column_group(',
'            p_column_groups => lColumnGroups,',
'            p_idx => lGroup1,',
'            p_name => ''VORSCHRIFTEN Liste Vorschriften potentiell SUMS relevant '' || to_char(sysdate,''dd.mm.yyyy'') || '' - intern'',',
'            p_alignment => apex_data_export.c_align_start',
'        );',
'',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''VORSCHRIFT_NUMMER'',',
'            p_heading => ''Vorschriften Nummer'',',
'            p_column_group_idx => lGroup1',
'        ); ',
'',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''HAUPTVERANTWORTLICHE_REV_NAME'',',
'            p_heading => ''Hauptverantwortliche REV Name'',',
'            p_column_group_idx => lGroup1',
'        );   ',
'',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''HAUPTVERANTWORTLICHE_REV_MAIL'',',
'            p_heading => ''Hauptverantwortliche REV E-Mail'',',
'            p_column_group_idx => lGroup1',
'        );          ',
'',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''HAUPTVERANTWORTLICHE_REV_ABTEILUNG'',',
'            p_heading => ''Hauptverantwortliche REV Abteilung'',',
'            p_column_group_idx => lGroup1',
'        );           ',
'',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''SWR_HAUPTUMSETZENDE_OE'',',
'            p_heading => ''Hauptumsetzende OE2'',',
'            p_column_group_idx => lGroup1',
'        );',
'',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''STELLVERTRETER_REV_NAME'',',
'            p_heading => ''Stellvertreter REV Name'',',
'            p_column_group_idx => lGroup1',
'        );   ',
'',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''STELLVERTRETER_REV_MAIL'',',
'            p_heading => ''Stellvertreter REV E-Mail'',',
'            p_column_group_idx => lGroup1',
'        );          ',
'',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''STELLVERTRETER_REV_ABTEILUNG'',',
'            p_heading => ''Stellvertreter REV Abteilung'',',
'            p_column_group_idx => lGroup1',
'        );           ',
'',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''RXSWIN'',',
'            p_heading => ''Potentiell SUMS relevant'',',
'            p_column_group_idx => lGroup1',
'        );',
'',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''REV_NOTWENDIG'',',
'            p_heading => ''Attribut REV notwendig'',',
'            p_column_group_idx => lGroup1',
'        );',
'',
'        lExport := apex_data_export.export (',
'                            p_context   => lContext,',
'                            p_print_config => l_print_config,',
'                            p_columns => lColumns,',
'                            p_column_groups => lColumnGroups,',
'                            p_format    => apex_data_export.c_format_xlsx,',
'                            p_file_name => ''VORSCHRIFTEN Liste Vorschriften potentiell SUMS relevant '' || to_char(sysdate,''dd.mm.yyyy'') || '' - intern.xlsx'' );',
'',
'        apex_exec.close(lContext);',
'        apex_data_export.download(p_export => lExport);',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_exec.close(lContext);',
'        RAISE;',
'',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1073554648506238697)
,p_internal_uid=>2598660743317149540
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1073551164955238694)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Export_REV'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lContext apex_exec.t_context; ',
'    l_print_config    apex_data_export.t_print_config;',
'    lExport  apex_data_export.t_export; ',
'    lColumns apex_data_export.t_columns; ',
'    lColumnGroups apex_data_export.t_column_groups;',
'    lGroup1 number;',
'    l_name VARCHAR2(255);',
'    lTitle varchar2(250);',
'BEGIN',
'    -- Retrieve the user''s name',
'    SELECT b.nachname || ''_'' || b.vorname',
'    INTO l_name',
'    FROM t_benutzer b',
'    WHERE benutzerid = :G_BENUTZERID;',
'',
'    lTitle := ''Liste REV'';',
'',
'    lContext := apex_exec.open_query_context(',
'            p_location    => apex_exec.c_location_local_db,',
'            p_sql_query   => q''[',
'        with cte1 as (',
'            select verantwortlicherid,',
'                    LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 10 then vor.vorschrift_nummer end, '', '') within group (order by vrv.VORSCHRIFT_REF_VERANTWORTLICHERID)as VORSCHRIFTEN_MIT_HAUPTVERANTWORTUNG,',
'                    LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 10 then vor.swr_hauptumsetzende_oe end, ''; '') within group (order by vrv.VORSCHRIFT_REF_VERANTWORTLICHERID)as HAUPTUMSETZENDE_OE,',
'                    LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 10 then decode(vor.rev_notwendig,10,''Nicht bewertet'',20,''Ja'',30,''Nein'') end, '', '') within group (order by vrv.VORSCHRIFT_REF_VERANTWORTLICHERID)as REV_NOTWENDIG,',
'                    LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 20 then vor.vorschrift_nummer end, '', '') within group (order by vrv.VORSCHRIFT_REF_VERANTWORTLICHERID)as VORSCHRIFTEN_MIT_Stellvertreterverantwortung,',
'                    LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 20 then vor.swr_hauptumsetzende_oe end, ''; '') within group (order by vrv.VORSCHRIFT_REF_VERANTWORTLICHERID)as HAUPTUMSETZENDE_OE_Stellvertreterverantwortung,',
'                    LISTAGG(distinct case when vrv.ist_hauptverantwortlicher = 20 then decode(vor.rev_notwendig,10,''Nicht bewertet'',20,''Ja'',30,''Nein'') end, '', '') within group (order by vrv.VORSCHRIFT_REF_VERANTWORTLICHERID)as REV_NOTWENDIG_Stellvertr'
||'eterverantwortung',
'            FROM t_vorschrift_ref_verantwortlicher vrv',
'            left outer join t_vorschrift       vor ON vor.vorschriftid = vrv.vorschriftid',
'            group by vrv.verantwortlicherid ',
'        )  ',
'        SELECT distinct (v.nachname  || '', '' || v.vorname) as REV,',
'                v.abteilung,',
'                v.email,',
'                verant.VORSCHRIFTEN_MIT_HAUPTVERANTWORTUNG,',
'                verant.HAUPTUMSETZENDE_OE,',
'                verant.REV_NOTWENDIG,',
'                verant.VORSCHRIFTEN_MIT_STELLVERTRETERVERANTWORTUNG,',
'                verant.HAUPTUMSETZENDE_OE_STELLVERTRETERVERANTWORTUNG,',
'                verant.REV_NOTWENDIG_STELLVERTRETERVERANTWORTUNG',
'                from T_VERANTWORTLICHER v',
'                left outer join cte1 verant ON verant.verantwortlicherid = v.verantwortlicherid',
'                ORDER BY REV;',
'        ]'');',
'',
'       l_print_config := apex_data_export.get_print_config(',
'            p_page_header => lTitle,',
'            p_header_font_family => ''Audi Type'',',
'            p_header_font_size => 10,',
'            p_body_font_family => ''Audi Type'',',
'            p_body_font_size => 10,',
'            p_border_width    => 0.5,',
'            p_page_footer_font_family => ''Audi Type'',',
'            p_page_footer_font_size => 10,',
'            p_header_bg_color => ''#D0D0D0''',
'        );',
'',
'        apex_data_export.add_column_group(',
'            p_column_groups => lColumnGroups,',
'            p_idx => lGroup1,',
'            p_name => ''VORSCHRIFTEN Liste Regulierungsverantwortliche '' || to_char(sysdate,''dd.mm.yyyy'') || '' - intern'',',
'            p_alignment => apex_data_export.c_align_start',
'        );',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''REV'',',
'            p_heading => ''Regulierungsverantwortlicher'',',
'            p_column_group_idx => lGroup1',
'        ); ',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''ABTEILUNG'',',
'            p_heading => ''REV Abteilung'',',
'            p_column_group_idx => lGroup1',
'        );   ',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''EMAIL'',',
'            p_heading => ''REV E-Mail'',',
'            p_column_group_idx => lGroup1',
'        );',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''VORSCHRIFTEN_MIT_HAUPTVERANTWORTUNG'',',
'            p_heading => ''Vorschriften mit Hauptverantwortung'',',
'            p_column_group_idx => lGroup1',
'        );   ',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''HAUPTUMSETZENDE_OE'',',
'            p_heading => ''Hauptumsetzende OE2 '',',
'            p_column_group_idx => lGroup1',
'        );   ',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''REV_NOTWENDIG'',',
'            p_heading => ''REV notwendig'',',
'            p_column_group_idx => lGroup1',
'        );   ',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''VORSCHRIFTEN_MIT_STELLVERTRETERVERANTWORTUNG'',',
'            p_heading => ''Vorschriften mit Stellvertreterverantwortung'',',
'            p_column_group_idx => lGroup1',
'        );   ',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''HAUPTUMSETZENDE_OE_STELLVERTRETERVERANTWORTUNG'',',
'            p_heading => ''Hauptumsetzende OE2 '',',
'            p_column_group_idx => lGroup1',
'        );   ',
'        apex_data_export.add_column(',
'            p_columns => lColumns,',
'            p_name => ''REV_NOTWENDIG_STELLVERTRETERVERANTWORTUNG'',',
'            p_heading => ''REV notwendig'',',
'            p_column_group_idx => lGroup1',
'        );   ',
'',
'        lExport := apex_data_export.export (',
'                            p_context   => lContext,',
'                            p_print_config => l_print_config,',
'                            p_columns => lColumns,',
'                            p_column_groups => lColumnGroups,',
'                            p_format    => apex_data_export.c_format_xlsx,',
'                            p_file_name => ''VORSCHRIFTEN Liste Regulierungsverantwortliche '' || to_char(sysdate,''dd.mm.yyyy'') || '' - intern.xlsx'' );',
'',
'        apex_exec.close(lContext);',
'        apex_data_export.download(p_export => lExport);',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_exec.close(lContext);',
'        RAISE;',
'',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1073554221707238697)
,p_internal_uid=>2598661150944149541
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1073550749937238693)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Kontrollgruppe erstellen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_rev.pErstelleKontrollGruppe(:P410_NAME, :P410_SELECTED);',
':P410_NAME := null;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1073553182470238696)
,p_process_success_message=>'Kontrollgruppe erstellt.'
,p_internal_uid=>2598661565962149542
);
wwv_flow_imp.component_end;
end;
/
