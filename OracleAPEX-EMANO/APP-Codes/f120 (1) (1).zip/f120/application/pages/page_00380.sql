prompt --application/pages/page_00380
begin
--   Manifest
--     PAGE: 00380
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>380
,p_name=>unistr('\00DCbersicht Arbeitskreise')
,p_alias=>unistr('\00DCBERSICHT-ET-B-AK')
,p_step_title=>unistr('\00DCbersicht Arbeitskreise')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(917287373573928187)
,p_plug_name=>'Report Arbeitskreise'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_themen as (',
'    select listagg(t.nummer /*|| '' - '' || t.bezeichnung*/, '', '') as thema_list, trak.et_b_akid',
'    from t_thema t',
'    inner join t_thema_ref_et_b_ak trak on (trak.themaid = t.themaid)',
'    group by  trak.et_b_akid',
'),',
'cte_konzern_cluster as (',
'    select listagg(kc.bezeichnung, '', '') as cluster_list, kcrak.et_b_akid',
'    from t_konzern_cluster kc',
'    inner join t_konzern_cluster_ref_et_b_ak kcrak on (kcrak.konzern_clusterid = kc.konzern_clusterid)',
'    group by  kcrak.et_b_akid',
')',
'/* cte_betr as ( select distinct b.nachname||'',''||b.vorname as d, ET_B_AK_REF_THEMA_BENUTZERID r ',
'                 from t_ET_B_AK_REF_THEMA_BENUTZER artb',
'                 join t_benutzer b on (b.benutzerid = artb.benutzerid )',
'                where RolleId = 1002  --and  artb.benutzerid != :P387_R_BENUTZERID',
'               order by 1',
')*/',
'select distinct ak.ET_B_AKID,',
'       ',
'       ak.KURZ,',
'       CASE ',
'    WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ak.BEZEICHNUNG',
'    ELSE ak.name_eng',
'END BEZEICHNUNG,',
'       ct.thema_list as thema_list,',
'       ct_kc.cluster_list as konzern_cluster_list,',
'       ak.haeufigkeit,',
'       ak.LETZTE_AENDERUNG_DATUM,',
'       nvl2(ak.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) as LETZTE_AENDERUNG_BENUTZER',
'      --, bet.d betreuer',
'  from T_ET_B_AK ak',
'  left outer join t_benutzer b on b.benutzerid = ak.LETZTE_AENDERUNG_BENUTZERID',
'  left outer join cte_themen ct on (ct.et_b_akid = ak.et_b_akid)',
'  left outer join cte_konzern_cluster ct_kc on (ct_kc.et_b_akid = ak.et_b_akid)',
'  --left outer join t_et_b_ak_ref_thema_benutzer artb on (artb.et_b_akid = ak.et_b_akid)',
'  --left outer join cte_betr bet on (bet.r = artb.betreuerid)',
'',
'where ak.et_b_akid not in ( 1200, 1400) -- Admin AK, AK REDACTION ausblenden',
'   and (:G_benutzerid in (select benutzerid from t_benutzer_ref_rolle where rolleid in (1003, 1000, 1002, 1005, 1006, 1050)) -- roll ids ',
'        OR ( :G_Benutzerid in (select benutzerid from T_benutzer_ref_rolle ) --where rolleid  =1002) ',
'            AND ',
'            ( ak.et_b_akid in (select et_b_akid from T_et_b_ak_ref_benutzer where benutzerid = :G_benutzerid )',
'              OR  ak.et_b_akid in ( select et_b_akid from T_et_b_ak_ref_THEMA_Benutzer where benutzerid = :G_benutzerid)',
'            )',
'        )',
'    )'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Report Arbeitskreise'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(917286956338928187)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:385:&SESSION.::&DEBUG.:RP,385:P385_ET_B_AKID:\#ET_B_AKID#\'
,p_detail_link_text=>'<span aria-label="Bearbeiten"><span class="fa fa-pencil" aria-hidden="true" title="Bearbeiten"></span></span>'
,p_detail_link_condition_type=>'EXISTS'
,p_detail_link_cond=>'select * from t_benutzer_ref_rolle where benutzerid=:G_Benutzerid and rolleid in (1000, 1003, 1002)'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>195405980756206217
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(917286925602928176)
,p_db_column_name=>'ET_B_AKID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Et B Akid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(917286120300928165)
,p_db_column_name=>'KURZ'
,p_display_order=>11
,p_column_identifier=>'C'
,p_column_label=>'Kurzbezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(863763484400305702)
,p_db_column_name=>'THEMA_LIST'
,p_display_order=>31
,p_column_identifier=>'G'
,p_column_label=>'Themen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(773132273232399301)
,p_db_column_name=>'HAEUFIGKEIT'
,p_display_order=>41
,p_column_identifier=>'I'
,p_column_label=>unistr('H\00E4ufigkeit')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(917285665412928164)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>51
,p_column_identifier=>'D'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(931186539131163898)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>61
,p_column_identifier=>'F'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(805044012315596403)
,p_db_column_name=>'KONZERN_CLUSTER_LIST'
,p_display_order=>71
,p_column_identifier=>'H'
,p_column_label=>'Konzern Cluster Liste'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949206251442439858)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>81
,p_column_identifier=>'K'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(917281236697911571)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1954118'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'KURZ:BEZEICHNUNG:KONZERN_CLUSTER_LIST:THEMA_LIST:HAEUFIGKEIT:LETZTE_AENDERUNG_DATUM:LETZTE_AENDERUNG_BENUTZER:'
,p_sort_column_1=>'KURZ'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(917283184462928128)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(917287373573928187)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:385:&SESSION.::&DEBUG.:385'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_button_comment=>'f useer has write access'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(917284236238928130)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(917287373573928187)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(917283722739928129)
,p_event_id=>wwv_flow_imp.id(917284236238928130)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(917287373573928187)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44056070809412468)
,p_name=>'hide Button'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NOT_EXISTS'
,p_display_when_cond=>'select * from t_benutzer_ref_rolle where benutzerid=:G_Benutzerid and rolleid in (1000, 1003)'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44055963818412467)
,p_event_id=>wwv_flow_imp.id(44056070809412468)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(917283184462928128)
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_da_action_comment=>'f user has write access'
);
wwv_flow_imp.component_end;
end;
/
