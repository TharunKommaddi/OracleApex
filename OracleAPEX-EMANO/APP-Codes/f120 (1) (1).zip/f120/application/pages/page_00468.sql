prompt --application/pages/page_00468
begin
--   Manifest
--     PAGE: 00468
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>468
,p_name=>'Massenupdate - Schritt 2 (Validierung)'
,p_alias=>'MASSENUPDATE-SCHRITT-2-VALIDIERUNG'
,p_page_mode=>'MODAL'
,p_step_title=>'Massenupdate - Schritt 2 (Validierung)'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* tr:hover .t-Button {',
'    background-color: black !important;',
'    color: white !important;',
'} */',
'',
'',
'/* Hover state - all turn white */',
'',
'/* ET Verwendung text white on hover */',
'tr:hover span[style*="color: #666"],',
'tr:hover span[style*="color: #27ae60"], ',
'tr:hover span[style*="color: #e74c3c"] {',
'    color: #ffffff !important;',
'}',
'',
'/* ET Verwendung icons white on hover */',
'tr:hover .fa-check,',
'tr:hover .fa-times {',
'    color: #ffffff !important;',
'}',
'',
'',
'',
'.apex_disabled {',
'    opacity: 0.5 !important;',
'    cursor: not-allowed !important;',
'    pointer-events: none !important;',
'}'))
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_dialog_width=>'1000'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2315978528315996624)
,p_plug_name=>unistr('Ausgew\00E4hlte Vorschriften f\00FCr Update - 17.09.2025')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-top-lg'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>170
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH selected_regulations AS (',
'    SELECT TO_NUMBER(COLUMN_VALUE) AS vorschriftid',
'    FROM TABLE(apex_string.split(:P468_SELECTED_ROWS, '':''))',
'    WHERE COLUMN_VALUE IS NOT NULL',
'),',
'card_countries AS (',
'    SELECT COUNT(DISTINCT landid) as total_countries',
'    FROM t_ms_suche_split ',
'    WHERE card_number = :P468_CARD_NUM ',
'    AND benutzerid = :G_BENUTZERID',
'),',
'-- Check for theme contradictions',
'theme_contradictions AS (',
'    SELECT ',
'        ms.sucheid,',
'        ms.meilenstein,',
'        ms.landid,',
'        CASE ',
'            WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'            ELSE ms.vorschriftid',
'        END as effective_vorschrift_id,',
'        COUNT(DISTINCT ms.themabezeichnung) as theme_count,',
'        LISTAGG(DISTINCT ms.themabezeichnung, ''; '') WITHIN GROUP (ORDER BY ms.themabezeichnung) as all_themes',
'    FROM t_ms_suchergebniss ms',
'    INNER JOIN t_ms_suche_split split ON (',
'        split.sucheid = ms.sucheid ',
'        AND split.meilenstein = ms.meilenstein ',
'        AND split.landid = ms.landid',
'        AND split.card_number = :P468_CARD_NUM',
'        AND split.benutzerid = :G_BENUTZERID',
'    )',
'    WHERE ms.sucheid = :P468_SEARCH_SELECTION',
'    AND ms.meilenstein = :P468_MILESTONE_SELECTION',
'    AND (CASE ',
'        WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'        ELSE ms.vorschriftid',
'    END) IN (SELECT vorschriftid FROM selected_regulations)',
'    GROUP BY ',
'        ms.sucheid, ms.meilenstein, ms.landid,',
'        CASE ',
'            WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'            ELSE ms.vorschriftid',
'        END',
'),',
'-- Check for alternative contradictions',
'alternative_contradictions AS (',
'    SELECT ',
'        CASE ',
'            WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'            ELSE ms.vorschriftid',
'        END as effective_vorschrift_id,',
'        COUNT(DISTINCT COALESCE(va.vorschrift_nummer, vm.vorschrift_nummer)) as alt_count,',
'        LISTAGG(DISTINCT COALESCE(va.vorschrift_nummer, vm.vorschrift_nummer), ''; '') ',
'        WITHIN GROUP (ORDER BY COALESCE(va.vorschrift_nummer, vm.vorschrift_nummer)) as all_alternatives',
'    FROM t_ms_suchergebniss ms',
'    INNER JOIN t_ms_suche_split split ON (',
'        split.sucheid = ms.sucheid ',
'        AND split.meilenstein = ms.meilenstein ',
'        AND split.landid = ms.landid',
'        AND split.card_number = :P468_CARD_NUM',
'        AND split.benutzerid = :G_BENUTZERID',
'    )',
'    LEFT JOIN t_vorschrift vm ON ms.vorschriftid = vm.vorschriftid',
'    LEFT JOIN t_vorschrift va ON ms.alternative_vorschriftid = va.vorschriftid',
'    WHERE ms.sucheid = :P468_SEARCH_SELECTION',
'    AND ms.meilenstein = :P468_MILESTONE_SELECTION',
'    AND (CASE ',
'        WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'        ELSE ms.vorschriftid',
'    END) IN (SELECT vorschriftid FROM selected_regulations)',
'    -- Check for regulations that have the same base regulation but different alternatives',
'    AND EXISTS (',
'        SELECT 1 FROM t_ms_suchergebniss ms2',
'        WHERE ms2.vorschriftid = ms.vorschriftid',
'        AND ms2.sucheid = ms.sucheid',
'        AND ms2.meilenstein = ms.meilenstein',
'        AND NVL(ms2.alternative_vorschriftid, 0) != NVL(ms.alternative_vorschriftid, 0)',
'    )',
'    GROUP BY ',
'        CASE ',
'            WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'            ELSE ms.vorschriftid',
'        END',
'),',
'-- UNECE Highest Series Logic',
'unece_series_analysis AS (',
'    SELECT ',
'        base_reg.effective_vorschrift_id,',
'        base_reg.vorschrift_nummer,',
'        base_reg.publisher,',
'        -- Extract series number from regulation number (e.g., R127-03 -> 03)',
'        REGEXP_SUBSTR(base_reg.vorschrift_nummer, ''\d+$'') as series_number,',
'        -- Find if there are higher series available',
'        CASE ',
'            WHEN base_reg.publisher = ''UNECE'' AND ',
'                 EXISTS (',
'                     SELECT 1 FROM t_vorschrift v2',
'                     WHERE v2.publisher = ''UNECE''',
'                     AND REGEXP_SUBSTR(v2.vorschrift_nummer, ''^[^-]+'') = REGEXP_SUBSTR(base_reg.vorschrift_nummer, ''^[^-]+'')',
'                     AND TO_NUMBER(REGEXP_SUBSTR(v2.vorschrift_nummer, ''\d+$'')) > TO_NUMBER(REGEXP_SUBSTR(base_reg.vorschrift_nummer, ''\d+$''))',
'                 )',
unistr('            THEN ''Warnung: H\00F6here UNECE Serie verf\00FCgbar'''),
'            WHEN base_reg.publisher = ''UNECE''',
unistr('            THEN ''OK: H\00F6chste UNECE Serie'''),
'            ELSE ''N/A''',
'        END as series_status',
'    FROM (',
'        SELECT DISTINCT',
'            CASE ',
'                WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'                ELSE ms.vorschriftid',
'            END as effective_vorschrift_id,',
'            COALESCE(va.vorschrift_nummer, vm.vorschrift_nummer) as vorschrift_nummer,',
'            NVL(va.publisher, vm.publisher) as publisher',
'        FROM t_ms_suchergebniss ms',
'        INNER JOIN t_ms_suche_split split ON (',
'            split.sucheid = ms.sucheid ',
'            AND split.meilenstein = ms.meilenstein ',
'            AND split.landid = ms.landid',
'            AND split.card_number = :P468_CARD_NUM',
'            AND split.benutzerid = :G_BENUTZERID',
'        )',
'        LEFT JOIN t_vorschrift vm ON ms.vorschriftid = vm.vorschriftid',
'        LEFT JOIN t_vorschrift va ON ms.alternative_vorschriftid = va.vorschriftid',
'        WHERE ms.sucheid = :P468_SEARCH_SELECTION',
'        AND ms.meilenstein = :P468_MILESTONE_SELECTION',
'        AND (CASE ',
'            WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'            ELSE ms.vorschriftid',
'        END) IN (SELECT vorschriftid FROM selected_regulations)',
'    ) base_reg',
'),',
'regulation_summary AS (',
'    SELECT',
'        CASE ',
'            WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'            ELSE ms.vorschriftid',
'        END as effective_vorschrift_id,',
'        ms.vorschriftid as original_vorschrift_id,',
'        COALESCE(va.vorschrift_nummer, vm.vorschrift_nummer) as vorschrift_nummer,',
'        NVL(va.publisher, vm.publisher) as publisher,',
'        COUNT(DISTINCT ms.landid) as regulation_countries,',
'        LISTAGG(DISTINCT ms.themabezeichnung, ''; '') WITHIN GROUP (ORDER BY ms.themabezeichnung) as themes,',
'        LISTAGG(DISTINCT ms.landbezeichnung, ''; '') WITHIN GROUP (ORDER BY ms.landbezeichnung) as countries,',
'        -- evaluation data',
'        MAX(bew.et_verwendung) as et_verwendung,',
'        MAX(bew.et_kommentar) as et_kommentar,',
'        -- Theme contradiction check',
'        MAX(tc.theme_count) as theme_count,',
'        -- Alternative contradiction check  ',
'        MAX(ac.alt_count) as alt_count',
'    FROM t_ms_suchergebniss ms',
'    INNER JOIN t_ms_suche_split split ON (',
'        split.sucheid = ms.sucheid ',
'        AND split.meilenstein = ms.meilenstein ',
'        AND split.landid = ms.landid',
'        AND split.card_number = :P468_CARD_NUM',
'        AND split.benutzerid = :G_BENUTZERID',
'    )',
'    LEFT JOIN t_vorschrift vm ON ms.vorschriftid = vm.vorschriftid',
'    LEFT JOIN t_vorschrift va ON ms.alternative_vorschriftid = va.vorschriftid',
'    -- LEFT JOIN for evaluation data',
'    LEFT JOIN t_ms_bewertung bew ON (',
'        bew.sucheid = ms.sucheid',
'        AND bew.meilenstein = ms.meilenstein',
'        AND bew.card_number = :P468_CARD_NUM',
'        AND bew.vorschriftid = CASE ',
'            WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'            ELSE ms.vorschriftid',
'        END',
'        AND (bew.benutzerid = :G_BENUTZERID ',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001))',
'    )',
'    -- Join contradiction checks',
'    LEFT JOIN theme_contradictions tc ON tc.effective_vorschrift_id = CASE ',
'        WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'        ELSE ms.vorschriftid',
'    END',
'    LEFT JOIN alternative_contradictions ac ON ac.effective_vorschrift_id = CASE ',
'        WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'        ELSE ms.vorschriftid',
'    END',
'    WHERE ms.sucheid = :P468_SEARCH_SELECTION',
'    AND ms.meilenstein = :P468_MILESTONE_SELECTION',
'    AND (CASE ',
'        WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'        ELSE ms.vorschriftid',
'    END) IN (SELECT vorschriftid FROM selected_regulations)',
'    GROUP BY ',
'        CASE ',
'            WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'            ELSE ms.vorschriftid',
'        END,',
'        ms.vorschriftid,',
'        COALESCE(va.vorschrift_nummer, vm.vorschrift_nummer),',
'        NVL(va.publisher, vm.publisher)',
')',
'SELECT ',
'    rs.vorschrift_nummer as "Vorschrift Nr.",',
'    rs.themes as "Thema",',
unistr('    rs.countries as "Betroffene L\00E4nder",'),
'    rs.publisher as "Publisher",',
'    -- ET Verwendung column',
'    CASE ',
'        WHEN rs.et_verwendung = ''nicht bewertet'' OR rs.et_verwendung IS NULL ',
'        THEN ''<span style="color: #666; font-style: italic;">nicht bewertet</span>''',
'        WHEN rs.et_verwendung = ''ja'' ',
'        THEN ''<span style="color: #27ae60; font-weight: bold;"><i class="fa fa-check"></i> ja</span>''',
'        WHEN rs.et_verwendung = ''nein'' ',
'        THEN ''<span style="color: #e74c3c; font-weight: bold;"><i class="fa fa-times"></i> nein</span>''',
'        ELSE rs.et_verwendung',
'    END as "ET Verwendung",',
'    -- ET Kommentar column',
'    NVL(rs.et_kommentar, ''-'') as "ET Kommentar",',
'    CASE ',
'        -- Check for existing evaluations (BLOCKING ERROR)',
'        WHEN rs.et_verwendung IS NOT NULL AND rs.et_verwendung != ''nicht bewertet''',
'        THEN ''Fehler: Bereits bewertet''',
'        -- Check for theme contradictions (BLOCKING ERROR)',
'        WHEN rs.theme_count > 1',
'        THEN ''Fehler: Themengebiete widersprechen sich''',
'        -- Check for alternative contradictions (BLOCKING ERROR) ',
'        WHEN rs.alt_count > 1',
'        THEN ''Fehler: Alternativen widersprechen sich''',
'        -- UNECE publisher check for UNECE type (BLOCKING ERROR)',
'        WHEN :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' AND (rs.publisher IS NULL OR rs.publisher != ''UNECE'')',
'        THEN ''Fehler: Nicht UNECE Publisher ('' || NVL(rs.publisher, ''NULL'') || '')''',
'        -- UNECE series check (WARNING)',
'        WHEN :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' AND usa.series_status LIKE ''Warnung%''',
'        THEN usa.series_status',
'        -- Country coverage check (WARNING)',
'        WHEN rs.regulation_countries < cc.total_countries',
unistr('        THEN ''Warnung: Nur in '' || rs.regulation_countries || ''/'' || cc.total_countries || '' L\00E4ndern'''),
'        ELSE ''OK: Bereit zur Verarbeitung''',
'    END as "Validierung",',
'    CASE ',
'        -- BLOCKING ERRORS (Red X)',
'        WHEN rs.et_verwendung IS NOT NULL AND rs.et_verwendung != ''nicht bewertet''',
'        THEN ''<span class="fa fa-times-circle" style="color: #e74c3c; font-size: 16px;" title="Fehler: Bereits bewertet - Kann nicht verarbeitet werden"></span>''',
'        WHEN rs.theme_count > 1',
'        THEN ''<span class="fa fa-times-circle" style="color: #e74c3c; font-size: 16px;" title="Fehler: Themengebiete widersprechen sich - Kann nicht verarbeitet werden"></span>''',
'        WHEN rs.alt_count > 1',
'        THEN ''<span class="fa fa-times-circle" style="color: #e74c3c; font-size: 16px;" title="Fehler: Alternativen widersprechen sich - Kann nicht verarbeitet werden"></span>''',
'        WHEN :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' AND (rs.publisher IS NULL OR rs.publisher != ''UNECE'')',
'        THEN ''<span class="fa fa-times-circle" style="color: #e74c3c; font-size: 16px;" title="Fehler: Nicht UNECE Publisher - Kann nicht verarbeitet werden"></span>''',
'        -- WARNINGS (Yellow Triangle)',
'        WHEN :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' AND usa.series_status LIKE ''Warnung%''',
'        THEN ''<span class="fa fa-exclamation-triangle" style="color: #f39c12; font-size: 16px;" title="'' || usa.series_status || '' - Kann verarbeitet werden"></span>''',
'        WHEN rs.regulation_countries < cc.total_countries',
unistr('        THEN ''<span class="fa fa-exclamation-triangle" style="color: #f39c12; font-size: 16px;" title="Warnung: Eingeschr\00E4nkte L\00E4nderabdeckung - Kann verarbeitet werden"></span>'''),
'        -- OK (Green Check)',
unistr('        ELSE ''<span class="fa fa-check-circle" style="color: #27ae60; font-size: 16px;" title="OK: Bereit f\00FCr Verarbeitung - Alle Pr\00FCfungen bestanden"></span>'''),
'    END as "Status",',
'    -- Hidden field for validation type (error/warning/ok)',
'    CASE ',
'        WHEN rs.et_verwendung IS NOT NULL AND rs.et_verwendung != ''nicht bewertet'' THEN ''error''',
'        WHEN rs.theme_count > 1 THEN ''error''',
'        WHEN rs.alt_count > 1 THEN ''error''',
'        WHEN :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' AND (rs.publisher IS NULL OR rs.publisher != ''UNECE'') THEN ''error''',
'        WHEN :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' AND usa.series_status LIKE ''Warnung%'' THEN ''warning''',
'        WHEN rs.regulation_countries < cc.total_countries THEN ''warning''',
'        ELSE ''ok''',
'    END as validation_status,',
'    rs.effective_vorschrift_id as vorschriftid',
'FROM regulation_summary rs',
'CROSS JOIN card_countries cc',
'LEFT JOIN unece_series_analysis usa ON usa.effective_vorschrift_id = rs.effective_vorschrift_id',
'ORDER BY ',
'    -- Sort by validation priority: errors first, then warnings, then OK',
'    CASE ',
'        WHEN rs.et_verwendung IS NOT NULL AND rs.et_verwendung != ''nicht bewertet'' THEN 1',
'        WHEN rs.theme_count > 1 THEN 1',
'        WHEN rs.alt_count > 1 THEN 1',
'        WHEN :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' AND (rs.publisher IS NULL OR rs.publisher != ''UNECE'') THEN 1',
'        WHEN :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' AND usa.series_status LIKE ''Warnung%'' THEN 2',
'        WHEN rs.regulation_countries < cc.total_countries THEN 2',
'        ELSE 3',
'    END,',
'    rs.vorschrift_nummer'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'NEVER'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Ausgew\00E4hlte Vorschriften f\00FCr Update - 17.09.2025')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2315978597453996625)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>5988190913353384860
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964112406355442875)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Vorschrift ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964111919849442875)
,p_db_column_name=>'Vorschrift Nr.'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964111589597442874)
,p_db_column_name=>'Thema'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Thema'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964111116636442873)
,p_db_column_name=>unistr('Betroffene L\00E4nder')
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('Betroffene L\00E4nder')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964110803732442873)
,p_db_column_name=>'Validierung'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Validierung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964110352402442872)
,p_db_column_name=>'VALIDATION_STATUS'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Validation Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964110071871442872)
,p_db_column_name=>'Status'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964109648988442871)
,p_db_column_name=>'ET Verwendung'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'ET Verwendung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964109304031442870)
,p_db_column_name=>'ET Kommentar'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'ET Kommentar'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964108852047442870)
,p_db_column_name=>'Publisher'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Publisher'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4436941819936942697)
,p_plug_name=>unistr('Ausgew\00E4hlte Vorschriften f\00FCr Update')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-top-lg'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>160
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH selected_regulations AS (',
'    SELECT TO_NUMBER(COLUMN_VALUE) AS vorschriftid',
'    FROM TABLE(apex_string.split(:P468_SELECTED_ROWS, '':''))',
'    WHERE COLUMN_VALUE IS NOT NULL',
'),',
'card_countries AS (',
'    SELECT COUNT(DISTINCT landid) as total_countries',
'    FROM t_ms_suche_split ',
'    WHERE card_number = :P468_CARD_NUM ',
'    AND (benutzerid = :G_BENUTZERID ',
'     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                WHERE brr.benutzerid = :G_BENUTZERID ',
'                AND brr.rolleid = 1001))',
'),',
'-- Milestone comparison error detection',
'milestone_comparison_errors AS (',
'    SELECT ',
'        COALESCE(m1.vorschriftid, m2.vorschriftid) as vorschriftid,',
'        1 as has_comparison_error',
'    FROM (',
'        -- Current milestone regulations',
'        SELECT ms.vorschriftid, ms.vorschriftnummer, ms.landbezeichnung, ',
'               COALESCE(mat.kritikalitaet, 0) as kritikalitaet',
'        FROM t_ms_suchergebniss ms',
'        LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'        LEFT JOIN t_ms_parameter_ref_ausgabe pra ON p.ms_parameterid = pra.ms_parameterid',
'        LEFT JOIN t_ms_ausgabe_text mat ON pra.ms_ausgabe_textid = mat.ms_ausgabe_textid',
'        WHERE ms.sucheid = :P468_SEARCH_SELECTION ',
'        AND ms.meilenstein = :P468_MILESTONE_SELECTION',
'    ) m1',
'    FULL OUTER JOIN (',
'        -- Previous milestone regulations',
'        SELECT ms.vorschriftid, ms.vorschriftnummer, ms.landbezeichnung,',
'               COALESCE(mat.kritikalitaet, 0) as kritikalitaet',
'        FROM t_ms_suchergebniss ms',
'        LEFT JOIN t_ms_parameter p ON ms.regelnummer = p.nummer',
'        LEFT JOIN t_ms_parameter_ref_ausgabe pra ON p.ms_parameterid = pra.ms_parameterid  ',
'        LEFT JOIN t_ms_ausgabe_text mat ON pra.ms_ausgabe_textid = mat.ms_ausgabe_textid',
'        WHERE ms.sucheid = :P468_SEARCH_SELECTION ',
'        AND ms.meilenstein = (:P468_MILESTONE_SELECTION - 1)',
'    ) m2 ON m1.vorschriftid = m2.vorschriftid',
'    WHERE EXISTS (',
'        -- Check for duplicate regulation entries (blocking error from comparison)',
'        SELECT 1 FROM t_ms_suchergebniss ms_dup1',
'        WHERE ms_dup1.vorschriftid = COALESCE(m1.vorschriftid, m2.vorschriftid)',
'        AND ms_dup1.sucheid = :P468_SEARCH_SELECTION ',
'        AND ms_dup1.meilenstein = :P468_MILESTONE_SELECTION',
'        AND ms_dup1.manueller_eintrag = 10  -- Manual entry',
'        AND EXISTS (',
'            SELECT 1 FROM t_ms_suchergebniss ms_dup2',
'            WHERE ms_dup2.vorschriftid = ms_dup1.vorschriftid',
'            AND ms_dup2.sucheid = :P468_SEARCH_SELECTION',
'            AND ms_dup2.meilenstein = :P468_MILESTONE_SELECTION',
'            AND ms_dup2.landid = ms_dup1.landid',
'            AND ms_dup2.manueller_eintrag != 10  -- Automatic entry',
'        )',
'    )',
'),',
'-- Check for theme contradictions',
'theme_contradictions AS (',
'    SELECT ',
'        ms.sucheid,',
'        ms.meilenstein,',
'        ms.landid,',
'        CASE ',
'            WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'            ELSE ms.vorschriftid',
'        END as effective_vorschrift_id,',
'        COUNT(DISTINCT ms.themabezeichnung) as theme_count,',
'        LISTAGG(DISTINCT ms.themabezeichnung, ''; '') WITHIN GROUP (ORDER BY ms.themabezeichnung) as all_themes',
'    FROM t_ms_suchergebniss ms',
'    INNER JOIN t_ms_suche_split split ON (',
'        split.sucheid = ms.sucheid ',
'        AND split.meilenstein = ms.meilenstein ',
'        AND split.landid = ms.landid',
'        AND split.card_number = :P468_CARD_NUM',
'        -- ',
'        AND (split.benutzerid = :G_BENUTZERID ',
'     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                WHERE brr.benutzerid = :G_BENUTZERID ',
'                AND brr.rolleid = 1001))',
'    )',
'    WHERE ms.sucheid = :P468_SEARCH_SELECTION',
'    AND ms.meilenstein = :P468_MILESTONE_SELECTION',
'    AND (CASE ',
'        WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'        ELSE ms.vorschriftid',
'    END) IN (SELECT vorschriftid FROM selected_regulations)',
'    GROUP BY ',
'        ms.sucheid, ms.meilenstein, ms.landid,',
'        CASE ',
'            WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'            ELSE ms.vorschriftid',
'        END',
'),',
'-- Check for alternative contradictions',
'alternative_contradictions AS (',
'    SELECT ',
'        CASE ',
'            WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'            ELSE ms.vorschriftid',
'        END as effective_vorschrift_id,',
'        COUNT(DISTINCT COALESCE(va.vorschrift_nummer, vm.vorschrift_nummer)) as alt_count,',
'        LISTAGG(DISTINCT COALESCE(va.vorschrift_nummer, vm.vorschrift_nummer), ''; '') ',
'        WITHIN GROUP (ORDER BY COALESCE(va.vorschrift_nummer, vm.vorschrift_nummer)) as all_alternatives',
'    FROM t_ms_suchergebniss ms',
'    INNER JOIN t_ms_suche_split split ON (',
'        split.sucheid = ms.sucheid ',
'        AND split.meilenstein = ms.meilenstein ',
'        AND split.landid = ms.landid',
'        AND split.card_number = :P468_CARD_NUM',
'        -- ',
'        AND (split.benutzerid = :G_BENUTZERID ',
'     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                WHERE brr.benutzerid = :G_BENUTZERID ',
'                AND brr.rolleid = 1001))',
'    )',
'    LEFT JOIN t_vorschrift vm ON ms.vorschriftid = vm.vorschriftid',
'    LEFT JOIN t_vorschrift va ON ms.alternative_vorschriftid = va.vorschriftid',
'    WHERE ms.sucheid = :P468_SEARCH_SELECTION',
'    AND ms.meilenstein = :P468_MILESTONE_SELECTION',
'    AND (CASE ',
'        WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'        ELSE ms.vorschriftid',
'    END) IN (SELECT vorschriftid FROM selected_regulations)',
'    -- Check for regulations that have the same base regulation but different alternatives',
'    AND EXISTS (',
'        SELECT 1 FROM t_ms_suchergebniss ms2',
'        WHERE ms2.vorschriftid = ms.vorschriftid',
'        AND ms2.sucheid = ms.sucheid',
'        AND ms2.meilenstein = ms.meilenstein',
'        AND NVL(ms2.alternative_vorschriftid, 0) != NVL(ms.alternative_vorschriftid, 0)',
'    )',
'    GROUP BY ',
'        CASE ',
'            WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'            ELSE ms.vorschriftid',
'        END',
'),',
'-- UNECE Highest Series Logic',
'unece_series_analysis AS (',
'    SELECT ',
'        base_reg.effective_vorschrift_id,',
'        base_reg.vorschrift_nummer,',
'        base_reg.publisher,',
'        -- Extract series number from regulation number (e.g., R127-03 -> 03)',
'        REGEXP_SUBSTR(base_reg.vorschrift_nummer, ''\d+$'') as series_number,',
'        -- Find if there are higher series available',
'        CASE ',
'            WHEN base_reg.publisher = ''UNECE'' AND ',
'                 EXISTS (',
'                     SELECT 1 FROM t_vorschrift v2',
'                     WHERE v2.publisher = ''UNECE''',
'                     AND REGEXP_SUBSTR(v2.vorschrift_nummer, ''^[^-]+'') = REGEXP_SUBSTR(base_reg.vorschrift_nummer, ''^[^-]+'')',
'                     AND TO_NUMBER(REGEXP_SUBSTR(v2.vorschrift_nummer, ''\d+$'')) > TO_NUMBER(REGEXP_SUBSTR(base_reg.vorschrift_nummer, ''\d+$''))',
'                 )',
unistr('            THEN ''Warnung: H\00F6here UNECE Serie verf\00FCgbar'''),
'            WHEN base_reg.publisher = ''UNECE''',
unistr('            THEN ''OK: H\00F6chste UNECE Serie'''),
'            ELSE ''N/A''',
'        END as series_status',
'    FROM (',
'        SELECT DISTINCT',
'            CASE ',
'                WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'                ELSE ms.vorschriftid',
'            END as effective_vorschrift_id,',
'            COALESCE(va.vorschrift_nummer, vm.vorschrift_nummer) as vorschrift_nummer,',
'            NVL(va.publisher, vm.publisher) as publisher',
'        FROM t_ms_suchergebniss ms',
'        INNER JOIN t_ms_suche_split split ON (',
'            split.sucheid = ms.sucheid ',
'            AND split.meilenstein = ms.meilenstein ',
'            AND split.landid = ms.landid',
'            AND split.card_number = :P468_CARD_NUM',
'            -- ',
'            AND (split.benutzerid = :G_BENUTZERID ',
'     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                WHERE brr.benutzerid = :G_BENUTZERID ',
'                AND brr.rolleid = 1001))',
'        )',
'        LEFT JOIN t_vorschrift vm ON ms.vorschriftid = vm.vorschriftid',
'        LEFT JOIN t_vorschrift va ON ms.alternative_vorschriftid = va.vorschriftid',
'        WHERE ms.sucheid = :P468_SEARCH_SELECTION',
'        AND ms.meilenstein = :P468_MILESTONE_SELECTION',
'        AND (CASE ',
'            WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'            ELSE ms.vorschriftid',
'        END) IN (SELECT vorschriftid FROM selected_regulations)',
'    ) base_reg',
'),',
'regulation_summary AS (',
'    SELECT',
'        CASE ',
'            WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'            ELSE ms.vorschriftid',
'        END as effective_vorschrift_id,',
'        ms.vorschriftid as original_vorschrift_id,',
'        COALESCE(va.vorschrift_nummer, vm.vorschrift_nummer) as vorschrift_nummer,',
'        NVL(va.publisher, vm.publisher) as publisher,',
'        COUNT(DISTINCT ms.landid) as regulation_countries,',
'        LISTAGG(DISTINCT ms.themabezeichnung, ''; '') WITHIN GROUP (ORDER BY ms.themabezeichnung) as themes,',
'        LISTAGG(DISTINCT ms.landbezeichnung, ''; '') WITHIN GROUP (ORDER BY ms.landbezeichnung) as countries,',
'        -- evaluation data',
'        MAX(bew.et_verwendung) as et_verwendung,',
'        MAX(bew.et_kommentar) as et_kommentar,',
'        -- Theme contradiction check',
'        MAX(tc.theme_count) as theme_count,',
'        -- Alternative contradiction check  ',
'        MAX(ac.alt_count) as alt_count,',
'        -- Milestone comparison error check',
'        MAX(mce.has_comparison_error) as has_milestone_error',
'    FROM t_ms_suchergebniss ms',
'    INNER JOIN t_ms_suche_split split ON (',
'        split.sucheid = ms.sucheid ',
'        AND split.meilenstein = ms.meilenstein ',
'        AND split.landid = ms.landid',
'        AND split.card_number = :P468_CARD_NUM',
'        -- ',
'        AND (split.benutzerid = :G_BENUTZERID ',
'     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                WHERE brr.benutzerid = :G_BENUTZERID ',
'                AND brr.rolleid = 1001))',
'    )',
'    LEFT JOIN t_vorschrift vm ON ms.vorschriftid = vm.vorschriftid',
'    LEFT JOIN t_vorschrift va ON ms.alternative_vorschriftid = va.vorschriftid',
'    -- LEFT JOIN for evaluation data',
'    LEFT JOIN t_ms_bewertung bew ON (',
'        bew.sucheid = ms.sucheid',
'        AND bew.meilenstein = ms.meilenstein',
'        AND bew.card_number = :P468_CARD_NUM',
'        AND bew.vorschriftid = CASE ',
'            WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'            ELSE ms.vorschriftid',
'        END',
'        AND (bew.benutzerid = :G_BENUTZERID ',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001))',
'    )',
'    -- Join contradiction checks',
'    LEFT JOIN theme_contradictions tc ON tc.effective_vorschrift_id = CASE ',
'        WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'        ELSE ms.vorschriftid',
'    END',
'    LEFT JOIN alternative_contradictions ac ON ac.effective_vorschrift_id = CASE ',
'        WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'        ELSE ms.vorschriftid',
'    END',
'    -- JOIN milestone comparison errors',
'    LEFT JOIN milestone_comparison_errors mce ON mce.vorschriftid = CASE ',
'        WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'        ELSE ms.vorschriftid',
'    END',
'    WHERE ms.sucheid = :P468_SEARCH_SELECTION',
'    AND ms.meilenstein = :P468_MILESTONE_SELECTION',
'    AND (CASE ',
'        WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'        ELSE ms.vorschriftid',
'    END) IN (SELECT vorschriftid FROM selected_regulations)',
'    GROUP BY ',
'        CASE ',
'            WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid',
'            ELSE ms.vorschriftid',
'        END,',
'        ms.vorschriftid,',
'        COALESCE(va.vorschrift_nummer, vm.vorschrift_nummer),',
'        NVL(va.publisher, vm.publisher)',
')',
'SELECT ',
'    rs.vorschrift_nummer as "Vorschrift Nr.",',
'    rs.themes as "Thema",',
unistr('    rs.countries as "Betroffene L\00E4nder",'),
'    rs.publisher as "Publisher",',
'    -- ET Verwendung column',
'    CASE ',
'        WHEN rs.et_verwendung = ''nicht bewertet'' OR rs.et_verwendung IS NULL ',
'        THEN ''<span style="color: #666; font-style: italic;">nicht bewertet</span>''',
'        WHEN rs.et_verwendung = ''ja'' ',
'        THEN ''<span style="color: #27ae60; font-weight: bold;"><i class="fa fa-check"></i> ja</span>''',
'        WHEN rs.et_verwendung = ''nein'' ',
'        THEN ''<span style="color: #e74c3c; font-weight: bold;"><i class="fa fa-times"></i> nein</span>''',
'        ELSE rs.et_verwendung',
'    END as "ET Verwendung",',
'    -- ET Kommentar column',
'    NVL(rs.et_kommentar, ''-'') as "ET Kommentar",',
'    -- VALIDATION WITH MILESTONE COMPARISON INTEGRATION',
'    CASE ',
'        -- Check for milestone comparison errors (NEW - HIGHEST PRIORITY BLOCKING ERROR)',
'        WHEN rs.has_milestone_error = 1',
'        THEN ''Fehler: Meilensteinvergleich zeigt kritischen Fehler - Massenupdate blockiert''',
'        -- Check for existing evaluations (BLOCKING ERROR)',
'        WHEN rs.et_verwendung IS NOT NULL AND rs.et_verwendung != ''nicht bewertet''',
'        THEN ''Fehler: Bereits bewertet''',
'        -- Check for theme contradictions (BLOCKING ERROR)',
'        WHEN rs.theme_count > 1 AND :P468_UPDATE_TYPE != ''DEACTIVATE_ROWS''',
'        THEN ''Fehler: Themengebiete widersprechen sich''',
'        -- Check for alternative contradictions (BLOCKING ERROR) ',
'        WHEN rs.alt_count > 1',
'        THEN ''Fehler: Alternativen widersprechen sich''',
'        -- UNECE publisher check for UNECE type (BLOCKING ERROR)',
'        WHEN :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' AND (rs.publisher IS NULL OR rs.publisher != ''UNECE'')',
'        THEN ''Fehler: Nicht UNECE Publisher ('' || NVL(rs.publisher, ''NULL'') || '')''',
'        -- UNECE series check (WARNING)',
'        WHEN :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' AND usa.series_status LIKE ''Warnung%''',
'        THEN usa.series_status',
'        -- Country coverage check (WARNING)',
'        WHEN rs.regulation_countries < cc.total_countries',
unistr('        THEN ''Warnung: Nur in '' || rs.regulation_countries || ''/'' || cc.total_countries || '' L\00E4ndern'''),
'        ELSE ''OK: Bereit zur Verarbeitung''',
'    END as "Validierung",',
'    -- STATUS ICONS INCLUDING MILESTONE ERRORS',
'    CASE ',
'        -- BLOCKING ERRORS (Red X) - INCLUDING NEW MILESTONE ERROR',
'        WHEN rs.has_milestone_error = 1',
'        THEN ''<span class="fa fa-times-circle" style="color: #e74c3c; font-size: 16px;" title="Fehler: Meilensteinvergleich zeigt kritischen Fehler - Kann nicht verarbeitet werden"></span>''',
'        WHEN rs.et_verwendung IS NOT NULL AND rs.et_verwendung != ''nicht bewertet''',
'        THEN ''<span class="fa fa-times-circle" style="color: #e74c3c; font-size: 16px;" title="Fehler: Bereits bewertet - Kann nicht verarbeitet werden"></span>''',
'        WHEN rs.theme_count > 1 AND :P468_UPDATE_TYPE != ''DEACTIVATE_ROWS''',
'        THEN ''<span class="fa fa-times-circle" style="color: #e74c3c; font-size: 16px;" title="Fehler: Themengebiete widersprechen sich - Kann nicht verarbeitet werden"></span>''',
'        WHEN rs.alt_count > 1',
'        THEN ''<span class="fa fa-times-circle" style="color: #e74c3c; font-size: 16px;" title="Fehler: Alternativen widersprechen sich - Kann nicht verarbeitet werden"></span>''',
'        WHEN :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' AND (rs.publisher IS NULL OR rs.publisher != ''UNECE'')',
'        THEN ''<span class="fa fa-times-circle" style="color: #e74c3c; font-size: 16px;" title="Fehler: Nicht UNECE Publisher - Kann nicht verarbeitet werden"></span>''',
'        -- WARNINGS (Yellow Triangle)',
'        WHEN :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' AND usa.series_status LIKE ''Warnung%''',
'        THEN ''<span class="fa fa-exclamation-triangle" style="color: #f39c12; font-size: 16px;" title="'' || usa.series_status || '' - Kann verarbeitet werden"></span>''',
'        WHEN rs.regulation_countries < cc.total_countries',
unistr('        THEN ''<span class="fa fa-exclamation-triangle" style="color: #f39c12; font-size: 16px;" title="Warnung: Eingeschr\00E4nkte L\00E4nderabdeckung - Kann verarbeitet werden"></span>'''),
'        -- OK (Green Check)',
unistr('        ELSE ''<span class="fa fa-check-circle" style="color: #27ae60; font-size: 16px;" title="OK: Bereit f\00FCr Verarbeitung - Alle Pr\00FCfungen bestanden"></span>'''),
'    END as "Status",',
'    -- HIDDEN VALIDATION STATUS INCLUDING MILESTONE ERRORS',
'    CASE ',
'        WHEN rs.has_milestone_error = 1 THEN ''error''',
'        WHEN rs.et_verwendung IS NOT NULL AND rs.et_verwendung != ''nicht bewertet'' THEN ''error''',
'        WHEN rs.theme_count > 1 AND :P468_UPDATE_TYPE != ''DEACTIVATE_ROWS'' THEN ''error''',
'        WHEN rs.alt_count > 1 THEN ''error''',
'        WHEN :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' AND (rs.publisher IS NULL OR rs.publisher != ''UNECE'') THEN ''error''',
'        WHEN :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' AND usa.series_status LIKE ''Warnung%'' THEN ''warning''',
'        WHEN rs.regulation_countries < cc.total_countries THEN ''warning''',
'        ELSE ''ok''',
'    END as validation_status,',
'    rs.effective_vorschrift_id as vorschriftid',
'FROM regulation_summary rs',
'CROSS JOIN card_countries cc',
'LEFT JOIN unece_series_analysis usa ON usa.effective_vorschrift_id = rs.effective_vorschrift_id',
'ORDER BY ',
'    -- PRIORITY ORDER - MILESTONE ERRORS FIRST',
'    CASE ',
'        WHEN rs.has_milestone_error = 1 THEN 0  -- Highest priority: milestone comparison errors',
'        WHEN rs.et_verwendung IS NOT NULL AND rs.et_verwendung != ''nicht bewertet'' THEN 1',
'        WHEN rs.theme_count > 1 AND :P468_UPDATE_TYPE != ''DEACTIVATE_ROWS'' THEN 1',
'        WHEN rs.alt_count > 1 THEN 1',
'        WHEN :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' AND (rs.publisher IS NULL OR rs.publisher != ''UNECE'') THEN 1',
'        WHEN :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' AND usa.series_status LIKE ''Warnung%'' THEN 2',
'        WHEN rs.regulation_countries < cc.total_countries THEN 2',
'        ELSE 3',
'    END,',
'    rs.vorschrift_nummer'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P468_SEARCH_SELECTION,P468_MILESTONE_SELECTION,P468_CARD_NUM,P468_SELECTED_ROWS,P468_UPDATE_TYPE'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Ausgew\00E4hlte Vorschriften f\00FCr Update')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2314310897947986128)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>5986523213847374363
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964105741232442863)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>10
,p_column_identifier=>'G'
,p_column_label=>'Vorschrift ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964108211289442867)
,p_db_column_name=>'Vorschrift Nr.'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964107810429442866)
,p_db_column_name=>'Thema'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Themabezeichnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964107328419442865)
,p_db_column_name=>unistr('Betroffene L\00E4nder')
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>unistr('Betroffene L\00E4nder')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964106962220442865)
,p_db_column_name=>'Validierung'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Validierung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964106196322442864)
,p_db_column_name=>'VALIDATION_STATUS'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Validation Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964106520644442864)
,p_db_column_name=>'Status'
,p_display_order=>80
,p_column_identifier=>'E'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964105353315442862)
,p_db_column_name=>'ET Verwendung'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'ET Verwendung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964105008500442862)
,p_db_column_name=>'ET Kommentar'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'ET Kommentar'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964104532343442861)
,p_db_column_name=>'Publisher'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Publisher'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2314770683745606517)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5711777'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('VORSCHRIFTID:Vorschrift Nr.:Thema:Betroffene L\00E4nder:Publisher:Validierung:ET Kommentar:ET Verwendung:VALIDATION_STATUS:Status:')
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17017746084265322993)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(964128428368451140)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17017748832912330315)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964103299182442859)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(17017748832912330315)
,p_button_name=>'BACK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964102857002442859)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(17017748832912330315)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964102513804442859)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(17017748832912330315)
,p_button_name=>'EXECUTE_UPDATE'
,p_button_static_id=>'b_executeupdate'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Massenupdate ausf\00FChren & Weiter ')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-user-check'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964102025772442859)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(17017748832912330315)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Weiter'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(964092055633442850)
,p_branch_name=>'Go To Page 464'
,p_branch_action=>'f?p=&APP_ID.:464:&SESSION.::&DEBUG.:464:P464_LOAD_FROM,P464_SEARCH_SELECTION,P464_MILESTONE_SELECTION,P464_CARD_NUM,P464_UPDATE_TYPE,P464_COMMENT:"P468_SELECTED_ROWS",&P468_SEARCH_SELECTION.,&P468_MILESTONE_SELECTION.,&P468_CARD_NUM.,&P468_UPDATE_TYPE.,&P468_COMMENT.'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(964103299182442859)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(964092486814442851)
,p_branch_name=>'Go To Page 469'
,p_branch_action=>'f?p=&APP_ID.:469:&SESSION.::&DEBUG.:469:P469_SELECTED_ROWS,P469_SEARCH_SELECTION,P469_MILESTONE_SELECTION,P469_CARD_NUM,P469_UPDATE_TYPE,P469_COMMENT:&P468_SELECTED_ROWS.,&P468_SEARCH_SELECTION.,&P468_MILESTONE_SELECTION.,&P468_CARD_NUM.,&P468_UPDATE_TYPE.,&P468_COMMENT.'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(964102513804442859)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964101710937442858)
,p_name=>'P468_SELECTED_ROWS'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964101251782442858)
,p_name=>'P468_SEARCH_SELECTION'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964100830323442858)
,p_name=>'P468_MILESTONE_SELECTION'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964100507583442857)
,p_name=>'P468_CARD_NUM'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964100034570442857)
,p_name=>'P468_UPDATE_TYPE'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964099715768442857)
,p_name=>'P468_PROCESSABLE_COUNT'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964099240862442857)
,p_name=>'P468_TOTAL_SELECTED'
,p_item_sequence=>100
,p_source=>'SELECT COUNT(*) FROM TABLE(apex_string.split(:P468_SELECTED_ROWS, '':'')) WHERE COLUMN_VALUE IS NOT NULL'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964098885395442857)
,p_name=>'P468_COMMENT'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964098504215442856)
,p_name=>'P468_OK_COUNT'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964098057670442856)
,p_name=>'P468_WARNING_COUNT'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964097645580442856)
,p_name=>'P468_ERROR_COUNT'
,p_item_sequence=>150
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(964097185669442855)
,p_validation_name=>'No Errors Allowed'
,p_validation_sequence=>10
,p_validation=>'TO_NUMBER(:P468_ERROR_COUNT) = 0'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Es gibt Fehler in der Auswahl. Bitte korrigieren Sie diese vor der Ausf\00FChrung.')
,p_validation_condition_type=>'NEVER'
,p_when_button_pressed=>wwv_flow_imp.id(964102513804442859)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964094891178442852)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(964102857002442859)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964094370463442852)
,p_event_id=>wwv_flow_imp.id(964094891178442852)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964093974849442851)
,p_name=>'EXECUTE_UPDATE button enable/disable'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964093446038442851)
,p_event_id=>wwv_flow_imp.id(964093974849442851)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log(''=== Button Enable/Disable Check ==='');',
'',
'// Get all values',
'var errorCount = parseInt($v(''P468_ERROR_COUNT'')) || 0;',
'var totalSelected = parseInt($v(''P468_TOTAL_SELECTED'')) || 0;',
'var okCount = parseInt($v(''P468_OK_COUNT'')) || 0;',
'var warningCount = parseInt($v(''P468_WARNING_COUNT'')) || 0;',
'',
'// Find the button',
'var executeButton = $(''#b_executeupdate'');',
'',
'// Debug logging',
unistr('console.log(''P468_ERROR_COUNT:'', $v(''P468_ERROR_COUNT''), ''\2192 Parsed:'', errorCount);'),
'console.log(''P468_TOTAL_SELECTED:'', totalSelected);',
'console.log(''P468_OK_COUNT:'', okCount);',
'console.log(''P468_WARNING_COUNT:'', warningCount);',
'console.log(''Button element found:'', executeButton.length > 0);',
'',
'// Check if button exists',
'if (executeButton.length === 0) {',
'    console.error(''ERROR: Execute button (#b_executeupdate) not found!'');',
'    return;',
'}',
'',
'// Decision logic',
'if (errorCount > 0) {',
unistr('    console.log(''\2192 DISABLING button: '' + errorCount + '' error(s) found'');'),
'    executeButton.addClass(''apex_disabled'').prop(''disabled'', true);',
unistr('    executeButton.attr(''title'', ''Kann nicht ausgef\00FChrt werden: '' + errorCount + '' Fehler gefunden'');'),
'} else if (totalSelected === 0) {',
unistr('    console.log(''\2192 DISABLING button: No rows selected'');'),
'    executeButton.addClass(''apex_disabled'').prop(''disabled'', true);',
unistr('    executeButton.attr(''title'', ''Keine Zeilen ausgew\00E4hlt'');'),
'} else {',
unistr('    console.log(''\2192 ENABLING button: No errors, '' + okCount + '' OK + '' + warningCount + '' warnings'');'),
'    executeButton.removeClass(''apex_disabled'').prop(''disabled'', false);',
unistr('    executeButton.attr(''title'', ''Massenupdate ausf\00FChren'');'),
'}',
'',
'console.log(''Final button state - disabled:'', executeButton.prop(''disabled''));',
'console.log(''=================================='');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(951938867668316313)
,p_event_id=>wwv_flow_imp.id(964093974849442851)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var errorCount = parseInt($v(''P468_ERROR_COUNT'')) || 0;',
'var executeButton = $(''#b_executeupdate'');',
'',
'if (errorCount > 0) {',
'    executeButton.addClass(''apex_disabled'').prop(''disabled'', true);',
unistr('    executeButton.attr(''title'', ''Kann nicht ausgef\00FChrt werden: '' + errorCount + '' Fehler gefunden'');'),
'} else {',
'    executeButton.removeClass(''apex_disabled'').prop(''disabled'', false);',
unistr('    executeButton.attr(''title'', ''Massenupdate ausf\00FChren'');'),
'}',
'',
'// console.log(''Button state updated - Error count:'', errorCount);'))
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964095235407442853)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Perform Mass Update'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_selected_rows apex_t_varchar2;',
'    l_processed_count NUMBER := 0;',
'    l_error_count NUMBER := 0;',
'    l_current_reg_id NUMBER;',
'    l_highest_successor_id NUMBER;',
'    l_highest_successor_nummer VARCHAR2(500);',
'    l_max_level NUMBER;',
'BEGIN',
'    -- Initialize and populate the collection',
'    l_selected_rows := apex_t_varchar2();',
'    ',
'    -- Split the selected rows',
'    IF :P468_SELECTED_ROWS IS NOT NULL AND LENGTH(TRIM(:P468_SELECTED_ROWS)) > 0 THEN',
'        l_selected_rows := apex_string.split(:P468_SELECTED_ROWS, '':'');',
'    ELSE',
unistr('        RAISE_APPLICATION_ERROR(-20001, ''Keine Zeilen f\00FCr Massenupdate ausgew\00E4hlt.'');'),
'    END IF;',
'    ',
'    apex_debug.info(''=== MASS UPDATE START ==='');',
'    apex_debug.info(''Total regulations to process: %s'', l_selected_rows.COUNT);',
'    apex_debug.info(''Update Type: %s'', :P468_UPDATE_TYPE);',
'    ',
'    -- Process each selected regulation',
'    FOR i IN 1..l_selected_rows.COUNT LOOP',
'        BEGIN',
'            l_current_reg_id := TO_NUMBER(l_selected_rows(i));',
'            l_highest_successor_id := NULL;',
'            l_highest_successor_nummer := NULL;',
'            l_max_level := 0;',
'            ',
'            apex_debug.info(''--- Processing Regulation ID: %s ---'', l_current_reg_id);',
'            ',
'',
'            -- Find the highest successor for this regulation (ONLY from T_MS_SUCHERGEBNISS)',
'            BEGIN',
'                SELECT ',
'                    successor_id,',
'                    successor_nummer,',
'                    successor_level',
'                INTO ',
'                    l_highest_successor_id,',
'                    l_highest_successor_nummer,',
'                    l_max_level',
'                FROM (',
'                    -- Get ALL successors recursively - ONLY from T_MS_SUCHERGEBNISS',
'                    SELECT ',
'                        vrv.nachfolger_vorschriftid as successor_id,',
'                        CASE ',
'                            WHEN tp.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND tv.DOKUMENTENDATUM IS NOT NULL ',
'                            THEN tv.vorschrift_nummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'                            ELSE tv.vorschrift_nummer ',
'                        END as successor_nummer,',
'                        LEVEL as successor_level',
'                    FROM t_vorschrift_ref_vorschrift vrv',
'                    INNER JOIN t_vorschrift tv ON tv.vorschriftid = vrv.nachfolger_vorschriftid',
'                    LEFT JOIN t_publisher tp ON tv.publisherid = tp.publisherid',
'                    -- FILTER: Only successors from T_MS_SUCHERGEBNISS',
'                    INNER JOIN t_ms_suchergebniss ms ON (',
'                        ms.vorschriftid = vrv.nachfolger_vorschriftid',
'                        AND ms.sucheid = :P468_SEARCH_SELECTION',
'                        AND ms.meilenstein = :P468_MILESTONE_SELECTION',
'                    )',
'                    WHERE vrv.beziehung_art = 10',
'                    START WITH vrv.vorgaenger_vorschriftid = l_current_reg_id',
'                    CONNECT BY NOCYCLE PRIOR vrv.nachfolger_vorschriftid = vrv.vorgaenger_vorschriftid',
'                        AND vrv.beziehung_art = 10',
'                        AND LEVEL <= 10',
'                    ORDER BY LEVEL DESC, tv.vorschrift_nummer',
'                )',
'                WHERE ROWNUM = 1;  -- Get the highest level (first row after ORDER BY LEVEL DESC)',
'                ',
'                apex_debug.info(''Found highest successor: %s (Level %s)'', l_highest_successor_nummer, l_max_level);',
'                ',
'            EXCEPTION',
'                WHEN NO_DATA_FOUND THEN',
'                    -- No successors found - use the regulation itself',
'                    SELECT ',
'                        ms.vorschriftid,',
'                        CASE ',
'                            WHEN tp.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND tv.DOKUMENTENDATUM IS NOT NULL ',
'                            THEN ms.vorschriftnummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'                            ELSE ms.vorschriftnummer ',
'                        END',
'                    INTO l_highest_successor_id, l_highest_successor_nummer',
'                    FROM T_MS_SUCHERGEBNISS ms',
'                    LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.vorschriftid',
'                    LEFT JOIN t_publisher tp ON tv.publisherid = tp.publisherid',
'                    WHERE ms.sucheid = :P468_SEARCH_SELECTION',
'                    AND ms.meilenstein = :P468_MILESTONE_SELECTION',
'                    AND (CASE ',
'                        WHEN ms.alternative_vorschriftid IS NOT NULL ',
'                        THEN ms.alternative_vorschriftid ',
'                        ELSE ms.vorschriftid ',
'                    END) = l_current_reg_id',
'                    AND ROWNUM = 1;',
'                    ',
'                    apex_debug.info(''No successors found - using regulation itself: %s'', l_highest_successor_nummer);',
'            END;',
'            ',
'            -- Perform the mass update based on type',
'            IF :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' THEN',
'                -- UNECE Mass Update with highest successor',
'                MERGE INTO t_ms_bewertung d',
'                USING (',
'                    SELECT ',
'                        :P468_SEARCH_SELECTION AS sucheid,',
'                        :P468_MILESTONE_SELECTION AS meilenstein,',
'                        :P468_CARD_NUM AS card_number,',
'                        l_current_reg_id AS vorschriftid,',
'                        :G_BENUTZERID AS benutzerid,',
'                        :P468_COMMENT AS et_kommentar,',
'                        l_highest_successor_nummer AS et_vorschlag_vorschrift',
'                    FROM dual',
'                ) s ON (',
'                    d.sucheid = s.sucheid AND',
'                    d.meilenstein = s.meilenstein AND',
'                    d.card_number = s.card_number AND',
'                    d.vorschriftid = s.vorschriftid AND',
'                    d.benutzerid = s.benutzerid',
'                )',
'                WHEN MATCHED THEN',
'                    UPDATE SET ',
'                        d.et_verwendung = ''ja'',',
'                        d.et_vorschlag_vorschrift = s.et_vorschlag_vorschrift,',
'                        d.et_kommentar = CASE ',
'                            WHEN s.et_kommentar IS NOT NULL ',
'                            THEN s.et_kommentar ',
'                            ELSE d.et_kommentar ',
'                        END,',
'                        d.letzte_aenderung_datum = SYSDATE,',
'                        d.letzte_aenderung_benutzerid = :G_BENUTZERID',
'                WHEN NOT MATCHED THEN',
'                    INSERT (',
'                        sucheid, meilenstein, card_number, vorschriftid, benutzerid,',
'                        et_verwendung, et_vorschlag_vorschrift, et_kommentar, ',
'                        erstellung_datum, letzte_aenderung_datum, letzte_aenderung_benutzerid',
'                    )',
'                    VALUES (',
'                        s.sucheid, s.meilenstein, s.card_number, s.vorschriftid, s.benutzerid,',
'                        ''ja'', s.et_vorschlag_vorschrift, s.et_kommentar,',
'                        SYSDATE, SYSDATE, :G_BENUTZERID',
'                    );',
'                    ',
'                apex_debug.info(''Saved: ET_VERWENDUNG=ja, ET_VORSCHLAG_VORSCHRIFT=%s'', l_highest_successor_nummer);',
'                ',
'            ELSIF :P468_UPDATE_TYPE = ''DEACTIVATE_ROWS'' THEN',
'                -- Deactivate Rows Mass Update (also save highest successor)',
'                MERGE INTO t_ms_bewertung d',
'                USING (',
'                    SELECT ',
'                        :P468_SEARCH_SELECTION AS sucheid,',
'                        :P468_MILESTONE_SELECTION AS meilenstein,',
'                        :P468_CARD_NUM AS card_number,',
'                        l_current_reg_id AS vorschriftid,',
'                        :G_BENUTZERID AS benutzerid,',
'                        l_highest_successor_nummer AS et_vorschlag_vorschrift',
'                    FROM dual',
'                ) s ON (',
'                    d.sucheid = s.sucheid AND',
'                    d.meilenstein = s.meilenstein AND',
'                    d.card_number = s.card_number AND',
'                    d.vorschriftid = s.vorschriftid AND',
'                    d.benutzerid = s.benutzerid',
'                )',
'                WHEN MATCHED THEN',
'                    UPDATE SET ',
'                        d.et_verwendung = ''nein'',',
'                        d.et_vorschlag_vorschrift = s.et_vorschlag_vorschrift,',
'                        d.letzte_aenderung_datum = SYSDATE,',
'                        d.letzte_aenderung_benutzerid = :G_BENUTZERID',
'                WHEN NOT MATCHED THEN',
'                    INSERT (',
'                        sucheid, meilenstein, card_number, vorschriftid, benutzerid,',
'                        et_verwendung, et_vorschlag_vorschrift,',
'                        erstellung_datum, letzte_aenderung_datum, letzte_aenderung_benutzerid',
'                    )',
'                    VALUES (',
'                        s.sucheid, s.meilenstein, s.card_number, s.vorschriftid, s.benutzerid,',
'                        ''nein'', s.et_vorschlag_vorschrift,',
'                        SYSDATE, SYSDATE, :G_BENUTZERID',
'                    );',
'                    ',
'                apex_debug.info(''Saved: ET_VERWENDUNG=nein, ET_VORSCHLAG_VORSCHRIFT=%s'', l_highest_successor_nummer);',
'            END IF;',
'            ',
'            l_processed_count := l_processed_count + 1;',
'            ',
'        EXCEPTION',
'            WHEN OTHERS THEN',
'                l_error_count := l_error_count + 1;',
'                apex_debug.error(''Error processing VorschriftID %s: %s'', l_current_reg_id, SQLERRM);',
'        END;',
'    END LOOP;',
'',
'    COMMIT;',
'    ',
'    apex_debug.info(''=== MASS UPDATE COMPLETE ==='');',
'    apex_debug.info(''Processed: %s, Errors: %s'', l_processed_count, l_error_count);',
'',
'    -- Success message',
'    apex_application.g_print_success_message := ',
unistr('        ''Massenupdate erfolgreich: '' || l_processed_count || '' Eintr\00E4ge verarbeitet.'';'),
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        apex_debug.error(''FATAL ERROR in Mass Update: %s'', SQLERRM);',
'        apex_error.add_error(',
'            p_message => ''Fehler beim Massenupdate: '' || SQLERRM,',
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(964102513804442859)
,p_internal_uid=>2708117080491945382
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(923435631772643727)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Perform Mass Update_Wernernotwant'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_selected_rows apex_t_varchar2;',
'    l_processed_count NUMBER := 0;',
'    l_error_count NUMBER := 0;',
'    l_current_reg_id NUMBER;',
'    l_highest_successor_id NUMBER;',
'    l_highest_successor_nummer VARCHAR2(500);',
'    l_max_level NUMBER;',
'BEGIN',
'    -- Initialize and populate the collection',
'    l_selected_rows := apex_t_varchar2();',
'    ',
'    -- Split the selected rows',
'    IF :P468_SELECTED_ROWS IS NOT NULL AND LENGTH(TRIM(:P468_SELECTED_ROWS)) > 0 THEN',
'        l_selected_rows := apex_string.split(:P468_SELECTED_ROWS, '':'');',
'    ELSE',
unistr('        RAISE_APPLICATION_ERROR(-20001, ''Keine Zeilen f\00FCr Massenupdate ausgew\00E4hlt.'');'),
'    END IF;',
'    ',
'    apex_debug.info(''=== MASS UPDATE START ==='');',
'    apex_debug.info(''Total regulations to process: %s'', l_selected_rows.COUNT);',
'    apex_debug.info(''Update Type: %s'', :P468_UPDATE_TYPE);',
'    ',
'    -- Process each selected regulation',
'    FOR i IN 1..l_selected_rows.COUNT LOOP',
'        BEGIN',
'            l_current_reg_id := TO_NUMBER(l_selected_rows(i));',
'            l_highest_successor_id := NULL;',
'            l_highest_successor_nummer := NULL;',
'            l_max_level := 0;',
'            ',
'            apex_debug.info(''--- Processing Regulation ID: %s ---'', l_current_reg_id);',
'            ',
'            -- Find the highest successor for this regulation',
'            BEGIN',
'                SELECT ',
'                    successor_id,',
'                    successor_nummer,',
'                    successor_level',
'                INTO ',
'                    l_highest_successor_id,',
'                    l_highest_successor_nummer,',
'                    l_max_level',
'                FROM (',
'                    -- Get ALL successors recursively',
'                    SELECT ',
'                        vrv.nachfolger_vorschriftid as successor_id,',
'                        CASE ',
'                            WHEN tp.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND tv.DOKUMENTENDATUM IS NOT NULL ',
'                            THEN tv.vorschrift_nummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'                            ELSE tv.vorschrift_nummer ',
'                        END as successor_nummer,',
'                        LEVEL as successor_level',
'                    FROM t_vorschrift_ref_vorschrift vrv',
'                    INNER JOIN t_vorschrift tv ON tv.vorschriftid = vrv.nachfolger_vorschriftid',
'                    LEFT JOIN t_publisher tp ON tv.publisherid = tp.publisherid',
'                    WHERE vrv.beziehung_art = 10',
'                    START WITH vrv.vorgaenger_vorschriftid = l_current_reg_id',
'                    CONNECT BY NOCYCLE PRIOR vrv.nachfolger_vorschriftid = vrv.vorgaenger_vorschriftid',
'                        AND vrv.beziehung_art = 10',
'                        AND LEVEL <= 10',
'                    ORDER BY LEVEL DESC, tv.vorschrift_nummer',
'                )',
'                WHERE ROWNUM = 1;  -- Get the highest level (first row after ORDER BY LEVEL DESC)',
'                ',
'                apex_debug.info(''Found highest successor: %s (Level %s)'', l_highest_successor_nummer, l_max_level);',
'                ',
'            EXCEPTION',
'                WHEN NO_DATA_FOUND THEN',
'                    -- No successors found - use the regulation itself',
'                    SELECT ',
'                        ms.vorschriftid,',
'                        CASE ',
'                            WHEN tp.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND tv.DOKUMENTENDATUM IS NOT NULL ',
'                            THEN ms.vorschriftnummer || ''_'' || TO_CHAR(tv.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'                            ELSE ms.vorschriftnummer ',
'                        END',
'                    INTO l_highest_successor_id, l_highest_successor_nummer',
'                    FROM T_MS_SUCHERGEBNISS ms',
'                    LEFT JOIN t_vorschrift tv ON tv.vorschriftid = ms.vorschriftid',
'                    LEFT JOIN t_publisher tp ON tv.publisherid = tp.publisherid',
'                    WHERE ms.sucheid = :P468_SEARCH_SELECTION',
'                    AND ms.meilenstein = :P468_MILESTONE_SELECTION',
'                    AND (CASE ',
'                        WHEN ms.alternative_vorschriftid IS NOT NULL ',
'                        THEN ms.alternative_vorschriftid ',
'                        ELSE ms.vorschriftid ',
'                    END) = l_current_reg_id',
'                    AND ROWNUM = 1;',
'                    ',
'                    apex_debug.info(''No successors found - using regulation itself: %s'', l_highest_successor_nummer);',
'            END;',
'            ',
'            -- Perform the mass update based on type',
'            IF :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' THEN',
'                -- UNECE Mass Update with highest successor',
'                MERGE INTO t_ms_bewertung d',
'                USING (',
'                    SELECT ',
'                        :P468_SEARCH_SELECTION AS sucheid,',
'                        :P468_MILESTONE_SELECTION AS meilenstein,',
'                        :P468_CARD_NUM AS card_number,',
'                        l_current_reg_id AS vorschriftid,',
'                        :G_BENUTZERID AS benutzerid,',
'                        :P468_COMMENT AS et_kommentar,',
'                        l_highest_successor_nummer AS et_vorschlag_vorschrift',
'                    FROM dual',
'                ) s ON (',
'                    d.sucheid = s.sucheid AND',
'                    d.meilenstein = s.meilenstein AND',
'                    d.card_number = s.card_number AND',
'                    d.vorschriftid = s.vorschriftid AND',
'                    d.benutzerid = s.benutzerid',
'                )',
'                WHEN MATCHED THEN',
'                    UPDATE SET ',
'                        d.et_verwendung = ''ja'',',
'                        d.et_vorschlag_vorschrift = s.et_vorschlag_vorschrift,',
'                        d.et_kommentar = CASE ',
'                            WHEN s.et_kommentar IS NOT NULL ',
'                            THEN s.et_kommentar ',
'                            ELSE d.et_kommentar ',
'                        END,',
'                        d.letzte_aenderung_datum = SYSDATE,',
'                        d.letzte_aenderung_benutzerid = :G_BENUTZERID',
'                WHEN NOT MATCHED THEN',
'                    INSERT (',
'                        sucheid, meilenstein, card_number, vorschriftid, benutzerid,',
'                        et_verwendung, et_vorschlag_vorschrift, et_kommentar, ',
'                        erstellung_datum, letzte_aenderung_datum, letzte_aenderung_benutzerid',
'                    )',
'                    VALUES (',
'                        s.sucheid, s.meilenstein, s.card_number, s.vorschriftid, s.benutzerid,',
'                        ''ja'', s.et_vorschlag_vorschrift, s.et_kommentar,',
'                        SYSDATE, SYSDATE, :G_BENUTZERID',
'                    );',
'                    ',
'                apex_debug.info(''Saved: ET_VERWENDUNG=ja, ET_VORSCHLAG_VORSCHRIFT=%s'', l_highest_successor_nummer);',
'                ',
'            ELSIF :P468_UPDATE_TYPE = ''DEACTIVATE_ROWS'' THEN',
'                -- Deactivate Rows Mass Update (also save highest successor)',
'                MERGE INTO t_ms_bewertung d',
'                USING (',
'                    SELECT ',
'                        :P468_SEARCH_SELECTION AS sucheid,',
'                        :P468_MILESTONE_SELECTION AS meilenstein,',
'                        :P468_CARD_NUM AS card_number,',
'                        l_current_reg_id AS vorschriftid,',
'                        :G_BENUTZERID AS benutzerid,',
'                        l_highest_successor_nummer AS et_vorschlag_vorschrift',
'                    FROM dual',
'                ) s ON (',
'                    d.sucheid = s.sucheid AND',
'                    d.meilenstein = s.meilenstein AND',
'                    d.card_number = s.card_number AND',
'                    d.vorschriftid = s.vorschriftid AND',
'                    d.benutzerid = s.benutzerid',
'                )',
'                WHEN MATCHED THEN',
'                    UPDATE SET ',
'                        d.et_verwendung = ''nein'',',
'                        d.et_vorschlag_vorschrift = s.et_vorschlag_vorschrift,',
'                        d.letzte_aenderung_datum = SYSDATE,',
'                        d.letzte_aenderung_benutzerid = :G_BENUTZERID',
'                WHEN NOT MATCHED THEN',
'                    INSERT (',
'                        sucheid, meilenstein, card_number, vorschriftid, benutzerid,',
'                        et_verwendung, et_vorschlag_vorschrift,',
'                        erstellung_datum, letzte_aenderung_datum, letzte_aenderung_benutzerid',
'                    )',
'                    VALUES (',
'                        s.sucheid, s.meilenstein, s.card_number, s.vorschriftid, s.benutzerid,',
'                        ''nein'', s.et_vorschlag_vorschrift,',
'                        SYSDATE, SYSDATE, :G_BENUTZERID',
'                    );',
'                    ',
'                apex_debug.info(''Saved: ET_VERWENDUNG=nein, ET_VORSCHLAG_VORSCHRIFT=%s'', l_highest_successor_nummer);',
'            END IF;',
'            ',
'            l_processed_count := l_processed_count + 1;',
'            ',
'        EXCEPTION',
'            WHEN OTHERS THEN',
'                l_error_count := l_error_count + 1;',
'                apex_debug.error(''Error processing VorschriftID %s: %s'', l_current_reg_id, SQLERRM);',
'        END;',
'    END LOOP;',
'',
'    COMMIT;',
'    ',
'    apex_debug.info(''=== MASS UPDATE COMPLETE ==='');',
'    apex_debug.info(''Processed: %s, Errors: %s'', l_processed_count, l_error_count);',
'',
'    -- Success message',
'    apex_application.g_print_success_message := ',
unistr('        ''Massenupdate erfolgreich: '' || l_processed_count || '' Eintr\00E4ge verarbeitet.'';'),
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        apex_debug.error(''FATAL ERROR in Mass Update: %s'', SQLERRM);',
'        apex_error.add_error(',
'            p_message => ''Fehler beim Massenupdate: '' || SQLERRM,',
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(964102513804442859)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2748776684126744508
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(923435891056643729)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Perform Mass Update_without_successors_15.01.2025'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_selected_rows apex_t_varchar2;',
'    l_processed_count NUMBER := 0;',
'    l_error_count NUMBER := 0;',
'    l_current_reg_id NUMBER;',
'BEGIN',
'    -- Initialize and populate the collection',
'    l_selected_rows := apex_t_varchar2();',
'    ',
'    -- Split the selected rows - handle empty case',
'    IF :P468_SELECTED_ROWS IS NOT NULL AND LENGTH(TRIM(:P468_SELECTED_ROWS)) > 0 THEN',
'        l_selected_rows := apex_string.split(:P468_SELECTED_ROWS, '':'');',
'    ELSE',
unistr('        RAISE_APPLICATION_ERROR(-20001, ''Keine Zeilen f\00FCr Massenupdate ausgew\00E4hlt.'');'),
'    END IF;',
'    ',
'    -- Process each selected regulation',
'    FOR i IN 1..l_selected_rows.COUNT LOOP',
'        BEGIN',
'            l_current_reg_id := TO_NUMBER(l_selected_rows(i));',
'            ',
'            IF :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' THEN',
'                -- UNECE Mass Update',
'                MERGE INTO t_ms_bewertung d',
'                USING (',
'                    SELECT :P468_SEARCH_SELECTION AS sucheid,',
'                           :P468_MILESTONE_SELECTION AS meilenstein,',
'                           :P468_CARD_NUM AS card_number,',
'                           l_current_reg_id AS vorschriftid,',
'                           :G_BENUTZERID AS benutzerid,',
'                           :P468_COMMENT AS et_kommentar',
'                    FROM dual',
'                ) s ON (',
'                    d.sucheid = s.sucheid AND',
'                    d.meilenstein = s.meilenstein AND',
'                    d.card_number = s.card_number AND',
'                    d.vorschriftid = s.vorschriftid AND',
'                    d.benutzerid = s.benutzerid',
'                )',
'                WHEN MATCHED THEN',
'                    UPDATE SET ',
'                        d.et_verwendung = ''ja'',',
'                        d.et_kommentar = CASE ',
'                            WHEN s.et_kommentar IS NOT NULL ',
'                            THEN s.et_kommentar ',
'                            ELSE d.et_kommentar ',
'                        END,',
'                        d.letzte_aenderung_datum = SYSDATE,',
'                        d.letzte_aenderung_benutzerid = :G_BENUTZERID',
'                WHEN NOT MATCHED THEN',
'                    INSERT (sucheid, meilenstein, card_number, vorschriftid, benutzerid, ',
'                           et_verwendung, et_kommentar, erstellung_datum, letzte_aenderung_datum, ',
'                           letzte_aenderung_benutzerid)',
'                    VALUES (s.sucheid, s.meilenstein, s.card_number, s.vorschriftid, ',
'                           s.benutzerid, ''ja'', s.et_kommentar, SYSDATE, SYSDATE, :G_BENUTZERID);',
'                           ',
'            ELSIF :P468_UPDATE_TYPE = ''DEACTIVATE_ROWS'' THEN',
'                -- Deactivate Rows Mass Update',
'                MERGE INTO t_ms_bewertung d',
'                USING (',
'                    SELECT :P468_SEARCH_SELECTION AS sucheid,',
'                           :P468_MILESTONE_SELECTION AS meilenstein,',
'                           :P468_CARD_NUM AS card_number,',
'                           l_current_reg_id AS vorschriftid,',
'                           :G_BENUTZERID AS benutzerid',
'                    FROM dual',
'                ) s ON (',
'                    d.sucheid = s.sucheid AND',
'                    d.meilenstein = s.meilenstein AND',
'                    d.card_number = s.card_number AND',
'                    d.vorschriftid = s.vorschriftid AND',
'                    d.benutzerid = s.benutzerid',
'                )',
'                WHEN MATCHED THEN',
'                    UPDATE SET ',
'                        d.et_verwendung = ''nein'',',
'                        d.letzte_aenderung_datum = SYSDATE,',
'                        d.letzte_aenderung_benutzerid = :G_BENUTZERID',
'                WHEN NOT MATCHED THEN',
'                    INSERT (sucheid, meilenstein, card_number, vorschriftid, benutzerid, ',
'                           et_verwendung, erstellung_datum, letzte_aenderung_datum, ',
'                           letzte_aenderung_benutzerid)',
'                    VALUES (s.sucheid, s.meilenstein, s.card_number, s.vorschriftid, ',
'                           s.benutzerid, ''nein'', SYSDATE, SYSDATE, :G_BENUTZERID);',
'            END IF;',
'            ',
'            l_processed_count := l_processed_count + 1;',
'            ',
'        EXCEPTION',
'            WHEN OTHERS THEN',
'                l_error_count := l_error_count + 1;',
'                apex_debug.error(''Error processing VorschriftID %s: %s'', l_current_reg_id, SQLERRM);',
'        END;',
'    END LOOP;',
'',
'    COMMIT;',
'',
'    -- success message',
'    apex_application.g_print_success_message := ',
unistr('        ''Massenupdate erfolgreich: '' || l_processed_count || '' Eintr\00E4ge verarbeitet.'';'),
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        apex_error.add_error(',
'            p_message => ''Fehler beim Massenupdate: '' || SQLERRM,',
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(964102513804442859)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2748776424842744506
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964096100197442854)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Perform Mass Update_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_selected_rows apex_t_varchar2;',
'    l_valid_rows    apex_t_varchar2;',
'    l_processed_count NUMBER := 0;',
'    l_error_count NUMBER := 0;',
'    l_current_reg_id NUMBER;',
'BEGIN',
'    l_selected_rows := apex_string.split(:P468_SELECTED_ROWS, '':'');',
'    ',
'    -- Validate and collect processable rows',
'    FOR i IN 1..l_selected_rows.COUNT LOOP',
'        l_current_reg_id := TO_NUMBER(l_selected_rows(i));',
'        ',
'        -- Check if this regulation can be processed',
'        DECLARE',
'            l_can_process NUMBER := 0;',
'        BEGIN',
'            SELECT COUNT(*)',
'            INTO l_can_process',
'            FROM T_MS_SUCHERGEBNISS ms',
'            LEFT JOIN T_MS_BEWERTUNG bew ON (',
'                bew.SUCHEID = ms.sucheid ',
'                AND bew.MEILENSTEIN = ms.meilenstein',
'                AND bew.CARD_NUMBER = :P468_CARD_NUM',
'                AND bew.VORSCHRIFTID = CASE ',
'                    WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'                    ELSE ms.VORSCHRIFTID',
'                END',
'                AND bew.BENUTZERID = :G_BENUTZERID',
'            )',
'            WHERE ms.sucheid = :P468_SEARCH_SELECTION',
'            AND ms.meilenstein = :P468_MILESTONE_SELECTION',
'            AND (CASE ',
'                WHEN ms.ALTERNATIVE_VORSCHRIFTID IS NOT NULL THEN ms.ALTERNATIVE_VORSCHRIFTID',
'                ELSE ms.VORSCHRIFTID',
'            END) = l_current_reg_id',
'            AND (bew.ET_VERWENDUNG IS NULL OR bew.ET_VERWENDUNG = ''nicht bewertet'');',
'            ',
'            IF l_can_process > 0 THEN',
'                l_valid_rows.EXTEND;',
'                l_valid_rows(l_valid_rows.COUNT) := TO_CHAR(l_current_reg_id);',
'            END IF;',
'            ',
'        EXCEPTION',
'            WHEN OTHERS THEN',
'                l_error_count := l_error_count + 1;',
'        END;',
'    END LOOP;',
'    ',
'    -- Perform update based on type',
'    IF :P468_UPDATE_TYPE = ''DEACTIVATE_ROWS'' AND l_valid_rows.COUNT > 0 THEN',
'        -- Deactivate rows by setting ET_VERWENDUNG to ''nein''',
'        FOR i IN 1..l_valid_rows.COUNT LOOP',
'            MERGE INTO t_ms_bewertung d',
'            USING (',
'                SELECT :P468_SEARCH_SELECTION AS sucheid,',
'                       :P468_MILESTONE_SELECTION AS meilenstein,',
'                       :P468_CARD_NUM AS card_number,',
'                       TO_NUMBER(l_valid_rows(i)) AS vorschriftid,',
'                       :G_BENUTZERID AS benutzerid',
'                FROM dual',
'            ) s ON (',
'                d.sucheid = s.sucheid AND',
'                d.meilenstein = s.meilenstein AND',
'                d.card_number = s.card_number AND',
'                d.vorschriftid = s.vorschriftid AND',
'                d.benutzerid = s.benutzerid',
'            )',
'            WHEN MATCHED THEN',
'                UPDATE SET d.et_verwendung = ''nein'',',
'                           d.letzte_aenderung_datum = SYSDATE,',
'                           d.letzte_aenderung_benutzerid = :G_BENUTZERID',
'            WHEN NOT MATCHED THEN',
'                INSERT (sucheid, meilenstein, card_number, vorschriftid, benutzerid, ',
'                       et_verwendung, erstellung_datum, letzte_aenderung_datum, ',
'                       letzte_aenderung_benutzerid)',
'                VALUES (s.sucheid, s.meilenstein, s.card_number, s.vorschriftid, ',
'                       s.benutzerid, ''nein'', SYSDATE, SYSDATE, :G_BENUTZERID);',
'        END LOOP;',
'        ',
'        l_processed_count := l_valid_rows.COUNT;',
'        ',
'    ELSIF :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' AND l_valid_rows.COUNT > 0 THEN',
'        -- UNECE Highest Series Selection Logic',
'        FOR i IN 1..l_valid_rows.COUNT LOOP',
'            MERGE INTO t_ms_bewertung d',
'            USING (',
'                SELECT :P468_SEARCH_SELECTION AS sucheid,',
'                       :P468_MILESTONE_SELECTION AS meilenstein,',
'                       :P468_CARD_NUM AS card_number,',
'                       TO_NUMBER(l_valid_rows(i)) AS vorschriftid,',
'                       :G_BENUTZERID AS benutzerid,',
'                       :P468_COMMENT AS et_kommentar',
'                FROM dual',
'            ) s ON (',
'                d.sucheid = s.sucheid AND',
'                d.meilenstein = s.meilenstein AND',
'                d.card_number = s.card_number AND',
'                d.vorschriftid = s.vorschriftid AND',
'                d.benutzerid = s.benutzerid',
'            )',
'            WHEN MATCHED THEN',
'                UPDATE SET d.et_verwendung = ''ja'',',
'                           d.et_kommentar = CASE ',
'                               WHEN s.et_kommentar IS NOT NULL ',
'                               THEN s.et_kommentar ',
'                               ELSE d.et_kommentar ',
'                           END,',
'                           d.letzte_aenderung_datum = SYSDATE,',
'                           d.letzte_aenderung_benutzerid = :G_BENUTZERID',
'            WHEN NOT MATCHED THEN',
'                INSERT (sucheid, meilenstein, card_number, vorschriftid, benutzerid, ',
'                       et_verwendung, et_kommentar, erstellung_datum, letzte_aenderung_datum, ',
'                       letzte_aenderung_benutzerid)',
'                VALUES (s.sucheid, s.meilenstein, s.card_number, s.vorschriftid, ',
'                       s.benutzerid, ''ja'', s.et_kommentar, SYSDATE, SYSDATE, :G_BENUTZERID);',
'        END LOOP;',
'        ',
'        l_processed_count := l_valid_rows.COUNT;',
'    END IF;',
'',
'    COMMIT;',
'',
'    -- Set success message',
'    apex_application.g_print_success_message := ',
unistr('        ''Massenupdate erfolgreich: '' || l_processed_count || '' Eintr\00E4ge verarbeitet.'';'),
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        apex_error.add_error(',
'            p_message => ''Fehler beim Massenupdate: '' || SQLERRM,',
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2708116215701945381
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964096843864442855)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Comment Value'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Set values from page 464 with debugging',
'    :P468_SELECTED_ROWS := :P464_SELECTED_ROWS;',
'    :P468_SEARCH_SELECTION := :P464_SEARCH_SELECTION;',
'    :P468_MILESTONE_SELECTION := :P464_MILESTONE_SELECTION;',
'    :P468_CARD_NUM := :P464_CARD_NUM;',
'    :P468_UPDATE_TYPE := :P464_UPDATE_TYPE;',
'    ',
'    -- Handle comment with explicit logic',
'    IF :P464_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' THEN',
'        :P468_COMMENT := :P464_COMMENT;',
'    ELSE',
'        :P468_COMMENT := NULL;',
'    END IF;',
'    ',
'    -- Debug logging',
'    -- apex_debug.info(''P464_COMMENT value: %s'', :P464_COMMENT);',
'    -- apex_debug.info(''P468_COMMENT set to: %s'', :P468_COMMENT);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2708115472034945380
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964096500353442855)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Calculate Validation Summary'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_ok_count       NUMBER := 0;',
'    l_warning_count  NUMBER := 0;',
'    l_error_count    NUMBER := 0;',
'    ',
'    TYPE rec_validation_status IS RECORD (',
'        status VARCHAR2(10)',
'    );',
'    ',
'    TYPE tbl_validation_status IS TABLE OF rec_validation_status;',
'    ',
'    l_validation_results tbl_validation_status;',
'',
'BEGIN',
'    -- If no rows are selected, exit early',
'    IF :P468_SELECTED_ROWS IS NULL OR TRIM(:P468_SELECTED_ROWS) IS NULL THEN',
'        :P468_OK_COUNT       := 0;',
'        :P468_WARNING_COUNT  := 0;',
'        :P468_ERROR_COUNT    := 0;',
'        :P468_TOTAL_SELECTED := 0;',
'        ',
'        apex_debug.warn(''No rows selected - P468_SELECTED_ROWS is empty'');',
'        RETURN;',
'    END IF;',
'',
'    -- Execute comprehensive validation query',
'    WITH',
'        selected_regulations AS (',
'            SELECT TO_NUMBER(COLUMN_VALUE) AS vorschriftid',
'            FROM TABLE(apex_string.split(:P468_SELECTED_ROWS, '':''))',
'            WHERE COLUMN_VALUE IS NOT NULL',
'        ),',
'        -- Check 1: Milestone comparison errors',
'        milestone_comparison_errors AS (',
'            SELECT DISTINCT',
'                COALESCE(m1.vorschriftid, m2.vorschriftid) as vorschriftid,',
'                1 as has_comparison_error',
'            FROM (',
'                SELECT DISTINCT ms.vorschriftid',
'                FROM t_ms_suchergebniss ms',
'                WHERE ms.sucheid = :P468_SEARCH_SELECTION ',
'                AND ms.meilenstein = :P468_MILESTONE_SELECTION',
'                AND (CASE WHEN ms.alternative_vorschriftid IS NOT NULL ',
'                          THEN ms.alternative_vorschriftid ',
'                          ELSE ms.vorschriftid END) IN (',
'                    SELECT vorschriftid FROM selected_regulations',
'                )',
'            ) m1',
'            FULL OUTER JOIN (',
'                SELECT DISTINCT ms.vorschriftid',
'                FROM t_ms_suchergebniss ms',
'                WHERE ms.sucheid = :P468_SEARCH_SELECTION ',
'                AND ms.meilenstein = (:P468_MILESTONE_SELECTION - 1)',
'                AND (CASE WHEN ms.alternative_vorschriftid IS NOT NULL ',
'                          THEN ms.alternative_vorschriftid ',
'                          ELSE ms.vorschriftid END) IN (',
'                    SELECT vorschriftid FROM selected_regulations',
'                )',
'            ) m2 ON m1.vorschriftid = m2.vorschriftid',
'            WHERE EXISTS (',
'                SELECT 1 FROM t_ms_suchergebniss ms_dup1',
'                WHERE ms_dup1.vorschriftid = COALESCE(m1.vorschriftid, m2.vorschriftid)',
'                AND ms_dup1.sucheid = :P468_SEARCH_SELECTION ',
'                AND ms_dup1.meilenstein = :P468_MILESTONE_SELECTION',
'                AND ms_dup1.manueller_eintrag = 10',
'                AND EXISTS (',
'                    SELECT 1 FROM t_ms_suchergebniss ms_dup2',
'                    WHERE ms_dup2.vorschriftid = ms_dup1.vorschriftid',
'                    AND ms_dup2.sucheid = :P468_SEARCH_SELECTION',
'                    AND ms_dup2.meilenstein = :P468_MILESTONE_SELECTION',
'                    AND ms_dup2.landid = ms_dup1.landid',
'                    AND ms_dup2.manueller_eintrag != 10',
'                )',
'            )',
'        ),',
'        -- Check 2: Base regulation info',
'        regulation_base_info AS (',
'            SELECT',
'                (CASE WHEN ms.alternative_vorschriftid IS NOT NULL ',
'                      THEN ms.alternative_vorschriftid ',
'                      ELSE ms.vorschriftid END) as vorschriftid,',
'                v.publisher,',
'                s.card_number',
'            FROM T_MS_SUCHERGEBNISS ms',
'            JOIN T_MS_SUCHE_SPLIT s ON (',
'                ms.sucheid = s.sucheid ',
'                AND ms.meilenstein = s.meilenstein ',
'                AND ms.landid = s.landid ',
'                AND s.card_number = :P468_CARD_NUM',
'                AND (s.benutzerid = :G_BENUTZERID ',
'                     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                               WHERE brr.benutzerid = :G_BENUTZERID ',
'                               AND brr.rolleid = 1001))',
'            )',
'            JOIN T_VORSCHRIFT v ON (',
'                v.vorschriftid = (CASE WHEN ms.alternative_vorschriftid IS NOT NULL ',
'                                       THEN ms.alternative_vorschriftid ',
'                                       ELSE ms.vorschriftid END)',
'            )',
'            WHERE ms.sucheid = :P468_SEARCH_SELECTION',
'              AND ms.meilenstein = :P468_MILESTONE_SELECTION',
'              AND (CASE WHEN ms.alternative_vorschriftid IS NOT NULL ',
'                        THEN ms.alternative_vorschriftid ',
'                        ELSE ms.vorschriftid END) IN (',
'                  SELECT vorschriftid FROM selected_regulations',
'              )',
'            GROUP BY (',
'                CASE WHEN ms.alternative_vorschriftid IS NOT NULL ',
'                     THEN ms.alternative_vorschriftid ',
'                     ELSE ms.vorschriftid END',
'            ), v.publisher, s.card_number',
'        ),',
'        -- Check 3: Already evaluated - FIXED VERSION',
'        evaluation_status AS (',
'            SELECT vorschriftid, 1 AS is_evaluated',
'            FROM T_MS_BEWERTUNG',
'            WHERE sucheid = :P468_SEARCH_SELECTION',
'              AND meilenstein = :P468_MILESTONE_SELECTION',
'              AND card_number = :P468_CARD_NUM',
'              AND (benutzerid = :G_BENUTZERID ',
'                   OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                             WHERE brr.benutzerid = :G_BENUTZERID ',
'                             AND brr.rolleid = 1001))',
'              -- FIX: Properly check for evaluation',
'              AND et_verwendung IS NOT NULL ',
'              AND et_verwendung != ''nicht bewertet''',
'              AND vorschriftid IN (SELECT vorschriftid FROM selected_regulations)',
'        ),',
'        -- Check 4: Theme contradictions',
'        theme_contradictions AS (',
'            SELECT ',
'                (CASE WHEN ms.alternative_vorschriftid IS NOT NULL ',
'                      THEN ms.alternative_vorschriftid ',
'                      ELSE ms.vorschriftid END) as vorschriftid,',
'                COUNT(DISTINCT ms.themabezeichnung) as theme_count',
'            FROM t_ms_suchergebniss ms',
'            INNER JOIN t_ms_suche_split split ON (',
'                split.sucheid = ms.sucheid ',
'                AND split.meilenstein = ms.meilenstein ',
'                AND split.landid = ms.landid',
'                AND split.card_number = :P468_CARD_NUM',
'                AND (split.benutzerid = :G_BENUTZERID ',
'                     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                               WHERE brr.benutzerid = :G_BENUTZERID ',
'                               AND brr.rolleid = 1001))',
'            )',
'            WHERE ms.sucheid = :P468_SEARCH_SELECTION',
'            AND ms.meilenstein = :P468_MILESTONE_SELECTION',
'            AND (CASE WHEN ms.alternative_vorschriftid IS NOT NULL ',
'                      THEN ms.alternative_vorschriftid ',
'                      ELSE ms.vorschriftid END) IN (',
'                SELECT vorschriftid FROM selected_regulations',
'            )',
'            GROUP BY (',
'                CASE WHEN ms.alternative_vorschriftid IS NOT NULL ',
'                     THEN ms.alternative_vorschriftid ',
'                     ELSE ms.vorschriftid END',
'            )',
'            HAVING COUNT(DISTINCT ms.themabezeichnung) > 1',
'        ),',
'        -- Check 5: Alternative contradictions',
'        alternative_contradictions AS (',
'            SELECT ',
'                (CASE WHEN ms.alternative_vorschriftid IS NOT NULL ',
'                      THEN ms.alternative_vorschriftid ',
'                      ELSE ms.vorschriftid END) as vorschriftid,',
'                COUNT(DISTINCT COALESCE(va.vorschrift_nummer, vm.vorschrift_nummer)) as alt_count',
'            FROM t_ms_suchergebniss ms',
'            INNER JOIN t_ms_suche_split split ON (',
'                split.sucheid = ms.sucheid ',
'                AND split.meilenstein = ms.meilenstein ',
'                AND split.landid = ms.landid',
'                AND split.card_number = :P468_CARD_NUM',
'                AND (split.benutzerid = :G_BENUTZERID ',
'                     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                               WHERE brr.benutzerid = :G_BENUTZERID ',
'                               AND brr.rolleid = 1001))',
'            )',
'            LEFT JOIN t_vorschrift vm ON ms.vorschriftid = vm.vorschriftid',
'            LEFT JOIN t_vorschrift va ON ms.alternative_vorschriftid = va.vorschriftid',
'            WHERE ms.sucheid = :P468_SEARCH_SELECTION',
'            AND ms.meilenstein = :P468_MILESTONE_SELECTION',
'            AND (CASE WHEN ms.alternative_vorschriftid IS NOT NULL ',
'                      THEN ms.alternative_vorschriftid ',
'                      ELSE ms.vorschriftid END) IN (',
'                SELECT vorschriftid FROM selected_regulations',
'            )',
'            AND EXISTS (',
'                SELECT 1 FROM t_ms_suchergebniss ms2',
'                WHERE ms2.vorschriftid = ms.vorschriftid',
'                AND ms2.sucheid = ms.sucheid',
'                AND ms2.meilenstein = ms.meilenstein',
'                AND NVL(ms2.alternative_vorschriftid, 0) != NVL(ms.alternative_vorschriftid, 0)',
'            )',
'            GROUP BY (',
'                CASE WHEN ms.alternative_vorschriftid IS NOT NULL ',
'                     THEN ms.alternative_vorschriftid ',
'                     ELSE ms.vorschriftid END',
'            )',
'            HAVING COUNT(DISTINCT COALESCE(va.vorschrift_nummer, vm.vorschrift_nummer)) > 1',
'        ),',
'        -- Check 6: Country coverage',
'        country_coverage AS (',
'            SELECT',
'                base.vorschriftid,',
'                (SELECT COUNT(DISTINCT landid) ',
'                 FROM T_MS_SUCHE_SPLIT ',
'                 WHERE card_number = :P468_CARD_NUM ',
'                 AND sucheid = :P468_SEARCH_SELECTION ',
'                 AND meilenstein = :P468_MILESTONE_SELECTION ',
'                 AND (benutzerid = :G_BENUTZERID ',
'                      OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                                WHERE brr.benutzerid = :G_BENUTZERID ',
'                                AND brr.rolleid = 1001))',
'                ) AS card_country_count,',
'                COUNT(DISTINCT ms.landid) AS reg_country_count',
'            FROM regulation_base_info base',
'            JOIN T_MS_SUCHERGEBNISS ms ON (',
'                ms.sucheid = :P468_SEARCH_SELECTION ',
'                AND ms.meilenstein = :P468_MILESTONE_SELECTION ',
'                AND (CASE WHEN ms.alternative_vorschriftid IS NOT NULL ',
'                          THEN ms.alternative_vorschriftid ',
'                          ELSE ms.vorschriftid END) = base.vorschriftid',
'            )',
'            GROUP BY base.vorschriftid, base.card_number',
'        )',
'    -- MAIN VALIDATION LOGIC WITH CORRECT PRIORITY',
'    SELECT',
'        CASE',
'            -- PRIORITY 1: Milestone comparison errors',
'            WHEN mce.has_comparison_error = 1 THEN ''error''',
'            ',
'            -- PRIORITY 2: Already evaluated',
'            WHEN eval.is_evaluated = 1 THEN ''error''',
'            ',
'            -- PRIORITY 3: Theme contradictions (only if NOT DEACTIVATE_ROWS)',
'            WHEN tc.vorschriftid IS NOT NULL ',
'                 AND :P468_UPDATE_TYPE != ''DEACTIVATE_ROWS'' THEN ''error''',
'            ',
'            -- PRIORITY 4: Alternative contradictions',
'            WHEN ac.vorschriftid IS NOT NULL THEN ''error''',
'            ',
'            -- PRIORITY 5: UNECE publisher check',
'            WHEN :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' ',
'                 AND NVL(base.publisher, ''NONE'') != ''UNECE'' THEN ''error''',
'            ',
'            -- PRIORITY 6: Country coverage (WARNING only)',
'            WHEN cov.reg_country_count < cov.card_country_count THEN ''warning''',
'            ',
'            -- Everything OK',
'            ELSE ''ok''',
'        END AS status',
'    BULK COLLECT INTO l_validation_results',
'    FROM regulation_base_info base',
'    LEFT JOIN evaluation_status eval ON base.vorschriftid = eval.vorschriftid',
'    LEFT JOIN theme_contradictions tc ON base.vorschriftid = tc.vorschriftid',
'    LEFT JOIN alternative_contradictions ac ON base.vorschriftid = ac.vorschriftid',
'    LEFT JOIN country_coverage cov ON base.vorschriftid = cov.vorschriftid',
'    LEFT JOIN milestone_comparison_errors mce ON base.vorschriftid = mce.vorschriftid;',
'',
'    -- Count the validation results',
'    FOR i IN 1..l_validation_results.COUNT LOOP',
'        IF l_validation_results(i).status = ''error'' THEN',
'            l_error_count := l_error_count + 1;',
'        ELSIF l_validation_results(i).status = ''warning'' THEN',
'            l_warning_count := l_warning_count + 1;',
'        ELSE -- ''ok''',
'            l_ok_count := l_ok_count + 1;',
'        END IF;',
'    END LOOP;',
'',
'    -- Set the page items',
'    :P468_TOTAL_SELECTED := l_validation_results.COUNT;',
'    :P468_OK_COUNT       := l_ok_count;',
'    :P468_WARNING_COUNT  := l_warning_count;',
'    :P468_ERROR_COUNT    := l_error_count;',
'    ',
'    -- DEBUG LOGGING',
'    apex_debug.info(''=== VALIDATION SUMMARY ==='');',
'    apex_debug.info(''P468_SELECTED_ROWS: %s'', :P468_SELECTED_ROWS);',
'    apex_debug.info(''P468_TOTAL_SELECTED: %s'', :P468_TOTAL_SELECTED);',
'    apex_debug.info(''P468_OK_COUNT: %s'', :P468_OK_COUNT);',
'    apex_debug.info(''P468_WARNING_COUNT: %s'', :P468_WARNING_COUNT);',
'    apex_debug.info(''P468_ERROR_COUNT: %s'', :P468_ERROR_COUNT);',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_debug.error(''Error in Calculate Validation Summary: %s'', SQLERRM);',
'        -- Fail safely - disable button by setting high error count',
'        :P468_ERROR_COUNT := 999;',
'        :P468_OK_COUNT := 0;',
'        :P468_WARNING_COUNT := 0;',
'        :P468_TOTAL_SELECTED := 0;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2708115815545945380
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964095680651442854)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Calculate Validation Summary_17.09.2025'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_ok_count       NUMBER := 0;',
'    l_warning_count  NUMBER := 0;',
'    l_error_count    NUMBER := 0;',
'    ',
'    -- Record type to hold the validation result for one row',
'    TYPE rec_validation_status IS RECORD (',
'        status VARCHAR2(10)',
'    );',
'    ',
'    -- Table type to hold all results',
'    TYPE tbl_validation_status IS TABLE OF rec_validation_status;',
'    ',
'    l_validation_results tbl_validation_status;',
'',
'BEGIN',
'    -- If no rows are selected, there is nothing to do.',
'    IF :P468_SELECTED_ROWS IS NULL THEN',
'        :P468_OK_COUNT       := 0;',
'        :P468_WARNING_COUNT  := 0;',
'        :P468_ERROR_COUNT    := 0;',
'        :P468_TOTAL_SELECTED := 0;',
'        RETURN;',
'    END IF;',
'',
'    -- Execute the main validation query and load all results into memory at once',
'    WITH',
'        selected_regulations AS (',
'            SELECT TO_NUMBER(COLUMN_VALUE) AS vorschriftid',
'            FROM TABLE(apex_string.split(:P468_SELECTED_ROWS, '':''))',
'        ),',
'        regulation_base_info AS (',
'            SELECT',
'                (CASE WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid ELSE ms.vorschriftid END) as vorschriftid,',
'                v.publisher,',
'                s.card_number',
'            FROM T_MS_SUCHERGEBNISS ms',
'            JOIN T_MS_SUCHE_SPLIT s',
'                ON ms.sucheid = s.sucheid AND ms.meilenstein = s.meilenstein AND ms.landid = s.landid AND s.benutzerid = :G_BENUTZERID',
'            JOIN T_VORSCHRIFT v',
'                ON v.vorschriftid = (CASE WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid ELSE ms.vorschriftid END)',
'            WHERE ms.sucheid = :P468_SEARCH_SELECTION',
'              AND ms.meilenstein = :P468_MILESTONE_SELECTION',
'              AND (CASE WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid ELSE ms.vorschriftid END) IN (SELECT vorschriftid FROM selected_regulations)',
'            GROUP BY (CASE WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid ELSE ms.vorschriftid END), v.publisher, s.card_number',
'        ),',
'        evaluation_status AS (',
'            SELECT vorschriftid, 1 AS is_evaluated',
'            FROM T_MS_BEWERTUNG',
'            WHERE sucheid = :P468_SEARCH_SELECTION',
'              AND meilenstein = :P468_MILESTONE_SELECTION',
'              AND benutzerid = :G_BENUTZERID',
'              AND et_verwendung != ''nicht bewertet''',
'              AND vorschriftid IN (SELECT vorschriftid FROM selected_regulations)',
'        ),',
'        country_coverage AS (',
'            SELECT',
'                base.vorschriftid,',
'                (SELECT COUNT(DISTINCT landid) FROM T_MS_SUCHE_SPLIT WHERE card_number = base.card_number AND sucheid = :P468_SEARCH_SELECTION AND meilenstein = :P468_MILESTONE_SELECTION AND benutzerid = :G_BENUTZERID) AS card_country_count,',
'                COUNT(DISTINCT ms.landid) AS reg_country_count',
'            FROM regulation_base_info base',
'            JOIN T_MS_SUCHERGEBNISS ms',
'                ON ms.sucheid = :P468_SEARCH_SELECTION AND ms.meilenstein = :P468_MILESTONE_SELECTION AND (CASE WHEN ms.alternative_vorschriftid IS NOT NULL THEN ms.alternative_vorschriftid ELSE ms.vorschriftid END) = base.vorschriftid',
'            GROUP BY base.vorschriftid, base.card_number',
'        )',
'    SELECT',
'        CASE',
'            WHEN eval.is_evaluated = 1 THEN ''ERROR''',
'            WHEN :P468_UPDATE_TYPE = ''UNECE_HIGHEST_SERIES'' AND NVL(base.publisher, ''NONE'') != ''UNECE'' THEN ''ERROR''',
'            WHEN cov.reg_country_count < cov.card_country_count THEN ''WARNING''',
'            ELSE ''OK''',
'        END AS status',
'    BULK COLLECT INTO l_validation_results',
'    FROM',
'        regulation_base_info base',
'    LEFT JOIN',
'        evaluation_status eval ON base.vorschriftid = eval.vorschriftid',
'    LEFT JOIN',
'        country_coverage cov ON base.vorschriftid = cov.vorschriftid;',
'',
'    -- Now, loop through the in-memory results to get the final counts',
'    FOR i IN 1..l_validation_results.COUNT LOOP',
'        IF l_validation_results(i).status = ''ERROR'' THEN',
'            l_error_count := l_error_count + 1;',
'        ELSIF l_validation_results(i).status = ''WARNING'' THEN',
'            l_warning_count := l_warning_count + 1;',
'        ELSE -- OK',
'            l_ok_count := l_ok_count + 1;',
'        END IF;',
'    END LOOP;',
'',
'    -- Set the page items',
'    :P468_TOTAL_SELECTED := l_validation_results.COUNT;',
'    :P468_OK_COUNT       := l_ok_count;',
'    :P468_WARNING_COUNT  := l_warning_count;',
'    :P468_ERROR_COUNT    := l_error_count;',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- In case of any unexpected SQL error, fail safely',
'        :P468_ERROR_COUNT := apex_string.split(:P468_SELECTED_ROWS, '':'').COUNT;',
'        :P468_OK_COUNT := 0;',
'        :P468_WARNING_COUNT := 0;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2708116635247945381
);
wwv_flow_imp.component_end;
end;
/
