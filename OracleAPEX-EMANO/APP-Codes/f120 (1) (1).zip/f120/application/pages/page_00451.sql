prompt --application/pages/page_00451
begin
--   Manifest
--     PAGE: 00451
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>451
,p_name=>'Suche Short'
,p_alias=>'SUCHE-SHORT'
,p_page_mode=>'MODAL'
,p_step_title=>'Suche Short'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_dialog_chained=>'N'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78202502153072164)
,p_plug_name=>'Suche Short'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- Anpasung aufgrund der L\00E4nder. Daten werden zum Schluss anhand der L\00E4nder zusammengefasst. Wenn Daten gleich sind, dann wird Land in Liste mit aufgenommen'),
'',
'with cte_base_regela as ',
'    ( Select t.vorschriftid, t.landid, t.MS_PARAMETERID, row_number() over (partition by t.vorschriftid,t.landid order by nvl(kritikalitaet,0) desc) as xrow',
'',
'    --Select t.vorschriftid, t.landid, t.MS_PARAMETERID, row_number() over (partition by t.vorschriftid, t.landid order by t.alternative_vorschriftid desc nulls last, kritikalitaet desc nulls last) as xrow',
'',
'        from t_ms_suchergebniss t ',
'        join t_ms_parameter pm on (t.MS_PARAMETERID = pm.MS_PARAMETERID)',
'        left join T_MS_PARAMETER_REF_AUSGABE tpr on (t.MS_PARAMETERID = tpr.MS_PARAMETERID)',
'        left join T_MS_AUSGABE_TEXT ta on(tpr.MS_AUSGABE_TEXTID = ta.MS_AUSGABE_TEXTID)',
'        where sucheid = :P451_SUCHEID and meilenstein = :P451_MS and AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = :P451_NEGATIV',
'),',
'cte_base_regelb as ',
'',
'    ( Select t.vorschriftid, t.landid, t.MS_PARAMETERID, t.risiko, row_number() over (partition by t.vorschriftid,t.landid order by nvl(kritikalitaet,0) desc) as xrow',
'',
'    --Select t.vorschriftid, t.landid, t.MS_PARAMETERID, row_number() over (partition by t.vorschriftid, t.landid order by t.alternative_vorschriftid desc nulls last, kritikalitaet desc nulls last) as xrow',
'        from t_ms_suchergebniss t ',
'        join t_ms_parameter pm on (t.MS_PARAMETERID = pm.MS_PARAMETERID)',
'        left join T_MS_PARAMETER_REF_AUSGABE tpr on (t.MS_PARAMETERID = tpr.MS_PARAMETERID)',
'        left join T_MS_AUSGABE_TEXT ta on(tpr.MS_AUSGABE_TEXTID = ta.MS_AUSGABE_TEXTID)',
'        where sucheid = :P451_SUCHEID and meilenstein = :P451_MS-1 and :P451_DELTA = 1  and AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = :P451_NEGATIV',
'),',
'cte_alternative_aktuellerms as ',
'    (select nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) Vorschriftnummer,',
'        nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) as vorschriftid , ',
'        regelnummer as Regel, tms.Risiko, tmat.ausgabe_text einsatz_erlaeuterung,',
'        --listagg (distinct tl.b_nummer, '','') within group (order by tl.b_nummer asc) Laender,',
'    tms.landid,',
'    teg.vorschrift_nummer as Grundvorschrift,  nvl(tmat.kritikalitaet,0) as Kritikalitaet,',
'    ALTERNATIVE_VORSCHRIFTID',
'      from t_MS_SUCHERGEBNISS tms',
'       join t_ms_parameter pm on (tms.MS_PARAMETERID = pm.MS_PARAMETERID)',
'      join cte_base_regela cbr on (tms.vorschriftid = cbr.vorschriftid and tms.MS_PARAMETERID = cbr.MS_PARAMETERID and tms.landid = cbr.landid  and cbr.xrow = 1)',
'      --left outer join t_ms_parameter tmp on (tms.regelnummer = tmp.nummer)',
'      left outer join t_ms_parameter_ref_ausgabe tmpra on (pm.MS_PARAMETERID = tmpra.MS_PARAMETERID)',
'      left outer join t_ms_ausgabe_text tmat on (tmpra.MS_AUSGABE_TEXTID = tmat.MS_AUSGABE_TEXTID)',
'      left outer join t_vorschrift tv on (tms.ALTERNATIVE_VORSCHRIFTID = tv.vorschriftid)',
'      left outer join t_vorschrift teg on (NVL2(tms.ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid,null)= teg.vorschriftid)',
'      where sucheid = :P451_SUCHEID and meilenstein = :P451_MS',
'),',
'cte_alternativeb as',
' ',
'    (select nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) Vorschriftnummer,',
'           nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) as vorschriftid , ',
'    regelnummer as Regel, tms.Risiko, tmat.ausgabe_text as einsatz_erlaeuterung,',
'    --listagg (distinct tl.b_nummer, '','') within group (order by tl.b_nummer asc) Laender,',
'    tms.landid,',
'    teg.vorschrift_nummer as Grundvorschrift,  nvl(tmat.kritikalitaet,0) as Kritikalitaet,',
'    ALTERNATIVE_VORSCHRIFTID',
'      from t_MS_SUCHERGEBNISS tms',
'       join t_ms_parameter pm on (tms.MS_PARAMETERID =pm.MS_PARAMETERID)',
'      join cte_base_regelb cbr on (tms.vorschriftid = cbr.vorschriftid and tms.MS_PARAMETERID = cbr.MS_PARAMETERID and tms.landid = cbr.landid  and cbr.xrow = 1)',
'      --left outer join t_ms_parameter tmp on (tms.regelnummer = tmp.nummer)',
'      left outer join t_ms_parameter_ref_ausgabe tmpra on (pm.MS_PARAMETERID = tmpra.MS_PARAMETERID)',
'      left outer join t_ms_ausgabe_text tmat on (tmpra.MS_AUSGABE_TEXTID = tmat.MS_AUSGABE_TEXTID)',
'      left outer join t_vorschrift tv on (tms.ALTERNATIVE_VORSCHRIFTID = tv.vorschriftid)',
'      left outer join t_vorschrift teg on (NVL2(tms.ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid,null)= teg.vorschriftid)',
'  where :P451_DELTA = 1 and sucheid = :P451_SUCHEID and meilenstein = :P451_MS-1',
'), cte_delta as (',
'Select case when ctb.vorschriftnummer is null and :P451_DELTA = 1 then ''<span style="color:green">'' || ctam.Vorschriftnummer ||''</span> ''  ',
'       when (ctam.Vorschriftnummer is null and :P451_DELTA = 1) then ''<span style="color:orange">'' || ctb.Vorschriftnummer ||''</span> '' ',
'        else nvl(ctam.vorschriftnummer,ctb.Vorschriftnummer) end as vorschriftnummer, ',
'    case when ctb.vorschriftnummer is null then ''Neu'' when ctam.Vorschriftnummer is null then ''entfallen'' else ''wegen Projektverschiebung'' end  as Delta,',
'    nvl(ctam.vorschriftid, ctb.vorschriftid) as vorschriftid,',
'     ctam.regel as regel , ',
'     ctb.regel as regel_alt,',
'     nvl(ctam.Risiko,ctb.Risiko) as Risiko, ',
'     ctam.einsatz_erlaeuterung, ',
'     nvl(ctam.landid, ctb.landid) as landid, ',
'     ctam.Grundvorschrift, ',
'     ctb.einsatz_erlaeuterung as text_alt,',
'     ctam.kritikalitaet , ',
'     ctb.kritikalitaet as krit_alt',
' ',
'from cte_alternative_aktuellerms ctam',
'full outer join cte_alternativeb ctb on (:P451_DELTA = 1 and ctam.vorschriftid = ctb.vorschriftid and ctam.landid = ctb.landid)',
'where :P451_DELTA = 0 or (:P451_DELTA = 1 and (( ctam.vorschriftnummer is null or ctb.Vorschriftnummer is null)',
'      or (ctb.regel is null or ctam.regel is null or ctam.regel != ctb.regel)))',
')',
' ',
'Select vorschriftnummer, Delta, vorschriftid, regel, regel_alt, Risiko, einsatz_erlaeuterung, ',
'--    landid, ',
'        Grundvorschrift, text_alt, kritikalitaet , krit_alt, ',
'        listagg (distinct tl.b_nummer, '','') within group (order by tl.b_nummer asc) as Laender',
'        from cte_delta delta',
'        left outer join t_land tl on (delta.landid = tl.landid)',
'    group by vorschriftnummer, Delta, vorschriftid, regel, regel_alt, Risiko, einsatz_erlaeuterung, ',
'--    landid, ',
'    Grundvorschrift, text_alt, kritikalitaet, krit_alt',
'',
'',
'',
'',
'',
'',
'',
'/*with cte_base_regela as ',
'( Select t.vorschriftid, t.MS_PARAMETERID, t.risiko, row_number() over (partition by t.vorschriftid, t.risiko order by nvl(kritikalitaet,0) desc) as xrow',
'        from t_ms_suchergebniss t ',
'        join t_ms_parameter pm on (t.MS_PARAMETERID =pm.MS_PARAMETERID)',
'left join T_MS_PARAMETER_REF_AUSGABE tpr on (t.MS_PARAMETERID =tpr.MS_PARAMETERID)',
'left join T_MS_AUSGABE_TEXT ta on(tpr.MS_AUSGABE_TEXTID= ta.MS_AUSGABE_TEXTID)',
'where sucheid = :P451_SUCHEID and meilenstein = :P451_MS),',
'cte_base_regelb as ',
'( Select t.vorschriftid, t.MS_PARAMETERID, t.risiko, row_number() over (partition by t.vorschriftid, t.risiko order by nvl(kritikalitaet,0) desc) as xrow',
'        from t_ms_suchergebniss t ',
'        join t_ms_parameter pm on (t.MS_PARAMETERID =pm.MS_PARAMETERID)',
'left join T_MS_PARAMETER_REF_AUSGABE tpr on (t.MS_PARAMETERID =tpr.MS_PARAMETERID)',
'left join T_MS_AUSGABE_TEXT ta on(tpr.MS_AUSGABE_TEXTID= ta.MS_AUSGABE_TEXTID)',
'where sucheid = :P451_SUCHEID and meilenstein = :P451_MS-1 and :P451_DELTA = 1  and AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE =:P451_NEGATIV),',
'',
'                         ',
'cte1 as (',
'select distinct nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) Vorschriftnummer,',
'                          nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) as vorschriftid , ',
' regelnummer as Regel, tms.Risiko, tmat.ausgabe_text einsatz_erlaeuterung,',
' listagg (distinct tl.b_nummer, '','') within group (order by tl.b_nummer asc) Laender, teg.vorschrift_nummer as Grundvorschrift,  nvl(tmat.kritikalitaet,0) as Kritikalitaet',
'  from t_MS_SUCHERGEBNISS tms',
'   join t_ms_parameter pm on (tms.MS_PARAMETERID =pm.MS_PARAMETERID)',
'  join cte_base_regelb cbr on (tms.vorschriftid = cbr.vorschriftid and tms.MS_PARAMETERID =cbr.MS_PARAMETERID and tms.risiko = cbr.risiko and cbr.xrow =1)',
'  left outer join t_ms_parameter tmp on (tms.regelnummer = tmp.nummer)',
'  left outer join t_ms_parameter_ref_ausgabe tmpra on (tmp.MS_PARAMETERID = tmpra.MS_PARAMETERID)',
'  left outer join t_ms_ausgabe_text tmat on (tmpra.MS_AUSGABE_TEXTID = tmat.MS_AUSGABE_TEXTID)',
'  left outer join t_vorschrift tv on (tms.ALTERNATIVE_VORSCHRIFTID = tv.vorschriftid)',
'  left outer join t_land tl on (tms.landid = tl.landid)',
'  left outer join t_vorschrift teg on (NVL2(tms.ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid,null)= teg.vorschriftid)',
'  where sucheid = :P451_SUCHEID and meilenstein = :P451_MS -1 and :P451_DELTA = 1  and pm.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE =:P451_NEGATIV',
'   group by nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) ,',
'   nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) ',
'  ,  regelnummer ',
'  , tms.Risiko, tmat.ausgabe_text,teg.vorschrift_nummer , nvl(tmat.kritikalitaet,0)',
'), ',
'Cte2 as (',
'select distinct nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) Vorschriftnummer, nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) as vorschriftid ,  ',
'regelnummer as Regel, tms.Risiko, tmat.ausgabe_text einsatz_erlaeuterung,',
'listagg (distinct tl.b_nummer, '','') within group (order by tl.b_nummer asc) Laender, teg.vorschrift_nummer as Grundvorschrift, nvl(tmat.kritikalitaet, 0) as Kritikalitaet',
'  from t_MS_SUCHERGEBNISS tms',
'   join t_ms_parameter pm on (tms.MS_PARAMETERID =pm.MS_PARAMETERID)',
'  join cte_base_regela cbr on (tms.vorschriftid = cbr.vorschriftid and tms.MS_PARAMETERID =cbr.MS_PARAMETERID and tms.risiko = cbr.risiko and cbr.xrow =1)',
'  left outer join t_ms_parameter tmp on (tms.regelnummer = tmp.nummer)',
'  left outer join t_ms_parameter_ref_ausgabe tmpra on (tmp.MS_PARAMETERID = tmpra.MS_PARAMETERID)',
'  left outer join t_ms_ausgabe_text tmat on (tmpra.MS_AUSGABE_TEXTID = tmat.MS_AUSGABE_TEXTID)',
'  left outer join t_vorschrift tv on (tms.ALTERNATIVE_VORSCHRIFTID = tv.vorschriftid)',
'  left outer join t_land tl on (tms.landid = tl.landid)',
'  left outer join t_vorschrift teg on (NVL2(tms.ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid,null)= teg.vorschriftid)',
'  where sucheid = :P451_SUCHEID and meilenstein = :P451_MS  and pm.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE =:P451_NEGATIV',
'  group by nvl(tv.vorschrift_nummer,tms.Vorschriftnummer) ,',
'   nvl(ALTERNATIVE_VORSCHRIFTID,tms.vorschriftid) ',
'  ,  regelnummer ',
'  , tms.Risiko, tmat.ausgabe_text,teg.vorschrift_nummer , nvl(tmat.kritikalitaet, 0)',
')',
'',
'Select case when (t1.vorschriftnummer is null and :P451_DELTA = 1) then ''<span style="color:green">'' || tv.Vorschriftnummer ||''</span> ''  ',
'       when (tv.Vorschriftnummer is null and :P451_DELTA = 1) then ''<span style="color:orange">'' || t1.Vorschriftnummer ||''</span> '' ',
'        else nvl(t1.vorschriftnummer,tv.Vorschriftnummer) end as vorschriftnummer, ',
'    case when t1.vorschriftnummer is null then ''Neu'' when tv.Vorschriftnummer is null then ''entfallen'' else ''wegen Projektverschiebung'' end  as Delta,',
'    nvl(tv.vorschriftid, t1.vorschriftid) as vorschriftid, ',
'     tv.regel   as regel ,',
'     nvl(tv.Risiko,t1.Risiko) Risiko, tv.einsatz_erlaeuterung, tv.Laender, tv.Grundvorschrift, t1.einsatz_erlaeuterung text_alt,tv.kritikalitaet , t1.kritikalitaet as krit_alt',
'from cte2 tv',
'full outer join cte1 t1 on (tv.vorschriftnummer = t1.vorschriftnummer)',
'where :P451_DELTA = 0 or (:P451_DELTA = 1 and (( t1.vorschriftnummer is null or tv.Vorschriftnummer is null)',
'                                                           or (t1.regel is null or tv.regel is null or tv.regel != t1.regel))',
'                                )',
'*/'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Suche Short'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(78202639930072164)
,p_name=>'Suche Short'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>1190895577025206568
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(861374494695848216)
,p_db_column_name=>'VORSCHRIFTNUMMER'
,p_display_order=>10
,p_column_identifier=>'B'
,p_column_label=>'Vorschriftnummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(861374115741848211)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>'Vorschriftid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(861373666646848209)
,p_db_column_name=>'REGEL'
,p_display_order=>30
,p_column_identifier=>'D'
,p_column_label=>'Regel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(861373262375848209)
,p_db_column_name=>'RISIKO'
,p_display_order=>40
,p_column_identifier=>'E'
,p_column_label=>'Risiko'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(861372837957848206)
,p_db_column_name=>'EINSATZ_ERLAEUTERUNG'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>unistr('Einsatz Erl\00E4uterung')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(861372530812848206)
,p_db_column_name=>'LAENDER'
,p_display_order=>60
,p_column_identifier=>'H'
,p_column_label=>unistr('L\00E4nder')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(861372072658848204)
,p_db_column_name=>'GRUNDVORSCHRIFT'
,p_display_order=>70
,p_column_identifier=>'I'
,p_column_label=>'Grundvorschrift'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(861371712848848203)
,p_db_column_name=>'DELTA'
,p_display_order=>80
,p_column_identifier=>'J'
,p_column_label=>'Delta'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(417285505151019199)
,p_db_column_name=>'TEXT_ALT'
,p_display_order=>90
,p_column_identifier=>'K'
,p_column_label=>'Text aus vorherigem Meilenstein'
,p_column_type=>'STRING'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P451_DELTA'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(417285189902019196)
,p_db_column_name=>'KRITIKALITAET'
,p_display_order=>100
,p_column_identifier=>'L'
,p_column_label=>unistr('Kritikalit\00E4t')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(417285136898019195)
,p_db_column_name=>'KRIT_ALT'
,p_display_order=>110
,p_column_identifier=>'M'
,p_column_label=>'Krit Alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P451_DELTA'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1049957060855570634)
,p_db_column_name=>'REGEL_ALT'
,p_display_order=>120
,p_column_identifier=>'N'
,p_column_label=>'Regel Alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(78209066856115123)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'6882979'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'VORSCHRIFTNUMMER:VORSCHRIFTID:REGEL:RISIKO:EINSATZ_ERLAEUTERUNG:LAENDER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(861371007225848179)
,p_name=>'P451_SUCHEID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(78202502153072164)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(861370614596848174)
,p_name=>'P451_MS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(78202502153072164)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(861370146135848173)
,p_name=>'P451_DELTA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(78202502153072164)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1434771507387790102)
,p_name=>'P451_NEGATIV'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(78202502153072164)
,p_item_default=>'1'
,p_prompt=>'Anzeige'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'off_label', 'Negativ',
  'off_value', '0',
  'on_label', 'Positiv',
  'on_value', '1',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1434771780381790105)
,p_name=>'Change Refresh'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P451_NEGATIV'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(652675168406374003)
,p_event_id=>wwv_flow_imp.id(1434771780381790105)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P451_NEGATIV'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1434771911849790106)
,p_event_id=>wwv_flow_imp.id(1434771780381790105)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(78202502153072164)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
