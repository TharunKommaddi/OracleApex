prompt --application/pages/page_00582
begin
--   Manifest
--     PAGE: 00582
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>582
,p_name=>'COCOA-Ticket'
,p_alias=>'COCOA-TICKET'
,p_page_mode=>'MODAL'
,p_step_title=>'COCOA-Ticket'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_dialog_width=>'1000'
,p_dialog_chained=>'N'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17911314199711719733)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(637561291400734979)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17911314306243719733)
,p_plug_name=>'COCOA'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>50
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17911314441282719733)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1006061507474091923)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(17911314441282719733)
,p_button_name=>'BACK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1006061064772091923)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(17911314441282719733)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1006060626813091922)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(17911314441282719733)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'MfV Teil'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1006055146987091919)
,p_branch_name=>'Go To Page 570'
,p_branch_action=>'f?p=&APP_ID.:570:&SESSION.::&DEBUG.:574,571,570::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1006060626813091922)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1006054722793091919)
,p_branch_name=>'Go To Page 581'
,p_branch_action=>'f?p=&APP_ID.:581:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1006061507474091923)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006060277482091922)
,p_name=>'P582_AUSWAHL'
,p_item_sequence=>60
,p_item_default=>'none'
,p_prompt=>unistr('M\00F6chten Sie Daten aus einem COCOA-Ticket \00FCbertragen?')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Gefiltert;filtered,Alle Tickets;all,Nein;none'
,p_read_only_when=>'P581_IS_CLONE'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1006059824102091922)
,p_name=>'P582_COCOA'
,p_item_sequence=>70
,p_prompt=>'COCOA-TICKET'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_COCOA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH cte1 AS (',
'    SELECT ',
'        t.JIRA_ISSUE_KEY,',
'        x.*',
'    FROM t_x_cocoa_import t,',
'    JSON_TABLE(',
'        t.DATA_CLOB, ''$.fields''',
'        COLUMNS (',
'            full_description VARCHAR2(4000) PATH ''$.description'',',
'            summary VARCHAR2(4000) PATH ''$.summary'',',
'            issue_type_desc VARCHAR2(500) PATH ''$.issuetype.description'',',
'            cluster_value VARCHAR2(500) PATH ''$.customfield_53150[0].value''',
'        )',
'    ) x',
'    WHERE t.JIRA_GET_STATUS = 20',
'), ',
'cte2 AS (',
'    SELECT ',
'        JIRA_ISSUE_KEY,',
'        summary,',
'        issue_type_desc,',
'        cluster_value,',
'        CASE ',
'            WHEN full_description LIKE ''%[%|%]%'' THEN',
'                substr(',
'                    substr(full_description, instr(full_description,''['')+1, ',
'                           instr(full_description,'']'')-(instr(full_description,''['')+1)),',
'                    instr(',
'                        substr(full_description, instr(full_description,''['')+1, ',
'                               instr(full_description,'']'')-(instr(full_description,''['')+1)),',
'                        ''|''',
'                    )+1',
'                )',
'            ELSE NULL',
'        END as extracted_url',
'    FROM cte1',
'), ',
'cte3 AS (',
'    SELECT ',
'        jira_issue_key,',
'        summary,',
'        issue_type_desc,',
'        cluster_value,',
'        CASE ',
'            WHEN extracted_url IS NOT NULL AND INSTR(extracted_url, ''/revision/'') > 0 THEN',
'                substr(extracted_url, 0, instr(extracted_url,''/revision/''))',
'            ELSE NULL',
'        END as getex_link_jira',
'    FROM cte2',
'),',
'cte4 AS (',
'    SELECT ',
'        t3.jira_issue_key,',
'        t3.summary,',
'        t3.issue_type_desc,',
'        t3.cluster_value,',
'        t3.getex_link_jira,',
'        CASE WHEN tv.url_getex_vorschrift IS NOT NULL THEN 1 ELSE NULL END as is_linked',
'    FROM cte3 t3',
'    LEFT JOIN t_vorschrift tv ON (',
'        tv.url_getex_vorschrift = t3.getex_link_jira ',
'        AND tv.vorschriftid = :P25_VORSCHRIFTID',
'    )',
')',
'SELECT ',
'    c4.jira_issue_key as d,',
'    c4.summary as d2,',
'    NVL(c4.issue_type_desc, ''No Issue Type'') as d3,',
'    NVL(c4.cluster_value, ''No Cluster'') as d4,',
'    c4.jira_issue_key as r',
'FROM cte4 c4',
'WHERE ',
'    :P582_AUSWAHL = ''all'' ',
'    OR (:P582_AUSWAHL = ''filtered'' AND c4.is_linked = 1)',
'ORDER BY ',
'    c4.is_linked DESC NULLS LAST,',
'    c4.jira_issue_key;'))
,p_lov_cascade_parent_items=>'P582_AUSWAHL'
,p_ajax_items_to_submit=>'P582_AUSWAHL'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_read_only_when=>'P581_IS_CLONE'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'Y',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(918674506795304034)
,p_name=>'P582_INFO'
,p_item_sequence=>80
,p_item_default=>'Bitte nur Ticketnummer eingeben (z. B.: VKO-1234), keine Links.'
,p_prompt=>'&nbsp;'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(916342312160945402)
,p_name=>'P582_CLONE_INFO'
,p_item_sequence=>90
,p_prompt=>'Clone Info'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT emano_util.fLang(',
unistr('    ''Im Klonmodus wird das COCOA-Ticket automatisch aus dem Quellticket \00FCbernommen.'','),
'    ''In clone mode, the COCOA ticket is automatically taken from the source ticket.''',
') as lang',
'FROM dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P581_IS_CLONE'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1006059470691091921)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1006061064772091923)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006059002665091921)
,p_event_id=>wwv_flow_imp.id(1006059470691091921)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1006058566903091921)
,p_name=>'Change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P582_AUSWAHL'
,p_condition_element=>'P582_AUSWAHL'
,p_triggering_condition_type=>'IN_LIST'
,p_triggering_expression=>'filtered,all'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006058085935091920)
,p_event_id=>wwv_flow_imp.id(1006058566903091921)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P582_COCOA'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// $s(''P582_MFVS'',null)',
'$s(''P582_COCOA'',null)'))
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006057561944091920)
,p_event_id=>wwv_flow_imp.id(1006058566903091921)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P582_COCOA'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// $s(''P582_MFVS'',null)',
'$s(''P582_COCOA'',null)'))
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006057093994091920)
,p_event_id=>wwv_flow_imp.id(1006058566903091921)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P582_COCOA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006056549070091920)
,p_event_id=>wwv_flow_imp.id(1006058566903091921)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P582_COCOA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1006056158868091919)
,p_name=>'New'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P582_COCOA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1006055631688091919)
,p_event_id=>wwv_flow_imp.id(1006056158868091919)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P571_AK_SEL := null;'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
