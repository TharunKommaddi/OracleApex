prompt --application/pages/page_00103
begin
--   Manifest
--     PAGE: 00103
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>103
,p_name=>unistr('Vorschriften L\00E4nder Zuordnung')
,p_alias=>unistr('VORSCHRIFTEN-L\00C4NDER-ZUORDNUNG')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Vorschriften L\00E4nder Zuordnung')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function loadLaenderShuttle() {',
'    var shuttleName = ''P103_LAENDER'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadLaenderShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P103_LAENDER_GRUPPE''),',
'          x03: $v(''P103_FILTER_BLAND_PRE'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'',
'function addItemToShuttle(aShuttle, aID, aDisplay) {',
'    var lLeft = $(''#'' + aShuttle + ''_LEFT'');',
'    var lRight = $(''#'' + aShuttle + ''_RIGHT'');',
'    lLeft.find(''option[value='' + aID + '']'').remove();',
'    lRight.append(''<option value="'' + aID + ''">'' + aDisplay + ''</option>'');',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Text-Item muss da sein, da sonst Submit bei Enter im Vorfilter-Feld',
'$(''#P103_TEXTFIELD'').closest(''div.row'').hide();',
'if(apex.item("P103_LANDID").isEmpty())',
'{',
'    $x_Hide(''P103_BEMERKUNG'');',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_dialog_width=>'1200'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2691959457656612943)
,p_plug_name=>'LAENDER_ITEMS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2691960500712612953)
,p_plug_name=>'Button_Footer'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1063773903122319804)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2691960500712612953)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1063774332200319805)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2691960500712612953)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P103_OPEN_TO_DELETE'
,p_button_condition_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1063773476084319804)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2691960500712612953)
,p_button_name=>'DELETE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P103_OPEN_TO_DELETE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1063763319461319765)
,p_branch_name=>'parent_page_submit'
,p_branch_action=>'javascript:parent.apex.submit()'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'REQUEST_IN_CONDITION'
,p_branch_condition=>'SAVE,DELETE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1063836212456809897)
,p_name=>'P103_LAENDER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(2691959457656612943)
,p_prompt=>'&nbsp;'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* select  -- b_nummer || '' - '' || land, ',
'landid from',
' t_land where landid in',
'    (Select distinct landid from t_vorschrift_ref_land',
'         where vorschriftid = :P103_VORSCHRIFTID  and geloescht = 0 );',
'*/',
'    select landid ',
'      from (Select distinct vrl.landid, la.B_nummer ',
'              from t_vorschrift_ref_land vrl',
'              join t_land la on (la.landid = vrl.landid)',
'             where vrl.vorschriftid = :P103_VORSCHRIFTID  and vrl.geloescht = 0',
'             order by NLSSORT(la.B_Nummer, ''NLS_SORT=BINARY_AI'')',
'                     );'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select b_nummer || '' - '' || land, landid ',
'from t_land',
' --where landid not in (Select Landid from  t_vorschrift_ref_land where vorschriftid= :P103_VORSCHRIFTID and geloescht !=1)',
'order by NLSSORT(B_Nummer, ''NLS_SORT=BINARY_AI'')',
'      '))
,p_cHeight=>5
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'( ((:P103_LAND_READ_ONLY = 0 or :P103_LAND_READ_ONLY is null) or (:P103_LAND_READ_ONLY = 1 and :P103_LAENDER is not null) )',
'',
' and ( :P103_LANDID is NULL and :P103_EDIT_LAENDER =1)',
')',
'or',
'(:P103_NEW_CREATE = 1 and :P103_EDIT_LAENDER = 1) '))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_read_only_when=>'P103_LAND_READ_ONLY'
,p_read_only_when2=>'0'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1063834172129809877)
,p_name=>'P103_FILTER_BLAND_PRE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(2691959457656612943)
,p_prompt=>unistr('Vorfilter L\00E4nder')
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<button type="button" class="a-Button" style="height: 24px; padding: 4px; border-radius: 0 2px 2px 0;" onclick="loadLaenderShuttle()"><span class="fa fa-search"></span></button>',
''))
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_begin_on_new_line=>'N'
,p_grid_column=>7
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'( ((:P103_LAND_READ_ONLY = 0 or :P103_LAND_READ_ONLY is null) or (:P103_LAND_READ_ONLY = 1 and :P103_LAENDER is not null) )',
'',
'  and ( :P103_LANDID is NULL and :P103_EDIT_LAENDER =1)',
')',
'or',
'(:P103_NEW_CREATE = 1 and :P103_EDIT_LAENDER = 1) '))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1063833871601809874)
,p_name=>'P103_TEXTFIELD'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(2691959457656612943)
,p_prompt=>'Textfield'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1063781327494319824)
,p_name=>'P103_VORSCHRIFTID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2691959457656612943)
,p_prompt=>'Vorschrift'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select Vorschrift_nummer ||'' - ''||VORSCHRIFT_BEZEICHNUNG, vorschriftid',
'from T_vorschrift'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1063780633485319820)
,p_name=>'P103_LANDID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2691959457656612943)
,p_prompt=>'Land'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select land ||'' (''|| B_Nummer ||'')'',landid ',
'from t_land order by land'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'( (:P103_NEW_CREATE is null or :P103_NEW_CREATE = 0 or :P103_OPEN_TO_DELETE is not null)) ',
'or ',
'( :P103_NEW_CREATE = 1 and (:P103_LAND_READ_ONLY = 0)',
' )',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'NOT( :P103_NEW_CREATE = 1 and (:P103_LAND_READ_ONLY = 1 or :P103_LANDID is null )) ',
'or :P103_OPEN_TO_DELETE is not null'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1063779771111319820)
,p_name=>'P103_LAND_READ_ONLY'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2691959457656612943)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1063779394175319820)
,p_name=>'P103_BEMERKUNG'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2691959457656612943)
,p_prompt=>'Bemerkung'
,p_source=>'select bemerkung from t_vorschrift_ref_land where vorschriftid = :P103_VORSCHRIFTID AND :P103_LANDID is not null and LANDid = :P103_LANDID;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>3
,p_read_only_when=>'P103_OPEN_TO_DELETE'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1063778948451319819)
,p_name=>'P103_LAENDER_GRUPPE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(2691959457656612943)
,p_prompt=>unistr('L\00E4nder Gruppe')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select laendergruppe, laendergruppeid',
'from t_laendergruppe where laendergruppeid != 1220',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-alle-'
,p_cHeight=>5
,p_colspan=>6
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'( ((:P103_LAND_READ_ONLY = 0 or :P103_LAND_READ_ONLY is null) or (:P103_LAND_READ_ONLY = 1 and :P103_LAENDER is not null) )',
'',
'   and ( :P103_LANDID is NULL and :P103_EDIT_LAENDER =1)',
')',
'or',
'(:P103_NEW_CREATE = 1 and :P103_EDIT_LAENDER = 1) '))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1063776628795319816)
,p_name=>'P103_NEW_CREATE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(2691959457656612943)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1063775401121319816)
,p_name=>'P103_OPEN_TO_DELETE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(2691959457656612943)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1061582674213444891)
,p_name=>'P103_EDIT_LAENDER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(2691959457656612943)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(640009379539644300)
,p_name=>'P103_LAND_COUNT'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(2691959457656612943)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN COUNT(DISTINCT tl.LANDID) = 1 ',
'             AND MAX(tl.SUMS_RELEVANT) = 10 ',
'             AND MAX(tv.RXSWIN) = 10 ',
'             ',
'        THEN ''1''',
'        ELSE ''0''',
'    END AS result',
'FROM t_vorschrift tv',
'LEFT OUTER JOIN t_vorschrift_ref_land tvrl ON (tv.vorschriftid = tvrl.vorschriftid)',
'LEFT OUTER JOIN t_land tl ON (tvrl.landid = tl.landid)',
'WHERE tv.vorschriftid = :P103_VORSCHRIFTID and geloescht != 1',
'GROUP BY tv.vorschriftid'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT COUNT(DISTINCT tl.LANDID) AS land_count',
'FROM t_vorschrift tv',
'LEFT OUTER JOIN t_vorschrift_ref_land tvrl ON (tv.vorschriftid = tvrl.vorschriftid)',
'LEFT OUTER JOIN t_land tl ON (tvrl.landid = tl.landid)',
'LEFT JOIN t_benutzer tb ON (tv.letzte_aenderung_benutzerid = tb.benutzerid)',
'-- and tl.SUMS_RELEVANT = 10 and tv.RXSWIN = 10;',
'WHERE tv.vorschriftid = :P103_VORSCHRIFTID and geloescht != 1;'))
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1063836039758809896)
,p_validation_name=>'Land_valid'
,p_validation_sequence=>40
,p_validation=>'P103_LAENDER'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Bitte w\00E4hlen Sie ein Land aus')
,p_validation_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P103_LANDID is null and (:P103_NEW_CREATE is null or :P103_NEW_CREATE= 0)',
')',
'or',
'(:P103_NEW_CREATE = 1 and :P103_EDIT_LAENDER = 1)'))
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(1063774332200319805)
,p_associated_item=>wwv_flow_imp.id(1063836212456809897)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1063766557249319769)
,p_name=>'Cancel'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1063773903122319804)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1063766093354319768)
,p_event_id=>wwv_flow_imp.id(1063766557249319769)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1063767508033319771)
,p_name=>unistr('change L\00E4ndergruppe')
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P103_LAENDER_GRUPPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1063767026186319769)
,p_event_id=>wwv_flow_imp.id(1063767508033319771)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'loadLaenderShuttle();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1063834074710809876)
,p_name=>'enter in filterfeld'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P103_FILTER_BLAND_PRE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1063834030600809875)
,p_event_id=>wwv_flow_imp.id(1063834074710809876)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(641414226789456581)
,p_name=>'Alert'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1063773476084319804)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(641414120550456580)
,p_event_id=>wwv_flow_imp.id(641414226789456581)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>unistr('Die L\00F6schung k\00F6nnte dazu f\00FChren, dass einige Vorschriften f\00FCr die Potentiell SUMS-relevante Position auf "nicht relevant" gesetzt werden!')
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>'$v("P103_LAND_COUNT") === "1"'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(641413957434456579)
,p_event_id=>wwv_flow_imp.id(641414226789456581)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--debug(''Seite 103 :P103_LAND '', :P103_LANDID );',
'--debug(''Seite 103 :P103_LAND_READ_ONLY '', :P103_LAND_READ_ONLY );',
'--debug(''Seite 103 :P103_OPEN_TO_DELETE '', :P103_OPEN_TO_DELETE);',
'',
unistr('--L\00F6schen '),
'declare ',
'l_getex_key varchar2(64);',
'begin',
'   ',
'--if (  (:P103_LAND_READ_ONLY is null or :P103_LAND_READ_ONLY =0 ))',
'   --     then ',
unistr('  --debug(''Seite 103 Delete '',''Land l\00F6schen'' );    '),
'    update  t_vorschrift_ref_land  set geloescht =1 where vorschriftid = :P103_VORSCHRIFTID AND LANDID = :P103_LANDID;',
'    select  regindexid into l_getex_key from t_vorschrift where vorschriftid = :P103_VORSCHRIFTID;',
' ',
'    --  delete  changes the list of countries',
'    update T_VORSCHRIFT SET   letzte_aenderung_getex_attr = sysdate where VORSCHRIFTID = :P103_VORSCHRIFTID;',
'     --  pck_ri_history.pInsertVorschriftLandRelationkeinThema(:P103_VORSCHRIFTID,:P103_LANDID,:P103_BEMERKUNG,1);',
'--end if;',
'end;'))
,p_attribute_02=>'P103_VORSCHRIFTID,P103_LANDID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(641413829845456577)
,p_event_id=>wwv_flow_imp.id(641414226789456581)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(826730140234794355)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Check_Aender_Getex_attribut'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if( 0 < PCK_RI_GETEX_COMPARE.fIsLandListChanged(:P103_VORSCHRIFTID, :P103_LAENDER)) then',
'    update T_VORSCHRIFT SET   letzte_aenderung_getex_attr = sysdate where VORSCHRIFTID = :P103_VORSCHRIFTID;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2845482175664593880
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1063769865387319775)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--debug(''Seite 103 :P103_LandID '',:P103_LANDID );',
'--debug(''Seite 103 :P103_LAENDER '',:P103_LAENDER );',
'--debug(''Seite 103 :P103_LAND_READ_ONLY:'',:P103_LAND_READ_ONLY);',
'--debug(''Seite 103 :P103_EDIT_LAENDER:'',:P103_EDIT_LAENDER);',
'--debug(''Seite 103 :P103_NEW_CREATE:'', :P103_NEW_CREATE);',
'',
'-- Afruf mit allem Bearbeiten',
'if ( :P103_EDIT_LAENDER = 1 )',
'then',
' --debug(''Seite 103'',''Aufruf Massenbearbeitung'');',
unistr(' -- merge l\00E4nder into vorschrift_ref_land'),
'     UPDATE  t_vorschrift_ref_land set geloescht=0, bemerkung= :P103_BEMERKUNG',
'      where vorschriftID = :P103_VORSCHRIFTID ',
'        and geloescht =1',
'        and landid  in (select column_value from table(apex_string.split_numbers(:P103_LAENDER, '':'')));',
'        ',
'    MERGE into t_vorschrift_ref_land dest',
'       USING ( select :P103_VORSCHRIFTID as vorschriftID, column_value as landid from table (apex_string.split_numbers(:P103_LAENDER, '':''))) src',
'       on (src.vorschriftID = dest.vorschriftID ',
'           and src.landid = dest.landid)',
'      WHEN NOT MATCHED THEN',
'       insert (vorschriftID, landid, geloescht, bemerkung)',
'       values (src.vorschriftID, src.landid, 0, :P103_BEMERKUNG);',
'     ',
unistr('     -- nicht l\00F6schen  nur flag setzen'),
'     UPDATE  t_vorschrift_ref_land set geloescht=1',
'      where vorschriftID = :P103_VORSCHRIFTID',
'        and landid not in (select column_value from table(apex_string.split_numbers(:P103_LAENDER, '':'')));',
'        ',
'     PCK_RI_BENACHRICHTIGUNG.pBenachricht_Mfv_Arbeitskreise( :P103_VORSCHRIFTID, ''Laender'', :G_BENUTZERID );',
'',
'else ',
unistr('-- //!AB nur ein land bearbeiten  z. B. Kommentar      Neues hinzuf\00FCgen'),
'         --debug(''Seite 103'',''nur ein land'');',
'         update t_vorschrift_ref_land set bemerkung = :P103_BEMERKUNG',
'          where vorschriftID = :P103_VORSCHRIFTID  and geloescht =0',
'            and landid = :P103_LANDID;',
'end if;',
'',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1063774332200319805)
,p_internal_uid=>2608442450512068460
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1063768712653319773)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DELETE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--debug(''Seite 103 :P103_LAND '', :P103_LANDID );',
'--debug(''Seite 103 :P103_LAND_READ_ONLY '', :P103_LAND_READ_ONLY );',
'--debug(''Seite 103 :P103_OPEN_TO_DELETE '', :P103_OPEN_TO_DELETE);',
'',
unistr('--L\00F6schen '),
'declare ',
'l_getex_key varchar2(64);',
'begin',
'   ',
'--if (  (:P103_LAND_READ_ONLY is null or :P103_LAND_READ_ONLY =0 ))',
'   --     then ',
unistr('  --debug(''Seite 103 Delete '',''Land l\00F6schen'' );    '),
'    update  t_vorschrift_ref_land  set geloescht =1 where vorschriftid = :P103_VORSCHRIFTID AND LANDID = :P103_LANDID;',
'    select  regindexid into l_getex_key from t_vorschrift where vorschriftid = :P103_VORSCHRIFTID;',
'  --  if( 0 < pck_ri_getex.fcheckDiffGetexVorschriftEinsatzDaten(l_getex_key, :P103_VORSCHRIFTID) ) then ',
'   --    update t_vorschrift set status_update_getex =20 where vorschriftid = :P103_VORSCHRIFTID;',
'  --  end if;',
'    --  delete  changes the list of countries',
'    update T_VORSCHRIFT SET   letzte_aenderung_getex_attr = sysdate where VORSCHRIFTID = :P103_VORSCHRIFTID;',
'     --  pck_ri_history.pInsertVorschriftLandRelationkeinThema(:P103_VORSCHRIFTID,:P103_LANDID,:P103_BEMERKUNG,1);',
'--end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1063773476084319804)
,p_process_when_type=>'NEVER'
,p_process_success_message=>'sfasdf'
,p_internal_uid=>2608443603246068462
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1063771536594319778)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Letzte Aenderung Datum setzen, Reset VI'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_vorschrift',
'set letzte_aenderung_datum = sysdate',
'where vorschriftid = :P103_VORSCHRIFTID;',
'-- UserID wird durch Trigger automatisch gesetzt',
'',
'pck_ri.pResetVI(:P103_VORSCHRIFTID);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2608440779305068457
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1016890460272243332)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Recalculate Cockpit and GETEX Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P103_VORSCHRIFTID IS NOT NULL THEN',
'        PCK_RI_GETEX_CTRL.pRecalculateGetexAndCockpitData(:P103_VORSCHRIFTID);',
'    END IF;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_debug.error(''Recalculation error: '' || SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE, DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2655321855627144903
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1063770267681319775)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'refresh cockpit'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri_cockpit_refresh.pTriggerRefresh;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2608442048218068460
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1063769500060319774)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1063774332200319805)
,p_internal_uid=>2608442815839068461
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1063768294089319773)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLaenderShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lLaendergruppe number := apex_application.g_x02;',
'    lTextfilter varchar2(2000) := apex_application.g_x03;',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    for l in (',
'        select b_nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'        ELSE land_eng',
'    END as d, landid',
'        from t_land',
'        where landid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))        ',
'        and ( lLaendergruppe is null',
'               or landid in (',
'                 select landid from t_land_ref_laendergruppe where laendergruppeid in (',
'                    select column_value from table(apex_string.split_numbers(lLaendergruppe,'':''))',
'                )',
'            )',
'        )',
'        and ( lTextfilter is null',
'            or instr(upper(b_nummer),upper(lTextFilter)) != 0',
'            or instr(upper(land),upper(lTextFilter)) != 0',
'        )',
'        and landid not in (select landid from t_vorschrift_ref_land where vorschriftid = :P103_VORSCHRIFTID and geloescht !=1)',
'        order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'')        ',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.landid);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2608444021810068462
);
wwv_flow_imp.component_end;
end;
/
