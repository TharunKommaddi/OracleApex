prompt --application/pages/page_00357
begin
--   Manifest
--     PAGE: 00357
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>357
,p_name=>'Historie Thema'
,p_alias=>'HISTORIE-THEMA'
,p_page_mode=>'MODAL'
,p_step_title=>'Historie Thema'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IR_HIST .t-fht-tbody {max-height: calc(100vh - 200px)}',
'.t-Body-topButton {display: none !important}',
'.t-Body-content {padding-bottom: 3px !important}',
'.t-Body {margin-bottom: 3px !important}',
'.t-Body-contentInner {padding-bottom: 0px !important}'))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_page_comment=>'a'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(837146824273650659)
,p_plug_name=>'Historie Thema'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ctl_b_nummern as (',
'    select vorschriftid, listagg(nummer||''-''||BEZEICHNUNG, '', '') within group (order by nummer) as t_nummer',
'    from (',
'        select distinct tvrt.vorschriftid,',
'        t.nummer,',
'        CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN t.bezeichnung',
'        ELSE t.name_eng',
'    END as BEZEICHNUNG',
'       from T_VORSCHRIFT_REF_THEMA tvrt ',
'        join t_thema t on t.themaid = tvrt.themaid',
'        where tvrt.geloescht = 0)',
'    group by vorschriftid',
')',
'select vrt.rowid as xrowid,',
'       vrt.letzte_aenderung_datum,',
'    -- b.nachname || '', '' || b.vorname as user_name,',
'     nvl2(vrt.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) AS letzte_AENDERUNG_BENUTZER,',
'    vrt.VORSCHRIFTID,',
'    cbn.t_nummer,',
'    vrt.bemerkung as Kommentar,',
'    vrt.AKTION',
'from T_H_VORSCHRIFT_REF_THEMA vrt',
'left outer join v_thema_baum vt on (vrt.themaid = vt.themaid)',
'left outer join t_benutzer b on b.benutzerid = vrt.letzte_aenderung_benutzerid',
'left outer join ctl_b_nummern cbn on vrt.VORSCHRIFTID = cbn.VORSCHRIFTID',
'order by 1;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'NEVER'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Historie Thema'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(837146644650650658)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>unistr('Es gibt keine historischen Verkn\00FCpfungen f\00FCr diese Vorschrift.')
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'mailto:#EMAIL#?body=#PERMALINK#'
,p_detail_link_text=>'<span class="fa fa-envelope-o" aria-hidden="true"></span></a>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>275546292444483746
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(837146564971650657)
,p_db_column_name=>'XROWID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Xrowid'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(837146475713650656)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('\00C4nderung Datum')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(837146425865650655)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Vorschriftid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(837146273921650654)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Aenderung Benutzer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(834281127643992803)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(834281033456992802)
,p_db_column_name=>'T_NUMMER'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'T Nummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(834280919817992801)
,p_db_column_name=>'AKTION'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Aktion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(200374047590647395)
,p_plug_name=>'Historie Thema'
,p_region_name=>'IR_HIST'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'      to_char(vrt.letzte_aenderung_datum, ''dd.mm.yyyy HH24:mi:ss'') as letzte_aenderung_datum,',
'    -- b.nachname || '', '' || b.vorname as user_name,',
'     nvl2(vrt.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) AS letzte_AENDERUNG_BENUTZER,',
'    vrt.VORSCHRIFTID,',
'    -- tv.vorschrift_nummer,',
'    --pck_ri_history.fdiff(tv.vorschrift_nummer, LAG(tv.vorschrift_nummer) over(partition by vrt.VORSCHRIFTID, tv.vorschrift_nummer order by vrt.letzte_aenderung_datum asc), aktion) as vorschrift_nummer,',
'    --cbn.t_nummer,',
'    listagg(vt.nummer||''-''||vt.BEZEICHNUNG, '', '' ON OVERFLOW TRUNCATE) within group (order by nummer) as t_nummer,',
'    --pck_ri_history.fdiff( vrt.bemerkung, LAG(vrt.bemerkung) over(partition by vrt.VORSCHRIFTID, tv.vorschrift_nummer order by vrt.letzte_aenderung_datum asc)) as KOMMENTAR,',
'    vrt.bemerkung, vrt.AKTION, decode(geloescht, 1, ''ja'', 0, ''Nein'', 0) as geloescht',
'from T_H_VORSCHRIFT_REF_THEMA vrt',
'left outer join v_thema_baum vt on (vrt.themaid = vt.themaid)',
'left outer join t_benutzer b on b.benutzerid = vrt.letzte_aenderung_benutzerid',
'left outer join t_vorschrift tv on (tv.vorschriftid = vrt.VORSCHRIFTID)',
'--left outer join ctl_b_nummern cbn on vrt.VORSCHRIFTID = cbn.VORSCHRIFTID',
'where vrt.VORSCHRIFTID = :P357_VORSCHRIFTID',
' group by vrt.VORSCHRIFTID, vrt.LETZTE_AENDERUNG_DATUM,',
' nvl2(vrt.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null),',
' vrt.bemerkung, vrt.AKTION, decode(geloescht, 1, ''ja'', 0, ''Nein'', 0) ',
'order by vrt.LETZTE_AENDERUNG_DATUM desc',
'',
'/*with ctl_b_nummern as (',
'    select vorschriftid, listagg(nummer||''-''||BEZEICHNUNG, '', '' ON OVERFLOW TRUNCATE) within group (order by nummer) as t_nummer',
'    from (',
'        select distinct tvrt.vorschriftid,',
'        t.nummer,',
'        CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN t.bezeichnung',
'        ELSE t.name_eng',
'    END as BEZEICHNUNG',
'       from T_VORSCHRIFT_REF_THEMA tvrt ',
'        join t_thema t on t.themaid = tvrt.themaid',
'        where tvrt.geloescht = 0)',
'    group by vorschriftid',
')',
'select',
'       vrt.letzte_aenderung_datum,',
'    -- b.nachname || '', '' || b.vorname as user_name,',
'     nvl2(vrt.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) AS letzte_AENDERUNG_BENUTZER,',
'    vrt.VORSCHRIFTID,',
'    -- tv.vorschrift_nummer,',
'    pck_ri_history.fdiff(tv.vorschrift_nummer, LAG(tv.vorschrift_nummer) over(partition by vrt.VORSCHRIFTID, tv.vorschrift_nummer order by vrt.letzte_aenderung_datum asc), aktion) as vorschrift_nummer,',
'    cbn.t_nummer,',
'    pck_ri_history.fdiff( vrt.bemerkung, LAG(vrt.bemerkung) over(partition by vrt.VORSCHRIFTID, tv.vorschrift_nummer order by vrt.letzte_aenderung_datum asc)) as KOMMENTAR,',
'    vrt.AKTION',
'from T_H_VORSCHRIFT_REF_THEMA vrt',
'left outer join v_thema_baum vt on (vrt.themaid = vt.themaid)',
'left outer join t_benutzer b on b.benutzerid = vrt.letzte_aenderung_benutzerid',
'left outer join t_vorschrift tv on (tv.vorschriftid = vrt.VORSCHRIFTID)',
'left outer join ctl_b_nummern cbn on vrt.VORSCHRIFTID = cbn.VORSCHRIFTID',
'where vrt.VORSCHRIFTID = :P356_VORSCHRIFTID',
'order by vrt.LETZTE_AENDERUNG_DATUM desc */'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P357_VORSCHRIFTID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Historie Thema'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(200373971053647395)
,p_name=>'Historie Vorschrift Kerndaten'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>unistr('Es gibt keine historischen Verkn\00FCpfungen f\00FCr diese Vorschrift.')
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'mailto:#EMAIL#?body=#PERMALINK#'
,p_detail_link_text=>'<span class="fa fa-envelope-o" aria-hidden="true"></span></a>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>912318966041487009
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(669153241387068777)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>10
,p_column_identifier=>'BZ'
,p_column_label=>unistr('\00C4nderung Datum')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(834383443154156063)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>20
,p_column_identifier=>'BO'
,p_column_label=>'Vorschriftid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(834382665681156062)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>30
,p_column_identifier=>'BS'
,p_column_label=>unistr('\00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(837147100719650662)
,p_db_column_name=>'T_NUMMER'
,p_display_order=>40
,p_column_identifier=>'BU'
,p_column_label=>'Thema'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(837146968632650661)
,p_db_column_name=>'AKTION'
,p_display_order=>50
,p_column_identifier=>'BV'
,p_column_label=>'Aktion'
,p_column_html_expression=>'<span class="fa #AKTION#" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(958145941627486314)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(130351694252775274)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>60
,p_column_identifier=>'BX'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(130351608608775273)
,p_db_column_name=>'GELOESCHT'
,p_display_order=>70
,p_column_identifier=>'BY'
,p_column_label=>unistr('Gel\00F6scht')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(200355796699634222)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'964101'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LETZTE_AENDERUNG_BENUTZER:AKTION:T_NUMMER:GELOESCHT:BEMERKUNG'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(834381207047156059)
,p_name=>'P357_VORSCHRIFTID'
,p_item_sequence=>10
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(834380787152156056)
,p_name=>'P357_VORSCHRIFTNUMMER'
,p_item_sequence=>20
,p_use_cache_before_default=>'NO'
,p_source=>'select VORSCHRIFT_NUMMER from t_vorschrift where VORSCHRIFTID= :P357_VORSCHRIFTID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
