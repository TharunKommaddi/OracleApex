prompt --application/pages/page_00341
begin
--   Manifest
--     PAGE: 00341
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>341
,p_name=>'Funktionen'
,p_alias=>'FUNKTIONEN'
,p_step_title=>'Funktionen'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function treeFind ( pTree$, pSearchString, pClassName ) {',
'    // find the string in tree nodes',
'    var lMatchedNodes$ = pTree$.treeView( "find", {',
'        depth: -1,',
'        findAll: true,',
'        match: function( n ) {',
'            return n.label.toLowerCase().indexOf( pSearchString.toLowerCase() ) >= 0;',
'        }',
'    } );',
'    // add CSS class to matching nodes',
'    lMatchedNodes$.addClass( pClassName );',
'',
'    // find is used in conjunction with server side filtering',
'    // so when there are matching nodes, we just expand all nodes, so users can see matched nodes easily',
'    if ( lMatchedNodes$.length > 0 ) {',
'        pTree$.treeView( "expandAll" );',
'    }',
'}',
'    ',
'function treeSearch  ( pSearchString, pStaticId, pClassName ) {',
'    // remove CSS classes from previous search, if any',
'    apex.jQuery( "." + apex.util.escapeCSS( pClassName ), "#" + apex.util.escapeCSS( pStaticId )).removeClass( pClassName );',
'    if ( pSearchString !== "" ) {',
'        treeFind( apex.region( pStaticId ).widget(), pSearchString, pClassName );',
'    }',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.a-TreeView-label'').each(function() {',
'    $(this).html($(this).text());',
'});'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(845321496376449700)
,p_plug_name=>'Funktionen (System42)Funktionen (System42) <span onclick="redirect(361)" class="fa fa-question-square-o"></span>'
,p_region_name=>'func_tree_id'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with  cte_u_rolle as ( select  count(*) as anzahl from t_benutzer_ref_rolle',
'                       where benutzerid=:G_BENUTZERID and rolleid in (1003, 1002, 1006)',
')',
'',
'select distinct funktionid, parentid,  --''<span style="color:red">'' || ',
'regexp_replace( to_char(id_aus_excel)||''-''||bezeichnung   , ''('' || :P341_TEXTSUCHE || '')'',''<span style="background-color:yellow">\1</span>'', 1, 0, ''i'') ',
'|| decode(status, emano_util.fLang(''veraltet'', ''outdated''), emano_util.fLang('' - - - veraltet'', '' - - - outdated''),',
'    emano_util.fLang(''entfallen'', ''discontinued''), emano_util.fLang('' - - - entfallen'', '' - - - discontinued''),',
'    emano_util.fLang(''in Bearbeitung'', ''in progress''), emano_util.fLang('' - - - in Bearbeitung'', '' - - - in progress''), '' '')',
'-- || ''</span>'' ',
'',
' as c_bezeichnung,',
' case when cte_u_rolle.anzahl >0 then',
'    apex_page.get_url(p_page => 345, p_items => ''P345_ROWID'', p_values => f.rowid)',
'    else null end',
'     as link ',
'from t_funktion f, cte_u_rolle',
'where :P341_TEXTSUCHE is not null',
'connect by funktionid = prior parentid',
'start with upper(to_char(id_aus_excel)||'' ''||bezeichnung) like ''%'' || upper(:P341_TEXTSUCHE) || ''%'' ',
'',
'union all',
'',
'select funktionid, parentid,  -- ''<span style="color:red">'' ||',
'to_char(id_aus_excel) ||'' '' || bezeichnung || decode(status, emano_util.fLang(''veraltet'', ''outdated''), emano_util.fLang('' - - - veraltet'', '' - - - outdated''),',
'    emano_util.fLang(''entfallen'', ''discontinued''), emano_util.fLang('' - - - entfallen'', '' - - - discontinued''),',
'    emano_util.fLang(''in Bearbeitung'', ''in progress''), emano_util.fLang('' - - - in Bearbeitung'', '' - - - in progress''), '' '')',
'--|| ''<span>'' ',
'as c_bezeichnung, ',
'case when cte_u_rolle.anzahl >0 then ',
'  apex_page.get_url(p_page => 345, p_items => ''P345_ROWID'', p_values => fu.rowid)',
'  else null end',
'    as link',
'from t_funktion fu, cte_u_rolle',
'where :P341_TEXTSUCHE is null',
'',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_JSTREE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'activate_node_link_with', 'S',
  'default_icon_css_class', 'fa-search',
  'icon_type_css_class', 'fa',
  'link_column', 'LINK',
  'node_id_column', 'FUNKTIONID',
  'node_label_column', 'C_BEZEICHNUNG',
  'parent_key_column', 'PARENTID',
  'start_tree_with', 'NULL',
  'tree_hierarchy', 'SQL',
  'tree_tooltip', 'N')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(696644511460772702)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(845321496376449700)
,p_button_name=>'SEARCH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Suchen'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'N'
,p_grid_column_span=>1
,p_grid_column=>5
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(494698701478206802)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(845321496376449700)
,p_button_name=>'EXPAND'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Alle aufklappen'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_column_span=>2
,p_grid_column=>6
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(842895982163854972)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(845321496376449700)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:345:&SESSION.::&DEBUG.:345::'
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(696644225870772699)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(845321496376449700)
,p_button_name=>'LISTENANSICHT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Zur Listenansicht wechseln'
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:340:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(696644605637772703)
,p_name=>'P341_TEXTSUCHE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(845321496376449700)
,p_prompt=>'Textsuche'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>4
,p_grid_column=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'Y',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(696644357307772701)
,p_name=>'Expand tree'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_display_when_cond=>'P341_TEXTSUCHE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(696644322404772700)
,p_event_id=>wwv_flow_imp.id(696644357307772701)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(845321496376449700)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(628095323477742890)
,p_name=>'search entered'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P341_TEXTSUCHE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which === 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(628095146155742889)
,p_event_id=>wwv_flow_imp.id(628095323477742890)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(845321496376449700)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(494698616041206801)
,p_name=>'Aufklappen'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(494698701478206802)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(494698487873206800)
,p_event_id=>wwv_flow_imp.id(494698616041206801)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(845321496376449700)
);
wwv_flow_imp.component_end;
end;
/
