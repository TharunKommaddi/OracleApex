prompt --application/pages/page_00430
begin
--   Manifest
--     PAGE: 00430
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>430
,p_name=>'Export Statement of Completeness'
,p_alias=>'EXPORT-STATEMENT-OF-COMPLETENESS'
,p_step_title=>'Export Statement of Completeness'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.col .rel-col {',
'    width: auto;',
'    float: right;',
'}',
'',
'',
'#IG1 .a-GV-headerGroup[data-idx="1"] {',
'    background-color: #ebf1de;',
'    color: black;',
'}',
'',
'#IG1 .a-GV-headerGroup[data-idx="2"] {',
'    background-color: #dce6f1;',
'    color: black;',
'}',
'',
'',
'#IG1 th span',
'{',
'    white-space: normal;',
'    word-break: break-word; /* Break words at any point */',
'    overflow-wrap: break-word; /* text to wrap */',
'    hyphens: auto; /*Enable hyphenation*/',
'}',
'',
'',
'#IG1 td {',
'    white-space: normal;',
'    word-break: break-word; /* Break words at any point */',
'    overflow-wrap: break-word; /* text to wrap */',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IG1 th span',
'{',
'    white-space: normal;',
'    word-break: break-word; /* Break words at any point */',
'    overflow-wrap: break-word; /* text to wrap */',
'    hyphens: auto; /*Enable hyphenation*/',
'}',
'',
'',
'#IG1 td {',
'    white-space: normal;',
'    word-break: break-word; /* Break words at any point */',
'    overflow-wrap: break-word; /* text to wrap */',
'}',
''))
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(759545785204682168)
,p_plug_name=>'Country: &P430_LIST_ITEM. Combined Report'
,p_region_name=>'IG1'
,p_region_css_classes=>'cc-text-wrap'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'        current_thema_sortorder,',
'        future_thema_sortorder,',
'        current_rowindex,',
'        future_rowindex, ',
'        "Topic ID",',
'        "Topic",',
'        "topics description SoC", ',
'        "Current Local Regulation",',
'        "Current Correction",',
'        "Current Comment",',
'        "Future Local Regulation",',
'        "Enactement Date",',
'        "Implementation date New Type",',
'        "Implementation date All Vehicles",',
'        "Future Correction",',
'        "Future Comment", ',
'        "Comment VKO",',
'        "Group Clusters",',
'        "AK",',
'        "Leaf"',
'',
'from ',
'(',
'with cte_kc as (  ',
'    select trc.themaid, listagg(kc.bezeichnung, '', '') within group (order by kc.bezeichnung) as liste_cluster',
'    from t_thema_ref_cluster trc',
'    join t_konzern_cluster kc on (kc.konzern_clusterid = trc.konzern_clusterid)',
'    group by trc.themaid',
'), ',
'cte_krz as (select LISTAGG(tebak.KURZ, '', '') WITHIN GROUP (ORDER BY tebak.KURZ) KURZ,t.themaid',
'    from t_thema t',
'    left outer join T_THEMA_REF_ET_B_AK ttrebak on ttrebak.THEMAID = t.themaid',
'    left outer join t_et_b_ak tebak on tebak.ET_B_AKID = ttrebak.ET_B_AKID',
'    group by t.themaid',
'),',
'cte_thema as (select t.themaid ct_themaid,',
'                    t.NUMMER,',
'                    nvl(t.name_eng,t.bezeichnung) as thema,',
'                    t.DESCRIPTION_SOC_EN,',
'                    ',
'                    t.name_eng,',
'                    t.bezeichnung,',
'                    vt.thema_sortorder,',
'                ',
'                    vt.leaf',
'            from v_thema_baum vt',
'join t_thema t on (t.themaid = vt.themaid)',
'),',
' ',
'cte_current as(select cd.landid,',
'      cd.themaid as current_themaid,',
'       cd.vorschriftid,',
'       ',
'       row_number() over (partition by  cd.themaid order by v.vorschrift_nummer)  rowindexid,',
'       row_number() over (partition by cd.themaid order by v.vorschrift_nummer) index_thema_land_anzeige,',
'       nvl(v.vorschrift_nummer,v_rr.vorschrift_nummer) as current_local_regulation',
'from t_cockpit_daten cd',
'left outer join t_vorschrift v on (cd.vorschriftid = v.vorschriftid)',
'left outer join t_vorschrift v_rr on (cd.rr_vorschriftid = v_rr.vorschriftid)',
'where cd.ANZEIGE_IN in (10,20)',
'and anzeigen = 1',
'and cd.landid =:P430_LAND',
'order by cd.themaid,ROWINDEXID',
'),',
' ',
'cte3 as (select cte_current.landid, cte_current.current_themaid, nvl(t.name_eng,t.bezeichnung) as thema, ',
'    max(index_thema_land_anzeige) as max_thema_land, t.nummer as thema_nummer, vt.thema_sortorder,',
'    cte_kc.liste_cluster konzern_clusters ',
'    from v_thema_baum vt',
'    join t_thema t on (t.themaid = vt.themaid)',
'    join t_land_statement_of_completeness lsc on (lsc.themaid = t.themaid and lsc.landid = :P430_LAND)',
'    left outer join cte_current on (cte_current.current_themaid = vt.themaid)',
'    left outer join cte_kc on (cte_kc.themaid = vt.themaid) ',
'    group by cte_current.landid, cte_current.current_themaid, t.bezeichnung, t.nummer, vt.thema_sortorder, t.name_eng , cte_kc.liste_cluster',
'),',
'cte_future as ( select anzeige_in, cd.landid, cd.themaid, cd.vorschriftid, rr_vorschriftid, v.vorschrift_nummer, v_rr.vorschrift_nummer as rr_vorschrift_nummer,',
'    dense_rank() over (partition by cd.themaid order by v.vorschrift_nummer) future_row_index,',
'    count(*) over (partition by cd.landid, cd.themaid) max_thema_land, rr_ursp_verknuepfung,',
'    v_vk.vorschrift_nummer as verkn_vorschrift, t.nummer as thema_nummer, nvl(t2.name_eng,t.bezeichnung) as thema,',
'    cd.regel_nr, t.thema_sortorder, cte_kc.liste_cluster konzern_clusters, cte_krz.kurz, t2.DESCRIPTION_SOC_DE, t2.DESCRIPTION_SOC_EN',
'    from v_thema_baum t',
'    join t_land_statement_of_completeness lsc  on (lsc.themaid = t.themaid and lsc.landid = :P430_LAND )',
'    join t_thema t2 on (t.themaid = t2.themaid)',
'    join t_cockpit_daten cd on (cd.themaid = t.themaid and anzeige_in = 30 and cd.landid = :P430_LAND and cd.anzeigen = 1)',
'    left outer join t_vorschrift v on (cd.vorschriftid = v.vorschriftid)',
'    left outer join t_vorschrift v_rr on (cd.rr_vorschriftid = v_rr.vorschriftid)',
'    left outer join t_vorschrift v_vk on (cd.verkn_vorschriftid = v_vk.vorschriftid)',
'    left outer join cte_kc on (cte_kc.themaid = cd.themaid)',
'    left outer join cte_krz on (cte_krz.themaid = cd.themaid)   ',
'),',
'cte_land as (',
'    select einsatzdatum_modellid',
'    from t_land l',
'    where l.landid = :P430_LAND',
'),',
'cte_current_output as (',
'select  cte3.landid, ',
'        cte3.thema_sortorder AS current_thema_sortorder,',
'        ctc.rowindexid AS current_rowindex,',
'        cte3.thema_nummer AS current_thema_nummer,',
'        cte3.thema AS current_thema, ',
'        cth.DESCRIPTION_SOC_EN,',
'        ctc.current_local_regulation,',
'        null as current_correction, ',
'        null as current_comment,',
'        null as current_comment_vko,',
'        null as future_correction,',
'        null as future_comment,',
'        cte3.konzern_clusters as current_konzern_clusters,',
'        cte_krz.kurz AS current_kurz,',
'        cte3.current_themaid as themaid,',
'        cth.leaf as Leaf',
'      from cte3',
'     left outer join cte_current ctc on (ctc.current_themaid=cte3.current_themaid)',
'     left outer join cte_krz on(cte3.current_themaid=cte_krz.themaid)',
'     left outer join cte_thema cth on(cte3.current_themaid =cth.ct_themaid) ',
'),',
'cte_future_output as (',
' select ft.thema_sortorder as future_thema_sortorder, ',
'        ',
'        ft.future_row_index AS future_rowindex,',
'        ',
'        ft.thema_nummer AS thema_nummer,',
'        ',
'        ft.thema AS thema, ',
'        ',
'        ',
'        ft.DESCRIPTION_SOC_EN,',
'        ',
'        ',
'        ft.vorschrift_nummer as future_local_regulation,',
'        ',
'        null as correction,',
'        ',
'        vret_ik.einsatzdatum future_in_kraft,',
'        ',
'        case when regel_nr in (180,190,200,210,220) then to_char(rr_ursp_vk.datum_neue_typen, ''dd.mm.yyyy'') else to_char(vret_nt.einsatzdatum, ''dd.mm.yyyy'') end as future_neue_typen,',
'        case when regel_nr in (180,190,200,210,220) then to_char(rr_ursp_vk.datum_alle_typen, ''dd.mm.yyyy'') else to_char(vret_af.einsatzdatum, ''dd.mm.yyyy'') end as future_alle_fzg,',
'        null as future_comment_vko,',
'       ',
'        null as comments,',
'        ft.konzern_clusters as future_konzern_clusters,',
'        ft.kurz as future_kurz  ',
'        ',
'from cte_future ft',
'cross join cte_land',
'left outer join t_vorschrift_ref_vorschrift rr_ursp_vk on (ft.rr_ursp_verknuepfung = rr_ursp_vk.vorschrift_ref_vorschriftid)',
'left outer join t_vorschrift_ref_einsatzdatum_typ vret_ik on (ft.vorschriftid = vret_ik.vorschriftid and vret_ik.einsatzdatum_typid = 1000)',
'left outer join t_vorschrift_ref_einsatzdatum_typ vret_nt on (ft.vorschriftid = vret_nt.vorschriftid',
'                and vret_nt.einsatzdatum_typid = case einsatzdatum_modellid when 10 then 1010 when 20 then 1022 when 30 then 1030 end)',
'left outer join t_vorschrift_ref_einsatzdatum_typ vret_af on (ft.vorschriftid = vret_af.vorschriftid',
'                and vret_af.einsatzdatum_typid = case einsatzdatum_modellid when 10 then 1011 when 20 then 1023 when 30 then 1031 end)',
')',
'Select  -- current_thema_sortorder, ',
'        co.current_thema_sortorder as current_thema_sortorder,',
'        -- future_thema_sortorder, ',
'        fo.future_thema_sortorder as future_thema_sortorder,',
'        -- current_rowindex,',
'        co.current_rowindex as current_rowindex,',
'        -- future_row_index,  ',
'        fo.future_rowindex as future_rowindex, ',
'        co.current_thema_nummer as "Topic ID",',
'        co.current_thema as "Topic",',
'        co.DESCRIPTION_SOC_EN as "topics description SoC", ',
'        co.current_local_regulation as "Current Local Regulation",',
'        co.current_correction as "Current Correction",',
'        co.current_comment as "Current Comment",',
'        fo.future_local_regulation as "Future Local Regulation",',
'        future_in_kraft as "Enactement Date",',
'        future_neue_typen as "Implementation date New Type",',
'        future_alle_fzg as "Implementation date All Vehicles",',
'        fo.correction as "Future Correction",',
'        fo.comments as "Future Comment", ',
'        nvl(co.current_comment_vko, fo.future_comment_vko) as "Comment VKO",',
'        co.current_konzern_clusters as "Group Clusters",',
'        co.current_kurz as "AK",',
'        co.leaf as "Leaf" ',
'from cte_current_output co',
'full outer join cte_future_output fo on (co.current_thema_sortorder = fo.future_thema_sortorder and co.current_rowindex = fo.future_rowindex)',
'order by nvl(co.current_thema_sortorder, fo.future_thema_sortorder), nvl(co.current_rowindex, fo.future_rowindex));'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P430_LAND'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P430_LAND'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Current + Future Interactive Grid'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column_group(
 p_id=>wwv_flow_imp.id(759545539545682166)
,p_heading=>'Current'
,p_label=>'Current'
);
wwv_flow_imp_page.create_region_column_group(
 p_id=>wwv_flow_imp.id(759545454944682165)
,p_heading=>'Future'
,p_label=>'Future'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687537148043989157)
,p_name=>'Topic ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'Topic ID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Topic Id'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>40
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687537104448989156)
,p_name=>'Topic'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'Topic'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Topic'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>1024
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687537029146989155)
,p_name=>'topics description SoC'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'topics description SoC'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Topics Description Soc'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>2000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687536877609989154)
,p_name=>'Current Local Regulation'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'Current Local Regulation'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Local Regulation'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(759545539545682166)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>1000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687437933010921503)
,p_name=>'Current Correction'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'Current Correction'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Correction'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(759545539545682166)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>0
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687437765699921502)
,p_name=>'Current Comment'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'Current Comment'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Comment'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(759545539545682166)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>0
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687437648568921501)
,p_name=>'Future Local Regulation'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'Future Local Regulation'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Local Regulation'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(759545454944682165)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>1000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687437591928921500)
,p_name=>'Enactement Date'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'Enactement Date'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Enactement Date'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>120
,p_value_alignment=>'CENTER'
,p_group_id=>wwv_flow_imp.id(759545454944682165)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687437509895921499)
,p_name=>'Implementation date New Type'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'Implementation date New Type'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Implementation Date New Type'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(759545454944682165)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687437381372921498)
,p_name=>'Implementation date All Vehicles'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'Implementation date All Vehicles'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Implementation Date All Vehicles'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(759545454944682165)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687437309047921497)
,p_name=>'Future Correction'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'Future Correction'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Correction'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(759545454944682165)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>0
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687437179817921496)
,p_name=>'Future Comment'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'Future Comment'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Comment'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_group_id=>wwv_flow_imp.id(759545454944682165)
,p_use_group_for=>'BOTH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>0
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687437054749921495)
,p_name=>'Comment VKO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'Comment VKO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Comment Vko'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>170
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>0
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687437026486921494)
,p_name=>'Group Clusters'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'Group Clusters'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Group Clusters'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>180
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687436868872921493)
,p_name=>'AK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'AK'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Ak'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>190
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687436817407921492)
,p_name=>'Leaf'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'Leaf'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Leaf'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>200
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687436057031921485)
,p_name=>'CURRENT_THEMA_SORTORDER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CURRENT_THEMA_SORTORDER'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687435958458921484)
,p_name=>'FUTURE_THEMA_SORTORDER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FUTURE_THEMA_SORTORDER'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687435879973921483)
,p_name=>'CURRENT_ROWINDEX'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CURRENT_ROWINDEX'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687435806177921482)
,p_name=>'FUTURE_ROWINDEX'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FUTURE_ROWINDEX'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(759545681829682167)
,p_internal_uid=>353147255265452237
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>false
,p_toolbar_buttons=>null
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(759018028420443671)
,p_interactive_grid_id=>wwv_flow_imp.id(759545681829682167)
,p_static_id=>'3536750'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(759017798761443671)
,p_report_id=>wwv_flow_imp.id(759018028420443671)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687431883128921219)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(687537148043989157)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687430959384921214)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(687537104448989156)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687430098646921210)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(687537029146989155)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687429152404921206)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(687536877609989154)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687428287731921203)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(687437933010921503)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687427349864921198)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(687437765699921502)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687426482634921194)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(687437648568921501)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687425570374921191)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(687437591928921500)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687424733884921187)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(687437509895921499)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687423828653921184)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(687437381372921498)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687422901308921180)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(687437309047921497)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687421997558921177)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(687437179817921496)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687421042258921174)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(687437054749921495)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687420204621921171)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(687437026486921494)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687419307892921167)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>20
,p_column_id=>wwv_flow_imp.id(687436868872921493)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687418392683921162)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(687436817407921492)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687394137300886312)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(687436057031921485)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687393269623886307)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(687435958458921484)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687392367645886303)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(687435879973921483)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687391525958886300)
,p_view_id=>wwv_flow_imp.id(759017798761443671)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(687435806177921482)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(757464315063322903)
,p_name=>'Current + Future Classic Report old'
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_kc as (  ',
'    select trc.themaid, listagg(kc.bezeichnung, '', '') within group (order by kc.bezeichnung) as liste_cluster',
'    from t_thema_ref_cluster trc',
'    join t_konzern_cluster kc on (kc.konzern_clusterid = trc.konzern_clusterid)',
'    group by trc.themaid',
'), ',
'',
'cte_krz as (select LISTAGG(tebak.KURZ, '', '') WITHIN GROUP (ORDER BY tebak.KURZ) KURZ,t.themaid',
'    from t_thema t',
'    left outer join T_THEMA_REF_ET_B_AK ttrebak on ttrebak.THEMAID = t.themaid',
'    left outer join t_et_b_ak tebak on tebak.ET_B_AKID = ttrebak.ET_B_AKID',
'    group by t.themaid',
'),',
'',
'cte_thema as (select t.themaid ct_themaid,',
'                    t.NUMMER,',
'                    nvl(t.name_eng,t.bezeichnung) as thema,',
'                    t.DESCRIPTION_SOC_EN,',
'                    ',
'                    t.name_eng,',
'                    t.bezeichnung,',
'                    vt.thema_sortorder,',
'                --    cte_kc.liste_cluster konzern_clusters,',
'                --    cte_krz.kurz',
'                    vt.leaf',
'',
'            from v_thema_baum vt',
'join t_thema t on (t.themaid = vt.themaid)',
'),',
' ',
'cte_current as(select cd.landid,',
'      cd.themaid as current_themaid,',
'       cd.vorschriftid,',
'       ',
'       row_number() over (partition by  cd.themaid order by v.vorschrift_nummer)  rowindexid,',
'       row_number() over (partition by cd.themaid order by v.vorschrift_nummer) index_thema_land_anzeige,',
'       nvl(v.vorschrift_nummer,v_rr.vorschrift_nummer) as current_local_regulation',
'from t_cockpit_daten cd',
'left outer join t_vorschrift v on (cd.vorschriftid = v.vorschriftid)',
'left outer join t_vorschrift v_rr on (cd.rr_vorschriftid = v_rr.vorschriftid)',
'where cd.ANZEIGE_IN in (10,20)',
'and anzeigen = 1',
'and cd.landid = :P430_LAND',
'order by cd.themaid,ROWINDEXID',
'),',
' ',
'cte3 as (select cte_current.landid, cte_current.current_themaid, nvl(t.name_eng,t.bezeichnung) as thema, ',
'    max(index_thema_land_anzeige) as max_thema_land, t.nummer as thema_nummer, vt.thema_sortorder,',
'    cte_kc.liste_cluster konzern_clusters ',
'    from v_thema_baum vt',
'    join t_thema t on (t.themaid = vt.themaid)',
'    join t_land_statement_of_completeness lsc on (lsc.themaid = t.themaid and lsc.landid = :P430_LAND)',
'    left outer join cte_current on (cte_current.current_themaid = vt.themaid)',
'    left outer join cte_kc on (cte_kc.themaid = vt.themaid) ',
'    group by cte_current.landid, cte_current.current_themaid, t.bezeichnung, t.nummer, vt.thema_sortorder, t.name_eng , cte_kc.liste_cluster',
'),',
'',
'cte_future as ( select anzeige_in, cd.landid, cd.themaid, cd.vorschriftid, rr_vorschriftid, v.vorschrift_nummer, v_rr.vorschrift_nummer as rr_vorschrift_nummer,',
'    dense_rank() over (partition by cd.themaid order by v.vorschrift_nummer) future_row_index,',
'    count(*) over (partition by cd.landid, cd.themaid) max_thema_land, rr_ursp_verknuepfung,',
'    v_vk.vorschrift_nummer as verkn_vorschrift, t.nummer as thema_nummer, nvl(t2.name_eng,t.bezeichnung) as thema,',
'    cd.regel_nr, t.thema_sortorder, cte_kc.liste_cluster konzern_clusters, cte_krz.kurz, t2.DESCRIPTION_SOC_DE, t2.DESCRIPTION_SOC_EN',
'    from v_thema_baum t',
'    join t_land_statement_of_completeness lsc  on (lsc.themaid = t.themaid and lsc.landid = :P430_LAND)',
'    join t_thema t2 on (t.themaid = t2.themaid)',
'    join t_cockpit_daten cd on (cd.themaid = t.themaid and anzeige_in = 30 and cd.landid = :P430_LAND and cd.anzeigen = 1)',
'    left outer join t_vorschrift v on (cd.vorschriftid = v.vorschriftid)',
'    left outer join t_vorschrift v_rr on (cd.rr_vorschriftid = v_rr.vorschriftid)',
'    left outer join t_vorschrift v_vk on (cd.verkn_vorschriftid = v_vk.vorschriftid)',
'    left outer join cte_kc on (cte_kc.themaid = cd.themaid)',
'    left outer join cte_krz on (cte_krz.themaid = cd.themaid)   ',
'),',
'',
'cte_land as (',
'    select einsatzdatum_modellid',
'    from t_land l',
'    where l.landid = :P430_LAND',
'),',
'',
'cte_current_output as (',
'select  cte3.landid, ',
'        cte3.thema_sortorder AS current_thema_sortorder,',
'        ctc.rowindexid AS current_rowindex,',
'        cte3.thema_nummer AS current_thema_nummer,',
'        cte3.thema AS current_thema, ',
'        cth.DESCRIPTION_SOC_EN,',
'        ctc.current_local_regulation,',
'        null as current_correction, ',
'        null as current_comment,',
'        null as current_comment_vko,',
'        null as future_correction,',
'        null as future_comment,',
'        cte3.konzern_clusters as current_konzern_clusters,',
'        cte_krz.kurz AS current_kurz,',
'        cte3.current_themaid as themaid,',
'        cth.leaf as Leaf',
'',
'      from cte3',
'     left outer join cte_current ctc on (ctc.current_themaid=cte3.current_themaid)',
'     left outer join cte_krz on(cte3.current_themaid=cte_krz.themaid)',
'     left outer join cte_thema cth on(cte3.current_themaid =cth.ct_themaid)',
'    --order by cte3.thema_sortorder,ctc.rowindexid',
'),',
'cte_future_output as (',
' select ft.thema_sortorder as future_thema_sortorder, ',
'        -- rank() over (partition by cte1.themaid order by cte1.vorschrift_nummer) future_row_index,',
'        ft.future_row_index AS future_rowindex,',
'        -- thema_nummer as future_thema_nummer, ',
'        ft.thema_nummer AS thema_nummer,',
'        -- thema as future_thema,',
'        ft.thema AS thema, ',
'        -- DESCRIPTION_SOC_DE as future_DESCRIPTION_SOC_DE,',
'        -- DESCRIPTION_SOC_EN as future_DESCRIPTION_SOC_EN,',
'        ft.DESCRIPTION_SOC_EN,',
'        ',
'        -- nvl(cte1.rr_vorschrift_nummer, cte1.vorschrift_nummer) as future_local_regulation,',
'        ft.vorschrift_nummer as future_local_regulation,',
'        -- null as future_correction,',
'        null as correction,',
'        ',
'        vret_ik.einsatzdatum future_in_kraft,',
'        -- case when regel_nr in (180,190,200,210,220) then rr_ursp_vk.datum_neue_typen else vret_nt.einsatzdatum end future_neue_typen,',
'        -- case when regel_nr in (180,190,200,210,220) then rr_ursp_vk.datum_alle_typen else vret_af.einsatzdatum end future_alle_fzg,',
'        case when regel_nr in (180,190,200,210,220) then to_char(rr_ursp_vk.datum_neue_typen, ''dd.mm.yyyy'') else to_char(vret_nt.einsatzdatum, ''dd.mm.yyyy'') end as future_neue_typen,',
'        case when regel_nr in (180,190,200,210,220) then to_char(rr_ursp_vk.datum_alle_typen, ''dd.mm.yyyy'') else to_char(vret_af.einsatzdatum, ''dd.mm.yyyy'') end as future_alle_fzg,',
'        null as future_comment_vko,',
'        -- null as future_comment,',
'        null as comments,',
'        ft.konzern_clusters as future_konzern_clusters,',
'        ft.kurz as future_kurz  ',
'        -- themaid',
'from cte_future ft',
'cross join cte_land',
'left outer join t_vorschrift_ref_vorschrift rr_ursp_vk on (ft.rr_ursp_verknuepfung = rr_ursp_vk.vorschrift_ref_vorschriftid)',
'left outer join t_vorschrift_ref_einsatzdatum_typ vret_ik on (ft.vorschriftid = vret_ik.vorschriftid and vret_ik.einsatzdatum_typid = 1000)',
'left outer join t_vorschrift_ref_einsatzdatum_typ vret_nt on (ft.vorschriftid = vret_nt.vorschriftid  -- neue typen',
'                and vret_nt.einsatzdatum_typid = case einsatzdatum_modellid when 10 then 1010 when 20 then 1022 when 30 then 1030 end)',
'left outer join t_vorschrift_ref_einsatzdatum_typ vret_af on (ft.vorschriftid = vret_af.vorschriftid  -- alle fahrzeuge',
'                and vret_af.einsatzdatum_typid = case einsatzdatum_modellid when 10 then 1011 when 20 then 1023 when 30 then 1031 end)',
'',
'-- order by thema_sortorder, future_row_index',
'',
')',
'',
'Select   ',
'        -- current_thema_sortorder, ',
'        co.current_thema_sortorder,',
'        -- future_thema_sortorder, ',
'        fo.future_thema_sortorder,',
'        -- current_rowindex,',
'        co.current_rowindex,',
'        -- future_row_index,  ',
'        fo.future_rowindex,',
'        -- t5.nummer,',
'        co.current_thema_nummer as "Topic ID",',
'        -- fo.thema_nummer,',
'',
'        -- t5.thema,',
'        co.current_thema as "Topic",',
'        -- fo.thema,',
'',
'        -- t5.DESCRIPTION_SOC_EN,',
'        co.DESCRIPTION_SOC_EN as "topics description SoC", ',
'        -- fo.DESCRIPTION_SOC_EN,',
'',
'',
'        -- ccr.current_local_regulation,',
'        co.current_local_regulation as "Current Local Regulation",',
'        -- ccr.current_correction,',
'        co.current_correction as "Current Correction",',
'        -- ccr.current_comment,',
'        co.current_comment as "Current Comment",',
'',
'        -- cfr.future_local_regulation,',
'        fo.future_local_regulation as "Future Local Regulation",',
'        future_in_kraft as "Enactement Date",',
'        future_neue_typen as "Implementation date New Type",',
'        future_alle_fzg as "Implementation date All Vehicles",',
'        -- cfr.future_correction,',
'        fo.correction as "Future Correction",',
'        -- cfr.future_comment,',
'        fo.comments as "Future Comment",         ',
'        -- null as "Comment VKO",',
'        nvl(co.current_comment_vko, fo.future_comment_vko) as "Comment VKO",',
'        co.current_konzern_clusters as "Current Group Clusters",',
'        -- fo.future_konzern_clusters as "Future Group Clusters",',
'        co.current_kurz as "Current AK",',
'        -- fo.future_kurz as "Future AK",',
'        co.leaf as "Leaf"',
'        ',
'    ',
'from cte_current_output co',
'-- full outer join cte_future_output fo on (co.themaid = cfr.themaid and ccr.current_rowindex = cfr.future_row_index)',
'-- full outer join cte_thema t5 on t5.ct_themaid = ccr.themaid',
'-- order by thema_sortorder, nvl(current_rowindex, future_row_index)',
'',
'full outer join cte_future_output fo on (co.current_thema_sortorder = fo.future_thema_sortorder and co.current_rowindex = fo.future_rowindex)',
'order by coalesce(co.current_thema_sortorder, fo.future_thema_sortorder), coalesce(co.current_rowindex, fo.future_rowindex);'))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'nvl(:P430_CURRENT_FUTURE,-10) = 20 and :P430_LAND is not null',
''))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(757665078464560066)
,p_query_column_id=>1
,p_column_alias=>'CURRENT_THEMA_SORTORDER'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(757664996514560065)
,p_query_column_id=>2
,p_column_alias=>'FUTURE_THEMA_SORTORDER'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(757461091865322871)
,p_query_column_id=>3
,p_column_alias=>'CURRENT_ROWINDEX'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687538854571989174)
,p_query_column_id=>4
,p_column_alias=>'FUTURE_ROWINDEX'
,p_column_display_sequence=>40
,p_column_heading=>'Future Rowindex'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687538739061989173)
,p_query_column_id=>5
,p_column_alias=>'Topic ID'
,p_column_display_sequence=>50
,p_column_heading=>'Topic Id'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687538659448989172)
,p_query_column_id=>6
,p_column_alias=>'Topic'
,p_column_display_sequence=>60
,p_column_heading=>'Topic'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687538625849989171)
,p_query_column_id=>7
,p_column_alias=>'topics description SoC'
,p_column_display_sequence=>70
,p_column_heading=>'Topics Description Soc'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687538510684989170)
,p_query_column_id=>8
,p_column_alias=>'Current Local Regulation'
,p_column_display_sequence=>80
,p_column_heading=>'Current Local Regulation'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687538385696989169)
,p_query_column_id=>9
,p_column_alias=>'Current Correction'
,p_column_display_sequence=>90
,p_column_heading=>'Current Correction'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687538305882989168)
,p_query_column_id=>10
,p_column_alias=>'Current Comment'
,p_column_display_sequence=>100
,p_column_heading=>'Current Comment'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687538181428989167)
,p_query_column_id=>11
,p_column_alias=>'Future Local Regulation'
,p_column_display_sequence=>110
,p_column_heading=>'Future Local Regulation'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687538110053989166)
,p_query_column_id=>12
,p_column_alias=>'Enactement Date'
,p_column_display_sequence=>120
,p_column_heading=>'Enactement Date'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687538033056989165)
,p_query_column_id=>13
,p_column_alias=>'Implementation date New Type'
,p_column_display_sequence=>130
,p_column_heading=>'Implementation Date New Type'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687537934421989164)
,p_query_column_id=>14
,p_column_alias=>'Implementation date All Vehicles'
,p_column_display_sequence=>140
,p_column_heading=>'Implementation Date All Vehicles'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687537764270989163)
,p_query_column_id=>15
,p_column_alias=>'Future Correction'
,p_column_display_sequence=>150
,p_column_heading=>'Future Correction'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687537687672989162)
,p_query_column_id=>16
,p_column_alias=>'Future Comment'
,p_column_display_sequence=>160
,p_column_heading=>'Future Comment'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687537559934989161)
,p_query_column_id=>17
,p_column_alias=>'Comment VKO'
,p_column_display_sequence=>170
,p_column_heading=>'Comment Vko'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687537451869989160)
,p_query_column_id=>18
,p_column_alias=>'Current Group Clusters'
,p_column_display_sequence=>180
,p_column_heading=>'Current Group Clusters'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687537402025989159)
,p_query_column_id=>19
,p_column_alias=>'Current AK'
,p_column_display_sequence=>190
,p_column_heading=>'Current Ak'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687537282801989158)
,p_query_column_id=>20
,p_column_alias=>'Leaf'
,p_column_display_sequence=>200
,p_column_heading=>'Leaf'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(701657877972422857)
,p_name=>'Current + Future Classic Report new'
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'with cte_kc as (  ',
'    select trc.themaid, listagg(kc.bezeichnung, '', '') within group (order by kc.bezeichnung) as liste_cluster',
'    from t_thema_ref_cluster trc',
'    join t_konzern_cluster kc on (kc.konzern_clusterid = trc.konzern_clusterid)',
'    group by trc.themaid',
'), ',
'',
'cte_krz as (select LISTAGG(tebak.KURZ, '', '') WITHIN GROUP (ORDER BY tebak.KURZ) KURZ,t.themaid',
'    from t_thema t',
'    left outer join T_THEMA_REF_ET_B_AK ttrebak on ttrebak.THEMAID = t.themaid',
'    left outer join t_et_b_ak tebak on tebak.ET_B_AKID = ttrebak.ET_B_AKID',
'    group by t.themaid',
'),',
'',
'cte_thema as (select t.themaid ct_themaid,',
'                    t.NUMMER,',
'                    nvl(t.name_eng,t.bezeichnung) as thema,',
'                    t.DESCRIPTION_SOC_EN,',
'                    ',
'                    t.name_eng,',
'                    t.bezeichnung,',
'                    vt.thema_sortorder,',
'                --    cte_kc.liste_cluster konzern_clusters,',
'                --    cte_krz.kurz',
'                    vt.leaf',
'',
'            from v_thema_baum vt',
'join t_thema t on (t.themaid = vt.themaid)',
'),',
' ',
'cte_current as(select cd.landid,',
'      cd.themaid as current_themaid,',
'       cd.vorschriftid,',
'       ',
'       row_number() over (partition by  cd.themaid order by v.vorschrift_nummer)  rowindexid,',
'       row_number() over (partition by cd.themaid order by v.vorschrift_nummer) index_thema_land_anzeige,',
'       nvl(v.vorschrift_nummer,v_rr.vorschrift_nummer) as current_local_regulation',
'from t_cockpit_daten cd',
'left outer join t_vorschrift v on (cd.vorschriftid = v.vorschriftid)',
'left outer join t_vorschrift v_rr on (cd.rr_vorschriftid = v_rr.vorschriftid)',
'where cd.ANZEIGE_IN in (10,20)',
'and anzeigen = 1',
'and cd.landid = :P430_LAND',
'order by cd.themaid,ROWINDEXID',
'),',
' ',
'cte3 as (select cte_current.landid, cte_current.current_themaid, nvl(t.name_eng,t.bezeichnung) as thema, ',
'    max(index_thema_land_anzeige) as max_thema_land, t.nummer as thema_nummer, vt.thema_sortorder,',
'    cte_kc.liste_cluster konzern_clusters ',
'    from v_thema_baum vt',
'    join t_thema t on (t.themaid = vt.themaid)',
'    join t_land_statement_of_completeness lsc on (lsc.themaid = t.themaid and lsc.landid = :P430_LAND)',
'    left outer join cte_current on (cte_current.current_themaid = vt.themaid)',
'    left outer join cte_kc on (cte_kc.themaid = vt.themaid) ',
'    group by cte_current.landid, cte_current.current_themaid, t.bezeichnung, t.nummer, vt.thema_sortorder, t.name_eng , cte_kc.liste_cluster',
'),',
'',
'cte_future as ( select anzeige_in, cd.landid, cd.themaid, cd.vorschriftid, rr_vorschriftid, v.vorschrift_nummer, v_rr.vorschrift_nummer as rr_vorschrift_nummer,',
'    dense_rank() over (partition by cd.themaid order by v.vorschrift_nummer) future_row_index,',
'    count(*) over (partition by cd.landid, cd.themaid) max_thema_land, rr_ursp_verknuepfung,',
'    v_vk.vorschrift_nummer as verkn_vorschrift, t.nummer as thema_nummer, nvl(t2.name_eng,t.bezeichnung) as thema,',
'    cd.regel_nr, t.thema_sortorder, cte_kc.liste_cluster konzern_clusters, cte_krz.kurz, t2.DESCRIPTION_SOC_DE, t2.DESCRIPTION_SOC_EN',
'    from v_thema_baum t',
'    join t_land_statement_of_completeness lsc  on (lsc.themaid = t.themaid and lsc.landid = :P430_LAND)',
'    join t_thema t2 on (t.themaid = t2.themaid)',
'    join t_cockpit_daten cd on (cd.themaid = t.themaid and anzeige_in = 30 and cd.landid = :P430_LAND and cd.anzeigen = 1)',
'    left outer join t_vorschrift v on (cd.vorschriftid = v.vorschriftid)',
'    left outer join t_vorschrift v_rr on (cd.rr_vorschriftid = v_rr.vorschriftid)',
'    left outer join t_vorschrift v_vk on (cd.verkn_vorschriftid = v_vk.vorschriftid)',
'    left outer join cte_kc on (cte_kc.themaid = cd.themaid)',
'    left outer join cte_krz on (cte_krz.themaid = cd.themaid)   ',
'),',
'',
'cte_land as (',
'    select einsatzdatum_modellid',
'    from t_land l',
'    where l.landid = :P430_LAND',
'),',
'',
'cte_current_output as (',
'select  cte3.landid, ',
'        cte3.thema_sortorder AS current_thema_sortorder,',
'        ctc.rowindexid AS current_rowindex,',
'        cte3.thema_nummer AS current_thema_nummer,',
'        cte3.thema AS current_thema, ',
'        cth.DESCRIPTION_SOC_EN,',
'        ctc.current_local_regulation,',
'        null as current_correction, ',
'        null as current_comment,',
'        null as current_comment_vko,',
'        null as future_correction,',
'        null as future_comment,',
'        cte3.konzern_clusters as current_konzern_clusters,',
'        cte_krz.kurz AS current_kurz,',
'        cte3.current_themaid as themaid,',
'        cth.leaf as Leaf',
'',
'      from cte3',
'     left outer join cte_current ctc on (ctc.current_themaid=cte3.current_themaid)',
'     left outer join cte_krz on(cte3.current_themaid=cte_krz.themaid)',
'     left outer join cte_thema cth on(cte3.current_themaid =cth.ct_themaid)',
'    --order by cte3.thema_sortorder,ctc.rowindexid',
'),',
'cte_future_output as (',
' select ft.thema_sortorder as future_thema_sortorder, ',
'        -- rank() over (partition by cte1.themaid order by cte1.vorschrift_nummer) future_row_index,',
'        ft.future_row_index AS future_rowindex,',
'        -- thema_nummer as future_thema_nummer, ',
'        ft.thema_nummer AS thema_nummer,',
'        -- thema as future_thema,',
'        ft.thema AS thema, ',
'        -- DESCRIPTION_SOC_DE as future_DESCRIPTION_SOC_DE,',
'        -- DESCRIPTION_SOC_EN as future_DESCRIPTION_SOC_EN,',
'        ft.DESCRIPTION_SOC_EN,',
'        ',
'        -- nvl(cte1.rr_vorschrift_nummer, cte1.vorschrift_nummer) as future_local_regulation,',
'        ft.vorschrift_nummer as future_local_regulation,',
'        -- null as future_correction,',
'        null as correction,',
'        ',
'        vret_ik.einsatzdatum future_in_kraft,',
'        -- case when regel_nr in (180,190,200,210,220) then rr_ursp_vk.datum_neue_typen else vret_nt.einsatzdatum end future_neue_typen,',
'        -- case when regel_nr in (180,190,200,210,220) then rr_ursp_vk.datum_alle_typen else vret_af.einsatzdatum end future_alle_fzg,',
'        case when regel_nr in (180,190,200,210,220) then to_char(rr_ursp_vk.datum_neue_typen, ''dd.mm.yyyy'') else to_char(vret_nt.einsatzdatum, ''dd.mm.yyyy'') end as future_neue_typen,',
'        case when regel_nr in (180,190,200,210,220) then to_char(rr_ursp_vk.datum_alle_typen, ''dd.mm.yyyy'') else to_char(vret_af.einsatzdatum, ''dd.mm.yyyy'') end as future_alle_fzg,',
'        null as future_comment_vko,',
'        -- null as future_comment,',
'        null as comments,',
'        ft.konzern_clusters as future_konzern_clusters,',
'        ft.kurz as future_kurz  ',
'        -- themaid',
'from cte_future ft',
'cross join cte_land',
'left outer join t_vorschrift_ref_vorschrift rr_ursp_vk on (ft.rr_ursp_verknuepfung = rr_ursp_vk.vorschrift_ref_vorschriftid)',
'left outer join t_vorschrift_ref_einsatzdatum_typ vret_ik on (ft.vorschriftid = vret_ik.vorschriftid and vret_ik.einsatzdatum_typid = 1000)',
'left outer join t_vorschrift_ref_einsatzdatum_typ vret_nt on (ft.vorschriftid = vret_nt.vorschriftid  -- neue typen',
'                and vret_nt.einsatzdatum_typid = case einsatzdatum_modellid when 10 then 1010 when 20 then 1022 when 30 then 1030 end)',
'left outer join t_vorschrift_ref_einsatzdatum_typ vret_af on (ft.vorschriftid = vret_af.vorschriftid  -- alle fahrzeuge',
'                and vret_af.einsatzdatum_typid = case einsatzdatum_modellid when 10 then 1011 when 20 then 1023 when 30 then 1031 end)',
'',
'-- order by thema_sortorder, future_row_index',
'',
')',
'',
'Select   ',
'        -- current_thema_sortorder, ',
'        co.current_thema_sortorder,',
'        -- future_thema_sortorder, ',
'        fo.future_thema_sortorder,',
'        -- current_rowindex,',
'        co.current_rowindex,',
'        -- future_row_index,  ',
'        fo.future_rowindex,',
'        -- t5.nummer,',
'        co.current_thema_nummer as "Topic ID",',
'        -- fo.thema_nummer,',
'',
'        -- t5.thema,',
'        co.current_thema as "Topic",',
'        -- fo.thema,',
'',
'        -- t5.DESCRIPTION_SOC_EN,',
'        co.DESCRIPTION_SOC_EN as "topics description SoC", ',
'        -- fo.DESCRIPTION_SOC_EN,',
'',
'',
'        -- ccr.current_local_regulation,',
'        co.current_local_regulation as "Current Local Regulation",',
'        -- ccr.current_correction,',
'        co.current_correction as "Current Correction",',
'        -- ccr.current_comment,',
'        co.current_comment as "Current Comment",',
'',
'        -- cfr.future_local_regulation,',
'        fo.future_local_regulation as "Future Local Regulation",',
'        future_in_kraft as "Enactement Date",',
'        future_neue_typen as "Implementation date New Type",',
'        future_alle_fzg as "Implementation date All Vehicles",',
'        -- cfr.future_correction,',
'        fo.correction as "Future Correction",',
'        -- cfr.future_comment,',
'        fo.comments as "Future Comment",         ',
'        -- null as "Comment VKO",',
'        nvl(co.current_comment_vko, fo.future_comment_vko) as "Comment VKO",',
'        co.current_konzern_clusters as "Current Group Clusters",',
'        -- fo.future_konzern_clusters as "Future Group Clusters",',
'        co.current_kurz as "Current AK",',
'        -- fo.future_kurz as "Future AK",',
'        co.leaf as "Leaf"',
'        ',
'    ',
'from cte_current_output co',
'-- full outer join cte_future_output fo on (co.themaid = cfr.themaid and ccr.current_rowindex = cfr.future_row_index)',
'-- full outer join cte_thema t5 on t5.ct_themaid = ccr.themaid',
'-- order by thema_sortorder, nvl(current_rowindex, future_row_index)',
'',
'full outer join cte_future_output fo on (co.current_thema_sortorder = fo.future_thema_sortorder and co.current_rowindex = fo.future_rowindex)',
'order by coalesce(co.current_thema_sortorder, fo.future_thema_sortorder), coalesce(co.current_rowindex, fo.future_rowindex);'))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'nvl(:P430_CURRENT_FUTURE,-10) = 20 and :P430_LAND is not null',
''))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687436676906921491)
,p_query_column_id=>1
,p_column_alias=>'CURRENT_THEMA_SORTORDER'
,p_column_display_sequence=>290
,p_column_heading=>'Current Thema Sortorder'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687436586133921490)
,p_query_column_id=>2
,p_column_alias=>'FUTURE_THEMA_SORTORDER'
,p_column_display_sequence=>300
,p_column_heading=>'Future Thema Sortorder'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687436462652921489)
,p_query_column_id=>3
,p_column_alias=>'CURRENT_ROWINDEX'
,p_column_display_sequence=>310
,p_column_heading=>'Current Rowindex'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687436435090921488)
,p_query_column_id=>4
,p_column_alias=>'FUTURE_ROWINDEX'
,p_column_display_sequence=>320
,p_column_heading=>'Future Rowindex'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(690530574209726686)
,p_query_column_id=>5
,p_column_alias=>'Topic ID'
,p_column_display_sequence=>50
,p_column_heading=>'Topic Id'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(690530472315726685)
,p_query_column_id=>6
,p_column_alias=>'Topic'
,p_column_display_sequence=>60
,p_column_heading=>'Topic'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(690530415191726684)
,p_query_column_id=>7
,p_column_alias=>'topics description SoC'
,p_column_display_sequence=>70
,p_column_heading=>'Topics Description Soc'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(690530304068726683)
,p_query_column_id=>8
,p_column_alias=>'Current Local Regulation'
,p_column_display_sequence=>80
,p_column_heading=>'Current Local Regulation'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(690530194872726682)
,p_query_column_id=>9
,p_column_alias=>'Current Correction'
,p_column_display_sequence=>90
,p_column_heading=>'Current Correction'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(690530037853726681)
,p_query_column_id=>10
,p_column_alias=>'Current Comment'
,p_column_display_sequence=>100
,p_column_heading=>'Current Comment'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(690530004576726680)
,p_query_column_id=>11
,p_column_alias=>'Future Local Regulation'
,p_column_display_sequence=>110
,p_column_heading=>'Future Local Regulation'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(690529922408726679)
,p_query_column_id=>12
,p_column_alias=>'Enactement Date'
,p_column_display_sequence=>120
,p_column_heading=>'Enactement Date'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(690529755055726678)
,p_query_column_id=>13
,p_column_alias=>'Implementation date New Type'
,p_column_display_sequence=>130
,p_column_heading=>'Implementation Date New Type'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(690529697379726677)
,p_query_column_id=>14
,p_column_alias=>'Implementation date All Vehicles'
,p_column_display_sequence=>140
,p_column_heading=>'Implementation Date All Vehicles'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(690528969297726670)
,p_query_column_id=>15
,p_column_alias=>'Future Correction'
,p_column_display_sequence=>150
,p_column_heading=>'Future Correction'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(690528935099726669)
,p_query_column_id=>16
,p_column_alias=>'Future Comment'
,p_column_display_sequence=>160
,p_column_heading=>'Future Comment'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(690529346621726674)
,p_query_column_id=>17
,p_column_alias=>'Comment VKO'
,p_column_display_sequence=>170
,p_column_heading=>'Comment Vko'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687436301994921487)
,p_query_column_id=>18
,p_column_alias=>'Current Group Clusters'
,p_column_display_sequence=>330
,p_column_heading=>'Current Group Clusters'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(687436221205921486)
,p_query_column_id=>19
,p_column_alias=>'Current AK'
,p_column_display_sequence=>340
,p_column_heading=>'Current Ak'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(690529079428726671)
,p_query_column_id=>20
,p_column_alias=>'Leaf'
,p_column_display_sequence=>280
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(687541502477989200)
,p_plug_name=>'Current + Future Interactive Grid old'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_kc as (  ',
'    select trc.themaid, listagg(kc.bezeichnung, '', '') within group (order by kc.bezeichnung) as liste_cluster',
'    from t_thema_ref_cluster trc',
'    join t_konzern_cluster kc on (kc.konzern_clusterid = trc.konzern_clusterid)',
'    group by trc.themaid',
'), cte_krz as (select LISTAGG(tebak.KURZ, '', '') WITHIN GROUP (ORDER BY tebak.KURZ) KURZ,t.themaid',
'    from t_thema t',
'    left outer join T_THEMA_REF_ET_B_AK ttrebak on ttrebak.THEMAID = t.themaid',
'    left outer join t_et_b_ak tebak on tebak.ET_B_AKID = ttrebak.ET_B_AKID',
'    group by t.themaid',
' ), cte1 as (',
'    select anzeige_in, cd.landid, cd.themaid, cd.vorschriftid, rr_vorschriftid, v.vorschrift_nummer, v_rr.vorschrift_nummer as rr_vorschrift_nummer,',
'    ',
'    count(*) over (partition by cd.landid, cd.themaid) max_thema_land, rr_ursp_verknuepfung,',
'    v_vk.vorschrift_nummer as verkn_vorschrift, t.nummer as thema_nummer, nvl(t2.name_eng,t.bezeichnung) as thema,',
'    cd.regel_nr, t.thema_sortorder, cte_kc.liste_cluster konzern_clusters, cte_krz.kurz, t2.DESCRIPTION_SOC_DE, t2.DESCRIPTION_SOC_EN',
'    from v_thema_baum t',
'    join t_land_statement_of_completeness lsc  on (lsc.themaid = t.themaid and lsc.landid = :P430_LAND)',
'    join t_thema t2 on (t.themaid = t2.themaid)',
'    join t_cockpit_daten cd on (cd.themaid = t.themaid and anzeige_in = 30 and cd.landid = :P430_LAND and cd.anzeigen = 1)',
'    left outer join t_vorschrift v on (cd.vorschriftid = v.vorschriftid)',
'    left outer join t_vorschrift v_rr on (cd.rr_vorschriftid = v_rr.vorschriftid)',
'    left outer join t_vorschrift v_vk on (cd.verkn_vorschriftid = v_vk.vorschriftid)',
'    left outer join cte_kc on (cte_kc.themaid = cd.themaid)',
'    left outer join cte_krz on (cte_krz.themaid = cd.themaid)   ',
'), cte_land as (',
'    select einsatzdatum_modellid',
'    from t_land l',
'    where l.landid = :P430_LAND',
'),cte_future_result as (',
'select',
'    ',
'    thema_sortorder as future_thema_sortorder, ',
'    rank() over (partition by cte1.themaid order by cte1.vorschrift_nummer) future_row_index,',
'    thema_nummer as future_thema_nummer, ',
'    thema as future_thema,',
'    DESCRIPTION_SOC_DE as future_DESCRIPTION_SOC_DE,',
'    DESCRIPTION_SOC_EN as future_DESCRIPTION_SOC_EN,',
'    nvl(cte1.rr_vorschrift_nummer, cte1.vorschrift_nummer) as future_local_regulation,',
'    null as future_correction,',
'    null as future_comment,',
'    vret_ik.einsatzdatum future_in_kraft,',
'    case when regel_nr in (180,190,200,210,220) then rr_ursp_vk.datum_neue_typen else vret_nt.einsatzdatum end future_neue_typen,',
'    case when regel_nr in (180,190,200,210,220) then rr_ursp_vk.datum_alle_typen else vret_af.einsatzdatum end future_alle_fzg,',
'    null as future_comment_vko,',
'    konzern_clusters as future_konzern_clusters,',
'    kurz as future_kurz,',
'    themaid',
'from cte1',
'cross join cte_land',
'left outer join t_vorschrift_ref_vorschrift rr_ursp_vk on (cte1.rr_ursp_verknuepfung = rr_ursp_vk.vorschrift_ref_vorschriftid)',
'left outer join t_vorschrift_ref_einsatzdatum_typ vret_ik on (cte1.vorschriftid = vret_ik.vorschriftid and vret_ik.einsatzdatum_typid = 1000) -- in kraft',
'left outer join t_vorschrift_ref_einsatzdatum_typ vret_nt on (cte1.vorschriftid = vret_nt.vorschriftid ',
'                and vret_nt.einsatzdatum_typid = case einsatzdatum_modellid when 10 then 1010 when 20 then 1022 when 30 then 1030 end) -- neue typen',
'left outer join t_vorschrift_ref_einsatzdatum_typ vret_af on (cte1.vorschriftid = vret_af.vorschriftid',
'                and vret_af.einsatzdatum_typid = case einsatzdatum_modellid when 10 then 1011 when 20 then 1023 when 30 then 1031 end) -- alle fahrzeuge',
'',
'order by thema_sortorder, future_row_index',
'',
'), ',
'cte_thema as (select t.themaid ct_themaid,',
'                    t.NUMMER,',
'                    nvl(t.name_eng,t.bezeichnung) as thema,',
'                    t.DESCRIPTION_SOC_EN,',
'                    ',
'                    t.name_eng,',
'                    t.bezeichnung,',
'                   vt.thema_sortorder,',
'                   cte_kc.liste_cluster konzern_clusters,',
'                   cte_krz.kurz',
'',
'            from v_thema_baum vt',
'    full outer join t_thema t on (t.themaid = vt.themaid)',
'    left outer join cte_kc on (cte_kc.themaid = t.themaid)',
'    left outer join cte_krz on (cte_krz.themaid = t.themaid)',
'),',
'cte_current as(select cd.landid,',
'      cd.themaid as current_themaid,',
'       cd.vorschriftid,',
'       ',
'       row_number() over (partition by  cd.themaid order by v.vorschrift_nummer)  rowindexid,',
'       row_number() over (partition by cd.themaid order by v.vorschrift_nummer) index_thema_land_anzeige,',
'       nvl(v.vorschrift_nummer,v_rr.vorschrift_nummer) as current_local_regulation',
'from t_cockpit_daten cd',
'left outer join t_vorschrift v on (cd.vorschriftid = v.vorschriftid)',
'left outer join t_vorschrift v_rr on (cd.rr_vorschriftid = v_rr.vorschriftid)',
'where cd.ANZEIGE_IN in (10,20)',
'and anzeigen = 1',
'and cd.landid = :P430_LAND',
'order by cd.themaid,ROWINDEXID',
'),',
'cte3 as (select cte_current.landid, cte_current.current_themaid, nvl(t.name_eng,t.bezeichnung) as thema, ',
'    max(index_thema_land_anzeige) as max_thema_land, t.nummer as thema_nummer, vt.thema_sortorder,',
'    cte_kc.liste_cluster konzern_clusters ',
'    from v_thema_baum vt',
'    join t_thema t on (t.themaid = vt.themaid)',
'    join t_land_statement_of_completeness lsc on (lsc.themaid = t.themaid and lsc.landid = :P430_LAND)',
'    left outer join cte_current on (cte_current.current_themaid = vt.themaid)',
'    left outer join cte_kc on (cte_kc.themaid = vt.themaid) ',
'    group by cte_current.landid, cte_current.current_themaid, t.bezeichnung, t.nummer, vt.thema_sortorder, t.name_eng , cte_kc.liste_cluster',
'), cte_current_result as (',
'select  cte3.landid, ',
'        cte3.thema_sortorder AS current_thema_sortorder,',
'        ctc.rowindexid AS current_rowindex,',
'        cte3.thema_nummer AS current_thema_nummer,',
'        cte3.thema AS current_thema, ',
'        ',
'        ctc.current_local_regulation,',
'        null as current_correction, ',
'        null as current_comment,',
'        null as current_comment_vko,',
'        null as future_correction,',
'        null as future_comment,',
'        cte3.konzern_clusters as current_konzern_clusters,',
'        cte_krz.kurz AS current_kurz,',
'        cte3.current_themaid as themaid',
'      from cte3',
'     left outer join cte_current ctc on (ctc.current_themaid=cte3.current_themaid)',
'     left outer join cte_krz on(cte3.current_themaid=cte_krz.themaid)',
'     left outer join cte_thema cth on(cte3.current_themaid =cth.ct_themaid)',
'    order by cte3.thema_sortorder,ctc.rowindexid',
') Select   ',
'            current_thema_sortorder, ',
'            future_thema_sortorder, ',
'            current_rowindex,',
'            future_row_index,  ',
'            t5.nummer,',
'',
'            t5.thema,',
'',
'            t5.DESCRIPTION_SOC_EN,',
'            ccr.current_local_regulation,',
'            ccr.current_correction,',
'            ccr.current_comment,',
'            cfr.future_local_regulation,',
'            future_in_kraft as future_inkraft,',
'            future_neue_typen as future_neue_typen,',
'            future_alle_fzg as future_alle_fzg,',
'            cfr.future_correction,',
'            cfr.future_comment,',
'            null as comment_vko,',
'            t5.konzern_clusters,',
'            t5.kurz,',
'            ROW_NUMBER() OVER (ORDER BY thema_sortorder, NVL(current_rowindex, future_row_index)) AS row_order',
'',
'from cte_current_result ccr',
'full outer join cte_future_result cfr on (ccr.themaid = cfr.themaid and ccr.current_rowindex = cfr.future_row_index)',
'full outer join cte_thema t5 on t5.ct_themaid = ccr.themaid',
'-- order by thema_sortorder, nvl(current_rowindex, future_row_index)',
''))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_region_column_group(
 p_id=>wwv_flow_imp.id(687541261868989198)
,p_heading=>'Current'
,p_label=>'Current'
);
wwv_flow_imp_page.create_region_column_group(
 p_id=>wwv_flow_imp.id(687541205675989197)
,p_heading=>'Future'
,p_label=>'Future'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687541041875989196)
,p_name=>'CURRENT_THEMA_SORTORDER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CURRENT_THEMA_SORTORDER'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'CURRENT_THEMA_SORTORDER'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687541021985989195)
,p_name=>'FUTURE_THEMA_SORTORDER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FUTURE_THEMA_SORTORDER'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687540877579989194)
,p_name=>'CURRENT_ROWINDEX'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CURRENT_ROWINDEX'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687540820520989193)
,p_name=>'FUTURE_ROW_INDEX'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FUTURE_ROW_INDEX'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Future Row Index'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>40
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687540641171989192)
,p_name=>'NUMMER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUMMER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Nummer'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>40
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687540610731989191)
,p_name=>'THEMA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'THEMA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Thema'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>1024
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687540503388989190)
,p_name=>'DESCRIPTION_SOC_EN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION_SOC_EN'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Description Soc En'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>2000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687540417456989189)
,p_name=>'CURRENT_LOCAL_REGULATION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CURRENT_LOCAL_REGULATION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Current Local Regulation'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>1000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687540238786989188)
,p_name=>'CURRENT_CORRECTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CURRENT_CORRECTION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Current Correction'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>0
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687540213516989187)
,p_name=>'CURRENT_COMMENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CURRENT_COMMENT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Current Comment'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>0
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687540127893989186)
,p_name=>'FUTURE_LOCAL_REGULATION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FUTURE_LOCAL_REGULATION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Future Local Regulation'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>1000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687540011931989185)
,p_name=>'FUTURE_INKRAFT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FUTURE_INKRAFT'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Future Inkraft'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>120
,p_value_alignment=>'CENTER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687539901767989184)
,p_name=>'FUTURE_NEUE_TYPEN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FUTURE_NEUE_TYPEN'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Future Neue Typen'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>130
,p_value_alignment=>'CENTER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687539833061989183)
,p_name=>'FUTURE_ALLE_FZG'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FUTURE_ALLE_FZG'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Future Alle Fzg'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>140
,p_value_alignment=>'CENTER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687539717346989182)
,p_name=>'FUTURE_CORRECTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FUTURE_CORRECTION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Future Correction'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>0
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687539619281989181)
,p_name=>'FUTURE_COMMENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FUTURE_COMMENT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Future Comment'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>0
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687539508702989180)
,p_name=>'COMMENT_VKO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMMENT_VKO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Comment Vko'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>170
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>0
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687539410645989179)
,p_name=>'KONZERN_CLUSTERS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'KONZERN_CLUSTERS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Konzern Clusters'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>180
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687539245908989178)
,p_name=>'KURZ'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'KURZ'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Kurz'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>190
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(687539223884989177)
,p_name=>'ROW_ORDER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ROW_ORDER'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Row Order'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>200
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(687541409544989199)
,p_internal_uid=>425151527550145205
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>false
,p_toolbar_buttons=>null
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(687477758638971060)
,p_interactive_grid_id=>wwv_flow_imp.id(687541409544989199)
,p_static_id=>'4252152'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(687477537944971060)
,p_report_id=>wwv_flow_imp.id(687477758638971060)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687476295680971057)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(687541041875989196)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687475371528971052)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(687541021985989195)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687474514338971048)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(687540877579989194)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687473549535971045)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(687540820520989193)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687472711486971040)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(687540641171989192)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687471823886971032)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(687540610731989191)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687471012672971026)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(687540503388989190)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687470112866971021)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(687540417456989189)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687469214176971015)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(687540238786989188)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687468325589970995)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(687540213516989187)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687467436694970986)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(687540127893989186)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687466501613970979)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(687540011931989185)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687465557125970972)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(687539901767989184)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687464663998970962)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(687539833061989183)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687463749430970954)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(687539717346989182)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687462849179970949)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(687539619281989181)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687461989020970946)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(687539508702989180)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687461080382970941)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(687539410645989179)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687460153183970932)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(687539245908989178)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(687459400973970924)
,p_view_id=>wwv_flow_imp.id(687477537944971060)
,p_display_seq=>20
,p_column_id=>wwv_flow_imp.id(687539223884989177)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1234964419656787181)
,p_plug_name=>'Einstellungen'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1234964616926787183)
,p_name=>'Current'
,p_region_name=>'current'
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- current working code - version 2',
' ',
'',
'with cte_kc as (   ',
'    select trc.themaid, listagg(kc.bezeichnung, '', '') within group (order by kc.bezeichnung) as liste_cluster',
'    from t_thema_ref_cluster trc',
'    join t_konzern_cluster kc on (kc.konzern_clusterid = trc.konzern_clusterid)',
'    group by trc.themaid',
'),',
'cte_krz as (select LISTAGG(tebak.KURZ, ''; '') WITHIN GROUP (ORDER BY tebak.KURZ) KURZ,t.themaid',
'         from t_thema t',
'         left outer join T_THEMA_REF_ET_B_AK ttrebak on ttrebak.THEMAID = t.themaid',
'    left outer join t_et_b_ak tebak on tebak.ET_B_AKID = ttrebak.ET_B_AKID',
'    group by t.themaid',
' ',
'),',
'cte_thema as (select t.themaid ct_themaid,',
'                    t.NUMMER,',
'                    nvl(t.name_eng,t.bezeichnung) as thema,',
'                    t.DESCRIPTION_SOC_EN,',
'                    t.DESCRIPTION_SOC_DE,',
'                    t.name_eng,',
'                    t.bezeichnung,',
'                   vt.thema_sortorder',
'            from v_thema_baum vt',
'    join t_thema t on (t.themaid = vt.themaid)',
'),',
'cte_current as(select cd.landid,',
'      cd.themaid as current_themaid,',
'       cd.vorschriftid,',
'       dense_rank() over (partition by  cd.themaid order by v.vorschrift_nummer)  rowindexid,',
'       row_number() over (partition by cd.themaid order by v.vorschrift_nummer) index_thema_land_anzeige,',
'       nvl(v.vorschrift_nummer,v_rr.vorschrift_nummer) as current_local_regulation',
'from t_cockpit_daten cd',
'left outer join t_vorschrift v on (cd.vorschriftid = v.vorschriftid)',
'left outer join t_vorschrift v_rr on (cd.rr_vorschriftid = v_rr.vorschriftid)',
'where cd.ANZEIGE_IN in (10,20)',
'and anzeigen = 1',
'and cd.landid = :P430_LAND',
'order by cd.themaid,ROWINDEXID',
'),',
'cte3 as (select cte_current.landid, cte_current.current_themaid, nvl(t.name_eng,t.bezeichnung) as thema, ',
'    max(index_thema_land_anzeige) as max_thema_land, t.nummer as thema_nummer, vt.thema_sortorder,',
'    cte_kc.liste_cluster konzern_clusters',
'    from v_thema_baum vt',
'    join t_thema t on (t.themaid = vt.themaid)',
'    join t_land_statement_of_completeness lsc on (lsc.themaid = t.themaid and lsc.landid = :P430_LAND)',
'    left outer join cte_current on (cte_current.current_themaid = vt.themaid)',
'    left outer join cte_kc on (cte_kc.themaid = vt.themaid) ',
'    group by cte_current.landid, cte_current.current_themaid, t.bezeichnung, t.nummer, vt.thema_sortorder, t.name_eng , cte_kc.liste_cluster',
')',
'select  cte3.landid, ',
'        cte3.thema_sortorder AS current_thema_sortorder,',
'        ctc.rowindexid AS current_rowindex,',
'        cte3.thema_nummer AS current_thema_nummer,',
'        cte3.thema AS current_thema, ',
'        cth.DESCRIPTION_SOC_EN,',
'        ---cth.DESCRIPTION_SOC_DE,',
'        ctc.current_local_regulation,',
'        null  as current_correction, ',
'        null as current_comment,',
'        null as current_comment_vko,',
'        cte3.konzern_clusters as current_konzern_clusters,',
'        cte_krz.kurz AS current_kurz',
'      from cte3',
'     left outer join cte_current ctc on (ctc.current_themaid=cte3.current_themaid)',
'     left outer join cte_krz on(cte3.current_themaid=cte_krz.themaid)',
'     left outer join cte_thema cth on(cte3.current_themaid =cth.ct_themaid)',
'    ',
'     order by cte3.thema_sortorder,ctc.rowindexid'))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>'nvl(:P430_CURRENT_FUTURE,-10) = 10 and :P430_LAND is not null'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759019740648445859)
,p_query_column_id=>1
,p_column_alias=>'LANDID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759022534159445886)
,p_query_column_id=>2
,p_column_alias=>'CURRENT_THEMA_SORTORDER'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759022360137445885)
,p_query_column_id=>3
,p_column_alias=>'CURRENT_ROWINDEX'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759022314487445884)
,p_query_column_id=>4
,p_column_alias=>'CURRENT_THEMA_NUMMER'
,p_column_display_sequence=>40
,p_column_heading=>'Topic ID'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759022139092445883)
,p_query_column_id=>5
,p_column_alias=>'CURRENT_THEMA'
,p_column_display_sequence=>50
,p_column_heading=>'Topic'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759019713329445858)
,p_query_column_id=>6
,p_column_alias=>'DESCRIPTION_SOC_EN'
,p_column_display_sequence=>70
,p_column_heading=>'topics description SoC'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759021892845445880)
,p_query_column_id=>7
,p_column_alias=>'CURRENT_LOCAL_REGULATION'
,p_column_display_sequence=>80
,p_column_heading=>'Local Regulation'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759021779595445879)
,p_query_column_id=>8
,p_column_alias=>'CURRENT_CORRECTION'
,p_column_display_sequence=>90
,p_column_heading=>'Correction'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759021731316445878)
,p_query_column_id=>9
,p_column_alias=>'CURRENT_COMMENT'
,p_column_display_sequence=>100
,p_column_heading=>'Comments'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759021570297445877)
,p_query_column_id=>10
,p_column_alias=>'CURRENT_COMMENT_VKO'
,p_column_display_sequence=>110
,p_column_heading=>'Comment VKO'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759021503460445876)
,p_query_column_id=>11
,p_column_alias=>'CURRENT_KONZERN_CLUSTERS'
,p_column_display_sequence=>120
,p_column_heading=>'Group Clusters'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759021426326445875)
,p_query_column_id=>12
,p_column_alias=>'CURRENT_KURZ'
,p_column_display_sequence=>140
,p_column_heading=>'AK'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1298126827101075800)
,p_name=>'Future'
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- future working code - version 2',
' ',
'',
'with cte_kc as (   ',
'    select trc.themaid, listagg(kc.bezeichnung, '', '') within group (order by kc.bezeichnung) as liste_cluster',
'    from t_thema_ref_cluster trc',
'    join t_konzern_cluster kc on (kc.konzern_clusterid = trc.konzern_clusterid)',
'    group by trc.themaid',
'),',
'cte_krz as (select LISTAGG(tebak.KURZ, ''; '') WITHIN GROUP (ORDER BY tebak.KURZ) KURZ,t.themaid',
'         from t_thema t',
'         left outer join T_THEMA_REF_ET_B_AK ttrebak on ttrebak.THEMAID = t.themaid',
'    left outer join t_et_b_ak tebak on tebak.ET_B_AKID = ttrebak.ET_B_AKID',
'    group by t.themaid',
' ',
'),',
'cte_thema as (select t.themaid themaid,',
'                    t.NUMMER,',
'                    nvl(t.name_eng,t.bezeichnung) as thema,',
'                    t.DESCRIPTION_SOC_EN ,',
'                    t.DESCRIPTION_SOC_DE,',
'                    t.name_eng,',
'                    t.bezeichnung,',
'                   vt.thema_sortorder',
'            from v_thema_baum vt',
'    join t_thema t on (t.themaid = vt.themaid)',
'),',
'cte_current as(select cd.landid,',
'      cd.themaid as current_themaid,',
'       cd.vorschriftid,',
'       dense_rank() over (partition by  cd.themaid order by v.vorschrift_nummer)  rowindexid,',
'       row_number() over (partition by cd.themaid order by v.vorschrift_nummer) index_thema_land_anzeige,',
'       nvl(v.vorschrift_nummer,v_rr.vorschrift_nummer) as current_local_regulation',
'from t_cockpit_daten cd',
'left outer join t_vorschrift v on (cd.vorschriftid = v.vorschriftid)',
'left outer join t_vorschrift v_rr on (cd.rr_vorschriftid = v_rr.vorschriftid)',
'where cd.ANZEIGE_IN in (10,20)',
'and anzeigen = 1',
'and cd.landid = :P430_LAND',
'order by cd.themaid,ROWINDEXID',
'),',
'cte3 as (select cte_current.landid, cte_current.current_themaid, nvl(t.name_eng,t.bezeichnung) as thema, ',
'    max(index_thema_land_anzeige) as max_thema_land, t.nummer as thema_nummer, vt.thema_sortorder,',
'    cte_kc.liste_cluster konzern_clusters ',
'    from v_thema_baum vt',
'    join t_thema t on (t.themaid = vt.themaid)',
'    join t_land_statement_of_completeness lsc on (lsc.themaid = t.themaid and lsc.landid = :P430_LAND)',
'    left outer join cte_current on (cte_current.current_themaid = vt.themaid)',
'    left outer join cte_kc on (cte_kc.themaid = vt.themaid) ',
'    group by cte_current.landid, cte_current.current_themaid, t.bezeichnung, t.nummer, vt.thema_sortorder, t.name_eng , cte_kc.liste_cluster',
'),',
'cte_future as(select anzeige_in, cd.landid, cd.themaid, cd.vorschriftid, rr_vorschriftid, v.vorschrift_nummer, v_rr.vorschrift_nummer as rr_vorschrift_nummer,',
'    dense_rank() over (partition by cd.themaid order by v.vorschrift_nummer) future_row_index,',
'    count(*) over (partition by cd.landid, cd.themaid) max_thema_land, rr_ursp_verknuepfung,',
'    v_vk.vorschrift_nummer as verkn_vorschrift, t.nummer as thema_nummer, nvl(t2.name_eng,t.bezeichnung) as thema,',
'    cd.regel_nr, t.thema_sortorder, cte_kc.liste_cluster konzern_clusters, cte_krz.kurz, t2.DESCRIPTION_SOC_DE, t2.DESCRIPTION_SOC_EN',
'    from v_thema_baum t',
'    join t_land_statement_of_completeness lsc  on (lsc.themaid = t.themaid and lsc.landid = :P430_LAND)',
'    join t_thema t2 on (t.themaid = t2.themaid)',
'    join t_cockpit_daten cd on (cd.themaid = t.themaid and anzeige_in = 30 and cd.landid = :P430_LAND and cd.anzeigen = 1)',
'    left outer join t_vorschrift v on (cd.vorschriftid = v.vorschriftid)',
'    left outer join t_vorschrift v_rr on (cd.rr_vorschriftid = v_rr.vorschriftid)',
'    left outer join t_vorschrift v_vk on (cd.verkn_vorschriftid = v_vk.vorschriftid)',
'    left outer join cte_kc on (cte_kc.themaid = cd.themaid)',
'    left outer join cte_krz on (cte_krz.themaid = cd.themaid)  ',
'   ),',
'   cte_land as (',
'    select einsatzdatum_modellid',
'    from t_land l',
'    where l.landid = :P430_LAND',
')',
'select  ft.thema_sortorder AS future_thema_sortorder,',
'        ft.future_row_index AS future_rowindex,',
'        ft.thema_nummer AS thema_nummer,',
'        ft.thema AS thema, ',
'        ft.vorschrift_nummer as future_local_regulation,',
'        ft.DESCRIPTION_SOC_EN,',
'        --ft.DESCRIPTION_SOC_DE,',
'        null as correction,',
'        vret_ik.einsatzdatum future_in_kraft,',
'       case when regel_nr in (180,190,200,210,220) then to_char(rr_ursp_vk.datum_neue_typen, ''dd.mm.yyyy'') else to_char(vret_nt.einsatzdatum, ''dd.mm.yyyy'') end as future_neue_typen,',
'  case when regel_nr in (180,190,200,210,220) then to_char(rr_ursp_vk.datum_alle_typen, ''dd.mm.yyyy'') else to_char(vret_af.einsatzdatum, ''dd.mm.yyyy'') end as future_alle_fzg,',
'    null as future_comment_vko,',
'    null as comments,',
'    ft.konzern_clusters as future_konzern_clusters,',
'    ft.kurz as future_kurz   ',
'   from cte_future ft',
'cross join cte_land',
'left outer join t_vorschrift_ref_vorschrift rr_ursp_vk on (ft.rr_ursp_verknuepfung = rr_ursp_vk.vorschrift_ref_vorschriftid)',
'left outer join t_vorschrift_ref_einsatzdatum_typ vret_ik on (ft.vorschriftid = vret_ik.vorschriftid and vret_ik.einsatzdatum_typid = 1000) -- in kraft',
'left outer join t_vorschrift_ref_einsatzdatum_typ vret_nt on ( -- neue typen',
'    ft.vorschriftid = vret_nt.vorschriftid',
'    and vret_nt.einsatzdatum_typid = case einsatzdatum_modellid when 10 then 1010 when 20 then 1022 when 30 then 1030 end',
')',
'left outer join t_vorschrift_ref_einsatzdatum_typ vret_af on ( -- alle fahrzeuge',
'    ft.vorschriftid = vret_af.vorschriftid',
'    and vret_af.einsatzdatum_typid = case einsatzdatum_modellid when 10 then 1011 when 20 then 1023 when 30 then 1031 end',
')',
' ',
'order by thema_sortorder, future_row_index -- ordering'))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>'nvl(:P430_CURRENT_FUTURE,-10) = 20 and :P430_LAND is not null'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759021314012445874)
,p_query_column_id=>1
,p_column_alias=>'FUTURE_THEMA_SORTORDER'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(757666438606560080)
,p_query_column_id=>2
,p_column_alias=>'FUTURE_ROWINDEX'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(757666419179560079)
,p_query_column_id=>3
,p_column_alias=>'THEMA_NUMMER'
,p_column_display_sequence=>30
,p_column_heading=>'Topic ID'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(757666289241560078)
,p_query_column_id=>4
,p_column_alias=>'THEMA'
,p_column_display_sequence=>40
,p_column_heading=>'Topic'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759020710564445868)
,p_query_column_id=>5
,p_column_alias=>'FUTURE_LOCAL_REGULATION'
,p_column_display_sequence=>80
,p_column_heading=>'Local Regulation'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(757666158404560077)
,p_query_column_id=>6
,p_column_alias=>'DESCRIPTION_SOC_EN'
,p_column_display_sequence=>60
,p_column_heading=>'topics description SoC'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(755098152486591063)
,p_query_column_id=>7
,p_column_alias=>'CORRECTION'
,p_column_display_sequence=>90
,p_column_heading=>'Correction'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759020411575445865)
,p_query_column_id=>8
,p_column_alias=>'FUTURE_IN_KRAFT'
,p_column_display_sequence=>110
,p_column_heading=>'Enactement Date'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759020322480445864)
,p_query_column_id=>9
,p_column_alias=>'FUTURE_NEUE_TYPEN'
,p_column_display_sequence=>120
,p_column_heading=>'Implementation date New Type'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759020189875445863)
,p_query_column_id=>10
,p_column_alias=>'FUTURE_ALLE_FZG'
,p_column_display_sequence=>130
,p_column_heading=>'Implementation date All Vehicles'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759020088001445862)
,p_query_column_id=>11
,p_column_alias=>'FUTURE_COMMENT_VKO'
,p_column_display_sequence=>140
,p_column_heading=>'Comment Vko'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(755098328153591064)
,p_query_column_id=>12
,p_column_alias=>'COMMENTS'
,p_column_display_sequence=>100
,p_column_heading=>'Comments'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759019969466445861)
,p_query_column_id=>13
,p_column_alias=>'FUTURE_KONZERN_CLUSTERS'
,p_column_display_sequence=>150
,p_column_heading=>'Group Clusters'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(759019871893445860)
,p_query_column_id=>14
,p_column_alias=>'FUTURE_KURZ'
,p_column_display_sequence=>160
,p_column_heading=>'AK'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(660124315647787003)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(1234964419656787181)
,p_button_name=>'BTN_EXPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Export Download'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:0:&SESSION.:APPLICATION_PROCESS=exportStatmentOfCompletenes2:&DEBUG.:::'
,p_button_condition=>'P430_LAND'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-download-alt'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(687435026264921474)
,p_name=>'P430_LIST_ITEM'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(1234964419656787181)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(668144763807128381)
,p_name=>'P430_CURRENT_FUTURE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1234964419656787181)
,p_item_default=>'10'
,p_prompt=>'Gegenwart / Zukunft'
,p_source=>'10'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Gegenwart'', ''Current'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Zukunft'', ''Future'') AS display_value,',
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(668144396942128378)
,p_name=>'P430_LAND'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1234964419656787181)
,p_prompt=>'Land'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    b_nummer || '' - '' || ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.land -- || ''-'' || landid',
'        ELSE l.land_eng ',
'    END AS LandName,',
'    landid',
'FROM ',
'    t_land l',
'ORDER BY ',
'    NLSSORT(l.B_NUMMER, ''NLS_SORT=BINARY_AI'') ASC',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('- w\00E4hlen -')
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(667907901561424603)
,p_name=>'P430_EINSATZDATUM_MODELLID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1234964419656787181)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(667128281416876003)
,p_name=>'P430_HEADER_ALLE_FZG'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1234964419656787181)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(667128213270876002)
,p_name=>'P430_HEADER_NEUE_TYPEN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(1234964419656787181)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(668135756991128339)
,p_name=>'onChangeSubmit'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P430_CURRENT_FUTURE,P430_LAND'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(667907786681424602)
,p_event_id=>wwv_flow_imp.id(668135756991128339)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P430_EINSATZDATUM_MODELLID'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select EINSATZDATUM_MODELLID',
'from T_LAND',
'where LANDID = :P430_LAND',
''))
,p_attribute_07=>'P430_LAND'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(667128131333876001)
,p_event_id=>wwv_flow_imp.id(668135756991128339)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P430_HEADER_NEUE_TYPEN'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select name_english',
'from T_EINSATZDATUM_TYP',
'where EINSATZDATUM_MODELLID = :P430_EINSATZDATUM_MODELLID',
'and SPALTENINDEX_COCKPIT = 2'))
,p_attribute_07=>'P430_EINSATZDATUM_MODELLID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(667127961255876000)
,p_event_id=>wwv_flow_imp.id(668135756991128339)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P430_HEADER_ALLE_FZG'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select name_english',
'from T_EINSATZDATUM_TYP',
'where EINSATZDATUM_MODELLID = :P430_EINSATZDATUM_MODELLID',
'and SPALTENINDEX_COCKPIT = 3'))
,p_attribute_07=>'P430_EINSATZDATUM_MODELLID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(687434508902921469)
,p_event_id=>wwv_flow_imp.id(668135756991128339)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P430_LIST_ITEM'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'       CASE ',
'           WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.land || '' ('' || b_nummer || '')''',
'           ELSE l.land_eng || '' ('' || b_nummer || '')''',
'       END AS LandName ',
'FROM t_land l',
'where landid = :P430_LAND',
''))
,p_attribute_07=>'P430_LAND'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(668135294075128335)
,p_event_id=>wwv_flow_imp.id(668135756991128339)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp.component_end;
end;
/
