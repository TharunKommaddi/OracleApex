prompt --application/pages/page_00617
begin
--   Manifest
--     PAGE: 00617
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>617
,p_name=>'Erstelle Benachrichtigung'
,p_alias=>'ERSTELLE-BENACHRICHTIGUNG'
,p_page_mode=>'MODAL'
,p_step_title=>'Erstelle Benachrichtigung'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(682664880752650925)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(680055399414941192)
,p_plug_name=>'Erstelle Benachrichtigung'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(680054624994941184)
,p_plug_name=>'&nbsp;'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<html>Hier k\00F6nnen VKOs eine Benachrichtigung \00FCber das System an Admins oder an die AK spezifischen VKOs versendet werden <br> '),
unistr('    z.B. : an Admin f\00FCr zu l\00F6schende Vorschriften'),
'</html>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(682664461891650924)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(682664880752650925)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(680054731828941185)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(682664880752650925)
,p_button_name=>'Save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(681730004440154803)
,p_branch_name=>'Return to parent'
,p_branch_action=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(680055216478941190)
,p_name=>'P617_BENACHRICHTIGUNGID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(680055399414941192)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(680055042079941189)
,p_name=>'P617_VORSCHRIFTID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(680055399414941192)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(680054879001941187)
,p_name=>'P617_BENACHRICHTIGUNG_TEXT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(680055399414941192)
,p_prompt=>'Benachrichtigung Text'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(3414144455872820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(680054486184941183)
,p_name=>'P617_ARBEITSKREIS'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(680055399414941192)
,p_prompt=>'Arbeitskreise'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.bezeichnung,  a.et_b_akid',
'from T_VORSCHRIFT_REF_ET_B_AK r ',
'join T_ET_B_AK a on  a.ET_B_AKID = r.ET_B_AKID ',
'WHERE VORSCHRIFTID = :P617_VORSCHRIFTID ',
'union',
'select ak.bezeichnung,  ak.et_b_akid',
'from T_ET_B_AK ak ',
'WHERE ak.bezeichnung in (''Administratoren'', ''Redaktionsteam'')',
'order by 1;'))
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(3414144455872820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(682664406480650924)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(682664461891650924)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(682663574147650920)
,p_event_id=>wwv_flow_imp.id(682664406480650924)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(682710425597274995)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save Message'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* ',
'  for ic in (select akt.column_value as akid ',
'   from table (apex_string.split(:P617_ARBEITSKREIS, '':'')) akt',
'  where akt.column_value IS NOT NULL)',
'  loop',
'  ',
'    insert into T_Benachrichtigung(VorschriftID, ArbeitskreisID, benachrichtigung_text, status, letzte_AENDERUNG_DATUM, grund, erstellung_benutzerid)',
'    values(:P617_VORSCHRIFTID, ic.akid, :P617_BENACHRICHTIGUNG_TEXT, 10, sysdate, 40, :G_BENUTZERID );',
'  end loop;',
'  */',
'  PCK_RI_BENACHRICHTIGUNG.pBenachrichtigung(:P617_VORSCHRIFTID, :P617_ARBEITSKREIS, :P617_BENACHRICHTIGUNG_TEXT,  40, 0, :G_BENUTZERID);',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(680054731828941185)
,p_internal_uid=>2989501890302113240
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(682660877548650913)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2989551438350737322
);
wwv_flow_imp.component_end;
end;
/
