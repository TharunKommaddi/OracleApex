prompt --application/pages/page_00031
begin
--   Manifest
--     PAGE: 00031
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>31
,p_name=>'Kerndaten bearbeiten'
,p_alias=>'KERNDATEN-BEARBEITEN'
,p_page_mode=>'MODAL'
,p_step_title=>'Kerndaten bearbeiten'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.getexlogo::after {',
'    content: ''GETEX'';',
'    position: absolute;',
'    right: 20px;',
'    color: #0000ff82;',
'    margin-right: 15px;',
'    font-weight: bold;',
'    top: 5px;',
'    font-size: 20px;',
'    font-family: ''Audi Type Extended'';',
'}',
'',
'',
'.getexlogo.t-Region-header::after {',
'    margin-right: 50px;',
'}',
''))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14417264557455729340)
,p_plug_name=>'Kerndaten bearbeiten'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26008731958749149323)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1014051049115833440)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(26008731958749149323)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1014050691639833435)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(26008731958749149323)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P31_VORSCHRIFTID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1014050302735833435)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(26008731958749149323)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>unistr('javascript:apex.confirm(''Soll die Getex Mapping Norm gel\00F6scht werden?'',''DELETE'');')
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'serve r',
'',
'pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0 and :P31_VORSCHRIFTID is not null'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1014069750576833474)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_button_name=>'BTN_CREATE_MESSAGE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Erstelle Benachrichtigung'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:617:&SESSION.::&DEBUG.:617:P617_VORSCHRIFTID:&P31_VORSCHRIFTID.'
,p_warn_on_unsaved_changes=>null
,p_button_condition_type=>'NEVER'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'exp plsq l ',
'',
''))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1014069388398833472)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_button_name=>'JIRA_TICKET_ASSIST'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Jira Ticket Assistent'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:581:&SESSION.::&DEBUG.:570, 571, 572,573, 574,581:P572_VORSCHRIFTEN_SEL:&P31_VORSCHRIFTID.'
,p_button_condition_type=>'NEVER'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P31_VORSCHRIFT_FREIGABESTATUSID >=1 and :P31_VORSCHRIFTID is not null',
'',
'exp ps ql seevr '))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1014049867445833434)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(26008731958749149323)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P31_VORSCHRIFTID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1013827004298833384)
,p_branch_name=>'Go To Page 25'
,p_branch_action=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::P25_VORSCHRIFTID,P25_ROWID:&P31_VORSCHRIFTID.,&P31_ROWID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1014050691639833435)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3095363468859678211)
,p_name=>'P31_SYNC_OE2_DES_REV'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>'Oe2 des REV manuelle Pflege'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_grid_column=>5
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#:margin-left-sm'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', '20',
  'unchecked_value', '10',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014068945584833460)
,p_name=>'P31_VORSCHRIFTID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014068652746833458)
,p_name=>'P31_ROWID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014068300362833458)
,p_name=>'P31_VORSCHRIFTID_PARENT'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014067880087833458)
,p_name=>'P31_PROCESS_FROM'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014067498083833457)
,p_name=>'P31_STRG_GETEX_ANZEIGE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_use_cache_before_default=>'NO'
,p_item_default=>'10'
,p_source=>'case when (:P31_MASTER in (20, 30)) then 20 else 10 end'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014067098132833457)
,p_name=>'P31_IMPORT_STATUS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_item_default=>'30'
,p_prompt=>'Getex Aktualisierung'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_IMPORT_STATUS_GETZEX'
,p_lov=>'.'||wwv_flow_imp.id(799385323802234434)||'.'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Server-Side Condition for Visibility',
'-- Show for Fachadmin, ',
'-- Fachadmin, Getex Migration, VKO',
'pck_ri.fIsUserInRolle(listRolleId => ''1003:1100:1000'') > 0',
'',
'',
'',
'lov sql single ',
'',
'select status_update_getex from t_vorschrift where vorschriftid = :P31_VORSCHRIFTID'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014066636661833457)
,p_name=>'P31_MASTER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_item_default=>'10'
,p_prompt=>unistr('Master f\00FCr diese Vorschrift')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Master in GETEX'', ''Master in GETEX'') AS display_value, ',
'        20 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Master in RegIndex'', ''Master in RegIndex'') AS display_value,',
'        10 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Master in GETEX + automatische \00DCbernahme'', ''Master in GETEX + automatische \00DCbernahme'') AS display_value,'),
'        30 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
'',
'',
'    ',
') ',
'ORDER BY sort_order;',
''))
,p_begin_on_new_line=>'N'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  (',
'  ( pck_ri.fIsUserInRolle(listRolleId => ''1003:1200'') > 0) -- Fachadmin, Redaktionsteam',
') = false',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014066310210833457)
,p_name=>'P31_PUBLISHER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Publisher'
,p_source=>'SELECT publisher FROM t_vorschrift WHERE vorschriftid = :P31_VORSCHRIFTID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- nur bearbeitbar mit Rolle inaktive Funktionen',
'pck_ri.fIsUserInRolle(listRolleId => ''1080'') = 0'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014065848321833457)
,p_name=>'P31_VORSCHRIFT_TYPID'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_item_default=>'10'
,p_prompt=>'Vorschrift Typ'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1100)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VORSCHRIFT_TYP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung ',
'        ELSE name_eng',
'    END AS d,',
'    vorschrift_typid AS r',
'FROM t_vorschrift_typ',
'ORDER BY 2;',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>5
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'   (  pck_ri.fIsAuthorized(pageId => 31, accessMode => 200) and ',
'            (    pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0',
'                   OR ( pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0 and :P31_VORSCHRIFTID is null) -- on "create"  f. Rolle Inaktive F.',
'            )',
'    ) ',
'',
') = false',
' ',
'',
'or (:P31_STRG_GETEX_ANZEIGE = 20 )'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014065462260833456)
,p_name=>'P31_EINSATZDATUM_MODELLID'
,p_is_required=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>'Einsatz DATUM Modell'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN MODELL',
'        ELSE MODELL_ENG',
'    END AS MODELL, ',
'    EINSATZDATUM_MODELLID',
'FROM T_EINSATZDATUM_MODELL ',
'ORDER BY 2;',
''))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(pck_ri.fIsAuthorized(pageId => 31, accessMode => 200) = false',
'',
') or (:P31_STRG_GETEX_ANZEIGE = 20 )'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014065029338833456)
,p_name=>'P31_DATUM_ANGABE_AS_MJ'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>'Datumsformat Modelljahr ?'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mj_schalter_status from t_vorschrift ',
'where vorschriftid = :P31_vorschriftID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Ja;1,Nein;0'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_value number;',
'begin',
'',
'if :P31_STRG_GETEX_ANZEIGE =20 then l_value :=0;',
'elsif :P31_STRG_GETEX_ANZEIGE !=20 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0  then',
' l_value :=1;',
'else l_value :=0;',
'end if;',
'',
'if l_value =0 then return (true);',
'else return(false);',
'end if;',
'',
'end;',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_value number;',
'begin',
'',
'if :P31_STRG_GETEX_ANZEIGE =20 then l_value :=0;',
'elsif :P31_STRG_GETEX_ANZEIGE !=20 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0  then',
' l_value :=1;',
'else l_value :=0;',
'end if;',
'',
'if l_value =0 then return (true);',
'else return(false);',
'end if;',
'',
'end;',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014064702373833455)
,p_name=>'P31_PHASEIN_ENTHALTEN'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>'<b><font size="3">Sind Phase in''s enthalten?</font></b>'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC2:;1'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_value number;',
'begin',
'',
'if :P31_STRG_GETEX_ANZEIGE =20 then l_value :=0;',
'elsif :P31_STRG_GETEX_ANZEIGE !=20 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0  then',
' l_value :=1;',
'else l_value :=0;',
'end if;',
'',
'if l_value =0 then return (true);',
'else return(false);',
'end if;',
'',
'end;'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014064263597833455)
,p_name=>'P31_PARENT_VORSCHRIFTID'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('\00DCbergeordnete Vorschrift')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vrv.vorgaenger_vorschriftid',
'from t_vorschrift_ref_vorschrift vrv',
'where vrv.nachfolger_vorschriftid = :P31_VORSCHRIFTID',
'and vrv.BEZIEHUNG_ART = (case when :P31_VORSCHRIFT_TYPID = 20 then 30 else 20 end)',
'and :P31_VORSCHRIFT_TYPID = 20 -- parents gibts nur bei Supplements',
'fetch first row only'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select VORSCHRIFT_NUMMER || '' - '' || VORSCHRIFT_BEZEICHNUNG d,',
'       VORSCHRIFTID as r',
'  from T_VORSCHRIFT where vorschrift_typid !=20  -- supplement is not allowed as parent',
'  and (:P31_VORSCHRIFT_NUMMER is null  or VORSCHRIFT_NUMMER != :P31_VORSCHRIFT_NUMMER)',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_colspan=>5
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 31, accessMode => 200) = false',
'',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'DIALOG',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_item_comment=>unistr('<a alt="\00DCbergeordnete Vorschrift \00F6ffnen" title="\00DCbergeordnete Vorschrift \00F6ffnen" style="margin-left: 5px" class="a-Button a-Button--icon" href="#" target="_blank" id="bLinkParent"><span class="fa fa-search"></span></a>')
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014063862088833455)
,p_name=>'P31_VORSCHRIFT_NUMMER'
,p_is_required=>true
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>'Vorschrift Nummer'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1102)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>250
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--or (:P31_STRG_GETEX_ANZEIGE = 20 ) and  :P31_VORSCHRIFTID is null',
'',
'(pck_ri.fIsAuthorized(pageId => 31, accessMode => 200) = false',
'',
') or (:P31_STRG_GETEX_ANZEIGE = 20 )'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014063469604833455)
,p_name=>'P31_DOKUMENTENDATUM'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>'Dokumentendatum'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_display_when=>'P31_VORSCHRIFTID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Read-only when',
'NOT (:P31_MASTER = 10 AND pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0)'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014063032427833454)
,p_name=>'P31_TITEL_KURZ'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>'Titel Kurz'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014062645831833454)
,p_name=>'P31_VORSCHRIFT_BEZEICHNUNG'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>unistr('Title English (\00DCberschrift)')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>500
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(pck_ri.fIsAuthorized(pageId => 31, accessMode => 200) = false',
'',
') or (:P31_STRG_GETEX_ANZEIGE = 20 )'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014062246135833454)
,p_name=>'P31_PROGNOSE_QUALITAETID'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>unistr('Prognosequalit\00E4t Einsatztermine')
,p_post_element_text=>'&nbsp;<span onclick="redirect(1103)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VORSCHRIFT_PROGNOSE_QUALITAET'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''offen'', ''open'') AS display_value,',
'        0 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''sicher'', ''secure'') AS display_value,',
'        10 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'    ',
'    UNION ALL',
'    ',
'    SELECT ',
unistr('        emano_util.fLang(''absch\00E4tzbar'', ''estimable'') AS display_value,'),
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_cHeight=>1
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'      --pck_ri.fIsAuthorized(pageId => 31, accessMode => 200) and ',
'    (   pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0 -- Rolle VKO, Fachadm',
'            OR ( pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0 and :P31_VORSCHRIFTID is null) -- on "create"  f. Rolle Inaktive F.',
'    )',
'    ',
') = false',
'',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>'PROGNOSE_QUALITAETID'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014061844976833454)
,p_name=>'P31_FAHRZEUGKLASSE1'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(fahrzeugklasseid, '':'')',
'from t_vorschrift_ref_fahrzeugklasse',
'where vorschriftid = :P31_VORSCHRIFTID'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014061481411833454)
,p_name=>'P31_FAHRZEUGKLASSE'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fahrzeugart'
,p_post_element_text=>'&nbsp;<span onclick="redirect(400)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(fahrzeugklasseid, '':'')',
'from t_vorschrift_ref_fahrzeugklasse',
'where vorschriftid = :P31_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung d, fahrzeugklasseid r',
'from t_fahrzeugklasse',
'order by bezeichnung asc'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>'nvl(:P31_VORSCHRIFT_TYPID,10) != 20'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(pck_ri.fIsAuthorized(pageId => 31, accessMode => 200) = false',
'',
') ',
'or (:P31_STRG_GETEX_ANZEIGE = 20 )',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014061017579833453)
,p_name=>'P31_FAHRZEUGKLASSE_SUPP'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>'Fahrzeugklassen'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(fk.bezeichnung, '', '')',
'from t_vorschrift_ref_fahrzeugklasse vrf',
'join t_fahrzeugklasse fk on (fk.fahrzeugklasseid = vrf.fahrzeugklasseid)',
'where vorschriftid = :P31_PARENT_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P31_VORSCHRIFT_TYPID'
,p_display_when2=>'20'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014060643776833453)
,p_name=>'P31_VORSCHRIFT_FREIGABESTATUSID'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_item_default=>'1'
,p_prompt=>'Interner DB Freigabestatus'
,p_post_element_text=>'&nbsp;<span onclick="redirect(281)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VORSCHRIFT_FREIGABE_STATUS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vorschrift_freigabestatusid as actual_value, emano_util.fLang(name_deutsch,name_englisch) as display_value',
'from t_vorschrift_freigabestatus',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014060252270833453)
,p_name=>'P31_VORSCHRIFT_STATUSID'
,p_is_required=>true
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_item_default=>'20'
,p_prompt=>'Status der Vorschrift'
,p_post_element_text=>'&nbsp;<span onclick="redirect(181)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select status, vorschrift_statusid',
'from t_vorschrift_status',
'order by 2'))
,p_cHeight=>1
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(pck_ri.fIsAuthorized(pageId => 31, accessMode => 200) = false',
'',
') or (:P31_STRG_GETEX_ANZEIGE = 20 )'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014059864580833453)
,p_name=>'P31_RXSWIN'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_item_default=>'20'
,p_prompt=>'Potentiell SUMS-relevant'
,p_post_element_text=>'&nbsp;<span onclick="redirect(184)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Nicht gepr\00FCft'', ''Not checked'') AS display_value,'),
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_colspan=>2
,p_grid_column=>1
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  1 from t_vorschrift tv',
' where (tv.publisher = ''UNECE'' ',
' or tv.vorschriftid in (select distinct (vrl.vorschriftid)   ',
'                        from t_vorschrift_ref_land vrl',
'left outer join t_land la on (vrl.landid = la.landid)',
'where vrl.vorschriftid = tv.vorschriftid and vrl.geloescht !=1',
'and SUMS_RELEVANT =10))',
'and tv.vorschriftid = :P31_VORSCHRIFTID',
'and pck_ri.fIsUserInRolle(listRolleId => ''1000:1002:1003'') > 0',
'',
'',
'',
''))
,p_read_only_when_type=>'NOT_EXISTS'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014059448016833453)
,p_name=>'P31_SWR_HAUPTUMSETZENDE_OE'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>'OE2 des REV'
,p_post_element_text=>'&nbsp;<span onclick="redirect(461)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct swr_hauptumsetzende_oe ',
'  from t_vorschrift',
' where swr_hauptumsetzende_oe is not null'))
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_grid_column=>3
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'  (  ',
'      pck_ri.fIsUserInRolle(listRolleId => ''1000:1002:1003'') > 0 ) -- Rolle VKO, VEX, Fachadm',
') = false',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'fetch_on_type', 'N',
  'match_type', 'CONTAINS_IGNORE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014059020624833451)
,p_name=>'P31_COP_RELEVANT'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_item_default=>'20'
,p_prompt=>'CoP Relevant'
,p_post_element_text=>'&nbsp;<span onclick="redirect(201)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Nicht gepr\00FCft'', ''Not checked'') AS display_value,'),
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_begin_on_new_line=>'N'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'  (  ',
'       pck_ri.fIsUserInRolle(listRolleId => ''1003:1000:1002:1001'') > 0) -- Fachadmin, VKO, VEX, PRI USER (L&B roles)',
') = false'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014058668571833451)
,p_name=>'P31_HOMOLOGATIONSRELEVANT'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_item_default=>'20'
,p_prompt=>'Homologationsrelevant'
,p_post_element_text=>'&nbsp;<span onclick="redirect(282)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Ja'', ''Yes'') AS display_value, ',
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Nein'', ''No'') AS display_value,',
'        0 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''Nicht gepr\00FCft'', ''Not checked'') AS display_value,'),
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
') ',
'ORDER BY sort_order;',
''))
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'  (  pck_ri.fIsAuthorized(pageId => 31, accessMode => 200) and ',
'                            pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0) -- Rolle VKO, Fachadm',
') = false',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014058312020833451)
,p_name=>'P31_HOMOLOGATIONSEIGENSCHAFTEN'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Homologationseigenschaften'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte1 as (',
'    select distinct e.EIGENSCHAFT_KENNUNG || ''-'' || et.kuerzel || ''-'' || e.eigenschaft as eigenschaft',
'    from t_vorschrift_ref_thema vtl',
'    join carmah2_admin.t_eigenschaft_ref_regindexthemen err on (vtl.themaid = err.regindex_themen_id)',
'    join carmah2_admin.t_eigenschaft e on (err.eigenschaft_id = e.eigenschaft_id)',
'    join carmah2_admin.t_eigenschaft_typ et on (e.eigenschaft_typ_id = et.eigenschaft_typ_id)',
'    where vtl.vorschriftid = :P31_VORSCHRIFTID and geloescht = 0',
')',
'select listagg(eigenschaft,'', '') within group (order by eigenschaft)',
'from cte1',
'',
'',
'',
'--e.EIGENSCHAFT_KENNUNG || ''-'' || et.kuerzel || ''-'' || e.eigenschaft'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014057832477833450)
,p_name=>'P31_REV_NOTWENDIG'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_item_default=>'10'
,p_prompt=>'REV Notwendig'
,p_post_element_text=>'&nbsp;<span onclick="redirect(202)" style="font-size:2em; margin-top:24px" class="fa fa-info-square-o"></span>'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_REV_NOTWENDIG'
,p_lov=>'.'||wwv_flow_imp.id(646432047862271176)||'.'
,p_display_when_type=>'NEVER'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'  (  --pck_ri.fIsAuthorized(pageId => 31, accessMode => 200) and ',
'                            pck_ri.fIsUserInRolle(listRolleId => ''1000:1002:1003'') > 0) -- Rolle VKO, VEX, Fachadm',
') = false',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014057438745833450)
,p_name=>'P31_BEMERKUNG'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>'Bemerkung zur Vorschrift'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1104)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>1024
,p_cHeight=>4
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'  (  pck_ri.fIsAuthorized(pageId => 31, accessMode => 200) and ',
'             (  pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0',
'                OR ( pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0 and :P31_VORSCHRIFTID is null) -- on "create"  f. Rolle Inaktive F.',
'            )',
'    ) -- Rolle VKO, Fachadm',
') = false',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014057105389833450)
,p_name=>'P31_BEMERKUNG_ENGLISCH'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>'Bemerkung zur Vorschrift English'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1104)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_begin_on_new_line=>'N'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'  (  pck_ri.fIsAuthorized(pageId => 31, accessMode => 200) and ',
'        ( pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') > 0',
'          OR ( pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0 and :P31_VORSCHRIFTID is null) -- on "create"  f. Rolle Inaktive F.',
'         )',
'  ) -- Rolle VKO, Fachadm',
') = false',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014056707742833449)
,p_name=>'P31_GETEX_URL'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Zum Dokument (GETEX2-URL)'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pck_ri.fcreateLinkIfUrl(url_getex_vorschrift, 512)',
'from t_vorschrift ',
'where vorschriftid = :P31_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="text-decoration: underline; text-decoration-style: dashed"'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014056292826833449)
,p_name=>'P31_LINK_ZUR_VORSCHRIFT_DMS'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>'Link zu DMS (Ein Link pro Zeile)'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1105)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>1024
,p_cHeight=>3
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'(',
'  (  pck_ri.fIsAuthorized(pageId => 31, accessMode => 200) and ',
'       pck_ri.fIsUserInRolle(listRolleId => ''1000'') > 0) -- Rolle VKO',
') = false',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>'&nbsp;'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014055867644833449)
,p_name=>'P31_LINK_REQMAN_RO'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Link zu REQMAN'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1107)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PCK_RI.fCreateLinkIfUrl(v.link_reqman, 80)',
'from t_vorschrift v',
'where v.vorschriftid = :P31_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="text-decoration: underline; text-decoration-style: dashed"'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_display_when=>'false'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML_UNSAFE',
  'send_on_page_submit', 'N')).to_clob
,p_item_comment=>'resd only - tem is null - edit mode '
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014055470516833449)
,p_name=>'P31_WEBSITELINK_RO'
,p_item_sequence=>390
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>'Link zu Web Site'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1108)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'style="text-decoration: underline; text-decoration-style: dashed"'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 31, accessMode => 200) = false',
'',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  pck_ri.fcreateLinkIfUrl(websitelink,80)',
'from t_vorschrift v',
'where v.vorschriftid = :P31_VORSCHRIFTID'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014055111176833448)
,p_name=>'P31_KSU'
,p_item_sequence=>410
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>'KSU'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN k.bezeichnung',
'        ELSE k.name_eng',
'    END AS bezeichnung, ',
'    k.ksuid',
'FROM t_ksu k',
'ORDER BY ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN k.bezeichnung',
'        ELSE k.name_eng',
'    END;',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when=>'true'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014054691825833448)
,p_name=>'P31_IN_KRAFT_DATUM_SUPPLEMENT'
,p_item_sequence=>420
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_use_cache_before_default=>'NO'
,p_prompt=>'In Kraft'
,p_format_mask=>'DD.MM.YYYY'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vredt.einsatzdatum',
'from T_VORSCHRIFT_REF_EINSATZDATUM_TYP vredt',
'where  vredt.vorschriftid = :P31_VORSCHRIFTID',
'    AND vredt.einsatzdatum_typid = 1000;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>'P31_VORSCHRIFT_TYPID'
,p_display_when2=>'20'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 31, accessMode => 200) = false',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014054297959833448)
,p_name=>'P31_TYPSCHILD'
,p_item_sequence=>430
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>'Typschild'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(typschild, '', '') within group(order by typschild)',
'from (',
'    select distinct l.typschild',
'    from T_VORSCHRIFT_REF_LAND ttl',
'    inner join T_LAND l on l.landid = ttl.landid',
'    where ttl.vorschriftid = :P31_VORSCHRIFTID and ttl.geloescht = 0',
');'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Rolle inakt. Funktionen',
'(pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0) = true',
'',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>unistr('Nur f\00FCr Administratoren sichtbar')
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014053343205833447)
,p_name=>'P31_TECHNOLOGIE'
,p_item_sequence=>440
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>'Technologie'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct technologie from t_vorschrift',
'order by technologie'))
,p_cSize=>30
,p_cMaxlength=>256
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Rolle inaktive Funktionen',
'(pck_ri.fIsUserInRolle(listRolleId => 1080) > 0)',
'',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'  (  pck_ri.fIsAuthorized(pageId => 31, accessMode => 200) /* and ',
'                            pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0*/) -- Rolle inaktive Funktionen',
') = false',
'  '))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'fetch_on_type', 'Y',
  'match_type', 'CONTAINS_IGNORE',
  'min_chars', '2',
  'use_cache', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014052969040833447)
,p_name=>'P31_STICHWOERTER'
,p_item_sequence=>450
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Stichw\00F6rter')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(sw.stext,  '', '') within group (order by sw.stext)',
'    from t_vorschrift_ref_schlagwort vrs',
'    join t_schlagwort sw on (sw.schlagwortid = vrs.schlagwortid)',
'   where vrs.vorschriftid = :P31_VORSCHRIFTID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014052569381833446)
,p_name=>'P31_INHALTLICH_SACHLICH_GEPRUEFT'
,p_item_sequence=>460
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>unistr('inhaltlich sachlich gepr\00FCft')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_INHALTLICH_SACHLICH_GEPRUEFT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
unistr('        emano_util.fLang(''nicht gepr\00FCft'', ''not checked'') AS display_value,'),
'        10 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''n.i.O gepr\00FCft'', ''checked n.i.O'') AS display_value,'),
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
unistr('        emano_util.fLang(''i.O gepr\00FCft'', ''checked i.O'') AS display_value,'),
'        30 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_display_when=>'pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014052155232833446)
,p_name=>'P31_DOCUMENT_TYPE'
,p_item_sequence=>470
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Document Type'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select emano_util.flang(dt.text_deutsch, dt.text_englisch)',
'from t_vorschrift v',
'join t_document_type dt on (v.document_typeid = dt.document_typeid)',
'where v.vorschriftid = :P31_VORSCHRIFTID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P31_VORSCHRIFTID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1014051784492833446)
,p_name=>'P31_LINK'
,p_item_sequence=>480
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1013003762825994328)
,p_name=>'P31_WEBSITELINK_RO_1'
,p_item_sequence=>400
,p_item_plug_id=>wwv_flow_imp.id(14417264557455729340)
,p_prompt=>'Link zu Web Site'
,p_post_element_text=>'&nbsp;<span onclick="redirect(1108)" style="font-size:2em" class="fa fa-info-square-o"></span>'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT w.WEBSITE_NAME, w.WEBSITEID',
'FROM T_WEBSITE w',
'ORDER BY 1',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_tag_attributes=>'style="text-decoration: underline; text-decoration-style: dashed"'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_display_when_type=>'NEVER'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri.fIsAuthorized(pageId => 31, accessMode => 200) = false',
'',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  pck_ri.fcreateLinkIfUrl(websitelink,80)',
'from t_vorschrift v',
'where v.vorschriftid = :P31_VORSCHRIFTID'))
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1014049356484833419)
,p_validation_name=>'Vorschrift Nummer unique (neuanlage)'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from t_vorschrift where trim(vorschrift_nummer) = trim(:P31_VORSCHRIFT_NUMMER) ',
'and  ( dokumentendatum is null and  :P31_DOKUMENTENDATUM is null  ',
'       OR to_char(dokumentendatum, ''dd.mm.yyyy'') = :P31_DOKUMENTENDATUM ',
'     )'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Es existiert bereits eine Vorschrift mit dieser Nummer!'
,p_validation_condition=>'P31_VORSCHRIFT_TYPID'
,p_validation_condition2=>'20'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(1014050691639833435)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1014048924306833419)
,p_validation_name=>'Vorschrift Nummer unique (edit)'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from t_vorschrift where trim(vorschrift_nummer) = trim(:P31_VORSCHRIFT_NUMMER) and vorschriftid != :P31_VORSCHRIFTID',
'and  ( dokumentendatum is null and  :P31_DOKUMENTENDATUM is null  ',
'       OR to_char(dokumentendatum, ''dd.mm.yyyy'') = :P31_DOKUMENTENDATUM ',
'     )'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Es existiert bereits eine Vorschrift mit dieser Nummer!'
,p_always_execute=>'Y'
,p_validation_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- evaluation nur wenn getex key (regindexid) is null',
'(select count(*) from T_vorschrift ',
'  where vorschriftid = :P31_VORSCHRIFTID ',
'  and regindexid is null) >0'))
,p_validation_condition2=>'SQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(1014049867445833434)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1014048544461833419)
,p_validation_name=>'Validate Supplement Parent'
,p_validation_sequence=>30
,p_validation=>'(:P31_VORSCHRIFT_TYPID != 20 or  :P31_PARENT_VORSCHRIFTID is not null)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Supplement muss eine \00FCbergeordnete Vorschrift haben.')
,p_when_button_pressed=>wwv_flow_imp.id(1014050691639833435)
,p_associated_item=>wwv_flow_imp.id(1014064263597833455)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1014044662329833413)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1014051049115833440)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1014044123235833409)
,p_event_id=>wwv_flow_imp.id(1014044662329833413)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1014043726318833409)
,p_name=>'SET GETEX Logo'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(20 = :P31_STRG_GETEX_ANZEIGE ) ',
''))
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1014043311204833408)
,p_event_id=>wwv_flow_imp.id(1014043726318833409)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'#P31_EINSATZDATUM_MODELLID_DISPLAY,#P31_VORSCHRIFT_TYPID_DISPLAY,#P31_FAHRZEUGKLASSE_DISPLAY,#P31_VORSCHRIFT_STATUSID_DISPLAY,#rEinsatzdaten .t-Region-header,#rLaender .t-Region-header,#rThemen .t-Region-header'
,p_attribute_01=>'getexlogo'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1014042778144833408)
,p_event_id=>wwv_flow_imp.id(1014043726318833409)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'#P31_VORSCHRIFT_NUMMER_DISPLAY,#P31_VORSCHRIFT_BEZEICHNUNG_DISPLAY,#P31_TITEL_KURZ_DISPLAY'
,p_attribute_01=>'getexlogo'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1014042358651833408)
,p_name=>'Typ Supplement UN-R'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P31_VORSCHRIFT_TYPID'
,p_condition_element=>'P31_VORSCHRIFT_TYPID'
,p_triggering_condition_type=>'IN_LIST'
,p_triggering_expression=>'20'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1014041828465833408)
,p_event_id=>wwv_flow_imp.id(1014042358651833408)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_EINSATZDATUM_MODELLID,P31_TYPSCHILD,P31_IN_KRAFT_DATUM_SUPPLEMENT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1014041395896833407)
,p_event_id=>wwv_flow_imp.id(1014042358651833408)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_PARENT_VORSCHRIFTID, P31_FAHRZEUGKLASSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1014040963280833407)
,p_name=>'Typ Vorschrift'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P31_VORSCHRIFT_TYPID'
,p_condition_element=>'P31_VORSCHRIFT_TYPID'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'10'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1014040485141833407)
,p_event_id=>wwv_flow_imp.id(1014040963280833407)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_EINSATZDATUM_MODELLID,P31_PROGNOSE_QUALITAETID,P31_VORSCHRIFT_FREIGABESTATUSID,P31_TYPSCHILD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1014039963589833407)
,p_event_id=>wwv_flow_imp.id(1014040963280833407)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_PARENT_VORSCHRIFTID, P31_IN_KRAFT_DATUM_SUPPLEMENT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1013839613971833406)
,p_name=>'Typ Norm'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P31_VORSCHRIFT_TYPID'
,p_condition_element=>'P31_VORSCHRIFT_TYPID'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'40'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013839049955833406)
,p_event_id=>wwv_flow_imp.id(1013839613971833406)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_EINSATZDATUM_MODELLID,P31_PROGNOSE_QUALITAETID,P31_VORSCHRIFT_FREIGABESTATUSID,P31_TYPSCHILD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013838534803833406)
,p_event_id=>wwv_flow_imp.id(1013839613971833406)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_PARENT_VORSCHRIFTID, P31_IN_KRAFT_DATUM_SUPPLEMENT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1013838196420833406)
,p_name=>'Typ Rahmenrichtlinie'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P31_VORSCHRIFT_TYPID'
,p_condition_element=>'P31_VORSCHRIFT_TYPID'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'30'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013837703031833406)
,p_event_id=>wwv_flow_imp.id(1013838196420833406)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_EINSATZDATUM_MODELLID,P31_PROGNOSE_QUALITAETID,P31_VORSCHRIFT_FREIGABESTATUSID,P31_TYPSCHILD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013837201837833406)
,p_event_id=>wwv_flow_imp.id(1013838196420833406)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_PARENT_VORSCHRIFTID, P31_IN_KRAFT_DATUM_SUPPLEMENT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1013836722277833405)
,p_name=>'New Parent'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P31_PARENT_VORSCHRIFTID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013836229916833405)
,p_event_id=>wwv_flow_imp.id(1013836722277833405)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lRowid rowid;',
'begin',
'    if (:P31_PARENT_VORSCHRIFTID is not null) then',
'        select rowid into lRowid from t_vorschrift where vorschriftid = :P31_PARENT_VORSCHRIFTID;',
'        :P31_LINK := apex_page.get_url(p_page => 25,p_items => ''P25_ROWID'', p_values => lRowid, p_clear_cache => 25);',
'    else',
'        :P31_LINK := null;',
'    end if;',
'    ',
'',
'',
'end;',
'',
''))
,p_attribute_02=>'P31_PARENT_VORSCHRIFTID'
,p_attribute_03=>'P31_LINK'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013835808584833405)
,p_event_id=>wwv_flow_imp.id(1013836722277833405)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var link = $v(''P31_LINK'');',
'if (link) {',
'    $(''#bLinkParent'').attr(''href'',$v(''P31_LINK'')).show();',
'} else {',
'    $(''#bLinkParent'').hide();',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1013835408267833405)
,p_name=>'Check ASCII'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P31_VORSCHRIFT_NUMMER'
,p_condition_element=>'P31_VORSCHRIFT_NUMMER'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013834909063833404)
,p_event_id=>wwv_flow_imp.id(1013835408267833405)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_VORSCHRIFT_NUMMER'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var ostr =  apex.item("P31_VORSCHRIFT_NUMMER").getValue();',
'var nstr ="";',
'var mark_on = 0;',
'var any_no_ascii =0;',
'for (var ic = 0; ic < ostr.length; ic++)',
'{',
'  if ( ostr.charCodeAt(ic) !== null && ostr.charCodeAt(ic) > 128  )',
'  {',
'      if( nstr == null)',
'      {',
'          //if(mark_on == 0) // always true',
'          //{',
'            nstr += "<mark>";',
'            mark_on = 1;',
'         // }',
'            nstr += ostr.charAt(ic) ;',
'      }',
'      else',
'      {',
'          if(mark_on == 0)',
'          {',
'             nstr += "<mark>" + ostr.charAt(ic) ;',
'              mark_on = 1;',
'          }',
'          else',
'          {',
'              nstr += ostr.charAt(ic) ;',
'          }',
'      }',
'      any_no_ascii=1;',
'  }',
'  else',
'  {',
'      if(mark_on == 1)',
'      {',
'          nstr += "</mark>";',
'          mark_on = 0;',
'      }',
'      if(nstr == null)',
'          nstr = ostr.charAt(ic);',
'      else',
'          nstr += ostr.charAt(ic);',
'  }',
'}',
'',
'if(mark_on == 1)',
'{    ',
'     nstr += "</mark>";   ',
'}',
'',
'if(any_no_ascii == 1)',
unistr('     $(''#P31_VORSCHRIFT_NUMMER_inline_help'').html(nstr + ''   - <span style ="color:red"><b>Die von Ihnen eingegeben Vorschriftennummer enth\00E4lt einige nicht unterst\00FCtzte Sonderzeichen. Bitte \00E4ndern Sie die gelb hervorgehobenen Sonderzeichen bis die Me')
||'ldung nicht mehr erscheint.</b></span>'');',
'else',
'     $(''#P31_VORSCHRIFT_NUMMER_inline_help'').html('' '');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1013834451235833404)
,p_name=>'Change'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P31_RXSWIN'
,p_condition_element=>'P31_RXSWIN'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'10'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013833978348833404)
,p_event_id=>wwv_flow_imp.id(1013834451235833404)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_SWR_HAUPTUMSETZENDE_OE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013833273576833388)
,p_event_id=>wwv_flow_imp.id(1013834451235833404)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_SWR_HAUPTUMSETZENDE_OE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013832812552833388)
,p_event_id=>wwv_flow_imp.id(1013834451235833404)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_REV_NOTWENDIG'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013832287939833388)
,p_event_id=>wwv_flow_imp.id(1013834451235833404)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_SWR_HAUPTUMSETZENDE_OE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013831758577833387)
,p_event_id=>wwv_flow_imp.id(1013834451235833404)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_REV_NOTWENDIG'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'10'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013831285272833387)
,p_event_id=>wwv_flow_imp.id(1013834451235833404)
,p_event_result=>'FALSE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_REV_NOTWENDIG'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1013830836405833387)
,p_name=>'homologationsrelevant?'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P31_HOMOLOGATIONSRELEVANT'
,p_condition_element=>'P31_HOMOLOGATIONSRELEVANT'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'10'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013830341815833387)
,p_event_id=>wwv_flow_imp.id(1013830836405833387)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_HOMOLOGATIONSEIGENSCHAFTEN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013829914624833387)
,p_event_id=>wwv_flow_imp.id(1013830836405833387)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_HOMOLOGATIONSEIGENSCHAFTEN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1013829501707833386)
,p_name=>'Change Einsatz DATUM Modell'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P31_EINSATZDATUM_MODELLID'
,p_condition_element=>'P31_EINSATZDATUM_MODELLID'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'30'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013828939407833386)
,p_event_id=>wwv_flow_imp.id(1013829501707833386)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_DATUM_ANGABE_AS_MJ,P31_PHASEIN_ENTHALTEN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013828457738833386)
,p_event_id=>wwv_flow_imp.id(1013829501707833386)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_DATUM_ANGABE_AS_MJ,P31_PHASEIN_ENTHALTEN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1013828062521833386)
,p_name=>'A_EINSATZDATUM_MODELL_CHANGED'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P31_EINSATZDATUM_MODELLID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1013827449650833385)
,p_event_id=>wwv_flow_imp.id(1013828062521833386)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Die \00C4nderung des ''Einsatz DATUM Modells'' erfordert eine Speicherung der Vorschrift.'),
'',
unistr('Die Bearbeitung abseits der Kerndaten nicht m\00F6glich.')))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3095363334033678210)
,p_name=>'onChange'
,p_event_sequence=>160
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P31_SYNC_OE2_DES_REV'
,p_condition_element=>'P31_SYNC_OE2_DES_REV'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'20'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3095363241979678209)
,p_event_id=>wwv_flow_imp.id(3095363334033678210)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_SWR_HAUPTUMSETZENDE_OE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3095363146031678208)
,p_event_id=>wwv_flow_imp.id(3095363334033678210)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P31_SWR_HAUPTUMSETZENDE_OE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1014047027068833418)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'check_letzte_Aenderung_GETEX_attr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'     l_any_attr_changed number :=0;',
'begin',
'   -- debug(''Seite 31'', ''Rowstatus: '' || :APEX$ROW_STATUS);',
'    if(:P31_VORSCHRIFTID is not null ) then   --and :P31_VORSCHRIFT_TYPID <> 20) then',
'        -- debug('' P31_EINSATZDATUM_MODELLID: '' || :P31_EINSATZDATUM_MODELLID);',
unistr('        -- wird erst f\00FCr naechste entwicklungsstufe vorgesehen --------'),
'         if (   pck_ri_getex.fIsEinsatzdatumModelChanging(:P31_VORSCHRIFTID, :P31_EINSATZDATUM_MODELLID) >0',
'             OR',
'              pck_ri_getex.fIsFzgKlasseListChanging(:P31_VORSCHRIFTID, :P31_FAHRZEUGKLASSE) >0 )',
'         then',
'              ',
'            update t_Vorschrift set letzte_aenderung_getex_attr = sysdate where Vorschriftid  = :P31_VORSCHRIFTID',
'            and (letzte_aenderung_getex_attr is null or letzte_aenderung_getex_attr <= sysdate - 0.0001 ); -- ca 8 sec;',
'            return;',
'         else',
'            select count (*) into l_any_attr_changed ',
'            from  T_VORSCHRIFT',
'            where  VORSCHRIFTID = :P31_VORSCHRIFTID and VORSCHRIFT_BEZEICHNUNG != :P31_VORSCHRIFT_BEZEICHNUNG;',
'            if (l_any_attr_changed >0) then',
'               update t_Vorschrift set letzte_aenderung_getex_attr = sysdate where Vorschriftid  = :P31_VORSCHRIFTID',
'               and (letzte_aenderung_getex_attr is null  or letzte_aenderung_getex_attr <= sysdate - 0.0001 );',
'               return;',
'            end if;',
'            -- Vorschr._sttatus',
'            select count (*) into l_any_attr_changed ',
'            from  T_VORSCHRIFT',
'            where  VORSCHRIFTID = :P31_VORSCHRIFTID and VORSCHRIFT_STATUSID != :P31_VORSCHRIFT_STATUSID;',
'            if (l_any_attr_changed >0) then',
'               update t_Vorschrift set letzte_aenderung_getex_attr = sysdate where Vorschriftid  = :P31_VORSCHRIFTID',
'               and (letzte_aenderung_getex_attr is null  or letzte_aenderung_getex_attr <= sysdate - 0.0001 );',
'               return;',
'            end if;',
'           -- Vorschr.-nummer',
'            select count (*) into l_any_attr_changed ',
'            from  T_VORSCHRIFT',
'            where  VORSCHRIFTID = :P31_VORSCHRIFTID and VORSCHRIFT_NUMMER != :P31_VORSCHRIFT_NUMMER;',
'            if (l_any_attr_changed >0) then',
'               update t_Vorschrift set letzte_aenderung_getex_attr = sysdate where Vorschriftid  = :P31_VORSCHRIFTID',
'               and (letzte_aenderung_getex_attr is null  or letzte_aenderung_getex_attr <= sysdate - 0.0001 );',
'               return;',
'            end if;',
'            -- Vorschr._-typ',
'            select count (*) into l_any_attr_changed ',
'            from  T_VORSCHRIFT',
'            where  VORSCHRIFTID = :P31_VORSCHRIFTID and VORSCHRIFT_TYPID != :P31_VORSCHRIFT_TYPID;',
'            if (l_any_attr_changed >0) then',
'               update t_Vorschrift set letzte_aenderung_getex_attr = sysdate where Vorschriftid  = :P31_VORSCHRIFTID',
'               and (letzte_aenderung_getex_attr is null  or letzte_aenderung_getex_attr <= sysdate - 0.0001 );',
'               return;',
'            end if;',
'',
'         end if;',
'',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1014049867445833434)
,p_internal_uid=>2658165288830554817
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1014045051497833416)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process Row of T_VORSCHRIFT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  lInKraft number default 1;',
'  exc_not_saved exception;',
'  lPublisherID number;',
'  PRAGMA exception_init( exc_not_saved, -20101 );',
'begin',
'',
'    begin',
'        select publisherid into lPublisherID',
'        from t_publisher',
'        where name = :P31_PUBLISHER;',
'    exception',
'        when others then',
'            lPublisherID := null;',
'    end;',
'',
'',
'  if :P31_VORSCHRIFTID is null then',
'    -- INSERT new record',
'    insert into t_vorschrift (',
'        vorschrift_nummer',
'        , titel_kurz',
'        , vorschrift_bezeichnung',
'        , dokumentendatum',
'        , prognose_qualitaetid',
'        , vorschrift_freigabestatusid',
'        , bemerkung',
'        , bemerkung_englisch',
'        , link_zur_vorschrift_dms',
'        -- , websiteid',
'        , websitelink',
'        , einsatzdatum_modellid',
'        , vorschrift_typid',
'        , ksuid',
'        , vorschrift_statusid',
'        , homologationsrelevant',
'        , rxswin',
'        , cop_relevant',
'        , rev_notwendig',
'        , technologie',
'        , swr_hauptumsetzende_oe',
'        , inhaltlich_sachlich_geprueft',
'        , master',
'        , status_update_getex',
'        , mj_schalter_status',
'        , phasein_enthalten',
'        , revisionszaehler',
'        , letzte_aenderung_datum',
'        , letzte_aenderung_benutzerid',
'        , publisher',
'        , publisherid',
'        , SYNC_OE2_DES_REV',
'    ) VALUES (',
'        TRIM(:P31_VORSCHRIFT_NUMMER)',
'        , :P31_TITEL_KURZ',
'        , :P31_VORSCHRIFT_BEZEICHNUNG',
'        , CASE WHEN TRIM(:P31_DOKUMENTENDATUM) IS NOT NULL THEN TO_DATE(:P31_DOKUMENTENDATUM, ''DD.MM.YYYY'') ELSE NULL END',
'        , :P31_PROGNOSE_QUALITAETID',
'        , 1  -- Initial status',
'        , :P31_BEMERKUNG',
'        , :P31_BEMERKUNG_ENGLISCH',
'        , :P31_LINK_ZUR_VORSCHRIFT_DMS',
'        -- , :P31_WEBSITEID',
'        , :P31_WEBSITELINK_RO',
'        , :P31_EINSATZDATUM_MODELLID',
'        , :P31_VORSCHRIFT_TYPID',
'        , :P31_KSU',
'        , :P31_VORSCHRIFT_STATUSID',
'        , :P31_HOMOLOGATIONSRELEVANT',
'        , :P31_RXSWIN',
'        , :P31_COP_RELEVANT',
'        , case when :P31_RXSWIN = 10 then :P31_REV_NOTWENDIG else ''10'' end',
'        , :P31_TECHNOLOGIE',
'        , :P31_SWR_HAUPTUMSETZENDE_OE',
'        , nvl(:P31_INHALTLICH_SACHLICH_GEPRUEFT, 10)',
'        , :P31_MASTER',
'        , :P31_IMPORT_STATUS',
'        , :P31_DATUM_ANGABE_AS_MJ',
'        , :P31_PHASEIN_ENTHALTEN',
'        , 1  -- Initial revision counter',
'        , SYSDATE',
'        , :G_BENUTZERID',
'        , :P31_PUBLISHER',
'        , lPublisherID',
'        , :P31_SYNC_OE2_DES_REV',
'    ) RETURNING rowid, vorschriftid INTO :P31_ROWID, :P31_VORSCHRIFTID;',
'    ',
'    -- Handle parent relationship for supplements',
'    if (nvl(:P31_VORSCHRIFTID, 0) > 0 and nvl(:P31_PARENT_VORSCHRIFTID, 0) > 0) then',
'       insert into t_vorschrift_ref_vorschrift (',
'        vorgaenger_vorschriftid, nachfolger_vorschriftid, beziehung_art)',
'           values(:P31_PARENT_VORSCHRIFTID, :P31_VORSCHRIFTID, ',
'                  (case when :P31_VORSCHRIFT_TYPID = 20 then 30 else 20 end));',
'    end if;',
'  else',
'    -- UPDATE code',
'    UPDATE t_vorschrift',
'    SET vorschrift_nummer = TRIM(:P31_VORSCHRIFT_NUMMER),',
'        titel_kurz = :P31_TITEL_KURZ,',
'        vorschrift_bezeichnung = :P31_VORSCHRIFT_BEZEICHNUNG,',
'        dokumentendatum = CASE WHEN TRIM(:P31_DOKUMENTENDATUM) IS NOT NULL THEN TO_DATE(:P31_DOKUMENTENDATUM, ''DD.MM.YYYY'') ELSE NULL END,',
'        prognose_qualitaetid = :P31_PROGNOSE_QUALITAETID,',
'        -- jira_ticket = :P31_JIRA_TICKET,',
'        -- vorschrift_freigabestatusid = :P31_VORSCHRIFT_FREIGABESTATUSID,',
'        bemerkung = :P31_BEMERKUNG,',
'        bemerkung_englisch = :P31_BEMERKUNG_ENGLISCH,',
'        link_zur_vorschrift_dms = :P31_LINK_ZUR_VORSCHRIFT_DMS,',
'        -- websiteid = :P31_WEBSITEID,',
'        websitelink = :P31_WEBSITELINK_RO,',
'        einsatzdatum_modellid = :P31_EINSATZDATUM_MODELLID,',
'        vorschrift_typid = :P31_VORSCHRIFT_TYPID,',
'        ksuid = :P31_KSU,',
'        vorschrift_statusid = :P31_VORSCHRIFT_STATUSID,',
'        homologationsrelevant = :P31_HOMOLOGATIONSRELEVANT,',
'        rxswin = :P31_RXSWIN,',
'        cop_relevant = :P31_COP_RELEVANT,',
'        rev_notwendig = case when :P31_RXSWIN = 10 then :P31_REV_NOTWENDIG else ''10'' end,',
'        technologie = :P31_TECHNOLOGIE,',
'        swr_hauptumsetzende_oe = :P31_SWR_HAUPTUMSETZENDE_OE,',
'        inhaltlich_sachlich_geprueft = :P31_INHALTLICH_SACHLICH_GEPRUEFT,',
'        master = :P31_MASTER,',
'        status_update_getex = :P31_IMPORT_STATUS,',
'        ',
'        -- MJ_SCHALTER_STATUS when EINSATZDATUM_MODELLID is 30',
'        mj_schalter_status = CASE ',
'                               WHEN :P31_EINSATZDATUM_MODELLID = 30 THEN TO_NUMBER(:P31_DATUM_ANGABE_AS_MJ) ',
'                               ELSE mj_schalter_status',
'                             END,',
'',
'        phasein_enthalten = :P31_PHASEIN_ENTHALTEN,',
'',
'        revisionszaehler = revisionszaehler + 1,',
'        publisher = :P31_PUBLISHER,',
'        publisherid = lPublisherID,',
'        letzte_aenderung_datum = SYSDATE,',
'        letzte_aenderung_benutzerid = :G_BENUTZERID,',
'        SYNC_OE2_DES_REV = :P31_SYNC_OE2_DES_REV',
'    WHERE rowid = :P31_ROWID and vorschriftid = :P31_VORSCHRIFTID;',
'  end if;',
'',
'  -- Cleanup old date entries if model has changed',
'  delete from t_vorschrift_ref_einsatzdatum_typ where vorschrift_ref_einsatzdatum_typid in (',
'      select vret.vorschrift_ref_einsatzdatum_typid',
'      from t_vorschrift v',
'      join t_vorschrift_ref_einsatzdatum_typ vret on (v.vorschriftid = vret.vorschriftid)',
'      join t_einsatzdatum_typ et on (vret.einsatzdatum_typid = et.einsatzdatum_typid)',
'      where v.vorschriftid = :P31_VORSCHRIFTID and v.einsatzdatum_modellid != et.einsatzdatum_modellid and et.einsatzdatum_modellid is not null',
'  );',
'',
'EXCEPTION ',
'  WHEN OTHERS THEN',
unistr('    raise_application_error(-20101, ''Vorschrift/\00C4nderungen nicht gespeichert: '' || SQLERRM);'),
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Fehler ist aufgetretten, Vorschrift ist nicht gespeichert'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_process_success_message=>'Vorschrift gespeichert.'
,p_internal_uid=>2658167264401554819
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1014047466696833418)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_PARENT_VORSCHRIFT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--debug(''save Parent:  vorschrid '' , :P31_VORSCHRIFTID);',
'--debug(''save Parent: parent_vorschrid '' , :P31_PARENT_VORSCHRIFTID_DISPLAY);',
'if (:P31_VORSCHRIFTID is not null   and :P31_VORSCHRIFT_TYPID in (20, 50)) then',
'merge into T_VORSCHRIFT_REF_VORSCHRIFT dest',
'using (select  :P31_VORSCHRIFTID  as vorschriftid,   ',
'              :P31_PARENT_VORSCHRIFTID as parent_vorschriftid,  ',
'           case when :P31_VORSCHRIFT_TYPID =20 then 30 else 20 end as beziehung_art ',
'           from dual) src',
'    on (src.vorschriftid = dest.nachfolger_vorschriftid ',
'       and src.beziehung_art = dest.beziehung_art)',
'    when not matched then insert (',
'       dest.nachfolger_vorschriftid, ',
'       dest.vorgaenger_vorschriftid,',
'        dest.beziehung_art',
'    ) VALUES (',
'       src.vorschriftid , ',
'       src.parent_vorschriftid,',
'        src.beziehung_art',
'    )',
'    when matched then update ',
'      set dest.vorgaenger_vorschriftid = src.parent_vorschriftid;',
'end if; ',
'    ',
'    ',
'    '))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('Das Supplement konnte nicht der \00FCbergeordneten Vorschrift zugeordnet werden.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1014049867445833434)
,p_internal_uid=>2658164849202554817
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1014046289678833417)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_IN_KRAFT_DATUM_SUPPLEMENT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--debug(''In Kraft Supplement'');',
'merge into T_VORSCHRIFT_REF_EINSATZDATUM_TYP dest',
'using (select :P31_VORSCHRIFTID as vorschriftid, :P31_IN_KRAFT_DATUM_SUPPLEMENT as in_kraft_datum from dual) src',
'    on (src.vorschriftid = dest.vorschriftid ',
'       and 1000 = dest.einsatzdatum_typid)',
'    when matched then update set ',
'        dest.einsatzdatum = src.in_kraft_datum',
'    when not matched then insert (',
'       vorschriftid, ',
'       einsatzdatum,',
'       einsatzdatum_typid',
'    ) VALUES (',
'       src.vorschriftid,',
'       src.in_kraft_datum,',
'       1000',
'    );',
'    ',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P31_VORSCHRIFTID is not null ',
'  and :P31_VORSCHRIFT_TYPID = 20)'))
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>2658166026220554818
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1014046644283833417)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Fahrzeugklasse - Save Tag Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--debug(''Fahrzeugklasse Vorschrift'');',
'merge into T_VORSCHRIFT_REF_FAHRZEUGKLASSE dest',
'using (select :P31_VORSCHRIFTID as vorschriftid, column_value as fahrzeugklasseid ',
'       from table (apex_string.split_numbers(:P31_FAHRZEUGKLASSE, '':''))) src',
'    on (src.vorschriftid = dest.vorschriftid ',
'       and src.fahrzeugklasseid = dest.fahrzeugklasseid)',
'    when not matched then insert (',
'       vorschriftid, ',
'       fahrzeugklasseid',
'    ) VALUES (',
'       src.vorschriftid,',
'       src.fahrzeugklasseid',
'    );',
'    ',
'delete from T_VORSCHRIFT_REF_FAHRZEUGKLASSE',
'where vorschriftid = :P31_VORSCHRIFTID',
'    and fahrzeugklasseid not in (',
'        select column_value',
'        from table(apex_string.split_numbers(:P31_FAHRZEUGKLASSE, '':''))',
'    );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P31_VORSCHRIFTID is not null ',
'  and :P31_VORSCHRIFT_TYPID IN (10,40,30) and :REQUEST = ''SAVE'' )'))
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>2658165671615554818
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1014045899852833417)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Check & Set Getex Status'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--pck_ri_getex.pVergleichAttributevonGetex(:P31_VORSCHRIFTID);',
'pck_ri_getex.pCompareVorschrift(:P31_VORSCHRIFTID);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2658166416046554818
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1014048282157833419)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Recalculate Cockpit and GETEX Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P31_VORSCHRIFTID IS NOT NULL THEN',
'        PCK_RI_GETEX_CTRL.pRecalculateGetexAndCockpitData(:P31_VORSCHRIFTID);',
'    END IF;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_debug.error(''Recalculation error: '' || SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2658164033741554816
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(910177187067695932)
,p_process_sequence=>120
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Pr\00FCfe Nicht-Relevant Automatismus')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P31_VORSCHRIFTID IS NOT NULL THEN',
'        PCK_RI_NICHT_RELEVANT.P_PRUEFE_VORSCHRIFT(:P31_VORSCHRIFTID);',
'    END IF;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_debug.error(''Nicht-Relevant check error: '' || SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2762035128831692303
,p_process_comment=>'SAVE,CREATE - reqw cionatindd invaleus '
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1014047893080833418)
,p_process_sequence=>130
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>2658164422818554817
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1014045497222833417)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Kerndaten Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  l_vorschrift_exists NUMBER;',
'BEGIN',
'  -- Check if this is a CREATE operation',
'  --IF :REQUEST = ''CREATE'' OR (',
'      if :P31_VORSCHRIFTID IS NULL  THEN',
'    -- This is a new record, set defaults',
'    :P31_VORSCHRIFTID := NULL;',
'    :P31_ROWID := NULL;',
'    :P31_VORSCHRIFT_FREIGABESTATUSID := 1;',
'    :P31_VORSCHRIFT_STATUSID := 20;',
'    :P31_PROGNOSE_QUALITAETID := 0;',
'    :P31_RXSWIN := 20;',
'    :P31_COP_RELEVANT := 20;',
'    :P31_HOMOLOGATIONSRELEVANT := 20;',
'    :P31_INHALTLICH_SACHLICH_GEPRUEFT := 10;',
'    :P31_MASTER := 10;',
'    :P31_KSU := 1020;',
'    -- :P31_VORSCHRIFT_TYPID := 10; -- Default to regular Vorschrift',
'    :P31_EINSATZDATUM_MODELLID := 10; -- Default model',
'    :P31_IMPORT_STATUS := 30; -- Default import status',
'    :P31_DATUM_ANGABE_AS_MJ := 0; -- Default to no model year',
'    :P31_PHASEIN_ENTHALTEN := 0;  -- Default to no phase-in',
'    :P31_STRG_GETEX_ANZEIGE := 10; -- Default display setting',
'    ',
'    -- Initialize empty fields',
'    :P31_VORSCHRIFT_NUMMER := NULL;',
'    :P31_TITEL_KURZ := NULL;',
'    :P31_VORSCHRIFT_BEZEICHNUNG := NULL;',
'    :P31_DOKUMENTENDATUM := NULL;',
'    :P31_SWR_HAUPTUMSETZENDE_OE := NULL;',
'    :P31_BEMERKUNG := NULL;',
'    :P31_BEMERKUNG_ENGLISCH := NULL;',
'    :P31_LINK_ZUR_VORSCHRIFT_DMS := NULL;',
'    :P31_GETEX_URL := NULL;',
'',
'    :P31_WEBSITELINK_RO := NULL;',
'    :P31_TECHNOLOGIE := NULL;',
'    :P31_PARENT_VORSCHRIFTID := NULL;',
'    :P31_FAHRZEUGKLASSE := NULL;',
'    :P31_IN_KRAFT_DATUM_SUPPLEMENT := NULL;',
'    :P31_SYNC_OE2_DES_REV := 10;',
'    ',
'    -- Don''t try to load data for new records',
'    RETURN;',
'  END IF;',
'',
'  ',
'  if :P31_VORSCHRIFTID is not null then',
'    -- Load all fields from the main table',
'    BEGIN',
'      SELECT',
'      rowid ,',
'      vorschriftid,',
'        vorschrift_nummer,',
'        titel_kurz,',
'        vorschrift_bezeichnung,',
'        vorschrift_typid,',
'        einsatzdatum_modellid,',
'        prognose_qualitaetid,',
'        vorschrift_statusid,',
'        vorschrift_freigabestatusid,',
'        master,',
'        status_update_getex,',
'        rxswin,',
'        swr_hauptumsetzende_oe,',
'        cop_relevant,',
'        homologationsrelevant,',
'        bemerkung,',
'        bemerkung_englisch,',
'        link_zur_vorschrift_dms,',
'        url_getex_vorschrift,',
'',
'        websitelink,',
'        ksuid,',
'        technologie,',
'        inhaltlich_sachlich_geprueft,',
'        DOKUMENTENDATUM,',
'        mj_schalter_status,',
'        phasein_enthalten,',
'        SYNC_OE2_DES_REV ',
'',
'      INTO',
'       :P31_ROWID,',
'       :P31_VORSCHRIFTID,',
'        :P31_VORSCHRIFT_NUMMER,',
'        :P31_TITEL_KURZ,',
'        :P31_VORSCHRIFT_BEZEICHNUNG,',
'        :P31_VORSCHRIFT_TYPID,',
'        :P31_EINSATZDATUM_MODELLID,',
'        :P31_PROGNOSE_QUALITAETID,',
'        :P31_VORSCHRIFT_STATUSID,',
'        :P31_VORSCHRIFT_FREIGABESTATUSID,',
'        :P31_MASTER,',
'        :P31_IMPORT_STATUS,',
'        :P31_RXSWIN,',
'        :P31_SWR_HAUPTUMSETZENDE_OE,',
'        :P31_COP_RELEVANT,',
'        :P31_HOMOLOGATIONSRELEVANT,',
'        :P31_BEMERKUNG,',
'        :P31_BEMERKUNG_ENGLISCH,',
'        :P31_LINK_ZUR_VORSCHRIFT_DMS,',
'        :P31_GETEX_URL,',
'',
'        :P31_WEBSITELINK_RO,',
'        :P31_KSU,',
'        :P31_TECHNOLOGIE,',
'        :P31_INHALTLICH_SACHLICH_GEPRUEFT,',
'        :P31_DOKUMENTENDATUM,',
'        :P31_DATUM_ANGABE_AS_MJ,',
'        :P31_PHASEIN_ENTHALTEN,',
'        :P31_SYNC_OE2_DES_REV ',
'      FROM t_vorschrift',
'      WHERE vorschriftid = :P31_VORSCHRIFTID;',
'    EXCEPTION',
'      WHEN NO_DATA_FOUND THEN',
'        -- Set defaults if record not found ',
'        :P31_VORSCHRIFT_FREIGABESTATUSID := 1;',
'        :P31_VORSCHRIFT_STATUSID := 20;',
'        :P31_PROGNOSE_QUALITAETID := 0;',
'        :P31_RXSWIN := 20;',
'        :P31_COP_RELEVANT := 20;',
'        :P31_HOMOLOGATIONSRELEVANT := 20;',
'        :P31_INHALTLICH_SACHLICH_GEPRUEFT := 10;',
'        :P31_MASTER := 10;',
'        :P31_KSU := 1020;',
'        :P31_VORSCHRIFT_TYPID := 10;',
'        :P31_EINSATZDATUM_MODELLID := 10;',
'        :P31_SYNC_OE2_DES_REV := 10;',
'    END;',
'',
'    -- Step 4: Load Parent Vorschrift ID (for supplements)',
'    BEGIN',
'      SELECT vrv.vorgaenger_vorschriftid',
'      INTO :P31_PARENT_VORSCHRIFTID',
'      FROM t_vorschrift_ref_vorschrift vrv',
'      WHERE vrv.nachfolger_vorschriftid = :P31_VORSCHRIFTID',
'      AND vrv.beziehung_art = 30',
'      AND :P31_VORSCHRIFT_TYPID = 20',
'      FETCH FIRST ROW ONLY;',
'    EXCEPTION',
'      WHEN NO_DATA_FOUND THEN',
'        :P31_PARENT_VORSCHRIFTID := NULL;',
'    END;',
'',
'    -- Step 5: Load Fahrzeugklasse (multi-select)',
'    BEGIN',
'      SELECT LISTAGG(fahrzeugklasseid, '':'')',
'      INTO :P31_FAHRZEUGKLASSE',
'      FROM t_vorschrift_ref_fahrzeugklasse',
'      WHERE vorschriftid = :P31_VORSCHRIFTID;',
'    EXCEPTION',
'      WHEN NO_DATA_FOUND THEN',
'        :P31_FAHRZEUGKLASSE := NULL;',
'      WHEN OTHERS THEN',
'        :P31_FAHRZEUGKLASSE := NULL;',
'    END;',
'',
'    -- Step 6: Load In-Kraft date for supplements',
'    IF :P31_VORSCHRIFT_TYPID = 20 THEN',
'      BEGIN',
'        SELECT einsatzdatum',
'        INTO :P31_IN_KRAFT_DATUM_SUPPLEMENT  ',
'        FROM t_vorschrift_ref_einsatzdatum_typ',
'        WHERE vorschriftid = :P31_VORSCHRIFTID',
'        AND einsatzdatum_typid = 1000;',
'      EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'          :P31_IN_KRAFT_DATUM_SUPPLEMENT := NULL;',
'      END;',
'    ELSE',
'      :P31_IN_KRAFT_DATUM_SUPPLEMENT := NULL;',
'    END IF;',
'',
'    -- Step 7: Set STRG_GETEX_ANZEIGE based on master',
'    :P31_STRG_GETEX_ANZEIGE := CASE WHEN :P31_MASTER in (20, 30) THEN 20 ELSE 10 END;',
'  ELSE',
'    -- Record doesn''t exist, set defaults as fallback',
'    :P31_VORSCHRIFT_FREIGABESTATUSID := 1;',
'    :P31_VORSCHRIFT_STATUSID := 20;',
'    :P31_PROGNOSE_QUALITAETID := 0;',
'    :P31_RXSWIN := 20;',
'    :P31_COP_RELEVANT := 20;',
'    :P31_HOMOLOGATIONSRELEVANT := 20;',
'    :P31_INHALTLICH_SACHLICH_GEPRUEFT := 10;',
'    :P31_MASTER := 10;',
'    :P31_KSU := 1020;',
'    :P31_VORSCHRIFT_TYPID := 10;',
'    :P31_EINSATZDATUM_MODELLID := 10;',
'    :P31_PHASEIN_ENTHALTEN := 0;',
'    :P31_STRG_GETEX_ANZEIGE := 10;',
'    :P31_SYNC_OE2_DES_REV := 10;',
'  END IF;',
'',
'EXCEPTION',
'  WHEN OTHERS THEN',
'    -- Log error but don''t stop page load',
'    apex_debug.error(''Error in Load Kerndaten Data: %s'', SQLERRM);',
'    ',
'    -- Set essential defaults so page doesn''t error out',
'    IF :P31_VORSCHRIFT_FREIGABESTATUSID IS NULL THEN :P31_VORSCHRIFT_FREIGABESTATUSID := 1; END IF;',
'    IF :P31_VORSCHRIFT_STATUSID IS NULL THEN :P31_VORSCHRIFT_STATUSID := 20; END IF;',
'    IF :P31_PROGNOSE_QUALITAETID IS NULL THEN :P31_PROGNOSE_QUALITAETID := 0; END IF;',
'    IF :P31_RXSWIN IS NULL THEN :P31_RXSWIN := 20; END IF;',
'    IF :P31_COP_RELEVANT IS NULL THEN :P31_COP_RELEVANT := 20; END IF;',
'    IF :P31_HOMOLOGATIONSRELEVANT IS NULL THEN :P31_HOMOLOGATIONSRELEVANT := 20; END IF;',
'    IF :P31_INHALTLICH_SACHLICH_GEPRUEFT IS NULL THEN :P31_INHALTLICH_SACHLICH_GEPRUEFT := 10; END IF;',
'    IF :P31_MASTER IS NULL THEN :P31_MASTER := 10; END IF;',
'    IF :P31_KSU IS NULL THEN :P31_KSU := 1020; END IF;',
'    IF :P31_VORSCHRIFT_TYPID IS NULL THEN :P31_VORSCHRIFT_TYPID := 10; END IF;',
'    IF :P31_EINSATZDATUM_MODELLID IS NULL THEN :P31_EINSATZDATUM_MODELLID := 10; END IF;',
'    IF :P31_STRG_GETEX_ANZEIGE IS NULL THEN :P31_STRG_GETEX_ANZEIGE := 10; END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2658166818676554818
);
wwv_flow_imp.component_end;
end;
/
