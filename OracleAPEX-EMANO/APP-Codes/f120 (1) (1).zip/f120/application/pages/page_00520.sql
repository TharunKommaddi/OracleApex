prompt --application/pages/page_00520
begin
--   Manifest
--     PAGE: 00520
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>520
,p_name=>'Besetzung Arbeitskreise'
,p_alias=>'BESETZUNG-ARBEITSKREISE'
,p_step_title=>'Besetzung Arbeitskreise'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function setCellBackground() {',
'    $("span[bg-style]").each(function() {',
'        $(this).parent().addClass($(this).attr(''bg-style''));',
'    });',
'}',
'',
'function setCellSpan() {',
'    var seen = {};',
'    $(''#ba_ir td'').each(function() {',
'       var index = $(this).index();',
'       var text = $(this).text();',
'       var last_text = ''dummy'';',
'        ',
'       /*if (text === last_text) {',
'                ',
'           ',
'           ',
'           ',
'       } else {',
'           last_text = text;',
'           ',
'           ',
'           ',
'       }*/',
'        ',
'        /*',
'          var $this = $(this);',
'        var index = $this.index();',
'        var text = $this.text();',
'        var count = 1;',
'        ',
'        if (seen[index] === text) {',
'            count++;',
'            $($this.parent().prev().children()[index]).attr(''rowspan'', 2);',
'            $this.hide();',
'        } else {',
'            count = 1;',
'            seen[index] = text;',
'        }*/',
'    }',
'    );',
'}',
'',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'setCellBackground();',
'setCellSpan();'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.lightgreen {',
'    background-color: lightgreen !important;',
'    color: black !important;',
'}',
'',
'.yellow {',
'    background-color: yellow !important;',
'    color: black !important;',
'}',
'',
'.pink {',
'    background-color: pink !important;',
'    color: black !important;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(852020141902651548)
,p_plug_name=>'Besetzung Arbeitskreise'
,p_region_name=>'ba_ir'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_arbeitskreise as (',
'    select ET_B_AKID, KURZ, CASE ',
'               WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN BEZEICHNUNG',
'               ELSE NAME_ENG',
'           END as BEZEICHNUNG, HAEUFIGKEIT ',
'    from t_et_b_ak ak',
'    where exists (select 1 from t_et_b_ak_ref_thema_benutzer akrtb where akrtb.et_b_akid = ak.et_b_akid)',
'        or exists (select 1 from t_et_b_ak_ref_benutzer akrb where akrb.et_b_akid = ak.et_b_akid)',
'),',
'cte_vko as (',
'    select ET_B_AKID, listagg(nvl2(b.benutzerid, b.nachname || '', '' || b.vorname || nvl2(akrb.BEMERKUNG, '' ('' || akrb.BEMERKUNG || '')'', ''''), null), ''; '') within group (order by b.nachname, b.vorname) as VKO_LISTE,',
'    listagg(nvl(b.email,''''), ''; '') within group (order by b.nachname) as email',
'    from T_ET_B_AK_REF_BENUTZER akrb',
'    inner join t_benutzer b on b.benutzerid = akrb.benutzerid',
'    group by ET_B_AKID',
'),',
' cte_betr as (select distinct b.nachname||'',''||b.vorname as d, ET_B_AK_REF_THEMA_BENUTZERID r ',
'                 from t_ET_B_AK_REF_THEMA_BENUTZER artb',
'                 join t_benutzer b on (b.benutzerid = artb.benutzerid )',
'                where RolleId = 1002  --and  artb.benutzerid != :P387_R_BENUTZERID',
'               order by 1',
' ),',
'cte_verantwortliche as (',
'    select aktb.et_b_ak_ref_thema_benutzerid,   betr.d as betreuer,  aktb.betreuerid betreuerid, ',
'        aktb.et_b_akid, ',
'        r.rolle, r.rolleid as rolleid,',
'        aktb.bereich, ',
'        b.abteilung,',
'     b.email,',
'        aktb.benutzerid as benutzerid,',
'        nvl2(b.nachname, b.nachname || '', '' || b.vorname, aktb.benutzername) as verantwortlicher, ',
'',
'',
'        aktb.bemerkung, ',
'        aktb.approved,',
'        aktb.letzte_aenderung_datum,',
'        nvl2 (aktb.letzte_aenderung_benutzerid, leb.nachname || '', '' || leb.vorname, null) as letzte_aenderung_benutzer',
'    from t_et_b_ak_ref_thema_benutzer aktb',
'    left outer join t_rolle r on r.rolleid = aktb.rolleid',
'    --left outer join t_benutzer_ref_rolle brf on brf.benutzer_ref_rolleid = aktb.benutzer_ref_rolleid',
'    left outer join t_benutzer b on b.benutzerid = aktb.benutzerid  --brf.benutzerid',
'    left outer join cte_betr betr on betr.r = aktb.betreuerid  ',
'    left outer join t_benutzer leb on leb.benutzerid = aktb.letzte_aenderung_benutzerid',
'),',
'cte_verantwortliche_thema as (',
'    select ET_B_AK_REF_THEMA_BENUTZERID, listagg(t.nummer || '' '' ||',
'    ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN t.bezeichnung',
'        ELSE t.name_eng',
'    END, ''; '') within group (order by vt.thema_sortorder) as thema_list',
'    ',
'    from T_ET_B_AK_REF_THEMA_BENUTZER_REF_ET_B_AK_REF_THEMA akbt',
'    inner join t_thema_ref_et_b_ak trak on trak.thema_ref_et_b_akid = akbt.thema_ref_et_b_akid',
'    inner join t_thema t on t.themaid = trak.themaid',
'    left outer join v_thema_baum vt on (t.themaid = vt.themaid)',
'    group by ET_B_AK_REF_THEMA_BENUTZERID',
')',
'',
'',
'select ak.ET_B_AKID,',
'       ak.BEZEICHNUNG,',
'       ak.KURZ,',
'       ak.HAEUFIGKEIT,',
'       vko.vko_liste as vko,',
'       vko.email as Email,',
'       vext.thema_list as thema,',
'       nvl(vex.verantwortlicher, ''Leerstelle'') as verantwortlicher,',
'            vex.benutzerid as verantwortlicher_benutzerid,',
'       vex.email as "VEX E-Mail",',
'       vex.bereich, vex.rolleid,',
'       vex.bemerkung as bemerkung,',
'       vex.letzte_aenderung_datum,',
'       vex.letzte_aenderung_benutzer,',
'       (case',
'       when vex.verantwortlicher is null then ''pink''',
'       when vex.verantwortlicher is not null and vex.APPROVED = 0 then ''yellow''',
'       when vex.verantwortlicher is not null and vex.APPROVED = 20 then ''lightgreen''',
'       else null',
'       end) as cell_class,',
'       (',
'case',
'    ',
'    -- VKO (1000) and Fachadmin (1003) have full rights, show pencil icon for all',
'    when (pck_ri.fIsAuthorized01(pageId => 387, accessMode => 200) > 0 and pck_ri.fIsUserInRolle(listRolleId => ''1000:1003'') >0 )',
'        then  ',
'        ''<a href="'' || case when  vex.et_b_ak_ref_thema_benutzerid is not null ',
'                    then apex_page.get_url(p_page => 388, p_items => ''P388_ET_B_AK_REF_THEMA_BENUTZERID'', ',
'                                              p_values => vex.et_b_ak_ref_thema_benutzerid, ',
'                                              p_clear_cache => 388)',
'                    else apex_page.get_url(p_page => 388, p_items => ''P388_ET_B_AKID'', ',
'                                              p_values => ak.et_b_akid, ',
'                                              p_clear_cache => 388)',
'                    end || ''"><span  aria-label="'' || emano_util.fLang(''Zuordnung bearbeiten'', ''Edit Assignment'') || ''" class="fa fa-pencil" aria-hidden="true" title="'' || emano_util.fLang(''Zuordnung bearbeiten'', ''Edit Assignment'') || ''"></span></a>''',
'',
'',
'   -- VEX (1002) can edit their own records',
'    when (pck_ri.fGetUserId = vex.benutzerid and pck_ri.fIsUserInRolle(listRolleId => ''1002'') > 0 and vex.rolleid =1002)',
'   -- or   (vex.betreuerid = pck_ri.fGetUserId )--and pck_ri.fIsUserInRolle(listRolleId => ''1006'') > 0 )--and vex.rolleid = ''1006'' )       ',
'    then ''<a href="'' || case when vex.ET_B_AK_REF_THEMA_BENUTZERID is not null ',
'                    then apex_page.get_url(p_page => 388, p_items => ''P388_ET_B_AK_REF_THEMA_BENUTZERID'',',
'                                              p_values =>vex.ET_B_AK_REF_THEMA_BENUTZERID ,',
'                                             p_clear_cache => 388)',
'                    else apex_page.get_url(p_page => 388, p_items => ''P388_ET_B_AKID'', ',
'                                              p_values => ak.et_b_akid, ',
'                                              p_clear_cache => 388)',
'                    end || ''"><span  aria-label="'' || emano_util.fLang(''Zuordnung bearbeiten'', ''Edit Assignment'') || ''" class="fa fa-pencil" aria-hidden="true" title="'' || emano_util.fLang(''Zuordnung bearbeiten'', ''Edit Assignment'') || ''"></span></a>''',
'  ',
'  -- vex manage fbex',
'  when  pck_ri.fIsUserInRolle(listRolleId => ''1002'') > 0 and pck_ri.fGetUserId in (select distinct BENUTZERID  from t_et_b_ak_ref_thema_benutzer where BETREUERID =vex.betreuerid and rolleid = 1006  and benutzerid=:G_benutzerid and  bETREUERID is not '
||'null)',
'   -- or   (vex.betreuerid = pck_ri.fGetUserId )--and pck_ri.fIsUserInRolle(listRolleId => ''1006'') > 0 )--and vex.rolleid = ''1006'' )       ',
'    then ''<a href="'' || case when vex.ET_B_AK_REF_THEMA_BENUTZERID is not null ',
'                    then apex_page.get_url(p_page => 388, p_items => ''P388_ET_B_AK_REF_THEMA_BENUTZERID'',',
'                                              p_values =>vex.ET_B_AK_REF_THEMA_BENUTZERID ,',
'                                             p_clear_cache => 388)',
'                    else apex_page.get_url(p_page => 388, p_items => ''P388_ET_B_AKID'', ',
'                                              p_values => ak.et_b_akid, ',
'                                              p_clear_cache => 388)',
'                    end || ''"><span  aria-label="'' || emano_util.fLang(''Zuordnung bearbeiten'', ''Edit Assignment'') || ''" class="fa fa-pencil" aria-hidden="true" title="'' || emano_util.fLang(''Zuordnung bearbeiten'', ''Edit Assignment'') || ''"></span></a>''',
'',
' --fbex (1006) can only see the pencil icon for fbex role',
'    when pck_ri.fGetUserId = vex.benutzerid and pck_ri.fIsUserInRolle(listRolleId => ''1006'') > 0 and vex.rolleid = ''1006''',
'    then ',
'        ''<a href="'' || case when  vex.et_b_ak_ref_thema_benutzerid is not null ',
'                    then apex_page.get_url(p_page => 388, p_items => ''P388_ET_B_AK_REF_THEMA_BENUTZERID'', ',
'                                              p_values => vex.et_b_ak_ref_thema_benutzerid, ',
'                                              p_clear_cache => 388)',
'                    else apex_page.get_url(p_page => 388, p_items => ''P388_ET_B_AKID'', ',
'                                              p_values => ak.et_b_akid, ',
'                                              p_clear_cache => 388)',
'                    end || ''"><span  aria-label="'' || emano_util.fLang(''Zuordnung bearbeiten'', ''Edit Assignment'') || ''" class="fa fa-pencil" aria-hidden="true" title="'' || emano_util.fLang(''Zuordnung bearbeiten'', ''Edit Assignment'') || ''"></span></a>''',
'',
'    -- KFEX (1040) can only see the pencil icon for KFEX role',
'    when pck_ri.fGetUserId = vex.benutzerid and pck_ri.fIsUserInRolle(listRolleId => ''1040'') > 0 and vex.rolleid = ''1040''',
'    then ',
'        ''<a href="'' || case when  vex.et_b_ak_ref_thema_benutzerid is not null ',
'                    then apex_page.get_url(p_page => 388, p_items => ''P388_ET_B_AK_REF_THEMA_BENUTZERID'', ',
'                                              p_values => vex.et_b_ak_ref_thema_benutzerid, ',
'                                              p_clear_cache => 388)',
'                    else apex_page.get_url(p_page => 388, p_items => ''P388_ET_B_AKID'', ',
'                                              p_values => ak.et_b_akid, ',
'                                              p_clear_cache => 388)',
'                    end || ''"><span  aria-label="'' || emano_util.fLang(''Zuordnung bearbeiten'', ''Edit Assignment'') || ''" class="fa fa-pencil" aria-hidden="true" title="'' || emano_util.fLang(''Zuordnung bearbeiten'', ''Edit Assignment'') || ''"></span></a>''',
'',
'    -- ZVEX (1001) can only see the pencil icon for ZVEX role',
'    when (pck_ri.fGetUserId = vex.benutzerid and pck_ri.fIsUserInRolle(listRolleId => ''1001'') > 0 and vex.rolleid = ''1001'')',
'    then ',
'        ''<a href="'' || case when  vex.et_b_ak_ref_thema_benutzerid is not null ',
'                    then apex_page.get_url(p_page => 388, p_items => ''P388_ET_B_AK_REF_THEMA_BENUTZERID'', ',
'                                              p_values => vex.et_b_ak_ref_thema_benutzerid, ',
'                                              p_clear_cache => 388)',
'                    else apex_page.get_url(p_page => 388, p_items => ''P388_ET_B_AKID'', ',
'                                              p_values => ak.et_b_akid, ',
'                                              p_clear_cache => 388)',
'                    end || ''"><span  aria-label="'' || emano_util.fLang(''Zuordnung bearbeiten'', ''Edit Assignment'') || ''" class="fa fa-pencil" aria-hidden="true" title="'' || emano_util.fLang(''Zuordnung bearbeiten'', ''Edit Assignment'') || ''"></span></a>''',
'',
'',
'    else null-- No pencil icon for other cases',
'end) as link_edit,',
'',
'vex.ET_B_AK_REF_THEMA_BENUTZERID,',
'       vex.rolle as rolle,',
'       vex.betreuer betreuer,',
'       vex.abteilung as abteilung,',
'       case',
'       when vex.verantwortlicher is null then emano_util.fLang(''Leerstelle'', ''Emptypoint'')',
'       when vex.verantwortlicher is not null and vex.APPROVED = 0 then emano_util.fLang(''Nein'', ''No'')',
'       when vex.verantwortlicher is not null and vex.APPROVED = 20 then emano_util.fLang(''Ja'', ''Yes'')',
'       else null',
'       end as bestaetigt',
'',
'       ',
'from cte_arbeitskreise ak',
'left outer join cte_vko vko on vko.et_b_akid = ak.et_b_akid',
'left outer join cte_verantwortliche vex on vex.et_b_akid = ak.et_b_akid',
'left outer join cte_verantwortliche_thema vext on vext.et_b_ak_ref_thema_benutzerid = vex.et_b_ak_ref_thema_benutzerid',
';',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_page_header=>'Besetzung Arbeitskreise'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(852020045580651548)
,p_name=>'Besetzung Arbeitskreise'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:385:&SESSION.::&DEBUG.:385:P385_ET_B_AKID:#ET_B_AKID#'
,p_detail_link_text=>'<span aria-label="Arbeitskreis bearbeiten"><span class="fa fa-pencil" aria-hidden="true" title="Arbeitskreis bearbeiten"></span></span>'
,p_detail_link_condition_type=>'EXPRESSION'
,p_detail_link_cond=>'pck_ri.fIsUserInRolle(listRolleId => ''1000:1003:1002'') >0'
,p_detail_link_cond2=>'PLSQL'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(2652734704667593954)
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>260672891514482856
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(852018972835651522)
,p_db_column_name=>'KURZ'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'ID'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(852019427001651522)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Arbeitskreis'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(772173779752661003)
,p_db_column_name=>'HAEUFIGKEIT'
,p_display_order=>50
,p_column_identifier=>'T'
,p_column_label=>unistr('H\00E4ufigkeit')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(852830334828138192)
,p_db_column_name=>'VKO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('Zust\00E4ndiger VKO')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(852829547569138185)
,p_db_column_name=>'THEMA'
,p_display_order=>70
,p_column_identifier=>'M'
,p_column_label=>'Thema'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(852829790737138187)
,p_db_column_name=>'BEREICH'
,p_display_order=>80
,p_column_identifier=>'K'
,p_column_label=>'Vertretener Bereich'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(845778928868438284)
,p_db_column_name=>'ROLLE'
,p_display_order=>90
,p_column_identifier=>'Q'
,p_column_label=>'Rolle'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(852830121053138190)
,p_db_column_name=>'VERANTWORTLICHER'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>'Nachname, Vorname'
,p_column_html_expression=>'<span bg-style="#CELL_CLASS#">#VERANTWORTLICHER#</span>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(852829685196138186)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>110
,p_column_identifier=>'L'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(852018600772651521)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>120
,p_column_identifier=>'D'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY HH24:Mi'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(852829968050138189)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>130
,p_column_identifier=>'I'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(845780154146438297)
,p_db_column_name=>'CELL_CLASS'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Cell Class'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(845779770168438293)
,p_db_column_name=>'LINK_EDIT'
,p_display_order=>150
,p_column_identifier=>'P'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(852019686622651527)
,p_db_column_name=>'ET_B_AKID'
,p_display_order=>160
,p_column_identifier=>'A'
,p_column_label=>'Et B Akid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1055142311303317515)
,p_db_column_name=>'ET_B_AK_REF_THEMA_BENUTZERID'
,p_display_order=>170
,p_column_identifier=>'AA'
,p_column_label=>'Et B Ak Ref Thema Benutzerid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(845778821839438283)
,p_db_column_name=>'ABTEILUNG'
,p_display_order=>190
,p_column_identifier=>'R'
,p_column_label=>'Abteilung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(581724718097659988)
,p_db_column_name=>'EMAIL'
,p_display_order=>200
,p_column_identifier=>'U'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(530861783854178062)
,p_db_column_name=>'VEX E-Mail'
,p_display_order=>210
,p_column_identifier=>'V'
,p_column_label=>'Vex E-mail'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(490931041862903703)
,p_db_column_name=>'BESTAETIGT'
,p_display_order=>220
,p_column_identifier=>'W'
,p_column_label=>'Bestaetigt'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1036496146956372584)
,p_db_column_name=>'BETREUER'
,p_display_order=>230
,p_column_identifier=>'X'
,p_column_label=>'Betreuer FbEx'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(929254208872458787)
,p_db_column_name=>'VERANTWORTLICHER_BENUTZERID'
,p_display_order=>240
,p_column_identifier=>'Y'
,p_column_label=>'Verantwortlicher Benutzerid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(929254057533458786)
,p_db_column_name=>'ROLLEID'
,p_display_order=>250
,p_column_identifier=>'Z'
,p_column_label=>'Rolleid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(851971686507466999)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'2607213'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'KURZ:BEZEICHNUNG:VKO:THEMA:HAEUFIGKEIT:ROLLE:BETREUER:BEREICH:ABTEILUNG:LINK_EDIT:ET_B_AKID:ET_B_AK_REF_THEMA_BENUTZERID:VERANTWORTLICHER:BEMERKUNG:LETZTE_AENDERUNG_DATUM:LETZTE_AENDERUNG_BENUTZER:BESTAETIGT:'
,p_sort_column_1=>'THEMA_SORTORDER'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'KURZ:BEZEICHNUNG:0:0:0:0'
,p_break_enabled_on=>'KURZ:0:0:0:0:BEZEICHNUNG'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(845780054994438296)
,p_name=>'After Refresh'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(852020141902651548)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(845779987116438295)
,p_event_id=>wwv_flow_imp.id(845780054994438296)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'setCellBackground();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(845779108448438286)
,p_name=>'Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(852020141902651548)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(845779027671438285)
,p_event_id=>wwv_flow_imp.id(845779108448438286)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(852020141902651548)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
