prompt --application/pages/page_00452
begin
--   Manifest
--     PAGE: 00452
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>452
,p_name=>'Merge MS Suchergebnissen'
,p_alias=>'MERGE-MS-SUCHERGEBNISSEN'
,p_page_mode=>'MODAL'
,p_step_title=>'Merge MS Suchergebnissen'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'850'
,p_dialog_width=>'1000'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33696042626757809)
,p_plug_name=>'&nbsp'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(413241362557746983)
,p_name=>'QUELL_DATEN'
,p_parent_plug_id=>wwv_flow_imp.id(33696042626757809)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Cards--compact:t-Cards--cols:t-Cards--animColorFill:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  select  ''Quelle 1''  as CARD_TITLE,',
'    case when (:P452_MEILENSTEIN_SUCHE_1 is null or :P452_ERSTE_SUCHE is null) then',
unistr('     ''<table><tr><td> Meilenstein Quelle 1 nicht gew\00E4hlt</td></tr></table>'''),
'     else',
'       (  select  --t.meilenstein ms,  ',
'          ''<table>'' ||  nvl2(t.ms, ''<tr><td>Datum Meilenstein:</td><td>'' || to_char(ftodate(t.ms), ''dd.mm.yyyy'') || ''</td></tr>'', null)',
'         || nvl2( t.sop, ''<tr><td>'' ',
'                 || PCK_RI_SUCHE.fGetBezeichnungStartdatumTyp(t.laender) || '':</td><td>'' || t.sop || ''</td></tr>'', null)',
'         || nvl2(t.eop, ''<tr><td>Datum EOP:</td><td>'' || t.eop  || ''</td></tr>'', null)',
unistr('         || nvl2( t.laender, ''<tr><td>Relevante L\00E4nder:</td><td>'' || to_char(regexp_count(t.laender, '':'')+1) || ''</td></tr>'', null)'),
'         || nvl2( t.themen, ''<tr><td>Relevante Themen:</td><td>'' || to_char(count(distinct x.column_value)) || ''</td></tr>'', null)',
'         || case when  t.laender is null or t.themen is null then ''<tr><td>Noch keine Suchparameter eingestellt</td></tr>'' else null end',
'         || ''</table>'' tab_e  ',
'         from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN'',',
'                laender varchar2(500) PATH ''$.LAENDER'',',
'                themen varchar2(2000) path ''$.THEMEN'',',
'                ms varchar2(20) path ''$.DATUM_MEILENSTEIN'',',
'                sop varchar2(20) path ''$.DATUM_SOP'',',
'                eop varchar2(20) path ''$.DATUM_EOP''',
'                ))) t,',
'          table ( select apex_string.split_numbers(t.themen, '':'') from dual) x,     ',
'         v_thema_baum vt  ',
'         where vt.Themaid = x.column_value  and sucheid = :P452_ERSTE_SUCHE and t.meilenstein =:P452_MEILENSTEIN_SUCHE_1 and leaf=1 ',
'        group by  t.meilenstein , t.ms, t.sop, t.eop, t.laender, t.themen',
'',
'    )  end AS CARD_TEXT , '''' as CARD_SUBTEXT, '''' as CARD_LINK',
'    from T_suche_json where sucheid = :P452_ERSTE_SUCHE',
'    ',
'    UNION',
'    ',
'    select   ''Quelle 2''  as CARD_TITLE,',
'    case when (:P452_MEILENSTEIN_SUCHE_2 is null or :P452_ZWEITE_SUCHE is null) then',
unistr('     ''<table><tr><td>Meilenstein Quelle 2 nicht gew\00E4hlt</td></tr></table>'''),
'     else',
'     (    select    ',
'          ''<table>'' ||  nvl2(t.ms, ''<tr><td>Datum Meilenstein:</td><td>'' || to_char(ftodate(t.ms), ''dd.mm.yyyy'') || ''</td></tr>'', null)',
'         || nvl2( t.sop, ''<tr><td>'' ',
'                 || PCK_RI_SUCHE.fGetBezeichnungStartdatumTyp(t.laender) || '':</td><td>'' || t.sop || ''</td></tr>'', null)',
'         || nvl2(t.eop, ''<tr><td>Datum EOP:</td><td>'' || t.eop  || ''</td></tr>'', null)',
unistr('         || nvl2( t.laender, ''<tr><td>Relevante L\00E4nder:</td><td>'' || to_char(regexp_count(t.laender, '':'')+1) || ''</td></tr>'', null)'),
'         || nvl2( t.themen, ''<tr><td>Relevante Themen:</td><td>'' || to_char(count(distinct x.column_value)) || ''</td></tr>'', null)',
'         || case when  t.laender is null or t.themen is null then ''<tr><td>Noch keine Suchparameter eingestellt</td></tr>'' else null end',
'         || ''</table>'' tab_e  ',
'         from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN'',',
'                laender varchar2(500) PATH ''$.LAENDER'',',
'                themen varchar2(2000) path ''$.THEMEN'',',
'                ms varchar2(20) path ''$.DATUM_MEILENSTEIN'',',
'                sop varchar2(20) path ''$.DATUM_SOP'',',
'                eop varchar2(20) path ''$.DATUM_EOP''',
'                ))) t,',
'          table ( select apex_string.split_numbers(t.themen, '':'') from dual) x,     ',
'         v_thema_baum vt  ',
'         where vt.Themaid = x.column_value  and sucheid = :P452_ZWEITE_SUCHE and t.meilenstein =:P452_MEILENSTEIN_SUCHE_2 and leaf=1 ',
'        group by  t.meilenstein , t.ms, t.sop, t.eop, t.laender, t.themen',
'    )  end AS CARD_TEXT, '''' as CARD_SUBTEXT, '''' as CARD_LINK',
'    from T_suche_json where sucheid = :P452_ZWEITE_SUCHE ',
'    order by 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414129911996820551)
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(413241335943746982)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(413241187216746981)
,p_query_column_id=>2
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>2
,p_column_heading=>'Card Text'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(394301998964385600)
,p_query_column_id=>3
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>3
,p_column_heading=>'Card Subtext'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(394301063565385591)
,p_query_column_id=>4
,p_column_alias=>'CARD_LINK'
,p_column_display_sequence=>4
,p_column_heading=>'Card Link'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(370182174756936060)
,p_plug_name=>'&nbsp;'
,p_parent_plug_id=>wwv_flow_imp.id(33696042626757809)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(413240060361746970)
,p_name=>'Laender Vergleich'
,p_parent_plug_id=>wwv_flow_imp.id(370182174756936060)
,p_template=>wwv_flow_imp.id(3414119964980820545)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_grid_column_span=>4
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl2(x.column_value, ''<html>&#x2714;</html>'', '''' ) "Quelle 1" ,',
'l.b_nummer || ''-'' || CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.land ELSE l.land_eng END as land,  nvl2(y.column_value, ''<html>&#x2714;</html>'', '''' ) "Quelle 2" ',
'from table ( select apex_string.split_numbers(laender, '':'')  ',
'              from ( select  t.meilenstein ms, t.laender laender, t.themen themen',
'                       from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'                        nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN'',',
'                            laender varchar2(500) PATH ''$.LAENDER'',',
'                            themen varchar2(2000) path ''$.THEMEN''',
'                         ))) t where sucheid =  :P452_ERSTE_SUCHE  ',
'              ) where ms = :P452_MEILENSTEIN_SUCHE_1',
'           ) x',
' full join table ( select apex_string.split_numbers(laender, '':'') ',
'               from ( select  t.meilenstein ms, t.laender laender, t.themen themen',
'                       from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'                        nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN'',',
'                            laender varchar2(500) PATH ''$.LAENDER'',',
'                            themen varchar2(2000) path ''$.THEMEN''',
'                         ))) t where sucheid =   :P452_ZWEITE_SUCHE  ',
'              ) where ms = :P452_MEILENSTEIN_SUCHE_2',
'       ) y on (y.column_value = x.column_value )',
'  join T_Land l on (l.landid = y.column_value or l.landid = x.column_value)',
'  where to_number(:P452_ONLY_DIFF) = 20',
'        or (to_number(:P452_ONLY_DIFF) = 10 and x.column_value is null  and y.column_value is not null )',
'        or (to_number(:P452_ONLY_DIFF) = 10 and x.column_value is not null  and y.column_value is  null) ',
'  order by 2;',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P452_ONLY_DIFF'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>200
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(394301442146385595)
,p_query_column_id=>1
,p_column_alias=>'Quelle 1'
,p_column_display_sequence=>2
,p_column_heading=>'Quelle 1'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(413239584996746965)
,p_query_column_id=>2
,p_column_alias=>'LAND'
,p_column_display_sequence=>1
,p_column_heading=>'Land'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(394301385298385594)
,p_query_column_id=>3
,p_column_alias=>'Quelle 2'
,p_column_display_sequence=>3
,p_column_heading=>'Quelle 2'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(413238948580746959)
,p_name=>'Themen Vergleich'
,p_parent_plug_id=>wwv_flow_imp.id(370182174756936060)
,p_template=>wwv_flow_imp.id(3414119964980820545)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_column=>5
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct nvl2(x.column_value, ''<html>&#x2714;</html>'', '''' ) "Quelle 1" ,',
'tt.nummer || '' '' || CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN tt.bezeichnung ELSE tt.name_eng END AS thema,  nvl2(y.column_value, ''<html>&#x2714;</html>'', '''' ) "Quelle 2" ',
'  from table ( select apex_string.split_numbers(themen, '':'')  ',
'              from ( select  t.meilenstein ms,  t.themen themen',
'                       from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'                        nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN'',',
'                            themen varchar2(2000) path ''$.THEMEN''',
'                         ))) t where sucheid =  :P452_ERSTE_SUCHE  ',
'              ) where ms = :P452_MEILENSTEIN_SUCHE_1',
'           ) x',
' full join table ( select apex_string.split_numbers(themen, '':'') ',
'               from ( select  t.meilenstein ms,  t.themen themen',
'                       from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'                        nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN'',',
'                            themen varchar2(2000) path ''$.THEMEN''',
'                         ))) t where sucheid =   :P452_ZWEITE_SUCHE  ',
'              ) where ms = :P452_MEILENSTEIN_SUCHE_2',
'       ) y on (y.column_value = x.column_value )',
'  --join T_THEMA th on (th.themaid = y.column_value or th.themaid = x.column_value)',
'  --left outer join v_thema_baum tt on (th.themaid = tt.themaid and  tt.leaf=1)',
' left join v_thema_baum tt on ((tt.themaid = y.column_value or tt.themaid = x.column_value) and tt.leaf =1)',
'  where to_number(:P452_ONLY_DIFF) = 20',
'        or (to_number(:P452_ONLY_DIFF) = 10 and x.column_value is null  and y.column_value is not null )',
'        or (to_number(:P452_ONLY_DIFF) = 10 and x.column_value is not null  and y.column_value is  null) ',
'  order by thema;',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>200
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(394301237814385593)
,p_query_column_id=>1
,p_column_alias=>'Quelle 1'
,p_column_display_sequence=>2
,p_column_heading=>'Quelle 1'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(413238560197746955)
,p_query_column_id=>2
,p_column_alias=>'THEMA'
,p_column_display_sequence=>1
,p_column_heading=>'Thema'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(394301204533385592)
,p_query_column_id=>3
,p_column_alias=>'Quelle 2'
,p_column_display_sequence=>3
,p_column_heading=>'Quelle 2'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(337622692062617260)
,p_name=>'QUELL_DATEN_PRE_1'
,p_parent_plug_id=>wwv_flow_imp.id(33696042626757809)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Cards--compact:t-Cards--3cols:t-Cards--animColorFill:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  select  ''Meilenstein 1 Preview''  as CARD_TITLE,',
'    case when (:P452_ERSTE_SUCHE is null ) then',
'     ''<table><tr><td> Meilenstein 1 Quelle  nicht vorhandent</td></tr></table>''',
'     when (:P452_MEILENSTEIN_SUCHE_1 is null and :P452_ERSTE_SUCHE is not null) then',
'       (  select   ',
'          ''<table>'' ||  nvl2(t.ms, ''<tr><td>Datum Meilenstein:</td><td>'' || to_char(ftodate(t.ms), ''dd.mm.yyyy'') || ''</td></tr>'', null)',
'         || nvl2( t.sop, ''<tr><td>'' ',
'                 || PCK_RI_SUCHE.fGetBezeichnungStartdatumTyp(t.laender) || '':</td><td>'' || t.sop || ''</td></tr>'', null)',
'         || nvl2(t.eop, ''<tr><td>Datum EOP:</td><td>'' || t.eop  || ''</td></tr>'', null)',
unistr('         || nvl2( t.laender, ''<tr><td>Relevante L\00E4nder:</td><td>'' || to_char(regexp_count(t.laender, '':'')+1) || ''</td></tr>'', null)'),
'         || nvl2( t.themen, ''<tr><td>Relevante Themen:</td><td>'' || to_char(count(distinct x.column_value)) || ''</td></tr>'', null)',
'         || case when  t.laender is null or t.themen is null then ''<tr><td>Noch keine Suchparameter eingestellt</td></tr>'' else null end',
'         || ''</table>'' tab_e  ',
'         from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN'',',
'                laender varchar2(500) PATH ''$.LAENDER'',',
'                themen varchar2(2000) path ''$.THEMEN'',',
'                ms varchar2(20) path ''$.DATUM_MEILENSTEIN'',',
'                sop varchar2(20) path ''$.DATUM_SOP'',',
'                eop varchar2(20) path ''$.DATUM_EOP''',
'                ))) t,',
'          table ( select apex_string.split_numbers(t.themen, '':'') from dual) x,     ',
'         v_thema_baum vt  ',
'         where vt.Themaid = x.column_value  and sucheid = :P452_ERSTE_SUCHE and t.meilenstein =1 and leaf=1 ',
'        group by  t.meilenstein , t.ms, t.sop, t.eop, t.laender, t.themen',
'',
'    )  end AS CARD_TEXT , '''' as CARD_SUBTEXT, '''' as CARD_LINK',
'    from T_suche_json where sucheid = :P452_ERSTE_SUCHE',
'    ',
'    UNION',
'    ',
'    select   ''Meilenstein 2 preview''  as CARD_TITLE,',
'    case when (:P452_ERSTE_SUCHE is null ) then',
'     ''<table><tr><td>Meilenstein 2 von Quelle nicht vorhanden</td></tr></table>''',
'     when (:P452_MEILENSTEIN_SUCHE_1 is null and :P452_ERSTE_SUCHE is not null) then',
'     (    select    ',
'          ''<table>'' ||  nvl2(t.ms, ''<tr><td>Datum Meilenstein:</td><td>'' || to_char(ftodate(t.ms), ''dd.mm.yyyy'') || ''</td></tr>'', null)',
'         || nvl2( t.sop, ''<tr><td>'' ',
'                 || PCK_RI_SUCHE.fGetBezeichnungStartdatumTyp(t.laender) || '':</td><td>'' || t.sop || ''</td></tr>'', null)',
'         || nvl2(t.eop, ''<tr><td>Datum EOP:</td><td>'' || t.eop  || ''</td></tr>'', null)',
unistr('         || nvl2( t.laender, ''<tr><td>Relevante L\00E4nder:</td><td>'' || to_char(regexp_count(t.laender, '':'')+1) || ''</td></tr>'', null)'),
'         || nvl2( t.themen, ''<tr><td>Relevante Themen:</td><td>'' || to_char(count(distinct x.column_value)) || ''</td></tr>'', null)',
'         || case when  t.laender is null or t.themen is null then ''<tr><td>Noch keine Suchparameter eingestellt</td></tr>'' else null end',
'         || ''</table>'' tab_e  ',
'         from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN'',',
'                laender varchar2(500) PATH ''$.LAENDER'',',
'                themen varchar2(2000) path ''$.THEMEN'',',
'                ms varchar2(20) path ''$.DATUM_MEILENSTEIN'',',
'                sop varchar2(20) path ''$.DATUM_SOP'',',
'                eop varchar2(20) path ''$.DATUM_EOP''',
'                ))) t,',
'          table ( select apex_string.split_numbers(t.themen, '':'') from dual) x,     ',
'         v_thema_baum vt  ',
'         where vt.Themaid = x.column_value  and sucheid = :P452_ERSTE_SUCHE and t.meilenstein =2 and leaf=1 ',
'        group by  t.meilenstein , t.ms, t.sop, t.eop, t.laender, t.themen',
'    )  end AS CARD_TEXT, '''' as CARD_SUBTEXT, '''' as CARD_LINK',
'    from T_suche_json where sucheid = :P452_ERSTE_SUCHE',
'    ',
'    UNION',
'    ',
'    select   ''Meilenstein 3 preview''  as CARD_TITLE,',
'    case when (:P452_ERSTE_SUCHE is null ) then',
'     ''<table><tr><td>Meilenstein 3 von Quelle nicht vorhanden</td></tr></table>''',
'     when (:P452_MEILENSTEIN_SUCHE_1 is null and :P452_ERSTE_SUCHE is not null) then',
'     (    select    ',
'          ''<table>'' ||  nvl2(t.ms, ''<tr><td>Datum Meilenstein:</td><td>'' || to_char(ftodate(t.ms), ''dd.mm.yyyy'') || ''</td></tr>'', null)',
'         || nvl2( t.sop, ''<tr><td>'' ',
'                 || PCK_RI_SUCHE.fGetBezeichnungStartdatumTyp(t.laender) || '':</td><td>'' || t.sop || ''</td></tr>'', null)',
'         || nvl2(t.eop, ''<tr><td>Datum EOP:</td><td>'' || t.eop  || ''</td></tr>'', null)',
unistr('         || nvl2( t.laender, ''<tr><td>Relevante L\00E4nder:</td><td>'' || to_char(regexp_count(t.laender, '':'')+1) || ''</td></tr>'', null)'),
'         || nvl2( t.themen, ''<tr><td>Relevante Themen:</td><td>'' || to_char(count(distinct x.column_value)) || ''</td></tr>'', null)',
'         || case when  t.laender is null or t.themen is null then ''<tr><td>Noch keine Suchparameter eingestellt</td></tr>'' else null end',
'         || ''</table>'' tab_e  ',
'         from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN'',',
'                laender varchar2(500) PATH ''$.LAENDER'',',
'                themen varchar2(2000) path ''$.THEMEN'',',
'                ms varchar2(20) path ''$.DATUM_MEILENSTEIN'',',
'                sop varchar2(20) path ''$.DATUM_SOP'',',
'                eop varchar2(20) path ''$.DATUM_EOP''',
'                ))) t,',
'          table ( select apex_string.split_numbers(t.themen, '':'') from dual) x,     ',
'         v_thema_baum vt  ',
'         where vt.Themaid = x.column_value  and sucheid = :P452_ERSTE_SUCHE and t.meilenstein =3 and leaf=1 ',
'        group by  t.meilenstein , t.ms, t.sop, t.eop, t.laender, t.themen',
'    )  end AS CARD_TEXT, '''' as CARD_SUBTEXT, '''' as CARD_LINK',
'    from T_suche_json where sucheid = :P452_ERSTE_SUCHE ',
'    order by 1;',
'    '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414129911996820551)
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337622482302617258)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337622415235617257)
,p_query_column_id=>2
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>3
,p_column_heading=>'Card Text'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337622262458617256)
,p_query_column_id=>3
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>4
,p_column_heading=>'Card Subtext'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(337622633126617259)
,p_query_column_id=>4
,p_column_alias=>'CARD_LINK'
,p_column_display_sequence=>1
,p_column_heading=>'Card Link'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(326656401018178400)
,p_plug_name=>'&nbsp;'
,p_parent_plug_id=>wwv_flow_imp.id(33696042626757809)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(326656326245178399)
,p_plug_name=>'&nbsp;'
,p_parent_plug_id=>wwv_flow_imp.id(33696042626757809)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(326655858924178395)
,p_name=>'QUELL_DATEN_PRE_2'
,p_parent_plug_id=>wwv_flow_imp.id(33696042626757809)
,p_template=>wwv_flow_imp.id(3414115547641820543)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Cards--compact:t-Cards--3cols:t-Cards--animColorFill:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  select  ''Meilenstein 1 ''  as CARD_TITLE,',
'    case when (:P452_ZWEITE_SUCHE is null ) then',
'     ''<table><tr><td> Meilenstein 1 Quelle  nicht vorhandent</td></tr></table>''',
'     when (:P452_MEILENSTEIN_SUCHE_2 is null and :P452_ZWEITE_SUCHE is not null) then',
'       (  select   ',
'          ''<table>'' ||  nvl2(t.ms, ''<tr><td>Datum Meilenstein:</td><td>'' || to_char(ftodate(t.ms), ''dd.mm.yyyy'') || ''</td></tr>'', null)',
'         || nvl2( t.sop, ''<tr><td>'' ',
'                 || PCK_RI_SUCHE.fGetBezeichnungStartdatumTyp(t.laender) || '':</td><td>'' || t.sop || ''</td></tr>'', null)',
'         || nvl2(t.eop, ''<tr><td>Datum EOP:</td><td>'' || t.eop  || ''</td></tr>'', null)',
unistr('         || nvl2( t.laender, ''<tr><td>Relevante L\00E4nder:</td><td>'' || to_char(regexp_count(t.laender, '':'')+1) || ''</td></tr>'', null)'),
'         || nvl2( t.themen, ''<tr><td>Relevante Themen:</td><td>'' || to_char(count(distinct x.column_value)) || ''</td></tr>'', null)',
'         || case when  t.laender is null or t.themen is null then ''<tr><td>Noch keine Suchparameter eingestellt</td></tr>'' else null end',
'         || ''</table>'' tab_e  ',
'         from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN'',',
'                laender varchar2(500) PATH ''$.LAENDER'',',
'                themen varchar2(2000) path ''$.THEMEN'',',
'                ms varchar2(20) path ''$.DATUM_MEILENSTEIN'',',
'                sop varchar2(20) path ''$.DATUM_SOP'',',
'                eop varchar2(20) path ''$.DATUM_EOP''',
'                ))) t,',
'          table ( select apex_string.split_numbers(t.themen, '':'') from dual) x,     ',
'         v_thema_baum vt  ',
'         where vt.Themaid = x.column_value  and sucheid = :P452_ZWEITE_SUCHE and t.meilenstein =1 and leaf=1 ',
'        group by  t.meilenstein , t.ms, t.sop, t.eop, t.laender, t.themen',
'',
'    )  end AS CARD_TEXT , '''' as CARD_SUBTEXT, '''' as CARD_LINK',
'    from T_suche_json where sucheid = :P452_ZWEITE_SUCHE',
'    ',
'    UNION',
'    ',
'    select   ''Meilenstein 2 preview''  as CARD_TITLE,',
'    case when (:P452_ZWEITE_SUCHE is null ) then',
'     ''<table><tr><td>Meilenstein 2 von Quelle nicht vorhanden</td></tr></table>''',
'     when (:P452_MEILENSTEIN_SUCHE_2 is null and :P452_ZWEITE_SUCHE is not null) then',
'     (    select    ',
'          ''<table>'' ||  nvl2(t.ms, ''<tr><td>Datum Meilenstein:</td><td>'' || to_char(ftodate(t.ms), ''dd.mm.yyyy'') || ''</td></tr>'', null)',
'         || nvl2( t.sop, ''<tr><td>'' ',
'                 || PCK_RI_SUCHE.fGetBezeichnungStartdatumTyp(t.laender) || '':</td><td>'' || t.sop || ''</td></tr>'', null)',
'         || nvl2(t.eop, ''<tr><td>Datum EOP:</td><td>'' || t.eop  || ''</td></tr>'', null)',
unistr('         || nvl2( t.laender, ''<tr><td>Relevante L\00E4nder:</td><td>'' || to_char(regexp_count(t.laender, '':'')+1) || ''</td></tr>'', null)'),
'         || nvl2( t.themen, ''<tr><td>Relevante Themen:</td><td>'' || to_char(count(distinct x.column_value)) || ''</td></tr>'', null)',
'         || case when  t.laender is null or t.themen is null then ''<tr><td>Noch keine Suchparameter eingestellt</td></tr>'' else null end',
'         || ''</table>'' tab_e  ',
'         from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN'',',
'                laender varchar2(500) PATH ''$.LAENDER'',',
'                themen varchar2(2000) path ''$.THEMEN'',',
'                ms varchar2(20) path ''$.DATUM_MEILENSTEIN'',',
'                sop varchar2(20) path ''$.DATUM_SOP'',',
'                eop varchar2(20) path ''$.DATUM_EOP''',
'                ))) t,',
'          table ( select apex_string.split_numbers(t.themen, '':'') from dual) x,     ',
'         v_thema_baum vt  ',
'         where vt.Themaid = x.column_value  and sucheid = :P452_ZWEITE_SUCHE and t.meilenstein =2 and leaf=1 ',
'        group by  t.meilenstein , t.ms, t.sop, t.eop, t.laender, t.themen',
'    )  end AS CARD_TEXT, '''' as CARD_SUBTEXT, '''' as CARD_LINK',
'    from T_suche_json where sucheid = :P452_ZWEITE_SUCHE',
'    ',
'    UNION',
'    ',
'    select   ''Meilenstein 3 preview''  as CARD_TITLE,',
'    case when (:P452_ZWEITE_SUCHE is null ) then',
'     ''<table><tr><td>Meilenstein 3 von Quelle nicht vorhanden</td></tr></table>''',
'     when (:P452_MEILENSTEIN_SUCHE_2 is null and :P452_ZWEITE_SUCHE is not null) then',
'     (    select    ',
'          ''<table>'' ||  nvl2(t.ms, ''<tr><td>Datum Meilenstein:</td><td>'' || to_char(ftodate(t.ms), ''dd.mm.yyyy'') || ''</td></tr>'', null)',
'         || nvl2( t.sop, ''<tr><td>'' ',
'                 || PCK_RI_SUCHE.fGetBezeichnungStartdatumTyp(t.laender) || '':</td><td>'' || t.sop || ''</td></tr>'', null)',
'         || nvl2(t.eop, ''<tr><td>Datum EOP:</td><td>'' || t.eop  || ''</td></tr>'', null)',
unistr('         || nvl2( t.laender, ''<tr><td>Relevante L\00E4nder:</td><td>'' || to_char(regexp_count(t.laender, '':'')+1) || ''</td></tr>'', null)'),
'         || nvl2( t.themen, ''<tr><td>Relevante Themen:</td><td>'' || to_char(count(distinct x.column_value)) || ''</td></tr>'', null)',
'         || case when  t.laender is null or t.themen is null then ''<tr><td>Noch keine Suchparameter eingestellt</td></tr>'' else null end',
'         || ''</table>'' tab_e  ',
'         from t_suche_json t, json_table (t.suchdaten, ''$[*]'' columns (',
'            nested path ''$[*]'' COLUMNS( meilenstein number path ''$.MEILENSTEIN'',',
'                laender varchar2(500) PATH ''$.LAENDER'',',
'                themen varchar2(2000) path ''$.THEMEN'',',
'                ms varchar2(20) path ''$.DATUM_MEILENSTEIN'',',
'                sop varchar2(20) path ''$.DATUM_SOP'',',
'                eop varchar2(20) path ''$.DATUM_EOP''',
'                ))) t,',
'          table ( select apex_string.split_numbers(t.themen, '':'') from dual) x,     ',
'         v_thema_baum vt  ',
'         where vt.Themaid = x.column_value  and sucheid = :P452_ZWEITE_SUCHE and t.meilenstein =3 and leaf=1 ',
'        group by  t.meilenstein , t.ms, t.sop, t.eop, t.laender, t.themen',
'    )  end AS CARD_TEXT, '''' as CARD_SUBTEXT, '''' as CARD_LINK',
'    from T_suche_json where sucheid = :P452_ZWEITE_SUCHE ',
'    order by 1;',
'    '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414129911996820551)
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(326655662034178393)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(326655568357178392)
,p_query_column_id=>2
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>3
,p_column_heading=>'Card Text'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(326655461798178391)
,p_query_column_id=>3
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>4
,p_column_heading=>'Card Subtext'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(326655742467178394)
,p_query_column_id=>4
,p_column_alias=>'CARD_LINK'
,p_column_display_sequence=>1
,p_column_heading=>'Card Link'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41343467576196209)
,p_plug_name=>'&nbsp'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41343546340196210)
,p_plug_name=>'&nbsp'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noBorder'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(401719319600191018)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(41343546340196210)
,p_button_name=>'Save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(401718921902191016)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(41343546340196210)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(401705150682190968)
,p_branch_name=>'CLOSE'
,p_branch_action=>'f?p=&APP_ID.:450:&SESSION.::&DEBUG.::P450_SUCHEID:&P452_NEW_SUCHE.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(401719319600191018)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1068058036743307389)
,p_name=>'P452_HINWEIS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(41343467576196209)
,p_use_cache_before_default=>'NO'
,p_prompt=>'&nbsp;'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401716978110191013)
,p_name=>'P452_BEZEICHNUNG'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(326656401018178400)
,p_prompt=>'Bezeichnung'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401716569183191009)
,p_name=>'P452_BESCHREIBUNG'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(326656401018178400)
,p_prompt=>'Beschreibung'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>5
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401716175865191009)
,p_name=>'P452_ERSTE_SUCHE'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(326656401018178400)
,p_prompt=>'Quelle: Erste Suche'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select BEZEICHNUNG || ''; - '' || beschreibung as d,      ',
'      SUCHEID as r',
'  from T_SUCHE_JSON where benutzerid = :G_benutzerid',
'order by 1;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- select -'
,p_lov_null_value=>'0'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401715831692191008)
,p_name=>'P452_MEILENSTEIN_SUCHE_1'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(326656401018178400)
,p_prompt=>'Meilenstein der Quellsuche 1'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:1;1,2;2,3;3'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401715341672191008)
,p_name=>'P452_ALERT_MS1'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(326656401018178400)
,p_prompt=>'&nbsp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_icon_css_classes=>'fa-exclamation-triangle-o'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401715009435191007)
,p_name=>'P452_ZWEITE_SUCHE'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(326656326245178399)
,p_prompt=>'Quelle: Zweite Suche'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select BEZEICHNUNG || ''; - '' || beschreibung  as d,      ',
'      SUCHEID as r',
'  from T_SUCHE_JSON where benutzerid = :G_benutzerid',
'order by 1;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- select -'
,p_lov_null_value=>'0'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401714627820191007)
,p_name=>'P452_MEILENSTEIN_SUCHE_2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(326656326245178399)
,p_prompt=>'Meilenstein der Quellsuche 2'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:1;1,2;2,3;3'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401714180210191007)
,p_name=>'P452_ALERT_MS2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(326656326245178399)
,p_prompt=>'&nbsp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_icon_css_classes=>'fa-exclamation-triangle-o'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401713821512191006)
,p_name=>'P452_NEW_SUCHE'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(33696042626757809)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(370182076906936059)
,p_name=>'P452_ONLY_DIFF'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(370182174756936060)
,p_item_default=>'10'
,p_prompt=>'Vergleich Anzeige'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''Differenz'', ''Difference'') AS display_value,',
'        10 AS actual_value,',
'        1 AS sort_order',
'',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''Alles'', ''All'') AS display_value,',
'        20 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(401712615160190976)
,p_name=>'Close Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(401718921902191016)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401712112498190973)
,p_event_id=>wwv_flow_imp.id(401712615160190976)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(401706164624190970)
,p_name=>'Check_Suche_Daten'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_MEILENSTEIN_SUCHE_1,P452_ERSTE_SUCHE'
,p_condition_element=>'P452_ERSTE_SUCHE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401705730550190970)
,p_event_id=>wwv_flow_imp.id(401706164624190970)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- check if selected :P452_MEILENSTEIN_SUCHE_1 contains data',
' declare ',
'   js_data varchar2(4000) ;',
' begin',
'   :P452_ALERT_MS1 :='''';',
'   SELECT nvl(t.daten,''#'')  ',
'     into js_data ',
'        FROM  t_suche_json tj,  json_table',
'        ( tj.suchdaten, ''$[*]'' COLUMNS (  daten clob format json path ''$'',',
'                    nested path ''$[*]'' COLUMNS(',
'                           meilenstein number path ''$.MEILENSTEIN'')) ',
'        ) t      ',
'   WHERE sucheid = :P452_ERSTE_SUCHE and t.meilenstein = to_number(nvl(:P452_MEILENSTEIN_SUCHE_1,''0''));',
'    ',
'  --if js_data is null  or length(js_data) <2 then',
unistr('  -- :P452_ALERT_MS1 := ''Meilenstein der Suche enth\00E4lt keine Daten!'';'),
' -- end if;',
'  --debug(''P452_MEILENSTEIN_SUCHE_1=''|| :P452_MEILENSTEIN_SUCHE_1, ''P452_ERSTE_SUCHE =''|| :P452_ERSTE_SUCHE);',
'  EXCEPTION ',
'   WHEN NO_DATA_FOUND THEN',
'     js_data :=''#'';',
unistr('     :P452_ALERT_MS1 := ''Meilenstein der Suche enth\00E4lt keine Daten!'';'),
'  end;'))
,p_attribute_02=>'P452_ERSTE_SUCHE,P452_MEILENSTEIN_SUCHE_1'
,p_attribute_03=>'P452_ALERT_MS1'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(401711661861190972)
,p_name=>'IsAlert'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_ALERT_MS1'
,p_condition_element=>'P452_ALERT_MS1'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>unistr('Meilenstein der Suche ist nicht gew\00E4hlt!')
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401711195081190972)
,p_event_id=>wwv_flow_imp.id(401711661861190972)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P452_ALERT_MS1'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401710704214190972)
,p_event_id=>wwv_flow_imp.id(401711661861190972)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P452_ALERT_MS1'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(401707631939190970)
,p_name=>'IsAlert2'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_ALERT_MS2'
,p_condition_element=>'P452_ALERT_MS2'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>unistr('Meilenstein der Suche ist nicht gew\00E4hlt!')
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401707112887190970)
,p_event_id=>wwv_flow_imp.id(401707631939190970)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P452_ALERT_MS2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401706587196190970)
,p_event_id=>wwv_flow_imp.id(401707631939190970)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P452_ALERT_MS2'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(401710275994190972)
,p_name=>'ChangeVal'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_ERSTE_SUCHE'
,p_condition_element=>'P452_MEILENSTEIN_SUCHE_1'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401709789577190972)
,p_event_id=>wwv_flow_imp.id(401710275994190972)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'clear Meilenstein 1 selection'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P452_MEILENSTEIN_SUCHE_1'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(401709371067190971)
,p_name=>'Check_suche_2_Daten'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_ZWEITE_SUCHE,P452_MEILENSTEIN_SUCHE_2'
,p_condition_element=>'P452_ZWEITE_SUCHE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401708865616190971)
,p_event_id=>wwv_flow_imp.id(401709371067190971)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare js_data varchar2(4000) ;',
' BEGIN',
'   :P452_ALERT_MS2 :='''';',
'   ',
'  SELECT nvl(t.daten,''#'')  into js_data ',
'        FROM  t_suche_json tj,  json_table',
'        ( tj.suchdaten, ''$[*]'' COLUMNS (  daten clob format json path ''$'',',
'                    nested path ''$[*]'' COLUMNS(',
'                           meilenstein number path ''$.MEILENSTEIN'')) ',
'        ) t      ',
'   WHERE sucheid = :P452_ZWEITE_SUCHE and t.meilenstein = to_number(:P452_MEILENSTEIN_SUCHE_2);',
'   ',
'  EXCEPTION ',
'   WHEN NO_DATA_FOUND THEN',
'     js_data :=''#'';',
unistr('    :P452_ALERT_MS2 := ''Meilenstein der Suche enth\00E4lt keine Daten!'';'),
'  end;'))
,p_attribute_02=>'P452_ZWEITE_SUCHE,P452_MEILENSTEIN_SUCHE_2'
,p_attribute_03=>'P452_ALERT_MS2'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(401708482832190971)
,p_name=>'Change_Val2'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_ZWEITE_SUCHE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(902559046238928001)
,p_event_id=>wwv_flow_imp.id(401708482832190971)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P452_MEILENSTEIN_SUCHE_2,P452_ZWEITE_SUCHE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401707941328190971)
,p_event_id=>wwv_flow_imp.id(401708482832190971)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P452_MEILENSTEIN_SUCHE_2'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(413241098369746980)
,p_name=>'anzeige quelldaten 1'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_MEILENSTEIN_SUCHE_1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(902559224341928002)
,p_event_id=>wwv_flow_imp.id(413241098369746980)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P452_MEILENSTEIN_SUCHE_1,P452_ERSTE_SUCHE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(413240982376746979)
,p_event_id=>wwv_flow_imp.id(413241098369746980)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(413241362557746983)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(413240867322746978)
,p_name=>'refresh anzeige quelldaten 2'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_MEILENSTEIN_SUCHE_2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(902558938220928000)
,p_event_id=>wwv_flow_imp.id(413240867322746978)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P452_MEILENSTEIN_SUCHE_2,P452_ZWEITE_SUCHE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(413240774968746977)
,p_event_id=>wwv_flow_imp.id(413240867322746978)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(413241362557746983)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(413240719776746976)
,p_name=>'refresh anzeige quelle 1'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_ERSTE_SUCHE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(902559255653928003)
,p_event_id=>wwv_flow_imp.id(413240719776746976)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P452_MEILENSTEIN_SUCHE_1,P452_ERSTE_SUCHE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(413240567003746975)
,p_event_id=>wwv_flow_imp.id(413240719776746976)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(413241362557746983)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(337622232581617255)
,p_name=>'refresh anzeige pre_1'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_ERSTE_SUCHE'
,p_condition_element=>'P452_ERSTE_SUCHE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(337622089790617254)
,p_event_id=>wwv_flow_imp.id(337622232581617255)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(337622692062617260)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(326656551943178402)
,p_event_id=>wwv_flow_imp.id(337622232581617255)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(337622692062617260)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(413240447964746974)
,p_name=>'refresh anzeige quelle 2'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_ZWEITE_SUCHE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(413240357754746973)
,p_event_id=>wwv_flow_imp.id(413240447964746974)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(413241362557746983)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(326655430678178390)
,p_event_id=>wwv_flow_imp.id(413240447964746974)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(326655858924178395)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(326655330330178389)
,p_event_id=>wwv_flow_imp.id(413240447964746974)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(326655858924178395)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(413239371287746963)
,p_name=>'refresh_Laender'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_MEILENSTEIN_SUCHE_2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(980816946281066824)
,p_event_id=>wwv_flow_imp.id(413239371287746963)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P452_ONLY_DIFF'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(413239314142746962)
,p_event_id=>wwv_flow_imp.id(413239371287746963)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(413240060361746970)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(394302196489385602)
,p_name=>'refresh_Themen_2'
,p_event_sequence=>160
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_MEILENSTEIN_SUCHE_2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(980816858323066823)
,p_event_id=>wwv_flow_imp.id(394302196489385602)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P452_ONLY_DIFF'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(394302063847385601)
,p_event_id=>wwv_flow_imp.id(394302196489385602)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(413238948580746959)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(413239186439746961)
,p_name=>'refresh_laender'
,p_event_sequence=>170
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_MEILENSTEIN_SUCHE_1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(980817142848066826)
,p_event_id=>wwv_flow_imp.id(413239186439746961)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P452_ONLY_DIFF'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(413239108184746960)
,p_event_id=>wwv_flow_imp.id(413239186439746961)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(413240060361746970)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(413238441905746954)
,p_name=>'refresh_Themen_1'
,p_event_sequence=>180
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_MEILENSTEIN_SUCHE_1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(980817032031066825)
,p_event_id=>wwv_flow_imp.id(413238441905746954)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P452_ONLY_DIFF'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(394302248996385603)
,p_event_id=>wwv_flow_imp.id(413238441905746954)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(413238948580746959)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(370181990815936058)
,p_name=>'Change switch'
,p_event_sequence=>190
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_ONLY_DIFF'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(980817357466066828)
,p_event_id=>wwv_flow_imp.id(370181990815936058)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P452_ONLY_DIFF'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370181890273936057)
,p_event_id=>wwv_flow_imp.id(370181990815936058)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(413240060361746970)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(357622802983193601)
,p_event_id=>wwv_flow_imp.id(370181990815936058)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(413238948580746959)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(326656200019178398)
,p_name=>'Pre_Visibility'
,p_event_sequence=>200
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_MEILENSTEIN_SUCHE_1'
,p_condition_element=>'P452_MEILENSTEIN_SUCHE_1'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(326656131969178397)
,p_event_id=>wwv_flow_imp.id(326656200019178398)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(337622692062617260)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(326656035440178396)
,p_event_id=>wwv_flow_imp.id(326656200019178398)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(337622692062617260)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(326655149417178388)
,p_name=>'Pre_Visibility_2'
,p_event_sequence=>210
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_MEILENSTEIN_SUCHE_2'
,p_condition_element=>'P452_MEILENSTEIN_SUCHE_2'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(326655049389178387)
,p_event_id=>wwv_flow_imp.id(326655149417178388)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(326655858924178395)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(326654984583178386)
,p_event_id=>wwv_flow_imp.id(326655149417178388)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(326655858924178395)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(326654925949178385)
,p_name=>'Pre1_Visibility'
,p_event_sequence=>220
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_ERSTE_SUCHE'
,p_condition_element=>'P452_ERSTE_SUCHE'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(326654738611178384)
,p_event_id=>wwv_flow_imp.id(326654925949178385)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(337622692062617260)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(326654637876178383)
,p_name=>'Pre2_Visibility'
,p_event_sequence=>230
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_ZWEITE_SUCHE'
,p_condition_element=>'P452_ZWEITE_SUCHE'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(326654634695178382)
,p_event_id=>wwv_flow_imp.id(326654637876178383)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(326655858924178395)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1068057706575307386)
,p_name=>'Set Hinweis'
,p_event_sequence=>240
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1068057635796307385)
,p_event_id=>wwv_flow_imp.id(1068057706575307386)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P452_HINWEIS'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CASE ',
'         WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' ',
unistr('         THEN ''W\00E4hle Suchergebnisse und Meilensteine zum Zusammenf\00FChren aus'' '),
'         ELSE ''Select search results and milestones to merge'' ',
'       END AS "LOV_VALUE" ',
'FROM dual;',
''))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1068057398703307383)
,p_name=>'change_Hinweis'
,p_event_sequence=>250
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_ERSTE_SUCHE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'($v(''P452_ERSTE_SUCHE'') !== 0) &&',
'($v(''P452_MEILENSTEIN_SUCHE_1'') == "") ',
'',
''))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1068058062785307390)
,p_event_id=>wwv_flow_imp.id(1068057398703307383)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Set_Hinweis'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P452_HINWEIS'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>unistr('select CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''W\00E4hle Meilenstein  f\00FCr Quellsuche 1  aus.'' ELSE ''Select Milestone for Sourcesearch 1.'' END from dual;')
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1068057215359307381)
,p_name=>'Change_Hinweis'
,p_event_sequence=>260
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_ZWEITE_SUCHE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'($v(''P452_ZWEITE_SUCHE'') !== 0) &&',
'($v(''P452_MEILENSTEIN_SUCHE_2'') == "") '))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1068057127185307380)
,p_event_id=>wwv_flow_imp.id(1068057215359307381)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Set Hinweis'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P452_HINWEIS'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>unistr('select CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''W\00E4hle Meilenstein  f\00FCr Quellsuche 2  aus.'' ELSE ''Select Milestone for Sourcesearch 2.'' END from dual;')
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1068056960561307379)
,p_name=>' Hinweis_wenn_alle _gesetzt'
,p_event_sequence=>270
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_MEILENSTEIN_SUCHE_1'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'($v(''P452_ERSTE_SUCHE'') !== 0) &&',
'($v(''P452_ZWEITE_SUCHE'') !== 0) &&',
'($v(''P452_MEILENSTEIN_SUCHE_1'') !== "") &&',
'($v(''P452_MEILENSTEIN_SUCHE_2'') !== "")'))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1068056858198307378)
,p_event_id=>wwv_flow_imp.id(1068056960561307379)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P452_HINWEIS'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>' !'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1068056822718307377)
,p_name=>'Hinweis_wenn_alle_gesetzt'
,p_event_sequence=>280
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_MEILENSTEIN_SUCHE_2'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'($v(''P452_ERSTE_SUCHE'') !== 0) &&',
'($v(''P452_ZWEITE_SUCHE'') !== 0) &&',
'($v(''P452_MEILENSTEIN_SUCHE_1'') !== 0) &&',
'($v(''P452_MEILENSTEIN_SUCHE_2'') !== 0)'))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1068056677488307376)
,p_event_id=>wwv_flow_imp.id(1068056822718307377)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P452_HINWEIS'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>' !'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1068056581409307375)
,p_name=>'change Hinweis_2'
,p_event_sequence=>290
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_ERSTE_SUCHE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'($v(''P452_ERSTE_SUCHE'') == 0)'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1068056451707307374)
,p_event_id=>wwv_flow_imp.id(1068056581409307375)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P452_HINWEIS'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>unistr('select CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''W\00E4hle Quellsuche 1'' ELSE ''Select Sourcesearch 1'' END from dual;')
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1068056416004307373)
,p_name=>'change_hinweis_2'
,p_event_sequence=>300
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_ZWEITE_SUCHE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'($v(''P452_ZWEITE_SUCHE'') == 0) ',
''))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1068056279503307372)
,p_event_id=>wwv_flow_imp.id(1068056416004307373)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P452_HINWEIS'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>unistr('select CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''W\00E4hle Quellsuche 2'' ELSE ''Select Sourcesearch 2'' END from dual;')
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1068056140174307371)
,p_name=>'Hinw_wenn_Quell1_null'
,p_event_sequence=>310
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_MEILENSTEIN_SUCHE_1'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'($v(''P452_ERSTE_SUCHE'') == 0) '
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1068056071473307370)
,p_event_id=>wwv_flow_imp.id(1068056140174307371)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P452_HINWEIS'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>unistr('select CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''W\00E4hle Quellsuche 1'' ELSE ''Select Sourcesearch 1'' END from dual;')
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1068055967149307369)
,p_name=>'Hinw_wenn _Quell2_null'
,p_event_sequence=>320
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_MEILENSTEIN_SUCHE_2'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'($v(''P452_ZWEITE_SUCHE'') == 0)'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1068055845089307368)
,p_event_id=>wwv_flow_imp.id(1068055967149307369)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P452_HINWEIS'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>unistr('select CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''W\00E4hle Quellsuche 2'' ELSE ''Select Sourcesearch 2'' END from dual;')
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1068055713139307366)
,p_name=>'Hinw_wenn Quell2 nicht gesetzt'
,p_event_sequence=>330
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P452_MEILENSTEIN_SUCHE_1'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'( $v(''P452_ERSTE_SUCHE'') !== 0) &&',
'( $v(''P452_ZWEITE_SUCHE'') == 0) &&',
'( $v(''P452_MEILENSTEIN_SUCHE_1'') !== "")'))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1068055593008307365)
,p_event_id=>wwv_flow_imp.id(1068055713139307366)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P452_HINWEIS'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>unistr('select CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''W\00E4hle Quellsuche 2'' ELSE ''Select Sourcesearch 2'' END from dual;')
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(401713393254190978)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Cleanup'
,p_attribute_01=>'CLEAR_CACHE_FOR_ITEMS'
,p_attribute_03=>'P452_BEZEICHNUNG,P452_BESCHREIBUNG,P452_ERSTE_SUCHE,P452_MEILENSTEIN_SUCHE_1,P452_ZWEITE_SUCHE,P452_MEILENSTEIN_SUCHE_2,P452_NEW_SUCHE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3270498922645197257
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(401713011505190977)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Merge suche'
,p_process_sql_clob=>'   :P452_NEW_SUCHE := pck_ri_suche.fmergeMSsuche(:P452_ERSTE_SUCHE, :P452_MEILENSTEIN_SUCHE_1, :P452_ZWEITE_SUCHE, :P452_MEILENSTEIN_SUCHE_2, :P452_BEZEICHNUNG, :P452_BESCHREIBUNG );'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(401719319600191018)
,p_internal_uid=>3270499304394197258
);
wwv_flow_imp.component_end;
end;
/
