prompt --application/pages/page_00322
begin
--   Manifest
--     PAGE: 00322
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>322
,p_name=>'Merge Suchergebnissen'
,p_alias=>'MERGE-SUCHERGEBNISSEN'
,p_page_mode=>'MODAL'
,p_step_title=>'Merge Suchergebnissen'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(677276717737185502)
,p_plug_name=>'&nbsp'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(669629292787747102)
,p_plug_name=>'&nbsp'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(3414114104242820540)
,p_plug_display_sequence=>10
,p_plug_source=>unistr('W\00E4hle Meilensteine zu Suchergebnisse zum Zusammenf\00FChren aus.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(669629214023747101)
,p_plug_name=>'&nbsp'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noBorder'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(677276237937185498)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(669629214023747101)
,p_button_name=>'Save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00DCbernehmen')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(677215876730271841)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(669629214023747101)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(569231000783407185)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(677276717737185502)
,p_button_name=>'SUCHE1_ANZEIGEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Anzeigen'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:605:&SESSION.::&DEBUG.:605:P605_SUCHEID,P605_SUCHE_INDEX:\&P322_ERSTE_SUCHE.\,\&P322_MEILENSTEIN_SUCHE_1.\'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(569230895979407184)
,p_button_sequence=>160
,p_button_plug_id=>wwv_flow_imp.id(677276717737185502)
,p_button_name=>'SUCHE2_ANZEIGEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Anzeigen'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:605:&SESSION.::&DEBUG.::P605_SUCHEID,P605_SUCHE_INDEX:\&P322_ZWEITE_SUCHE.\,\&P322_MEILENSTEIN_SUCHE_2.\'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(569230758145407183)
,p_button_sequence=>190
,p_button_plug_id=>wwv_flow_imp.id(677276717737185502)
,p_button_name=>'SUCHEN_VERGLEICHEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Suchen Vergleichen'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:323:&SESSION.::&DEBUG.::P323_MS1,P323_MS2,P323_SUCHE1ID,P323_SUCHE2ID:&P322_MEILENSTEIN_SUCHE_1.,&P322_MEILENSTEIN_SUCHE_2.,&P322_ERSTE_SUCHE.,&P322_ZWEITE_SUCHE.'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(675195241675506701)
,p_branch_name=>'CLOSE 320'
,p_branch_action=>'f?p=&APP_ID.:320:&SESSION.::&DEBUG.::P320_SUCHEID:&P322_NEW_SUCHE.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(677276237937185498)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(677276607586185501)
,p_name=>'P322_ALERT_MS1'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(677276717737185502)
,p_prompt=>'&nbsp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_icon_css_classes=>'fa-exclamation-triangle-o'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(677276469285185500)
,p_name=>'P322_ERSTE_SUCHE'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(677276717737185502)
,p_prompt=>'Quelle: Erste Suche'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select BEZEICHNUNG  as d,      ',
'      SUCHEID as r',
'  from T_SUCHE_JSON where benutzerid = :G_benutzerid;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- select -'
,p_lov_null_value=>'0'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(677276364532185499)
,p_name=>'P322_ZWEITE_SUCHE'
,p_is_required=>true
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(677276717737185502)
,p_prompt=>'Quelle: Zweite Suche'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select BEZEICHNUNG  as d,      ',
'      SUCHEID as r',
'  from T_SUCHE_JSON where benutzerid = :G_benutzerid;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- select -'
,p_lov_null_value=>'0'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(675481880284014103)
,p_name=>'P322_BEZEICHNUNG'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(677276717737185502)
,p_prompt=>'Bezeichnung'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(675481827990014102)
,p_name=>'P322_BESCHREIBUNG'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(677276717737185502)
,p_prompt=>'Beschreibung'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(675481604199014100)
,p_name=>'P322_MEILENSTEIN_SUCHE_1'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(677276717737185502)
,p_prompt=>'Meilenstein der Quellsuche 1'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:1;1,2;2,3;3'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(675481447025014099)
,p_name=>'P322_MEILENSTEIN_SUCHE_2'
,p_is_required=>true
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(677276717737185502)
,p_prompt=>'Meilenstein der Quellsuche 2'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:1;1,2;2,3;3'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(675195482230506703)
,p_name=>'P322_ALERT_MS2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(677276717737185502)
,p_prompt=>'&nbsp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_icon_css_classes=>'fa-exclamation-triangle-o'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(675195177644506700)
,p_name=>'P322_NEW_SUCHE'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(677276717737185502)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(677275902899185494)
,p_name=>'Close Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(677215876730271841)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(677275796791185493)
,p_event_id=>wwv_flow_imp.id(677275902899185494)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(675175437312323003)
,p_name=>'Check_mSuche1_Daten'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P322_MEILENSTEIN_SUCHE_1,P322_ERSTE_SUCHE'
,p_condition_element=>'P322_ERSTE_SUCHE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(675175374998323002)
,p_event_id=>wwv_flow_imp.id(675175437312323003)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- check if selected :P322_MEILENSTEIN_SUCHE_1 contains data',
'   declare js_data varchar2(4000) ;',
' begin',
':P322_ALERT_MS1 :='''';',
' ',
' BEGIN',
' SELECT nvl(daten,''#'') into js_data',
'   FROM  t_suche_json t,',
'         json_table',
'        ( t.suchdaten, ''$[*]'' COLUMNS ( order_id for ordinality, daten clob format json path ''$'' )',
'        )',
'  WHERE sucheid = :P322_ERSTE_SUCHE and order_id = to_number(:P322_MEILENSTEIN_SUCHE_1);',
'  EXCEPTION ',
'   WHEN NO_DATA_FOUND THEN',
'     js_data :=''#'';',
'   END;',
'  if js_data is null  or length(js_data) <2 then',
unistr('   :P322_ALERT_MS1 := ''Meilenstein der Suche enth\00E4lt keine Daten!'';'),
'  end if;',
'  ',
'  end;'))
,p_attribute_02=>'P322_ERSTE_SUCHE,P322_MEILENSTEIN_SUCHE_1'
,p_attribute_03=>'P322_ALERT_MS1'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(674484567212847203)
,p_name=>'IsAlert'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P322_ALERT_MS1'
,p_condition_element=>'P322_ALERT_MS1'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>unistr('Meilenstein der Suche enth\00E4lt keine Daten!')
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(674484483577847202)
,p_event_id=>wwv_flow_imp.id(674484567212847203)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P322_ALERT_MS1'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(674484357029847201)
,p_event_id=>wwv_flow_imp.id(674484567212847203)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P322_ALERT_MS1'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(674484031846847197)
,p_name=>'IsAlert2'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P322_ALERT_MS2'
,p_condition_element=>'P322_ALERT_MS2'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>unistr('Meilenstein der Suche enth\00E4lt keine Daten!')
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(674483860528847196)
,p_event_id=>wwv_flow_imp.id(674484031846847197)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P322_ALERT_MS2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(674483746851847195)
,p_event_id=>wwv_flow_imp.id(674484031846847197)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P322_ALERT_MS2'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(674483680254847194)
,p_name=>'ChangeVal'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P322_ERSTE_SUCHE'
,p_condition_element=>'P322_MEILENSTEIN_SUCHE_1'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(674483473781847192)
,p_event_id=>wwv_flow_imp.id(674483680254847194)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P322_MEILENSTEIN_SUCHE_1'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(669812749290498498)
,p_name=>'Check_suche_2_Daten'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P322_ZWEITE_SUCHE,P322_MEILENSTEIN_SUCHE_2'
,p_condition_element=>'P322_ZWEITE_SUCHE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(669812647949498497)
,p_event_id=>wwv_flow_imp.id(669812749290498498)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare js_data varchar2(4000) ;',
' begin',
':P322_ALERT_MS2 :='''';',
' ',
' BEGIN',
' SELECT nvl(daten,''#'') into js_data',
'   FROM  t_suche_json t,',
'         json_table',
'        ( t.suchdaten, ''$[*]'' COLUMNS ( order_id for ordinality, daten clob format json path ''$'' )',
'        )',
'  WHERE sucheid = :P322_ZWEITE_SUCHE and order_id = to_number(:P322_MEILENSTEIN_SUCHE_2);',
'  EXCEPTION ',
'   WHEN NO_DATA_FOUND THEN',
'     js_data :=''#'';',
'   END;',
'  if js_data is null  or length(js_data) <2 then',
unistr('   :P322_ALERT_MS2 := ''Meilenstein der Suche enth\00E4lt keine Daten!'';'),
'  end if;',
'  ',
'  end;'))
,p_attribute_02=>'P322_ZWEITE_SUCHE,P322_MEILENSTEIN_SUCHE_2'
,p_attribute_03=>'P322_ALERT_MS2'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(669812566548498496)
,p_name=>'Change_Val2'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P322_ZWEITE_SUCHE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(669812519246498495)
,p_event_id=>wwv_flow_imp.id(669812566548498496)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P322_MEILENSTEIN_SUCHE_2'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(677275182772185487)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Cleanup'
,p_attribute_01=>'CLEAR_CACHE_FOR_ITEMS'
,p_attribute_03=>'P322_BEZEICHNUNG,P322_BESCHREIBUNG,P322_ERSTE_SUCHE,P322_MEILENSTEIN_SUCHE_1,P322_ZWEITE_SUCHE,P322_MEILENSTEIN_SUCHE_2,P322_NEW_SUCHE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2994937133127202748
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(675195101786506699)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Merge suche'
,p_process_sql_clob=>'   :P322_NEW_SUCHE := pck_ri_suche.fmergesuche(:P322_ERSTE_SUCHE, :P322_MEILENSTEIN_SUCHE_1, :P322_ZWEITE_SUCHE, :P322_MEILENSTEIN_SUCHE_2, :P322_BEZEICHNUNG, :P322_BESCHREIBUNG );'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(677276237937185498)
,p_internal_uid=>2997017214112881536
);
wwv_flow_imp.component_end;
end;
/
