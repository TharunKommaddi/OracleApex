prompt --application/pages/page_00590
begin
--   Manifest
--     PAGE: 00590
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>590
,p_name=>'Konzern Jira Tickets'
,p_alias=>'KONZERN-JIRA-TICK'
,p_step_title=>'Konzern Jira Tickets'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(374245908964172148)
,p_plug_name=>'Konzern Jira Ticket'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_vo as (',
'    select konzern_jira_ticketid, listagg(trim(vo.vorschrift_nummer), '', '') within group (order by vo.vorschrift_nummer) as liste_vorschriften',
'    from t_konzern_jira_ticket_ref_vorschrift kjrv',
'    left outer join t_vorschrift vo on (kjrv.vorschriftid = vo.vorschriftid)',
'    group by kjrv.konzern_jira_ticketid    ',
'),',
' cte_ak as (',
'    select konzern_jira_ticketid, listagg(trim(ak.kurz), '', '') within group (order by ak.kurz) as liste_ak',
'    from t_konzern_jira_ticket_ref_et_b_ak kjrak',
'    left outer join t_et_b_ak ak on (kjrak.et_b_akid = ak.et_b_akid)',
'    group by kjrak.konzern_jira_ticketid    ',
'),',
' cte_k_cluster as (',
'    select konzern_jira_ticketid, listagg(trim(kc.bezeichnung), '', '') within group (order by kc.bezeichnung) as liste_cluster',
'    from t_konzern_jira_ticket_ref_konzern_cluster kjrkc',
'    left outer join t_konzern_cluster kc on (kjrkc.konzern_clusterid = kc.konzern_clusterid)',
'    group by kjrkc.konzern_jira_ticketid    ',
')',
'',
'select kj.KONZERN_JIRA_TICKETID,',
'      PCK_RI.fCreateLinkIfUrl("LINK", 250) as LINK,',
'       TICKETNR,',
'      cte_vo.liste_vorschriften,',
'       cte_ak.liste_ak,',
'       cte_k_cluster.liste_cluster',
'  from T_konzern_jira_ticket kj',
'  left outer join cte_vo on (kj.konzern_jira_ticketid = cte_vo.konzern_jira_ticketid)',
'  left outer join cte_ak  on (cte_ak.konzern_jira_ticketid = kj.konzern_jira_ticketid)',
'  left outer join cte_k_cluster  on (cte_k_cluster.konzern_jira_ticketid = kj.konzern_jira_ticketid)',
'  ORDER BY ticketnr'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Konzern Jira Ticket'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(374245511166172148)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:595:&SESSION.::&DEBUG.:RP,595:P595_KONZERN_JIRA_TICKETID:\#KONZERN_JIRA_TICKETID#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(2652734963787598041)
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>738447425928962256
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(374245371795172147)
,p_db_column_name=>'KONZERN_JIRA_TICKETID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Konzern Jira Ticketid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(374244974903172146)
,p_db_column_name=>'LINK'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Link'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(374244621591172145)
,p_db_column_name=>'TICKETNR'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Ticketnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(375330134875175267)
,p_db_column_name=>'LISTE_VORSCHRIFTEN'
,p_display_order=>13
,p_column_identifier=>'D'
,p_column_label=>'Vorschriften'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(375329985326175266)
,p_db_column_name=>'LISTE_AK'
,p_display_order=>23
,p_column_identifier=>'E'
,p_column_label=>'Arbeitskreise'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(375329846872175265)
,p_db_column_name=>'LISTE_CLUSTER'
,p_display_order=>33
,p_column_identifier=>'F'
,p_column_label=>'Konzern Cluster'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(374238156472081333)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'7384548'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TICKETNR:LINK:LISTE_VORSCHRIFTEN:LISTE_AK:LISTE_CLUSTER:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(374242536341172133)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(374245908964172148)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:595:&SESSION.::&DEBUG.:595::'
,p_security_scheme=>wwv_flow_imp.id(2652734963787598041)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(374243467582172134)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(374245908964172148)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(374242973403172133)
,p_event_id=>wwv_flow_imp.id(374243467582172134)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(374245908964172148)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
