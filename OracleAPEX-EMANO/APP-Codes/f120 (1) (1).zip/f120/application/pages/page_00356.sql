prompt --application/pages/page_00356
begin
--   Manifest
--     PAGE: 00356
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>356
,p_name=>'Historie Land'
,p_alias=>'HISTORIE-LAND'
,p_page_mode=>'MODAL'
,p_step_title=>'Historie Land'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IR_HIST .t-fht-tbody {max-height: calc(100vh - 200px)}',
'.t-Body-topButton {display: none !important}',
'.t-Body-content {padding-bottom: 3px !important}',
'.t-Body {margin-bottom: 3px !important}',
'.t-Body-contentInner {padding-bottom: 0px !important}'))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_page_comment=>'b'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(478682448223625728)
,p_plug_name=>'Historie Land'
,p_region_name=>'IR_HIST'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  listagg(l.b_nummer||''-''||l.land, '','') as Laender , ',
'    vrl.bemerkung as Kommentar,',
'    nvl2(vrl.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) AS letzte_AENDERUNG_BENUTZER,',
'      --  pck_ri_history.fdiff(tv.vorschrift_nummer, LAG(tv.vorschrift_nummer) over(partition by vrl.VORSCHRIFTID, tv.vorschrift_nummer order by vrl.letzte_aenderung_datum asc), aktion) as vorschrift_nummer,',
'    to_char(vrl.letzte_aenderung_datum, ''dd.mm.yyyy HH24:mi:ss'') as aenderung_datum,  ',
'  -- pck_ri_history.fdiff( vrl.bemerkung, LAG(vrl.bemerkung) over(partition by vrl.VORSCHRIFTID, tv.vorschrift_nummer order by vrl.letzte_aenderung_datum asc)) as KOMMENTAR,',
'    vrl.aktion as aktion, ',
'    decode(geloescht, 1, ''ja'', 0, ''Nein'', 0) as geloescht',
' from T_H_Vorschrift_ref_land vrl',
' left outer join t_vorschrift tv on (tv.vorschriftid = vrl.VORSCHRIFTID)',
' join t_land l on (l.landid = vrl.landid)',
' left outer join t_benutzer b on b.benutzerid = vrl.letzte_aenderung_benutzerid',
' ',
' where vrl.vorschriftid in ( :P356_VORSCHRIFTID )',
' group by   vrl.letzte_aenderung_datum, vrl.aktion,',
'       nvl2(vrl.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null), vrl.bemerkung,',
'        decode(geloescht, 1, ''ja'', 0, ''Nein'', 0) ',
'      -- pck_ri_history.fdiff( vrl.bemerkung, LAG(vrl.bemerkung) over(partition by vrl.VORSCHRIFTID, tv.vorschrift_nummer order by vrl.letzte_aenderung_datum asc))',
' order by  vrl.letzte_aenderung_datum desc',
' /*',
' with ctl_b_nummern as (',
'    select vorschriftid, listagg(b_nummer||''-''||land, '', '') within group (order by b_nummer) as b_nummern',
'    from (',
'        select distinct vrtrl.vorschriftid, l.b_nummer,',
'        CASE ',
'             WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.Land ELSE l.Land_eng END AS Land',
'       from t_vorschrift_ref_land vrtrl ',
'        join t_land l on l.landid = vrtrl.landid',
'        where vrtrl.geloescht = 0)',
'    group by vorschriftid',
')',
'select ',
'       vrl.letzte_aenderung_datum,',
'    -- b.nachname || '', '' || b.vorname as user_name,',
'     nvl2(vrl.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, null) AS letzte_AENDERUNG_BENUTZER,',
'    vrl.VORSCHRIFTID,',
'    pck_ri_history.fdiff(tv.vorschrift_nummer, LAG(tv.vorschrift_nummer) over(partition by vrl.VORSCHRIFTID, tv.vorschrift_nummer order by vrl.letzte_aenderung_datum asc), aktion) as vorschrift_nummer,',
'    cbn.b_nummern,',
'    --vrl.bemerkung as Kommentar,',
'   pck_ri_history.fdiff( vrl.bemerkung, LAG(vrl.bemerkung) over(partition by vrl.VORSCHRIFTID, tv.vorschrift_nummer order by vrl.letzte_aenderung_datum asc)) as KOMMENTAR,',
'   ',
'    vrl.AKTION',
'from T_H_VORSCHRIFT_REF_LAND vrl',
'left outer join t_benutzer b on b.benutzerid = vrl.letzte_aenderung_benutzerid',
'left outer join t_vorschrift tv on (tv.vorschriftid = vrl.VORSCHRIFTID)',
'left outer join ctl_b_nummern cbn on vrl.VORSCHRIFTID = cbn.VORSCHRIFTID',
'where vrl.VORSCHRIFTID = :P356_VORSCHRIFTID',
'order by vrl.LETZTE_AENDERUNG_DATUM desc',
'*/',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P356_VORSCHRIFTID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Historie Land'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(478682371686625728)
,p_name=>'Historie Vorschrift Kerndaten'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>unistr('Es gibt keine historischen Verkn\00FCpfungen f\00FCr diese Vorschrift.')
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'mailto:#EMAIL#?body=#PERMALINK#'
,p_detail_link_text=>'<span class="fa fa-envelope-o" aria-hidden="true"></span></a>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>634010565408508676
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(837147523521650666)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>60
,p_column_identifier=>'BS'
,p_column_label=>unistr('\00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(130352400383775281)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>100
,p_column_identifier=>'CB'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(130352148705775279)
,p_db_column_name=>'LAENDER'
,p_display_order=>110
,p_column_identifier=>'CD'
,p_column_label=>unistr('L\00E4nder')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(130351962492775277)
,p_db_column_name=>'GELOESCHT'
,p_display_order=>130
,p_column_identifier=>'CF'
,p_column_label=>unistr('Gel\00F6scht')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(130351933910775276)
,p_db_column_name=>'AENDERUNG_DATUM'
,p_display_order=>140
,p_column_identifier=>'CG'
,p_column_label=>unistr('\00C4nderung Datum')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(130351809183775275)
,p_db_column_name=>'AKTION'
,p_display_order=>150
,p_column_identifier=>'CH'
,p_column_label=>'Aktion'
,p_column_html_expression=>'<span class="fa #AKTION#" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(958145941627486314)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(478664197332612555)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'964101'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LETZTE_AENDERUNG_BENUTZER:AENDERUNG_DATUM:AKTION:LAENDER:GELOESCHT:KOMMENTAR:'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(834813696604794171)
,p_name=>'P356_VORSCHRIFTID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(834398818440256385)
,p_name=>'P356_VORSCHRIFTNUMMER'
,p_item_sequence=>10
,p_use_cache_before_default=>'NO'
,p_source=>'select VORSCHRIFT_NUMMER from t_vorschrift where VORSCHRIFTID= :P356_VORSCHRIFTID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
