prompt --application/pages/page_00600
begin
--   Manifest
--     PAGE: 00600
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>600
,p_name=>'Suche Dialoganzeige'
,p_alias=>'SUCHE-DIALOGANZEIGE'
,p_page_mode=>'MODAL'
,p_step_title=>'Suche Dialoganzeige'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'600'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(569232763312407203)
,p_plug_name=>unistr('Anzeige ausgew\00E4hlte Suche')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(569232579451407201)
,p_name=>'Suchergebnis'
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT se.Vorschriftnummer, se.vorschriftid, se.regelnummer as Regel, se.Risiko ',
'  , null as supplement_vor_in_kraft ',
'  ,  p.sop_gleich_oder_nach_datum_in_kraft    sop_nach_in_kraft ',
'  ,   p.SOP_IST_NACH_ODER_GLECIH_DATUM_ALLE_FAHRZEUGE_     alle_fzg_vor_sop ',
'  , p.sop_ist_nach_oder_gleich_datum_neue_typen   neue_typen_vor_sop',
' , p.eop_liegt_nach_oder_gleich_datum_alle_fahrzeuge  alle_fzg_vor_eop',
'      -- ms_parameterid',
'   FROM t_ms_suchergebniss se',
'    JOIN t_MS_parameter p on (p.ms_parameterid = se.ms_parameterid)',
'   ',
'   where sucheid = :P600_SUCHEID  and meilenstein = to_number(:P600_SUCHE_INDEX);',
'                       '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(413242442898746994)
,p_query_column_id=>1
,p_column_alias=>'VORSCHRIFTNUMMER'
,p_column_display_sequence=>9
,p_column_heading=>'Vorschriftnummer'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(569232368542407199)
,p_query_column_id=>2
,p_column_alias=>'VORSCHRIFTID'
,p_column_display_sequence=>1
,p_column_heading=>'Vorschriftid'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(569232244229407198)
,p_query_column_id=>3
,p_column_alias=>'REGEL'
,p_column_display_sequence=>2
,p_column_heading=>'Regel'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(569232229351407197)
,p_query_column_id=>4
,p_column_alias=>'RISIKO'
,p_column_display_sequence=>3
,p_column_heading=>'Risiko'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(569232122708407196)
,p_query_column_id=>5
,p_column_alias=>'SUPPLEMENT_VOR_IN_KRAFT'
,p_column_display_sequence=>4
,p_column_heading=>'Supplement Vor In Kraft'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'STATIC:Ja;1,Nein;0'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(569232023643407195)
,p_query_column_id=>6
,p_column_alias=>'SOP_NACH_IN_KRAFT'
,p_column_display_sequence=>5
,p_column_heading=>'Sop Nach In Kraft'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'STATIC:Ja;1,Nein;0'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(569231936678407194)
,p_query_column_id=>7
,p_column_alias=>'ALLE_FZG_VOR_SOP'
,p_column_display_sequence=>6
,p_column_heading=>'Alle Fzg Vor Sop'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'STATIC:Ja;1,Nein;0'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(569231762762407193)
,p_query_column_id=>8
,p_column_alias=>'NEUE_TYPEN_VOR_SOP'
,p_column_display_sequence=>7
,p_column_heading=>'Neue Typen Vor Sop'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'STATIC:Ja;1,Nein;0'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(569231672193407192)
,p_query_column_id=>9
,p_column_alias=>'ALLE_FZG_VOR_EOP'
,p_column_display_sequence=>8
,p_column_heading=>'Alle Fzg Vor Eop'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'STATIC:Ja;1,Nein;0'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(569231565923407191)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(569231472182407190)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(569231565923407191)
,p_button_name=>'CLOSE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(569232681803407202)
,p_name=>'P600_SUCHE_TEMPID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(569232579451407201)
,p_prompt=>'IDs'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(569231056857407186)
,p_name=>'P600_SUCHE_INDEX'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(569232579451407201)
,p_prompt=>'Index'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(413242581586746995)
,p_name=>'P600_SUCHEID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(569232579451407201)
,p_prompt=>'Sucheid'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(569231357554407189)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(569231472182407190)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(569231323759407188)
,p_event_id=>wwv_flow_imp.id(569231357554407189)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp.component_end;
end;
/
