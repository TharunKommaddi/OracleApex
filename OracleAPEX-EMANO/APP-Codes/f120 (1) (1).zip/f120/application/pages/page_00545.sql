prompt --application/pages/page_00545
begin
--   Manifest
--     PAGE: 00545
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>545
,p_name=>unistr('Vorschrift kopieren abschlie\00DFen')
,p_alias=>unistr('VORSCHRIFT-KOPIEREN-ABSCHLIE\00DFEN')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Vorschrift kopieren abschlie\00DFen')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Click auf Checkbox in Tabellenheader: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'/*$(''#report-laender-themen'').on(''click'', ''th input'', function() {',
'    var check_all = $("#report-laender-themen").find("th input:checked").is(":checked");',
'',
'    $("#report-laender-themen").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'    setSelectedEntries();',
'});',
'*/',
'/* Click auf Checkbox in Tabellenzeile: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'',
'/*$(''#report-laender-themen'').on(''click'', ''td input'', function() {',
'    setSelectedEntries();',
'});',
'',
'function setSelectedEntries() {',
'    var sel_rows = $("#P545_SELECTED_LAENDER_THEMEN");',
'    sel_rows.val("");',
'    $("#report-laender-themen").find("td input:checked").each(function() {',
'      // alert(this.value);',
'      if(sel_rows.val().length > 0) {',
'        sel_rows.val(sel_rows.val() + ":");    ',
'      }',
'      sel_rows.val(sel_rows.val() + this.value);',
'    });',
'    alert(sel_rows.val());',
'}',
'*/',
'',
'/* Click auf Checkbox in Tabellenheader: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'$(''#report-laender'').on(''click'', ''th input'', function() {',
'    var check_all = $("#report-laender").find("th input:checked").is(":checked");',
'',
'    $("#report-laender").find("td input").each(function() {',
'        this.checked = check_all;',
'    });',
'',
'    setSelectedLandEntries();',
'});',
'',
'/* Click auf Checkbox in Tabellenzeile: alle selektieren ',
'',
unistr('   Nicht \00FCber Dynamic Action, da diese den Event-Listener nicht korrekt'),
unistr('   f\00FCr partial page refresh definiert. */'),
'',
'$(''#report-laender'').on(''click'', ''td input'', function() {',
'    setSelectedLandEntries();',
'});',
'',
'function setSelectedLandEntries() {',
'    var sel_rows = $("#P545_SELECTED_COUNTRIES");',
'    sel_rows.val("");',
'    $("#report-laender").find("td input:checked").each(function() {',
'      // alert(this.value);',
'      if(sel_rows.val().length > 0) {',
'        sel_rows.val(sel_rows.val() + ":");    ',
'      }',
'      sel_rows.val(sel_rows.val() + this.value);',
'    });',
'    //alert(sel_rows.val());',
'}',
'            ',
''))
,p_step_template=>wwv_flow_imp.id(3414113720492820539)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'400'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(301914402146952469)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(712760182011977984)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(3414143558979820565)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(301914240321952469)
,p_plug_name=>unistr('Vorschrift pr\00FCfen')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1063834673304809882)
,p_name=>unistr('L\00E4nder')
,p_region_name=>'report-laender'
,p_parent_plug_id=>wwv_flow_imp.id(301914240321952469)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vrl.landid,',
'APEX_ITEM.CHECKBOX(3,vrl.landid, null, :P545_SELECTED_COUNTRIES,'':'') as checkbox_l,',
'  l.land || '' ('' || l.b_nummer ||'')'' as land,',
'  vrl.bemerkung as bemerkung,',
'  vrl.letzte_aenderung_datum',
'from t_vorschrift_ref_land vrl',
'join t_land l on (l.landid = vrl.landid)',
'where vrl.vorschriftid = :P540_SOURCE_VORSCHRIFTID',
'  and vrl.geloescht <> 1',
'  ORDER BY l.land'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1063834546831809881)
,p_query_column_id=>1
,p_column_alias=>'LANDID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1063834460431809880)
,p_query_column_id=>2
,p_column_alias=>'CHECKBOX_L'
,p_column_display_sequence=>20
,p_column_heading=>'<input type="checkbox" onclick="$f_CheckFirstColumn(this)" />'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1063834419636809879)
,p_query_column_id=>3
,p_column_alias=>'LAND'
,p_column_display_sequence=>30
,p_column_heading=>'Land'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1040360969430747102)
,p_query_column_id=>4
,p_column_alias=>'BEMERKUNG'
,p_column_display_sequence=>40
,p_column_heading=>'Bemerkung'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1040360256194747095)
,p_query_column_id=>5
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>50
,p_column_heading=>'Letzte Aenderung Datum'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1063832969092809865)
,p_name=>'Themen'
,p_region_name=>'report-themen'
,p_parent_plug_id=>wwv_flow_imp.id(301914240321952469)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vrt.themaid,',
'    apex_item.CHECKBOX (4, vrt.themaid, null, :P545_SELECTED_THEMES,'':'') as checkbox_t,',
'    t.nummer || ''-'' ||t.bezeichnung as Thema,',
'    vrt.bemerkung bemerkung,',
'    vrt.letzte_aenderung_datum',
'from t_vorschrift_ref_thema vrt',
'join v_thema_baum t on (t.themaid = vrt.themaid)',
'where vrt.vorschriftid = :P540_SOURCE_VORSCHRIFTID',
'  and vrt.geloescht <> 1 ',
'  and vrt.themaid not in (select distinct themaid from T_thema_ref_et_b_AK  where et_b_AKid =1036)',
'  order by t.thema_sortorder'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414132514175820554)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1063832553335809861)
,p_query_column_id=>1
,p_column_alias=>'THEMAID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1063832525649809860)
,p_query_column_id=>2
,p_column_alias=>'CHECKBOX_T'
,p_column_display_sequence=>20
,p_column_heading=>'<input type="checkbox" onclick="$f_CheckFirstColumn(this)" />'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1063832430789809859)
,p_query_column_id=>3
,p_column_alias=>'THEMA'
,p_column_display_sequence=>30
,p_column_heading=>'Thema'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1040360485461747097)
,p_query_column_id=>4
,p_column_alias=>'BEMERKUNG'
,p_column_display_sequence=>40
,p_column_heading=>'Bemerkung'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1040360381270747096)
,p_query_column_id=>5
,p_column_alias=>'LETZTE_AENDERUNG_DATUM'
,p_column_display_sequence=>50
,p_column_heading=>'Letzte Aenderung Datum'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(301914151670952469)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(701850781774108814)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(301914151670952469)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(701849990396108810)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(301914151670952469)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Vorschrift kopieren'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(701850396150108810)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(301914151670952469)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>unistr('Zur\00FCck')
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(701848198982108761)
,p_branch_name=>'Go To Page 542'
,p_branch_action=>'f?p=&APP_ID.:542:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(701850396150108810)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(697276342413037096)
,p_branch_name=>'Go To Page 25'
,p_branch_action=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:&P545_NEW_VORSCHRIFTID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(701849990396108810)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1063834301317809878)
,p_name=>'P545_SELECTED_COUNTRIES'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1063834673304809882)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1063832302254809858)
,p_name=>'P545_SELECTED_THEMES'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1063832969092809865)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1040361096701747103)
,p_name=>'P545_LAND_BEMERKUNG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1063834673304809882)
,p_prompt=>unistr('Bemerkung f\00FCr gew\00E4hlte L\00E4nder')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>2
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'N',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1040360587022747098)
,p_name=>'P545_THEMEN_BEMERKUNG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1063832969092809865)
,p_prompt=>unistr('Bemerkung f\00FCr gew\00E4hlte Themen')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>2
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'N',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(929253506139458780)
,p_name=>'P545_NEW_VORSCHRIFTID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(878574381948383533)
,p_name=>'P545_QUERSCHNITTS_THEMEN_CB'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1063832969092809865)
,p_prompt=>'<b>Querschnitts  Themengebiete</b>'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  tra.Themaid --into :P104_QUERSCHNITT_THEMEN_CB ',
' from T_thema_ref_et_b_AK tra ',
'  left outer join T_THEMA t on (t.themaid = tra.themaid)',
'  join t_vorschrift_ref_thema vrt on (vrt.themaid = tra.themaid )',
'  where tra.et_b_AKid =1036 and vrt.vorschriftid =:P104_VORSCHRIFTID and  vrt.geloescht = 0;'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t.NUMMER || '' - '' ||t.bezeichnung d, t.Themaid r ',
'  from T_thema_ref_et_b_AK tra ',
'  join T_THEMA t on (t.themaid = tra.themaid)   ',
' where tra.et_b_AKid = 1036 -- querschnitt Themen'))
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(701849224212108769)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(701850781774108814)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(701848716896108764)
,p_event_id=>wwv_flow_imp.id(701849224212108769)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(697276517747037097)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'COPY_KERNDATEN'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lRowSourceVorschrift T_VORSCHRIFT%ROWTYPE;',
'BEGIN',
'    select * into lRowSourceVorschrift',
'    from t_vorschrift',
'    where vorschriftid = :P540_SOURCE_VORSCHRIFTID;',
'    ',
'    --debug('' vorher: P545_NEW_VORSCHRIFTID ='' || :P545_NEW_VORSCHRIFTID);',
'    if lRowSourceVorschrift.VORSCHRIFT_NUMMER is not null then',
'     --debug('' P540_NEW_PROGNOSE_QUALITAET '', :P540_NEW_PROGNOSE_QUALITAET);',
'     --debug(''FT_NUMMER; _ZDATUM_MODELLID; RIFT_TYPID; ..OUT_NORM_VALIDATION; TECHNOLOGIE'', ',
'    --     :P540_NEW_VORSCHRIFTNUMMER  ||''; '' ||  :P540_NEW_EINSATZDATUM_MODELLID ||''; '' ||  :P540_NEW_VORSCHRIFT_TYPID  ||''; '' || :P540_NEW_WITHOUT_NORM_VALIDATION   ||''; '' || :P540_NEW_TECHNOLOGIE ) ;',
'    -- debug (''..SATZDATUM_MODELLID; :P540_NEW_V.._TYPID; :P540_V.._NOTATION'', :P540_EINSATZDATUM_MODELLID ||''; '' || :P540_NEW_VORSCHRIFT_TYPID||''; '' ||:P540_NEW_VORSCHRIFT_NOTATION);',
'    ',
'    insert into t_vorschrift(VORSCHRIFT_NUMMER, VORSCHRIFT_BEZEICHNUNG, ',
'                PROGNOSE_QUALITAETID, JIRA_TICKET, ',
'                VORSCHRIFT_FREIGABESTATUSID, BEMERKUNG,',
'                --',
'                LINK_REQMAN,',
'                LINK_ZUR_VORSCHRIFT_DMS, LINK_ZUR_VORSCHRIFT_GETEX, ',
'                TYPSCHILD, LETZTE_AENDERUNG_DATUM, LETZTE_AENDERUNG_BENUTZERID,',
'                --',
'                WEBSITEID, WEBSITELINK, ',
'                EINSATZDATUM_MODELLID, VORSCHRIFT_TYPID, ',
'                --',
'                NORMID, WITHOUT_NORM_VALIDATION, HOMOLOGATION_MOEGLICH, ',
'                KSUID, VORSCHRIFT_STATUSID, ',
'                HOMOLOGATIONSRELEVANT, RXSWIN, ',
'                VORSCHRIFT_BEZEICHNUNG_ENG, --DEKRA_DATENSATZID, ',
'                COP_RELEVANT, ERSTELLUNG_DATUM, ',
'                TECHNOLOGIE,',
'                mj_schalter_status,',
'                phasein_enthalten,',
'                revisionszaehler,',
'                getex_vergleich_bitmaske,',
'                master',
'            )',
'    values (trim(:P540_NEW_VORSCHRIFTNUMMER), :P540_NEW_VORSCHRIFT_BEZEICHNUNG,',
'                :P540_NEW_PROGNOSE_QUALITAET,   --lRowSourceVorschrift.PROGNOSE_QUALITAET,',
'                 '''', -- lRowSourceVorschrift.JIRA_TICKET, ',
'                1,            :P540_NEW_BEMERKUNG, ',
'                --',
'                :P540_NEW_LINK_REQMAN,',
'                :P540_NEW_LINK_ZUR_VORSCHRIFT_DMS, :P540_NEW_LINK_ZUR_VORSCHRIFT_GETEX, ',
'                lRowSourceVorschrift.TYPSCHILD, sysdate, pck_ri.fgetuserid,',
'                --',
'                :P540_NEW_WEBSITEID, :P540_NEW_WEBSITELINK, ',
'                :P540_NEW_EINSATZDATUM_MODELLID,   :P540_NEW_VORSCHRIFT_TYPID, ',
'                --',
'                :P540_NEW_VORSCHRIFT_NOTATION, :P540_NEW_WITHOUT_NORM_VALIDATION, lRowSourceVorschrift.HOMOLOGATION_MOEGLICH, ',
'                :P540_NEW_KSU,  :P540_NEW_VORSCHRIFT_STATUSID,  --lRowSourceVorschrift.VORSCHRIFT_STATUSID, ',
'                :P540_NEW_HOMOLOGATIONSRELEVANT, :P540_NEW_RXSWIN,',
'                 '''', --null,  --lRowSourceVorschrift.VORSCHRIFT_BEZEICHNUNG_ENG, lRowSourceVorschrift.DEKRA_DATENSATZID, ',
'                 lRowSourceVorschrift.COP_RELEVANT, sysdate, ',
'                :P540_NEW_TECHNOLOGIE,',
'                case when :P540_NEW_EINSATZDATUM_MODELLID =30',
'				then 1	 else 0 end,',
'                 :P544_PHASEIN_ENTHALTEN,',
'                 1,',
'                -1,',
'                10',
'    )',
'    returning vorschriftid into :P545_NEW_VORSCHRIFTID;',
'     --debug('' nachher: P545_NEW_VORSCHRIFTID= '' , :P545_NEW_VORSCHRIFTID);',
'    end if;',
'    ',
'    ',
'    if :P545_NEW_VORSCHRIFTID is not null then',
'      insert into t_vorschrift_ref_fahrzeugklasse (VORSCHRIFTID, FAHRZEUGKLASSEID )',
'      select  :P545_NEW_VORSCHRIFTID, ',
'           column_value  from table(apex_string.split_numbers(:P540_NEW_FAHRZEUGKLASSE, '':''));',
'    end if;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'kern daten nicht gespeichert'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(701849990396108810)
,p_internal_uid=>2974935798152351138
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(591079343506850457)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Copy Einsatzdaten'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'INSERT INTO t_VORSCHRIFT_ref_EINSATZDATUM_TYP ( ',
'            VORSCHRIFTID, EINSATZDATUM_TYPID, ',
'            EINSATZDATUM, ',
'            EINSATZDATUM_TEXT, ',
'            --MANUELLE_EINTRAGUNG, ',
'            Modeljahr)',
'SELECT  :P545_NEW_VORSCHRIFTID, EINSATZDATUM_TYPID, ',
'--to_date(einsatzdatum, ''dd.mm.yyyy''), ',
'       case when (EINSATZDATUM_TYPID in (1041 ) and modeljahr is not null) then to_date(''01.01.''||(to_number(modeljahr) +1), ''dd.mm.yyyy'') ',
'           when (EINSATZDATUM_TYPID in (1031 ) and modeljahr is not null) then to_date(''31.12.''|| to_number(modeljahr ), ''dd.mm.yyyy'')',
'           when (EINSATZDATUM_TYPID in (1030 ) and modeljahr is not null) then to_date(''01.02.''||(to_number(modeljahr) -1), ''dd.mm.yyyy'') ',
'           else to_date(einsatzdatum) end, ',
'           einsatzdatum_text, ',
'           --1,',
'            case when EINSATZDATUM_TYPID in ( 1041,1030,1031) then to_date(modeljahr, ''yyyy'') else null end ',
' FROM JSON_TABLE( :P544_EINSATZDATEN, ''$[*]'' COLUMNS (',
'           EINSATZDATUM_TYP    VARCHAR2(40 CHAR) PATH ''$.einsatzDatum'', ',
'           EINSATZDATUM_TYPID    number PATH ''$.einsatzDatumId'', ',
'           einsatzdatum    VARCHAR2(40 CHAR) PATH ''$.datum'',',
'           modeljahr    VARCHAR2(40 CHAR) PATH ''$.modeljahr'', ',
'           einsatzdatum_text    VARCHAR2(250 CHAR) PATH ''$.bemerkung'' )',
'        ) where :P544_EINSATZDATEN IS NOT NULL;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(701849990396108810)
,p_internal_uid=>3081132972392537778
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(929252340326458769)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Copy Keywords'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P545_NEW_VORSCHRIFTID IS NOT NULL THEN',
'  insert into t_vorschrift_ref_schlagwort (vorschriftid, schlagwortid )',
'  ',
'  select :P545_NEW_VORSCHRIFTID, vrs.schlagwortid from t_vorschrift_ref_schlagwort vrs',
'   where vrs.vorschriftid = :P540_VORSCHRIFTID;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(701849990396108810)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2742959975572929466
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(697276305232037095)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'COPY_VERKNUEPFUNGEN'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' l_src_v_typ number :=0;',
'BEGIN',
'   -- debug(''P540_VORSCHRIFT_TYPID='' || :P540_VORSCHRIFT_TYPID, ''P540_NEW_PARENT_VORSCHRITID='' || :P540_NEW_PARENT_VORSCHRITID);',
'    -- kopiere alle nachvolger',
'    insert into T_VORSCHRIFT_REF_VORSCHRIFT(',
'           VORGAENGER_VORSCHRIFTID, NACHFOLGER_VORSCHRIFTID,    BEZIEHUNG_ART,   datum_in_KRAFT,   datum_neue_Typen,    datum_alle_Typen,',
'             HOMOLOGATION_SERIE, MAX_HOMOLOGATION_VORSCHRIFTID)',
'     select :P545_NEW_VORSCHRIFTID, vrv.nachfolger_vorschriftid, vrv.beziehung_art, vrv.datum_in_KRAFT, vrv.datum_neue_Typen, vrv.datum_alle_Typen,',
'             vrv.HOMOLOGATION_SERIE, vrv.MAX_HOMOLOGATION_VORSCHRIFTID',
'       from t_vorschrift_ref_vorschrift vrv',
'      join apex_string.split_numbers(:P541_ALTE_VERKNUEPFUNGEN,'':'') x on (x.column_value = vrv.vorschrift_ref_vorschriftid',
'                                                                         and vrv.vorgaenger_vorschriftid = :P540_SOURCE_VORSCHRIFTID);',
unistr('      -- kopiere alle vorg\00E4nger'),
'      insert into T_VORSCHRIFT_REF_VORSCHRIFT(',
'             VORGAENGER_VORSCHRIFTID,     NACHFOLGER_VORSCHRIFTID,    BEZIEHUNG_ART,   datum_in_KRAFT,   datum_neue_Typen,    datum_alle_Typen,',
'             HOMOLOGATION_SERIE, MAX_HOMOLOGATION_VORSCHRIFTID)',
'     select vrv.vorgaenger_vorschriftid, :P545_NEW_VORSCHRIFTID,  vrv.beziehung_art, vrv.datum_in_KRAFT, vrv.datum_neue_Typen, vrv.datum_alle_Typen,',
'             vrv.HOMOLOGATION_SERIE, vrv.MAX_HOMOLOGATION_VORSCHRIFTID',
'       from t_vorschrift_ref_vorschrift vrv',
'      join apex_string.split_numbers(:P541_ALTE_VERKNUEPFUNGEN,'':'') x on (x.column_value = vrv.vorschrift_ref_vorschriftid',
'                                                                         and vrv.nachfolger_vorschriftid = :P540_SOURCE_VORSCHRIFTID);',
'       -- and vrv.beziehung_art in (10- successor/predecessor, 30- amendment, 40- demands, 50- beendet)',
'    if ( :P540_NEW_PARENT_VORSCHRITID  is not null ) then  -- insert supplements parent',
'          --select vorschrift_typid into l_src_v_typ from T_VORSCHRIFT where VORSCHRIFTID = :P540_SOURCE_VORSCHRIFTID;',
'        if ( :P540_VORSCHRIFT_TYPID = 20 ) then -- supplement',
'            ',
'             insert into T_VORSCHRIFT_REF_VORSCHRIFT(',
'                  VORGAENGER_VORSCHRIFTID,     NACHFOLGER_VORSCHRIFTID,    BEZIEHUNG_ART,   datum_in_KRAFT,   datum_neue_Typen,    datum_alle_Typen,',
'                HOMOLOGATION_SERIE, MAX_HOMOLOGATION_VORSCHRIFTID)',
'             select vrv.vorgaenger_vorschriftid, :P545_NEW_VORSCHRIFTID,  vrv.beziehung_art, vrv.datum_in_KRAFT, vrv.datum_neue_Typen, vrv.datum_alle_Typen,',
'                vrv.HOMOLOGATION_SERIE, vrv.MAX_HOMOLOGATION_VORSCHRIFTID',
'              from t_vorschrift_ref_vorschrift vrv',
'             where vrv.nachfolger_vorschriftid = :P540_SOURCE_VORSCHRIFTID and vrv.beziehung_art = 30;',
'        end if;',
'    end if;',
'',
'    if  :P541_FOLGEVORSCHRIFT = 1 then',
'    insert into t_vorschrift_ref_vorschrift (vorgaenger_vorschriftid, nachfolger_vorschriftid, beziehung_art)',
'                                    values (:P540_SOURCE_VORSCHRIFTID, :P545_NEW_VORSCHRIFTID, 10);',
'    end if;',
'',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(701849990396108810)
,p_internal_uid=>2974936010667351140
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(697276143113037094)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'COPY_MFVS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'',
'INSERT INTO t_MfV_ref_vorschrift (vorschriftid,  LETZTE_AENDERUNG_BENUTZERID, mfvid )',
'   SELECT :P545_NEW_VORSCHRIFTID, pck_ri.fGetUserId, column_value  ',
'            from table(apex_string.split_numbers(:P542_SELECTED_MFVS, '':'')) where column_value is not null;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(701849990396108810)
,p_internal_uid=>2974936172786351141
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(697276058135037093)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'COPY_VERLINKTE_NORMEN'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'',
'    INSERT INTO T_VERLINKTE_NORM (',
'        VORSCHRIFTID,',
'        NUMMER,',
'        BEZEICHNUNG,',
'        LETZTE_AENDERUNG_DATUM,',
'        LETZTE_AENDERUNG_BENUTZERID',
'    ) SELECT',
'        :P540_NEW_VORSCHRIFTID,',
'        NUMMER,',
'        BEZEICHNUNG,',
'        LETZTE_AENDERUNG_DATUM,',
'        LETZTE_AENDERUNG_BENUTZERID',
'    FROM T_VERLINKTE_NORM',
'    WHERE VERLINKTE_NORMID IN (',
'        select column_value ',
'        from table(apex_string.split_numbers(:P543_SELECTED_NORMEN, '':''))',
'    );',
'',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(701849990396108810)
,p_process_when_type=>'NEVER'
,p_internal_uid=>2974936257764351142
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1063833201715809867)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get selected countries'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--debug(''Prozess get selected countries: '',APEX_APPLICATION.G_F03.COUNT);',
':P545_SELECTED_COUNTRIES := null;',
'',
'FOR i IN 1..APEX_APPLICATION.G_F03.COUNT LOOP ',
'   -- debug(''element ''||i||'' has a value of ''||APEX_APPLICATION.G_F03(i)); ',
'    :P545_SELECTED_COUNTRIES := :P545_SELECTED_COUNTRIES || APEX_APPLICATION.G_F03(i) || '':'';',
'END LOOP;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2608379114183578368
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1063832209695809857)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get selected themes'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--debug(''Prozess get selected themes: '',APEX_APPLICATION.G_F04.COUNT);',
':P545_SELECTED_THEMES := null;',
'FOR i IN 1..APEX_APPLICATION.G_F04.COUNT LOOP ',
'    :P545_SELECTED_THEMES := :P545_SELECTED_THEMES || APEX_APPLICATION.G_F04(i) || '':'';',
'END LOOP;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2608380106203578378
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1063833118649809866)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'COPY SELECTED COUNTRIES'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'  INSERT INTO T_VORSCHRIFT_REF_LAND ( VORSCHRIFTID,',
'                                      LANDID,',
'                                   LETZTE_AENDERUNG_BENUTZERID,',
'                                   geloescht, ',
'                                   bemerkung',
'            )   SELECT   :P545_NEW_VORSCHRIFTID,',
'                         x.column_value ,',
'                         PCK_RI.fGetUserId,',
'                         0, ',
'                         :P545_LAND_BEMERKUNG',
'        from table (apex_string.split_numbers(:P545_SELECTED_COUNTRIES, '':'')) x where x.column_value is not null;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(701849990396108810)
,p_internal_uid=>2608379197249578369
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1063832071926809856)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'COPY SELECTED THEMES'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'INSERT INTO T_VORSCHRIFT_REF_THEMA (',
'        VORSCHRIFTID,',
'        THEMAID,',
'        BEMERKUNG,',
'        LETZTE_AENDERUNG_DATUM,',
'        LETZTE_AENDERUNG_BENUTZERID,',
'        geloescht',
'    ) SELECT',
'        :P545_NEW_VORSCHRIFTID,',
'        THEMAID,',
'        :P545_THEMEN_BEMERKUNG,',
'        SYSDATE,',
'        PCK_RI.fGetUserId,',
'        0',
'    FROM T_VORSCHRIFT_REF_THEMA ',
'    WHERE ',
'        vorschriftid = :P540_SOURCE_VORSCHRIFTID',
'        and  THEMAID in (select column_value ',
'                          from table(apex_string.split_numbers(:P545_SELECTED_THEMES, '':''))) ;',
'        ',
'     INSERT INTO T_VORSCHRIFT_REF_THEMA (',
'        VORSCHRIFTID,',
'        THEMAID,',
'        BEMERKUNG,',
'        LETZTE_AENDERUNG_DATUM,',
'        LETZTE_AENDERUNG_BENUTZERID,',
'        geloescht',
'    ) SELECT',
'        :P545_NEW_VORSCHRIFTID,',
'        x.column_value,',
'        :P545_THEMEN_BEMERKUNG,',
'        SYSDATE,',
'        PCK_RI.fGetUserId,',
'        0',
'    from table(apex_string.split_numbers(:P545_QUERSCHNITTS_THEMEN_CB, '':'')) x;',
'  '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(701849990396108810)
,p_internal_uid=>2608380243972578379
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(929253915540458784)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ResetVI'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--debug(''copy_f: VId='' || :P545_NEW_VORSCHRIFTID);',
'PCK_RI.pResetVI(:P545_NEW_VORSCHRIFTID);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(701849990396108810)
,p_internal_uid=>2742958400358929451
);
wwv_flow_imp.component_end;
end;
/
