prompt --application/pages/page_00100
begin
--   Manifest
--     PAGE: 00100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>100
,p_name=>'Vorschriften Themen Zuordnung bearbeiten'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Vorschriften: L\00E4nder und Themen Zuordnung bearbeiten')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function loadLaenderShuttle() {',
'    var shuttleName = ''P100_LAENDER'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadLaenderShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P100_LAENDER_GRUPPE'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'function loadThemenShuttle() {',
'    var shuttleName = ''P100_THEMENIDS'';',
'    var lLeft = $x(shuttleName + ''_LEFT'');',
'    var lRight = $x(shuttleName + ''_RIGHT'');',
'    var lSelected = $.map(lRight.options, function(n,i) {',
'        return n.value;',
'    });',
'    apex.server.process(',
'        ''loadThemenShuttle'',                           ',
'        { x01: lSelected.join('':''),',
'          x02: $v(''P100_PRE_THEMENIDS'')',
'        }, ',
'        {',
'            success: function (pData)',
'            {     ',
'                lLeft.length = 0;',
'                for ( var i=0; i<pData.length; i++ ) {',
'                    lLeft.options[i] = new Option(pData[i].d,pData[i].r);',
'                }',
'',
'            },',
'            dataType: "json"                     ',
'        }',
'    );     ',
'}',
'',
'function addItemToShuttle(aShuttle, aID, aDisplay) {',
'    var lLeft = $(''#'' + aShuttle + ''_LEFT'');',
'    var lRight = $(''#'' + aShuttle + ''_RIGHT'');',
'    lLeft.find(''option[value='' + aID + '']'').remove();',
'    lRight.append(''<option value="'' + aID + ''">'' + aDisplay + ''</option>'');',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Text-Item muss da sein, da sonst Submit bei Enter im Vorfilter-Feld',
'$(''#P100_TEXTFIELD'').closest(''div.row'').hide();'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_dialog_width=>'1200'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2643048377405798437)
,p_plug_name=>'THEMEN_LAENDER_ITEMS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2643049420461798447)
,p_plug_name=>'Button_Footer'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2643049532332798448)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2643049420461798447)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2643049582055798449)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2643049420461798447)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P100_OPEN_TO_DELETE'
,p_button_condition_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2644930117098399850)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2643049420461798447)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P100_OPEN_TO_DELETE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(2651730518985234843)
,p_branch_name=>'parent_page_submit'
,p_branch_action=>'javascript:parent.apex.submit()'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'REQUEST_IN_CONDITION'
,p_branch_condition=>'SAVE,DELETE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(845146520931051452)
,p_name=>'P100_THEMEN_CHILDREN_TO_ADD'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(2643048377405798437)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(581724092617659982)
,p_name=>'P100_OLD_THEMENIDS'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(2643048377405798437)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2643048527782798438)
,p_name=>'P100_VORSCHRIFTID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2643048377405798437)
,p_prompt=>'Vorschrift'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select Vorschrift_nummer ||'' - ''||VORSCHRIFT_BEZEICHNUNG, vorschriftid',
'from T_vorschrift'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when=>':P100_COME_FROM = 25 or :P100_LAND_READ_ONLY = 0 or :P100_OPEN_TO_DELETE is not null'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2643048661902798439)
,p_name=>'P100_THEMAID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2643048377405798437)
,p_prompt=>'Thema'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_THEMA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    NUMMER || '' - '' || ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN BEZEICHNUNG',
'        ELSE name_eng',
'    END as d,',
'    THEMAID as r',
'FROM V_THEMA_BAUM vtb',
'-- It excludes topics linked to et_b_akid = 1036 in t_thema_ref_et_b_ak, ensuring results are relevant to users without access to these excluded topics.',
'-- WHERE vtb.themaid not in (select themaid from t_thema_ref_et_b_ak where et_b_akid =1036 )',
'ORDER BY vtb.thema_sortorder;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P100_NEW_CREATE = 1 and :P100_THEMEN_UND_LAENDER is null and :P100_LAND_READ_ONLY = 1)',
'or',
' (:P100_THEMAID is not null',
'  and (:P100_NEW_CREATE is null or :P100_NEW_CREATE= 0)',
'    )'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P100_COME_FROM = 35 or :P100_LAND_READ_ONLY = 0',
'or (:P100_COME_FROM = 25 and (:P100_NEW_CREATE is null or :P100_NEW_CREATE = 0))',
'or :P100_OPEN_TO_DELETE is not null',
''))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2643048747315798440)
,p_name=>'P100_COME_FROM'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2643048377405798437)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2643049054890798443)
,p_name=>'P100_BEMERKUNG'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2643048377405798437)
,p_prompt=>'Bemerkung'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>3
,p_read_only_when=>'P100_OPEN_TO_DELETE'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2643049070712798444)
,p_name=>'P100_LAENDER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(2643048377405798437)
,p_prompt=>unistr('L\00E4nder')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select b_nummer || '' - '' || land,landid ',
'from t_land',
'/*where  (landid in (Select Landid from ',
'                     t_land_ref_laendergruppe where laendergruppeid = :P100_LAENDER_GRUPPE',
'                  )',
'        --or :P100_LAENDER_GRUPPE is null',
'       )*/',
'',
'order by NLSSORT(B_Nummer, ''NLS_SORT=BINARY_AI'')',
'        ',
''))
,p_cHeight=>5
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(((:P100_LAND_READ_ONLY = 0 or :P100_LAND_READ_ONLY is null) or (:P100_LAND_READ_ONLY = 1 and :P100_LAENDER is not null) )',
'',
'and',
':P100_THEMAID IS not null and :P100_LANDID is NULL ',
'',
'',
'and (:P100_NEW_CREATE = 0 or :P100_NEW_CREATE is null)',
')',
'or',
'(:P100_NEW_CREATE = 1 and :P100_THEMEN_UND_LAENDER = 1)'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_read_only_when=>'P100_LAND_READ_ONLY'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2643049202806798445)
,p_name=>'P100_LAENDER_GRUPPE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(2643048377405798437)
,p_prompt=>unistr('L\00E4nder Gruppe')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select LAENDERGRUPPE, LAENDERGRUPPEID',
'from T_laendergruppe'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(((:P100_LAND_READ_ONLY = 0 or :P100_LAND_READ_ONLY is null) ',
'and (:P100_LANDID is NULL and (:P100_NEW_CREATE = 0 or :P100_NEW_CREATE is null) ) )',
'and :P100_OPEN_TO_DELETE is null',
') or (:P100_NEW_CREATE = 1 and :P100_THEMEN_UND_LAENDER = 1)'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_read_only_when=>'P100_LAND_READ_ONLY'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2643049277573798446)
,p_name=>'P100_LAND_READ_ONLY'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2643048377405798437)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2651730102964234839)
,p_name=>'P100_THEMENIDS'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(2643048377405798437)
,p_prompt=>'Themen'
,p_display_as=>'NATIVE_SHUTTLE'
,p_named_lov=>'LOV_THEMA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    NUMMER || '' - '' || ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN BEZEICHNUNG',
'        ELSE name_eng',
'    END as d,',
'    THEMAID as r',
'FROM V_THEMA_BAUM vtb',
'-- It excludes topics linked to et_b_akid = 1036 in t_thema_ref_et_b_ak, ensuring results are relevant to users without access to these excluded topics.',
'-- WHERE vtb.themaid not in (select themaid from t_thema_ref_et_b_ak where et_b_akid =1036 )',
'ORDER BY vtb.thema_sortorder;'))
,p_cHeight=>5
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P100_THEMAID is null and (:P100_NEW_CREATE is null or :P100_NEW_CREATE= 0)',
')',
'or',
'(:P100_NEW_CREATE = 1 and :P100_THEMEN_UND_LAENDER = 1)'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_read_only_when=>'P100_THEMA_READ_ONLY'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2651730227912234840)
,p_name=>'P100_LANDID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2643048377405798437)
,p_prompt=>'Land'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select land ||'' (''|| B_Nummer ||'')'',landid ',
'from t_land order by land'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P100_THEMAID is null and (:P100_NEW_CREATE is null or :P100_NEW_CREATE = 0 or :P100_OPEN_TO_DELETE is not null)) ',
'or ',
'(:P100_COME_FROM = 25 and :P100_NEW_CREATE = 1 and (:P100_LAND_READ_ONLY = 0)',
' )',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'NOT(:P100_COME_FROM = 25 and :P100_NEW_CREATE = 1 and (:P100_LAND_READ_ONLY = 0) )',
'or :P100_OPEN_TO_DELETE is not null'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2651730334349234841)
,p_name=>'P100_NEW_CREATE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(2643048377405798437)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2653320251694129839)
,p_name=>'P100_THEMA_READ_ONLY'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(2643048377405798437)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2655334732317608637)
,p_name=>'P100_THEMEN_UND_LAENDER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(2643048377405798437)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2655334894178608639)
,p_name=>'P100_OPEN_TO_DELETE'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(2643048377405798437)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2656451204586465543)
,p_name=>'P100_TEXTFIELD'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(2643048377405798437)
,p_prompt=>'Textfield'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2656457403922499192)
,p_name=>'P100_PRE_THEMENIDS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(2643048377405798437)
,p_prompt=>'Vorfilter Themen'
,p_post_element_text=>'<button type="button" class="a-Button" style="height: 48px; padding: 8px; border-radius: 0 2px 2px 0;" onclick="loadThemenShuttle()"><span class="fa fa-search"></span></button>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'((:P100_THEMAID is null and (:P100_NEW_CREATE is null or :P100_NEW_CREATE= 0)',
')',
'or',
'(:P100_NEW_CREATE = 1 and :P100_THEMEN_UND_LAENDER = 1)',
') and :p100_thema_read_only != 1'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1461631278857422531)
,p_validation_name=>'Land_Validation'
,p_validation_sequence=>10
,p_validation=>'P100_LAENDER'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Bitte w\00E4hlen Sie ein Land aus')
,p_validation_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(((:P100_LAND_READ_ONLY = 0 or :P100_LAND_READ_ONLY is null) or (:P100_LAND_READ_ONLY = 1 and :P100_LAENDER is not null) )',
'',
'and',
':P100_THEMAID IS not null and :P100_LANDID is NULL ',
'',
'',
'and (:P100_NEW_CREATE = 0 or :P100_NEW_CREATE is null)',
')',
'or',
'(:P100_NEW_CREATE = 1 and :P100_THEMEN_UND_LAENDER = 1)'))
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(2643049582055798449)
,p_associated_item=>wwv_flow_imp.id(2643049070712798444)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1461631336310422532)
,p_validation_name=>'THEMA_VALIDATION'
,p_validation_sequence=>20
,p_validation=>'P100_THEMENIDS'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Bitte w\00E4hlen Sie ein Thema aus')
,p_validation_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P100_THEMAID is null and (:P100_NEW_CREATE is null or :P100_NEW_CREATE= 0)',
')',
'or',
'(:P100_NEW_CREATE = 1 and :P100_THEMEN_UND_LAENDER = 1)'))
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(2643049582055798449)
,p_associated_item=>wwv_flow_imp.id(2651730102964234839)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1461631472670422533)
,p_validation_name=>'Validation_land_einzeln'
,p_validation_sequence=>30
,p_validation=>'P100_LANDID'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Bitte w\00E4hlen Sie ein Land aus.')
,p_validation_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P100_THEMAID is null and (:P100_NEW_CREATE is null or :P100_NEW_CREATE = 0 or :P100_OPEN_TO_DELETE is not null)) ',
'or ',
'(:P100_COME_FROM = 25 and :P100_NEW_CREATE = 1 and (:P100_LAND_READ_ONLY = 0)',
' )'))
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(2643049582055798449)
,p_associated_item=>wwv_flow_imp.id(2651730227912234840)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1461631528190422534)
,p_validation_name=>'Validation_thema_einzeln'
,p_validation_sequence=>40
,p_validation=>'P100_THEMAID'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Bitte w\00E4hlen Sie ein Thema aus.')
,p_validation_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:P100_NEW_CREATE = 1 and :P100_THEMEN_UND_LAENDER is null and :P100_LAND_READ_ONLY = 1)',
'or',
' (:P100_THEMAID is not null',
'  and (:P100_NEW_CREATE is null or :P100_NEW_CREATE= 0)',
'    )'))
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(2643049582055798449)
,p_associated_item=>wwv_flow_imp.id(2643048661902798439)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2643049728686798450)
,p_name=>'Cancel'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2643049532332798448)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2643049793714798451)
,p_event_id=>wwv_flow_imp.id(2643049728686798450)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2656450680505465538)
,p_name=>unistr('change L\00E4ndergruppe')
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_LAENDER_GRUPPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2656450853941465539)
,p_event_id=>wwv_flow_imp.id(2656450680505465538)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2656450974231465541)
,p_name=>'enter im suchfeld'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_PRE_THEMENIDS'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which == 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2656451071529465542)
,p_event_id=>wwv_flow_imp.id(2656450974231465541)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'loadThemenShuttle();',
'return false;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(845146242426048684)
,p_name=>'add childThemen'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_THEMENIDS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(845145436032048683)
,p_event_id=>wwv_flow_imp.id(845146242426048684)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lThemenliste apex_t_number := apex_string.split_numbers(:P100_THEMENIDS,'':'');',
'begin    ',
'',
'    apex_json.initialize_clob_output;',
'    apex_json.open_array;    ',
'',
unistr('    -- Jedes bereits ausgew\00E4hlte Thema durchgehen und dessen Kinder selektieren'),
'    for i in 1 .. lThemenliste.count loop',
'        for childthemen in (',
'            select themaid, nummer || '' - '' || bezeichnung as d',
'            from t_thema',
'            connect by parentid = prior themaid',
'            start with parentid = lThemenliste(i)',
'        ) loop',
'            -- Wenn das entsprechende Kind noch nicht im Shuttle ist, dann ',
unistr('            -- zu einer Hinzuf\00FCgungs-Liste addieren'),
'            if (childthemen.themaid not member of lThemenliste) then',
'                apex_json.open_object;',
'                apex_json.write(''id'',childthemen.themaid);',
'                apex_json.write(''display'',childthemen.d);',
'                apex_json.close_object;',
'            end if;',
'        end loop;',
'    ',
'    end loop;',
unistr('    -- Hinzuf\00FCgungs-Liste ist hidden item'),
unistr('    -- Direktes Hinzuf\00FCgen w\00FCrde zu einem Refresh der Scrollbalken des Items f\00FChren'),
'    apex_json.close_array;',
'    :P100_THEMEN_CHILDREN_TO_ADD := apex_json.get_clob_output;',
'    apex_json.free_output;',
'end;    '))
,p_attribute_02=>'P100_THEMENIDS'
,p_attribute_03=>'P100_THEMEN_CHILDREN_TO_ADD'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(845145862381048684)
,p_event_id=>wwv_flow_imp.id(845146242426048684)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var items = JSON.parse($v(''P100_THEMEN_CHILDREN_TO_ADD''));',
'',
unistr('// alle Items im Shuttle hinzuf\00FCgen'),
'for (item of items) {',
'    if (item) addItemToShuttle(''P100_THEMENIDS'',item.id,item.display);',
'} ',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2643048952105798442)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*debug(''Seite 100'',''Aufruf Save'');',
'debug(''Seite 100 :P100_COME_FROM '',:P100_COME_FROM );',
'debug(''Seite 100 :P100_VORSCHRIFT '',:P100_VORSCHRIFTID );',
'debug(''Seite 100 :P100_THEMA '',:P100_THEMAID );',
'debug(''Seite 100 :P100_Land '',:P100_LANDID );',
'debug(''Seite 100 :P100_LAENDER '',:P100_LAENDER );',
'*/',
'',
'-- Afruf mit allem Bearbeiten',
'if (:P100_COME_FROM = 25 and :P100_THEMEN_UND_LAENDER = 1 )',
'then',
'-- debug(''Seite 100'',''Aufruf Massenbearbeitung'');',
'',
'  pck_ri_history.pInsertVorschriftAlleRelation(:P100_VORSCHRIFTID, :P100_THEMENIDS, :P100_LAENDER,:P100_BEMERKUNG);',
'  PCK_RI_BENACHRICHTIGUNG.pBenachricht_Mfv_Arbeitskreise( :P100_VORSCHRIFTID, ''Themen'', :G_BENUTZERID );',
'  PCK_RI_BENACHRICHTIGUNG.pBenachricht_Mfv_Arbeitskreise( :P100_VORSCHRIFTID, ''Laender'', :G_BENUTZERID );',
unistr('--Vorschriftenseite nur L\00E4nder bearbeiten'),
'elsif (:P100_COME_FROM = 25  and (:P100_LAND_READ_ONLY =0 or :P100_LAND_READ_ONLY is null)',
'       and :P100_THEMEN_UND_LAENDER is null and :P100_NEW_CREATE is null )',
' then ',
'        pck_ri_history.pInsertVorschriftThemaRelation(:P100_VORSCHRIFTID,:P100_THEMAID,:P100_LAENDER,:P100_BEMERKUNG);',
unistr('       --  debug(''Seite 100'',''Aufruf L\00E4nder++ bearbeiten'');'),
'        PCK_RI_BENACHRICHTIGUNG.pBenachricht_Mfv_Arbeitskreise( :P100_VORSCHRIFTID, ''Laender'', :G_BENUTZERID );',
'',
'elsif (:P100_COME_FROM = 25 and :P100_NEW_CREATE = 1 and (:P100_LAND_READ_ONLY = 0) and :P100_LANDID is not null',
'       and :P100_THEMEN_UND_LAENDER is null)',
' then',
unistr('-- Neues Land hinzuf\00FCgen'),
'-- debug(''Seite 100'',''Aufruf Neues Land'');',
'      pck_ri_history.pInsertVorschriftLandRelationkeinThema(:P100_VORSCHRIFTID,:P100_LANDID,:P100_BEMERKUNG); ',
'    PCK_RI_BENACHRICHTIGUNG.pBenachricht_Mfv_Arbeitskreise( :P100_VORSCHRIFTID, ''Laender'', :G_BENUTZERID );',
'elsif (:P100_COME_FROM = 25 and :P100_NEW_CREATE = 1 and (:P100_LAND_READ_ONLY = 1) and :P100_THEMAID is not null',
'       and :P100_THEMEN_UND_LAENDER is null)',
' then',
unistr('-- Neues Thema hinzuf\00FCgen'),
'-- debug(''Seite 100'',''Aufruf Neues Thema'');',
'      pck_ri_history.pInsertVorschriftThemaRelationkeinLand(:P100_VORSCHRIFTID,:P100_THEMAID,:P100_BEMERKUNG); ',
'      PCK_RI_BENACHRICHTIGUNG.pBenachricht_Mfv_Arbeitskreise( :P100_VORSCHRIFTID, ''Themen'', :G_BENUTZERID );',
'',
'elsif (:P100_THEMAID is null and (:P100_NEW_CREATE is null or :P100_NEW_CREATE= 0) and :P100_LANDID is not null)',
' then',
'-- Mehrere Themen Speichern',
' pck_ri_history.pInsertVorschriftLandRelation(:P100_VORSCHRIFTID,:P100_THEMENIDS,:P100_LANDID,:P100_BEMERKUNG);',
'-- debug(''Seite 100'',''Aufruf Themen++ bearbeiten'');',
'  PCK_RI_BENACHRICHTIGUNG.pBenachricht_Mfv_Arbeitskreise( :P100_VORSCHRIFTID, ''Themen'', :G_BENUTZERID );',
'end if;',
'',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2643049582055798449)
,p_internal_uid=>6315261268005186677
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(581724899227659990)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Benachricht_Fremdzuweis_Thema'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   -- lThemenIdliste apex_t_number; -- := apex_string.split_numbers(:P100_THEMENIDS,'':'');',
'    sDiffListe varchar2(800);',
'begin',
'',
'    if (',
'        :P100_COME_FROM = 25 -- Vorschriften-Detailseite',
'        and ',
'        ( ',
'            (:P100_THEMEN_UND_LAENDER = 1 OR :P100_LAND_READ_ONLY = 1)  ',
'            or',
'            :P100_THEMAID is null and (:P100_NEW_CREATE is null or :P100_NEW_CREATE = 0)',
'        )',
'     ) then',
'      select listagg(themaid,'':'') within group (order by themaid)  into sDiffListe from',
'        (select column_value as themaid from table( APEX_STRING.split_numbers(:P100_THEMENIDS, '':''))',
'          MINUS                                                     -- :P100_OLD_THEMENIDS',
'          select column_value as themaid from table( APEX_STRING.split_numbers(:P100_OLD_THEMENIDS, '':''))',
'         )',
'      where themaid is not null;',
'      if length(sDiffListe) >1 then',
'         --debug(''sDiffListe= '', sDiffListe);',
'',
'         -- lThemenIdliste := apex_string.split_numbers(sDiffListe,'':'');',
'          PCK_RI_BENACHRICHTIGUNG.pBenachrichtigung_fremdzuweisung2(:P100_VORSCHRIFTID, sDiffListe, :G_BENUTZERID);',
'      end if;',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2643049582055798449)
,p_internal_uid=>3090487416671728245
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2651730395121234842)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DELETE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*debug(''Seite 100'',''Aufruf DELETE'');',
'debug(''Seite 100 :P100_COME_FROM '',:P100_COME_FROM );',
'debug(''Seite 100 :P100_VORSCHRIFT '',:P100_VORSCHRIFTID );',
'debug(''Seite 100 :P100_THEMA '',:P100_THEMAID );',
'debug(''Seite 100 :P100_LAND '',:P100_LANDID );*/',
'',
'',
unistr('--L\00F6schen vom Thema'),
'if (:P100_COME_FROM = 25  and :P100_LAND_READ_ONLY =1)',
'        then ',
unistr('-- debug(''Seite 100 Delete '',''Thema l\00F6schen'' );     '),
'        pck_ri_history.pInsertVorschriftThemaRelationkeinLand(:P100_VORSCHRIFTID,:P100_THEMAID,:P100_BEMERKUNG,1);',
unistr('--L\00F6schen vom Land'),
'elsif (:P100_COME_FROM = 25  and (:P100_LAND_READ_ONLY =0 or :P100_LAND_READ_ONLY is null))',
'        then ',
unistr('    --     debug(''Seite 100 Delete '',''Land l\00F6schen'' );     '),
'        pck_ri_history.pInsertVorschriftLandRelationkeinThema(:P100_VORSCHRIFTID,:P100_LANDID,:P100_BEMERKUNG,1);',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2644930117098399850)
,p_internal_uid=>6323942711020623077
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(806712219663495190)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Letzte Aenderung Datum setzen, Reset VI'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_vorschrift',
'set letzte_aenderung_datum = sysdate',
'where vorschriftid = :P100_VORSCHRIFTID;',
'-- UserID wird durch Trigger automatisch gesetzt',
'',
'pck_ri.pResetVI(:P100_VORSCHRIFTID);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2865500096235893045
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1455203230930506542)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'refresh cockpit'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pck_ri_cockpit_refresh.pTriggerRefresh;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>5127415546829894777
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(654956078558504602)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Nachricht_Option'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- wenn AK 18, keine nachricht vorhanden ',
'/*',
'declare',
'    ak_zuordn number :=0;',
'    offene_benachr number :=0;',
'    need_autonachricht number :=0;',
'begin',
'    if (',
'        :P100_COME_FROM = 25 and (',
'            :P100_LAND_READ_ONLY =0 or :P100_LAND_READ_ONLY is null',
'        ) and :P100_THEMEN_UND_LAENDER is null and :P100_NEW_CREATE is null',
'    ) then',
'           ',
'        --- ist Vorschr. zu AK zugeordnet',
'        select count(*)',
'        into ak_zuordn',
'        from T_VORSCHRIFT_REF_ET_B_AK vr ',
'        where vr.VORSCHRIFTID = to_number(:P100_VORSCHRIFTID) and vr.et_b_akid = 1000;',
'        ',
'        if (ak_zuordn < 1) then',
'            null; -- nicht zu AK E18 zugeordnet',
'        else  ',
'            select count(*) into offene_benachr from t_Benachrichtigung',
'            where status in (10 ) and Arbeitskreisid =1000 and grund =10 and vorschriftid = :P100_VORSCHRIFTID;',
'',
'            if ( offene_benachr <1  ) then',
unistr('                -- sind die  (zu zuordnete l\00E4nder) in der gruppe mit  autonachricht=1'),
'                select  count(*)',
'                into need_autonachricht ',
'                from T_Land_REF_Laendergruppe llg     ',
'                join T_Laendergruppe lg on (lg.laendergruppeid = llg.laendergruppeid)',
'                where lg.autonachricht=1 AND llg.landid in (',
'                    select t.column_value ',
'                    from table (apex_string.split(:P100_LAENDER, '':'')) t where t.column_value IS NOT NULL',
'                ); ',
'                ',
'                if (need_autonachricht > 0) then ',
'                    pck_ri_benachrichtigung.pbenachrichtigung(',
'                        :P100_VORSCHRIFTID, ''1000'', ',
unistr('                       ''Bitte pr\00FCfe bei dieser neuen/ge\00E4nderten Vorschrift id='' || :P100_VORSCHRIFTID || '' die SW-Relevanz'', aGrund => 10, aLoeschmarker =>0'),
'                    );',
'                end if;',
'            end if;',
'         end if;',
'    ',
'    else if (',
'        :P100_COME_FROM = 25 and (',
'            :P100_LAND_READ_ONLY = 0 or :P100_LAND_READ_ONLY is null',
'        ) and :P100_NEW_CREATE =1 )',
'    then',
'        select count(*)',
'        into ak_zuordn',
'        from T_VORSCHRIFT_REF_ET_B_AK vr ',
'        where vr.VORSCHRIFTID = to_number(:P100_VORSCHRIFTID) and vr.et_b_akid = 1000;',
'        ',
'        if (ak_zuordn < 1) then',
'            null; -- nicht zu AK E18 zugeordnet',
'        else  ',
'            select count(*)',
'            into offene_benachr',
'            from t_Benachrichtigung',
'            where status in (10 ) and Arbeitskreisid =1000 and grund =10 and vorschriftid = :P100_VORSCHRIFTID;',
'',
'            if ( offene_benachr <1 ) then',
'                --DBMS_OUTPUT.PUT_LINE('' keine offene Benachricht mit grund=10'');',
unistr('                -- sind die  (zu zuordnete l\00E4nder) in der gruppe mit  autonachricht=1'),
'                ',
'                select  count(*)',
'                into need_autonachricht ',
'                from T_Land_REF_Laendergruppe llg     ',
'                join T_Laendergruppe lg on (lg.laendergruppeid = llg.laendergruppeid)',
'                where lg.autonachricht=1 AND llg.landid in (:P100_LANDID); ',
'                ',
'                if (need_autonachricht > 0) then ',
'                    -- to AK E18 (id=1000)',
'                    pck_ri_benachrichtigung.pbenachrichtigung(',
'                        :P100_VORSCHRIFTID, ''1000'', ',
unistr('                       ''Bitte pr\00FCfe bei dieser neuen/ge\00E4nderten Vorschrift id='' || :P100_VORSCHRIFTID || '' die SW-Relevanz'', aGrund => 10, aLoeschmarker =>0'),
'                   );',
'                end if;',
'           end if;',
'        end if;',
'      end if; ',
'   end if;',
'end;',
'*/',
'PCK_RI_BENACHRICHTIGUNG.pBenachrichtigungSWRelevanz(:P100_VORSCHRIFTID);',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>3017256237340883633
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2644928874223399838)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(2643049582055798449)
,p_internal_uid=>6317141190122788073
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2651729891530234837)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load_Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'lcountLand number;',
'LcountThemen number;',
'begin',
'',
'if (:P100_THEMAID is not null)',
'                then ',
'                Select count(Landid) into lcountLand',
'                from t_vorschrift_ref_thema_ref_land',
'                where vorschriftid = :P100_VORSCHRIFTID and themaid = :P100_THEMAID and geloescht = 0;',
'                with cte1 as(Select distinct bemerkung',
'                             from t_vorschrift_ref_thema_ref_land',
'                             where vorschriftid = :P100_VORSCHRIFTID and nvl(themaid,-1) = nvl(:P100_THEMAID,-1) and geloescht = 0',
'                             )',
'                select listagg(bemerkung, '', ''on overflow truncate) into :P100_BEMERKUNG',
'                from cte1;',
'                if (lcountLand > 0)',
'                then ',
'                select listagg(landid, '':'') into :P100_LAENDER',
'                from t_vorschrift_ref_thema_ref_land',
'                where vorschriftid = :P100_VORSCHRIFTID and themaid = :P100_THEMAID and geloescht = 0;',
'                ',
'                end if;',
'                ',
'elsif (:P100_LANDID is not null)',
'                then ',
'                Select count(Themaid) into LcountThemen',
'                from t_vorschrift_ref_thema_ref_land',
'                where vorschriftid = :P100_VORSCHRIFTID and landid = :P100_LANDID and geloescht = 0;',
'                 with cte1 as(Select distinct bemerkung',
'                             from t_vorschrift_ref_thema_ref_land',
'                             where vorschriftid = :P100_VORSCHRIFTID and nvl(landid,-1) = nvl(:P100_LANDID,-1) and geloescht = 0',
'                             )',
'                select listagg(bemerkung, '', ''on overflow truncate) into :P100_BEMERKUNG',
'                from cte1;',
'                if (lcountThemen> 0)',
'                then ',
'                select listagg(Themaid, '':'') into :P100_THEMENIDS',
'                from t_vorschrift_ref_thema_ref_land',
'                where vorschriftid = :P100_VORSCHRIFTID and landid = :P100_LANDID and geloescht = 0;',
'               ',
'                end if;',
'elsif (:P100_THEMEN_UND_LAENDER = 1 and :P100_NEW_CREATE = 1)',
'                then',
'                Select count( distinct Themaid) into LcountThemen',
'                from t_vorschrift_ref_thema_ref_land',
'                where vorschriftid = :P100_VORSCHRIFTID and geloescht = 0;',
'                ',
'                :P100_OLD_THEMENIDS :='''';',
'                if (lcountThemen> 0)',
'                then ',
'                select listagg(Themaid, '':'') into :P100_THEMENIDS',
'                from (Select distinct themaid ',
'                      from t_vorschrift_ref_thema_ref_land',
'                      where vorschriftid = :P100_VORSCHRIFTID  and geloescht = 0',
'                     );',
'                end if;',
'                select :P100_THEMENIDS into :P100_OLD_THEMENIDS from dual;',
'               -- debug('':P100_OLD_THEMENIDS:'', :P100_OLD_THEMENIDS);',
'                ',
'                 Select count(Landid) into lcountLand',
'                 from t_vorschrift_ref_thema_ref_land',
'                 where vorschriftid = :P100_VORSCHRIFTID and geloescht = 0;',
'',
'                if (lcountLand > 0)',
'                then ',
'                select listagg(landid, '':'') into :P100_LAENDER',
'                from (Select distinct landid ',
'                      from t_vorschrift_ref_thema_ref_land',
'                      where vorschriftid = :P100_VORSCHRIFTID  and geloescht = 0',
'                     );',
'',
'                end if;',
'                ',
'',
'end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>6323942207429623072
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2656450593720465537)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLaenderShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lLaendergruppe number := apex_application.g_x02;',
'BEGIN',
'    ',
'    apex_json.open_array;',
'    for l in (',
'        select b_nummer || '' - '' || ',
'        ',
'        CASE ',
'            WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'            ELSE land_eng',
'        END as d, ',
'        ',
'        landid',
'',
'        from t_land',
'        where landid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))        ',
'        and (',
'            lLaendergruppe is null',
'            or landid in (select landid from t_land_ref_laendergruppe where laendergruppeid = lLaendergruppe)',
'        )',
'        order by nlssort(b_nummer,''NLS_SORT=BINARY_AI'')        ',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.landid);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'    ',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>6328662909619853772
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2656450892083465540)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadThemenShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected varchar2(2000) := apex_application.g_x01;',
'    lText varchar2(2000) := apex_application.g_x02;',
'BEGIN',
'    ',
'    ',
'    apex_json.open_array;',
'    for l in (',
'        select nummer || '' - '' || bezeichnung as d, themaid as r',
'        from v_thema_baum',
'        where upper(nummer || '' - '' || bezeichnung) like ''%'' || upper(lText) || ''%''',
'        and themaid not in (select column_value from table(apex_string.split_numbers(lSelected,'':'')))            ',
'        order by thema_sortorder',
'        ',
'    ) loop',
'        apex_json.open_object;',
'        apex_json.write(''d'',l.d);',
'        apex_json.write(''r'',l.r);',
'        apex_json.close_object;',
'    end loop;',
'    apex_json.close_array;',
'    ',
'    ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6328663207982853775
);
wwv_flow_imp.component_end;
end;
/
