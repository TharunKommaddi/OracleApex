prompt --application/pages/page_00595
begin
--   Manifest
--     PAGE: 00595
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>595
,p_name=>'Konzern Jira Ticket'
,p_alias=>'KONZERN-JIRA-TICK-DLG'
,p_page_mode=>'MODAL'
,p_step_title=>'Konzern Jira Ticket'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>unistr('var htmldb_delete_message=''M\00F6chten Sie dieses Ticket l\00F6schen?'';')
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(375328908950175255)
,p_plug_name=>'Zugeordnete Arbeitskreise'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(374252998777172204)
,p_plug_name=>'Konzern Jira Tick Dlg'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_KONZERN_JIRA_TICKET'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(374250464152172173)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(374250124855172173)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(374250464152172173)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(374248520864172165)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(374250464152172173)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P595_KONZERN_JIRA_TICKETID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(374248082298172165)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(374250464152172173)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P595_KONZERN_JIRA_TICKETID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(374247698278172165)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(374250464152172173)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Erstellen'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P595_KONZERN_JIRA_TICKETID'
,p_button_condition_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(375329273258175259)
,p_name=>'P595_ARBEITSKREISE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(375328908950175255)
,p_prompt=>'Zugeordnete Arbeitskreise'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(ak.et_b_akid, '':'') within group (order by ak.et_b_akid) ',
'  from t_et_b_ak ak',
'  join t_konzern_jira_ticket_ref_et_b_ak kjrak on (ak.et_b_akid = kjrak.et_b_akid)',
'where kjrak.konzern_jira_ticketid = :P595_KONZERN_JIRA_TICKETID;'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_ARBEITSKREIS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' SELECT ',
'    ET_B_AKID, ',
'    kurz, ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN Bezeichnung',
'        ELSE name_eng',
'    END AS name',
'FROM T_ET_B_AK ',
'WHERE ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN Bezeichnung',
'        ELSE name_eng',
'    END NOT IN ',
'    (',
'        CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''Administratoren'' ELSE ''Administrators'' END,',
'        CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''Redaktionsteam'' ELSE ''Editorial Team'' END',
'    );',
''))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(375329007594175256)
,p_name=>'P595_VORSCHRIFTEN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(374252998777172204)
,p_prompt=>'Vorschriften'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(v.vorschriftid, '':'') within group (order by v.vorschriftid) ',
'  from t_vorschrift v',
'  join t_konzern_jira_ticket_ref_vorschrift kjrv on (kjrv.vorschriftid = v.vorschriftid)',
'where kjrv.konzern_jira_ticketid = :P595_KONZERN_JIRA_TICKETID;'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_VORSCHRIFT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select VORSCHRIFT_NUMMER || '' - '' || VORSCHRIFT_BEZEICHNUNG d,',
'       VORSCHRIFTID as r',
'  from T_VORSCHRIFT',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(374252614811172202)
,p_name=>'P595_KONZERN_JIRA_TICKETID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(374252998777172204)
,p_item_source_plug_id=>wwv_flow_imp.id(374252998777172204)
,p_source=>'KONZERN_JIRA_TICKETID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(374252149850172185)
,p_name=>'P595_LINK'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(374252998777172204)
,p_item_source_plug_id=>wwv_flow_imp.id(374252998777172204)
,p_prompt=>'Link'
,p_source=>'LINK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>1000
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(374251749460172175)
,p_name=>'P595_TICKETNR'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(374252998777172204)
,p_item_source_plug_id=>wwv_flow_imp.id(374252998777172204)
,p_prompt=>'Ticketnr'
,p_source=>'TICKETNR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>1000
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(373086210640579448)
,p_name=>'P595_KONZERN_CLUSTER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(374252998777172204)
,p_prompt=>'Konzern-Cluster'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(konzern_clusterid, '':'') within group (order by konzern_clusterid) ',
'from t_kONZERN_JIRA_TICKET_ref_konzern_cluster kjkc',
'join t_kONZERN_JIRA_TICKET kjt on (kjt.kONZERN_JIRA_TICKETID = kjkc.kONZERN_JIRA_TICKETID )',
'where kjt.kONZERN_JIRA_TICKETID = :P595_KONZERN_JIRA_TICKETID;'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct bezeichnung d, konzern_clusterid s',
'from t_konzern_cluster',
'order by d'))
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(375329615804175262)
,p_validation_name=>'Check TicketNr'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
' not exists (select 1 from t_konzern_jira_ticket ',
'where ticketnr = :P595_TICKETNR)'))
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Eingegebene Ticketnummer existiert bereits!'
,p_always_execute=>'Y'
,p_validation_condition=>'CREATE'
,p_validation_condition_type=>'REQUEST_IN_CONDITION'
,p_associated_item=>wwv_flow_imp.id(374251749460172175)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(374249938598172173)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(374250124855172173)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(374249230862172168)
,p_event_id=>wwv_flow_imp.id(374249938598172173)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(375329732889175263)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'save Ticket'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  --debug(''page 595: REQUEST ='', '' in save process'' );',
'  if (:P595_KONZERN_JIRA_TICKETID is null) then',
'    insert into t_konzern_jira_ticket (ticketnr, link)',
'             values (:P595_TICKETNR, :P595_LINK) ',
'    returning konzern_jira_ticketid into :P595_KONZERN_JIRA_TICKETID;',
'    ',
'  elsif (:P595_KONZERN_JIRA_TICKETID is not null) then',
'     update t_konzern_jira_ticket ',
'        set ticketnr = :P595_TICKETNR, link = :P595_LINK',
'      where konzern_jira_ticketid = :P595_KONZERN_JIRA_TICKETID;',
'   else',
'      debug(''page 595: REQUEST =''||:REQUEST, '''' );',
'  end if;',
'  -- konzern_cluster',
'   --merge insert into',
'  ',
'  Exception when OTHERS then',
'  debug(''page 595: Exception'', '''');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE, CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3296882583010212972
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(375329353339175260)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Merge ref Konzern Cluster'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_konzern_jira_ticketid number;',
'begin',
'    l_konzern_jira_ticketid := :P595_KONZERN_JIRA_TICKETID;',
'    -- neue Konzern_Cluster einfuegen',
'    merge into t_KONZERN_JIRA_TICKET_ref_konzern_cluster dest',
'    using (select l_konzern_jira_ticketid as konzern_jira_ticketid, column_value as konzern_clusterid from table(APEX_STRING.split_numbers(:P595_KONZERN_CLUSTER, '':''))) src',
'    on (src.konzern_jira_ticketid = dest.konzern_jira_ticketid ',
'       and src.konzern_clusterid = dest.konzern_clusterid)',
'    when not matched then',
'    insert (konzern_jira_ticketid, konzern_clusterid)',
'    values (src.konzern_jira_ticketid, src.konzern_clusterid);',
'    ',
'    -- entfernte Konzern_Cluster loeschen',
'    delete from t_konzern_jira_ticket_ref_konzern_cluster kjkc',
'    where kjkc.konzern_jira_ticketid = l_konzern_jira_ticketid',
'        and kjkc.konzern_clusterid not in (select column_value from table(APEX_STRING.split_numbers(:P595_KONZERN_CLUSTER, '':'')));',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE, CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3296882962560212975
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(375329216834175258)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Merge ref Arbeitskreise'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_konzern_jira_ticketid number;',
'begin',
'    l_konzern_jira_ticketid := :P595_KONZERN_JIRA_TICKETID;',
'    -- neue Arbeitskreise einfuegen',
'    merge into t_konzern_jira_ticket_ref_et_b_ak dest',
'    using (select l_konzern_jira_ticketid as konzern_jira_ticketid, column_value as et_b_akid from table(APEX_STRING.split_numbers(:P595_ARBEITSKREISE, '':''))) src',
'    on (src.konzern_jira_ticketid = dest.konzern_jira_ticketid ',
'       and src.et_b_akid = dest.et_b_akid)',
'    when not matched then',
'    insert (konzern_jira_ticketid, et_b_akid)',
'    values (src.konzern_jira_ticketid, src.et_b_akid);',
'    ',
'    -- entfernte Konzern_Cluster loeschen',
'    delete from t_konzern_jira_ticket_ref_et_b_ak kjrak',
'    where kjrak.konzern_jira_ticketid = l_konzern_jira_ticketid',
'        and kjrak.et_b_akid not in (select column_value from table(APEX_STRING.split_numbers(:P595_ARBEITSKREISE, '':'')));',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3296883099065212977
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(375329046409175257)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Merge ref Vorschriften'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_konzern_jira_ticketid number;',
'begin',
'    l_konzern_jira_ticketid := :P595_KONZERN_JIRA_TICKETID;',
'    -- ',
'    merge into t_konzern_jira_ticket_ref_vorschrift dest',
'    using (select l_konzern_jira_ticketid as konzern_jira_ticketid, column_value as vorschriftid from table(APEX_STRING.split_numbers(:P595_VORSCHRIFTEN, '':''))) src',
'    on (src.konzern_jira_ticketid = dest.konzern_jira_ticketid ',
'       and src.vorschriftid = dest.vorschriftid)',
'    when not matched then',
'    insert (konzern_jira_ticketid, vorschriftid)',
'    values (src.konzern_jira_ticketid, src.vorschriftid);',
'    ',
'    -- entfernte Konzern_Cluster loeschen',
'    delete from t_konzern_jira_ticket_ref_vorschrift kjrv',
'    where kjrv.konzern_jira_ticketid = l_konzern_jira_ticketid',
'        and kjrv.vorschriftid not in (select column_value from table(APEX_STRING.split_numbers(:P595_VORSCHRIFTEN, '':'')));',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3296883269490212978
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(375329520694175261)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete Ticket'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from t_konzern_jira_ticket_ref_konzern_cluster',
'where konzern_jira_ticketid = :P595_KONZERN_JIRA_TICKETID;',
'',
'delete from t_konzern_jira_ticket_ref_et_b_ak',
'where konzern_jira_ticketid = :P595_KONZERN_JIRA_TICKETID;',
'',
'delete from t_konzern_jira_ticket_ref_vorschrift',
'where konzern_jira_ticketid = :P595_KONZERN_JIRA_TICKETID;',
'',
'delete from t_konzern_jira_ticket',
' where konzern_jira_ticketid = :P595_KONZERN_JIRA_TICKETID;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('Ticket konnte nicht gel\00F6scht werden!')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(374248520864172165)
,p_internal_uid=>3296882795205212974
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(374246470205172164)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3297965845694216071
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(375329749915175264)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Initialize'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  if(:P595_KONZERN_JIRA_TICKETID is not null) then',
'    select link, TICKETNR into :P595_LINK, :P595_TICKETNR',
'      from t_KONZERN_jira_ticket ',
'     where KONZERN_jira_ticketid= :P595_KONZERN_JIRA_TICKETID;',
'   end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>3296882565984212971
);
wwv_flow_imp.component_end;
end;
/
