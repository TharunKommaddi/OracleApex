prompt --application/pages/page_00467
begin
--   Manifest
--     PAGE: 00467
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>467
,p_name=>unistr('\00C4nderungshistorie')
,p_alias=>'HISTORY'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('\00C4nderungshistorie')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function regiontitle(){',
'var cardNum = apex.item("P467_CARD_NUM").getValue();',
'if (cardNum){',
unistr('apex.util.getTopApex().jQuery(".ui-dialog-content").dialog("option", "title", "\00C4nderungshistorie Karte " + cardNum);'),
'}else{',
unistr('apex.util.getTopApex().jQuery(".ui-dialog-content").dialog("option", "title", "\00C4nderungshistorie Karte");'),
'} ',
'}'))
,p_javascript_code_onload=>'regiontitle();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IR_HIST .t-fht-tbody {max-height: calc(100vh - 200px)}',
'.t-Body-topButton {display: none !important}',
'.t-Body-content {padding-bottom: 3px !important}',
'.t-Body {margin-bottom: 3px !important}',
'.t-Body-contentInner {padding-bottom: 0px !important}'))
,p_step_template=>wwv_flow_imp.id(3414111602455820538)
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3112140012749461085)
,p_plug_name=>unistr('\00C4nderungshistorie f\00FCr Karte &P467_CARD_NUM.')
,p_region_name=>'IR_HIST'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    AKTION,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.ET_VERWENDUNG, ',
'        LAG(combined_history.ET_VERWENDUNG) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC), ',
'        combined_history.AKTION',
'    ) AS ET_VERWENDUNG,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.ET_VORSCHLAG_VORSCHRIFT, ',
'        LAG(combined_history.ET_VORSCHLAG_VORSCHRIFT) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS ET_VORSCHLAG_VORSCHRIFT,',
'    ',
'    -- ET COMMENT COLUMN (VARCHAR2)',
'    pck_ri_history.fdiff(',
'        combined_history.ET_KOMMENTAR, ',
'        LAG(combined_history.ET_KOMMENTAR) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS ET_KOMMENTAR,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.FB_VERWENDUNG, ',
'        LAG(combined_history.FB_VERWENDUNG) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS FB_VERWENDUNG,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.FB_VORSCHLAG_VORSCHRIFT, ',
'        LAG(combined_history.FB_VORSCHLAG_VORSCHRIFT) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS FB_VORSCHLAG_VORSCHRIFT,',
'    ',
'    -- FB COMMENT COLUMN (VARCHAR2)',
'    pck_ri_history.fdiff(',
'        combined_history.FB_KOMMENTAR, ',
'        LAG(combined_history.FB_KOMMENTAR) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS FB_KOMMENTAR,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.VORSCHRIFT_INFO, ',
'        LAG(combined_history.VORSCHRIFT_INFO) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS VORSCHRIFT_NUMMER,',
'    ',
'    -- CARD STATUS COLUMN',
'    pck_ri_history.fdiff(',
'        combined_history.CARD_STATUS, ',
'        LAG(combined_history.CARD_STATUS) OVER(PARTITION BY combined_history.CARD_NUMBER ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS CARD_STATUS,',
'    ',
'    combined_history.BEREICH,',
'    combined_history.table_type AS KATEGORIE,',
'    ',
'    NVL2(combined_history.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, NULL) AS LETZTE_AENDERUNG_BENUTZER,',
'    TO_CHAR(combined_history.LETZTE_AENDERUNG_DATUM, ''DD.MM.YYYY HH24:MI:SS'') AS LETZTE_AENDERUNG_DATUM,',
'    b.EMAIL,',
'    combined_history.PERMALINK',
'',
'FROM (',
'    -- BEWERTUNG History',
'    SELECT ',
'        ''BEWERTUNG'' AS table_type,',
'        h.CARD_NUMBER,',
'        h.VORSCHRIFTID,',
'        h.AKTION,',
'        h.ET_VERWENDUNG,',
'        h.ET_VORSCHLAG_VORSCHRIFT,',
'        h.ET_KOMMENTAR,',
'        h.FB_VERWENDUNG,',
'        h.FB_VORSCHLAG_VORSCHRIFT,',
'        h.FB_KOMMENTAR,',
'        CAST(v.vorschrift_nummer AS VARCHAR2(2000)) AS VORSCHRIFT_INFO,',
'        CAST(''Karte '' || h.CARD_NUMBER AS VARCHAR2(2000)) AS BEREICH,',
'        h.LETZTE_AENDERUNG_DATUM,',
'        h.LETZTE_AENDERUNG_BENUTZERID,',
'        CAST(pck_ri.fCreatePermalinkUrl(v.vorschriftid) AS VARCHAR2(4000)) AS PERMALINK,',
'        CAST(NULL AS VARCHAR2(20)) AS CARD_STATUS',
'        ',
'    FROM T_H_MS_BEWERTUNG h',
'    LEFT OUTER JOIN t_vorschrift v ON (v.vorschriftid = h.vorschriftid)',
'    WHERE h.CARD_NUMBER = :P467_CARD_NUM',
'    ',
'    UNION ALL',
'    ',
'    -- SUCHERGEBNISS History  ',
'    SELECT ',
'        ''SUCHERGEBNISS'' AS table_type,',
'        CAST(NULL AS NUMBER) AS CARD_NUMBER,',
'        h.VORSCHRIFTID,',
'        h.AKTION,',
'        CAST(NULL AS VARCHAR2(200)) AS ET_VERWENDUNG,',
'        CAST(NULL AS VARCHAR2(800)) AS ET_VORSCHLAG_VORSCHRIFT,',
'        CAST(NULL AS VARCHAR2(4000)) AS ET_KOMMENTAR,',
'        CAST(NULL AS VARCHAR2(200)) AS FB_VERWENDUNG,',
'        CAST(NULL AS VARCHAR2(800)) AS FB_VORSCHLAG_VORSCHRIFT,',
'        CAST(NULL AS VARCHAR2(4000)) AS FB_KOMMENTAR,',
'        CAST(h.VORSCHRIFTNUMMER AS VARCHAR2(2000)) AS VORSCHRIFT_INFO,',
'        CAST(h.LANDNUMMER || '' - '' || h.LANDBEZEICHNUNG AS VARCHAR2(2000)) AS BEREICH,',
'        h.LETZTE_AENDERUNG_DATUM,',
'        h.LETZTE_AENDERUNG_BENUTZERID,',
'        CAST(pck_ri.fCreatePermalinkUrl(h.vorschriftid) AS VARCHAR2(4000)) AS PERMALINK,',
'        CAST(NULL AS VARCHAR2(20)) AS CARD_STATUS',
'        ',
'    -- FROM T_H_MS_SUCHERGEBNISS h',
'    -- WHERE EXISTS (',
'    --     SELECT 1 FROM T_MS_SUCHE_SPLIT split',
'    --     WHERE split.CARD_NUMBER = :P467_CARD_NUM',
'    --     AND split.SUCHEID = h.SUCHEID',
'    --     AND split.MEILENSTEIN = h.MEILENSTEIN',
'    --     AND split.LANDID = h.LANDID',
'    -- )',
'',
'    FROM T_H_MS_SUCHERGEBNISS h',
'    WHERE EXISTS (',
'        SELECT 1 FROM T_MS_SUCHE_SPLIT split',
'        WHERE split.CARD_NUMBER = :P467_CARD_NUM',
'        AND (split.BENUTZERID = :G_BENUTZERID',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001)',
'            )',
'        AND split.SUCHEID = h.SUCHEID',
'        AND split.MEILENSTEIN = h.MEILENSTEIN',
'        AND split.LANDID = h.LANDID',
'    )',
'    ',
'    UNION ALL',
'    ',
'    -- SUCHE_SPLIT History',
'    SELECT ',
'        ''SUCHE_SPLIT'' AS table_type,',
'        h.CARD_NUMBER,',
'        CAST(NULL AS NUMBER) AS VORSCHRIFTID,',
'        h.AKTION,',
'        CAST(NULL AS VARCHAR2(200)) AS ET_VERWENDUNG,',
'        CAST(NULL AS VARCHAR2(800)) AS ET_VORSCHLAG_VORSCHRIFT,',
'        CAST(NULL AS VARCHAR2(4000)) AS ET_KOMMENTAR,',
'        CAST(NULL AS VARCHAR2(200)) AS FB_VERWENDUNG,',
'        CAST(NULL AS VARCHAR2(800)) AS FB_VORSCHLAG_VORSCHRIFT,',
'        CAST(NULL AS VARCHAR2(4000)) AS FB_KOMMENTAR,',
'        CAST(h.CUSTOM_CARD_TITLE AS VARCHAR2(2000)) AS VORSCHRIFT_INFO,',
'        CAST(l.b_nummer || '' - '' || l.land AS VARCHAR2(2000)) AS BEREICH,',
'        h.LETZTE_AENDERUNG_DATUM,',
'        h.LETZTE_AENDERUNG_BENUTZERID,',
'        CAST(NULL AS VARCHAR2(4000)) AS PERMALINK,',
'        CAST(NULL AS VARCHAR2(20)) AS CARD_STATUS',
'        ',
'    FROM T_H_MS_SUCHE_SPLIT h',
'    LEFT OUTER JOIN t_land l ON (l.landid = h.landid)',
'    WHERE h.CARD_NUMBER = :P467_CARD_NUM',
'    ',
'    UNION ALL',
'    ',
'    -- CARD STATUS History - CORRECTED',
'    SELECT ',
'        ''CARD_STATUS'' AS table_type,',
'        h.CARD_NUMBER,',
'        CAST(NULL AS NUMBER) AS VORSCHRIFTID,',
'        h.AKTION,',
'        CAST(NULL AS VARCHAR2(200)) AS ET_VERWENDUNG,',
'        CAST(NULL AS VARCHAR2(800)) AS ET_VORSCHLAG_VORSCHRIFT,',
'        CAST(NULL AS VARCHAR2(4000)) AS ET_KOMMENTAR,',
'        CAST(NULL AS VARCHAR2(200)) AS FB_VERWENDUNG,',
'        CAST(NULL AS VARCHAR2(800)) AS FB_VORSCHLAG_VORSCHRIFT,',
'        CAST(NULL AS VARCHAR2(4000)) AS FB_KOMMENTAR,',
'        CAST(NULL AS VARCHAR2(2000)) AS VORSCHRIFT_INFO,  -- EMPTY - no regulation!',
'        CAST(''Karte '' || h.CARD_NUMBER AS VARCHAR2(2000)) AS BEREICH,',
'        h.LETZTE_AENDERUNG_DATUM,',
'        h.LETZTE_AENDERUNG_BENUTZERID,',
'        CAST(NULL AS VARCHAR2(4000)) AS PERMALINK,',
'        h.STATUS AS CARD_STATUS ',
'        ',
'    FROM T_H_MS_CARD_STATUS h',
'    WHERE h.CARD_NUMBER = :P467_CARD_NUM',
'    ',
') combined_history',
'LEFT OUTER JOIN t_benutzer b ON (b.benutzerid = combined_history.LETZTE_AENDERUNG_BENUTZERID)',
'',
'ORDER BY combined_history.LETZTE_AENDERUNG_DATUM DESC;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P467_CARD_NUM'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('\00C4nderungshistorie f\00FCr Karte &P467_CARD_NUM.')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    AKTION,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.ET_VERWENDUNG, ',
'        LAG(combined_history.ET_VERWENDUNG) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC), ',
'        combined_history.AKTION',
'    ) AS ET_VERWENDUNG,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.ET_VORSCHLAG_VORSCHRIFT, ',
'        LAG(combined_history.ET_VORSCHLAG_VORSCHRIFT) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS ET_VORSCHLAG_VORSCHRIFT,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.FB_VERWENDUNG, ',
'        LAG(combined_history.FB_VERWENDUNG) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS FB_VERWENDUNG,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.FB_VORSCHLAG_VORSCHRIFT, ',
'        LAG(combined_history.FB_VORSCHLAG_VORSCHRIFT) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS FB_VORSCHLAG_VORSCHRIFT,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.VORSCHRIFT_INFO, ',
'        LAG(combined_history.VORSCHRIFT_INFO) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS VORSCHRIFT_NUMMER,',
'    ',
'    combined_history.BEREICH,',
'    combined_history.table_type AS KATEGORIE,',
'    ',
'    NVL2(combined_history.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, NULL) AS LETZTE_AENDERUNG_BENUTZER,',
'    combined_history.LETZTE_AENDERUNG_DATUM,',
'    b.EMAIL,',
'    combined_history.PERMALINK',
'',
'FROM (',
'    -- BEWERTUNG History',
'    SELECT ',
'        ''BEWERTUNG'' AS table_type,',
'        h.CARD_NUMBER,',
'        h.VORSCHRIFTID,',
'        h.AKTION,',
'        h.ET_VERWENDUNG,',
'        h.ET_VORSCHLAG_VORSCHRIFT,',
'        h.FB_VERWENDUNG,',
'        h.FB_VORSCHLAG_VORSCHRIFT,',
'        v.vorschrift_nummer AS VORSCHRIFT_INFO,',
'        ''Karte '' || h.CARD_NUMBER AS BEREICH,',
'        h.LETZTE_AENDERUNG_DATUM,',
'        h.LETZTE_AENDERUNG_BENUTZERID,',
'        pck_ri.fCreatePermalinkUrl(v.vorschriftid) AS PERMALINK',
'        ',
'    FROM T_H_MS_BEWERTUNG h',
'    LEFT OUTER JOIN t_vorschrift v ON (v.vorschriftid = h.vorschriftid)',
'    WHERE h.CARD_NUMBER = :P467_CARD_NUM',
'    ',
'    UNION ALL',
'    ',
'    -- SUCHERGEBNISS History  ',
'    SELECT ',
'        ''SUCHERGEBNISS'' AS table_type,',
'        CAST(NULL AS NUMBER) AS CARD_NUMBER,',
'        h.VORSCHRIFTID,',
'        h.AKTION,',
'        CAST(NULL AS VARCHAR2(50)) AS ET_VERWENDUNG,',
'        CAST(NULL AS VARCHAR2(250)) AS ET_VORSCHLAG_VORSCHRIFT,',
'        CAST(NULL AS VARCHAR2(50)) AS FB_VERWENDUNG,',
'        CAST(NULL AS VARCHAR2(250)) AS FB_VORSCHLAG_VORSCHRIFT,',
'        h.VORSCHRIFTNUMMER AS VORSCHRIFT_INFO,',
'        h.LANDNUMMER || '' - '' || h.LANDBEZEICHNUNG AS BEREICH,',
'        h.LETZTE_AENDERUNG_DATUM,',
'        h.LETZTE_AENDERUNG_BENUTZERID,',
'        pck_ri.fCreatePermalinkUrl(h.vorschriftid) AS PERMALINK',
'        ',
'    FROM T_H_MS_SUCHERGEBNISS h',
'    WHERE EXISTS (',
'        SELECT 1 FROM T_MS_SUCHE_SPLIT split',
'        WHERE split.CARD_NUMBER = :P467_CARD_NUM',
'        AND split.SUCHEID = h.SUCHEID',
'        AND split.MEILENSTEIN = h.MEILENSTEIN',
'        AND split.LANDID = h.LANDID',
'    )',
'    ',
'    UNION ALL',
'    ',
'    -- SUCHE_SPLIT History',
'    SELECT ',
'        ''SUCHE_SPLIT'' AS table_type,',
'        h.CARD_NUMBER,',
'        CAST(NULL AS NUMBER) AS VORSCHRIFTID,',
'        h.AKTION,',
'        CAST(NULL AS VARCHAR2(50)) AS ET_VERWENDUNG,',
'        CAST(NULL AS VARCHAR2(250)) AS ET_VORSCHLAG_VORSCHRIFT,',
'        CAST(NULL AS VARCHAR2(50)) AS FB_VERWENDUNG,',
'        CAST(NULL AS VARCHAR2(250)) AS FB_VORSCHLAG_VORSCHRIFT,',
'        h.CUSTOM_CARD_TITLE AS VORSCHRIFT_INFO,',
'        l.b_nummer || '' - '' || l.land AS BEREICH,',
'        h.LETZTE_AENDERUNG_DATUM,',
'        h.LETZTE_AENDERUNG_BENUTZERID,',
'        CAST(NULL AS VARCHA'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(985040991959786925)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>unistr('Es gibt keine historischen \00C4nderungen f\00FCr diese Karte.')
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'mailto:#EMAIL#?body=#PERMALINK#'
,p_detail_link_text=>'<span class="fa fa-envelope-o" aria-hidden="true"></span></a>'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>2687171323939601310
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985036940002786885)
,p_db_column_name=>'AKTION'
,p_display_order=>60
,p_column_identifier=>'W'
,p_column_label=>'Aktion'
,p_column_html_expression=>'<span class="fa #AKTION#" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(958145941627486314)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985038967917786905)
,p_db_column_name=>'PERMALINK'
,p_display_order=>80
,p_column_identifier=>'R'
,p_column_label=>'Permalink'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985040439585786920)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>90
,p_column_identifier=>'E'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(984845039123221291)
,p_db_column_name=>'ET_KOMMENTAR'
,p_display_order=>100
,p_column_identifier=>'X'
,p_column_label=>'ET Kommentar'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985039691217786912)
,p_db_column_name=>'ET_VERWENDUNG'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'ET Verwendung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985039609823786911)
,p_db_column_name=>'ET_VORSCHLAG_VORSCHRIFT'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'ET Vorschlag Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(984845011220221290)
,p_db_column_name=>'FB_KOMMENTAR'
,p_display_order=>130
,p_column_identifier=>'Y'
,p_column_label=>'FB Kommentar'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985039473632786910)
,p_db_column_name=>'FB_VERWENDUNG'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'FB Verwendung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985039391945786909)
,p_db_column_name=>'FB_VORSCHLAG_VORSCHRIFT'
,p_display_order=>150
,p_column_identifier=>'N'
,p_column_label=>'FB Vorschlag Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(984844825504221289)
,p_db_column_name=>'CARD_STATUS'
,p_display_order=>170
,p_column_identifier=>'Z'
,p_column_label=>'Kartenstatus'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985038823611786904)
,p_db_column_name=>'BEREICH'
,p_display_order=>180
,p_column_identifier=>'S'
,p_column_label=>'Bereich'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985038798923786903)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>190
,p_column_identifier=>'T'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985039263216786908)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>200
,p_column_identifier=>'O'
,p_column_label=>unistr('\00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985037129462786887)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>unistr('\00C4nderung Datum')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985039086239786906)
,p_db_column_name=>'EMAIL'
,p_display_order=>220
,p_column_identifier=>'Q'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(985029484087744668)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'26871829'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'VORSCHRIFT_NUMMER:AKTION:EMAIL:PERMALINK:ET_KOMMENTAR:ET_VERWENDUNG:ET_VORSCHLAG_VORSCHRIFT:FB_KOMMENTAR:FB_VERWENDUNG:FB_VORSCHLAG_VORSCHRIFT:BEREICH:KATEGORIE:CARD_STATUS:LETZTE_AENDERUNG_DATUM:LETZTE_AENDERUNG_BENUTZER:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(985041485970786930)
,p_plug_name=>'CLOSE'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(985038628410786902)
,p_plug_name=>unistr('\00C4nderungshistorie f\00FCr Karte &P467_CARD_NUM.')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    AKTION,',
'',
'',
'',
'',
'    pck_ri_history.fdiff(',
'        combined_history.ET_VERWENDUNG, ',
'        LAG(combined_history.ET_VERWENDUNG) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC), ',
'        combined_history.AKTION',
'    ) AS ET_VERWENDUNG,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.ET_VORSCHLAG_VORSCHRIFT, ',
'        LAG(combined_history.ET_VORSCHLAG_VORSCHRIFT) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS ET_VORSCHLAG_VORSCHRIFT,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.FB_VERWENDUNG, ',
'        LAG(combined_history.FB_VERWENDUNG) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS FB_VERWENDUNG,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.FB_VORSCHLAG_VORSCHRIFT, ',
'        LAG(combined_history.FB_VORSCHLAG_VORSCHRIFT) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS FB_VORSCHLAG_VORSCHRIFT,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.VORSCHRIFT_INFO, ',
'        LAG(combined_history.VORSCHRIFT_INFO) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS VORSCHRIFT_NUMMER,',
'    ',
'    combined_history.BEREICH,',
'    combined_history.table_type AS KATEGORIE,',
'    ',
'    NVL2(combined_history.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, NULL) AS LETZTE_AENDERUNG_BENUTZER,',
'    -- combined_history.LETZTE_AENDERUNG_DATUM,',
'    TO_CHAR(combined_history.LETZTE_AENDERUNG_DATUM, ''DD.MM.YYYY HH24:MI:SS'') AS LETZTE_AENDERUNG_DATUM,',
'    b.EMAIL,',
'    combined_history.PERMALINK',
'',
'FROM (',
'    -- BEWERTUNG History',
'    SELECT ',
'        ''BEWERTUNG'' AS table_type,',
'        h.CARD_NUMBER,',
'        h.VORSCHRIFTID,',
'        h.AKTION,',
'        h.ET_VERWENDUNG,',
'        h.ET_VORSCHLAG_VORSCHRIFT,',
'        h.FB_VERWENDUNG,',
'        h.FB_VORSCHLAG_VORSCHRIFT,',
'        v.vorschrift_nummer AS VORSCHRIFT_INFO,',
'        ''Karte '' || h.CARD_NUMBER AS BEREICH,',
'        h.LETZTE_AENDERUNG_DATUM,',
'        h.LETZTE_AENDERUNG_BENUTZERID,',
'        pck_ri.fCreatePermalinkUrl(v.vorschriftid) AS PERMALINK',
'        ',
'    FROM T_H_MS_BEWERTUNG h',
'    LEFT OUTER JOIN t_vorschrift v ON (v.vorschriftid = h.vorschriftid)',
'    WHERE h.CARD_NUMBER = :P467_CARD_NUM',
'    ',
'    UNION ALL',
'    ',
'    -- SUCHERGEBNISS History  ',
'    SELECT ',
'        ''SUCHERGEBNISS'' AS table_type,',
'        CAST(NULL AS NUMBER) AS CARD_NUMBER,',
'        h.VORSCHRIFTID,',
'        h.AKTION,',
'        CAST(NULL AS VARCHAR2(50)) AS ET_VERWENDUNG,',
'        CAST(NULL AS VARCHAR2(250)) AS ET_VORSCHLAG_VORSCHRIFT,',
'        CAST(NULL AS VARCHAR2(50)) AS FB_VERWENDUNG,',
'        CAST(NULL AS VARCHAR2(250)) AS FB_VORSCHLAG_VORSCHRIFT,',
'        h.VORSCHRIFTNUMMER AS VORSCHRIFT_INFO,',
'        h.LANDNUMMER || '' - '' || h.LANDBEZEICHNUNG AS BEREICH,',
'        h.LETZTE_AENDERUNG_DATUM,',
'        h.LETZTE_AENDERUNG_BENUTZERID,',
'        pck_ri.fCreatePermalinkUrl(h.vorschriftid) AS PERMALINK',
'        ',
'    FROM T_H_MS_SUCHERGEBNISS h',
'    WHERE EXISTS (',
'        SELECT 1 FROM T_MS_SUCHE_SPLIT split',
'        WHERE split.CARD_NUMBER = :P467_CARD_NUM',
'        AND split.SUCHEID = h.SUCHEID',
'        AND split.MEILENSTEIN = h.MEILENSTEIN',
'        AND split.LANDID = h.LANDID',
'    )',
'    ',
'    UNION ALL',
'    ',
'    -- SUCHE_SPLIT History',
'    SELECT ',
'        ''SUCHE_SPLIT'' AS table_type,',
'        h.CARD_NUMBER,',
'        CAST(NULL AS NUMBER) AS VORSCHRIFTID,',
'        h.AKTION,',
'        CAST(NULL AS VARCHAR2(50)) AS ET_VERWENDUNG,',
'        CAST(NULL AS VARCHAR2(250)) AS ET_VORSCHLAG_VORSCHRIFT,',
'        CAST(NULL AS VARCHAR2(50)) AS FB_VERWENDUNG,',
'        CAST(NULL AS VARCHAR2(250)) AS FB_VORSCHLAG_VORSCHRIFT,',
'        h.CUSTOM_CARD_TITLE AS VORSCHRIFT_INFO,',
'        l.b_nummer || '' - '' || l.land AS BEREICH,',
'        h.LETZTE_AENDERUNG_DATUM,',
'        h.LETZTE_AENDERUNG_BENUTZERID,',
'        CAST(NULL AS VARCHAR2(4000)) AS PERMALINK',
'        ',
'    FROM T_H_MS_SUCHE_SPLIT h',
'    LEFT OUTER JOIN t_land l ON (l.landid = h.landid)',
'    WHERE h.CARD_NUMBER = :P467_CARD_NUM',
'    ',
') combined_history',
'LEFT OUTER JOIN t_benutzer b ON (b.benutzerid = combined_history.LETZTE_AENDERUNG_BENUTZERID)',
'',
'ORDER BY combined_history.LETZTE_AENDERUNG_DATUM DESC;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'NEVER'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('\00C4nderungshistorie f\00FCr Karte &P467_CARD_NUM.')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    AKTION,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.ET_VERWENDUNG, ',
'        LAG(combined_history.ET_VERWENDUNG) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC), ',
'        combined_history.AKTION',
'    ) AS ET_VERWENDUNG,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.ET_VORSCHLAG_VORSCHRIFT, ',
'        LAG(combined_history.ET_VORSCHLAG_VORSCHRIFT) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS ET_VORSCHLAG_VORSCHRIFT,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.FB_VERWENDUNG, ',
'        LAG(combined_history.FB_VERWENDUNG) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS FB_VERWENDUNG,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.FB_VORSCHLAG_VORSCHRIFT, ',
'        LAG(combined_history.FB_VORSCHLAG_VORSCHRIFT) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS FB_VORSCHLAG_VORSCHRIFT,',
'    ',
'    pck_ri_history.fdiff(',
'        combined_history.VORSCHRIFT_INFO, ',
'        LAG(combined_history.VORSCHRIFT_INFO) OVER(PARTITION BY combined_history.CARD_NUMBER, combined_history.VORSCHRIFTID ORDER BY combined_history.LETZTE_AENDERUNG_DATUM ASC)',
'    ) AS VORSCHRIFT_NUMMER,',
'    ',
'    combined_history.BEREICH,',
'    combined_history.table_type AS KATEGORIE,',
'    ',
'    NVL2(combined_history.LETZTE_AENDERUNG_BENUTZERID, b.nachname || '', '' || b.vorname, NULL) AS LETZTE_AENDERUNG_BENUTZER,',
'    combined_history.LETZTE_AENDERUNG_DATUM,',
'    b.EMAIL,',
'    combined_history.PERMALINK',
'',
'FROM (',
'    -- BEWERTUNG History',
'    SELECT ',
'        ''BEWERTUNG'' AS table_type,',
'        h.CARD_NUMBER,',
'        h.VORSCHRIFTID,',
'        h.AKTION,',
'        h.ET_VERWENDUNG,',
'        h.ET_VORSCHLAG_VORSCHRIFT,',
'        h.FB_VERWENDUNG,',
'        h.FB_VORSCHLAG_VORSCHRIFT,',
'        v.vorschrift_nummer AS VORSCHRIFT_INFO,',
'        ''Karte '' || h.CARD_NUMBER AS BEREICH,',
'        h.LETZTE_AENDERUNG_DATUM,',
'        h.LETZTE_AENDERUNG_BENUTZERID,',
'        pck_ri.fCreatePermalinkUrl(v.vorschriftid) AS PERMALINK',
'        ',
'    FROM T_H_MS_BEWERTUNG h',
'    LEFT OUTER JOIN t_vorschrift v ON (v.vorschriftid = h.vorschriftid)',
'    WHERE h.CARD_NUMBER = :P467_CARD_NUM',
'    ',
'    UNION ALL',
'    ',
'    -- SUCHERGEBNISS History  ',
'    SELECT ',
'        ''SUCHERGEBNISS'' AS table_type,',
'        CAST(NULL AS NUMBER) AS CARD_NUMBER,',
'        h.VORSCHRIFTID,',
'        h.AKTION,',
'        CAST(NULL AS VARCHAR2(50)) AS ET_VERWENDUNG,',
'        CAST(NULL AS VARCHAR2(250)) AS ET_VORSCHLAG_VORSCHRIFT,',
'        CAST(NULL AS VARCHAR2(50)) AS FB_VERWENDUNG,',
'        CAST(NULL AS VARCHAR2(250)) AS FB_VORSCHLAG_VORSCHRIFT,',
'        h.VORSCHRIFTNUMMER AS VORSCHRIFT_INFO,',
'        h.LANDNUMMER || '' - '' || h.LANDBEZEICHNUNG AS BEREICH,',
'        h.LETZTE_AENDERUNG_DATUM,',
'        h.LETZTE_AENDERUNG_BENUTZERID,',
'        pck_ri.fCreatePermalinkUrl(h.vorschriftid) AS PERMALINK',
'        ',
'    FROM T_H_MS_SUCHERGEBNISS h',
'    WHERE EXISTS (',
'        SELECT 1 FROM T_MS_SUCHE_SPLIT split',
'        WHERE split.CARD_NUMBER = :P467_CARD_NUM',
'        AND split.SUCHEID = h.SUCHEID',
'        AND split.MEILENSTEIN = h.MEILENSTEIN',
'        AND split.LANDID = h.LANDID',
'    )',
'    ',
'    UNION ALL',
'    ',
'    -- SUCHE_SPLIT History',
'    SELECT ',
'        ''SUCHE_SPLIT'' AS table_type,',
'        h.CARD_NUMBER,',
'        CAST(NULL AS NUMBER) AS VORSCHRIFTID,',
'        h.AKTION,',
'        CAST(NULL AS VARCHAR2(50)) AS ET_VERWENDUNG,',
'        CAST(NULL AS VARCHAR2(250)) AS ET_VORSCHLAG_VORSCHRIFT,',
'        CAST(NULL AS VARCHAR2(50)) AS FB_VERWENDUNG,',
'        CAST(NULL AS VARCHAR2(250)) AS FB_VORSCHLAG_VORSCHRIFT,',
'        h.CUSTOM_CARD_TITLE AS VORSCHRIFT_INFO,',
'        l.b_nummer || '' - '' || l.land AS BEREICH,',
'        h.LETZTE_AENDERUNG_DATUM,',
'        h.LETZTE_AENDERUNG_BENUTZERID,',
'        CAST(NULL AS VARCHA'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(985038546459786901)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>unistr('Es gibt keine historischen \00C4nderungen f\00FCr diese Karte.')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>2687173769439601334
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985038507203786900)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Vorschrift Nummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985038356187786899)
,p_db_column_name=>'AKTION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Aktion'
,p_column_html_expression=>'<span class="fa #AKTION#" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(958145941627486314)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985038218835786898)
,p_db_column_name=>'ET_VERWENDUNG'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Et Verwendung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985038210801786897)
,p_db_column_name=>'ET_VORSCHLAG_VORSCHRIFT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Et Vorschlag Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985038043360786896)
,p_db_column_name=>'FB_VERWENDUNG'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fb Verwendung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985037921147786895)
,p_db_column_name=>'FB_VORSCHLAG_VORSCHRIFT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fb Vorschlag Vorschrift'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985037882120786894)
,p_db_column_name=>'LETZTE_AENDERUNG_BENUTZER'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('\00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985037704946786892)
,p_db_column_name=>'EMAIL'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985037596351786891)
,p_db_column_name=>'PERMALINK'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Permalink'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985037486678786890)
,p_db_column_name=>'BEREICH'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Bereich'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(985037349538786889)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(984848607210221326)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Letzte Aenderung Datum'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(985041275350786928)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(985041485970786930)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(985041844234786934)
,p_name=>'P467_CARD_NUM'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(985041772069786933)
,p_name=>'P467_SEARCH_SELECTION'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(985041696533786932)
,p_name=>'P467_MILESTONE_SELECTION'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(985040208502786917)
,p_name=>'Close Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(985041275350786928)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(985040092669786916)
,p_event_id=>wwv_flow_imp.id(985040208502786917)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp.component_end;
end;
/
