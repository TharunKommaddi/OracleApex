prompt --application/pages/page_00255
begin
--   Manifest
--     PAGE: 00255
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>255
,p_name=>'Keyword bearbeiten'
,p_alias=>'KEYWORD-BEARBEITEN'
,p_page_mode=>'MODAL'
,p_step_title=>'Keyword bearbeiten'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>unistr('var htmldb_delete_message=''M\00F6chten Sie dieses Keyword wirklich l\00F6schen?'';')
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'600'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(644991141179150487)
,p_plug_name=>'Keyword bearbeiten'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_SCHLAGWORT'
,p_include_rowid_column=>true
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(644987283582150459)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115701564820543)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(644986862831150459)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(644987283582150459)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(644985290444150458)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(644987283582150459)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P255_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(644984861262150458)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(644987283582150459)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\00C4nderungen Speichern')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P255_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(644984529871150458)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(644987283582150459)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144722843820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Hinzuf\00FCgen')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P255_ROWID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(644990764530150486)
,p_name=>'P255_ROWID'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(644991141179150487)
,p_item_source_plug_id=>wwv_flow_imp.id(644991141179150487)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Rowid'
,p_source=>'ROWID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(644990392194150476)
,p_name=>'P255_PARENTID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(644991141179150487)
,p_item_source_plug_id=>wwv_flow_imp.id(644991141179150487)
,p_source=>'PARENTID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(644989952575150471)
,p_name=>'P255_TEXT'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(644991141179150487)
,p_item_source_plug_id=>wwv_flow_imp.id(644991141179150487)
,p_prompt=>'Keyword Text'
,p_source=>'STEXT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>250
,p_field_template=>wwv_flow_imp.id(2707165174169204364)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(644989549652150465)
,p_name=>'P255_LETZTE_AENDERUNG_DATUM'
,p_source_data_type=>'DATE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(644991141179150487)
,p_item_source_plug_id=>wwv_flow_imp.id(644991141179150487)
,p_source=>'LETZTE_AENDERUNG_DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(644989190052150460)
,p_name=>'P255_LETZTE_AENDERUNG_BENUTZERID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(644991141179150487)
,p_item_source_plug_id=>wwv_flow_imp.id(644991141179150487)
,p_source=>'LETZTE_AENDERUNG_BENUTZERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(644978535325140099)
,p_name=>'P255_DISPLAY_PARENT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(644991141179150487)
,p_item_source_plug_id=>wwv_flow_imp.id(644991141179150487)
,p_prompt=>'Parent'
,p_source=>'PARENTID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_SCHLAGWORT_STAMMDATEN'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT stext as Schlagwort, SCHLAGWORTID as R, spath as Pfad ',
'FROM (',
'  SELECT stext, SCHLAGWORTID, sys_connect_by_path(stext, ''/'') spath',
'  FROM T_SCHLAGWORT',
'  --WHERE SCHLAGWORTID NOT IN (SELECT DISTINCT PARENTID FROM T_SCHLAGWORT WHERE PARENTID IS NOT NULL)',
'  CONNECT BY PRIOR SCHLAGWORTID = parentid',
'  START WITH parentid IS NULL',
');',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- keine -'
,p_cSize=>30
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'height', '300',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(644978063576140095)
,p_name=>'P255_PARENT_TEXT'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(644991141179150487)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select stext from t_schlagwort',
'where schlagwortid = :p255_parentid;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(581723776439659979)
,p_name=>'P255_SCHLAGWORTID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(644991141179150487)
,p_item_source_plug_id=>wwv_flow_imp.id(644991141179150487)
,p_source=>'SCHLAGWORTID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(581723649995659978)
,p_validation_name=>' Loops not allowed'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare n_exists number:=0;',
' begin',
'    if :P255_DISPLAY_PARENT = :P255_SCHLAGWORTID then',
'       return false;',
'    end if;',
'    select case when exists(',
'                select dummy from dual where :P255_DISPLAY_PARENT in',
'                 (SELECT SCHLAGWORTID  FROM T_SCHLAGWORT',
'                  START WITH parentid  = :P255_SCHLAGWORTID ',
'                   CONNECT BY PRIOR SCHLAGWORTID = parentid)',
'             ) then  1',
'             else 0 end into n_exists',
'     from dual; ',
'',
'   if ( n_exists is not null and n_exists =1) then',
'     return false;',
'    end if;',
'      ',
'   return true;',
'   --exception when others then',
'    -- return true; ',
' end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('Anh\00E4ngen eines Elements unter eigenem Zweig ist nicht erlaubt.')
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(554263786029028795)
,p_validation_name=>'Duplikate im Zweig'
,p_validation_sequence=>20
,p_validation=>'select * from T_schlagwort where trim(stext) = :P255_TEXT and parentid = :P255_DISPLAY_PARENT;'
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>unistr('Duplikate (gleiche keywords) sind nicht zul\00E4ssig.')
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(644986743304150459)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(644986862831150459)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(644985981498150458)
,p_event_id=>wwv_flow_imp.id(644986743304150459)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(644983719997150457)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(644991141179150487)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Schlagwort Bearbeiten'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_process_error_message=>unistr('Das Keyword kann nicht gel\00F6scht werden.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3027228595902237778
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(644983256820150457)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>3027229059079237778
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(644984053774150457)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(644991141179150487)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Schlagwort Bearbeiten'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3027228262125237778
);
wwv_flow_imp.component_end;
end;
/
