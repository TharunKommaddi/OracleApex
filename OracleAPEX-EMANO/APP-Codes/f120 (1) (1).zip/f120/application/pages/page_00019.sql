prompt --application/pages/page_00019
begin
--   Manifest
--     PAGE: 00019
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>19
,p_name=>'Backup - 1615 pm'
,p_alias=>'BACKUP-1615-PM'
,p_step_title=>'Backup - 1615 pm'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/**********************************************',
' * Global Variables',
' ***********************************************/',
'const cardState = new Map();',
'const DEBUG_MODE = false;',
'',
'function debug(message) {',
'    if (DEBUG_MODE) {',
'        console.log(message);',
'    }',
'}',
'',
'/**********************************************',
' * Shuttle Loading Function',
' ***********************************************/',
'function loadLaenderShuttle() {',
'    const shuttleName = ''P460_FILTER_LAND'';',
'    const lLeft = $x(shuttleName + ''_LEFT'');',
'    const lRight = $x(shuttleName + ''_RIGHT'');',
'    const lSelected = $.map(lRight.options, function (n) {',
'        return n.value;',
'    });',
'',
'    apex.server.process(',
'        ''loadLaenderShuttle'',',
'        {',
'            x01: lSelected.join('':''),',
'            x02: $v(''P460_FILTER_LAENDERGRUPPE''),',
'            x03: $v(''P460_SEARCH_SELECTION''),',
'            x04: $v(''P460_MILESTONE_SELECTION'')',
'        },',
'        {',
'            success: function (pData) {',
'                lLeft.length = 0;',
'                for (var i = 0; i < pData.length; i++) {',
'                    lLeft.options[i] = new Option(pData[i].d, pData[i].r);',
'                }',
'            },',
'            error: function (xhr, status, error) {',
'                console.error(''Error loading shuttle:'', error);',
'                apex.message.showPageError(''Error loading country shuttle: '' + error);',
'            },',
'            dataType: "json"',
'        }',
'    );',
'}',
'',
'/**********************************************',
' * Card Management Functions',
' ***********************************************/',
'function click_to_showResult() {',
'    // Get selected countries',
'    const shuttleName = ''P460_FILTER_LAND'';',
'    const lRight = $x(shuttleName + ''_RIGHT'');',
'    const lSelected = $.map(lRight.options, function (n) {',
'        return n.value;',
'    }).join('':'');',
'',
'    apex.server.process(',
'        ''INSERT_CODE_AJAX'',',
'        {',
'            x01: lSelected,',
'            x02: $v(''P460_FILTER_LAENDERGRUPPE''),',
'            x03: $v(''P460_SEARCH_SELECTION''),',
'            x04: $v(''P460_MILESTONE_SELECTION'')',
'        },',
'        {',
'            dataType: "json",',
'            success: function() {',
'                // Clear card state and refresh region',
'                cardState.clear();',
'                refreshcard();',
'            },',
'            error: function(xhr, status, error) {',
'                console.error(''Error applying filter:'', error);',
'                apex.message.showPageError(''Error applying filter: '' + error);',
'            }',
'        }',
'    );',
'}',
'',
'',
'/*',
'function loadCardContent(cardsToUpdate = [], forceReload = false) {',
'    document.querySelectorAll(''.card-placeholder'').forEach(function(placeholder) {',
'        const cardNum = placeholder.getAttribute(''data-card'');',
'        const landids = placeholder.getAttribute(''data-landids'');',
'        ',
'       ',
'        if (!forceReload && placeholder.classList.contains(''loaded'')) {',
'            cardState.set(cardNum, landids);',
'            return;',
'        }',
'',
'        // Only load specified cards or all if empty array',
'        if (!cardsToUpdate.length || cardsToUpdate.includes(cardNum)) {',
'            apex.server.process(',
'                ''GET_CARD_CONTENT'',',
'                {',
'                    x01: cardNum,',
'                    x02: landids,',
'                    x03: $v(''P460_SEARCH_SELECTION''),',
'                    x04: $v(''P460_MILESTONE_SELECTION'')',
'                },',
'                {',
'                    dataType: ''html'',',
'                    success: function(data) {',
'                        placeholder.innerHTML = data;',
'                        placeholder.classList.add(''loaded'');',
'                        cardState.set(cardNum, landids);',
'                        ',
'                        const loadDataDiv = placeholder.querySelector(''.loaddata'');',
'                        if (loadDataDiv) {',
'                            loadDataForCard(loadDataDiv);',
'                        }',
'                    }',
'                }',
'            );',
'        }',
'    });',
'}',
'',
'*/',
'',
'',
'function loadCardContent(cardsToUpdate = [], forceReload = false) {',
'    console.log("Loading card content, force reload:", forceReload);',
'    ',
'    const cards = document.querySelectorAll(''.card-placeholder'');',
'    console.log("Found " + cards.length + " card placeholders");',
'    ',
'    document.querySelectorAll(''.card-placeholder'').forEach(function(placeholder) {',
'        const cardNum = placeholder.getAttribute(''data-card'');',
'        const landids = placeholder.getAttribute(''data-landids'');',
'        ',
'        if (!forceReload && placeholder.classList.contains(''loaded'')) {',
'            cardState.set(cardNum, landids);',
'            return;',
'        }',
'',
'        // Only load specified cards or all if empty array',
'        if (!cardsToUpdate.length || cardsToUpdate.includes(cardNum)) {',
'            console.log(`Loading content for card ${cardNum} with countries: ${landids}`);',
'            ',
'            apex.server.process(',
'                ''GET_CARD_CONTENT'',',
'                {',
'                    x01: cardNum,',
'                    x02: landids,',
'                    x03: $v(''P460_SEARCH_SELECTION''),',
'                    x04: $v(''P460_MILESTONE_SELECTION'')',
'                },',
'                {',
'                    dataType: ''html'',',
'                    success: function(data) {',
'                        console.log(`Card ${cardNum} content loaded successfully`);',
'                        placeholder.innerHTML = data;',
'                        placeholder.classList.add(''loaded'');',
'                        cardState.set(cardNum, landids);',
'                        ',
'                        const loadDataDiv = placeholder.querySelector(''.loaddata'');',
'                        if (loadDataDiv) {',
'                            console.log(`Loading data for card ${cardNum}`);',
'                            loadDataForCard(loadDataDiv);',
'                        }',
'                    },',
'                    error: function(xhr, status, error) {',
'                        console.error(`Error loading card ${cardNum}:`, error);',
'                    }',
'                }',
'            );',
'        }',
'    });',
'}',
'',
'',
'',
'function loadDataForCard(loadDataDiv) {',
'    const searchid = loadDataDiv.getAttribute(''searchid'');',
'    const milestone = loadDataDiv.getAttribute(''milestone'');',
'    const landid = loadDataDiv.getAttribute(''landid'');',
'    ',
'    apex.server.process(',
'        ''loadData'',',
'        {',
'            x01: searchid,',
'            x02: milestone,',
'            x03: landid',
'        },',
'        {',
'            success: function(pData) {',
'                const tbody = loadDataDiv.closest(''.t-Report-tableWrap'').querySelector(''tbody'');',
'                tbody.innerHTML = pData;',
'                loadDataDiv.remove();',
'            },',
'            error: function(xhr, status, error) {',
'                console.error(''Error loading card data:'', error);',
'                apex.message.showPageError(''Error loading data: '' + error);',
'            },',
'            dataType: "text"',
'        }',
'    );',
'}',
'',
'/**********************************************',
' * Card Action Functions',
' ***********************************************/',
'function processCardAction() {',
'    let action = apex.item(''P460_ACTION'').getValue();',
'    let cardNumbers = apex.item(''P460_CARD_SHUTTLE'').getValue();',
'    let selectedCountries = apex.item(''P460_SELECTED_COUNTRIES_FROM_CARD'').getValue();',
'    ',
'    if (action === ''DELETE_CARD'' && apex.item(''P460_DELETE_SPECIFIC_COUNTRIES'').getValue() === ''Y'') {',
'        action = ''DELETE_COUNTRIES'';',
'    } else if (action === ''UNMERGE_CARD'' && apex.item(''P460_SPLIT_SPECIFIC_COUNTRIES'').getValue() === ''Y'') {',
'        action = ''UNMERGE_COUNTRIES'';',
'    }',
'    ',
'    if (Array.isArray(cardNumbers)) {',
'        cardNumbers = cardNumbers.join('':'');',
'    }',
'    if (Array.isArray(selectedCountries)) {',
'        selectedCountries = selectedCountries.join('':'');',
'    }',
'',
'    apex.server.process(',
'        ''HANDLE_CARD_ACTION'',',
'        {',
'            x01: action,',
'            x02: cardNumbers,',
'            x03: selectedCountries',
'        }',
'    ).then(function (data) {',
'        if (data.status === ''success'') {',
'            apex.message.showPageSuccess(data.message);',
'            apex.item(''P460_CARD_SHUTTLE'').setValue('''');',
'            apex.item(''P460_SELECTED_COUNTRIES_FROM_CARD'').setValue('''');',
'            refreshcard();',
'        } else {',
'            console.error(''Card action failed:'', data.message);',
'            apex.message.showPageError(data.message);',
'        }',
'    }).catch(function (error) {',
'        console.error(''Card action error:'', error);',
'        apex.message.showPageError(''Action failed: '' + error);',
'    });',
'}',
'',
'/**********************************************',
' * Card Download Function',
' ***********************************************/',
'function downloadCardData(landids) {',
'    const url = ''wwv_flow.show'';',
'    const params = {',
'        p_request: ''APPLICATION_PROCESS=DOWNLOAD_CARD_DATA'',',
'        p_flow_id: $v(''pFlowId''),',
'        p_flow_step_id: $v(''pFlowStepId''),',
'        p_instance: $v(''pInstance''),',
'        x01: landids',
'    };',
'',
'    const $form = $(''<form>'', {',
'        action: url,',
'        method: ''POST'',',
'        target: ''_blank''',
'    });',
'',
'    $.each(params, function (key, value) {',
'        $form.append($(''<input>'', {',
'            type: ''hidden'',',
'            name: key,',
'            value: value',
'        }));',
'    });',
'',
'    $(''body'').append($form);',
'    $form.submit();',
'    $form.remove();',
'}',
'',
'/**********************************************',
' * UI Enhancement Functions',
' ***********************************************/',
'',
'',
'function addScrollToTopButton() {',
'    if (document.querySelector(''.scroll-to-top-btn'')) {',
'        return; // Button already exists',
'    }',
'    ',
'    const scrollButton = document.createElement(''button'');',
'    scrollButton.innerHTML = ''<i class="fa fa-arrow-up"></i>'';',
'    scrollButton.className = ''scroll-to-top-btn'';',
'    document.body.appendChild(scrollButton);',
'',
'    const style = document.createElement(''style'');',
'    style.textContent = `',
'        .scroll-to-top-btn {',
'            position: fixed;',
'            bottom: 60px;',
'            right: 20px;',
'            width: 40px;',
'            height: 40px;',
'            border-radius: 50%;',
'            background-color: #bb0a31;',
'            color: white;',
'            border: none;',
'            cursor: pointer;',
'            opacity: 0;',
'            transition: opacity 0.3s, transform 0.3s;',
'            z-index: 1000;',
'            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);',
'            display: flex;',
'            justify-content: center;',
'            align-items: center;',
'        }',
'        ',
'        .scroll-to-top-btn:hover {',
'            transform: scale(1.1);',
'            background-color: #d01a45;',
'        }',
'        ',
'',
'        ',
'        .scroll-to-top-btn.visible {',
'            opacity: 1;',
'        }',
'    `;',
'    document.head.appendChild(style);',
'',
'    window.addEventListener(''scroll'', () => {',
'        if (window.scrollY > 300) {',
'            scrollButton.classList.add(''visible'');',
'        } else {',
'            scrollButton.classList.remove(''visible'');',
'        }',
'    });',
'',
'    scrollButton.addEventListener(''click'', () => {',
'        window.scrollTo({',
'            top: 0,',
'            behavior: ''smooth''',
'        });',
'    });',
'}',
'',
'',
'',
'',
'/*',
'',
'function refreshcard() {',
'    const cardsRegion = apex.region("R43543646345346");',
'    if (!cardsRegion) {',
'        console.error("Cards region not found");',
'        return;',
'    }',
'',
'    debug(''Refreshing cards region'');',
'    // Clear existing card state',
'    cardState.clear();',
'    ',
'    // Force synchronous refresh ',
'    cardsRegion.refresh();',
'    ',
'    ',
'    cardsRegion.on("apexafterrefresh", function () {',
'        // Reset scroll position',
'        window.scrollBy(0, 1);',
'        window.scrollBy(0, -1);',
'        ',
'        // Load all cards',
'        loadCardContent([], true);',
'    });',
'}',
'*/',
'',
'',
'function refreshcard() {',
'    const cardsRegion = apex.region("R43543646345346");',
'    if (!cardsRegion) {',
'        console.error("Cards region not found");',
'        return;',
'    }',
'',
'    console.log("Refreshing cards region");',
'    // Clear existing card state',
'    cardState.clear();',
'    ',
'    // Force synchronous refresh ',
'    cardsRegion.refresh();',
'    ',
'    cardsRegion.on("apexafterrefresh", function () {',
'        console.log("Cards region refreshed");',
'        // Count cards',
'        const cardContainers = document.querySelectorAll(''.card-container'');',
'        console.log("Number of cards loaded:", cardContainers.length);',
'        ',
'        // Log card details',
'        cardContainers.forEach(function(card, index) {',
'            const cardNum = card.getAttribute(''data-cardnum'');',
'            const placeholder = card.querySelector(''.card-placeholder'');',
'            const landids = placeholder ? placeholder.getAttribute(''data-landids'') : ''unknown'';',
'            console.log(`Card ${index+1}: Number ${cardNum}, Countries: ${landids}`);',
'        });',
'        ',
'        // Reset scroll position',
'        window.scrollBy(0, 1);',
'        window.scrollBy(0, -1);',
'        ',
'        // Load all cards',
'        loadCardContent([], true);',
'    });',
'}',
'',
'',
'',
'',
'',
'',
'',
'/**********************************************',
' * Initialization Functions  ',
' ***********************************************/',
'function initializeAll() {',
'    addScrollToTopButton();',
'    setupFixedTableHeaders();',
'    addColumnHeaderToggle();',
'    setupDynamicCardMonitoring();',
'',
'',
'    // Only load unloaded cards',
'    const unloadedCards = Array.from(document.querySelectorAll(''.card-placeholder''))',
'        .filter(placeholder => !cardState.has(placeholder.getAttribute(''data-card'')))',
'        .map(placeholder => placeholder.getAttribute(''data-card''));',
'    ',
'    if (unloadedCards.length > 0) {',
'        loadCardContent(unloadedCards);',
'    }',
'',
'    setupUserInterface();',
'}',
'',
'function setupUserInterface() {',
'    function createUserDisplay() {',
'        const userIcon = $(''<span>'').addClass(''fa fa-user'').css({ ',
'            ''margin-right'': ''8px'', ',
'            ''color'': ''#bb0a31'', ',
'            ''font-weight'': ''normal'' ',
'        });',
'',
'        const userDisplay = $(''<span>'').text($(''#P460_BENUTZER_NAME'').val()).css({  ',
'            ''font-weight'': ''normal'',  ',
'            ''color'': ''#404040'', ',
'            ''font-family'': ''"Audi Type", "Helvetica Neue", Helvetica, Arial, sans-serif''  ',
'        });',
'        ',
'        return $(''<div>'')',
'            .addClass(''t-Region-headerItems t-Region-headerItems--buttons'')',
'            .css({ ',
'                ''display'': ''flex'', ',
'                ''align-items'': ''center'', ',
'                ''margin-left'': ''auto'', ',
'                ''margin-right'': ''10px'' ',
'            })',
'            .append(userIcon)',
'            .append(userDisplay);',
'    }',
'',
'    // Benutzer Name',
'    $(''.t-Form-fieldContainer:contains("Benutzer")'').hide();',
'    $(''#FilterSuche .t-Region-header .t-Region-headerItems--buttons'').replaceWith(createUserDisplay());',
'    // $(''#Kartenverwaltung .t-Region-header .t-Region-headerItems--buttons'').replaceWith(createUserDisplay());',
'    ',
'    ',
'    $(''#P460_JUMP_TO_CARD_CONTAINER'')',
'        .detach()',
'        .appendTo(''#FilterLaenderVorschriften .t-Region-headerItems--buttons'')',
'        .css({ ',
'            ''display'': ''flex'', ',
'            ''align-items'': ''center'', ',
'            ''margin-left'': ''auto'', ',
'            ''margin-right'': ''10px'', ',
'            ''padding-top'': ''6px'' ',
'        });',
'',
'    $(''#P460_JUMP_TO_CARD_LABEL'').css({ ',
'        ''margin-right'': ''0px'', ',
'        ''white-space'': ''nowrap'', ',
'        ''margin-bottom'': ''0'', ',
'        ''padding-bottom'': ''18px'' ',
'    });',
'',
'    $(''#FilterLaenderVorschriften .t-Region-headerItems--buttons'').css({ ',
'        ''display'': ''flex'', ',
'        ''align-items'': ''center'' ',
'    });',
'    ',
'    // Initialize shuttle tooltips',
'    function initializeShuttleTooltips() {',
'        $("#P460_CARD_SHUTTLE option").each(function() {',
'            $(this).attr(''title'', $(this).text());',
'        });',
'    }',
'    ',
'    initializeShuttleTooltips();',
'    ',
'    // Update button states based on selections',
'    if ($v("P460_FILTER_LAND")) {',
'        apex.item("B501317057147707225").enable();',
'    } else {',
'        apex.item("B501317057147707225").disable();',
'    }',
'    ',
'    if ($v("P460_CARD_SHUTTLE")) {',
'        apex.item("APPLY_ACTION_BUTTON").enable();',
'    } else {',
'        apex.item("APPLY_ACTION_BUTTON").disable();',
'    }',
'}',
'',
'',
'function setupFixedTableHeaders() {',
'    document.querySelectorAll(''.t-Report-tableWrap'').forEach(tableWrap => {',
'        const header = tableWrap.querySelector(''thead'');',
'        if (header) {',
'            header.classList.add(''fixed-table-header'');',
'        }',
'    });',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'function cycleStatus(cardNumber) {',
'    const statusIndicator = document.querySelector(`.status-indicator[data-card="${cardNumber}"]`);',
'    if (!statusIndicator) return;',
'    ',
'    // Get current status',
'    const currentStatus = statusIndicator.classList.contains(''not-started'') ? ''not-started'' : ',
'                          statusIndicator.classList.contains(''in-progress'') ? ''in-progress'' : ''completed'';',
'    ',
'    // Get next status',
'    const statusOrder = [''not-started'', ''in-progress'', ''completed''];',
'    const currentIndex = statusOrder.indexOf(currentStatus);',
'    const nextStatus = statusOrder[(currentIndex + 1) % statusOrder.length];',
'    ',
'    // Update UI',
'    statusIndicator.classList.remove(''not-started'', ''in-progress'', ''completed'');',
'    statusIndicator.classList.add(nextStatus);',
'    ',
'    // Set title',
'    const statusTitles = {',
'        ''not-started'': ''Nicht begonnen'',',
'        ''in-progress'': ''In Bearbeitung'',',
'        ''completed'': ''Bearbeitung des Marktes abgeschlossen''',
'    };',
'    statusIndicator.title = statusTitles[nextStatus];',
'    ',
'    // Set icon with improved visibility',
'    const statusIcons = {',
'        ''not-started'': ''<span class="fa fa-clock-o" style="font-size: 14px;"></span>'',',
'        ''in-progress'': ''<span class="fa fa-spinner fa-spin" style="font-size: 14px;"></span>'',',
'        ''completed'': ''<span class="fa fa-check-circle" style="font-size: 14px;"></span>''',
'    };',
'    statusIndicator.innerHTML = statusIcons[nextStatus];',
'    ',
'    // Save to database',
'    saveCardStatus(cardNumber, nextStatus);',
'}',
'',
'function saveCardStatus(cardNumber, status) {',
'    apex.server.process(',
'        ''UPDATE_CARD_STATUS'',',
'        {',
'            x01: cardNumber,',
'            x02: status,',
'            x03: $v(''P460_SEARCH_SELECTION''),',
'            x04: $v(''P460_MILESTONE_SELECTION'')',
'        },',
'        {',
'            success: function(data) {',
'',
'                 apex.message.showPageSuccess(''Status updated'');',
'            },',
'            error: function(xhr, status, error) {',
'                console.error(''Error updating card status:'', error);',
'                apex.message.showPageError(''Error updating status: '' + error);',
'            }',
'        }',
'    );',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'/**',
' * Column header toggle implementation',
' * Adds collapse/expand functionality with icon in the column header',
' */',
'',
'// Add styles for header toggle',
'function addToggleStyles() {',
'    if (document.getElementById(''toggle-styles'')) return;',
'    ',
'    const style = document.createElement(''style'');',
'    style.id = ''toggle-styles'';',
'    style.textContent = `',
'        .header-toggle-btn {',
'            cursor: pointer;',
'            color: #666;',
'            margin-left: 8px;',
'            transition: transform 0.3s ease;',
'        }',
'        ',
'        .header-toggle-btn:hover {',
'            color: #bb0a31;',
'        }',
'        ',
'        .header-toggle-btn.expanded {',
'            transform: rotate(180deg);',
'        }',
'        ',
'        .card-container.collapsed-view tr:nth-child(n+6) {',
'            display: none;',
'        }',
'        ',
'        .regulation-count {',
'            display: block;',
'            background-color: #f5f5f5;',
'            color: #666;',
'            border-radius: 4px;',
'            padding: 4px 8px;',
'            margin: 8px auto;',
'            text-align: center;',
'            font-size: 12px;',
'            width: fit-content;',
'        }',
'    `;',
'    document.head.appendChild(style);',
'}',
'',
'',
'function addColumnHeaderToggle() {',
'',
'    addToggleStyles();',
'    ',
'',
'    document.querySelectorAll(''.t-Report-colHead .u-Report-sortHeading'').forEach(header => {',
'        if (header.textContent.trim() === ''Vorschriftennummer'' && !header.querySelector(''.header-toggle-btn'')) {',
'            // Create toggle icon',
'            const toggleIcon = document.createElement(''span'');',
'            toggleIcon.className = ''header-toggle-btn fa fa-chevron-down'';',
'            toggleIcon.setAttribute(''title'', ''Alle anzeigen/verbergen'');',
'            ',
'            // Add icon to header',
'            header.appendChild(toggleIcon);',
'            ',
'            // Get the card container',
'            const cardContainer = header.closest(''.card-container'');',
'            if (!cardContainer) return;',
'            ',
'            const cardNum = cardContainer.getAttribute(''data-cardnum'');',
'            ',
'            // Add click event to toggle icon',
'            toggleIcon.addEventListener(''click'', function(e) {',
'                e.preventDefault();',
'                e.stopPropagation();',
'                ',
'                const isExpanded = toggleIcon.classList.contains(''expanded'');',
'                ',
'                // Toggle icon state',
'                if (isExpanded) {',
'                    toggleIcon.classList.remove(''expanded'');',
'                } else {',
'                    toggleIcon.classList.add(''expanded'');',
'                }',
'                ',
'                // Toggle card view',
'                toggleCardView(cardNum, cardContainer, !isExpanded);',
'            });',
'            ',
'            // Add count display if more than 5 regulations',
'            const tableRows = cardContainer.querySelectorAll(''.t-Report-tableWrap tbody tr'');',
'            if (tableRows.length > 5 && !cardContainer.querySelector(''.regulation-count'')) {',
'                const countDisplay = document.createElement(''div'');',
'                countDisplay.className = ''regulation-count'';',
'                countDisplay.textContent = `${tableRows.length} Vorschriften insgesamt`;',
'                ',
'                const tbody = cardContainer.querySelector(''.t-Report-tableWrap tbody'');',
'                if (tbody) {',
'                    tbody.insertBefore(countDisplay, tbody.firstChild);',
'                }',
'            }',
'            ',
'            // Initial state: collapsed',
'            cardContainer.classList.add(''collapsed-view'');',
'        }',
'    });',
'}',
'',
'// Toggle card view function',
'function toggleCardView(cardNum, cardContainer, expand) {',
'    if (!cardContainer) {',
'        cardContainer = document.querySelector(`.card-container[data-cardnum="${cardNum}"]`);',
'    }',
'    if (!cardContainer) return;',
'    ',
'    const headerToggle = cardContainer.querySelector(''.header-toggle-btn'');',
'    const countDisplay = cardContainer.querySelector(''.regulation-count'');',
'    ',
'    if (expand) {',
'        // Expand card',
'        cardContainer.classList.remove(''collapsed-view'');',
'        if (headerToggle) headerToggle.classList.add(''expanded'');',
'        if (countDisplay) countDisplay.style.display = ''none'';',
'    } else {',
'        // Collapse card',
'        cardContainer.classList.add(''collapsed-view'');',
'        if (headerToggle) headerToggle.classList.remove(''expanded'');',
'        if (countDisplay) countDisplay.style.display = ''block'';',
'    }',
'}',
'',
'',
'function setupDynamicCardMonitoring() {',
'    $(document).on(''apexafterrefresh'', function(event) {',
'',
'        setTimeout(addColumnHeaderToggle, 100);',
'    });',
'    ',
'    if (typeof loadCardContent === ''function'') {',
'        const originalLoadCardContent = loadCardContent;',
'        ',
'        window.loadCardContent = function(cardsToUpdate = [], forceReload = false) {',
'            originalLoadCardContent(cardsToUpdate, forceReload);',
'            ',
'           ',
'            setTimeout(addColumnHeaderToggle, 500);',
'        };',
'    }',
'}',
'',
'',
'function initializeAllCards() {',
'    addColumnHeaderToggle();',
'    setupDynamicCardMonitoring();',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'function openDetailView(landids, cardNum) {',
'    // Get the current status of the card',
'    const statusIndicator = document.querySelector(`.status-indicator[data-card="${cardNum}"]`);',
'    const currentStatus = statusIndicator ? ',
'        (statusIndicator.classList.contains(''not-started'') ? ''not-started'' : ',
'         statusIndicator.classList.contains(''in-progress'') ? ''in-progress'' : ''completed'') : ''not-started'';',
'    ',
'    var url = ''f?p='' + $v(''pFlowId'') + '':461:'' + $v(''pInstance'') +',
'              ''::NO:RP:P461_LANDIDS,P461_CARD_NUM,P461_SEARCH_SELECTION,P461_MILESTONE_SELECTION,P461_CARD_STATUS:'' +',
'              landids + '','' + cardNum + '','' + ',
'              $v(''P460_SEARCH_SELECTION'') + '','' + ',
'              $v(''P460_MILESTONE_SELECTION'') + '','' +',
'              currentStatus;',
'    ',
'    window.open(url, ''_blank'');',
'}',
'',
'',
'function makeEditable(cardNumber) {',
'    const titleElement = document.getElementById(''card-title-'' + cardNumber);',
'    const currentText = titleElement.textContent.trim();',
'    const titleContainer = titleElement.parentElement;',
'    ',
'    titleContainer.innerHTML = ',
'        ''<span class="edit-icon">'' +',
'        ''<span class="fa fa-edit" style="font-size: 14px; color: #666;"></span>'' +',
'        ''</span>'' +',
'        ''<input type="text" id="edit-title-'' + cardNumber + ''" '' +',
'        ''value="'' + currentText + ''" '' +',
'        ''style="width: 70%; margin: 0 5px;">'' +',
unistr('        ''<span class="save-icon" onclick="saveTitle('' + cardNumber + '')" title="\00C4nderungen speichern">'' +'),
'        ''<span class="fa fa-save" style="font-size: 14px; color: #bb0a31;"></span>'' +',
'        ''</span>'';',
'    ',
'    document.getElementById(''edit-title-'' + cardNumber).focus();',
'}',
'',
'function saveTitle(cardNumber) {',
'    const inputElement = document.getElementById(''edit-title-'' + cardNumber);',
'    const newTitle = inputElement.value;',
'    const titleContainer = inputElement.parentElement;',
'    ',
'    console.log("Saving title: " + newTitle + " for card: " + cardNumber);',
'    ',
'    titleContainer.querySelector(''.save-icon .fa'').className = ''fa fa-spinner fa-spin'';',
'    ',
'    apex.server.process(',
'        ''SAVE_CARD_TITLE'',',
'        {',
'            x01: cardNumber,',
'            x02: newTitle',
'        },',
'        {',
'            success: function(data) {',
'                console.log("Success response:", data);',
'                ',
'               ',
'                const originalTitle = data.original_title || '''';',
'                ',
'               ',
'                titleContainer.innerHTML = ',
'                    ''<span class="edit-icon" onclick="makeEditable('' + cardNumber + '')" title="Title bearbeiten">'' +',
'                    ''<span class="fa fa-edit" style="font-size: 14px; color: #666;"></span>'' +',
'                    ''</span>'' +',
'                    ''<span class="reset-icon" onclick="resetTitle('' + cardNumber + '', \'''' + ',
unistr('                    originalTitle.replace(/''/g, "\005C\005C''") + ''\005C'')" title="Zur\00FCcksetzen auf Standardtitel">'' +'),
'                    ''<span class="fa fa-undo" style="font-size: 14px; color: #666;"></span>'' +',
'                    ''</span>'' +',
'                    ''<span class="country-name" id="card-title-'' + cardNumber + ''">'' + ',
'                    newTitle + ',
'                    ''</span>'';',
'            },',
'            error: function(xhr, status, error) {',
'                console.error("AJAX Error:", error);',
'                console.error("Response Text:", xhr.responseText);',
'                alert("Error saving title: " + error);',
'                ',
'                titleContainer.querySelector(''.save-icon .fa'').className = ''fa fa-save'';',
'            },',
'            dataType: "json"',
'        }',
'    );',
'}',
'',
'function resetTitle(cardNumber, defaultTitle) {',
'    const titleElement = document.getElementById(''card-title-'' + cardNumber);',
'    const titleContainer = titleElement.parentElement;',
'    ',
'    console.log("Resetting title for card: " + cardNumber);',
'    ',
'',
'    const resetIcon = titleContainer.querySelector(''.reset-icon .fa'');',
'    if (resetIcon) {',
'        resetIcon.className = ''fa fa-spinner fa-spin'';',
'    }',
'',
'    apex.server.process(',
'        ''SAVE_CARD_TITLE'',',
'        {',
'            x01: cardNumber,',
'            x02: '''', ',
'            x03: ''RESET'' ',
'        },',
'        {',
'            success: function(data) {',
'                console.log("Reset successful:", data);',
'                ',
'                titleContainer.innerHTML = ',
'                    ''<span class="edit-icon" onclick="makeEditable('' + cardNumber + '')" title="Title bearbeiten">'' +',
'                    ''<span class="fa fa-edit" style="font-size: 14px; color: #666;"></span>'' +',
'                    ''</span>'' +',
'                    ''<span class="country-name" id="card-title-'' + cardNumber + ''">'' + ',
'                    defaultTitle + ',
'                    ''</span>'';',
'            },',
'            error: function(xhr, status, error) {',
'                console.error("Reset Error:", error);',
'                console.error("Response Text:", xhr.responseText);',
'                alert("Error resetting title: " + error);',
'                ',
'            ',
'                if (resetIcon) {',
'                    resetIcon.className = ''fa fa-undo'';',
'                }',
'            },',
'            dataType: "json"',
'        }',
'    );',
'}',
'',
'',
'',
'// Get all countries from existing cards',
'function getAllCardCountries() {',
'    let allCardCountries = [];',
'    const cardContainers = document.querySelectorAll(''.card-container'');',
'    ',
'    cardContainers.forEach(function(card) {',
'        const cardPlaceholder = card.querySelector(''.card-placeholder'');',
'        if (cardPlaceholder) {',
'            const landids = cardPlaceholder.getAttribute(''data-landids'');',
'            if (landids) {',
'                const countryIds = landids.split('':'');',
'                allCardCountries = allCardCountries.concat(countryIds);',
'            }',
'        }',
'    });',
'    ',
'    return allCardCountries.join('':'');',
'}',
'',
'// Get all card numbers',
'function getAllCardNumbers() {',
'    let allCardNumbers = [];',
'    const cardContainers = document.querySelectorAll(''.card-container'');',
'    ',
'    cardContainers.forEach(function(card) {',
'        const cardNum = card.getAttribute(''data-cardnum'');',
'        if (cardNum) {',
'            allCardNumbers.push(cardNum);',
'        }',
'    });',
'    ',
'    return allCardNumbers.join('':'');',
'}',
'',
'',
'',
'function restoreCardsFromProfile() {',
'    const cardCountries = $v(''P460_SAVED_CARD_COUNTRIES'');',
'    const cardNumbers = $v(''P460_SAVED_CARD_NUMBERS'');',
'    ',
'    console.log("Filter Profile Loading - Countries:", cardCountries);',
'    console.log("Filter Profile Loading - Card Numbers:", cardNumbers);',
'    ',
'    if (cardCountries && cardNumbers) {',
'        console.log("Attempting to restore " + cardNumbers.split('':'').length + " cards");',
'        apex.server.process(',
'            ''RESTORE_SAVED_CARDS'',',
'            {',
'                x01: cardCountries,',
'                x02: cardNumbers,',
'                x03: $v(''P460_SEARCH_SELECTION''),',
'                x04: $v(''P460_MILESTONE_SELECTION'')',
'            },',
'            {',
'                success: function(data) {',
'                    console.log("Cards restored successfully:", data);',
'                    console.log("Search Selection:", $v(''P460_SEARCH_SELECTION''));',
'                    console.log("Milestone Selection:", $v(''P460_MILESTONE_SELECTION''));',
'                    console.log("Filter Countries:", $v(''P460_FILTER_LAND''));',
'                    ',
'                    // IMPORTANT: Force a complete page submit to refresh all regions',
'                    // apex.page.submit({',
'                    //     request: "REFRESH",',
'                    //     showWait: true',
'                    // });',
'                },',
'                error: function(xhr, status, error) {',
'                    console.error("Error restoring cards:", error);',
'                    console.error("Response:", xhr.responseText);',
'                }',
'            }',
'        );',
'    } else {',
'        console.warn("No card data found in profile");',
'    }',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/**********************************************',
' * Event Handlers',
' ***********************************************/',
'$(document).ready(function() {',
'    initializeAll();',
'});',
'',
'$(document).on("apexafterrefresh", function() {',
'    initializeAll();',
'    loadCardContent();',
'});',
'',
'apex.jQuery(function($) {',
'    // Function to initialize tooltips',
'    function initializeShuttleTooltips() {',
'        $("#P460_CARD_SHUTTLE option").each(function() {',
'            var tooltipContent = $(this).text();',
'            $(this).attr(''title'', tooltipContent);',
'        });',
'    }',
'    ',
'    // Initialize on page load',
'    initializeShuttleTooltips();',
'    ',
'    // Initialize after shuttle changes',
'    $("#P460_CARD_SHUTTLE").on("shuttlechange", function() {',
'        setTimeout(initializeShuttleTooltips, 100);',
'    });',
'    ',
'    // Handle dynamic page refreshes',
'    apex.jQuery(document).on("apexafterrefresh", function(e, data) {',
'        if (data && data.targetId === "P460_CARD_SHUTTLE") {',
'            setTimeout(initializeShuttleTooltips, 100);',
'        }',
'    });',
'    ',
'    // P460_CARD_SHUTTLE for dynamic content',
'    $(document).on(''mouseenter'', ''#P460_CARD_SHUTTLE option'', function() {',
'        if (!$(this).attr(''title'')) {',
'            $(this).attr(''title'', $(this).text());',
'        }',
'    });',
'});',
'',
'',
'',
'',
'',
'initializeAllCards();',
'',
'',
'',
'// Check if we have saved card data from a loaded profile',
'if ($v(''P460_SAVED_CARD_COUNTRIES'') && $v(''P460_SAVED_CARD_NUMBERS'')) {',
'    console.log("Saved card data found, restoring profile");',
'    // Call function to restore cards',
'    restoreCardsFromProfile();',
'',
'',
'}',
'',
'if ($v(''P460_REFRESH_CARDS'') === ''Y'') {',
'    console.log("Refreshing cards due to loaded profile");',
'',
'    refreshcard();',
'',
'    $s(''P460_REFRESH_CARDS'', ''N'');',
'}'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/***********************',
' * Button Styles',
' ***********************/',
'/* Gradient Button Styling for Filter */',
'button#B501317057147707225 {',
'    background: linear-gradient(90deg, #bb0a31 0%, #d01a45 50%, #bb0a31 100%); ',
'    color: white; ',
'    padding: 8px 12px;',
'    border: none; ',
'    border-radius: 2px; ',
'    font-size: 12px; ',
'    cursor: pointer; ',
'    transition: background 0.3s ease-in-out; ',
'    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2); ',
'}',
'',
'button#B501317057147707225:hover {',
'    background: linear-gradient(90deg, #d01a45 0%, #e02b55 50%, #d01a45 100%); ',
'    box-shadow: 0 6px 8px rgba(0, 0, 0, 0.3);',
'}',
'',
'/***********************',
' * Message Styles',
' ***********************/',
'/* No Data Found Message */',
'.no-data-message {',
'    background-color: #f5f5f5;',
'    color: #404040;',
'    padding: 8px 12px;',
'    font-family: ''Segoe UI'', Arial, sans-serif;',
'    border-left: 3px solid #bb0a31;',
'    margin: 10px 0;',
'    font-size: 14px;',
'    line-height: 1.4;    ',
'}',
'',
'.highlight {',
'    color: #d60c38;',
'}',
'',
'/***********************',
' * Region Height Settings',
' ***********************/',
'/* ',
'.heightclass { ',
'    min-height: 250px;',
'    max-height: 697px; ',
'    overflow: auto;',
'} ',
'*/',
'',
'/***********************',
' * Custom Alert Styles ',
' ***********************/',
'/* ',
'.custom-alert {',
'    margin: 4px 0;',
'    padding: 6px 8px;',
'    background-color: #fff3e0;',
'    border-left: 3px solid #bb0a31;',
'    font-size: 13px;',
'    font-family: "Audi Type", sans-serif;',
'}',
'',
'.alert-content {',
'    display: flex;',
'    align-items: center;',
'    gap: 8px;',
'}',
'',
'.alert-icon {',
'    color: #bb0a31;',
'    font-size: 12px;',
'    flex-shrink: 0;',
'}',
'',
'.alert-text {',
'    line-height: 1.3;',
'}',
'*/',
'',
'/***********************',
' * Report Cell Styles',
' ***********************/',
'/*',
'.t-Report-cell {',
'    background-color: #E0E0E0;',
'}',
'*/',
'',
'/***********************',
' * Region Height Override',
' ***********************/',
'/*',
'#R43543646345346 {',
'    height: 700px;',
'    overflow-y: auto;',
'}',
'*/',
'',
'/***********************',
' * Checkbox and Popup Styles',
' ***********************/',
'.apex-item-single-checkbox input:checked+.u-checkbox:after, ',
'.apex-item-single-checkbox input:checked+label:after, ',
'.u-checkbox.is-checked:after {',
'    opacity: 1;',
'    background-color: #bb0a31;',
'}',
'',
'.apex-item-single-checkbox {',
'    margin-top: 13px;',
'}',
'',
'.a-PopupLOV-clearButton:hover {',
'    background-color: #bb0a31;',
'}',
'',
'/***********************',
' * Card Layout Styles',
' ***********************/',
'.cards-region .card-container {',
'    transition: background-color 0.3s ease;',
'    margin-bottom: 16px;',
'    border: 1px solid #e0e0e0;',
'    border-radius: 8px;',
'    box-shadow: 0 2px 4px rgba(0,0,0,0.1);',
'    position: relative;',
'}',
'',
'.cards-region .card-container .header-container {',
'    display: flex;',
'    justify-content: space-between;',
'    align-items: center;',
'    background-color: #f5f5f5;',
'    padding: 12px;',
'    border-radius: 6px;',
'    gap: 8px;',
'    flex-wrap: nowrap;',
'}',
'',
'.cards-region .card-container .country-name {',
'    font-size: 16px;',
'    color: #333;',
'    font-family: "Audi Type", "Helvetica Neue", Helvetica, Arial, sans-serif;',
'    flex-grow: 1;',
'    white-space: pre-line;',
'    word-break: break-word;',
'    overflow-wrap: break-word;',
'    min-width: 0;',
'    margin-right: 8px;',
'}',
'',
'/***********************',
' * Download Icon Styles',
' ***********************/',
'/* .download-icon {',
'    cursor: pointer;',
'    background-color: #bb0a31;',
'    color: white;',
'    padding: 8px;',
'    border-radius: 50%;',
'    width: 32px;',
'    height: 32px;',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    margin-left: auto;',
'    flex-shrink: 0;',
'    transition: all 0.2s ease;',
'}',
'',
'.download-icon:hover {',
'    background-color: #d01a45;',
'    transform: scale(1.1);',
'} */',
'',
'',
'',
'.download-icon {',
'    display: inline-flex;',
'    align-items: center;',
'    justify-content: center;',
'    width: 28px;',
'    height: 28px;',
'    border-radius: 50%;',
'    margin-left: 8px;',
'    cursor: pointer;',
'    transition: all 0.3s ease;',
'    box-shadow: 0 2px 4px rgba(0,0,0,0.2);',
'    border: 2px solid #ddd;',
'    background-color: #f5f5f5;',
'    color: #666;',
'}',
'',
'.download-icon:hover {',
'    transform: scale(1.1);',
'    box-shadow: 0 3px 6px rgba(0,0,0,0.3);',
'    background-color: #bb0a31;',
'    color: white;',
'    border-color: #d01a45;',
'}',
'',
'.download-icon .fa-download-alt {',
'    font-size: 14px;',
'    transition: transform 0.3s ease;',
'}',
'',
'.download-icon:hover .fa-download-alt {',
'    transform: rotate(15deg);',
'}',
'',
'',
'/***********************',
' * Report and Table Styles',
' ***********************/',
'.t-Report {',
'    margin-top: 12px;',
'}',
'',
'.t-Report-colHead {',
'    transition: background-color .2s;',
'    background-color: #fafafa;',
'    padding: 12px 8px;',
'    height: 40px;',
'    text-align: center;',
'}',
'',
'.t-Report-cell {',
'    padding: 8px 12px;',
'    height: 32px;',
'    text-align: center;',
'}',
'',
'.t-Report-report {',
'    width: 100%;',
'    table-layout: fixed;',
'}',
'',
'.a-CardView {',
'    border: none;',
'}',
'',
'.a-CardView-items {',
'    gap: 0px !important;',
'}',
'',
'/***********************',
' * Alert Confirmation Styles',
' ***********************/',
'.a-AlertMessage {',
'    padding-left: 20px;',
'    padding-right: 20px;',
'    padding-bottom: 20px;',
'}',
'',
'.delete_confirm {',
'    cursor: pointer;',
'}',
'',
'',
'/* Sticky Headers */',
'.fixed-table-header {',
'    position: sticky;',
'    top: 0;',
'    background-color: #fafafa;',
'    z-index: 10;',
'    box-shadow: 0 1px 3px rgba(0,0,0,0.1);',
'}',
'',
'',
'',
'.t-Report-colHead {',
'    position: sticky;',
'    top: 0;',
'    z-index: 10;',
'    background-color: #fafafa;',
'    box-shadow: 0 1px 3px rgba(0,0,0,0.1);',
'}',
'',
'.t-Report-tableWrap {',
'    max-height: 500px;',
'    overflow-y: auto;',
'}',
'',
'',
'',
'/***************************',
' * Status indicator styles',
' ***************************/',
'',
'.status-indicator {',
'    display: inline-flex;',
'    align-items: center;',
'    justify-content: center;',
'    width: 28px;',
'    height: 28px;',
'    border-radius: 50%;',
'    margin-left: 8px;',
'    cursor: pointer;',
'    transition: all 0.3s ease;',
'    box-shadow: 0 2px 4px rgba(0,0,0,0.2);',
'    border: 2px solid #ddd;',
'}',
'',
'.status-indicator.not-started {',
'    background-color: #e8f5e9;',
'    border: 2px solid #c8e6c9;',
'    color: #388e3c;',
'}',
'',
'.status-indicator.in-progress {',
'    background-color: #f39c12;',
'    color: white;',
'    border: 2px solid #e67e22;',
'}',
'',
'.status-indicator.completed {',
'    background-color: #2ecc71;',
'    color: white;',
'    border: 2px solid #27ae60;',
'}',
'',
'.status-indicator:hover {',
'    transform: scale(1.1);',
'    box-shadow: 0 3px 6px rgba(0,0,0,0.3);',
'}',
'',
'',
'/***************************',
' * Edit Card Title',
' ***************************/',
'',
'.title-container {',
'    display: flex;',
'    align-items: center;',
'    flex-grow: 1;',
'    overflow: hidden;',
'}',
'',
'.edit-icon, .save-icon {',
'    cursor: pointer;',
'    padding: 4px;',
'    margin-right: 4px;',
'    border-radius: 50%;',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    background-color: #f5f5f5;',
'    width: 24px;',
'    height: 24px;',
'    transition: all 0.2s;',
'}',
'',
'.edit-icon:hover, .save-icon:hover {',
'    background-color: #e0e0e0;',
'    transform: scale(1.1);',
'}',
'',
'.country-name {',
'    flex-grow: 1;',
'    overflow: hidden;',
'    text-overflow: ellipsis;',
'    white-space: nowrap;',
'}',
'',
'',
'.reset-icon {',
'    cursor: pointer;',
'    padding: 4px;',
'    margin-right: 4px;',
'    border-radius: 50%;',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    background-color: #f5f5f5;',
'    width: 24px;',
'    height: 24px;',
'    transition: all 0.2s;',
'}',
'',
'.reset-icon:hover {',
'    background-color: #e0e0e0;',
'    transform: scale(1.1);',
'}',
'',
'',
'',
'',
'',
'',
'',
'/**********************************************************',
' * Go from Page 460 to 461 using Expand or Collapse Icon',
' **********************************************************/',
'',
'.view-full-button {',
'    display: inline-flex;',
'    align-items: center;',
'    justify-content: center;',
'    width: 28px;',
'    height: 28px;',
'    border-radius: 50%;',
'    margin-left: 8px;',
'    cursor: pointer;',
'    transition: all 0.3s ease;',
'    box-shadow: 0 2px 4px rgba(0,0,0,0.2);',
'    border: 2px solid #ddd;',
'    background-color: #f5f5f5;',
'    color: #666;',
'}',
'',
'.view-full-button:hover {',
'    transform: scale(1.1);',
'    box-shadow: 0 3px 6px rgba(0,0,0,0.3);',
'    /* background-color: #bb0a31; */',
'    color: white;',
'    border-color: #d01a45;',
'}',
'',
'.view-full-button .fa-expand {',
'    font-size: 14px;',
'    transition: transform 0.3s ease;',
'}',
'',
'.view-full-button:hover .fa-expand {',
'    transform: rotate(15deg);',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* CSS Styles */',
'',
'',
'.cards-region .card-container {',
'    transition: background-color 0.3s ease;',
'    margin-bottom: 16px;',
'    border: 1px solid #e0e0e0;',
'    border-radius: 8px;',
'    box-shadow: 0 2px 4px rgba(0,0,0,0.1);',
'    position: relative;',
'}',
'',
'.cards-region .card-container .header-container {',
'    display: flex;',
'    justify-content: space-between;',
'    align-items: center;',
'    background-color: #f5f5f5;',
'    padding: 12px;',
'    border-radius: 6px;',
'    gap: 8px;',
'    flex-wrap: nowrap;',
'}',
'',
'.cards-region .card-container .country-name {',
'    font-size: 16px;',
'    color: #333;',
'    font-family: "Audi Type", "Helvetica Neue", Helvetica, Arial, sans-serif;',
'    flex-grow: 1;',
'    white-space: pre-line;',
'    word-break: break-word;',
'    overflow-wrap: break-word;',
'    min-width: 0;',
'    margin-right: 8px;',
'}',
'',
'',
'',
'',
'',
'.download-icon {',
'    cursor: pointer;',
'    background-color: #bb0a31;',
'    color: white;',
'    padding: 8px;',
'    border-radius: 50%;',
'    width: 32px;',
'    height: 32px;',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    margin-left: auto;',
'    flex-shrink: 0;',
'    transition: all 0.2s ease;',
'}',
'',
'.download-icon:hover {',
'    background-color: #d01a45 ; /*#99082a*/',
'    transform: scale(1.1);',
'}',
'',
'.t-Report {',
'    margin-top: 12px;',
'}',
'',
'.t-Report-colHead {',
'    transition: background-color .2s;',
'    background-color: #fafafa;',
'}',
'',
'.a-CardView {',
'    border: none;',
'}',
'',
'.a-CardView-items {',
'    gap: 0px !important;',
'}',
'',
'',
'/* Table Cell Styles */',
'.t-Report-cell {',
'    padding: 8px 12px;',
'    height: 32px;',
'    text-align: center;',
'}',
'',
'/* Report Table Styles */',
'.t-Report-report {',
'    width: 100%;',
'    table-layout: fixed;',
'}',
'',
'/* Report Header Styles */',
'.t-Report-colHead {',
'    padding: 12px 8px;',
'    height: 40px;',
'    text-align: center;',
'}',
'',
''))
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540063104747099848)
,p_plug_name=>'Filtersuche'
,p_region_name=>'FilterSuche'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>6
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6125654821655513204)
,p_plug_name=>unistr('Box Vorfilter L\00E4nder')
,p_parent_plug_id=>wwv_flow_imp.id(540063104747099848)
,p_region_template_options=>'#DEFAULT#:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>80
,p_plug_grid_column_span=>4
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6125655760058515141)
,p_plug_name=>unistr('Box Filter L\00E4nder')
,p_parent_plug_id=>wwv_flow_imp.id(540063104747099848)
,p_region_template_options=>'#DEFAULT#:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540061366066099831)
,p_plug_name=>unistr('Filter L\00E4nder - Vorschriften')
,p_region_name=>'FilterLaenderVorschriften'
,p_region_css_classes=>'cards-regions'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540062171405099839)
,p_plug_name=>'All Countries Results'
,p_parent_plug_id=>wwv_flow_imp.id(540061366066099831)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2707059584407204267)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540061161446099829)
,p_plug_name=>'Reports'
,p_region_name=>'Reports'
,p_parent_plug_id=>wwv_flow_imp.id(540061366066099831)
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>40
,p_plug_grid_column_span=>4
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH search_countries AS (',
'    SELECT ',
'        sucheid,',
'        to_number(COLUMN_VALUE) as landid',
'    FROM t_suche_json,',
'    TABLE(apex_string.split(',
'        json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'        '':''',
'    ))',
'    where ',
'    sucheid = :P19_SEARCH_SELECTION  -- Search Selection check',
'   and BENUTZERID = :G_BENUTZERID',
')',
'SELECT DISTINCT',
'    sc.sucheid,   ',
'    ms.VORSCHRIFTID,      ',
'    ms.landnummer||'' - ''||ms.landbezeichnung AS Landbezeichnung,   ',
'    ms.vorschriftnummer as Vorschriftennummer',
'    ',
'',
'FROM search_countries sc',
'LEFT JOIN T_MS_SUCHERGEBNISS ms ON (',
'    ms.sucheid = sc.sucheid ',
'    AND ms.landid = sc.landid',
'     AND ms.meilenstein = :P19_MILESTONE_SELECTION  ',
'    and  sc.landid not in (select column_value from table(apex_string.split_numbers(:P19_FILTER_LAND, '':'')))',
'     AND sc.LANDID NOT IN (SELECT LANDID FROM T_MS_SUCHE_SPLIT WHERE BENUTZERID=:G_BENUTZERID AND SUCHEID	=:P19_SEARCH_SELECTION AND MEILENSTEIN =:P19_MILESTONE_SELECTION )',
')',
'where VORSCHRIFTID is not null ',
'',
'GROUP BY ',
'    ms.vorschriftnummer,',
'    ms.VORSCHRIFTID,',
'    ms.landnummer,',
'    ms.landbezeichnung,',
'    sc.sucheid',
'ORDER BY ',
'    Landbezeichnung,   ',
'    Vorschriftennummer; '))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P19_FILTER_LAND,P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Reports'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH search_countries AS (',
'    SELECT ',
'        sucheid,',
'        to_number(COLUMN_VALUE) as landid',
'    FROM t_suche_json,',
'    TABLE(apex_string.split(',
'        json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'        '':''',
'    ))',
'    where BENUTZERID = :G_BENUTZERID',
')',
'SELECT DISTINCT',
'    sc.sucheid,   ',
'    ms.VORSCHRIFTID,      ',
'    ms.landnummer||'' - ''||ms.landbezeichnung AS Landbezeichnung,   ',
'    ms.vorschriftnummer as Vorschriftennummer',
'    ',
'',
'FROM search_countries sc',
'LEFT JOIN T_MS_SUCHERGEBNISS ms ON (',
'    ms.sucheid = sc.sucheid ',
' AND',
'     ms.landid = sc.landid',
'    and  sc.landid not in (select column_value from table(apex_string.split_numbers(:P460_FILTER_LAND, '':'')))',
')',
'where VORSCHRIFTID is not null ',
'',
'GROUP BY ',
'    ms.vorschriftnummer,',
'    ms.VORSCHRIFTID,',
'    ms.landnummer,',
'    ms.landbezeichnung,',
'    sc.sucheid',
'ORDER BY ',
'    Landbezeichnung,   ',
'    Vorschriftennummer; '))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(540059553074099813)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="no-data-message">',
unistr('    Es wurden <span class="highlight">keine</span> Vorschriftsnummern f\00FCr diese L\00E4nder gefunden. Bitte planen Sie die erforderlichen L\00E4nder.'),
'',
'</div>'))
,p_max_rows_per_page=>'15'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>3132152762825288422
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1041364039892806892)
,p_db_column_name=>'SUCHEID'
,p_display_order=>10
,p_column_identifier=>'I'
,p_column_label=>'Sucheid'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1041364870772806897)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Vorschriftid'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1041364445618806893)
,p_db_column_name=>'LANDBEZEICHNUNG'
,p_display_order=>30
,p_column_identifier=>'E'
,p_column_label=>'Landbezeichnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1041363647520806891)
,p_db_column_name=>'VORSCHRIFTENNUMMER'
,p_display_order=>40
,p_column_identifier=>'K'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1549049138854946242)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'25904279'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'LANDBEZEICHNUNG:VORSCHRIFTENNUMMER:'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1560136779615164952)
,p_name=>'Cards - CR'
,p_region_name=>'2590421933418752847'
,p_parent_plug_id=>wwv_flow_imp.id(540061366066099831)
,p_template=>wwv_flow_imp.id(3414123643808820547)
,p_display_sequence=>90
,p_region_css_classes=>'heightclass'
,p_region_sub_css_classes=>'card_icon'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--basic:t-Cards--displayIcons:t-Cards--3cols:t-Cards--animColorFill'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH selected_countries AS (',
'    SELECT ',
'        LISTAGG(l.B_NUMMER||'' - ''||l.LAND, ''; '') ',
'        WITHIN GROUP (ORDER BY l.B_NUMMER) as country_list,',
'        LISTAGG(tms.landid,'':'') ',
'        WITHIN GROUP (ORDER BY tms.landid) as landids,',
'        tms.card_number,',
'        TMS.meilenstein,',
'        tms.SUCHEID,',
'        -- Original DB count',
'        (SELECT COUNT(DISTINCT ms.vorschriftnummer)',
'         FROM T_MS_SUCHERGEBNISS ms',
'         WHERE ms.landid IN (',
'            SELECT tms2.landid ',
'            FROM T_MS_SUCHE_SPLIT tms2 ',
'            WHERE tms2.card_number = tms.card_number',
'            AND tms2.BENUTZERID = :G_BENUTZERID ',
'            AND tms2.SUCHEID = :P19_SEARCH_SELECTION ',
'            AND tms2.MEILENSTEIN = :P19_MILESTONE_SELECTION',
'         )',
'         AND ms.sucheid = :P19_SEARCH_SELECTION',
'         AND ms.meilenstein = :P19_MILESTONE_SELECTION',
'        ) as db_count',
'  ',
'    FROM t_land l',
'    join T_MS_SUCHE_SPLIT tms on (l.LANDID = tms.LANDID)',
'    where tms.BENUTZERID=:G_BENUTZERID ',
'    AND tms.SUCHEID=:P19_SEARCH_SELECTION ',
'    AND tms.MEILENSTEIN =:P19_MILESTONE_SELECTION',
'    group by tms.card_number,tms.SUCHEID,TMS.meilenstein',
')',
'',
'SELECT ',
'    sc.country_list || ''DB: ('' || NVL(sc.db_count,0) || '')''  as card_title,',
'    ''<style> .t-Card-icon, .t-Icon.fa-download-alt { cursor: pointer; } </style>'' ||',
'    ''<div data-landids="'' || sc.landids || ''" '' ||',
'    ''data-row-count="'' || sc.db_count || ''" '' || ',
'    ''class="downloadArea" title="Download '' || REPLACE(sc.country_list, '''''''', '''') || '' in Excel">'' ||',
'  --  COUNTRY_VORSCHRIFT_CARD_DETAIL(sc.landids, :G_BENUTZERID) ||',
'  country_vorschrift_card_detail(p_search_id =>:P19_SEARCH_SELECTION, p_milestone =>:P19_MILESTONE_SELECTION, P_LANDID =>sc.landids)||',
'    ''</div>'' AS card_text,',
'    null as card_subtext,',
'    null as card_link,',
'    null as card_icon_link,',
'    ''fa-download-alt'' as card_icon',
'FROM selected_countries sc',
''))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3414129911996820551)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_more_data=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_query_num_rows_type=>'ROW_RANGES'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'2590421933418752847',
'WITH selected_countries AS (',
'    SELECT ',
'        LISTAGG(l.B_NUMMER||'' - ''||l.LAND, ''; '') ',
'        WITHIN GROUP (ORDER BY l.B_NUMMER) as country_list,',
'        LISTAGG(tms.landid,'':'') ',
'        WITHIN GROUP (ORDER BY tms.landid) as landids,',
'        tms.card_number,',
'        COUNT(*) as row_count',
'    FROM t_land l',
'    join T_MS_SUCHE_SPLIT tms  on ( l.LANDID = tms.LANDID)',
'  where tms.BENUTZERID=:G_BENUTZERID AND tms.SUCHEID=:P460_SEARCH_SELECTION AND tms.MEILENSTEIN =:P460_MILESTONE_SELECTION',
'--    AND TMS.landid IN (',
'--             SELECT column_value ',
'--             FROM TABLE(apex_string.split_numbers(:P460_FILTER_LAND, '':''))',
'--         )',
'  group by tms.card_number',
'',
')',
'SELECT ',
'    -- sc.country_list as card_title,',
'    sc.country_list || '' count: ('' || sc.row_count || '')'' as card_title,',
'    COUNTRY_VORSCHRIFT_CARD_DETAIL(sc.landids, :G_BENUTZERID) AS card_text, -- ''1011:1015''',
'    null as card_subtext,',
'    -- ''count: '' || sc.row_count as card_subtext,',
'    ',
'    -- NULL as card_link,',
'    -- ''javascript:downloadCardData('''''' || sc.landids || '''''');'' as card_icon,',
'    -- ''fa-download-alt'' as card_icon_class',
'    ',
'    ',
'    -- ''javascript:downloadCardData('''''' || sc.landids || '''''');'' as card_link,',
'    -- ''fa-download-alt'' as card_icon',
'',
'null as card_link,',
'    ''javascript:downloadCardData('''''' || sc.landids || '''''')'' as card_icon_link,',
'    ''fa-download'' as card_icon',
'',
'    ',
'',
'',
'',
'FROM selected_countries sc',
'--order by CARD_NUMBER asc',
'',
'',
'',
'',
'-- working query ',
'',
'',
'WITH selected_countries AS (',
'    SELECT ',
'        LISTAGG(l.B_NUMMER||'' - ''||l.LAND, ''; '') ',
'        WITHIN GROUP (ORDER BY l.B_NUMMER) as country_list,',
'        LISTAGG(tms.landid,'':'') ',
'        WITHIN GROUP (ORDER BY tms.landid) as landids,',
'        tms.card_number,',
'        COUNT(*) as row_count',
'    FROM t_land l',
'    join T_MS_SUCHE_SPLIT tms  on ( l.LANDID = tms.LANDID)',
'    where tms.BENUTZERID=:G_BENUTZERID ',
'    AND tms.SUCHEID=:P460_SEARCH_SELECTION ',
'    AND tms.MEILENSTEIN =:P460_MILESTONE_SELECTION',
'    group by tms.card_number',
')',
'SELECT ',
'    sc.country_list as card_title,',
'    -- Store landids in the card detail HTML with style for hover',
'    ''<style> .t-Card-icon, .t-Icon.fa-download { cursor: pointer; } </style>'' ||',
'    ''<div data-landids="'' || sc.landids || ''">'' ||',
'    COUNTRY_VORSCHRIFT_CARD_DETAIL(sc.landids, :G_BENUTZERID) ||',
'    ''</div>'' AS card_text,',
'    -- sc.landids as card_subtext,',
'    null as card_subtext,',
'    null as card_link,',
'    null as card_icon_link,',
'    ''fa-download-alt'' as card_icon',
'FROM selected_countries sc',
'',
'',
'',
'--- cotn working correctly . ',
'',
'',
'WITH selected_countries AS (',
'    SELECT ',
'        MIN(l.B_NUMMER||'' - ''||l.LAND) as country_name,',
'        tms.card_number,',
'        LISTAGG(tms.landid,'':'') WITHIN GROUP (ORDER BY tms.landid) as landids,',
'        COUNT(DISTINCT ms.VORSCHRIFTID) as row_count',
'    FROM t_land l',
'    join T_MS_SUCHE_SPLIT tms on (l.LANDID = tms.LANDID)',
'    LEFT JOIN T_MS_SUCHERGEBNISS ms ON (',
'        ms.landid = tms.landid',
'        AND ms.sucheid = tms.sucheid',
'        AND ms.meilenstein = tms.meilenstein',
'        AND ms.VORSCHRIFTID IS NOT NULL',
'    )',
'    where tms.BENUTZERID=:G_BENUTZERID ',
'    AND tms.SUCHEID=:P460_SEARCH_SELECTION ',
'    AND tms.MEILENSTEIN =:P460_MILESTONE_SELECTION',
'    group by tms.card_number, tms.sucheid, tms.meilenstein',
')',
'SELECT ',
'    sc.country_name  || '' count: ('' || sc.row_count || '')'' as card_title,',
'    ''<style> .t-Card-icon, .t-Icon.fa-download-alt { cursor: pointer;  } </style>'' ||   -- color: #bb0a31;',
'    ''<div data-landids="'' || sc.landids || ''">'' ||',
'    COUNTRY_VORSCHRIFT_CARD_DETAIL(sc.landids, :G_BENUTZERID) ||',
'    ''</div>'' AS card_text,',
'    null as card_subtext,',
'    null as card_link,',
'    null as card_icon_link,',
'    ''fa-download-alt'' as card_icon',
'FROM selected_countries sc',
'',
''))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1041369175269806918)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Card Title'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1041368724509806917)
,p_query_column_id=>2
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>20
,p_column_heading=>'Card Text'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1041367134903806915)
,p_query_column_id=>3
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>60
,p_column_heading=>'Card Subtext'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1041368384847806916)
,p_query_column_id=>4
,p_column_alias=>'CARD_LINK'
,p_column_display_sequence=>30
,p_column_heading=>'Card Link'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1041367595351806916)
,p_query_column_id=>5
,p_column_alias=>'CARD_ICON_LINK'
,p_column_display_sequence=>50
,p_column_heading=>'Card Icon Link'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1041367974297806916)
,p_query_column_id=>6
,p_column_alias=>'CARD_ICON'
,p_column_display_sequence=>40
,p_column_heading=>'Card Icon'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1560139926880164983)
,p_plug_name=>'Cards'
,p_region_name=>'R43543646345346'
,p_parent_plug_id=>wwv_flow_imp.id(540061366066099831)
,p_region_css_classes=>'cards-region'
,p_region_template_options=>'#DEFAULT#:margin-top-none'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH selected_countries AS (',
'    SELECT ',
'        sc.card_number,',
'        sc.landids',
'    FROM (',
'        SELECT ',
'            tms.card_number,',
'            LISTAGG(tms.landid, '':'') WITHIN GROUP (ORDER BY l.B_NUMMER) AS landids',
'        FROM t_land l',
'        JOIN T_MS_SUCHE_SPLIT tms ON (l.LANDID = tms.LANDID)',
'        WHERE tms.BENUTZERID = :G_BENUTZERID',
'        AND tms.SUCHEID = :P19_SEARCH_SELECTION',
'        AND tms.MEILENSTEIN = :P19_MILESTONE_SELECTION',
'        GROUP BY tms.card_number',
'    ) sc',
')',
'SELECT ',
'    ''<div class="card-container" data-cardnum="'' || sc.card_number || ''">'' ||',
'    ''<div id="card_'' || sc.card_number || ''" class="card-placeholder" '' ||',
'    ''data-card="'' || sc.card_number || ''" '' ||',
'    ''data-landids="'' || sc.landids || ''">&nbsp;</div>'' ||  -- Loading card content...',
'    ''</div>'' AS card_text,',
'    NULL AS card_subtext,',
'    NULL AS card_link,',
'    NULL AS card_icon_link,',
'    NULL AS card_icon',
'FROM selected_countries sc;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="no-data-message">',
unistr('    Es wurden <span class="highlight">keine</span> Vorschriftsnummern f\00FCr diese L\00E4nder gefunden. Bitte planen Sie die erforderlichen L\00E4nder.'),
'</div>'))
,p_show_total_row_count=>true
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'R43543646345346',
'',
'WITH selected_countries AS (',
'    SELECT ',
'        sc.card_number,',
'        sc.landids',
'    FROM (',
'        SELECT ',
'            tms.card_number,',
'            LISTAGG(tms.landid, '':'') WITHIN GROUP (ORDER BY l.B_NUMMER) AS landids',
'        FROM t_land l',
'        JOIN T_MS_SUCHE_SPLIT tms ON (l.LANDID = tms.LANDID)',
'        WHERE tms.BENUTZERID = :G_BENUTZERID',
'        AND tms.SUCHEID = :P460_SEARCH_SELECTION',
'        AND tms.MEILENSTEIN = :P460_MILESTONE_SELECTION',
'        GROUP BY tms.card_number',
'    ) sc',
')',
'SELECT ',
'    ''<div class="card-container" data-cardnum="'' || sc.card_number || ''">'' ||',
'    ''<div id="card_'' || sc.card_number || ''" class="card-placeholder" '' ||',
'    ''data-card="'' || sc.card_number || ''" '' ||',
'    ''data-landids="'' || sc.landids || ''">&nbsp;</div>'' ||  -- Loading card content...',
'    ''</div>'' AS card_text,',
'    NULL AS card_subtext,',
'    NULL AS card_link,',
'    NULL AS card_icon_link,',
'    NULL AS card_icon',
'FROM selected_countries sc;',
'',
'',
'R43543646345346',
'',
'',
'&CARD_TITLE!RAW.',
'',
'',
'cards-region',
'',
'',
''))
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(1041366462296806913)
,p_region_id=>wwv_flow_imp.id(1560139926880164983)
,p_layout_type=>'GRID'
,p_grid_column_count=>2
,p_title_adv_formatting=>false
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>'&CARD_TEXT!RAW.'
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1560329416772218058)
,p_plug_name=>'Cards-1 - Original but see in comments'
,p_parent_plug_id=>wwv_flow_imp.id(540061366066099831)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH selected_countries AS (',
'    SELECT ',
'        LISTAGG(l.B_NUMMER||'' - ''||l.LAND, ''; '') ',
'        WITHIN GROUP (ORDER BY l.B_NUMMER) as country_list,',
'        LISTAGG(tms.landid,'':'') ',
'        WITHIN GROUP (ORDER BY l.B_NUMMER) as landids,',
'        tms.card_number,',
'        tms.meilenstein,',
'        tms.SUCHEID,',
'        (SELECT COUNT(DISTINCT ms.vorschriftnummer)',
'         FROM T_MS_SUCHERGEBNISS ms',
'         WHERE ms.landid IN (',
'            SELECT tms2.landid ',
'            FROM T_MS_SUCHE_SPLIT tms2 ',
'            WHERE tms2.card_number = tms.card_number',
'            AND tms2.BENUTZERID = :G_BENUTZERID ',
'            AND tms2.SUCHEID = :P19_SEARCH_SELECTION ',
'            AND tms2.MEILENSTEIN = :P19_MILESTONE_SELECTION',
'         )',
'         AND ms.sucheid = :P19_SEARCH_SELECTION',
'         AND ms.meilenstein = :P19_MILESTONE_SELECTION',
'        ) as regulations_count',
'    FROM t_land l',
'    JOIN T_MS_SUCHE_SPLIT tms ON (l.LANDID = tms.LANDID)',
'    WHERE tms.BENUTZERID = :G_BENUTZERID ',
'    AND tms.SUCHEID = :P19_SEARCH_SELECTION ',
'    AND tms.MEILENSTEIN = :P19_MILESTONE_SELECTION',
'    GROUP BY tms.card_number, tms.SUCHEID, tms.meilenstein',
')',
'',
'',
'SELECT ',
'    -- sc.country_list || '' - '' || NVL(sc.regulations_count, 0)  as card_title,',
'    ''<div style="font-size: 20px; color: #333; font-family: &quot;Audi Type&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;">'' ||',
'    sc.country_list || '' - '' || NVL(sc.regulations_count, 0) ||',
'    ''</div>'' as card_title,',
'',
'    ''<div class="t-Report t-Report--altRowsDefault t-Report--rowHighlight">',
'        <div class="t-Report-wrap">',
'            <div class="t-Report-tableWrap">',
'                <table class="t-Report-report" summary="Report">',
'                    <thead>',
'                        <tr>',
'                            <th class="t-Report-colHead" align="center" style="padding: 12px 8px; height: 40px;">',
'                                <span class="u-Report-sortHeading">Vorschriftennummer</span>',
'                            </th>',
'                        </tr>',
'                    </thead>',
'                    <tbody>'' ||',
'                    ',
'                    country_vorschrift_card_detail(',
'                        p_search_id => :P19_SEARCH_SELECTION, ',
'                        p_milestone => :P19_MILESTONE_SELECTION, ',
'                        P_LANDID => sc.landids',
'                    ) ||',
'                    ''</tbody>',
'                </table>',
'            </div>',
'        </div>',
'    </div>'' AS card_text,',
'    null as card_subtext,',
'    null as card_link,',
'    null as card_icon_link,',
'    null as card_icon ',
'FROM selected_countries sc;',
'',
'',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'NEVER'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace FUNCTION country_vorschrift_card_detail(',
'    p_search_id number, ',
'    p_milestone number, ',
'    P_LANDID VARCHAR2,',
'    p_format IN VARCHAR2 DEFAULT ''DISPLAY'' ',
') RETURN CLOB',
'AS',
'    l_body_html_table CLOB;',
'    l_row_num NUMBER := 0;',
'BEGIN',
'    IF p_format = ''DISPLAY'' THEN',
'        l_body_html_table := '''';',
'                        ',
'        FOR i IN (',
'            WITH search_countries AS (',
'                SELECT ',
'                    sucheid,',
'                    to_number(COLUMN_VALUE) as landid',
'                FROM t_suche_json,',
'                TABLE(apex_string.split(',
'                    json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                    '':''',
'                ))',
'                WHERE sucheid = p_search_id',
'            )',
'            SELECT DISTINCT',
'                ms.vorschriftnummer AS r',
'            FROM search_countries sc',
'            LEFT JOIN T_MS_SUCHERGEBNISS ms ON (',
'                ms.sucheid = sc.sucheid ',
'                AND ms.landid = sc.landid',
'                AND sc.landid IN (',
'                    SELECT column_value ',
'                    FROM table(apex_string.split_numbers(P_LANDID, '':''))',
'                )',
'            )',
'            WHERE vorschriftnummer IS NOT NULL ',
'            AND ms.MEILENSTEIN = p_milestone',
'            ORDER BY r',
'        ) LOOP',
'            l_row_num := l_row_num + 1;',
'            l_body_html_table := l_body_html_table || ',
'                ''<tr>'' ||',
'                ''<td class="t-Report-cell" headers="VORSCHRIFT" style="padding: 8px 12px; height: 32px; text-align: center;'' ||',
'                CASE ',
'                    WHEN MOD(l_row_num, 2) = 1 THEN '' background-color: #E0E0E0;''',
'                    ELSE ''''',
'                END || ''">'' || ',
'                i.r || ',
'                ''</td></tr>'';',
'        END LOOP;',
'        ',
'        RETURN l_body_html_table;',
'        ',
'    ELSIF p_format = ''EXCEL'' THEN',
'        RETURN q''[',
'            WITH search_countries AS (',
'                SELECT ',
'                    sucheid,',
'                    to_number(COLUMN_VALUE) as landid',
'                FROM t_suche_json,',
'                TABLE(apex_string.split(',
'                    json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                    '':''',
'                ))',
'                WHERE sucheid = ]'' || p_search_id || q''[',
'            )',
'            SELECT DISTINCT',
'                ms.landnummer||'' - ''||ms.landbezeichnung AS Landbezeichnung,',
'                ms.vorschriftnummer as Vorschriftennummer',
'            FROM search_countries sc',
'            JOIN T_MS_SUCHERGEBNISS ms ON (',
'                ms.sucheid = sc.sucheid ',
'                AND ms.landid = sc.landid',
'                AND ms.meilenstein = ]'' || p_milestone || q''[',
'                AND ms.landid IN (',
'                    SELECT TO_NUMBER(COLUMN_VALUE)',
'                    FROM TABLE(apex_string.split('']'' || P_LANDID || q''['', '':''))',
'                )',
'            )',
'            ORDER BY ',
'                Landbezeichnung,',
'                Vorschriftennummer]'';',
'    END IF;',
'END;'))
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(1041361917313806872)
,p_region_id=>wwv_flow_imp.id(1560329416772218058)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>true
,p_title_html_expr=>'&CARD_TITLE!RAW.'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>'&CARD_TEXT!RAW.'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'CARD_ICON'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1570718576886421746)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_imp.id(540061366066099831)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>70
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    FOR r IN (SELECT message_timestamp, message',
'              FROM apex_debug_messages',
'              WHERE session_id = v(''APP_SESSION'')',
'              ORDER BY message_timestamp DESC) LOOP',
'        HTP.P(TO_CHAR(r.message_timestamp, ''HH24:MI:SS'') || '': '' || r.message || ''<br>'');',
'    END LOOP;',
'END;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1573760883966919971)
,p_plug_name=>'Cards-10 Duplicate 22.02.2025 18:36 pm - Load dta and load card cotnent si diffrent '
,p_parent_plug_id=>wwv_flow_imp.id(540061366066099831)
,p_region_css_classes=>'cards-region'
,p_region_template_options=>'#DEFAULT#:margin-top-none'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH selected_countries AS (',
'    SELECT ',
'        sc.card_number,',
'        sc.landids',
'    FROM (',
'        SELECT ',
'            tms.card_number,',
'            LISTAGG(tms.landid, '':'') WITHIN GROUP (ORDER BY l.B_NUMMER) AS landids',
'        FROM t_land l',
'        JOIN T_MS_SUCHE_SPLIT tms ON (l.LANDID = tms.LANDID)',
'        WHERE tms.BENUTZERID = :G_BENUTZERID',
'        AND tms.SUCHEID = :P19_SEARCH_SELECTION',
'        AND tms.MEILENSTEIN = :P19_MILESTONE_SELECTION',
'        GROUP BY tms.card_number',
'    ) sc',
')',
'SELECT ',
'    ''<div class="card-container" data-cardnum="'' || sc.card_number || ''">'' ||',
'    ''<div id="card_'' || sc.card_number || ''" class="card-placeholder" '' ||',
'    ''data-card="'' || sc.card_number || ''" '' ||',
'    ''data-landids="'' || sc.landids || ''">&nbsp;</div>'' ||  -- Loading card content...',
'    ''</div>'' AS card_text,',
'    NULL AS card_subtext,',
'    NULL AS card_link,',
'    NULL AS card_icon_link,',
'    NULL AS card_icon',
'FROM selected_countries sc;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="no-data-message">',
unistr('    Es wurden <span class="highlight">keine</span> Vorschriftsnummern f\00FCr diese L\00E4nder gefunden. Bitte planen Sie die erforderlichen L\00E4nder.'),
'</div>'))
,p_show_total_row_count=>true
,p_plug_display_condition_type=>'NEVER'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'R43543646345346',
'',
'WITH selected_countries AS (',
'    SELECT ',
'        LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '' || chr(10)) WITHIN GROUP (ORDER BY l.B_NUMMER) AS country_list,',
'        LISTAGG(tms.landid, '':'') WITHIN GROUP (ORDER BY l.B_NUMMER) AS landids,',
'        tms.card_number,',
'        tms.meilenstein,',
'        tms.SUCHEID,',
'        (',
'            SELECT COUNT(DISTINCT ms.vorschriftnummer)',
'            FROM T_MS_SUCHERGEBNISS ms',
'            WHERE ms.landid IN (',
'                SELECT tms2.landid',
'                FROM T_MS_SUCHE_SPLIT tms2',
'                WHERE tms2.card_number = tms.card_number',
'                AND tms2.BENUTZERID = :G_BENUTZERID',
'                AND tms2.SUCHEID = :P460_SEARCH_SELECTION',
'                AND tms2.MEILENSTEIN = :P460_MILESTONE_SELECTION',
'            )',
'            AND ms.sucheid = :P460_SEARCH_SELECTION',
'            AND ms.meilenstein = :P460_MILESTONE_SELECTION',
'        ) AS regulations_count',
'    FROM t_land l',
'    JOIN T_MS_SUCHE_SPLIT tms ON (l.LANDID = tms.LANDID)',
'    WHERE tms.BENUTZERID = :G_BENUTZERID',
'    AND tms.SUCHEID = :P460_SEARCH_SELECTION',
'    AND tms.MEILENSTEIN = :P460_MILESTONE_SELECTION',
'    GROUP BY tms.card_number, tms.SUCHEID, tms.meilenstein',
')',
'',
'SELECT ',
'    ''<div class="card-container" data-cardnum="'' || sc.card_number || ''">'' ||',
'    ''<div class="header-container">'' ||',
'    ''<span class="country-name">'' ||',
'    sc.country_list ||',
'    ''</span>'' ||',
'    ''<span class="download-icon" onclick="downloadCardData('''''' || sc.landids || '''''')" '' ||',
unistr('    unistr(''title="Daten herunterladen f\00FCr '' || sc.country_list || ''">'') ||'),
'    ''<span class="fa fa-download-alt" style="font-size: 14px;"></span>'' ||',
'    ''</span>'' ||',
'    ''</div>'' ||',
'    ''<div class="t-Report t-Report--altRowsDefault t-Report--rowHighlight">'' ||',
'    ''<div class="t-Report-wrap">'' ||',
'    ''<div class="t-Report-tableWrap">'' ||',
'    ''<table class="t-Report-report" style="width: 100%; table-layout: fixed;" summary="Report">'' ||',
'    ''<thead>'' ||',
'    ''<tr>'' ||',
'    ''<th class="t-Report-colHead" align="center" style="padding: 12px 8px; height: 40px; text-align: center;">'' ||',
'    ''<span class="u-Report-sortHeading">Vorschriftennummer</span>'' ||',
'    ''</th>'' ||',
'    ''</tr>'' ||',
'    ''</thead>'' ||',
'    ''<tbody><div class="loaddata" searchid="'' || :P460_SEARCH_SELECTION || ''" milestone="'' || :P460_MILESTONE_SELECTION || ''" landid="'' || sc.landids || ''">loading</div></tbody>'' ||',
'    ''</table>'' ||',
'    ''</div>'' ||',
'    ''</div>'' ||',
'    ''</div>'' ||',
'    ''</div>'' AS card_text,',
'    NULL AS card_subtext,',
'    NULL AS card_link,',
'    NULL AS card_icon_link,',
'    NULL AS card_icon',
'FROM selected_countries sc;',
'',
'',
'',
'R43543646345346',
'',
'',
'&CARD_TITLE!RAW.',
'',
'',
'cards-region',
'',
'',
''))
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(1041365642221806912)
,p_region_id=>wwv_flow_imp.id(1573760883966919971)
,p_layout_type=>'GRID'
,p_grid_column_count=>4
,p_title_adv_formatting=>false
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>'&CARD_TEXT!RAW.'
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(514465462002129628)
,p_plug_name=>'Profile Configuration'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1561836742698118942)
,p_plug_name=>'Kartenverwaltung'
,p_region_name=>'Kartenverwaltung'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1561836776464118943)
,p_plug_name=>'CardControl'
,p_parent_plug_id=>wwv_flow_imp.id(1561836742698118942)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1570718817443421748)
,p_plug_name=>'New2'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2707059584407204267)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'WITH search_countries AS (',
'                SELECT ',
'                    sucheid,',
'                    TO_NUMBER(COLUMN_VALUE) AS landid',
'                FROM t_suche_json,',
'                TABLE(apex_string.split(',
'                    JSON_VALUE(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                    '':''',
'                ))',
'                WHERE sucheid = 12871',
'            )',
'            SELECT DISTINCT',
'                ms.vorschriftnummer AS r',
'            FROM search_countries sc',
'            LEFT JOIN T_MS_SUCHERGEBNISS ms ON (',
'                ms.sucheid = sc.sucheid ',
'                AND ms.landid = sc.landid',
'                AND sc.landid IN (',
'                    SELECT column_value ',
'                    FROM TABLE(apex_string.split_numbers(''1015'', '':''))',
'                )',
'            )',
'            WHERE vorschriftnummer IS NOT NULL ',
'            AND ms.MEILENSTEIN = 1',
'          ',
'            ',
'            ',
'            -- SELECT country_vorschrift_card_detail(',
'--     12871,  -- p_search_id',
'--     1,    -- p_milestone ',
'--     ''1015'', -- P_LANDID',
'--     ''DISPLAY''',
'-- ) AS html_output',
'-- FROM dual;',
'',
'',
'  ORDER BY r'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(1041370953780806934)
,p_region_id=>wwv_flow_imp.id(1570718817443421748)
,p_layout_type=>'GRID'
,p_grid_column_count=>4
,p_title_adv_formatting=>false
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1041378187633806982)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(514465462002129628)
,p_button_name=>'SaveFilterandViewSettings'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Savefilterandviewsettings'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'<span aria-hidden="true" class="fa fa-save fam-check fam-is-success" style="color: white;"></span>'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1041377764648806979)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(514465462002129628)
,p_button_name=>'LoadorManageFilterandViewSettings'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'Loadormanagefilterandviewsettings'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-save-as'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1041377406780806978)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(514465462002129628)
,p_button_name=>'SelectedFilterandViewName'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'<b>Selected Filter&View Name</b>: &P19_START_PROFILE.'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-user-check'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1041356662940806862)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(6125655760058515141)
,p_button_name=>'B_KOMMENTARE_PRUEFEN'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('Kommentar bez. ausgew\00E4hlten L\00E4ndern pr\00FCfen')
,p_warn_on_unsaved_changes=>null
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-info-square-o'
,p_button_cattributes=>'style="margin: 0px; padding: 0px; "'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1041357078600806862)
,p_button_sequence=>150
,p_button_plug_id=>wwv_flow_imp.id(6125655760058515141)
,p_button_name=>'BTN_MERGE_CARDS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'Merge Selected Cards'
,p_warn_on_unsaved_changes=>null
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-object-group'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1041373970140806946)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1561836742698118942)
,p_button_name=>'APPLY_ACTION_BUTTON'
,p_button_static_id=>'APPLY_ACTION_BUTTON'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'Aktion anwenden'
,p_button_position=>'NEXT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1041361214672806871)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(540063104747099848)
,p_button_name=>'FilterAnwenden'
,p_button_static_id=>'B501317057147707225'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Filter anwenden'
,p_button_position=>'NEXT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-filter'
,p_button_comment=>'gradient-button'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1041362992845806874)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(540061161446099829)
,p_button_name=>'DownloadExcelReport'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Daten herunterladen f\00FCr Aller L\00E4nder Vorschriften')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_icon_css_classes=>'fa-download-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041376960295806962)
,p_name=>'P19_FIRST_LOAD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(514465462002129628)
,p_prompt=>'First Load'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041376627159806956)
,p_name=>'P19_MODAL_URL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(514465462002129628)
,p_prompt=>'Modal URL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041376230416806955)
,p_name=>'P19_FILTER_VIEW_PROFILE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(514465462002129628)
,p_prompt=>'Filter View Profile'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041375853526806955)
,p_name=>'P19_FILTER_VIEW_PROFILE_ID'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(514465462002129628)
,p_prompt=>'Filter View Profile'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041375448883806955)
,p_name=>'P19_FILTER_PROFILE_NEW'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(514465462002129628)
,p_prompt=>'Filter View Profile New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041375022380806955)
,p_name=>'P19_START_PROFILE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(514465462002129628)
,p_prompt=>'Start Profile'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041374630288806955)
,p_name=>'P19_START_PROFILE_NEW'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(514465462002129628)
,p_prompt=>'Start Profile New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041373257149806945)
,p_name=>'P19_ACTION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1561836776464118943)
,p_prompt=>'Aktion'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH card_stats AS (',
'    SELECT ',
'        COUNT(DISTINCT card_number) as total_cards,',
'        COUNT(CASE WHEN card_count > 1 THEN 1 END) as merged_cards',
'    FROM (',
'        SELECT card_number, COUNT(*) as card_count',
'        FROM T_MS_SUCHE_SPLIT',
'        WHERE SUCHEID = :P19_SEARCH_SELECTION',
'        AND MEILENSTEIN = :P19_MILESTONE_SELECTION',
'        GROUP BY card_number',
'    )',
')',
'SELECT d, r',
'FROM (',
'    -- Delete Card: Show always if any cards exist',
unistr('    SELECT ''Karte l\00F6schen'' as d, ''DELETE_CARD'' as r '),
'    FROM card_stats',
'    WHERE total_cards > 0',
'    ',
'    UNION ALL',
'    ',
'    -- -- Delete Countries: Show when any merged cards exist',
unistr('    -- SELECT ''Bestimmte L\00E4nder aus Karte l\00F6schen'' as d, ''DELETE_COUNTRIES'' as r'),
'    -- FROM card_stats',
'    -- WHERE merged_cards > 0',
'    ',
'    -- UNION ALL',
'    ',
'    -- -- Unmerge Countries: Show when any merged cards exist',
unistr('    -- SELECT ''Bestimmte L\00E4nder aus Karte trennen'' as d, ''UNMERGE_COUNTRIES'' as r'),
'    -- FROM card_stats',
'    -- WHERE merged_cards > 0',
'    ',
'    -- UNION ALL',
'    ',
'    -- Merge Cards: Show only when more than one card exists',
unistr('    SELECT ''Karten zusammenf\00FChren'' as d, ''MERGE_CARD'' as r'),
'    FROM card_stats',
'    WHERE total_cards > 1',
'    ',
'    UNION ALL',
'    ',
'    -- Unmerge Card: Show only when merged cards exist',
'    SELECT ''Karte trennen'' as d, ''UNMERGE_CARD'' as r',
'    FROM card_stats',
'    WHERE merged_cards > 0',
')',
'ORDER BY r;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- ausw\00E4hlen --')
,p_lov_cascade_parent_items=>'P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION'
,p_ajax_items_to_submit=>'P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:margin-top-lg'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH card_stats AS (',
'    SELECT ',
'        COUNT(DISTINCT card_number) as total_cards,',
'        COUNT(CASE WHEN card_count > 1 THEN 1 END) as merged_cards',
'    FROM (',
'        SELECT card_number, COUNT(*) as card_count',
'        FROM T_MS_SUCHE_SPLIT',
'        WHERE SUCHEID = :P19_SEARCH_SELECTION',
'        AND MEILENSTEIN = :P19_MILESTONE_SELECTION',
'        GROUP BY card_number',
'    )',
')',
'SELECT d, r',
'FROM (',
'    -- Delete Card: Show always if any cards exist',
'    SELECT ''Delete Card'' as d, ''DELETE_CARD'' as r ',
'    FROM card_stats',
'    WHERE total_cards > 0',
'    ',
'    UNION ALL',
'    ',
'    -- Delete Countries: Show when any merged cards exist',
'    SELECT ''Delete Countries from Card'' as d, ''DELETE_COUNTRIES'' as r',
'    FROM card_stats',
'    WHERE merged_cards > 0',
'    ',
'    UNION ALL',
'    ',
'    -- Merge Cards: Show only when more than one card exists',
'    SELECT ''Merge Cards'' as d, ''MERGE_CARD'' as r',
'    FROM card_stats',
'    WHERE total_cards > 1',
'    ',
'    UNION ALL',
'    ',
'    -- Unmerge Card: Show only when merged cards exist',
'    SELECT ''Unmerge Card'' as d, ''UNMERGE_CARD'' as r',
'    FROM card_stats',
'    WHERE merged_cards > 0',
')',
'ORDER BY r;'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041372894825806943)
,p_name=>'P19_DELETE_SPECIFIC_COUNTRIES'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(1561836776464118943)
,p_prompt=>unistr('Bestimmte L\00E4nder aus Karte l\00F6schen')
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:margin-top-lg'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'unchecked_value', 'N',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041372504949806941)
,p_name=>'P19_SPLIT_SPECIFIC_COUNTRIES'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(1561836776464118943)
,p_prompt=>unistr('Bestimmte L\00E4nder aus Karte trennen')
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:margin-top-lg'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'unchecked_value', 'N',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041372096521806941)
,p_name=>'P19_CARD_SHUTTLE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(1561836776464118943)
,p_prompt=>unistr('L\00E4nder')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    LISTAGG(L.B_NUMMER || '' - '' || L.LAND, ''; '') ',
'    WITHIN GROUP (ORDER BY L.B_NUMMER) as d,',
'    MS.CARD_NUMBER as r',
'FROM T_MS_SUCHE_SPLIT MS',
'JOIN t_land L ON (L.LANDID = MS.LANDID)',
'WHERE MS.SUCHEID = :P19_SEARCH_SELECTION ',
'AND MS.MEILENSTEIN = :P19_MILESTONE_SELECTION',
'AND (',
'    :P19_ACTION = ''DELETE_CARD''',
'    OR (:P19_ACTION = ''DELETE_COUNTRIES'' AND ',
'        MS.CARD_NUMBER IN (',
'            SELECT card_number ',
'            FROM T_MS_SUCHE_SPLIT ',
'            WHERE SUCHEID = :P19_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P19_MILESTONE_SELECTION',
'            GROUP BY card_number ',
'            HAVING COUNT(*) > 1',
'        )',
'    )',
'    OR (:P19_ACTION = ''UNMERGE_COUNTRIES'' AND ',
'        MS.CARD_NUMBER IN (',
'            SELECT card_number ',
'            FROM T_MS_SUCHE_SPLIT ',
'            WHERE SUCHEID = :P19_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P19_MILESTONE_SELECTION',
'            GROUP BY card_number ',
'            HAVING COUNT(*) > 1',
'        )',
'    )',
'    OR (:P19_ACTION = ''MERGE_CARD'' ',
'        AND NOT (',
'            (SELECT COUNT(DISTINCT card_number) ',
'             FROM T_MS_SUCHE_SPLIT ',
'             WHERE SUCHEID = :P19_SEARCH_SELECTION',
'             AND MEILENSTEIN = :P19_MILESTONE_SELECTION) = 1',
'        )',
'    )',
'    OR (:P19_ACTION = ''UNMERGE_CARD'' AND ',
'        MS.CARD_NUMBER IN (',
'            SELECT card_number ',
'            FROM T_MS_SUCHE_SPLIT ',
'            WHERE SUCHEID = :P19_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P19_MILESTONE_SELECTION',
'            GROUP BY card_number ',
'            HAVING COUNT(*) > 1',
'        )',
'    )',
')',
'GROUP BY MS.CARD_NUMBER',
'ORDER BY NLSSORT(',
'    LISTAGG(L.B_NUMMER || '' - '' || L.LAND, ''; '') ',
'    WITHIN GROUP (ORDER BY L.B_NUMMER),',
'    ''NLS_SORT=BINARY_AI''',
');'))
,p_lov_cascade_parent_items=>'P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION,P19_ACTION'
,p_ajax_items_to_submit=>'P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION,P19_ACTION'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_css_classes=>'CardShuttle_Tooltip'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    -- ''Card-''|| MS.CARD_NUMBER || '' ('' || ',
'    LISTAGG(L.B_NUMMER || '' - '' || L.LAND, ''; '') ',
'    WITHIN GROUP (ORDER BY L.B_NUMMER) ',
'    -- || '')'' ',
'    as d,',
'    MS.CARD_NUMBER as r,',
'    L.B_NUMMER',
'FROM T_MS_SUCHE_SPLIT MS',
'JOIN t_land L ON (L.LANDID = MS.LANDID)',
'WHERE MS.SUCHEID = :P19_SEARCH_SELECTION ',
'AND MS.MEILENSTEIN = :P19_MILESTONE_SELECTION',
'AND (',
'    -- For DELETE_CARD: show all cards',
'    :P19_ACTION = ''DELETE_CARD''',
'    ',
'    -- Delete Countries: Show when any merged cards exist',
'    OR (:P19_ACTION = ''DELETE_COUNTRIES'' AND ',
'        MS.CARD_NUMBER IN (',
'            SELECT card_number ',
'            FROM T_MS_SUCHE_SPLIT ',
'            WHERE SUCHEID = :P19_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P19_MILESTONE_SELECTION',
'            GROUP BY card_number ',
'            HAVING COUNT(*) > 1',
'        )',
'    )',
'    ',
'    -- Unmerge Countries: Show when any merged cards exist',
'    OR (:P19_ACTION = ''UNMERGE_COUNTRIES'' AND ',
'        MS.CARD_NUMBER IN (',
'            SELECT card_number ',
'            FROM T_MS_SUCHE_SPLIT ',
'            WHERE SUCHEID = :P19_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P19_MILESTONE_SELECTION',
'            GROUP BY card_number ',
'            HAVING COUNT(*) > 1',
'        )',
'    )',
'',
'    -- For MERGE_CARD: only show if there are multiple cards total',
'    OR (:P19_ACTION = ''MERGE_CARD'' ',
'        AND NOT (',
'            (SELECT COUNT(DISTINCT card_number) ',
'             FROM T_MS_SUCHE_SPLIT ',
'             WHERE SUCHEID = :P19_SEARCH_SELECTION',
'             AND MEILENSTEIN = :P19_MILESTONE_SELECTION) = 1',
'        )',
'    )',
'    ',
'    -- For UNMERGE_CARD: only show merged cards',
'    OR (:P19_ACTION = ''UNMERGE_CARD'' AND ',
'        MS.CARD_NUMBER IN (',
'            SELECT card_number ',
'            FROM T_MS_SUCHE_SPLIT ',
'            WHERE SUCHEID = :P19_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P19_MILESTONE_SELECTION',
'            GROUP BY card_number ',
'            HAVING COUNT(*) > 1',
'        )',
'    )',
')',
'GROUP BY MS.CARD_NUMBER',
'',
'-- ORDER BY NLSSORT(L.B_NUMMER, ''NLS_SORT=BINARY_AI'')',
'ORDER BY MS.CARD_NUMBER DESC;',
'',
'',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041371707709806939)
,p_name=>'P19_SELECTED_COUNTRIES_FROM_CARD'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(1561836776464118943)
,p_prompt=>unistr('W\00E4hlen Sie bestimmte L\00E4nder')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    l.b_nummer || '' - '' || l.LAND as d,',
'    l.landid as r',
'FROM t_land l',
'JOIN T_MS_SUCHE_SPLIT ms ON (',
'    l.landid = ms.landid',
'    AND ms.card_number in(select column_value from table(apex_string.split_numbers(:P19_CARD_SHUTTLE, '':'')))',
'    -- AND ms.card_number = :P19_CARD_SHUTTLE',
'    AND ms.sucheid = :P19_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P19_MILESTONE_SELECTION',
')',
'-- ORDER BY l.b_nummer;',
'ORDER BY NLSSORT(L.B_NUMMER, ''NLS_SORT=BINARY_AI'')'))
,p_lov_cascade_parent_items=>'P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION,P19_CARD_SHUTTLE'
,p_ajax_items_to_submit=>'P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION,P19_CARD_SHUTTLE'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>5
,p_grid_column=>3
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041370167756806927)
,p_name=>'P19_JUMP_TO_CARD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(540061366066099831)
,p_prompt=>'Zur Karte springen'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    -- ''Card-'' || MS.CARD_NUMBER || '' ('' || ',
'    LISTAGG(L.B_NUMMER || '' - '' || L.LAND, ''; '') ',
'    WITHIN GROUP (ORDER BY L.B_NUMMER) ',
'    -- || '')'' ',
'    as d,',
'    MS.CARD_NUMBER as r',
'FROM T_MS_SUCHE_SPLIT MS',
'JOIN t_land L ON (L.LANDID = MS.LANDID)',
'WHERE MS.SUCHEID = :P19_SEARCH_SELECTION ',
'AND MS.MEILENSTEIN = :P19_MILESTONE_SELECTION',
'GROUP BY MS.CARD_NUMBER',
'ORDER BY MS.CARD_NUMBER asc'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- ausw\00E4hlen --')
,p_lov_cascade_parent_items=>'P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION'
,p_ajax_items_to_submit=>'P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041360754218806870)
,p_name=>'P19_SAVED_CARD_COUNTRIES'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(540063104747099848)
,p_prompt=>'Saved Card Countries'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041360344849806870)
,p_name=>'P19_SAVED_CARD_NUMBERS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(540063104747099848)
,p_prompt=>'Saved Card Countries '
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041359987362806869)
,p_name=>'P19_REFRESH_CARDS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(540063104747099848)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041359592381806868)
,p_name=>'P19_BENUTZER_NAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(540063104747099848)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Benutzer'
,p_source=>'select NACHNAME || '',  '' || VORNAME from t_benutzer where BENUTZERID = :G_BENUTZERID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041359135616806865)
,p_name=>'P19_FILTER_APPLIED'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(540063104747099848)
,p_prompt=>'Filter Applied'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041358891042806865)
,p_name=>'P19_SEARCH_SELECTION'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(540063104747099848)
,p_prompt=>'Suchergebnis'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ''Suche ID ('' || sucheid || '') - '' || ',
'    REGEXP_REPLACE(',
'        REGEXP_REPLACE(BEZEICHNUNG, ''user_'', ''''),',
'        ''(.*?) (\d{2}\.\d{2}\.\d{4}) (\d{2}:\d{2}:\d{2})'',',
'        ''\1 - \2, \3''',
'    )',
'AS d,',
'    sucheid AS r',
'FROM ',
'    t_suche_json',
'WHERE ',
'    benutzerid = :G_BENUTZERID',
'ORDER BY ',
'    zeitpunkt DESC;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- ausw\00E4hlen --')
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ''Search '' || sucheid || '' - '' || BEZEICHNUNG ',
'    -- || '' ('' || TO_CHAR(zeitpunkt, ''DD.MM.YYYY HH24:MI'') || '')'' ',
'    AS d, -- Display Value',
'    sucheid AS r -- Return Value',
'FROM ',
'    t_suche_json',
'WHERE ',
'    benutzerid = :G_BENUTZERID',
'ORDER BY ',
'    zeitpunkt DESC;',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041358498568806864)
,p_name=>'P19_MILESTONE_SELECTION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(540063104747099848)
,p_prompt=>'Meilenstein'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH json_data AS (',
'    SELECT suchdaten',
'    FROM t_suche_json',
'    WHERE sucheid = :P19_SEARCH_SELECTION',
')',
'SELECT ',
'    ''Meilenstein '' || j.meilenstein as d, -- Display Value',
'    j.meilenstein as r -- Return Value',
'    ',
'FROM json_data,',
'JSON_TABLE(suchdaten, ''$[*]'' COLUMNS (',
'    meilenstein NUMBER PATH ''$.MEILENSTEIN''',
')) j',
'WHERE j.meilenstein IS NOT NULL;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- ausw\00E4hlen --')
,p_lov_cascade_parent_items=>'P19_SEARCH_SELECTION'
,p_ajax_items_to_submit=>'P19_SEARCH_SELECTION'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041357796959806863)
,p_name=>'P19_FILTER_LAENDERGRUPPE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6125654821655513204)
,p_prompt=>unistr('Vorfilter <br> L\00E4nder&shy;gruppen')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    lg.laendergruppe as d,  ',
'    lg.laendergruppeid as r',
'FROM t_laendergruppe lg ',
'WHERE lg.laendergruppeid != 1220',
'AND EXISTS (',
'    -- Check if group has countries from user''s selected search and milestone',
'    SELECT 1 ',
'    FROM t_land_ref_laendergruppe lrg',
'    WHERE lrg.laendergruppeid = lg.laendergruppeid',
'    AND lrg.landid IN (',
'        SELECT TO_NUMBER(COLUMN_VALUE) as landid',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            laender VARCHAR2(4000) PATH ''$.LAENDER''',
'        )) jt,',
'        TABLE(apex_string.split(jt.laender, '':''))',
'        WHERE tsj.sucheid = :P19_SEARCH_SELECTION',
'        AND tsj.benutzerid = :G_BENUTZERID',
'        AND jt.meilenstein = :P19_MILESTONE_SELECTION',
'    )',
')',
'ORDER BY lg.laendergruppe;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Alle --'
,p_lov_cascade_parent_items=>'P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION'
,p_ajax_items_to_submit=>'P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>8
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select lg.laendergruppe, lg.laendergruppeid ',
'from t_laendergruppe lg where lg.laendergruppeid!=1220',
'--and landid in (select column_value from table(apex_string.split_numbers(:P19_NEW_1,'':'')))',
'',
'/*and lg.laendergruppeid in (select LAENDERGRUPPEID from t_land_ref_laendergruppe */',
'--where landid in (select column_value from table(apex_string.split_numbers(:P19_NEW_1,'':'')))',
'order by 1;',
'',
'',
'',
'SELECT ',
'    lg.laendergruppe as d,  ',
'    lg.laendergruppeid as r',
'FROM t_laendergruppe lg ',
'WHERE lg.laendergruppeid != 1220',
'AND EXISTS (',
'    -- Check if group has countries from user''s selected search and milestone',
'    SELECT 1 ',
'    FROM t_land_ref_laendergruppe lrg',
'    WHERE lrg.laendergruppeid = lg.laendergruppeid',
'    AND lrg.landid IN (',
'        SELECT TO_NUMBER(COLUMN_VALUE) as landid',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            laender VARCHAR2(4000) PATH ''$.LAENDER''',
'        )) jt,',
'        TABLE(apex_string.split(jt.laender, '':''))',
'        WHERE tsj.sucheid = :P19_SEARCH_SELECTION',
'        AND tsj.benutzerid = :G_BENUTZERID',
'        AND jt.meilenstein = :P19_MILESTONE_SELECTION',
'    )',
')',
'ORDER BY lg.laendergruppe;',
'',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041356242560806861)
,p_name=>'P19_FILTER_LAND'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(6125655760058515141)
,p_prompt=>unistr('L\00E4nder')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    -- l.landid || '' - '' || ',
'    l.b_nummer || '' - '' || ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.land',
'        ELSE l.land_eng',
'    END as d,      ',
'    l.landid as r  ',
'FROM ',
'    t_land l',
'WHERE EXISTS (',
'    -- Match countries from selected search and milestone',
'    SELECT 1',
'    FROM t_suche_json tsj,',
'    JSON_TABLE(',
'        tsj.suchdaten, ',
'        ''$[*]'' COLUMNS (',
'            laender VARCHAR2(4000) PATH ''$.LAENDER'',',
'            meilenstein VARCHAR2(4000) PATH ''$.MEILENSTEIN''',
'        )',
'    ) jt',
'    WHERE ',
'        tsj.sucheid = :P19_SEARCH_SELECTION',
'        AND tsj.benutzerid = :G_BENUTZERID',
'        AND l.landid IN (',
'            SELECT TO_NUMBER(COLUMN_VALUE)',
'            FROM TABLE(apex_string.split(jt.laender, '':''))',
'        )',
'        AND jt.meilenstein = :P19_MILESTONE_SELECTION',
'',
' -- Exclude countries that are already in cards',
'    AND L.LANDID NOT IN (',
'    SELECT LANDID ',
'    FROM T_MS_SUCHE_SPLIT ',
'    WHERE ',
'        BENUTZERID = :G_BENUTZERID ',
'        AND SUCHEID = :P19_SEARCH_SELECTION ',
'        AND MEILENSTEIN = :P19_MILESTONE_SELECTION',
'',
'    )',
')',
'-- ORDER BY l.b_nummer;',
'ORDER BY NLSSORT(l.b_nummer, ''NLS_SORT=BINARY_AI'')'))
,p_lov_cascade_parent_items=>'P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION'
,p_ajax_items_to_submit=>'P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#:margin-top-sm'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ',
'    l.b_nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.land',
'        ELSE l.land_eng',
'    END as d,      -- Changed ''land'' to ''d'' to match AJAX process',
'    l.landid as r  -- Changed ''landid'' to ''r'' to match AJAX process',
'FROM t_land l',
'WHERE EXISTS (',
'    -- Match countries from selected search and milestone',
'    SELECT 1',
'    FROM t_suche_json tsj,',
'    JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'        laender VARCHAR2(4000) PATH ''$.LAENDER'',',
'        meilenstein VARCHAR2(4000) PATH ''$.MEILENSTEIN''',
'    )) jt',
'    WHERE tsj.sucheid = :P19_SEARCH_SELECTION',
'    AND tsj.benutzerid = :G_BENUTZERID',
'    AND l.landid IN (',
'        SELECT TO_NUMBER(COLUMN_VALUE)',
'        FROM TABLE(apex_string.split(jt.laender, '':''))',
'    )',
'    AND jt.meilenstein = :P19_MILESTONE_SELECTION',
'  -- AND L.LANDID NOT IN (SELECT LANDID FROM T_MS_SUCHE_SPLIT WHERE BENUTZERID=:G_BENUTZERID AND SUCHEID	=:P19_SEARCH_SELECTION AND MEILENSTEIN =:P19_MILESTONE_SELECTION )',
')',
'',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041355882671806861)
,p_name=>'P19_LAND_STATUS_DATENSTAND'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(6125655760058515141)
,p_prompt=>unistr('Die folgenden L\00E4nder sind derzeit im Regulation Index nicht abgebildet:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="font-size: 12px; font-weight: 100; line-height: 16px; margin:0px; padding:0px;"'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#:margin-top-none:margin-bottom-none'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041355500325806859)
,p_name=>'P19_BESONDERHEITEN'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(6125655760058515141)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041355065092806859)
,p_name=>'P19_URL'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(6125655760058515141)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041354684030806859)
,p_name=>'P19_LAENDER_CONTAINED_MJ'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(6125655760058515141)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041354304011806858)
,p_name=>'P19_CARD_COUNT'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(6125655760058515141)
,p_use_cache_before_default=>'NO'
,p_prompt=>'New'
,p_source=>'SELECT COUNT(DISTINCT card_number) FROM T_MS_SUCHE_SPLIT WHERE SUCHEID = :P19_SEARCH_SELECTION AND MEILENSTEIN = :P19_MILESTONE_SELECTION AND BENUTZERID = :G_BENUTZERID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041353831248806857)
,p_name=>'P19_MERGE_ENABLED'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(6125655760058515141)
,p_item_default=>'N'
,p_prompt=>'Merge Enabled'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'unchecked_value', 'N',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041353472976806856)
,p_name=>'P19_MANAGE_CARD'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(6125655760058515141)
,p_prompt=>'Manage Card'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ''Card '' || LEVEL as d,  -- Display Value',
'    LEVEL as r              -- Return Value',
'FROM dual',
'CONNECT BY LEVEL <= (',
'    SELECT COUNT(DISTINCT landid)',
'    FROM t_ms_suchergebniss',
'    WHERE sucheid = :P19_SEARCH_SELECTION',
'    AND meilenstein = :P19_MILESTONE_SELECTION',
'    AND landid IN (',
'        SELECT column_value ',
'        FROM TABLE(apex_string.split_numbers(:P19_FILTER_LAND, '':''))',
'    )',
');'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Select --'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041353018107806856)
,p_name=>'P19_MERGE_COUNTRIES'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(6125655760058515141)
,p_prompt=>'Merge Lands'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    l.B_NUMMER || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.land',
'        ELSE l.land_eng',
'    END as d,          -- Display Value',
'    l.landid as r      -- Return Value',
'FROM t_land l',
'WHERE l.landid IN (',
'    SELECT column_value ',
'    FROM TABLE(apex_string.split_numbers(:P19_FILTER_LAND, '':''))',
')',
'-- -- Don''t show countries already in cards',
'-- AND l.landid NOT IN (',
'--     SELECT landid ',
'--     FROM t_ms_suche_split',
'--     WHERE sucheid = :P19_SEARCH_SELECTION',
'--     AND meilenstein = :P19_MILESTONE_SELECTION',
'-- )',
'ORDER BY ',
'    NLSSORT(l.B_NUMMER, ''NLS_SORT=BINARY_AI'');'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Select--'
,p_lov_cascade_parent_items=>'P19_FILTER_LAND'
,p_ajax_items_to_submit=>'P19_FILTER_LAND'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(3414144209519820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select l.b_nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.land',
'        ELSE l.land_eng',
'    END as land, l.landid',
'from t_land l',
'WHERE LANDID in (select column_value from table(apex_string.split_numbers(:P19_FILTER_LAND, '':'')))',
'',
'/*8where (:P19_FILTER_LAENDERGRUPPE is null or landid in (select landid from t_land_ref_laendergruppe where laendergruppeid = :P19_FILTER_LAENDERGRUPPE))',
' and (:P19_STARTDATUM_TYP is null or startdatum_typ = :P19_STARTDATUM_TYP)*/',
'ORDER BY NLSSORT(l.B_NUMMER, ''NLS_SORT=BINARY_AI'') ASC'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1041352623069806856)
,p_name=>'P19_HAS_MERGED_CARDS'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(6125655760058515141)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041316541753806788)
,p_name=>'FILTER_LAENDERGRUPPE_CHANGED'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_FILTER_LAENDERGRUPPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041316102175806788)
,p_event_id=>wwv_flow_imp.id(1041316541753806788)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041315712230806788)
,p_name=>'Set Count'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_MILESTONE_SELECTION'
,p_condition_element=>'P19_MILESTONE_SELECTION'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041315144248806788)
,p_event_id=>wwv_flow_imp.id(1041315712230806788)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_FILTER_LAENDERGRUPPE,P19_FILTER_LAND'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041312691292806785)
,p_event_id=>wwv_flow_imp.id(1041315712230806788)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_FILTER_LAENDERGRUPPE,P19_FILTER_LAND'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041313629094806786)
,p_event_id=>wwv_flow_imp.id(1041315712230806788)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(1041356662940806862)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041313119390806786)
,p_event_id=>wwv_flow_imp.id(1041315712230806788)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(1041356662940806862)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041314691444806788)
,p_event_id=>wwv_flow_imp.id(1041315712230806788)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1561836742698118942)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041314176452806787)
,p_event_id=>wwv_flow_imp.id(1041315712230806788)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1561836742698118942)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041312196292806785)
,p_event_id=>wwv_flow_imp.id(1041315712230806788)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(540061366066099831)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041311626417806785)
,p_event_id=>wwv_flow_imp.id(1041315712230806788)
,p_event_result=>'FALSE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(540061366066099831)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041311118482806785)
,p_event_id=>wwv_flow_imp.id(1041315712230806788)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(540061161446099829)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041310640392806784)
,p_event_id=>wwv_flow_imp.id(1041315712230806788)
,p_event_result=>'TRUE'
,p_action_sequence=>110
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'refreshcard();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041321397399806791)
,p_name=>'Handle Action Change'
,p_event_sequence=>180
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_ACTION'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$v("P19_ACTION") !== null && $v("P19_ACTION") !== ""'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_da_event_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'js  client ',
'',
'$v("P460_ACTION") !== null && $v("P460_ACTION") !== ""'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041320334997806791)
,p_event_id=>wwv_flow_imp.id(1041321397399806791)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_CARD_SHUTTLE,P19_SELECTED_COUNTRIES_FROM_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041319339460806790)
,p_event_id=>wwv_flow_imp.id(1041321397399806791)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_CARD_SHUTTLE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    ''Card-''|| MS.CARD_NUMBER || '' ('' || ',
'    LISTAGG(L.B_NUMMER || '' - '' || L.LAND, ''; '') ',
'    WITHIN GROUP (ORDER BY L.B_NUMMER) || '')'' as d,',
'    MS.CARD_NUMBER as r',
'FROM T_MS_SUCHE_SPLIT MS',
'JOIN t_land L ON (L.LANDID = MS.LANDID)',
'WHERE MS.SUCHEID = :P19_SEARCH_SELECTION ',
'AND MS.MEILENSTEIN = :P19_MILESTONE_SELECTION',
'AND (',
'    (:P19_ACTION = ''UNMERGE_CARD'' AND',
'        MS.CARD_NUMBER IN (',
'            SELECT CARD_NUMBER ',
'            FROM T_MS_SUCHE_SPLIT ',
'            WHERE SUCHEID = :P19_SEARCH_SELECTION ',
'            AND MEILENSTEIN = :P19_MILESTONE_SELECTION',
'            GROUP BY CARD_NUMBER ',
'            HAVING COUNT(*) > 1',
'        )',
'    ) OR',
'    :P19_ACTION != ''UNMERGE_CARD''',
')',
'GROUP BY MS.CARD_NUMBER',
'ORDER BY MS.CARD_NUMBER DESC'))
,p_attribute_07=>'P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_da_action_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sql ',
'',
'SELECT DISTINCT ',
'    ''Card-''|| MS.CARD_NUMBER || '' ('' || ',
'    LISTAGG(L.B_NUMMER || '' - '' || L.LAND, ''; '') ',
'    WITHIN GROUP (ORDER BY L.B_NUMMER) || '')'' as d,',
'    MS.CARD_NUMBER as r',
'FROM T_MS_SUCHE_SPLIT MS',
'JOIN t_land L ON (L.LANDID = MS.LANDID)',
'WHERE MS.SUCHEID = :P460_SEARCH_SELECTION ',
'AND MS.MEILENSTEIN = :P460_MILESTONE_SELECTION',
'AND (',
'    (:P460_ACTION = ''UNMERGE_CARD'' AND',
'        MS.CARD_NUMBER IN (',
'            SELECT CARD_NUMBER ',
'            FROM T_MS_SUCHE_SPLIT ',
'            WHERE SUCHEID = :P460_SEARCH_SELECTION ',
'            AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'            GROUP BY CARD_NUMBER ',
'            HAVING COUNT(*) > 1',
'        )',
'    ) OR',
'    :P460_ACTION != ''UNMERGE_CARD''',
')',
'GROUP BY MS.CARD_NUMBER',
'ORDER BY MS.CARD_NUMBER DESC'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041320877577806791)
,p_event_id=>wwv_flow_imp.id(1041321397399806791)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_CARD_SHUTTLE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041319842540806791)
,p_event_id=>wwv_flow_imp.id(1041321397399806791)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041340206005806801)
,p_name=>'Handle Apply Action'
,p_event_sequence=>190
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1041373970140806946)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041339622317806801)
,p_event_id=>wwv_flow_imp.id(1041340206005806801)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Sind Sie sicher, dass Sie die ausgew\00E4hlten Karten l\00F6schen m\00F6chten?')
,p_attribute_02=>unistr('Karten l\00F6schen ? ')
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-question'
,p_attribute_05=>'.delete_confirm'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P19_ACTION'
,p_client_condition_expression=>'DELETE_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041339210856806801)
,p_event_id=>wwv_flow_imp.id(1041340206005806801)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Sind Sie sicher, dass Sie die ausgew\00E4hlten L\00E4nder aus der Karte l\00F6schen m\00F6chten?')
,p_attribute_02=>unistr('ausgew\00E4hlten L\00E4nder aus der Karte l\00F6schen ?')
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-question'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P19_ACTION'
,p_client_condition_expression=>'DELETE_COUNTRIES'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041338203970806801)
,p_event_id=>wwv_flow_imp.id(1041340206005806801)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Sind Sie sicher, dass Sie die ausgew\00E4hlten Karten zusammenf\00FChren m\00F6chten?')
,p_attribute_02=>unistr('Karten zusammenf\00FChren ?')
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-question'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P19_ACTION'
,p_client_condition_expression=>'MERGE_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041337662767806801)
,p_event_id=>wwv_flow_imp.id(1041340206005806801)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Sind Sie sicher, dass Sie die ausgew\00E4hlte Karte aufteilen m\00F6chten?')
,p_attribute_02=>unistr('ausgew\00E4hlte Karte aufteilen ?')
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-question'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P19_ACTION'
,p_client_condition_expression=>'UNMERGE_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041338697585806801)
,p_event_id=>wwv_flow_imp.id(1041340206005806801)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Sind Sie sicher, dass Sie die ausgew\00E4hlten L\00E4nder in Karten aufteilen m\00F6chten?')
,p_attribute_02=>unistr('ausgew\00E4hlten L\00E4nder in Karten ?')
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-question'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P19_ACTION'
,p_client_condition_expression=>'UNMERGE_COUNTRIES'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041336700437806800)
,p_event_id=>wwv_flow_imp.id(1041340206005806801)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'processCardAction();'
,p_da_action_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'l_first_card NUMBER;',
'l_new_card NUMBER;',
'l_counter NUMBER := 0;',
'l_remaining_countries NUMBER;',
'BEGIN',
'    CASE :P460_ACTION',
'    WHEN ''DELETE_CARD'' THEN',
'    DELETE FROM t_ms_suche_split',
'    WHERE CARD_NUMBER IN (',
'        SELECT column_value',
'        FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
'    )',
'    AND SUCHEID = :P460_SEARCH_SELECTION',
'    AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'',
'',
'    WHEN ''DELETE_COUNTRIES'' THEN',
'        -- First check if this would delete all countries from the card',
'        SELECT COUNT(*)',
'        INTO l_remaining_countries',
'        FROM t_ms_suche_split',
'        WHERE card_number IN (',
'            SELECT column_value ',
'            FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
'        )',
'        AND SUCHEID = :P460_SEARCH_SELECTION',
'        AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'        AND landid NOT IN (',
'            SELECT column_value',
'            FROM table(apex_string.split_numbers(:P460_SELECTED_COUNTRIES_FROM_CARD, '':''))',
'        );',
'',
'        IF l_remaining_countries > 0 THEN',
'            -- Safe to delete as it won''t remove all countries',
'            DELETE FROM t_ms_suche_split',
'            WHERE card_number IN (',
'                SELECT column_value',
'                FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
'            )',
'            AND landid IN (',
'                SELECT column_value',
'                FROM table(apex_string.split_numbers(:P460_SELECTED_COUNTRIES_FROM_CARD, '':''))',
'            )',
'            AND SUCHEID = :P460_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'        ELSE',
'            -- Would delete all countries - show error',
'            apex_error.add_error(',
'                p_message => ''Cannot delete all countries from a card. Use Delete Card action instead.'',',
'                p_display_location => apex_error.c_inline_in_notification',
'            );',
'            RETURN;',
'        END IF;',
'',
'        ',
'',
'WHEN ''MERGE_CARD'' THEN',
'-- Get first selected card number',
'SELECT MIN(column_value)',
'INTO l_first_card',
'FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''));',
'',
'-- Update other cards to first card number',
'UPDATE t_ms_suche_split',
'SET CARD_NUMBER = l_first_card,',
'    LETZTE_AENDERUNG_DATUM = SYSDATE,',
'    LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'WHERE CARD_NUMBER IN (',
'    SELECT column_value',
'    FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
')',
'AND CARD_NUMBER != l_first_card',
'AND SUCHEID = :P460_SEARCH_SELECTION',
'AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'',
'WHEN ''UNMERGE_CARD'' THEN',
'-- Get next available card number',
'SELECT NVL(MAX(CARD_NUMBER), 0) + 1',
'INTO l_new_card',
'FROM t_ms_suche_split;',
'',
'-- Update each landid to new card number',
'FOR r IN (',
'    SELECT DISTINCT ms.LANDID',
'    FROM t_ms_suche_split ms',
'    WHERE ms.CARD_NUMBER IN (',
'        SELECT column_value',
'        FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
'    )',
'    AND ms.SUCHEID = :P460_SEARCH_SELECTION',
'    AND ms.MEILENSTEIN = :P460_MILESTONE_SELECTION',
') LOOP',
'    IF l_counter > 0 THEN',
'        UPDATE t_ms_suche_split',
'        SET CARD_NUMBER = l_new_card + l_counter,',
'            LETZTE_AENDERUNG_DATUM = SYSDATE,',
'            LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'        WHERE LANDID = r.LANDID',
'        AND SUCHEID = :P460_SEARCH_SELECTION',
'        AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'    END IF;',
'    l_counter := l_counter + 1;',
'END LOOP;',
'END CASE;',
'',
'-- Show success message',
'apex_application.g_print_success_message := ',
'CASE :P460_ACTION',
'WHEN ''DELETE_CARD'' THEN ''Selected cards deleted successfully''',
'WHEN ''DELETE_COUNTRIES'' THEN ''Selected Countries from card deleted successfully''',
'WHEN ''MERGE_CARD'' THEN ''Cards merged successfully''',
'WHEN ''UNMERGE_CARD'' THEN ''Cards unmerged successfully''',
'END;',
'END;',
'',
'',
'',
'',
'',
'P460_ACTION,P460_CARD_SHUTTLE,P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION',
'',
'',
'P460_ACTION,P460_CARD_SHUTTLE'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041337162724806800)
,p_event_id=>wwv_flow_imp.id(1041340206005806801)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'refreshcard();'
,p_server_condition_type=>'NEVER'
,p_da_action_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'l_first_card NUMBER;',
'l_new_card NUMBER;',
'l_counter NUMBER := 0;',
'l_remaining_countries NUMBER;',
'BEGIN',
'    CASE :P460_ACTION',
'    WHEN ''DELETE_CARD'' THEN',
'    DELETE FROM t_ms_suche_split',
'    WHERE CARD_NUMBER IN (',
'        SELECT column_value',
'        FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
'    )',
'    AND SUCHEID = :P460_SEARCH_SELECTION',
'    AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'',
'',
'    WHEN ''DELETE_COUNTRIES'' THEN',
'        -- First check if this would delete all countries from the card',
'        SELECT COUNT(*)',
'        INTO l_remaining_countries',
'        FROM t_ms_suche_split',
'        WHERE card_number IN (',
'            SELECT column_value ',
'            FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
'        )',
'        AND SUCHEID = :P460_SEARCH_SELECTION',
'        AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'        AND landid NOT IN (',
'            SELECT column_value',
'            FROM table(apex_string.split_numbers(:P460_SELECTED_COUNTRIES_FROM_CARD, '':''))',
'        );',
'',
'        IF l_remaining_countries > 0 THEN',
'            -- Safe to delete as it won''t remove all countries',
'            DELETE FROM t_ms_suche_split',
'            WHERE card_number IN (',
'                SELECT column_value',
'                FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
'            )',
'            AND landid IN (',
'                SELECT column_value',
'                FROM table(apex_string.split_numbers(:P460_SELECTED_COUNTRIES_FROM_CARD, '':''))',
'            )',
'            AND SUCHEID = :P460_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'        ELSE',
'            -- Would delete all countries - show error',
'            apex_error.add_error(',
'                p_message => ''Cannot delete all countries from a card. Use Delete Card action instead.'',',
'                p_display_location => apex_error.c_inline_in_notification',
'            );',
'            RETURN;',
'        END IF;',
'',
'        ',
'',
'WHEN ''MERGE_CARD'' THEN',
'-- Get first selected card number',
'SELECT MIN(column_value)',
'INTO l_first_card',
'FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''));',
'',
'-- Update other cards to first card number',
'UPDATE t_ms_suche_split',
'SET CARD_NUMBER = l_first_card,',
'    LETZTE_AENDERUNG_DATUM = SYSDATE,',
'    LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'WHERE CARD_NUMBER IN (',
'    SELECT column_value',
'    FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
')',
'AND CARD_NUMBER != l_first_card',
'AND SUCHEID = :P460_SEARCH_SELECTION',
'AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'',
'WHEN ''UNMERGE_CARD'' THEN',
'-- Get next available card number',
'SELECT NVL(MAX(CARD_NUMBER), 0) + 1',
'INTO l_new_card',
'FROM t_ms_suche_split;',
'',
'-- Update each landid to new card number',
'FOR r IN (',
'    SELECT DISTINCT ms.LANDID',
'    FROM t_ms_suche_split ms',
'    WHERE ms.CARD_NUMBER IN (',
'        SELECT column_value',
'        FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
'    )',
'    AND ms.SUCHEID = :P460_SEARCH_SELECTION',
'    AND ms.MEILENSTEIN = :P460_MILESTONE_SELECTION',
') LOOP',
'    IF l_counter > 0 THEN',
'        UPDATE t_ms_suche_split',
'        SET CARD_NUMBER = l_new_card + l_counter,',
'            LETZTE_AENDERUNG_DATUM = SYSDATE,',
'            LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'        WHERE LANDID = r.LANDID',
'        AND SUCHEID = :P460_SEARCH_SELECTION',
'        AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'    END IF;',
'    l_counter := l_counter + 1;',
'END LOOP;',
'END CASE;',
'',
'-- Show success message',
'apex_application.g_print_success_message := ',
'CASE :P460_ACTION',
'WHEN ''DELETE_CARD'' THEN ''Selected cards deleted successfully''',
'WHEN ''DELETE_COUNTRIES'' THEN ''Selected Countries from card deleted successfully''',
'WHEN ''MERGE_CARD'' THEN ''Cards merged successfully''',
'WHEN ''UNMERGE_CARD'' THEN ''Cards unmerged successfully''',
'END;',
'END;',
'',
'',
'',
'',
'',
'P460_ACTION,P460_CARD_SHUTTLE,P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION',
'',
'',
'P460_ACTION,P460_CARD_SHUTTLE'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041336167203806799)
,p_event_id=>wwv_flow_imp.id(1041340206005806801)
,p_event_result=>'TRUE'
,p_action_sequence=>120
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_CARD_SHUTTLE,P19_ACTION,P19_JUMP_TO_CARD,P19_FILTER_LAND,P19_FILTER_LAENDERGRUPPE,P19_CARD_COUNT'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041318966923806790)
,p_name=>'When Filter button press'
,p_event_sequence=>200
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1041361214672806871)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041318002134806789)
,p_event_id=>wwv_flow_imp.id(1041318966923806790)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'click_to_showResult();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041317497132806789)
,p_event_id=>wwv_flow_imp.id(1041318966923806790)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'refreshcard();'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041318503254806790)
,p_event_id=>wwv_flow_imp.id(1041318966923806790)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_ACTION'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH card_stats AS (',
'    SELECT ',
'        COUNT(DISTINCT card_number) as total_cards,',
'        COUNT(CASE WHEN card_count > 1 THEN 1 END) as merged_cards',
'    FROM (',
'        SELECT card_number, COUNT(*) as card_count',
'        FROM T_MS_SUCHE_SPLIT',
'        WHERE SUCHEID = :P19_SEARCH_SELECTION',
'        AND MEILENSTEIN = :P19_MILESTONE_SELECTION',
'        GROUP BY card_number',
'    )',
')',
'SELECT d, r',
'FROM (',
'    -- Delete Card: Show always if any cards exist',
'    SELECT ''Delete Card'' as d, ''DELETE_CARD'' as r ',
'    FROM card_stats',
'    WHERE total_cards > 0',
'    ',
'    UNION ALL',
'    ',
'    -- Delete Countries: Show when any merged cards exist',
'    SELECT ''Delete Countries from Card'' as d, ''DELETE_COUNTRIES'' as r',
'    FROM card_stats',
'    WHERE merged_cards > 0',
'    ',
'    UNION ALL',
'    ',
'    -- Unmerge Countries: Show when any merged cards exist',
'    SELECT ''Unmerge Countries from Card'' as d, ''UNMERGE_COUNTRIES'' as r',
'    FROM card_stats',
'    WHERE merged_cards > 0',
'    ',
'    UNION ALL',
'    ',
'    -- Merge Cards: Show only when more than one card exists',
'    SELECT ''Merge Cards'' as d, ''MERGE_CARD'' as r',
'    FROM card_stats',
'    WHERE total_cards > 1',
'    ',
'    UNION ALL',
'    ',
'    -- Unmerge Card: Show only when merged cards exist',
'    SELECT ''Unmerge Card'' as d, ''UNMERGE_CARD'' as r',
'    FROM card_stats',
'    WHERE merged_cards > 0',
')',
'ORDER BY r;'))
,p_attribute_07=>'P19_MILESTONE_SELECTION,P19_SEARCH_SELECTION'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041316976120806789)
,p_event_id=>wwv_flow_imp.id(1041318966923806790)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_FILTER_LAND,P19_CARD_SHUTTLE,P19_ACTION,P19_FILTER_LAENDERGRUPPE,P19_JUMP_TO_CARD,P19_CARD_COUNT'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041346645498806821)
,p_name=>'Show / Hide'
,p_event_sequence=>210
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_CARD_SHUTTLE'
,p_condition_element=>'P19_CARD_SHUTTLE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041346147541806818)
,p_event_id=>wwv_flow_imp.id(1041346645498806821)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_SELECTED_COUNTRIES_FROM_CARD'
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>'$v("P19_ACTION") === "DELETE_COUNTRIES" || $v("P19_ACTION") === "UNMERGE_COUNTRIES"'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041345682252806817)
,p_event_id=>wwv_flow_imp.id(1041346645498806821)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_SELECTED_COUNTRIES_FROM_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041345207265806817)
,p_event_id=>wwv_flow_imp.id(1041346645498806821)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_SELECTED_COUNTRIES_FROM_CARD'
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$v("P19_ACTION") !== "DELETE_COUNTRIES" && $v("P19_ACTION") !== "UNMERGE_COUNTRIES"',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041344739168806817)
,p_name=>'Scroll to Selected Card'
,p_event_sequence=>220
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_JUMP_TO_CARD'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$v(''P19_JUMP_TO_CARD'') !== null'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041344282325806816)
,p_event_id=>wwv_flow_imp.id(1041344739168806817)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'try {',
'    const selectedCardNum = apex.item(''P19_JUMP_TO_CARD'').getValue();',
'    if (selectedCardNum) {',
'        const cardElement = document.querySelector(`.cards-region .card-container[data-cardnum="${selectedCardNum}"]`);',
'        ',
'        if (cardElement) {',
'            // Smooth scroll',
'            cardElement.scrollIntoView({',
'                behavior: ''smooth'',',
'                block: ''start''',
'            });',
'            ',
'            // Highlight animation',
'            // FFFFC0 FFFFCC',
'            cardElement.style.backgroundColor = ''#FFFFC0'';   ',
'            setTimeout(() => {',
'                cardElement.style.backgroundColor = '''';',
'            }, 2000);',
'        }',
'        // Clear selection',
'        // apex.item(''P19_JUMP_TO_CARD'').setValue('''');',
'    }',
'} catch (error) {',
'    console.error(''Error scrolling to card:'', error);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041322743023806792)
,p_name=>'Show Hide Next Items'
,p_event_sequence=>230
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_SEARCH_SELECTION'
,p_condition_element=>'P19_SEARCH_SELECTION'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041322256049806792)
,p_event_id=>wwv_flow_imp.id(1041322743023806792)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_MILESTONE_SELECTION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041321795622806792)
,p_event_id=>wwv_flow_imp.id(1041322743023806792)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_MILESTONE_SELECTION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041343905347806804)
,p_name=>'Change'
,p_event_sequence=>240
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_CARD_SHUTTLE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041343349070806804)
,p_event_id=>wwv_flow_imp.id(1041343905347806804)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("P19_CARD_SHUTTLE")) {',
'    apex.item("APPLY_ACTION_BUTTON").enable();',
'} else {',
'    apex.item("APPLY_ACTION_BUTTON").disable();',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041331935480806798)
,p_name=>'Enable / Disable Filter button'
,p_event_sequence=>270
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_FILTER_LAND'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041330978130806796)
,p_event_id=>wwv_flow_imp.id(1041331935480806798)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("P19_FILTER_LAND")) {',
'    apex.item("B501317057147707225").enable();',
'} else {',
'    apex.item("B501317057147707225").disable();',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041331490597806796)
,p_event_id=>wwv_flow_imp.id(1041331935480806798)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(540061161446099829)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041335792968806799)
,p_name=>'Toggle Checkboxes Based on Action'
,p_event_sequence=>280
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_ACTION,P19_HAS_MERGED_CARDS'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$v(''P19_ACTION'') === ''DELETE_CARD'' && $v(''P19_HAS_MERGED_CARDS'') === ''Y'''
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_da_event_comment=>'$v(''P460_ACTION'') === ''DELETE_CARD'''
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041335290760806799)
,p_event_id=>wwv_flow_imp.id(1041335792968806799)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_DELETE_SPECIFIC_COUNTRIES'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041334749119806798)
,p_event_id=>wwv_flow_imp.id(1041335792968806799)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_DELETE_SPECIFIC_COUNTRIES'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041330527881806796)
,p_name=>'Toggle Checkboxes Based on Action_1'
,p_event_sequence=>290
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_ACTION,P19_HAS_MERGED_CARDS'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$v(''P19_ACTION'') === ''UNMERGE_CARD'' && $v(''P19_HAS_MERGED_CARDS'') === ''Y'''
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041330048149806795)
,p_event_id=>wwv_flow_imp.id(1041330527881806796)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_SPLIT_SPECIFIC_COUNTRIES'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041329586085806795)
,p_event_id=>wwv_flow_imp.id(1041330527881806796)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_SPLIT_SPECIFIC_COUNTRIES'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041329133420806795)
,p_name=>'New'
,p_event_sequence=>300
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_DELETE_SPECIFIC_COUNTRIES,P19_SPLIT_SPECIFIC_COUNTRIES'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$v(''P19_DELETE_SPECIFIC_COUNTRIES'') === ''Y'' || $v(''P19_SPLIT_SPECIFIC_COUNTRIES'') === ''Y'''
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041328679223806795)
,p_event_id=>wwv_flow_imp.id(1041329133420806795)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_SELECTED_COUNTRIES_FROM_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041328206286806794)
,p_event_id=>wwv_flow_imp.id(1041329133420806795)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_SELECTED_COUNTRIES_FROM_CARD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041334381279806798)
,p_name=>'Change 5'
,p_event_sequence=>310
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_CARD_SHUTTLE'
,p_condition_element=>'P19_CARD_SHUTTLE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041333345797806798)
,p_event_id=>wwv_flow_imp.id(1041334381279806798)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_SELECTED_COUNTRIES_FROM_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041332376022806798)
,p_event_id=>wwv_flow_imp.id(1041334381279806798)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_SELECTED_COUNTRIES_FROM_CARD'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041332832509806798)
,p_event_id=>wwv_flow_imp.id(1041334381279806798)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_SELECTED_COUNTRIES_FROM_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041333822850806798)
,p_event_id=>wwv_flow_imp.id(1041334381279806798)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("P19_CARD_SHUTTLE")) {',
'    apex.item("APPLY_ACTION_BUTTON").enable();',
'} else {',
'    apex.item("APPLY_ACTION_BUTTON").disable();',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041326898244806794)
,p_name=>'New_1'
,p_event_sequence=>320
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_CARD_COUNT'
,p_condition_element=>'P19_CARD_COUNT'
,p_triggering_condition_type=>'GREATER_THAN_OR_EQUAL'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041326329938806793)
,p_event_id=>wwv_flow_imp.id(1041326898244806794)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_JUMP_TO_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041325841682806793)
,p_event_id=>wwv_flow_imp.id(1041326898244806794)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_JUMP_TO_CARD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041325507304806793)
,p_name=>'Toggle Jump To Card Visibility'
,p_event_sequence=>330
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(540061366066099831)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041324996750806793)
,p_event_id=>wwv_flow_imp.id(1041325507304806793)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Check if there are any cards in the region',
'var cardContainers = $(".cards-regions .card-container");',
'if (cardContainers.length > 0) {',
'    // Show the "Jump to Card" item if cards exist',
'    apex.item("P19_JUMP_TO_CARD_CONTAINER").enable();',
'} else {',
'    // Hide the "Jump to Card" item if no cards exist',
'    apex.item("P19_JUMP_TO_CARD_CONTAINER").disable();',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041324608943806793)
,p_name=>'New_2'
,p_event_sequence=>340
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_CARD_SHUTTLE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041324090356806792)
,p_event_id=>wwv_flow_imp.id(1041324608943806793)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  l_count NUMBER;',
'BEGIN',
'  SELECT COUNT(*) INTO l_count',
'  FROM (',
'    SELECT 1 FROM t_ms_suche_split ',
'    WHERE card_number IN (',
'      SELECT column_value ',
'      FROM apex_string.split(:P19_CARD_SHUTTLE,'':'')',
'    ) ',
'    AND SUCHEID = :P19_SEARCH_SELECTION',
'    AND MEILENSTEIN = :P19_MILESTONE_SELECTION',
'    GROUP BY card_number ',
'    HAVING COUNT(*) > 1',
'  );',
'  ',
'  IF l_count > 0 THEN',
'    :P19_HAS_MERGED_CARDS := ''Y'';',
'  ELSE',
'    :P19_HAS_MERGED_CARDS := ''N'';',
'  END IF;',
'END;'))
,p_attribute_02=>'P19_CARD_SHUTTLE,P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION'
,p_attribute_03=>'P19_HAS_MERGED_CARDS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041342917185806804)
,p_name=>'Save FilterandView Settings'
,p_event_sequence=>350
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1041378187633806982)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041342503074806802)
,p_event_id=>wwv_flow_imp.id(1041342917185806804)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P19_MODAL_URL := APEX_PAGE.get_url(',
'    p_page => 462,',
'    p_clear_cache => 462,',
'    p_items => ''P462_DATA,P462_FILTER_VIEW_PAGE'',',
'    p_values => ''\'' || :P19_FILTER_VIEW_PROFILE|| ''\,460'' ',
');'))
,p_attribute_02=>'P19_FILTER_VIEW_PROFILE,G_BENUTZERID'
,p_attribute_03=>'P19_MODAL_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041341973755806802)
,p_event_id=>wwv_flow_imp.id(1041342917185806804)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window.location = $v(''P19_MODAL_URL'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041341599898806802)
,p_name=>'Manage FilterandView Settings'
,p_event_sequence=>360
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1041377764648806979)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041341113121806802)
,p_event_id=>wwv_flow_imp.id(1041341599898806802)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P19_MODAL_URL := APEX_PAGE.get_url(',
'    p_page => 463,',
'    p_clear_cache => 463,',
'    p_items => ''P463_FILTER_VIEW_PAGE'',',
'    p_values => ''460''',
');',
'',
'UPDATE T_FILTER_VIEW_PROFILE ',
'SET NEW = 0 ',
'WHERE BENUTZERID = :G_BENUTZERID AND PAGE = 460;',
'',
':P19_FILTER_PROFILE_NEW := '''';'))
,p_attribute_02=>'P19_FILTER_PROFILE_NEW'
,p_attribute_03=>'P19_MODAL_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041340607110806802)
,p_event_id=>wwv_flow_imp.id(1041341599898806802)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window.location = $v(''P19_MODAL_URL'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041327760687806794)
,p_name=>'Pass Data to Filter Profile'
,p_event_sequence=>370
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_SEARCH_SELECTION,P19_MILESTONE_SELECTION,P19_FILTER_LAENDERGRUPPE,P19_FILTER_LAND'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041327298263806794)
,p_event_id=>wwv_flow_imp.id(1041327760687806794)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var obj = new Object();',
'obj.search_selection = $v(''P19_SEARCH_SELECTION'');',
'obj.milestone_selection = $v(''P19_MILESTONE_SELECTION'');',
'obj.filter_laendergruppe = $v(''P19_FILTER_LAENDERGRUPPE'');',
'obj.filter_land = $v(''P19_FILTER_LAND'');',
'obj.card_countries = getAllCardCountries();',
'obj.card_numbers = getAllCardNumbers();',
'$s(''P19_FILTER_VIEW_PROFILE'', JSON.stringify(obj));',
'',
'apex.server.process(''DUMMY_PROCESS'', {',
'  pageItems: ''#P19_FILTER_VIEW_PROFILE''',
'}, {',
'  dataType: "text"',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1041323635916806792)
,p_name=>'Dialog Closed Page 463'
,p_event_sequence=>380
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId && this.data.dialogPageId == 463'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1041323126390806792)
,p_event_id=>wwv_flow_imp.id(1041323635916806792)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.submit(''REFRESH'');'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1041351889060806831)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Custom XLSX Export - All Countries Result'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_context apex_exec.t_context;',
'    l_print_config    apex_data_export.t_print_config;',
'    l_export apex_data_export.t_export;',
'    l_name VARCHAR2(255);',
'    lTitle varchar2(250);',
'BEGIN',
'    -- Get user name',
'    SELECT b.nachname || '' '' || b.vorname',
'    INTO l_name',
'    FROM t_benutzer b',
'    WHERE benutzerid = :G_BENUTZERID;',
'    ',
'    -- Set title',
unistr('    lTitle := ''Aller L\00E4nder - Vorschriften'';'),
'    ',
'    -- Create query context',
'    l_context := apex_exec.open_query_context(',
'        p_location => apex_exec.c_location_local_db,',
'        p_sql_query => q''[',
'            WITH search_countries AS (',
'                SELECT ',
'                    sucheid,',
'                    to_number(COLUMN_VALUE) as landid',
'                FROM t_suche_json,',
'                TABLE(apex_string.split(',
'                    json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                    '':''',
'                ))',
'                WHERE ',
'                    sucheid = v(''P19_SEARCH_SELECTION'') ',
'                    AND BENUTZERID = v(''G_BENUTZERID'')',
'            )',
'            SELECT DISTINCT',
'                -- sc.sucheid,',
'                -- ms.VORSCHRIFTID,',
'                ',
'                ms.landnummer||'' - ''||ms.landbezeichnung AS Landbezeichnung,',
'                ms.vorschriftnummer as Vorschriftennummer',
'                ',
'            FROM search_countries sc',
'            LEFT JOIN T_MS_SUCHERGEBNISS ms ON (',
'                ms.sucheid = sc.sucheid ',
'                AND ms.landid = sc.landid',
'                AND ms.meilenstein =  v(''P19_MILESTONE_SELECTION'')',
'                AND sc.landid NOT IN (',
'                    SELECT column_value ',
'                    FROM table(apex_string.split_numbers(v(''P19_FILTER_LAND''), '':''))',
'                )',
'            )',
'            WHERE VORSCHRIFTID IS NOT NULL ',
'            GROUP BY ',
'                ms.vorschriftnummer,',
'                ms.VORSCHRIFTID,',
'                ms.landnummer,',
'                ms.landbezeichnung,',
'                sc.sucheid',
'            ORDER BY ',
'                Landbezeichnung,',
'                Vorschriftennummer',
'        ]''',
'    );',
'    ',
'    -- Configure print settings',
'    l_print_config := apex_data_export.get_print_config(',
'        p_page_header => lTitle,',
'        p_header_font_family => ''Audi Type'',',
'        p_header_font_size => 10,',
'        p_body_font_family => ''Audi Type'',',
'        p_body_font_size => 10,',
'        p_border_width => 0.5,',
'        p_page_footer_font_family => ''Audi Type'',',
'        p_page_footer_font_size => 10,',
'        p_header_bg_color => ''#D0D0D0''',
'    );',
'',
'',
'',
'',
'        ',
'    -- Create export',
'    l_export := apex_data_export.export(',
'        p_context => l_context,',
'        p_print_config => l_print_config,',
'        p_format => apex_data_export.c_format_xlsx,',
unistr('        p_file_name => ''Aller L\00E4nder - Vorschriften'' || ''-'' || l_name || ''-'' || TO_CHAR(SYSDATE, ''DD.MM.YYYY HH24:MI:SS'') || ''.xlsx'''),
'    );',
'    ',
'    -- Close context and download',
'    apex_exec.close(l_context);',
'    apex_data_export.download(p_export => l_export);',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_exec.close(l_context);',
'        RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1041362992845806874)
,p_internal_uid=>2630860426838581404
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_context apex_exec.t_context;',
'    l_print_config    apex_data_export.t_print_config;',
'    l_export apex_data_export.t_export;',
'    l_name VARCHAR2(255);',
'    lTitle varchar2(250);',
'BEGIN',
'    -- Get user name',
'    SELECT b.nachname || '' '' || b.vorname',
'    INTO l_name',
'    FROM t_benutzer b',
'    WHERE benutzerid = :G_BENUTZERID;',
'',
'    -- Set title',
unistr('    lTitle := ''Aller L\00E4nder - Vorschriften'';'),
'',
'    -- Create query context',
'    l_context := apex_exec.open_query_context(',
'        p_location => apex_exec.c_location_local_db,',
'        p_sql_query => q''[',
'            WITH search_countries AS (',
'                SELECT ',
'                    DISTINCT sucheid,',
'                    to_number(COLUMN_VALUE) as landid',
'                FROM t_suche_json,',
'                TABLE(apex_string.split(',
'                    json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                    '':''',
'                ))',
'                WHERE BENUTZERID = ]'' || v(''G_BENUTZERID'') || q''[',
'            )',
'            SELECT DISTINCT',
'                ms.landnummer||'' - ''||ms.landbezeichnung AS Landbezeichnung,   ',
'                ms.vorschriftnummer as Vorschriftennummer',
'            FROM search_countries sc',
'            LEFT JOIN T_MS_SUCHERGEBNISS ms ON (',
'                ms.sucheid = sc.sucheid ',
'                AND ms.landid = sc.landid',
'                AND sc.landid NOT IN (',
'                    SELECT column_value ',
'                    FROM table(apex_string.split_numbers('']'' || v(''P460_FILTER_LAND'') || q''['', '':''))',
'                )',
'            )',
'            WHERE VORSCHRIFTID IS NOT NULL ',
'            GROUP BY ',
'                ms.vorschriftnummer,',
'                ms.VORSCHRIFTID,',
'                ms.landnummer,',
'                ms.landbezeichnung,',
'                sc.sucheid',
'            ORDER BY ',
'                Landbezeichnung,',
'                Vorschriftennummer',
'        ]''',
'    );',
'',
'    -- Configure print settings',
'    l_print_config := apex_data_export.get_print_config(',
'        p_page_header => lTitle,',
'        p_header_font_family => ''Audi Type'',',
'        p_header_font_size => 10,',
'        p_body_font_family => ''Audi Type'',',
'        p_body_font_size => 10,',
'        p_border_width => 0.5,',
'        p_page_footer_font_family => ''Audi Type'',',
'        p_page_footer_font_size => 10,',
'        p_header_bg_color => ''#D0D0D0''',
'    );',
'        ',
'    -- Create export',
'    l_export := apex_data_export.export(',
'        p_context => l_context,',
'        p_print_config => l_print_config,',
'        p_format => apex_data_export.c_format_xlsx,',
unistr('        p_file_name => ''Aller L\00E4nder - Vorschriften'' || ''-'' || l_name || ''-'' || TO_CHAR(SYSDATE, ''DD.MM.YYYY HH24:MI:SS'') || ''.xlsx'''),
'    );',
'',
'    -- Close context and download',
'    apex_exec.close(l_context);',
'    apex_data_export.download(p_export => l_export);',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_exec.close(l_context);',
'        RAISE;',
'END;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1041347869521806825)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Fill Items in Page Load '
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    SELECT',
'           JSON_VALUE(DATA, ''$.search_selection''),',
'           JSON_VALUE(DATA, ''$.milestone_selection''),',
'           JSON_VALUE(DATA, ''$.filter_laendergruppe''),',
'           JSON_VALUE(DATA, ''$.filter_land''),',
'           JSON_VALUE(DATA, ''$.card_countries''),',
'           JSON_VALUE(DATA, ''$.card_numbers''),',
'           name',
'    INTO :P19_SEARCH_SELECTION,',
'         :P19_MILESTONE_SELECTION,',
'         :P19_FILTER_LAENDERGRUPPE,',
'         :P19_FILTER_LAND,',
'         :P19_SAVED_CARD_COUNTRIES,',
'         :P19_SAVED_CARD_NUMBERS,',
'         :P19_START_PROFILE',
'    FROM T_FILTER_VIEW_PROFILE',
'    WHERE START_PROFILE = 1 ',
'    AND BENUTZERID = :G_BENUTZERID ',
'    AND PAGE = 460;',
'',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        :P19_SEARCH_SELECTION := null;',
'        :P19_MILESTONE_SELECTION := null;',
'        :P19_FILTER_LAENDERGRUPPE := null;',
'        :P19_FILTER_LAND := null;',
'        :P19_START_PROFILE := null;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2630864446377581410
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1041347083634806824)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Filter Profile Settings'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'BEGIN',
'    IF :P19_FILTER_VIEW_PROFILE_ID IS NOT NULL THEN',
'        SELECT ',
'           JSON_VALUE(DATA, ''$.search_selection''),',
'           JSON_VALUE(DATA, ''$.milestone_selection''),',
'           JSON_VALUE(DATA, ''$.filter_laendergruppe''),',
'           JSON_VALUE(DATA, ''$.filter_land''),',
'           JSON_VALUE(DATA, ''$.card_countries''),',
'           JSON_VALUE(DATA, ''$.card_numbers''),',
'           NAME',
'        INTO ',
'           :P19_SEARCH_SELECTION,',
'           :P19_MILESTONE_SELECTION,',
'           :P19_FILTER_LAENDERGRUPPE,',
'           :P19_FILTER_LAND,',
'           :P19_SAVED_CARD_COUNTRIES,',
'           :P19_SAVED_CARD_NUMBERS,',
'           :P19_START_PROFILE',
'        FROM T_FILTER_VIEW_PROFILE',
'        WHERE FILTER_VIEW_PROFILEID = :P19_FILTER_VIEW_PROFILE_ID',
'        AND BENUTZERID = :G_BENUTZERID',
'        AND PAGE = ''460'';',
'        ',
'        :P19_REFRESH_CARDS := ''Y'';',
'        -- Clear the profile ID after loading it',
'        -- :P19_FILTER_VIEW_PROFILE_ID := NULL;',
'    END IF;',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        NULL;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2630865232264581411
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1041351487958806830)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLaenderShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'DECLARE',
'    lSelected            VARCHAR2(2000) := apex_application.g_x01;  -- List of selected items',
'    lLaendergruppe       VARCHAR2(2000) := apex_application.g_x02;  -- List of country groups',
'    lStartdatumTyp       NUMBER := NULL;  -- Type of start date',
'    lSuche               VARCHAR2(2000) := apex_application.g_x03;  -- Selected Search',
'    lMilestoneSelection  VARCHAR2(2000) := apex_application.g_x04;   -- Selected milestone',
'BEGIN',
'    -- Open the JSON array to start constructing the response',
'    apex_json.open_array;',
'',
'    -- Loop through the selected countries that match the conditions',
'    FOR l IN (',
'        SELECT ',
'            b_nummer || '' - '' || CASE ',
'                WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'                ELSE land_eng',
'            END AS d,  -- Display value',
'            landid      -- Return value (land ID)',
'        FROM ',
'            t_land',
'        WHERE ',
'            -- Exclude selected countries based on lSelected',
'            landid NOT IN (SELECT column_value FROM table(apex_string.split_numbers(lSelected, '':'')))',
'            ',
'            -- Filter by Laendergruppe (country group), if specified',
'            AND (',
'                lLaendergruppe IS NULL ',
'                OR landid IN (',
'                    SELECT landid ',
'                    FROM t_land_ref_laendergruppe ',
'                    WHERE laendergruppeid IN (',
'                        SELECT column_value ',
'                        FROM table(apex_string.split_numbers(lLaendergruppe, '':''))',
'                    )',
'                )',
'            )',
'            ',
'            -- Ensure the country is part of the selected search and milestone',
'            AND EXISTS (',
'                SELECT 1',
'                FROM t_suche_json tsj,',
'                     json_table(tsj.suchdaten, ''$[*]'' COLUMNS (',
'                         laender VARCHAR2(4000) PATH ''$.LAENDER'',',
'                         meilenstein VARCHAR2(4000) PATH ''$.MEILENSTEIN''',
'                     )) jt',
'                WHERE tsj.sucheid = lSuche',
'                AND tsj.BENUTZERID = :G_BENUTZERID',
'                AND landid IN (',
'                    SELECT TO_NUMBER(COLUMN_VALUE)',
'                    FROM TABLE(apex_string.split(jt.laender, '':''))',
'                )',
'              AND LANDID NOT IN (SELECT LANDID FROM T_MS_SUCHE_SPLIT WHERE BENUTZERID=:G_BENUTZERID AND SUCHEID	=lSuche AND MEILENSTEIN =lMilestoneSelection )',
'                AND (',
'                    lMilestoneSelection IS NULL',
'                    OR jt.meilenstein = lMilestoneSelection',
'                )',
'            )',
'            ',
'            -- filtering by startdatum_typ',
'            AND (',
'                lStartdatumTyp IS NULL',
'                OR startdatum_typ = lStartdatumTyp',
'            )',
'        ',
'        -- Order results by binary sort of the country number',
'        ORDER BY ',
'            NLSSORT(b_nummer, ''NLS_SORT=BINARY_AI'')',
'    ) LOOP',
'        -- Write each country to the JSON response',
'        apex_json.open_object;',
'        apex_json.write(''d'', l.d);  -- Display value',
'        apex_json.write(''r'', l.landid);  -- Return value (land ID)',
'        apex_json.close_object;',
'    END LOOP;',
'',
'    -- Close the JSON array',
'    apex_json.close_array;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2630860827940581405
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected      VARCHAR2(2000) := apex_application.g_x01;  -- List of selected items',
'    lLaendergruppe VARCHAR2(2000) := apex_application.g_x02;  -- List of country groups',
'    lStartdatumTyp NUMBER := NULL;  -- Type of start date',
'    lSuche         NUMBER := apex_application.g_x03;  -- Search number',
'',
'BEGIN',
'    -- Open the JSON array to start constructing the response',
'    apex_json.open_array;',
'',
'    -- Loop through the selected countries that match the conditions',
'    FOR l IN (',
'        SELECT ',
'            b_nummer || '' - '' || CASE ',
'                WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'                ELSE land_eng',
'            END AS d,  -- Display value',
'            landid      -- Return value (land ID)',
'        FROM ',
'            t_land',
'        WHERE ',
'            -- Exclude selected countries based on lSelected',
'            landid NOT IN (SELECT column_value FROM table(apex_string.split_numbers(lSelected, '':'')))',
'            ',
'            -- Filter by Laendergruppe (country group), if specified',
'            AND (',
'                lLaendergruppe IS NULL ',
'                OR landid IN (',
'                    SELECT landid ',
'                    FROM t_land_ref_laendergruppe ',
'                    WHERE laendergruppeid IN (',
'                        SELECT column_value ',
'                        FROM table(apex_string.split_numbers(lLaendergruppe, '':''))',
'                    )',
'                )',
'            )',
'            ',
'            -- Ensure the country is part of the selected search (suche)',
'            AND landid IN (',
'                SELECT ',
'                    TO_NUMBER(COLUMN_VALUE) AS landid',
'                FROM ',
'                    t_suche_json,',
'                    TABLE(apex_string.split(',
'                        json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                        '':''',
'                    ))',
'                WHERE ',
'                    BENUTZERID = :G_BENUTZERID  -- User ID',
'                    AND sucheid = :P460_SEARCH_SELECTION  -- Selected search ID',
'            )',
'',
'            -- filtering by startdatum_typ',
'            AND (',
'                lStartdatumTyp IS NULL',
'                OR startdatum_typ = lStartdatumTyp',
'            )',
'        ',
'        -- Order results by binary sort of the country number',
'        ORDER BY ',
'            NLSSORT(b_nummer, ''NLS_SORT=BINARY_AI'')',
'    ) LOOP',
'        -- Write each country to the JSON response',
'        apex_json.open_object;',
'        apex_json.write(''d'', l.d);  -- Display value',
'        apex_json.write(''r'', l.landid);  -- Return value (land ID)',
'        apex_json.close_object;',
'    END LOOP;',
'',
'    -- Close the JSON array',
'    apex_json.close_array;',
'',
'END;',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1041350654560806829)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'INSERT_CODE_AJAX'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
'',
'',
'DECLARE',
'    lSelected            VARCHAR2(2000) := apex_application.g_x01;  -- List of selected items',
'    lLaendergruppe       VARCHAR2(2000) := apex_application.g_x02;  -- List of country groups',
'    lStartdatumTyp       NUMBER := NULL;  -- Type of start date',
'    lSuche               VARCHAR2(2000) := apex_application.g_x03;  -- Selected Search',
'    lMilestoneSelection  VARCHAR2(2000) := apex_application.g_x04;   -- Selected milestone',
'     L_CARD NUMBER;',
'    l_count NUMBER;',
'    l_selected_count NUMBER;',
'    l_landid_exists BOOLEAN := FALSE;',
'    l_card_number number;',
'    begin',
'    -- Open the JSON array to start constructing the response',
'    apex_json.open_array;',
'  ',
'BEGIN    ',
'',
'    SELECT COUNT(column_value) INTO l_selected_count ',
'    FROM TABLE(apex_string.split_numbers(lSelected, '':''));',
'    ',
'    IF l_selected_count = 0 THEN',
'        apex_error.add_error(',
unistr('            p_message => ''Bitte w\00E4hlen Sie mindestens ein Land aus.'','),
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'      --  RETURN;',
'   -- END IF;',
'else',
'    -- Check if these lands already exist in a card',
'    begin',
' SELECT distinct card_number INTO l_card_number ',
'        FROM t_ms_suche_split ',
'        WHERE sucheid = lSuche ',
'        AND meilenstein = lMilestoneSelection ',
'        AND landid IN (',
'            SELECT column_value ',
'            FROM TABLE(apex_string.split_numbers(lSelected, '':''))',
'        );',
'   exception when no_data_found then l_card_number :=0;',
'   end;',
'  --deleting existing countries for selected card',
'   if  l_card_number>0 then ',
'   delete from t_ms_suche_split where card_number =l_card_number and  BENUTZERID = :G_BENUTZERID;',
'   end if;',
'',
'    BEGIN',
'        SELECT COUNT(*) INTO l_count ',
'        FROM t_ms_suche_split ',
'        WHERE sucheid = lSuche ',
'        AND meilenstein = lMilestoneSelection ',
'        AND landid IN (',
'            SELECT column_value ',
'            FROM TABLE(apex_string.split_numbers(lSelected, '':''))',
'        );',
'    EXCEPTION ',
'        WHEN NO_DATA_FOUND THEN ',
'            l_count := 0;',
'    END;',
'',
'    -- Only proceed if countries aren''t already in a card',
'    IF l_count = 0 THEN ',
'        -- Get next card number',
'        SELECT NVL(MAX(card_number) + 1, 1) ',
'        INTO L_CARD ',
'        FROM t_ms_suche_split ',
'        WHERE BENUTZERID = :G_BENUTZERID;',
'',
'        -- Insert data',
'        FOR i IN (',
'            WITH search_countries AS (',
'                SELECT ',
'                    sucheid,',
'                    to_number(COLUMN_VALUE) AS landid',
'                FROM t_suche_json,',
'                TABLE(apex_string.split(',
'                    json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                    '':''',
'                ))',
'                WHERE BENUTZERID = :G_BENUTZERID',
'                AND sucheid = lSuche ',
'            )',
'            SELECT DISTINCT',
'                ms.sucheid AS sucheid,',
'                lMilestoneSelection AS meilenstein,',
'                sc.landid AS landid',
'            FROM search_countries sc',
'            LEFT JOIN T_MS_SUCHERGEBNISS ms ON (',
'                ms.sucheid = sc.sucheid ',
'                AND ms.landid = sc.landid',
'                AND sc.landid IN (',
'                    SELECT column_value ',
'                    FROM TABLE(apex_string.split_numbers(lSelected, '':''))',
'                )',
'            )',
'            WHERE VORSCHRIFTID IS NOT NULL',
'        ) LOOP',
'           -- l_landid_exists := TRUE;',
'            ',
'            INSERT INTO t_ms_suche_split (',
'                sucheid,',
'                meilenstein,',
'                card_number,',
'                landid,',
'                BENUTZERID,',
'                letzte_aenderung_datum,',
'                letzte_aenderung_benutzerid',
'            )',
'            VALUES (',
'                i.sucheid,',
'                i.meilenstein,',
'                L_CARD,',
'                i.landid,',
'                :G_BENUTZERID,',
'                SYSDATE,',
'                :G_BENUTZERID',
'            );',
'        END LOOP;',
'',
'        -- Check if any records were actually inserted',
'      /*  IF NOT l_landid_exists THEN',
'            apex_error.add_error(',
'                p_message => ''No valid regulations found for selected countries.'',',
'                p_display_location => apex_error.c_inline_in_notification',
'            );',
'            RETURN;',
'        END IF;',
'*/',
'        -- Success message',
'        apex_application.g_print_success_message := ',
'            ''Karte '' || L_CARD || '' erfolgreich erstellt.'';',
'            ',
'    ELSE',
'        apex_error.add_error(',
unistr('            p_message => ''Ausgew\00E4hlte L\00E4nder sind bereits in einer Karte enthalten.'','),
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'    end if;',
'end if;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_error.add_error(',
'            p_message => ''Fehler beim Erstellen der Karte: '' || SQLERRM,',
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'        RAISE;',
' end; ',
'    -- Close the JSON array',
'   apex_json.close_array;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2630861661338581406
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected            VARCHAR2(2000) := apex_application.g_x01;  -- List of selected items',
'    lLaendergruppe       VARCHAR2(2000) := apex_application.g_x02;  -- List of country groups',
'    lStartdatumTyp       NUMBER := NULL;  -- Type of start date',
'    lSuche               VARCHAR2(2000) := apex_application.g_x03;  -- Selected Search',
'    lMilestoneSelection  VARCHAR2(2000) := apex_application.g_x04;   -- Selected milestone',
'     L_CARD NUMBER;',
'    l_count NUMBER;',
'    l_selected_count NUMBER;',
'    l_landid_exists BOOLEAN := FALSE;',
'    l_card_number number;',
'    begin',
'    -- Open the JSON array to start constructing the response',
'    apex_json.open_array;',
'  ',
'BEGIN    ',
'',
'    SELECT COUNT(column_value) INTO l_selected_count ',
'    FROM TABLE(apex_string.split_numbers(lSelected, '':''));',
'    ',
'    IF l_selected_count = 0 THEN',
'        apex_error.add_error(',
'            p_message => ''Please select at least one country.'',',
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'      --  RETURN;',
'   -- END IF;',
'else',
'    -- Check if these lands already exist in a card',
'    begin',
' SELECT distinct card_number INTO l_card_number ',
'        FROM t_ms_suche_split ',
'        WHERE sucheid = lSuche ',
'        AND meilenstein = lMilestoneSelection ',
'        AND landid IN (',
'            SELECT column_value ',
'            FROM TABLE(apex_string.split_numbers(lSelected, '':''))',
'        );',
'   exception when no_data_found then l_card_number :=0;',
'   end;',
'  --deleting existing countries for selected card',
'   if  l_card_number>0 then ',
'   delete from t_ms_suche_split where card_number =l_card_number and  BENUTZERID = :G_BENUTZERID;',
'   end if;',
'',
'    BEGIN',
'        SELECT COUNT(*) INTO l_count ',
'        FROM t_ms_suche_split ',
'        WHERE sucheid = lSuche ',
'        AND meilenstein = lMilestoneSelection ',
'        AND landid IN (',
'            SELECT column_value ',
'            FROM TABLE(apex_string.split_numbers(lSelected, '':''))',
'        );',
'    EXCEPTION ',
'        WHEN NO_DATA_FOUND THEN ',
'            l_count := 0;',
'    END;',
'',
'    -- Only proceed if countries aren''t already in a card',
'    IF l_count = 0 THEN ',
'        -- Get next card number',
'        SELECT NVL(MAX(card_number) + 1, 1) ',
'        INTO L_CARD ',
'        FROM t_ms_suche_split ',
'        WHERE BENUTZERID = :G_BENUTZERID;',
'',
'        -- Insert data',
'        FOR i IN (',
'            WITH search_countries AS (',
'                SELECT ',
'                    sucheid,',
'                    to_number(COLUMN_VALUE) AS landid',
'                FROM t_suche_json,',
'                TABLE(apex_string.split(',
'                    json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                    '':''',
'                ))',
'                WHERE BENUTZERID = :G_BENUTZERID',
'                AND sucheid = lSuche ',
'            )',
'            SELECT DISTINCT',
'                ms.sucheid AS sucheid,',
'                lMilestoneSelection AS meilenstein,',
'                sc.landid AS landid',
'            FROM search_countries sc',
'            LEFT JOIN T_MS_SUCHERGEBNISS ms ON (',
'                ms.sucheid = sc.sucheid ',
'                AND ms.landid = sc.landid',
'                AND sc.landid IN (',
'                    SELECT column_value ',
'                    FROM TABLE(apex_string.split_numbers(lSelected, '':''))',
'                )',
'            )',
'            WHERE VORSCHRIFTID IS NOT NULL',
'        ) LOOP',
'           -- l_landid_exists := TRUE;',
'            ',
'            INSERT INTO t_ms_suche_split (',
'                sucheid,',
'                meilenstein,',
'                card_number,',
'                landid,',
'                BENUTZERID,',
'                letzte_aenderung_datum,',
'                letzte_aenderung_benutzerid',
'            )',
'            VALUES (',
'                i.sucheid,',
'                i.meilenstein,',
'                L_CARD,',
'                i.landid,',
'                :G_BENUTZERID,',
'                SYSDATE,',
'                :G_BENUTZERID',
'            );',
'        END LOOP;',
'',
'        -- Check if any records were actually inserted',
'      /*  IF NOT l_landid_exists THEN',
'  '))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1041350231152806828)
,p_process_sequence=>40
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'HANDLE_CARD_ACTION'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   l_first_card        NUMBER;',
'   l_new_card         NUMBER;',
'   l_counter          NUMBER := 0;',
'   l_remaining_countries NUMBER;',
'   l_total_rows       NUMBER;',
'   l_action           VARCHAR2(50) := apex_application.g_x01;',
'   l_card_numbers     VARCHAR2(4000) := apex_application.g_x02;',
'   l_country_ids      VARCHAR2(4000) := apex_application.g_x03;',
'BEGIN',
'   dbms_output.put_line(''=== Startkarte Aktion ==='');',
'   dbms_output.put_line(''Aktion: '' || l_action);',
'   dbms_output.put_line(''Karten-Nummern: '' || l_card_numbers);',
unistr('   dbms_output.put_line(''L\00E4nder-IDs: '' || l_country_ids);'),
'   ',
'   CASE l_action',
'       WHEN ''DELETE_CARD'' THEN',
'           DELETE FROM t_ms_suche_split',
'           WHERE CARD_NUMBER IN (',
'               SELECT column_value',
'               FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'           )',
'           AND SUCHEID = :P19_SEARCH_SELECTION',
'           AND MEILENSTEIN = :P19_MILESTONE_SELECTION;',
'',
'           apex_json.open_object;',
'           apex_json.write(''status'', ''success'');',
unistr('           apex_json.write(''message'', ''Ausgew\00E4hlte Karten erfolgreich gel\00F6scht'');'),
'           apex_json.close_object;',
'',
'       WHEN ''DELETE_COUNTRIES'' THEN',
'           SELECT COUNT(*)',
'           INTO l_remaining_countries',
'           FROM t_ms_suche_split',
'           WHERE card_number IN (',
'               SELECT column_value ',
'               FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'           )',
'           AND SUCHEID = :P19_SEARCH_SELECTION',
'           AND MEILENSTEIN = :P19_MILESTONE_SELECTION',
'           AND landid NOT IN (',
'               SELECT column_value',
'               FROM table(apex_string.split_numbers(l_country_ids, '':''))',
'           );',
'',
unistr('           dbms_output.put_line(''Verbleibende L\00E4nder: '' || l_remaining_countries);'),
'',
'           IF l_remaining_countries > 0 THEN',
'               DELETE FROM t_ms_suche_split',
'               WHERE card_number IN (',
'                   SELECT column_value',
'                   FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'               )',
'               AND landid IN (',
'                   SELECT column_value',
'                   FROM table(apex_string.split_numbers(l_country_ids, '':''))',
'               )',
'               AND SUCHEID = :P19_SEARCH_SELECTION',
'               AND MEILENSTEIN = :P19_MILESTONE_SELECTION;',
'',
unistr('               dbms_output.put_line(''L\00E4nder gel\00F6scht: '' || SQL%ROWCOUNT);'),
'',
'               apex_json.open_object;',
'               apex_json.write(''status'', ''success'');',
unistr('               apex_json.write(''message'', ''Ausgew\00E4hlte L\00E4nder erfolgreich gel\00F6scht'');'),
'               apex_json.close_object;',
'           ELSE',
'               apex_json.open_object;',
'               apex_json.write(''status'', ''error'');',
unistr('               apex_json.write(''message'', ''Es k\00F6nnen nicht alle L\00E4nder von einer Karte gel\00F6scht werden. Verwenden Sie stattdessen Karte l\00F6schen.'');'),
'               apex_json.close_object;',
'           END IF;',
'',
'       WHEN ''MERGE_CARD'' THEN',
'           SELECT COUNT(*) INTO l_total_rows',
'           FROM t_ms_suche_split',
'           WHERE CARD_NUMBER IN (',
'               SELECT column_value',
'               FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'           )',
'           AND SUCHEID = :P19_SEARCH_SELECTION',
'           AND MEILENSTEIN = :P19_MILESTONE_SELECTION;',
'           ',
unistr('           dbms_output.put_line(''Zeilen vor der Zusammenf\00FChrung: '' || l_total_rows);'),
'           ',
'           SELECT MIN(column_value)',
'           INTO l_first_card',
'           FROM table(apex_string.split_numbers(l_card_numbers, '':''));',
'           ',
'           dbms_output.put_line(''Ziel-Kartennummer: '' || l_first_card);',
'           ',
'           UPDATE t_ms_suche_split',
'           SET CARD_NUMBER = l_first_card',
'           WHERE CARD_NUMBER IN (',
'               SELECT column_value',
'               FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'           )',
'           AND SUCHEID = :P19_SEARCH_SELECTION',
'           AND MEILENSTEIN = :P19_MILESTONE_SELECTION;',
'           ',
unistr('           dbms_output.put_line(''Bei der Zusammenf\00FChrung aktualisierte Zeilen: '' || SQL%ROWCOUNT);'),
'',
'           apex_json.open_object;',
'           apex_json.write(''status'', ''success'');',
unistr('           apex_json.write(''message'', ''Karten erfolgreich zusammengef\00FChrt'');'),
'           apex_json.close_object;',
'',
'       WHEN ''UNMERGE_CARD'' THEN',
'           SELECT NVL(MAX(CARD_NUMBER), 0) + 1',
'           INTO l_new_card',
'           FROM t_ms_suche_split;',
'           ',
'           dbms_output.put_line(''Beginn der Aufhebung der Sperrung mit neuer Kartennummer: '' || l_new_card);',
'           ',
'           FOR r IN (',
'               SELECT DISTINCT landid,',
'                      ROW_NUMBER() OVER (ORDER BY landid) - 1 as rn',
'               FROM t_ms_suche_split ',
'               WHERE CARD_NUMBER IN (',
'                   SELECT column_value',
'                   FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'               )',
'               AND SUCHEID = :P19_SEARCH_SELECTION',
'               AND MEILENSTEIN = :P19_MILESTONE_SELECTION',
'           ) LOOP',
'               IF r.rn > 0 THEN',
'                   UPDATE t_ms_suche_split',
'                   SET CARD_NUMBER = l_new_card + r.rn - 1',
'                   WHERE LANDID = r.landid',
'                   AND SUCHEID = :P19_SEARCH_SELECTION',
'                   AND MEILENSTEIN = :P19_MILESTONE_SELECTION;',
'                   ',
'                   dbms_output.put_line(''Updated landid '' || r.landid || '' to card '' || (l_new_card + r.rn - 1));',
'               END IF;',
'           END LOOP;',
'',
'           apex_json.open_object;',
'           apex_json.write(''status'', ''success'');',
'           apex_json.write(''message'', ''Karten erfolgreich entwertet'');',
'           apex_json.close_object;',
'',
'       WHEN ''UNMERGE_COUNTRIES'' THEN',
'           -- Get next available card number',
'           SELECT NVL(MAX(CARD_NUMBER), 0) + 1',
'           INTO l_new_card',
'           FROM t_ms_suche_split;',
'           ',
'           dbms_output.put_line(''Starting selective unmerge with new card number: '' || l_new_card);',
'           ',
'           -- Verify we have countries to unmerge',
'           IF l_country_ids IS NULL THEN',
'               apex_json.open_object;',
'               apex_json.write(''status'', ''error'');',
unistr('               apex_json.write(''message'', ''Bitte w\00E4hlen Sie die L\00E4nder aus, deren Zusammenf\00FChrung Sie aufheben m\00F6chten'');'),
'               apex_json.close_object;',
'               RETURN;',
'           END IF;',
'           ',
'           -- Count selected countries for unmerge',
'           l_counter := 0;',
'           FOR r IN (',
'               SELECT landid,',
'                      ROW_NUMBER() OVER (ORDER BY landid) as rn',
'               FROM t_ms_suche_split ',
'               WHERE card_number IN (',
'                   SELECT column_value',
'                   FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'               )',
'               AND landid IN (',
'                   SELECT column_value',
'                   FROM table(apex_string.split_numbers(l_country_ids, '':''))',
'               )',
'               AND SUCHEID = :P19_SEARCH_SELECTION',
'               AND MEILENSTEIN = :P19_MILESTONE_SELECTION',
'           ) LOOP',
'               -- Move each selected country to its own new card',
'               UPDATE t_ms_suche_split',
'               SET CARD_NUMBER = l_new_card + l_counter,',
'                   LETZTE_AENDERUNG_DATUM = SYSDATE,',
'                   LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'               WHERE LANDID = r.landid',
'               AND SUCHEID = :P19_SEARCH_SELECTION',
'               AND MEILENSTEIN = :P19_MILESTONE_SELECTION;',
'               ',
'               dbms_output.put_line(''Created new card '' || (l_new_card + l_counter) || '' for country '' || r.landid);',
'               l_counter := l_counter + 1;',
'           END LOOP;',
'',
'           IF l_counter > 0 THEN',
'               apex_json.open_object;',
'               apex_json.write(''status'', ''success'');',
unistr('               apex_json.write(''message'', l_counter || '' Aufteilung der L\00E4nder auf neue Karten'');'),
'               apex_json.close_object;',
'           ELSE',
'               apex_json.open_object;',
'               apex_json.write(''status'', ''error'');',
unistr('               apex_json.write(''message'', ''Es wurden keine L\00E4nder zur Aufteilung ausgew\00E4hlt'');'),
'               apex_json.close_object;',
'           END IF;',
'   END CASE;',
'   ',
'   COMMIT;',
'   dbms_output.put_line(''=== Action Completed Successfully ==='');',
'   ',
'EXCEPTION',
'   WHEN OTHERS THEN',
'       dbms_output.put_line(''Ein Fehler ist aufgetreten: '' || SQLERRM);',
'       apex_json.open_object;',
'       apex_json.write(''status'', ''error'');',
'       apex_json.write(''message'', ''Error: '' || SQLERRM);',
'       apex_json.close_object;',
'       ROLLBACK;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2630862084746581407
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1041351051359806829)
,p_process_sequence=>100
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DOWNLOAD_CARD_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_query         CLOB;',
'    l_excel         BLOB;',
'    l_filename      VARCHAR2(4000);',
'    l_name          VARCHAR2(4000);',
'    lTitle          VARCHAR2(4000);',
'    l_landids       VARCHAR2(4000) := apex_application.g_x01;',
'    l_count         NUMBER;',
'BEGIN',
'    -- Get user name',
'    SELECT b.nachname || ''_'' || b.vorname',
'      INTO l_name',
'      FROM t_benutzer b',
'     WHERE benutzerid = :G_BENUTZERID;',
'',
'    -- Count the number of selected countries',
'    SELECT COUNT(*)',
'      INTO l_count',
'      FROM t_land l',
'     WHERE l.LANDID IN (',
'           SELECT TO_NUMBER(COLUMN_VALUE)',
'             FROM TABLE(apex_string.split(l_landids, '':''))',
'     );',
'',
'    -- Determine title based on the number of countries selected',
'    IF l_count > 15 THEN',
'        -- More than 15 countries: use a general title',
unistr('        lTitle := ''L\00E4nder Vorschriften'';'),
'    ELSIF l_count >= 5 THEN',
'        -- Between 5 and 15 countries: use only B_NUMMER',
'        SELECT LISTAGG(l.B_NUMMER, ''; '') WITHIN GROUP (ORDER BY l.B_NUMMER)',
'          INTO lTitle',
'          FROM t_land l',
'         WHERE l.LANDID IN (',
'               SELECT TO_NUMBER(COLUMN_VALUE)',
'                 FROM TABLE(apex_string.split(l_landids, '':''))',
'         );',
'    ELSE',
'        -- Fewer than 5 countries: use B_NUMMER and the country name',
'        SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '') WITHIN GROUP (ORDER BY l.B_NUMMER)',
'          INTO lTitle',
'          FROM t_land l',
'         WHERE l.LANDID IN (',
'               SELECT TO_NUMBER(COLUMN_VALUE)',
'                 FROM TABLE(apex_string.split(l_landids, '':''))',
'         );',
'    END IF;',
'',
'    -- Get SQL query with EXCEL format',
'    l_query := country_vorschrift_card_detail(',
'                 p_search_id => :P19_SEARCH_SELECTION,',
'                 p_milestone => :P19_MILESTONE_SELECTION,',
'                 p_landid    => l_landids,',
'                 p_format    => ''EXCEL''',
'               );',
'',
'    -- Generate Excel using emano_report',
'    l_excel := emano_report.fMakeExcelsingleSheet_land(',
'                   aSheetName => ''3MS Gefilterte Ergebnisse'',',
'                   aTitleName => lTitle || '' - Vorschriften'',',
'                   aQuery     => l_query',
'               );',
'',
'    -- Set filename',
'    l_filename := lTitle || '' - Vorschriften'' || ''-'' || l_name || ''-'' ||',
'                  TO_CHAR(SYSDATE, ''DD.MM.YYYY HH24:MI:SS'') || ''.xlsx'';',
'',
'    -- Download file',
'    sys.htp.init;',
'    sys.owa_util.mime_header(''application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'', FALSE);',
'    sys.htp.p(''Content-Length: '' || DBMS_LOB.GETLENGTH(l_excel));',
'    sys.htp.p(''Content-Disposition: attachment; filename="'' || l_filename || ''"'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(l_excel);',
'',
'    apex_application.stop_apex_engine;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        htp.p(''Error: '' || SQLERRM);',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2630861264539581406
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_query         CLOB;',
'    l_excel         BLOB;',
'    l_filename      VARCHAR2(4000);',
'    l_name          VARCHAR2(4000);',
'    lTitle          VARCHAR2(4000);',
'    l_landids       VARCHAR2(4000) := apex_application.g_x01;',
'BEGIN',
'    -- Get user name',
'    SELECT b.nachname || ''_'' || b.vorname',
'    INTO l_name',
'    FROM t_benutzer b',
'    WHERE benutzerid = :G_BENUTZERID;',
'    ',
'    -- Get title with all countries',
'    SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '') WITHIN GROUP (ORDER BY l.B_NUMMER)',
'    INTO lTitle',
'    FROM t_land l',
'    WHERE l.LANDID IN (',
'        SELECT TO_NUMBER(COLUMN_VALUE)',
'        FROM TABLE(apex_string.split(l_landids, '':''))',
'    );',
'    ',
'    -- Get SQL query with EXCEL format',
'    l_query := country_vorschrift_card_detail(',
'        p_search_id => :P460_SEARCH_SELECTION,',
'        p_milestone => :P460_MILESTONE_SELECTION,',
'        p_landid => l_landids,',
'        p_format => ''EXCEL''',
'    );',
'    ',
'    -- Generate Excel using emano_report',
'    l_excel := emano_report.fMakeExcelsingleSheet_land(',
'        aSheetName => ''3MS Filtered Results'',',
'        aTitleName => lTitle || '' - Vorschriften'',',
'        aQuery => l_query',
'    );',
'    ',
'    -- Set filename',
'    -- l_filename := ''Regulations_'' || l_name || ''_'' || ',
'    --               TO_CHAR(SYSDATE, ''YYYYMMDD_HH24MISS'') || ''.xlsx'';',
'    l_filename := lTitle || '' - Vorschriften'' || ''-'' || l_name || ''-'' || ',
'              TO_CHAR(SYSDATE, ''DD.MM.YYYY HH24:MI:SS'') || ''.xlsx'';',
'',
'    ',
'    -- Download',
'    sys.htp.init;',
'    sys.owa_util.mime_header(''application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'', FALSE);',
'    sys.htp.p(''Content-Length: '' || DBMS_LOB.GETLENGTH(l_excel));',
'    sys.htp.p(''Content-Disposition: attachment; filename="'' || l_filename || ''"'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(l_excel);',
'    ',
'    apex_application.stop_apex_engine;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        htp.p(''Error: '' || SQLERRM);',
'END;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1041349821743806827)
,p_process_sequence=>140
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadData'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSearchID NUMBER := apex_application.g_x01;',
'    lMilestone NUMBER := apex_application.g_x02;',
'    lLaender VARCHAR2(2000) := apex_application.g_x03;',
'    cChunkSize CONSTANT NUMBER := 32000;',
'    lChunk VARCHAR2(cChunkSize CHAR);',
'    lDaten CLOB;',
'    lOffset PLS_INTEGER := 1;',
'BEGIN',
'    -- Get regulation data with chunks',
'    lDaten := country_vorschrift_card_detail(',
'        p_search_id => lSearchID,',
'        p_milestone => lMilestone,',
'        P_LANDID => lLaender,',
'        p_format => ''DISPLAY''',
'    );',
'',
'    -- Output data in chunks',
'    LOOP',
'        lChunk := DBMS_LOB.SUBSTR(lDaten, cChunkSize, lOffset);',
'        EXIT WHEN lChunk IS NULL;',
'        HTP.PRN(lChunk);',
'        lOffset := lOffset + cChunkSize;',
'    END LOOP;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_error.add_error(',
'            p_message => ''Error loading data: '' || SQLERRM,',
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2630862494155581408
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare    ',
'    lSearchID number := apex_application.g_x01;  -- List of selected items',
'    lMilestone number := apex_application.g_x02;  -- List of country groups',
'    lLaender varchar2(2000) := apex_application.g_x03;  -- Selected Search',
'    cChunkSize constant number := 32000;',
'    lChunk   varchar2(cChunkSize char);    ',
'',
'    lDaten clob;',
'    lOffset  pls_integer := 1;',
'begin',
'',
'    debug(''ajax1'');',
'',
'    lDaten := country_vorschrift_card_detail(',
'           p_search_id => lSearchID,',
'           p_milestone => lMilestone,',
'           P_LANDID => lLaender,',
'           p_format => ''DISPLAY''',
'       );',
'',
'    debug(''ajax2'');       ',
'',
'--  OWA_UTIL.MIME_HEADER(''application/json'');  ',
'  loop    ',
'    lChunk := dbms_lob.substr(lDaten, cChunkSize, lOffset);    ',
'    exit when lChunk is null;    ',
'    htp.prn(lChunk); -- PRN = don''t terminate each call with newline   ',
'    lOffset := lOffset + cChunkSize;  ',
'  end loop;',
'',
'',
'    debug(''ajax3'');    ',
'',
'    --debug(''ajax'',dbms_lob.getlength(lDaten));',
'',
'end;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1041348700507806825)
,p_process_sequence=>150
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadData_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare    ',
'    lSearchID number := apex_application.g_x01;  -- List of selected items',
'    lMilestone number := apex_application.g_x02;  -- List of country groups',
'    lLaender varchar2(2000) := apex_application.g_x03;  -- Selected Search',
'    cChunkSize constant number := 32000;',
'    lChunk   varchar2(cChunkSize char);    ',
'',
'    lDaten clob;',
'    lOffset  pls_integer := 1;',
'begin',
'',
'    debug(''ajax1'');',
'',
'    lDaten := country_vorschrift_card_detail(',
'           p_search_id => lSearchID,',
'           p_milestone => lMilestone,',
'           P_LANDID => lLaender,',
'           p_format => ''DISPLAY''',
'       );',
'',
'    debug(''ajax2'');       ',
'',
'--  OWA_UTIL.MIME_HEADER(''application/json'');  ',
'  loop    ',
'    lChunk := dbms_lob.substr(lDaten, cChunkSize, lOffset);    ',
'    exit when lChunk is null;    ',
'    htp.prn(lChunk); -- PRN = don''t terminate each call with newline   ',
'    lOffset := lOffset + cChunkSize;  ',
'  end loop;',
'',
'',
'    debug(''ajax3'');    ',
'',
'    --debug(''ajax'',dbms_lob.getlength(lDaten));',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2630863615391581410
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare    ',
'    lSearchID number := apex_application.g_x01;  -- List of selected items',
'    lMilestone number := apex_application.g_x02;  -- List of country groups',
'    lLaender varchar2(2000) := apex_application.g_x03;  -- Selected Search',
'    cChunkSize constant number := 32000;',
'    lChunk   varchar2(cChunkSize char);    ',
'',
'    lDaten clob;',
'    lOffset  pls_integer := 1;',
'begin',
'',
'    debug(''ajax1'');',
'',
'    lDaten := country_vorschrift_card_detail(',
'           p_search_id => lSearchID,',
'           p_milestone => lMilestone,',
'           P_LANDID => lLaender,',
'           p_format => ''DISPLAY''',
'       );',
'',
'    debug(''ajax2'');       ',
'',
'--  OWA_UTIL.MIME_HEADER(''application/json'');  ',
'  loop    ',
'    lChunk := dbms_lob.substr(lDaten, cChunkSize, lOffset);    ',
'    exit when lChunk is null;    ',
'    htp.prn(lChunk); -- PRN = don''t terminate each call with newline   ',
'    lOffset := lOffset + cChunkSize;  ',
'  end loop;',
'',
'',
'    debug(''ajax3'');    ',
'',
'    --debug(''ajax'',dbms_lob.getlength(lDaten));',
'',
'end;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1041349482786806826)
,p_process_sequence=>160
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_CARD_CONTENT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_landids VARCHAR2(4000) := apex_application.g_x02;',
'    l_search_id NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_milestone NUMBER := TO_NUMBER(apex_application.g_x04);',
'    l_country_list CLOB;',
'    l_status VARCHAR2(20) := ''not-started'';',
'    l_status_icon VARCHAR2(100);',
'    l_status_title VARCHAR2(100);',
'    l_html CLOB;',
'    l_custom_title VARCHAR2(200);',
'BEGIN',
'    -- Get country list',
'    SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '' || CHR(10)) ',
'           WITHIN GROUP (ORDER BY l.B_NUMMER)',
'    INTO l_country_list',
'    FROM t_land l',
'    WHERE l.LANDID IN (',
'        SELECT TO_NUMBER(COLUMN_VALUE)',
'        FROM TABLE(apex_string.split(l_landids, '':''))',
'    );',
'',
'    -- Get custom title if exists',
'    BEGIN',
'        SELECT custom_card_title ',
'        INTO l_custom_title',
'        FROM t_ms_suche_split',
'        WHERE card_number = l_card_number',
'        AND ROWNUM = 1',
'        AND custom_card_title IS NOT NULL;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_custom_title := NULL;',
'    END;',
'    ',
'    -- Get status if exists',
'    BEGIN',
'        SELECT status',
'        INTO l_status',
'        FROM t_ms_card_status',
'        WHERE benutzerid = :G_BENUTZERID',
'        AND card_number = l_card_number',
'        AND sucheid = l_search_id',
'        AND meilenstein = l_milestone;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_status := ''not-started'';',
'    END;',
'    ',
'    -- Set status icon and title',
'    CASE l_status',
'        WHEN ''not-started'' THEN',
'            l_status_icon := ''<span class="fa fa-clock-o" style="font-size: 14px;"></span>'';',
'            l_status_title := ''Nicht begonnen'';',
'        WHEN ''in-progress'' THEN',
'            l_status_icon := ''<span class="fa fa-spinner fa-spin" style="font-size: 14px;"></span>'';',
'            l_status_title := ''In Bearbeitung'';',
'        WHEN ''completed'' THEN',
'            l_status_icon := ''<span class="fa fa-check-circle" style="font-size: 14px;"></span>'';',
'            l_status_title := ''Bearbeitung des Marktes abgeschlossen'';',
'    END CASE;',
'    ',
'    -- Build card HTML with editable title section and reset icon',
'    l_html := ',
'    ''<div class="header-container">'' ||',
'    ''<div class="title-container">'' ||',
'    ''<span class="edit-icon" onclick="makeEditable('' || l_card_number || '')" title="Title bearbeiten">'' ||',
'    ''<span class="fa fa-edit" style="font-size: 14px; color: #666;"></span>'' ||',
'    ''</span>'' ||',
'    -- Add reset icon (only visible when custom title exists)',
'    CASE WHEN l_custom_title IS NOT NULL THEN',
'        ''<span class="reset-icon" onclick="resetTitle('' || l_card_number || '', '''''' || ',
'        REPLACE(l_country_list, '''''''', '''''''''''' ) || '''''');" '' ||',
unistr('        ''title="Zur\00FCcksetzen auf Standardtitel">'' ||'),
'        ''<span class="fa fa-undo" style="font-size: 14px; color: #666;"></span>'' ||',
'        ''</span>''',
'    ELSE '''' END ||',
'    ''<span class="country-name" id="card-title-'' || l_card_number || ''">'' || ',
'    nvl(l_custom_title, l_country_list) || ',
'    ''</span>'' ||',
'    ''</div>'' ||',
'    -- Status Indicator',
'    ''<span class="status-indicator '' || l_status || ''" '' || ',
'    ''title="'' || l_status_title || ''" '' || ',
'    ''data-card="'' || l_card_number || ''" '' || ',
'    ''onclick="cycleStatus('' || l_card_number || '')">'' ||',
'    l_status_icon ||',
'    ''</span>'' ||',
'    -- View button',
'    ''<span class="view-full-button" onclick="openDetailView('''''' || l_landids || '''''', '''''' || l_card_number || '''''')" '' ||',
unistr('    ''title="Detailansicht \00F6ffnen" style="cursor: pointer; margin: 0 8px; color: #bb0a31;">'' ||'),
'    ''<span class="fa fa-expand" style="font-size: 14px;"></span>'' ||',
'    ''</span>'' ||',
'    -- Download button',
'    ''<span class="download-icon" onclick="downloadCardData('''''' || l_landids || '''''')" '' ||',
'    ''title="Daten herunterladen">'' ||',
'    ''<span class="fa fa-download-alt" style="font-size: 14px;"></span>'' ||',
'    ''</span>'' ||',
'    ''</div>'' ||',
'    ''<div class="t-Report t-Report--altRowsDefault t-Report--rowHighlight">'' ||',
'    ''<div class="t-Report-wrap">'' ||',
'    ''<div class="t-Report-tableWrap">'' ||',
'    ''<table class="t-Report-report" style="width: 100%; table-layout: fixed;">'' ||',
'    ''<thead><tr>'' ||',
'    ''<th class="t-Report-colHead" align="center" style="padding: 12px 8px; height: 40px; text-align: center;">'' ||',
'    ''<span class="u-Report-sortHeading">Vorschriftennummer</span>'' ||',
'    ''</th></tr></thead>'' ||',
'    ''<tbody>'' ||',
'    ''<div class="loaddata" searchid="'' || l_search_id || ''" milestone="'' || l_milestone || ''" landid="'' || l_landids || ''">'' ||',
'    ''</div>'' ||',
'    ''</tbody>'' ||',
'    ''</table></div></div></div>'';',
'    ',
'    -- Return HTML',
'    HTP.p(l_html);',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        HTP.p(''Error generating card content: '' || SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2630862833112581409
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_landids VARCHAR2(4000) := apex_application.g_x02;',
'    l_search_id NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_milestone NUMBER := TO_NUMBER(apex_application.g_x04);',
'    l_country_list CLOB;',
'    l_status VARCHAR2(20) := ''not-started''; -- Default status',
'    l_status_icon VARCHAR2(100);',
'    l_status_title VARCHAR2(100);',
'    l_html CLOB;',
'BEGIN',
'    -- Get country list',
'    SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '' || CHR(10)) ',
'           WITHIN GROUP (ORDER BY l.B_NUMMER)',
'    INTO l_country_list',
'    FROM t_land l',
'    WHERE l.LANDID IN (',
'        SELECT TO_NUMBER(COLUMN_VALUE)',
'        FROM TABLE(apex_string.split(l_landids, '':''))',
'    );',
'    ',
'    -- Get status if exists',
'    BEGIN',
'        SELECT status',
'        INTO l_status',
'        FROM t_ms_card_status',
'        WHERE benutzerid = :G_BENUTZERID',
'        AND card_number = l_card_number',
'        AND sucheid = l_search_id',
'        AND meilenstein = l_milestone;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_status := ''not-started'';',
'    END;',
'    ',
'    -- Set status icon and title',
'    CASE l_status',
'        WHEN ''not-started'' THEN',
'            l_status_icon := '''';',
'            l_status_title := ''Nicht begonnen'';',
'        WHEN ''in-progress'' THEN',
'            l_status_icon := ''<span class="fa fa-spinner"></span>'';',
'            l_status_title := ''In Bearbeitung'';',
'        WHEN ''completed'' THEN',
'            l_status_icon := ''<span class="fa fa-check"></span>'';',
'            l_status_title := ''Bearbeitung des Marktes abgeschlossen'';',
'    END CASE;',
'    ',
'    -- Build card HTML with status indicator',
'    l_html := ',
'    ''<div class="header-container">'' ||',
'    ''<span class="country-name">'' || l_country_list || ''</span>'' ||',
'    ''<span class="status-indicator '' || l_status || ''" title="'' || l_status_title || ',
'    ''" data-card="'' || l_card_number || ''" onclick="cycleStatus('' || l_card_number || '')">'' ||',
'    l_status_icon ||',
'    ''</span>'' ||',
'    ''<span class="download-icon" onclick="downloadCardData('''''' || l_landids || '''''')" title="Daten herunterladen">'' ||',
'    ''<span class="fa fa-download-alt" style="font-size: 14px;"></span>'' ||',
'    ''</span>'' ||',
'    ''</div>'' ||',
'    ''<div class="t-Report t-Report--altRowsDefault t-Report--rowHighlight">'' ||',
'    ''<div class="t-Report-wrap">'' ||',
'    ''<div class="t-Report-tableWrap">'' ||',
'    ''<table class="t-Report-report" style="width: 100%; table-layout: fixed;">'' ||',
'    ''<thead><tr>'' ||',
'    ''<th class="t-Report-colHead" align="center" style="padding: 12px 8px; height: 40px; text-align: center;">'' ||',
'    ''<span class="u-Report-sortHeading">Vorschriftennummer</span>'' ||',
'    ''</th></tr></thead>'' ||',
'    ''<tbody>'' ||',
'    ''<div class="loaddata" searchid="'' || l_search_id || ''" milestone="'' || l_milestone || ''" landid="'' || l_landids || ''">'' ||',
'    ''</div>'' ||',
'    ''</tbody>'' ||',
'    ''</table></div></div></div>'';',
'    ',
'    -- Return HTML',
'    HTP.p(l_html);',
'END;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1041348283720806825)
,p_process_sequence=>170
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_CARD_TITLE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_title VARCHAR2(200) := apex_application.g_x02;',
'    l_action VARCHAR2(20) := apex_application.g_x03;',
'    l_country_list CLOB;',
'    l_landids VARCHAR2(4000);',
'BEGIN',
'    -- Get the landids for this card to construct the original title',
'    BEGIN',
'        SELECT LISTAGG(landid, '':'') WITHIN GROUP (ORDER BY landid)',
'        INTO l_landids',
'        FROM t_ms_suche_split',
'        WHERE card_number = l_card_number',
'        AND ROWNUM = 1;',
'    ',
'        -- Get the original country list',
'        SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '') ',
'               WITHIN GROUP (ORDER BY l.B_NUMMER)',
'        INTO l_country_list',
'        FROM t_land l',
'        WHERE l.LANDID IN (',
'            SELECT TO_NUMBER(COLUMN_VALUE)',
'            FROM TABLE(apex_string.split(l_landids, '':''))',
'        );',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_country_list := '''';',
'    END;',
'    ',
'    -- Update title based on action',
'    IF l_action = ''RESET'' OR l_title IS NULL OR l_title = '''' THEN',
'        -- Reset to default - set to NULL',
'        UPDATE t_ms_suche_split',
'        SET custom_card_title = NULL',
'        WHERE card_number = l_card_number',
'        AND benutzerid = :G_BENUTZERID;',
'    ELSE',
'        -- Set to custom title',
'        UPDATE t_ms_suche_split',
'        SET custom_card_title = l_title',
'        WHERE card_number = l_card_number',
'        AND benutzerid = :G_BENUTZERID;',
'    END IF;',
'    ',
'    COMMIT;',
'    ',
'    -- JSON response',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
'    apex_json.write(''message'', ''Title updated successfully'');',
'    apex_json.write(''original_title'', l_country_list);',
'    apex_json.close_object;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Return error as JSON',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;',
'       ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2630864032178581410
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_title VARCHAR2(200) := apex_application.g_x02;',
'BEGIN',
'    -- Update title',
'    UPDATE t_ms_suche_split',
'    SET custom_card_title = l_title',
'    WHERE card_number = l_card_number',
'    AND benutzerid = :G_BENUTZERID;',
'    ',
'    ',
'    -- JSON response',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
'    apex_json.write(''message'', ''Title updated successfully'');',
'    apex_json.close_object;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Return error as JSON',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;',
'        -- -- Roll back transaction',
'        -- ROLLBACK;',
'',
'        ',
'END;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1041352255311806832)
,p_process_sequence=>180
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UPDATE_CARD_STATUS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_status VARCHAR2(20) := apex_application.g_x02;',
'    l_search_id NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_milestone NUMBER := TO_NUMBER(apex_application.g_x04);',
'BEGIN',
'    -- Update or insert status in the profile table',
'    MERGE INTO t_ms_card_status cs',
'    USING (SELECT :G_BENUTZERID as benutzerid, l_card_number as card_number, ',
'                 l_search_id as sucheid, l_milestone as meilenstein FROM dual) src',
'    ON (cs.benutzerid = src.benutzerid AND cs.card_number = src.card_number ',
'        AND cs.sucheid = src.sucheid AND cs.meilenstein = src.meilenstein)',
'    WHEN MATCHED THEN',
'        UPDATE SET status = l_status, letzte_aenderung_datum = SYSDATE',
'    WHEN NOT MATCHED THEN',
'        INSERT (benutzerid, card_number, sucheid, meilenstein, status, erstelldatum, letzte_aenderung_datum)',
'        VALUES (src.benutzerid, src.card_number, src.sucheid, src.meilenstein, ',
'                l_status, SYSDATE, SYSDATE);',
'                ',
'    -- Return success response',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
'    apex_json.write(''message'', ''Status updated successfully'');',
'    apex_json.close_object;',
'                ',
'    COMMIT;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Return error response',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;',
'        ',
'        ROLLBACK;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2630860060587581403
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare    ',
'    lSearchID number := apex_application.g_x01;  -- List of selected items',
'    lMilestone number := apex_application.g_x02;  -- List of country groups',
'    lLaender varchar2(2000) := apex_application.g_x03;  -- Selected Search',
'    cChunkSize constant number := 32000;',
'    lChunk   varchar2(cChunkSize char);    ',
'',
'    lDaten clob;',
'    lOffset  pls_integer := 1;',
'begin',
'',
'    debug(''ajax1'');',
'',
'    lDaten := country_vorschrift_card_detail(',
'           p_search_id => lSearchID,',
'           p_milestone => lMilestone,',
'           P_LANDID => lLaender,',
'           p_format => ''DISPLAY''',
'       );',
'',
'    debug(''ajax2'');       ',
'',
'--  OWA_UTIL.MIME_HEADER(''application/json'');  ',
'  loop    ',
'    lChunk := dbms_lob.substr(lDaten, cChunkSize, lOffset);    ',
'    exit when lChunk is null;    ',
'    htp.prn(lChunk); -- PRN = don''t terminate each call with newline   ',
'    lOffset := lOffset + cChunkSize;  ',
'  end loop;',
'',
'',
'    debug(''ajax3'');    ',
'',
'    --debug(''ajax'',dbms_lob.getlength(lDaten));',
'',
'end;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1041349090227806826)
,p_process_sequence=>190
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_CARD_CONTENT_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_landids VARCHAR2(4000) := apex_application.g_x02;',
'    l_search_id NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_milestone NUMBER := TO_NUMBER(apex_application.g_x04);',
'    l_country_list CLOB;',
'    l_html CLOB;',
'BEGIN',
'    -- Get country list',
'    SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '' || CHR(10)) ',
'           WITHIN GROUP (ORDER BY l.B_NUMMER)',
'    INTO l_country_list',
'    FROM t_land l',
'    WHERE l.LANDID IN (',
'        SELECT TO_NUMBER(COLUMN_VALUE)',
'        FROM TABLE(apex_string.split(l_landids, '':''))',
'    );',
'',
'    -- Build inner HTML content',
'    l_html := ',
'    ''<div class="header-container">'' ||',
'    ''<span class="country-name">'' || l_country_list || ''</span>'' ||',
'    ''<span class="download-icon" onclick="downloadCardData('''''' || l_landids || '''''')" '' ||',
'    ''title="Daten herunterladen">'' ||',
'    ''<span class="fa fa-download-alt" style="font-size: 14px;"></span>'' ||',
'    ''</span>'' ||',
'    ''</div>'' ||',
'    ''<div class="t-Report t-Report--altRowsDefault t-Report--rowHighlight">'' ||',
'    ''<div class="t-Report-wrap">'' ||',
'    ''<div class="t-Report-tableWrap">'' ||',
'    ''<table class="t-Report-report" style="width: 100%; table-layout: fixed;">'' ||',
'    ''<thead><tr>'' ||',
'    ''<th class="t-Report-colHead" align="center" style="padding: 12px 8px; height: 40px; text-align: center;">'' ||',
'    ''<span class="u-Report-sortHeading">Vorschriftennummer</span>'' ||',
'    ''</th></tr></thead>'' ||',
'    ''<tbody><div class="loaddata" searchid="'' || l_search_id || ''" '' ||',
'    ''milestone="'' || l_milestone || ''" landid="'' || l_landids || ''">&nbsp;</div></tbody>'' || -- loading',
'    ''</table></div></div></div>'';',
'',
'    -- Return HTML',
'    HTP.p(l_html);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2630863225671581409
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare    ',
'    lSearchID number := apex_application.g_x01;  -- List of selected items',
'    lMilestone number := apex_application.g_x02;  -- List of country groups',
'    lLaender varchar2(2000) := apex_application.g_x03;  -- Selected Search',
'    cChunkSize constant number := 32000;',
'    lChunk   varchar2(cChunkSize char);    ',
'',
'    lDaten clob;',
'    lOffset  pls_integer := 1;',
'begin',
'',
'    debug(''ajax1'');',
'',
'    lDaten := country_vorschrift_card_detail(',
'           p_search_id => lSearchID,',
'           p_milestone => lMilestone,',
'           P_LANDID => lLaender,',
'           p_format => ''DISPLAY''',
'       );',
'',
'    debug(''ajax2'');       ',
'',
'--  OWA_UTIL.MIME_HEADER(''application/json'');  ',
'  loop    ',
'    lChunk := dbms_lob.substr(lDaten, cChunkSize, lOffset);    ',
'    exit when lChunk is null;    ',
'    htp.prn(lChunk); -- PRN = don''t terminate each call with newline   ',
'    lOffset := lOffset + cChunkSize;  ',
'  end loop;',
'',
'',
'    debug(''ajax3'');    ',
'',
'    --debug(''ajax'',dbms_lob.getlength(lDaten));',
'',
'end;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1041347474158806824)
,p_process_sequence=>200
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RESTORE_SAVED_CARDS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_countries VARCHAR2(4000) := apex_application.g_x01;',
'    l_card_numbers VARCHAR2(4000) := apex_application.g_x02;',
'    l_search_id NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_milestone NUMBER := TO_NUMBER(apex_application.g_x04);',
'    l_card_number NUMBER;',
'BEGIN',
'    -- Loop through card numbers',
'    FOR i IN (',
'        SELECT ',
'            column_value AS card_num,',
'            ROWNUM AS rn',
'        FROM TABLE(apex_string.split(l_card_numbers, '':''))',
'    ) LOOP',
'        l_card_number := TO_NUMBER(i.card_num);',
'        ',
'        -- For each country in this card',
'        FOR c IN (',
'            SELECT ',
'                column_value AS landid,',
'                i.rn AS card_index',
'            FROM TABLE(apex_string.split(l_card_countries, '':''))',
'            WHERE MOD(ROWNUM, LENGTH(l_card_numbers) - LENGTH(REPLACE(l_card_numbers, '':'', '''')) + 1) = ',
'                  MOD(i.rn - 1, LENGTH(l_card_numbers) - LENGTH(REPLACE(l_card_numbers, '':'', '''')) + 1)',
'        ) LOOP',
'            -- Insert record for this card and country',
'            INSERT INTO t_ms_suche_split (',
'                sucheid,',
'                meilenstein,',
'                card_number,',
'                landid,',
'                BENUTZERID,',
'                letzte_aenderung_datum,',
'                letzte_aenderung_benutzerid',
'            ) VALUES (',
'                l_search_id,',
'                l_milestone,',
'                l_card_number,',
'                TO_NUMBER(c.landid),',
'                :G_BENUTZERID,',
'                SYSDATE,',
'                :G_BENUTZERID',
'            );',
'        END LOOP;',
'    END LOOP;',
'    ',
'    COMMIT;',
'    ',
'    -- Return success response',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
'    apex_json.write(''message'', ''Cards restored successfully'');',
'    apex_json.close_object;',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Return error response',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;',
'        ROLLBACK;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2630864841740581411
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare    ',
'    lSearchID number := apex_application.g_x01;  -- List of selected items',
'    lMilestone number := apex_application.g_x02;  -- List of country groups',
'    lLaender varchar2(2000) := apex_application.g_x03;  -- Selected Search',
'    cChunkSize constant number := 32000;',
'    lChunk   varchar2(cChunkSize char);    ',
'',
'    lDaten clob;',
'    lOffset  pls_integer := 1;',
'begin',
'',
'    debug(''ajax1'');',
'',
'    lDaten := country_vorschrift_card_detail(',
'           p_search_id => lSearchID,',
'           p_milestone => lMilestone,',
'           P_LANDID => lLaender,',
'           p_format => ''DISPLAY''',
'       );',
'',
'    debug(''ajax2'');       ',
'',
'--  OWA_UTIL.MIME_HEADER(''application/json'');  ',
'  loop    ',
'    lChunk := dbms_lob.substr(lDaten, cChunkSize, lOffset);    ',
'    exit when lChunk is null;    ',
'    htp.prn(lChunk); -- PRN = don''t terminate each call with newline   ',
'    lOffset := lOffset + cChunkSize;  ',
'  end loop;',
'',
'',
'    debug(''ajax3'');    ',
'',
'    --debug(''ajax'',dbms_lob.getlength(lDaten));',
'',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
