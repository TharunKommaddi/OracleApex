prompt --application/pages/page_00070
begin
--   Manifest
--     PAGE: 00070
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>70
,p_name=>'MfVs'
,p_step_title=>'MfVs'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2643469227263719096)
,p_plug_name=>'MfVs <span onclick="redirect(11)" class="fa fa-question-square-o"></span>'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH cte as ( select listagg( mrt.mfv_teilid, '', '') within group (order by mrt.mfv_teilid) as mfv_teil_list, ',
'                      listagg( t.bezeichnung, '', '') within group (order by t.bezeichnung) as teil_bez_list,',
'                                m.mfv_name mfv_name,  mrt.mfvid mfvid',
'                from t_mfv_ref_mfv_teil mrt',
'                join t_mfv_teil t on (t.mfv_teilID = mrt.mfv_teilid)',
'                join t_mfv m on (m.mfvid = mrt.mfvid)',
'                 group by mrt.mfvid, m.mfv_name',
' )',
' select  case when m.jira_status =10 then',
'             ''<span class="fa fa-pencil" aria-hidden="true"></span>'' ',
'              else null end as lnk,',
'm.rowid as xrowid,',
'cte.teil_bez_list AS "MFV_TEIL",',
'"SCHLAGWORTE",',
'm.VORSCHRIFTENVERANTWORTLICHER  as VORSCHRIFTENVERANTWORTLICHER,',
'"BETEILIGTE_OES",',
'PCK_RI.fJiraTicketsToLinks(JIRA_TICKET) AS "JIRA_TICKET",',
'PCK_RI.fCreateLinkIfUrl("LINK_MFV_DMS") AS "LINK_MFV_DMS",',
'',
'CASE ',
'    WHEN (m.JIRA_Status IS NULL OR m.JIRA_Status=0) THEN emano_util.fLang(''offen'', ''open'')',
'    WHEN (m.JIRA_Status =10) THEN emano_util.fLang(''geschlossen'', ''closed'')',
'     when (m.JIRA_Status =20) THEN emano_util.fLang(''ohne MfV beendet'', ''closed without MfV'')',
'    ELSE emano_util.fLang(''offen'', ''open'')',
'END AS JIRA_STATUS,',
'',
'm.DMS_DOKUMENTENSTATUS as "DMS_DOKUMENTENSTATUS",',
'CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN k.bezeichnung ELSE k.name_eng END as "KSU",',
'm.mfv_thema,',
'm.mfv_name,',
'b.nachname || '', '' || b.vorname  as benutzer,',
'm."LETZTE_AENDERUNG_DATUM",',
'm."GUELTIGKEITSDATUM",',
'x.vorschriftenliste,',
'y.ak_liste',
'from "#OWNER#"."T_MFV" m',
'join cte on (cte.mfvid = m.mfvid)',
'left outer join T_BENUTZER b on b.benutzerid = m.LETZTE_AENDERUNG_BENUTZERID',
'left outer join T_KSU k on k.ksuid = m.ksuid',
'outer apply (',
'    select listagg(vorschrift_nummer, '','') within group(order by vorschrift_nummer) vorschriftenliste',
'    from t_mfv_ref_vorschrift mrv',
'    join t_vorschrift v on (mrv.vorschriftid = v.vorschriftid)',
'    where mrv.mfvid = m.mfvid',
') x',
'outer apply (',
'    select listagg(a.kurz,'', '') within group (order by a.kurz) as ak_liste',
'    from t_mfv_ref_et_b_ak i',
'    join t_et_b_ak a on (i.et_b_akid = a.et_b_akid)',
'    where m.mfvid = i.mfvid',
') y',
unistr('where (m.DMS_DOKUMENTENSTATUS in (20, 30) -- freigegeben oder ung\00FCltig'),
'       OR pck_ri.fIsUserInRolle(listRolleId => ''1000:1002'') > 0) -- oder benutzer hat rolle VEX bzw. VKO',
'ORDER BY m.mfv_name',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2643469609472719097)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'Keine MfVs gefunden.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>154123043514446861
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2678714856878847255)
,p_db_column_name=>'MFV_NAME'
,p_display_order=>11
,p_column_identifier=>'N'
,p_column_label=>'MfV ID'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2643272562841755356)
,p_db_column_name=>'MFV_TEIL'
,p_display_order=>21
,p_column_identifier=>'J'
,p_column_label=>'MfV Teil'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2678714670455847254)
,p_db_column_name=>'MFV_THEMA'
,p_display_order=>31
,p_column_identifier=>'M'
,p_column_label=>'Thema der MfV'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2643470532274719113)
,p_db_column_name=>'SCHLAGWORTE'
,p_display_order=>41
,p_column_identifier=>'C'
,p_column_label=>'Schlagworte'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2643471358819719114)
,p_db_column_name=>'BETEILIGTE_OES'
,p_display_order=>51
,p_column_identifier=>'E'
,p_column_label=>'Beteiligte OEs'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2643471748225719114)
,p_db_column_name=>'LINK_MFV_DMS'
,p_display_order=>61
,p_column_identifier=>'F'
,p_column_label=>'Link zur Ablage DMS'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(895789678245594085)
,p_db_column_name=>'DMS_DOKUMENTENSTATUS'
,p_display_order=>81
,p_column_identifier=>'Q'
,p_column_label=>'DMS Dokumentenstatus'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(958148833580521269)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2643272383312755355)
,p_db_column_name=>'VORSCHRIFTENVERANTWORTLICHER'
,p_display_order=>91
,p_column_identifier=>'I'
,p_column_label=>'ET Arbeitskreis (alt)'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2656500247247854244)
,p_db_column_name=>'JIRA_TICKET'
,p_display_order=>101
,p_column_identifier=>'K'
,p_column_label=>'Jira-Tickets'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2677392730513635640)
,p_db_column_name=>'KSU'
,p_display_order=>111
,p_column_identifier=>'L'
,p_column_label=>'KSU'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2643272267727755354)
,p_db_column_name=>'LETZTE_AENDERUNG_DATUM'
,p_display_order=>121
,p_column_identifier=>'H'
,p_column_label=>unistr('Letzte \00C4nderung Datum')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(565124314804321287)
,p_db_column_name=>'GUELTIGKEITSDATUM'
,p_display_order=>131
,p_column_identifier=>'S'
,p_column_label=>unistr('G\00FCltigkeitsdatum')
,p_column_type=>'DATE'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2643272176991755353)
,p_db_column_name=>'BENUTZER'
,p_display_order=>141
,p_column_identifier=>'G'
,p_column_label=>unistr('Letzte \00C4nderung Benutzer')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1458191265073012537)
,p_db_column_name=>'XROWID'
,p_display_order=>151
,p_column_identifier=>'O'
,p_column_label=>'Xrowid'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1458191339247012538)
,p_db_column_name=>'VORSCHRIFTENLISTE'
,p_display_order=>161
,p_column_identifier=>'P'
,p_column_label=>'Vorschriften'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(644942673262825569)
,p_db_column_name=>'AK_LISTE'
,p_display_order=>171
,p_column_identifier=>'R'
,p_column_label=>'ET Arbeitskreis'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1078791179544398573)
,p_db_column_name=>'JIRA_STATUS'
,p_display_order=>181
,p_column_identifier=>'U'
,p_column_label=>'Jira Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1078790965457398571)
,p_db_column_name=>'LNK'
,p_display_order=>191
,p_column_identifier=>'W'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:75:&SESSION.::&DEBUG.::P75_ROWID:#XROWID#'
,p_column_linktext=>'#LNK#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'FUNCTION_BODY'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return PCK_RI.fIsAuthorized(userId => PCK_RI.fGetUserId, ',
'                      pageId => :APP_PAGE_ID,',
'                      accessMode => 200) ;'))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2643478898463746612)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1541324'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LNK:MFV_NAME:MFV_TEIL:AK_LISTE:VORSCHRIFTENLISTE:MFV_THEMA:SCHLAGWORTE:BETEILIGTE_OES:LINK_MFV_DMS:DMS_DOKUMENTENSTATUS:JIRA_STATUS:JIRA_TICKET:KSU:LETZTE_AENDERUNG_DATUM:BENUTZER:GUELTIGKEITSDATUM:'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2643472126664719114)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2643469227263719096)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2643472567505719115)
,p_event_id=>wwv_flow_imp.id(2643472126664719114)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2643469227263719096)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
