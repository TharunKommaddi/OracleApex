prompt --application/pages/page_00425
begin
--   Manifest
--     PAGE: 00425
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>425
,p_name=>'REV Kontroll Gruppen'
,p_alias=>'REV-KONTROLL-GRUPPEN'
,p_step_title=>'REV Kontroll Gruppen'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'function confirmDelete(aId,aItem,aText) {',
'    check = confirm(aText);',
'    if (check) {',
'        $(''#''+aItem).val(aId);',
'        apex.submit(''DELETE'');        ',
'    }',
'}',
'',
''))
,p_javascript_code_onload=>'confirmDelete'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2033601374808353785)
,p_plug_name=>'REV Kontroll Gruppen'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'',
'    kg.rev_kontrolle_gruppe_id, ',
'    kg.gruppe_name, ',
'    kg.zeitpunkt,',
'    sum(case when k.status in (10,20,30) then 1 else 0 end) anzahl_rev, ',
'    sum(case when k.status = 30 then 1 else 0 end) anzahl_erledigt,',
'   ',
unistr('    ''<a href="javascript:confirmDelete('' || kg.rev_kontrolle_gruppe_id || '',''''P425_DELETE_ID'''', ''''M\00F6chten Sie diese Kontrollgruppe und alle zugeh\00F6rigen Daten wirklich l\00F6schen?'''');">'),
unistr('    <span aria-hidden="true" alt="Kontrollgruppe l\00F6schen" title="Kontrollgruppe l\00F6schen" class="fa fa-trash-o"></span>'),
'    </a>'' as delete_link',
'',
'from t_rev_kontrolle_gruppe kg',
'left outer join t_rev_kontrolle k on (k.rev_kontrolle_gruppe_id = kg.rev_kontrolle_gruppe_id)',
'group by kg.rev_kontrolle_gruppe_id, kg.gruppe_name, kg.zeitpunkt'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'REV Kontroll Gruppen'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2033601483192353786)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>5705813799091742021
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1073543645980229498)
,p_db_column_name=>'REV_KONTROLLE_GRUPPE_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:420:&SESSION.::&DEBUG.:420:P420_KONTROLLE_GRUPPE:#REV_KONTROLLE_GRUPPE_ID#'
,p_column_linktext=>'<span class="fa fa-search"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1073543305835229497)
,p_db_column_name=>'GRUPPE_NAME'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Kontrollgruppe'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1073542877708229497)
,p_db_column_name=>'ZEITPUNKT'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>unistr('Zeitpunkt der Er\00F6ffnung')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd.mm.yyyy hh24:mi'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1073542459511229497)
,p_db_column_name=>'ANZAHL_REV'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Anzahl der REV'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1073542102642229497)
,p_db_column_name=>'ANZAHL_ERLEDIGT'
,p_display_order=>60
,p_column_identifier=>'G'
,p_column_label=>'davon erledigt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1068993432057462200)
,p_db_column_name=>'DELETE_LINK'
,p_display_order=>70
,p_column_identifier=>'I'
,p_column_label=>'&nbsp;'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2034273368088483249)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5091919'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'REV_KONTROLLE_GRUPPE_ID:DELETE_LINK:GRUPPE_NAME:ZEITPUNKT:ANZAHL_REV:ANZAHL_ERLEDIGT:'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1068993594900462201)
,p_name=>'P425_DELETE_ID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1068993687172462202)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process - Delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    -- First delete from T_REV_KONTROLLE_VORSCHRIFT',
'    delete from t_rev_kontrolle_vorschrift ',
'    where rev_kontrolle_id in (',
'        select rev_kontrolle_id ',
'        from t_rev_kontrolle ',
'        where rev_kontrolle_gruppe_id = :P425_DELETE_ID',
'    );',
'    ',
'    -- Then delete from T_REV_KONTROLLE',
'    delete from t_rev_kontrolle ',
'    where rev_kontrolle_gruppe_id = :P425_DELETE_ID;',
'    ',
'    -- Finally delete the group itself',
'    delete from t_rev_kontrolle_gruppe ',
'    where rev_kontrolle_gruppe_id = :P425_DELETE_ID;',
'    ',
'',
unistr('    apex_application.g_print_success_message := ''Kontrollgruppe und zugeh\00F6rige Daten wurden erfolgreich gel\00F6scht'';'),
'exception',
'    when others then',
'        rollback;',
'        apex_application.g_print_success_message := ''Error: '' || sqlerrm;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':REQUEST = ''DELETE'''
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>2603218628726926033
);
wwv_flow_imp.component_end;
end;
/
