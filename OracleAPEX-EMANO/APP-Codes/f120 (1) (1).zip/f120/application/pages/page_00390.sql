prompt --application/pages/page_00390
begin
--   Manifest
--     PAGE: 00390
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>390
,p_name=>'CoP Vorschriften Report'
,p_alias=>'COP-VORSCHRIFTEN-REPORT'
,p_step_title=>'CoP Vorschriften Report'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Hilfe Button',
'$(''#VSIG_toolbar_controls'').append('' <span onclick="redirect(221)" style="font-size:2.7em" class="fa fa-question-square-o"></span>'');',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(885738596396484648)
,p_plug_name=>'CoP Vorschriften Report'
,p_region_name=>'VSIG'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414123142457820547)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select VORSCHRIFTID,',
'       VORSCHRIFT_NUMMER,',
'       DOKUMENTENDATUM,',
'   ',
'        VORSCHRIFT_BEZEICHNUNG',
'       as VORSCHRIFT_BEZEICHNUNG,',
'       CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN BEMERKUNG ',
'        ELSE BEMERKUNG_ENGLISCH ',
'       END BEMERKUNG,',
'       HOMOLOGATIONSRELEVANT,',
'       COP_RELEVANT,',
'       VORSCHRIFT_STATUSID,',
'       laender_direkt.list_land || '', '' || laender_verlinkt.liste AS LIST_LAENDER,',
'       --laender_verlinkt.liste as laender_verlinkt,',
'       laendergruppe.list_laendergruppe AS LAENDER_CLUSTERUNG,',
'       themengebiete.list_themengebiet as THEMA_NUMMER,',
'       themengebiete_text.list_themengebiet_text as THEMA_BEZEICHNUNG,',
'       mfvs.list_mfv as MFVIDS,',
'       pck_ri.fCreatePermalinkUrl(VORSCHRIFTID) AS PERMALINK,',
'       VORSCHRIFTID AS LINK_NETZ',
'  from T_VORSCHRIFT vs',
'  ',
'outer apply (',
'    select listagg(b_nummer, '', '') within group(order by b_nummer) list_land',
'    from (',
'        select distinct land.b_nummer',
'        from T_VORSCHRIFT_REF_LAND vl ',
'        left outer join t_land land on land.landid = vl.landid',
'        where vl.vorschriftid = vs.vorschriftid and vl.geloescht = 0',
'            )',
') laender_direkt',
'',
'outer apply (',
'    select listagg(laendergruppe, '', '') within group(order by laendergruppe) list_laendergruppe',
'    from (',
'        select distinct lg.laendergruppe',
'        from T_VORSCHRIFT_REF_LAND vl ',
'--        left outer join t_land land on land.landid = vtl.landid',
'        left outer join t_land_ref_laendergruppe lrl on lrl.landid = vl.landid',
'        left outer join t_laendergruppe lg on lg.laendergruppeid = lrl.laendergruppeid',
'        where vl.vorschriftid = vs.vorschriftid and vl.geloescht = 0',
'            )',
') laendergruppe',
'',
'outer apply (',
'    select listagg(b_nummer,'', '') within group (order by b_nummer) as liste',
'    from (',
'        --select distinct l.b_nummer',
'       -- from t_vorschrift_ref_vorschrift vrv',
'       -- join t_vorschrift_ref_land vl on (vrv.nachfolger_vorschriftid = vl.vorschriftid and vl.geloescht = 0)',
'       -- join t_land l on (vl.landid = l.landid)',
'       -- where',
'        --    vrv.vorgaenger_vorschriftid = vs.vorschriftid',
'         --   and vrv.beziehung_art in (40,102) -- verweist auf, gleichwertig',
'        -- neu',
'        select distinct l.b_nummer b_nummer',
'        from t_vorschrift_ref_vorschrift vrv',
'        join t_vorschrift_ref_land rtl on (vrv.nachfolger_vorschriftid = rtl.vorschriftid)',
'        join t_land l on (rtl.landid = l.landid)',
'        where vorgaenger_vorschriftid = vs.vorschriftid and beziehung_art = 40 and rtl.geloescht = 0    ',
'        union',
'            ',
'       -- select distinct l.b_nummer',
'        --from t_vorschrift_ref_vorschrift vrv',
'       -- join t_vorschrift_ref_land vl on (vrv.vorgaenger_vorschriftid = vl.vorschriftid and vl.geloescht = 0)',
'       -- join t_land l on (vl.landid = l.landid)',
'       -- where',
'       --     vrv.nachfolger_vorschriftid = vs.vorschriftid',
'        --    and vrv.beziehung_art in (40,102) -- verweist auf, gleichwertig ',
'        -- neu ',
'       select  distinct l.b_nummer b_nummer ',
'        from t_vorschrift_ref_vorschrift vrv',
'        join t_vorschrift_ref_land rtl on (vrv.nachfolger_vorschriftid = rtl.vorschriftid)',
'        join t_land l on (rtl.landid = l.landid)',
'        where vorgaenger_vorschriftid = vs.vorschriftid ',
'        and vrv.beziehung_art = 102 and rtl.geloescht = 0  ',
'    )',
') laender_verlinkt',
'',
'',
'outer apply (',
'    select listagg(tg,'', '') within group (order by tg) list_themengebiet',
'    from (',
'        select distinct t.nummer tg',
'        from t_vorschrift_ref_thema vt',
'        join t_thema t on (vt.themaid = t.themaid)',
'        where vt.vorschriftid = vs.vorschriftid and vt.geloescht = 0',
'    )',
') themengebiete',
'  ',
'outer apply (',
'    select listagg(tg,'', '' ON OVERFLOW TRUNCATE ''...'' WITHOUT COUNT) within group (order by tg_n) list_themengebiet_text',
'    from (',
'        select distinct CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN t.bezeichnung',
'        ELSE t.name_eng',
'    END as tg, t.nummer as tg_n',
'        from t_vorschrift_ref_thema vt',
'        join t_thema t on (vt.themaid = t.themaid)',
'        where vt.vorschriftid = vs.vorschriftid and vt.geloescht = 0',
'    )',
') themengebiete_text',
'',
'outer apply (',
'    select listagg(mfv_name,'', '') within group (order by mfv_name) list_mfv',
'    from (',
'        select distinct mfv.mfv_name mfv_name',
'        from t_mfv_ref_vorschrift mv',
'        join t_mfv mfv on (mfv.mfvid = mv.mfvid)',
'        where mv.vorschriftid = vs.vorschriftid',
'    )',
') mfvs',
'',
'where vs.vorschrift_typid in (10, 30, 40) -- Supplements nicht anzeigen',
unistr('-- f\00FCr eingeschraenkte Nutzer nur freigegebene Vorschriften anzeigen'),
'and (vs.vorschrift_freigabestatusid = 20 or pck_ri.fIsLimitedUser = 0) ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'CoP Vorschriften Report'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(885738480566484648)
,p_name=>'CoP Vorschriften Report'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV'
,p_enable_mail_download=>'N'
,p_detail_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25:P25_VORSCHRIFTID:#VORSCHRIFTID#'
,p_detail_link_text=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_detail_link_condition_type=>'EXPRESSION'
,p_detail_link_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 25,',
'                      accessMode => 100))'))
,p_detail_link_cond2=>'PLSQL'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>226954456528649756
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(885738059203484618)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Vorschriftid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(885806831088768078)
,p_db_column_name=>'LINK_NETZ'
,p_display_order=>11
,p_column_identifier=>'AG'
,p_column_label=>'&nbsp;'
,p_column_link=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.::P300_VORSCHRIFTID:#LINK_NETZ#'
,p_column_linktext=>unistr('<span class="fa fa-network-hub" title="Vernetzungsansicht \00F6ffnen" alt="Vernetzungsansicht \00F6ffnen"></span>')
,p_column_link_attr=>'target="_blank"'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(885806902351768079)
,p_db_column_name=>'PERMALINK'
,p_display_order=>21
,p_column_identifier=>'AF'
,p_column_label=>'&nbsp;'
,p_column_html_expression=>'<span class="fa fa-link" title="Permalink in Zwischenablage kopieren" alt="Permalink in Zwischenablage kopieren" onClick="javascript:navigator.clipboard.writeText(''#PERMALINK#'');alert(''Der Permalink wurde in die Zwischenablage kopiert:\n\n#PERMALINK#'
||''');"></span>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(885737832566484615)
,p_db_column_name=>'VORSCHRIFT_NUMMER'
,p_display_order=>31
,p_column_identifier=>'B'
,p_column_label=>'Vorschriften&shy;nummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(885730154498484609)
,p_db_column_name=>'HOMOLOGATIONSRELEVANT'
,p_display_order=>61
,p_column_identifier=>'U'
,p_column_label=>'Homologations&shy;relevant'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(958145374896477003)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(885728541205484608)
,p_db_column_name=>'COP_RELEVANT'
,p_display_order=>71
,p_column_identifier=>'Y'
,p_column_label=>'CoP Relevant'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(958149357559525013)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(885730585521484609)
,p_db_column_name=>'VORSCHRIFT_STATUSID'
,p_display_order=>81
,p_column_identifier=>'T'
,p_column_label=>'Status der Vorschrift'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(2490458092659806028)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(885808407489768094)
,p_db_column_name=>'LAENDER_CLUSTERUNG'
,p_display_order=>101
,p_column_identifier=>'AA'
,p_column_label=>unistr('L\00E4nder Clusterung')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(885807958883768090)
,p_db_column_name=>'MFVIDS'
,p_display_order=>141
,p_column_identifier=>'AE'
,p_column_label=>'MfV IDs'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(375328804289175254)
,p_db_column_name=>'THEMA_NUMMER'
,p_display_order=>151
,p_column_identifier=>'AH'
,p_column_label=>'Thema Nummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(372030107239395101)
,p_db_column_name=>'THEMA_BEZEICHNUNG'
,p_display_order=>171
,p_column_identifier=>'AK'
,p_column_label=>'Thema Bezeichnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949206018171439855)
,p_db_column_name=>'VORSCHRIFT_BEZEICHNUNG'
,p_display_order=>181
,p_column_identifier=>'AN'
,p_column_label=>'Vorschrift Bezeichnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(949205839770439854)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>191
,p_column_identifier=>'AO'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(875245096622362298)
,p_db_column_name=>'LIST_LAENDER'
,p_display_order=>201
,p_column_identifier=>'AP'
,p_column_label=>unistr('L\00E4nder')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1094032376035457131)
,p_db_column_name=>'DOKUMENTENDATUM'
,p_display_order=>211
,p_column_identifier=>'AQ'
,p_column_label=>'Dokumentendatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(885720974880440872)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2269720'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LINK_NETZ:PERMALINK:VORSCHRIFT_NUMMER:DOKUMENTENDATUM:VORSCHRIFT_BEZEICHNUNG:HOMOLOGATIONSRELEVANT:COP_RELEVANT:VORSCHRIFT_STATUSID:LAENDER_CLUSTERUNG:THEMA_NUMMER:THEMA_BEZEICHNUNG:BEMERKUNG:MFVIDS:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(885807869567768089)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(885738596396484648)
,p_button_name=>'BTN_LAENDER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('L\00E4nder')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-info-square'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(804986789339965103)
,p_name=>'Click Button Laender Info'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(885807869567768089)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(804986650268965102)
,p_event_id=>wwv_flow_imp.id(804986789339965103)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'javascript:window.open(''f?p=&APP_ID.:130:&SESSION.'',''_blank'');'
);
wwv_flow_imp.component_end;
end;
/
