prompt --application/pages/page_00460
begin
--   Manifest
--     PAGE: 00460
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>460
,p_name=>'3MS Filtered Results'
,p_alias=>'3MS-FILTERED-RESULTS'
,p_step_title=>'3MS Filtered Results'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#APP_FILES#page460Functions.js'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// functions moved to external file',
'function initializePageOnLoad() {',
'    console.log("Page 460 initialized - functions loaded from external file");',
'}',
'',
'',
'',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// // Initialize the page',
'// initializePageOnLoad();',
'',
'// // Initial card loading ',
'// if (typeof loadCardContent === ''function'') {',
'//     loadCardContent();',
'// }',
'',
'',
'// loadCardContent();',
'',
'',
'',
'// Initialize the page',
'initializePageOnLoad();',
'',
'// Initial card loading ',
'if (typeof loadCardContent === ''function'') {',
'    loadCardContent();',
'}',
'',
'// Move ''SelectedFilterName'' button next to region title',
'$(document).ready(function() {',
'    ',
'    // Find ONLY the first title area of the main region',
'    var targetTitleArea = $(''#FilterLaenderVorschriften'')',
'                            .find(''.t-Region-headerItems--title'')',
'                            .first();',
'',
'    $(''#selectedfilter'')',
'      .detach() // Remove it from its current location',
'      .appendTo(targetTitleArea) // Append it to ONLY the first title area',
'      .css({',
'        ''display'': ''inline-block'',',
'        ''margin-left'': ''16px'', // some space',
'        ''margin-bottom'': ''0'' // Align it vertically',
'      });',
'});',
'',
'loadCardContent();'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/***********************',
' * Button Styles',
' ***********************/',
'/* Gradient Button Styling for Filter */',
'button#B501317057147707225 {',
'    background: linear-gradient(90deg, #bb0a31 0%, #d01a45 50%, #bb0a31 100%); ',
'    color: white; ',
'    padding: 8px 12px;',
'    border: none; ',
'    border-radius: 2px; ',
'    font-size: 12px; ',
'    cursor: pointer; ',
'    transition: background 0.3s ease-in-out; ',
'    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2); ',
'}',
'',
'button#B501317057147707225:hover {',
'    background: linear-gradient(90deg, #d01a45 0%, #e02b55 50%, #d01a45 100%); ',
'    box-shadow: 0 6px 8px rgba(0, 0, 0, 0.3);',
'}',
'',
'/***********************',
' * Message Styles',
' ***********************/',
'/* No Data Found Message */',
'.no-data-message {',
'    background-color: #f5f5f5;',
'    color: #404040;',
'    padding: 8px 12px;',
'    font-family: ''Segoe UI'', Arial, sans-serif;',
'    border-left: 3px solid #bb0a31;',
'    margin: 10px 0;',
'    font-size: 14px;',
'    line-height: 1.4;    ',
'}',
'',
'.highlight {',
'    color: #d60c38;',
'}',
'',
'/***********************',
' * Region Height Settings',
' ***********************/',
'/* ',
'.heightclass { ',
'    min-height: 250px;',
'    max-height: 697px; ',
'    overflow: auto;',
'} ',
'*/',
'',
'/***********************',
' * Custom Alert Styles ',
' ***********************/',
'/* ',
'.custom-alert {',
'    margin: 4px 0;',
'    padding: 6px 8px;',
'    background-color: #fff3e0;',
'    border-left: 3px solid #bb0a31;',
'    font-size: 13px;',
'    font-family: "Audi Type", sans-serif;',
'}',
'',
'.alert-content {',
'    display: flex;',
'    align-items: center;',
'    gap: 8px;',
'}',
'',
'.alert-icon {',
'    color: #bb0a31;',
'    font-size: 12px;',
'    flex-shrink: 0;',
'}',
'',
'.alert-text {',
'    line-height: 1.3;',
'}',
'*/',
'',
'/***********************',
' * Report Cell Styles',
' ***********************/',
'/*',
'.t-Report-cell {',
'    background-color: #E0E0E0;',
'}',
'*/',
'',
'/***********************',
' * Region Height Override',
' ***********************/',
'/*',
'#R43543646345346 {',
'    height: 700px;',
'    overflow-y: auto;',
'}',
'*/',
'',
'/***********************',
' * Checkbox and Popup Styles',
' ***********************/',
'.apex-item-single-checkbox input:checked+.u-checkbox:after, ',
'.apex-item-single-checkbox input:checked+label:after, ',
'.u-checkbox.is-checked:after {',
'    opacity: 1;',
'    background-color: #bb0a31;',
'}',
'',
'.apex-item-single-checkbox {',
'    margin-top: 13px;',
'}',
'',
'.a-PopupLOV-clearButton:hover {',
'    background-color: #bb0a31;',
'}',
'',
'/***********************',
' * Card Layout Styles',
' ***********************/',
'.cards-region .card-container {',
'    transition: background-color 0.3s ease;',
'    margin-bottom: 16px;',
'    border: 1px solid #e0e0e0;',
'    border-radius: 8px;',
'    box-shadow: 0 2px 4px rgba(0,0,0,0.1);',
'    position: relative;',
'}',
'',
'.cards-region .card-container .header-container {',
'    display: flex;',
'    justify-content: space-between;',
'    align-items: center;',
'    background-color: #f5f5f5;',
'    padding: 12px;',
'    border-radius: 6px;',
'    gap: 8px;',
'    flex-wrap: nowrap;',
'}',
'',
'',
'.title-section {',
'    display: flex;',
'    flex-wrap: wrap;',
'    flex-grow: 1;',
'    overflow: hidden;',
'    min-width: 0;',
'}',
'',
'.action-buttons {',
'    display: flex;',
'    align-items: center;',
'    gap: 8px;',
'    flex-shrink: 0;',
'    margin-left: auto;',
'}',
'',
'.cards-region .card-container .country-name {',
'    font-size: 16px;',
'    color: #333;',
'    font-family: "Audi Type", "Helvetica Neue", Helvetica, Arial, sans-serif;',
'    flex-grow: 1;',
'    white-space: pre-line;',
'    word-break: break-word;',
'    overflow-wrap: break-word;',
'    min-width: 0;',
'    margin-right: 8px;',
'}',
'',
'/***********************',
' * Download Icon Styles',
' ***********************/',
'',
'.download-icon {',
'    display: inline-flex;',
'    align-items: center;',
'    justify-content: center;',
'    width: 34px;',
'    height: 34px;',
'    border-radius: 50%;',
'    margin-left: 8px;',
'    cursor: pointer;',
'    transition: all 0.3s ease;',
'    box-shadow: 0 2px 4px rgba(0,0,0,0.2);',
'    border: 2px solid #ddd;',
'',
'    background-color: #bb0a31;',
'    color: #f5f5f5;',
'}',
'',
'.download-icon:hover {',
'    transform: scale(1.1);',
'    box-shadow: 0 3px 6px rgba(0,0,0,0.3);',
'    /* background-color: #bb0a31; */',
'    color: white;',
'    border-color: #d01a45;',
'}',
'',
'.download-icon .fa-download-alt {',
'    font-size: 14px;',
'    transition: transform 0.3s ease;',
'}',
'',
'/* .download-icon:hover .fa-download-alt {',
'    transform: rotate(-15deg);',
'} */',
'',
'',
'.download-icon:hover .fa-download-alt {',
'    transform: translateY(2px);',
'}',
'',
'',
'',
'',
'/***********************',
' * Report and Table Styles',
' ***********************/',
'.t-Report {',
'    margin-top: 12px;',
'}',
'',
'.t-Report-colHead {',
'    transition: background-color .2s;',
'    background-color: #fafafa;',
'    padding: 12px 8px;',
'    height: 40px;',
'    text-align: center;',
'}',
'',
'.t-Report-cell {',
'    padding: 8px 12px;',
'    height: 32px;',
'    text-align: center;',
'}',
'',
'.t-Report-report {',
'    width: 100%;',
'    table-layout: fixed;',
'    border-collapse: separate;',
'}',
'',
'.a-CardView {',
'    border: none;',
'}',
'',
'.a-CardView-items {',
'    gap: 0px !important;',
'}',
'',
'',
'/* .t-Report-report th,',
'.t-Report-report td {',
'    border: 1px solid #e0e0e0;',
'} */',
'',
'/***********************',
' * Alert Confirmation Styles',
' ***********************/',
'.a-AlertMessage {',
'    padding-left: 20px;',
'    padding-right: 20px;',
'    padding-bottom: 20px;',
'}',
'',
'.delete_confirm {',
'    cursor: pointer;',
'}',
'',
'',
'/* Sticky Headers */',
'.fixed-table-header {',
'    position: sticky;',
'    top: 0;',
'    background-color: #fafafa;',
'    z-index: 10;',
'    box-shadow: 0 1px 3px rgba(0,0,0,0.1);',
'}',
'',
'',
'',
'.t-Report-colHead {',
'    position: sticky;',
'    top: 0;',
'    z-index: 10;',
'    background-color: #fafafa;',
'    box-shadow: 0 1px 3px rgba(0,0,0,0.1);',
'}',
'',
'.t-Report-tableWrap {',
'    max-height: 500px;',
'    overflow-y: auto;',
'}',
'',
'',
'',
'/***************************',
' * Status indicator styles',
' ***************************/',
'',
'.status-indicator, .view-full-button',
'/* , .download-icon  */',
'{',
'    flex-shrink: 0;',
'    width: 28px !important; ',
'    height: 28px !important; ',
'    min-width: 28px !important;',
'    min-height: 28px !important;',
'}',
'',
'',
'',
'.status-indicator {',
'    display: inline-flex;',
'    align-items: center;',
'    justify-content: center;',
'    width: 28px;',
'    height: 28px;',
'    border-radius: 50%;',
'    margin-left: 8px;',
'    cursor: pointer;',
'    transition: all 0.3s ease;',
'    box-shadow: 0 2px 4px rgba(0,0,0,0.2);',
'    border: 2px solid #ddd;',
'}',
'',
'.status-indicator.not-started {',
'    background-color: #e8f5e9;',
'    border: 2px solid #c8e6c9;',
'    color: #388e3c;',
'}',
'',
'.status-indicator.in-progress {',
'    background-color: #f39c12;',
'    color: white;',
'    border: 2px solid #e67e22;',
'}',
'',
'.status-indicator.completed {',
'    background-color: #2ecc71;',
'    color: white;',
'    border: 2px solid #27ae60;',
'}',
'',
'.status-indicator:hover {',
'    transform: scale(1.1);',
'    box-shadow: 0 3px 6px rgba(0,0,0,0.3);',
'}',
'',
'',
'',
'/**********************************************************',
' * Card Title',
' **********************************************************/',
'',
'',
'',
'.title-container {',
'    display: flex;',
'    flex-wrap: wrap;',
'    align-items: center;',
'    flex-grow: 1;',
'    overflow: hidden;',
'}',
'',
'',
'.edit-icon, .reset-icon, .save-icon, .cancel-icon {',
'    cursor: pointer;',
'    padding: 4px;',
'    margin-right: 4px;',
'    border-radius: 50%;',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    background-color: #f5f5f5;',
'    width: 24px;',
'    height: 24px;',
'    transition: all 0.2s;',
'    flex-shrink: 0;',
'}',
'',
'.edit-icon:hover, .reset-icon:hover, .save-icon:hover, .cancel-icon:hover {',
'    background-color: #e0e0e0;',
'    transform: scale(1.1);',
'}',
'',
'/*',
'.custom-title-indicator {',
'    font-weight: bold;',
'    color: #2563EB;',
'    background-color: rgba(37, 99, 235, 0.06);',
'     padding-left: 4px;',
'    padding: 3px 8px; ',
'    margin-right: 8px;',
'    border-left: 3px solid #2563EB;',
'    font-size: 18px;',
'    flex-shrink: 0;',
'}',
'',
'',
'.custom-title-indicator:hover {',
'    background-color: rgba(37, 99, 235, 0.12);',
'    cursor: default;',
'}',
'*/',
'',
'',
'.custom-title-indicator {',
'    font-weight: bold;',
'    color: #2563EB;',
'    background-color: rgba(37, 99, 235, 0.08);',
'    padding: 4px 10px;',
'    margin-right: 10px;',
'    border-left: 3px solid #2563EB;',
'    border-radius: 0 4px 4px 0;',
'    font-size: 14px;',
'    flex-shrink: 0;',
'    transition: all 0.2s ease;',
'    box-shadow: 0 1px 2px rgba(37, 99, 235, 0.15);',
'    text-shadow: 0 1px 0 rgba(255, 255, 255, 0.8);',
'    letter-spacing: 0.3px;',
'}',
'',
'',
'.custom-title-indicator:hover {',
'    background-color: rgba(37, 99, 235, 0.12);',
'    box-shadow: 0 2px 4px rgba(37, 99, 235, 0.25);',
'}',
'',
'',
'/* .custom-title-indicator::before {',
'    content: "\f02b"; ',
'    font-family: "Font Awesome 5 Free", "FontAwesome";',
'    margin-right: 6px;',
'    font-size: 12px;',
'    opacity: 0.8;',
'    position: relative;',
'    top: -1px;',
'} */',
'',
'.title-edit-input {',
'    flex-grow: 0;',
'    width: 200px;',
'    padding: 4px 8px;',
'    border: 1px solid #ccc;',
'    border-radius: 3px;',
'    margin-right: 4px;',
'    font-size: 14px;',
'}',
'',
'.title-edit-input::placeholder {',
'    font-size: 12px;',
'    color: #999;',
'}',
'',
'.country-name {',
'    width: 100%;',
'    margin-top: 4px;',
'    flex-basis: 100%;',
'    word-break: break-word;',
'    white-space: pre-line;',
'}',
'',
'',
'',
'/**********************************************************',
' * Go from Page 460 to 461 using Expand or Collapse Icon',
' **********************************************************/',
'',
'.view-full-button {',
'    display: inline-flex;',
'    align-items: center;',
'    justify-content: center;',
'    width: 28px;',
'    height: 28px;',
'    border-radius: 50%;',
'    margin-left: 8px;',
'    cursor: pointer;',
'    transition: all 0.3s ease;',
'    box-shadow: 0 2px 4px rgba(0,0,0,0.2);',
'    border: 2px solid #ddd;',
'    background-color: #f5f5f5;',
'',
'    color: #666;',
'}',
'',
'.view-full-button:hover {',
'    transform: scale(1.1);',
'    box-shadow: 0 3px 6px rgba(0,0,0,0.3);',
'    /* background-color: #bb0a31; */',
'    color: white;',
'    border-color: #d01a45;',
'}',
'',
'.view-full-button .fa-expand {',
'    font-size: 14px;',
'    transition: transform 0.3s ease;',
'}',
'',
'.view-full-button:hover .fa-expand {',
'    transform: rotate(15deg);',
'} ',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'/**********************************************************',
' * Countries Header List Expand or Collapse',
' **********************************************************/',
'',
'',
'.show-more, .show-less {',
'    display: inline-block;',
'    cursor: pointer;',
'    color: #bb0a31;',
'    margin-left: 5px;',
'    margin-top: 8px !important;',
'    font-size: 13px;',
'    vertical-align: middle;',
'    background-color: #f5f5f5;',
'    padding: 2px 6px;',
'    border-radius: 3px;',
'    border: 1px solid #e0e0e0;',
'    transition: all 0.2s ease;',
'}',
'',
'.show-more:hover, .show-less:hover {',
'    color: #d01a45;',
'    background-color: #efefef;',
'    border-color: #ccc;',
'    text-decoration: underline;',
'}',
'',
'.show-more i, .show-less i {',
'    margin-right: 4px;',
'    font-size: 14px;',
'    vertical-align: middle;',
'    position: relative;',
'    top: -1px;',
'}',
'',
'',
'',
'',
'/* .read-only-status {',
'    cursor: default !important;',
'    opacity: 0.9;',
'} */',
'',
'.read-only-status {',
'    cursor: default !important;',
'',
'    opacity: 0.9;',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'/* Fix horizontal scrolling */',
'.t-Report-tableWrap {',
'    width: 100%;',
'    overflow-x: hidden !important;',
'}',
'',
'.t-Report-report {',
'    width: 100% !important;',
'    table-layout: fixed !important;',
'}',
'',
'/* Column widths */',
'.t-Report-report th:nth-child(1),',
'.t-Report-report td:nth-child(1) {',
'    width: 40% !important;',
'}',
'',
'.t-Report-report th:nth-child(2),',
'.t-Report-report td:nth-child(2) {',
'    width: 30% !important;',
'}',
'',
'.t-Report-report th:nth-child(3),',
'.t-Report-report td:nth-child(3) {',
'    width: 30% !important;',
'}',
'',
'/* Text wrapping */',
'.t-Report-cell {',
'    word-wrap: break-word !important;',
'    white-space: normal !important;',
'}',
'',
'',
'/*                */',
'',
'',
'',
'',
'.t-IRR-region,',
'.t-Report,',
'.t-IRR-table,',
'.a-IRR-table,',
'.t-Report-report {',
'    width: 100% !important;',
'    table-layout: fixed !important;',
'    max-width: none !important;',
'}',
'',
'',
'.t-IRR-tableContainer,',
'.t-Report-tableWrap {',
'    overflow-x: hidden !important;',
'    max-width: 100% !important;',
'}',
'',
'',
'.t-Report-cell,',
'td.t-Report-cell,',
'th.t-Report-colHead,',
'td[headers],',
'th[id] {',
'    white-space: normal !important;',
'    word-wrap: break-word !important;',
'    overflow-wrap: break-word !important;',
'    text-overflow: ellipsis !important;',
'}',
'',
'',
'[headers$="LANDBEZEICHNUNG"],',
'[id$="LANDBEZEICHNUNG"] {',
'    width: 20% !important;',
'}',
'[headers$="THEMABEZEICHNUNG"],',
'[id$="THEMABEZEICHNUNG"] {',
'    width: 35% !important;',
'}',
'[headers$="VORSCHRIFTENNUMMER"],',
'[id$="VORSCHRIFTENNUMMER"] {',
'    width: 25% !important;',
'}',
'[headers$="ALTERNATIVE_VORSCHRIFTENNUMMER"],',
'[id$="ALTERNATIVE_VORSCHRIFTENNUMMER"] {',
'    width: 20% !important;',
'}',
'',
'',
'.a-IRR-container {',
'    overflow-x: hidden !important;',
'}',
'',
'',
'',
'',
'',
'/* Change only the success icon to green */',
'.t-Alert--success .t-Alert-icon .t-Icon {',
'    color: #2ecc71 !important; ',
'}',
'',
'',
'.t-Alert--success .t-Button--closeAlert .t-Icon {',
'    color: inherit !important; ',
'}',
'',
'',
'',
'',
'',
'/* Add this CSS to your page 460 CSS section */',
'.clickable-reg {',
'    cursor: pointer !important;',
'    color: #bb0a31 !important;',
'    text-decoration: underline !important;',
'    padding: 8px 12px !important;',
'    height: 32px !important;',
'    text-align: left !important;',
'}',
'',
'.clickable-reg:hover {',
'    background-color: #f0f0f0 !important;',
'}',
'',
'',
'',
'span.js-maximizeButtonContainer button {',
'    display: none;   ',
'}',
'',
'',
'',
'',
'',
'#report_501317562849707230 #P460_JUMP_TO_CARD_CONTAINER {',
'    display: none !important;',
'}',
'',
'',
'',
'',
' /* Warning Icon (Exclamation Triangle) */',
'.warning-icon {',
'    color: #ff6600 !important;',
'    cursor: help;',
'    font-size: 14px !important;',
'    margin-right: 5px;',
'    animation: pulse-warning 2s infinite;',
'}',
'',
'.warning-icon:hover {',
'    color: #ff4400 !important;',
'    transform: scale(1.1);',
'    animation: none;',
'}',
'',
'/* Checkmark Icon */',
'.checkmark-icon {',
'    color: #27ae60 !important;',
'    cursor: help;',
'    font-size: 14px !important;',
'    margin-right: 5px;',
'    opacity: 0.9;',
'}',
'',
'.checkmark-icon:hover {',
'    color: #1e8e3e !important;',
'    transform: scale(1.1);',
'    opacity: 1;',
'}',
'',
'/* Pulse Animation for Warning */',
'/* @keyframes pulse-warning {',
'    0% { opacity: 1; }',
'    50% { opacity: 0.6; }',
'    100% { opacity: 1; }',
'}',
' */',
'',
'',
'',
'.separator-line::before {',
'    content: "";',
'    display: block;',
'    width: 100%;',
'    height: 2px;',
'    background-color: #e0e0e0;',
'    margin: 20px 0 10px 0;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* CSS Styles */',
'',
'',
'.cards-region .card-container {',
'    transition: background-color 0.3s ease;',
'    margin-bottom: 16px;',
'    border: 1px solid #e0e0e0;',
'    border-radius: 8px;',
'    box-shadow: 0 2px 4px rgba(0,0,0,0.1);',
'    position: relative;',
'}',
'',
'.cards-region .card-container .header-container {',
'    display: flex;',
'    justify-content: space-between;',
'    align-items: center;',
'    background-color: #f5f5f5;',
'    padding: 12px;',
'    border-radius: 6px;',
'    gap: 8px;',
'    flex-wrap: nowrap;',
'}',
'',
'.cards-region .card-container .country-name {',
'    font-size: 16px;',
'    color: #333;',
'    font-family: "Audi Type", "Helvetica Neue", Helvetica, Arial, sans-serif;',
'    flex-grow: 1;',
'    white-space: pre-line;',
'    word-break: break-word;',
'    overflow-wrap: break-word;',
'    min-width: 0;',
'    margin-right: 8px;',
'}',
'',
'',
'',
'',
'',
'.download-icon {',
'    cursor: pointer;',
'    background-color: #bb0a31;',
'    color: white;',
'    padding: 8px;',
'    border-radius: 50%;',
'    width: 32px;',
'    height: 32px;',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    margin-left: auto;',
'    flex-shrink: 0;',
'    transition: all 0.2s ease;',
'}',
'',
'.download-icon:hover {',
'    background-color: #d01a45 ; /*#99082a*/',
'    transform: scale(1.1);',
'}',
'',
'.t-Report {',
'    margin-top: 12px;',
'}',
'',
'.t-Report-colHead {',
'    transition: background-color .2s;',
'    background-color: #fafafa;',
'}',
'',
'.a-CardView {',
'    border: none;',
'}',
'',
'.a-CardView-items {',
'    gap: 0px !important;',
'}',
'',
'',
'/* Table Cell Styles */',
'.t-Report-cell {',
'    padding: 8px 12px;',
'    height: 32px;',
'    text-align: center;',
'}',
'',
'/* Report Table Styles */',
'.t-Report-report {',
'    width: 100%;',
'    table-layout: fixed;',
'}',
'',
'/* Report Header Styles */',
'.t-Report-colHead {',
'    padding: 12px 8px;',
'    height: 40px;',
'    text-align: center;',
'}',
'',
'function openDetailView(landids, cardNum) {',
'',
'console.log("Opening detail view with landids:", landids);',
'if (!landids || !cardNum) {',
'console.error(''Missing parameters for detail view'');',
'return;',
'}',
'',
'// Get the current status of the card',
'const statusIndicator = document.querySelector(`.status-indicator[data-card="${cardNum}"]`);',
'const currentStatus = statusIndicator ? ',
'(statusIndicator.classList.contains(''not-started'') ? ''not-started'' : ',
'statusIndicator.classList.contains(''in-progress'') ? ''in-progress'' : ''completed'') : ''not-started'';',
'',
'// Mapping status to user-friendly messages',
'const statusMessages = {',
'''not-started'': ''Nicht begonnen'',',
'''in-progress'': ''In Bearbeitung'',',
'''completed'': ''Abgeschlossen''',
'};',
'',
'// var url = ''f?p='' + $v(''pFlowId'') + '':461:'' + $v(''pInstance'') +',
'//     ''::NO:RP:P461_LANDIDS,P461_CARD_NUM,P461_SEARCH_SELECTION,P461_MILESTONE_SELECTION,P461_CARD_STATUS:'' +',
'//     landids + '','' + cardNum + '','' + ',
'//     $v(''P460_SEARCH_SELECTION'') + '','' + ',
'//     $v(''P460_MILESTONE_SELECTION'') + '','' +',
'//     currentStatus;',
'',
'',
'',
'var url = ''f?p='' + $v(''pFlowId'') + '':461:'' + $v(''pInstance'') +',
'    ''::NO:RP:P461_LANDIDS,P461_CARD_NUM,P461_SEARCH_SELECTION,P461_MILESTONE_SELECTION,P461_CARD_STATUS:'' +',
'    landids + '':'' + cardNum + '','' + ',
'    $v(''P460_SEARCH_SELECTION'') + '','' + ',
'    $v(''P460_MILESTONE_SELECTION'') + '','' +',
'    currentStatus;',
'',
'    ',
'// Show success message before opening the detail view',
unistr('// apex.message.showPageSuccess(`\00D6ffne Details f\00FCr Karte ${cardNum} (Status: ${statusMessages[currentStatus]})`);'),
'',
'window.open(url, ''_blank'');',
'}',
'',
''))
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5570784955205133329)
,p_plug_name=>'Suchparameter PRI Postprozess'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11866126095230983706)
,p_plug_name=>'CardControl'
,p_parent_plug_id=>wwv_flow_imp.id(5570784955205133329)
,p_region_css_classes=>'separator-line'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>70
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9764226214019764915)
,p_plug_name=>'Filtersuche'
,p_region_name=>'FilterSuche'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3414119964980820545)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>6
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16429944140422377967)
,p_plug_name=>unistr('Box Vorfilter L\00E4nder')
,p_parent_plug_id=>wwv_flow_imp.id(9764226214019764915)
,p_region_template_options=>'#DEFAULT#:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>120
,p_plug_grid_column_span=>4
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16429945078825379904)
,p_plug_name=>unistr('Box Filter L\00E4nder')
,p_parent_plug_id=>wwv_flow_imp.id(9764226214019764915)
,p_region_template_options=>'#DEFAULT#:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>130
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9764227952700764932)
,p_plug_name=>unistr('Filter L\00E4nder - Vorschriften')
,p_region_name=>'FilterLaenderVorschriften'
,p_region_css_classes=>'cards-regions'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9764228157320764934)
,p_plug_name=>unistr('Vorschriften \00FCbersicht')
,p_region_name=>'report_501317562849707230'
,p_parent_plug_id=>wwv_flow_imp.id(9764227952700764932)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(3414123643808820547)
,p_plug_display_sequence=>40
,p_plug_grid_column_span=>4
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH search_countries AS (',
'    SELECT ',
'        sucheid,',
'        to_number(COLUMN_VALUE) as landid',
'    FROM t_suche_json,',
'    TABLE(apex_string.split(',
'        json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'        '':''',
'    ))',
'    WHERE ',
'    sucheid = :P460_SEARCH_SELECTION  -- Search Selection check',
'    -- AND BENUTZERID = :G_BENUTZERID',
'',
'    AND (BENUTZERID = :G_BENUTZERID ',
'     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                WHERE brr.benutzerid = :G_BENUTZERID ',
'                AND brr.rolleid = 1001))',
'',
'',
'',
'',
')',
'SELECT DISTINCT',
'    sc.sucheid,   ',
'    ms.VORSCHRIFTID,      ',
'    ms.landnummer||'' - ''||ms.landbezeichnung AS Landbezeichnung,',
'    ms.themabezeichnung AS Themabezeichnung,',
'    -- ms.vorschriftnummer AS Vorschriftennummer,',
'',
'    -- ''<a href="f?p='' || :APP_ID || '':25:'' || :APP_SESSION || ''::'' || :DEBUG || '':RP,25:P25_VORSCHRIFTID:'' || ms.VORSCHRIFTID || ''" target="_blank">'' || ms.vorschriftnummer || ''</a>'' AS Vorschriftennummer,',
'    ''<a href="f?p='' || :APP_ID || '':25:'' || :APP_SESSION || ''::'' || :DEBUG || '':RP,25:P25_VORSCHRIFTID:'' || ms.VORSCHRIFTID || ''" target="_blank">'' || ',
'        CASE ',
'            WHEN p_main.ANZEIGE_MIT_DOKUMENTENDATUM = 20 AND v_main.DOKUMENTENDATUM IS NOT NULL ',
'            THEN v_main.vorschrift_nummer || ''_'' || TO_CHAR(v_main.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'            ELSE ms.vorschriftnummer',
'        END ',
'    || ''</a>'' AS Vorschriftennummer,',
'    nvl(tv.vorschrift_nummer, '''') AS Alternative_Vorschriftennummer',
'FROM search_countries sc',
'LEFT JOIN T_MS_SUCHERGEBNISS ms ON (',
'    ms.sucheid = sc.sucheid ',
'    AND ms.landid = sc.landid',
'    AND ms.meilenstein = :P460_MILESTONE_SELECTION  ',
'    AND sc.landid NOT IN (select column_value from table(apex_string.split_numbers(:P460_FILTER_LAND, '':'')))',
'    -- AND sc.LANDID NOT IN (SELECT LANDID FROM T_MS_SUCHE_SPLIT WHERE BENUTZERID=:G_BENUTZERID AND SUCHEID=:P460_SEARCH_SELECTION AND MEILENSTEIN =:P460_MILESTONE_SELECTION)',
'',
'    AND sc.LANDID NOT IN (',
'    SELECT LANDID FROM T_MS_SUCHE_SPLIT ',
'    WHERE (BENUTZERID = :G_BENUTZERID ',
'           OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                      WHERE brr.benutzerid = :G_BENUTZERID ',
'                      AND brr.rolleid = 1001))',
'    AND SUCHEID = :P460_SEARCH_SELECTION ',
'    AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
')',
'',
')',
'',
'LEFT JOIN t_vorschrift v_main ON v_main.vorschriftid = ms.VORSCHRIFTID',
'LEFT JOIN t_publisher p_main ON p_main.publisherid = v_main.publisherid',
'',
'',
'LEFT OUTER JOIN t_vorschrift tv ON (tv.vorschriftid = ms.alternative_vorschriftid)',
'LEFT OUTER JOIN t_ms_parameter tmp ON (ms.regelnummer = tmp.nummer)',
'',
'WHERE ms.VORSCHRIFTID IS NOT NULL  AND tmp.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1 ',
'',
'GROUP BY ',
'    ms.vorschriftnummer,',
'    ms.VORSCHRIFTID,',
'    ms.landnummer,',
'    ms.landbezeichnung,',
'    ms.themabezeichnung,',
'    tv.vorschrift_nummer,',
'    v_main.vorschrift_nummer,',
'    v_main.DOKUMENTENDATUM,',
'    p_main.ANZEIGE_MIT_DOKUMENTENDATUM,',
'    sc.sucheid',
'ORDER BY ',
'    Landbezeichnung,',
'    Themabezeichnung,   ',
'    Vorschriftennummer'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P460_FILTER_LAND,P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Vorschriften \00FCbersicht')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH search_countries AS (',
'    SELECT ',
'        sucheid,',
'        to_number(COLUMN_VALUE) as landid',
'    FROM t_suche_json,',
'    TABLE(apex_string.split(',
'        json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'        '':''',
'    ))',
'    where ',
'    sucheid = :P460_SEARCH_SELECTION  -- Search Selection check',
'   and BENUTZERID = :G_BENUTZERID',
')',
'SELECT DISTINCT',
'    sc.sucheid,   ',
'    ms.VORSCHRIFTID,      ',
'    ms.landnummer||'' - ''||ms.landbezeichnung AS Landbezeichnung,   ',
'    ms.vorschriftnummer as Vorschriftennummer',
'    ',
'',
'FROM search_countries sc',
'LEFT JOIN T_MS_SUCHERGEBNISS ms ON (',
'    ms.sucheid = sc.sucheid ',
'    AND ms.landid = sc.landid',
'     AND ms.meilenstein = :P460_MILESTONE_SELECTION  ',
'    and  sc.landid not in (select column_value from table(apex_string.split_numbers(:P460_FILTER_LAND, '':'')))',
'     AND sc.LANDID NOT IN (SELECT LANDID FROM T_MS_SUCHE_SPLIT WHERE BENUTZERID=:G_BENUTZERID AND SUCHEID	=:P460_SEARCH_SELECTION AND MEILENSTEIN =:P460_MILESTONE_SELECTION )',
')',
'where VORSCHRIFTID is not null ',
'',
'GROUP BY ',
'    ms.vorschriftnummer,',
'    ms.VORSCHRIFTID,',
'    ms.landnummer,',
'    ms.landbezeichnung,',
'    sc.sucheid',
'ORDER BY ',
'    Landbezeichnung,   ',
'    Vorschriftennummer; '))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(9764229765692764950)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="no-data-message">',
unistr('    Es wurden <span class="highlight">keine</span> Vorschriftsnummern f\00FCr diese L\00E4nder gefunden. Bitte planen Sie die erforderlichen L\00E4nder.'),
'',
'</div>'))
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>500
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'VORSCHRIFTEN_ADMIN'
,p_internal_uid=>13436442081592153185
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964333027504509460)
,p_db_column_name=>'SUCHEID'
,p_display_order=>10
,p_column_identifier=>'I'
,p_column_label=>'Sucheid'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964333795504509461)
,p_db_column_name=>'VORSCHRIFTID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Vorschriftid'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964333427997509460)
,p_db_column_name=>'LANDBEZEICHNUNG'
,p_display_order=>30
,p_column_identifier=>'E'
,p_column_label=>'Landbezeichnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964332655155509459)
,p_db_column_name=>'VORSCHRIFTENNUMMER'
,p_display_order=>40
,p_column_identifier=>'K'
,p_column_label=>'Vorschriftennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964332270686509459)
,p_db_column_name=>'THEMABEZEICHNUNG'
,p_display_order=>50
,p_column_identifier=>'L'
,p_column_label=>'Themabezeichnung'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(964331863684509458)
,p_db_column_name=>'ALTERNATIVE_VORSCHRIFTENNUMMER'
,p_display_order=>60
,p_column_identifier=>'M'
,p_column_label=>'Alternative Vorschriftennummer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(11853338457621811005)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'25904279'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'LANDBEZEICHNUNG:THEMABEZEICHNUNG:VORSCHRIFTENNUMMER:ALTERNATIVE_VORSCHRIFTENNUMMER:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11864429245647029746)
,p_plug_name=>'Cards'
,p_region_name=>'R43543646345346'
,p_parent_plug_id=>wwv_flow_imp.id(9764227952700764932)
,p_region_css_classes=>'cards-region'
,p_region_template_options=>'#DEFAULT#:margin-top-none'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3414115547641820543)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH selected_countries AS (',
'    SELECT ',
'        sc.card_number,',
'        sc.landids',
'    FROM (',
'        SELECT ',
'            tms.card_number,',
'            LISTAGG(tms.landid, '':'') WITHIN GROUP (ORDER BY l.B_NUMMER) AS landids',
'        FROM t_land l',
'        JOIN T_MS_SUCHE_SPLIT tms ON (l.LANDID = tms.LANDID)',
'        -- WHERE tms.BENUTZERID = :G_BENUTZERID',
'        WHERE (tms.BENUTZERID = :G_BENUTZERID ',
'            OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                  WHERE brr.benutzerid = :G_BENUTZERID ',
'                  AND brr.rolleid = 1001))',
'        AND tms.SUCHEID = :P460_SEARCH_SELECTION',
'        AND tms.MEILENSTEIN = :P460_MILESTONE_SELECTION',
'        GROUP BY tms.card_number',
'    ) sc',
')',
'SELECT ',
'    ''<div class="card-container" data-cardnum="'' || sc.card_number || ''">'' ||',
'    ''<div id="card_'' || sc.card_number || ''" class="card-placeholder" '' ||',
'    ''data-card="'' || sc.card_number || ''" '' ||',
'    ''data-landids="'' || sc.landids || ''">&nbsp;</div>'' ||  -- Loading card content...',
'    ''</div>'' AS card_text,',
'    NULL AS card_subtext,',
'    NULL AS card_link,',
'    NULL AS card_icon_link,',
'    NULL AS card_icon',
'FROM selected_countries sc;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="no-data-message">',
unistr('    Es wurden <span class="highlight">keine</span> Vorschriftsnummern f\00FCr diese L\00E4nder gefunden. Bitte planen Sie die erforderlichen L\00E4nder.'),
'</div>'))
,p_show_total_row_count=>true
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'R43543646345346',
'',
'WITH selected_countries AS (',
'    SELECT ',
'        sc.card_number,',
'        sc.landids',
'    FROM (',
'        SELECT ',
'            tms.card_number,',
'            LISTAGG(tms.landid, '':'') WITHIN GROUP (ORDER BY l.B_NUMMER) AS landids',
'        FROM t_land l',
'        JOIN T_MS_SUCHE_SPLIT tms ON (l.LANDID = tms.LANDID)',
'        WHERE tms.BENUTZERID = :G_BENUTZERID',
'        AND tms.SUCHEID = :P460_SEARCH_SELECTION',
'        AND tms.MEILENSTEIN = :P460_MILESTONE_SELECTION',
'        GROUP BY tms.card_number',
'    ) sc',
')',
'SELECT ',
'    ''<div class="card-container" data-cardnum="'' || sc.card_number || ''">'' ||',
'    ''<div id="card_'' || sc.card_number || ''" class="card-placeholder" '' ||',
'    ''data-card="'' || sc.card_number || ''" '' ||',
'    ''data-landids="'' || sc.landids || ''">&nbsp;</div>'' ||  -- Loading card content...',
'    ''</div>'' AS card_text,',
'    NULL AS card_subtext,',
'    NULL AS card_link,',
'    NULL AS card_icon_link,',
'    NULL AS card_icon',
'FROM selected_countries sc;',
'',
'',
'R43543646345346',
'',
'',
'&CARD_TITLE!RAW.',
'',
'',
'cards-region',
'',
'',
''))
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(964330467896509437)
,p_region_id=>wwv_flow_imp.id(11864429245647029746)
,p_layout_type=>'GRID'
,p_grid_column_count=>2
,p_title_adv_formatting=>false
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>'&CARD_TEXT!RAW.'
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9789823856764735135)
,p_plug_name=>'Filter Profile Configuration'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(3414126953447820548)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964329993991509431)
,p_button_sequence=>20
,p_button_name=>'BTN_BACK_TO_HUB'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Zur\00FCck zum Post-process Hub')
,p_button_redirect_url=>'f?p=&APP_ID.:482:&SESSION.::&DEBUG.:482:P482_POSTPROZESS_ID:&P460_POSTPROZESS_ID.'
,p_icon_css_classes=>'fa-long-arrow-left'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ssrver sifde ',
'',
'itme is not nuill ',
'',
'P460_POSTPROZESS_ID'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964334820940509474)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9764227952700764932)
,p_button_name=>'MAXIMIZE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Vollbildansicht'
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-expand'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964339922954509479)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9789823856764735135)
,p_button_name=>'VERGLEICHEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--warning:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'Vergleichen'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:471:&SESSION.::&DEBUG.:471:P471_SEARCH_1,P471_MILESTONE_1:&P460_SEARCH_SELECTION.,&P460_MILESTONE_SELECTION.'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa fa-code-fork fa-rotate-180'
,p_button_comment=>':G_BENUTZERID = 2000'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964339554362509478)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(9789823856764735135)
,p_button_name=>'BTN_COPY_PERMALINK'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_image_alt=>'Permalink in Zwischenablage kopieren'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa fa-link'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964339159241509477)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(9789823856764735135)
,p_button_name=>'SaveFilterSettings'
,p_button_static_id=>'savefilter'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Einstellungen speichern'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'<span aria-hidden="true" class="fa fa-save fam-check fam-is-success" style="color: white;"></span>'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964338735598509477)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(9789823856764735135)
,p_button_name=>'LoadorManageFilterSettings'
,p_button_static_id=>'loadfilter'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'Einstellungen laden/verwalten'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-save-as'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964338350322509477)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(9789823856764735135)
,p_button_name=>'SelectedFilterName'
,p_button_static_id=>'selectedfilter'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>unistr('<b>Ausgew\00E4hlter Filtername</b> <b><u><i><span style="color:#bb0a31; font-size:14px">&P460_START_PROFILE.</span></i></u></b>')
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-user-check'
,p_button_comment=>'<b>Selected Filter&View Name</b>: <b><u><i>&P460_START_PROFILE.<.i></u></b>'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964352257500509503)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5570784955205133329)
,p_button_name=>'APPLY_ACTION_BUTTON'
,p_button_static_id=>'APPLY_ACTION_BUTTON'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_image_alt=>'Aktion anwenden'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964347284027509488)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(9764226214019764915)
,p_button_name=>'FilterAnwenden'
,p_button_static_id=>'B501317057147707225'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(3414144835517820567)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Kachel erstellen'
,p_button_position=>'NEXT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-filter'
,p_button_comment=>'gradient-button'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(964331204381509440)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9764228157320764934)
,p_button_name=>'DownloadExcelReport'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(3414144604626820566)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Daten herunterladen f\00FCr Aller L\00E4nder Vorschriften')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-download-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964351844607509501)
,p_name=>'P460_SEARCH_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(5570784955205133329)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Name der Suche'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT tsj.bezeichnung',
'FROM t_suche_json tsj',
'WHERE tsj.sucheid = :P460_SEARCH_SELECTION',
'AND (tsj.benutzerid = :G_BENUTZERID ',
'     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                WHERE brr.benutzerid = :G_BENUTZERID ',
'                AND brr.rolleid = 1001))'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964351444589509499)
,p_name=>'P460_SEARCH_SOP'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(5570784955205133329)
,p_use_cache_before_default=>'NO'
,p_prompt=>'SOP Datum'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR(TO_DATE(jt.datum_sop), ''DD.MM.YYYY'')',
'FROM t_suche_json tsj,',
'JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'    meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'    datum_sop VARCHAR2(20) PATH ''$.DATUM_SOP''',
')) jt',
'WHERE tsj.sucheid = :P460_SEARCH_SELECTION',
'AND jt.meilenstein = :P460_MILESTONE_SELECTION',
'AND jt.datum_sop IS NOT NULL',
'AND (tsj.benutzerid = :G_BENUTZERID ',
'     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                WHERE brr.benutzerid = :G_BENUTZERID ',
'                AND brr.rolleid = 1001))'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964351081172509498)
,p_name=>'P460_SEARCH_EOP'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(5570784955205133329)
,p_use_cache_before_default=>'NO'
,p_prompt=>'EOP Datum'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR(TO_DATE(jt.datum_eop), ''DD.MM.YYYY'')',
'FROM t_suche_json tsj,',
'JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'    meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'    datum_eop VARCHAR2(20) PATH ''$.DATUM_EOP''',
')) jt',
'WHERE tsj.sucheid = :P460_SEARCH_SELECTION',
'AND jt.meilenstein = :P460_MILESTONE_SELECTION',
'AND jt.datum_eop IS NOT NULL',
'AND (tsj.benutzerid = :G_BENUTZERID ',
'     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                WHERE brr.benutzerid = :G_BENUTZERID ',
'                AND brr.rolleid = 1001))'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964350681676509498)
,p_name=>'P460_SEARCH_TYPE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(5570784955205133329)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Suche Typ'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE jt.suchtyp',
'        WHEN ''0'' THEN ''Neue Typen''',
'        WHEN ''10'' THEN ''Bestehender Typ''',
'        ELSE ''Nicht angegeben''',
'    END',
'FROM t_suche_json tsj,',
'JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'    meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'    suchtyp VARCHAR2(20) PATH ''$.SUCHTYP''',
')) jt',
'WHERE tsj.sucheid = :P460_SEARCH_SELECTION',
'AND jt.meilenstein = :P460_MILESTONE_SELECTION',
'AND (tsj.benutzerid = :G_BENUTZERID ',
'     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                WHERE brr.benutzerid = :G_BENUTZERID ',
'                AND brr.rolleid = 1001))'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964350287083509497)
,p_name=>'P460_KPB_NUMBERS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(5570784955205133329)
,p_use_cache_before_default=>'NO'
,p_prompt=>'KPB Nummern'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT listagg(unique_val, '', '') WITHIN GROUP (ORDER BY unique_val)',
'FROM (',
'    SELECT DISTINCT TRIM(column_value) as unique_val',
'    FROM ',
'    (',
'        -- query to get the raw string',
'        SELECT',
'             jt.kpb_values',
'        FROM',
'            t_suche_json tsj,',
'            JSON_TABLE(tsj.suchdaten, ''$[*]''',
'                COLUMNS (',
'                    meilenstein NUMBER         PATH ''$.MEILENSTEIN'',',
'                    kpb_values  VARCHAR2(4000) PATH ''$.KPB''',
'                )',
'            ) jt',
'        WHERE',
'            tsj.sucheid = :P460_SEARCH_SELECTION',
'            AND jt.meilenstein = :P460_MILESTONE_SELECTION',
'    ) source_data,',
'    -- Split the string by comma to process individual items',
'    TABLE(apex_string.split(source_data.kpb_values, '',''))',
')'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    distinct jt.kpb_values',
'FROM',
'    t_suche_json tsj,',
'    JSON_TABLE(tsj.suchdaten, ''$[*]''',
'        COLUMNS (',
'            meilenstein NUMBER         PATH ''$.MEILENSTEIN'',',
'             kpb_values  VARCHAR2(4000) PATH ''$.KPB''',
'        )',
'    ) jt',
'WHERE',
'    tsj.sucheid = :P460_SEARCH_SELECTION',
'    AND jt.meilenstein = :P460_MILESTONE_SELECTION'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964349575573509495)
,p_name=>'P460_ACTION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(11866126095230983706)
,p_prompt=>'Kartenverwaltung'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH card_stats AS (',
'    SELECT ',
'        COUNT(DISTINCT card_number) as total_cards,',
'        COUNT(CASE WHEN card_count > 1 THEN 1 END) as merged_cards',
'    FROM (',
'        SELECT card_number, COUNT(*) as card_count',
'        FROM T_MS_SUCHE_SPLIT',
'        WHERE SUCHEID = :P460_SEARCH_SELECTION',
'        AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'        GROUP BY card_number',
'    )',
')',
'SELECT d, r',
'FROM (',
'    -- Delete Card: Show always if any cards exist',
unistr('    SELECT ''Karte l\00F6schen'' as d, ''DELETE_CARD'' as r '),
'    FROM card_stats',
'    WHERE total_cards > 0',
'    ',
'    UNION ALL',
'    ',
'    -- -- Delete Countries: Show when any merged cards exist',
unistr('    -- SELECT ''Bestimmte L\00E4nder aus Karte l\00F6schen'' as d, ''DELETE_COUNTRIES'' as r'),
'    -- FROM card_stats',
'    -- WHERE merged_cards > 0',
'    ',
'    -- UNION ALL',
'    ',
'    -- -- Unmerge Countries: Show when any merged cards exist',
unistr('    -- SELECT ''Bestimmte L\00E4nder aus Karte trennen'' as d, ''UNMERGE_COUNTRIES'' as r'),
'    -- FROM card_stats',
'    -- WHERE merged_cards > 0',
'    ',
'    -- UNION ALL',
'    ',
'    -- Merge Cards: Show only when more than one card exists',
unistr('    SELECT ''Karten zusammenf\00FChren'' as d, ''MERGE_CARD'' as r'),
'    FROM card_stats',
'    WHERE total_cards > 1',
'    ',
'    UNION ALL',
'    ',
'    -- Unmerge Card: Show only when merged cards exist',
'    SELECT ''Karte trennen'' as d, ''UNMERGE_CARD'' as r',
'    FROM card_stats',
'    WHERE merged_cards > 0',
')',
'ORDER BY r;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- ausw\00E4hlen --')
,p_lov_cascade_parent_items=>'P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION'
,p_ajax_items_to_submit=>'P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:margin-top-none'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH card_stats AS (',
'    SELECT ',
'        COUNT(DISTINCT card_number) as total_cards,',
'        COUNT(CASE WHEN card_count > 1 THEN 1 END) as merged_cards',
'    FROM (',
'        SELECT card_number, COUNT(*) as card_count',
'        FROM T_MS_SUCHE_SPLIT',
'        WHERE SUCHEID = :P460_SEARCH_SELECTION',
'        AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'        GROUP BY card_number',
'    )',
')',
'SELECT d, r',
'FROM (',
'    -- Delete Card: Show always if any cards exist',
'    SELECT ''Delete Card'' as d, ''DELETE_CARD'' as r ',
'    FROM card_stats',
'    WHERE total_cards > 0',
'    ',
'    UNION ALL',
'    ',
'    -- Delete Countries: Show when any merged cards exist',
'    SELECT ''Delete Countries from Card'' as d, ''DELETE_COUNTRIES'' as r',
'    FROM card_stats',
'    WHERE merged_cards > 0',
'    ',
'    UNION ALL',
'    ',
'    -- Merge Cards: Show only when more than one card exists',
'    SELECT ''Merge Cards'' as d, ''MERGE_CARD'' as r',
'    FROM card_stats',
'    WHERE total_cards > 1',
'    ',
'    UNION ALL',
'    ',
'    -- Unmerge Card: Show only when merged cards exist',
'    SELECT ''Unmerge Card'' as d, ''UNMERGE_CARD'' as r',
'    FROM card_stats',
'    WHERE merged_cards > 0',
')',
'ORDER BY r;'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964349198889509494)
,p_name=>'P460_DELETE_SPECIFIC_COUNTRIES'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(11866126095230983706)
,p_prompt=>unistr('Bestimmte L\00E4nder aus Karte l\00F6schen')
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:margin-top-none'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'unchecked_value', 'N',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964348742956509492)
,p_name=>'P460_SPLIT_SPECIFIC_COUNTRIES'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(11866126095230983706)
,p_prompt=>unistr('Bestimmte L\00E4nder aus Karte trennen')
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#:margin-top-none'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'unchecked_value', 'N',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964348367217509492)
,p_name=>'P460_CARD_SHUTTLE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(11866126095230983706)
,p_prompt=>unistr('L\00E4nder')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    LISTAGG(L.B_NUMMER || '' - '' || L.LAND, ''; '') ',
'    WITHIN GROUP (ORDER BY L.B_NUMMER) as d,',
'    MS.CARD_NUMBER as r',
'FROM T_MS_SUCHE_SPLIT MS',
'JOIN t_land L ON (L.LANDID = MS.LANDID)',
'WHERE MS.SUCHEID = :P460_SEARCH_SELECTION ',
'AND MS.MEILENSTEIN = :P460_MILESTONE_SELECTION',
'AND (MS.BENUTZERID = :G_BENUTZERID ',
'     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                WHERE brr.benutzerid = :G_BENUTZERID ',
'                AND brr.rolleid = 1001))',
'AND (',
'    :P460_ACTION = ''DELETE_CARD''',
'    OR (:P460_ACTION = ''DELETE_COUNTRIES'' AND ',
'        MS.CARD_NUMBER IN (',
'            SELECT card_number ',
'            FROM T_MS_SUCHE_SPLIT ',
'            WHERE SUCHEID = :P460_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'            AND (BENUTZERID = :G_BENUTZERID ',
'                 OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                            WHERE brr.benutzerid = :G_BENUTZERID ',
'                            AND brr.rolleid = 1001))',
'            GROUP BY card_number ',
'            HAVING COUNT(*) > 1',
'        )',
'    )',
'    OR (:P460_ACTION = ''UNMERGE_COUNTRIES'' AND ',
'        MS.CARD_NUMBER IN (',
'            SELECT card_number ',
'            FROM T_MS_SUCHE_SPLIT ',
'            WHERE SUCHEID = :P460_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'            AND (BENUTZERID = :G_BENUTZERID ',
'                 OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                            WHERE brr.benutzerid = :G_BENUTZERID ',
'                            AND brr.rolleid = 1001))',
'            GROUP BY card_number ',
'            HAVING COUNT(*) > 1',
'        )',
'    )',
'    OR (:P460_ACTION = ''MERGE_CARD'' ',
'        AND NOT (',
'            (SELECT COUNT(DISTINCT card_number) ',
'             FROM T_MS_SUCHE_SPLIT ',
'             WHERE SUCHEID = :P460_SEARCH_SELECTION',
'             AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'             AND (BENUTZERID = :G_BENUTZERID ',
'                  OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                             WHERE brr.benutzerid = :G_BENUTZERID ',
'                             AND brr.rolleid = 1001))) = 1',
'        )',
'    )',
'    OR (:P460_ACTION = ''UNMERGE_CARD'' AND ',
'        MS.CARD_NUMBER IN (',
'            SELECT card_number ',
'            FROM T_MS_SUCHE_SPLIT ',
'            WHERE SUCHEID = :P460_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'            AND (BENUTZERID = :G_BENUTZERID ',
'                 OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                            WHERE brr.benutzerid = :G_BENUTZERID ',
'                            AND brr.rolleid = 1001))',
'            GROUP BY card_number ',
'            HAVING COUNT(*) > 1',
'        )',
'    )',
')',
'GROUP BY MS.CARD_NUMBER',
'ORDER BY NLSSORT(',
'    LISTAGG(L.B_NUMMER || '' - '' || L.LAND, ''; '') ',
'    WITHIN GROUP (ORDER BY L.B_NUMMER),',
'    ''NLS_SORT=BINARY_AI''',
');'))
,p_lov_cascade_parent_items=>'P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION,P460_ACTION'
,p_ajax_items_to_submit=>'P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION,P460_ACTION'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_css_classes=>'CardShuttle_Tooltip'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    LISTAGG(L.B_NUMMER || '' - '' || L.LAND, ''; '') ',
'    WITHIN GROUP (ORDER BY L.B_NUMMER) as d,',
'    MS.CARD_NUMBER as r',
'FROM T_MS_SUCHE_SPLIT MS',
'JOIN t_land L ON (L.LANDID = MS.LANDID)',
'WHERE MS.SUCHEID = :P460_SEARCH_SELECTION ',
'AND MS.MEILENSTEIN = :P460_MILESTONE_SELECTION',
'AND (',
'    :P460_ACTION = ''DELETE_CARD''',
'    OR (:P460_ACTION = ''DELETE_COUNTRIES'' AND ',
'        MS.CARD_NUMBER IN (',
'            SELECT card_number ',
'            FROM T_MS_SUCHE_SPLIT ',
'            WHERE SUCHEID = :P460_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'            GROUP BY card_number ',
'            HAVING COUNT(*) > 1',
'        )',
'    )',
'    OR (:P460_ACTION = ''UNMERGE_COUNTRIES'' AND ',
'        MS.CARD_NUMBER IN (',
'            SELECT card_number ',
'            FROM T_MS_SUCHE_SPLIT ',
'            WHERE SUCHEID = :P460_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'            GROUP BY card_number ',
'            HAVING COUNT(*) > 1',
'        )',
'    )',
'    OR (:P460_ACTION = ''MERGE_CARD'' ',
'        AND NOT (',
'            (SELECT COUNT(DISTINCT card_number) ',
'             FROM T_MS_SUCHE_SPLIT ',
'             WHERE SUCHEID = :P460_SEARCH_SELECTION',
'             AND MEILENSTEIN = :P460_MILESTONE_SELECTION) = 1',
'        )',
'    )',
'    OR (:P460_ACTION = ''UNMERGE_CARD'' AND ',
'        MS.CARD_NUMBER IN (',
'            SELECT card_number ',
'            FROM T_MS_SUCHE_SPLIT ',
'            WHERE SUCHEID = :P460_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'            GROUP BY card_number ',
'            HAVING COUNT(*) > 1',
'        )',
'    )',
')',
'GROUP BY MS.CARD_NUMBER',
'ORDER BY NLSSORT(',
'    LISTAGG(L.B_NUMMER || '' - '' || L.LAND, ''; '') ',
'    WITHIN GROUP (ORDER BY L.B_NUMMER),',
'    ''NLS_SORT=BINARY_AI''',
');'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964348009693509490)
,p_name=>'P460_SELECTED_COUNTRIES_FROM_CARD'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(11866126095230983706)
,p_prompt=>unistr('W\00E4hlen Sie bestimmte L\00E4nder')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    l.b_nummer || '' - '' || l.LAND as d,',
'    l.landid as r',
'FROM t_land l',
'JOIN T_MS_SUCHE_SPLIT ms ON (',
'    l.landid = ms.landid',
'    AND ms.card_number in(select column_value from table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':'')))',
'    -- AND ms.card_number = :P460_CARD_SHUTTLE',
'    AND ms.sucheid = :P460_SEARCH_SELECTION ',
'    AND ms.meilenstein = :P460_MILESTONE_SELECTION',
')',
'-- ORDER BY l.b_nummer;',
'ORDER BY NLSSORT(L.B_NUMMER, ''NLS_SORT=BINARY_AI'')'))
,p_lov_cascade_parent_items=>'P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION,P460_CARD_SHUTTLE'
,p_ajax_items_to_submit=>'P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION,P460_CARD_SHUTTLE'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964346817365509487)
,p_name=>'P460_PERMALINK'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9764226214019764915)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
'apex_util.host_url(''SCRIPT'') ||',
'apex_page.get_url(',
'    p_application => :APP_ALIAS,',
'    p_page => ''PRI_CARD'',',
'    p_items => ''P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION,P460_FILTER_LAENDERGRUPPE,P460_FILTER_LAND,P460_START_PROFILE'',',
'    p_values => :P460_SEARCH_SELECTION || '','' || ',
'                :P460_MILESTONE_SELECTION || '','' || ',
'                :P460_FILTER_LAENDERGRUPPE || '','' || ',
'                :P460_FILTER_LAND || '','' || ',
'                :P460_START_PROFILE,',
'    p_session => null,',
'    p_clear_cache => ''460''',
')'))
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.host_url(''SCRIPT'') || apex_page.get_url(',
'    p_application => :APP_ALIAS',
'    , p_page => ''VORSCHRIFT''',
'    , p_items => ''P25_VORSCHRIFTID''',
'    , p_values => :P25_VORSCHRIFTID',
'    , p_session => null',
'    , p_clear_cache => ''25''',
')'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964346474811509487)
,p_name=>'P460_SAVED_CARD_COUNTRIES'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(9764226214019764915)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964346047591509486)
,p_name=>'P460_JUST_UPDATED_CARD'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(9764226214019764915)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964345704752509486)
,p_name=>'P460_JUST_UPDATED_STATUS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(9764226214019764915)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964345266424509486)
,p_name=>'P460_SAVED_CARD_NUMBERS'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(9764226214019764915)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964344887038509486)
,p_name=>'P460_REFRESH_CARDS'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(9764226214019764915)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964344418795509485)
,p_name=>'P460_BENUTZER_NAME'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(9764226214019764915)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Benutzer'
,p_source=>'select NACHNAME || '',  '' || VORNAME from t_benutzer where BENUTZERID = :G_BENUTZERID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964344104559509485)
,p_name=>'P460_SEARCH_SELECTION'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(9764226214019764915)
,p_prompt=>'Suchergebnis'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_SEARCH_SELECTION'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH pri_user_check AS (',
'    SELECT 1 AS is_pri_user',
'    FROM t_benutzer_ref_rolle',
'    WHERE benutzerid = :G_BENUTZERID',
'      AND rolleid = 1001 -- Role ID for PRI User',
'      AND ROWNUM = 1',
')',
'SELECT',
'    tsj.sucheid AS sucheid,                        -- First column: Search ID',
'    tsj.bezeichnung AS d,                          -- Second column: Search Name',
'    tsj.sucheid AS r,                              -- Return value',
'    b.nachname || '', '' || b.vorname AS benutzer,',
'    TO_CHAR(tsj.zeitpunkt, ''DD.MM.YYYY HH24:MI'') AS zeitpunkt',
'FROM',
'    t_suche_json tsj',
'JOIN',
'    t_benutzer b ON tsj.benutzerid = b.benutzerid',
'WHERE',
'    tsj.manuelle_speicherung > 0  -- Greater than 0 (includes both 1 and 10)',
'    AND (',
'        (SELECT NVL(is_pri_user, 0) FROM pri_user_check) = 1',
'        OR',
'        tsj.benutzerid = :G_BENUTZERID',
'    )',
'ORDER BY',
'    tsj.zeitpunkt DESC'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- ausw\00E4hlen --')
,p_cSize=>30
,p_colspan=>9
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ''Search '' || sucheid || '' - '' || BEZEICHNUNG ',
'    -- || '' ('' || TO_CHAR(zeitpunkt, ''DD.MM.YYYY HH24:MI'') || '')'' ',
'    AS d, -- Display Value',
'    sucheid AS r -- Return Value',
'FROM ',
'    t_suche_json',
'WHERE ',
'    benutzerid = :G_BENUTZERID',
'ORDER BY ',
'    zeitpunkt DESC;',
'',
'',
'-- 22.08.2025',
'SELECT ',
'    ''Suche ID ('' || sucheid || '') - '' || ',
'    REGEXP_REPLACE(',
'        REGEXP_REPLACE(BEZEICHNUNG, ''user_'', ''''),',
'        ''(.*?) (\d{2}\.\d{2}\.\d{4}) (\d{2}:\d{2}:\d{2})'',',
'        ''\1 - \2, \3''',
'    ) AS d,',
'    sucheid AS r',
'FROM t_suche_json',
'WHERE benutzerid = :G_BENUTZERID',
'   OR EXISTS (',
'       SELECT 1 ',
'       FROM t_benutzer_ref_rolle brr ',
'       WHERE brr.benutzerid = :G_BENUTZERID ',
'       AND brr.rolleid = 1001  -- PRI USER role',
'   )',
'ORDER BY zeitpunkt DESC;'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964343621868509484)
,p_name=>'P460_MILESTONE_SELECTION'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(9764226214019764915)
,p_prompt=>'Meilenstein'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH json_data AS (',
'    SELECT suchdaten',
'    FROM t_suche_json',
'    WHERE sucheid = :P460_SEARCH_SELECTION',
')',
'SELECT ',
'    ''Meilenstein '' || j.meilenstein as d, -- Display Value',
'    j.meilenstein as r -- Return Value',
'    ',
'FROM json_data,',
'JSON_TABLE(suchdaten, ''$[*]'' COLUMNS (',
'    meilenstein NUMBER PATH ''$.MEILENSTEIN''',
')) j',
'WHERE j.meilenstein IS NOT NULL;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- ausw\00E4hlen --')
,p_lov_cascade_parent_items=>'P460_SEARCH_SELECTION'
,p_ajax_items_to_submit=>'P460_SEARCH_SELECTION'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964342986897509483)
,p_name=>'P460_FILTER_LAENDERGRUPPE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(16429944140422377967)
,p_prompt=>unistr('Vorfilter <br> L\00E4nder&shy;gruppen')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    lg.laendergruppe as d,  ',
'    lg.laendergruppeid as r',
'FROM t_laendergruppe lg ',
'WHERE lg.laendergruppeid != 1220',
'AND EXISTS (',
'    -- Check if group has countries from user''s selected search and milestone',
'    SELECT 1 ',
'    FROM t_land_ref_laendergruppe lrg',
'    WHERE lrg.laendergruppeid = lg.laendergruppeid',
'    AND lrg.landid IN (',
'        SELECT TO_NUMBER(COLUMN_VALUE) as landid',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            laender VARCHAR2(4000) PATH ''$.LAENDER''',
'        )) jt,',
'        TABLE(apex_string.split(jt.laender, '':''))',
'        WHERE tsj.sucheid = :P460_SEARCH_SELECTION',
'        -- AND tsj.benutzerid = :G_BENUTZERID',
'',
'        AND (tsj.benutzerid = :G_BENUTZERID ',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001))',
'        AND jt.meilenstein = :P460_MILESTONE_SELECTION',
'    )',
')',
'ORDER BY lg.laendergruppe;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Alle --'
,p_lov_cascade_parent_items=>'P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION'
,p_ajax_items_to_submit=>'P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>8
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select lg.laendergruppe, lg.laendergruppeid ',
'from t_laendergruppe lg where lg.laendergruppeid!=1220',
'--and landid in (select column_value from table(apex_string.split_numbers(:P460_NEW_1,'':'')))',
'',
'/*and lg.laendergruppeid in (select LAENDERGRUPPEID from t_land_ref_laendergruppe */',
'--where landid in (select column_value from table(apex_string.split_numbers(:P460_NEW_1,'':'')))',
'order by 1;',
'',
'',
'',
'SELECT ',
'    lg.laendergruppe as d,  ',
'    lg.laendergruppeid as r',
'FROM t_laendergruppe lg ',
'WHERE lg.laendergruppeid != 1220',
'AND EXISTS (',
'    -- Check if group has countries from user''s selected search and milestone',
'    SELECT 1 ',
'    FROM t_land_ref_laendergruppe lrg',
'    WHERE lrg.laendergruppeid = lg.laendergruppeid',
'    AND lrg.landid IN (',
'        SELECT TO_NUMBER(COLUMN_VALUE) as landid',
'        FROM t_suche_json tsj,',
'        JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'            meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'            laender VARCHAR2(4000) PATH ''$.LAENDER''',
'        )) jt,',
'        TABLE(apex_string.split(jt.laender, '':''))',
'        WHERE tsj.sucheid = :P460_SEARCH_SELECTION',
'        AND tsj.benutzerid = :G_BENUTZERID',
'        AND jt.meilenstein = :P460_MILESTONE_SELECTION',
'    )',
')',
'ORDER BY lg.laendergruppe;',
'',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964342289844509481)
,p_name=>'P460_FILTER_LAND'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(16429945078825379904)
,p_prompt=>unistr('L\00E4nder')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    l.b_nummer || '' - '' || ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.land',
'        ELSE l.land_eng',
'    END as d,      ',
'    l.landid as r  ',
'FROM ',
'    t_land l',
'WHERE EXISTS (',
'    SELECT 1',
'    FROM t_suche_json tsj,',
'    JSON_TABLE(',
'        tsj.suchdaten, ',
'        ''$[*]'' COLUMNS (',
'            laender VARCHAR2(4000) PATH ''$.LAENDER'',',
'            meilenstein VARCHAR2(4000) PATH ''$.MEILENSTEIN''',
'        )',
'    ) jt',
'    WHERE ',
'        tsj.sucheid = :P460_SEARCH_SELECTION',
'        AND (tsj.benutzerid = :G_BENUTZERID ',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001))',
'        AND l.landid IN (',
'            SELECT TO_NUMBER(COLUMN_VALUE)',
'            FROM TABLE(apex_string.split(jt.laender, '':''))',
'        )',
'        AND jt.meilenstein = :P460_MILESTONE_SELECTION',
'        AND LANDID NOT IN (',
'            SELECT LANDID FROM T_MS_SUCHE_SPLIT ',
'            WHERE (BENUTZERID = :G_BENUTZERID ',
'                   OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                              WHERE brr.benutzerid = :G_BENUTZERID ',
'                              AND brr.rolleid = 1001))',
'            AND SUCHEID = :P460_SEARCH_SELECTION ',
'            AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'        )',
')',
'ORDER BY NLSSORT(l.b_nummer, ''NLS_SORT=BINARY_AI'')'))
,p_lov_cascade_parent_items=>'P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION'
,p_ajax_items_to_submit=>'P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#:margin-top-sm'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ',
'    l.b_nummer || '' - '' || CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.land',
'        ELSE l.land_eng',
'    END as d,      -- Changed ''land'' to ''d'' to match AJAX process',
'    l.landid as r  -- Changed ''landid'' to ''r'' to match AJAX process',
'FROM t_land l',
'WHERE EXISTS (',
'    -- Match countries from selected search and milestone',
'    SELECT 1',
'    FROM t_suche_json tsj,',
'    JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'        laender VARCHAR2(4000) PATH ''$.LAENDER'',',
'        meilenstein VARCHAR2(4000) PATH ''$.MEILENSTEIN''',
'    )) jt',
'    WHERE tsj.sucheid = :P460_SEARCH_SELECTION',
'    AND tsj.benutzerid = :G_BENUTZERID',
'    AND l.landid IN (',
'        SELECT TO_NUMBER(COLUMN_VALUE)',
'        FROM TABLE(apex_string.split(jt.laender, '':''))',
'    )',
'    AND jt.meilenstein = :P460_MILESTONE_SELECTION',
'  -- AND L.LANDID NOT IN (SELECT LANDID FROM T_MS_SUCHE_SPLIT WHERE BENUTZERID=:G_BENUTZERID AND SUCHEID	=:P460_SEARCH_SELECTION AND MEILENSTEIN =:P460_MILESTONE_SELECTION )',
')',
'',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964341863094509481)
,p_name=>'P460_BESONDERHEITEN'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(16429945078825379904)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964341513560509480)
,p_name=>'P460_URL'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(16429945078825379904)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964341085006509480)
,p_name=>'P460_LAENDER_CONTAINED_MJ'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(16429945078825379904)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964340624726509480)
,p_name=>'P460_HAS_MERGED_CARDS'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(16429945078825379904)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964337947322509477)
,p_name=>'P460_FIRST_LOAD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(9789823856764735135)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964337534650509476)
,p_name=>'P460_MODAL_URL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(9789823856764735135)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964337189634509476)
,p_name=>'P460_FILTER_VIEW_PROFILE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(9789823856764735135)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964336771722509476)
,p_name=>'P460_FILTER_VIEW_PROFILE_ID'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(9789823856764735135)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964336365106509475)
,p_name=>'P460_FILTER_PROFILE_NEW'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(9789823856764735135)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964335967089509475)
,p_name=>'P460_START_PROFILE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(9789823856764735135)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964335545855509475)
,p_name=>'P460_START_PROFILE_NEW'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(9789823856764735135)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964334432871509474)
,p_name=>'P460_JUMP_TO_CARD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9764227952700764932)
,p_prompt=>'Zur Karte springen'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    -- ''Card-'' || MS.CARD_NUMBER || '' ('' || ',
'    LISTAGG(L.B_NUMMER || '' - '' || L.LAND, ''; '') ',
'    WITHIN GROUP (ORDER BY L.B_NUMMER) ',
'    -- || '')'' ',
'    as d,',
'    MS.CARD_NUMBER as r',
'FROM T_MS_SUCHE_SPLIT MS',
'JOIN t_land L ON (L.LANDID = MS.LANDID)',
'/*',
'WHERE MS.SUCHEID = :P460_SEARCH_SELECTION ',
'AND MS.MEILENSTEIN = :P460_MILESTONE_SELECTION',
'*/',
'WHERE MS.SUCHEID = :P460_SEARCH_SELECTION ',
'AND MS.MEILENSTEIN = :P460_MILESTONE_SELECTION',
'AND (MS.BENUTZERID = :G_BENUTZERID ',
'     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                WHERE brr.benutzerid = :G_BENUTZERID ',
'                AND brr.rolleid = 1001))',
'',
'GROUP BY MS.CARD_NUMBER',
'ORDER BY MS.CARD_NUMBER asc'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- ausw\00E4hlen --')
,p_lov_cascade_parent_items=>'P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION'
,p_ajax_items_to_submit=>'P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(3414144245911820566)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964329533206509430)
,p_name=>'P460_POSTPROZESS_ID'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964329155848509429)
,p_name=>'P460_COMPARE_SEARCH_ID'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(964328762341509429)
,p_name=>'P460_COMPARE_MILESTONE_ID'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(951939669356316321)
,p_name=>'P460_SORT_ORDER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9764226214019764915)
,p_item_default=>'ASC'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(951938677141316311)
,p_name=>'P460_SUCHE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(5570784955205133329)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Suche Id'
,p_source=>'P460_SEARCH_SELECTION'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>2
,p_field_template=>wwv_flow_imp.id(2707164817965204361)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964320801290509413)
,p_name=>'FILTER_LAENDERGRUPPE_CHANGED'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P460_FILTER_LAENDERGRUPPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964320279366509410)
,p_event_id=>wwv_flow_imp.id(964320801290509413)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'loadLaenderShuttle();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964319856415509410)
,p_name=>'Set Count'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P460_MILESTONE_SELECTION'
,p_condition_element=>'P460_MILESTONE_SELECTION'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964319405841509409)
,p_event_id=>wwv_flow_imp.id(964319856415509410)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_FILTER_LAENDERGRUPPE,P460_FILTER_LAND'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964318847246509409)
,p_event_id=>wwv_flow_imp.id(964319856415509410)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_FILTER_LAENDERGRUPPE,P460_FILTER_LAND'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964318411060509408)
,p_event_id=>wwv_flow_imp.id(964319856415509410)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9789823856764735135)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964317817030509407)
,p_event_id=>wwv_flow_imp.id(964319856415509410)
,p_event_result=>'FALSE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9789823856764735135)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964317370312509407)
,p_event_id=>wwv_flow_imp.id(964319856415509410)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9764227952700764932)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964316856586509407)
,p_event_id=>wwv_flow_imp.id(964319856415509410)
,p_event_result=>'FALSE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9764227952700764932)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964316324217509407)
,p_event_id=>wwv_flow_imp.id(964319856415509410)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9764228157320764934)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964315915631509406)
,p_event_id=>wwv_flow_imp.id(964319856415509410)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'refreshcard();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964315475258509406)
,p_name=>'Handle Action Change'
,p_event_sequence=>180
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P460_ACTION'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$v("P460_ACTION") !== null && $v("P460_ACTION") !== ""'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_da_event_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'js  client ',
'',
'$v("P460_ACTION") !== null && $v("P460_ACTION") !== ""'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964314969091509406)
,p_event_id=>wwv_flow_imp.id(964315475258509406)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_CARD_SHUTTLE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    ''Card-''|| MS.CARD_NUMBER || '' ('' || ',
'    LISTAGG(L.B_NUMMER || '' - '' || L.LAND, ''; '') ',
'    WITHIN GROUP (ORDER BY L.B_NUMMER) || '')'' as d,',
'    MS.CARD_NUMBER as r',
'FROM T_MS_SUCHE_SPLIT MS',
'JOIN t_land L ON (L.LANDID = MS.LANDID)',
'WHERE MS.SUCHEID = :P460_SEARCH_SELECTION ',
'AND MS.MEILENSTEIN = :P460_MILESTONE_SELECTION',
'AND (',
'    (:P460_ACTION = ''UNMERGE_CARD'' AND',
'        MS.CARD_NUMBER IN (',
'            SELECT CARD_NUMBER ',
'            FROM T_MS_SUCHE_SPLIT ',
'            WHERE SUCHEID = :P460_SEARCH_SELECTION ',
'            AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'            GROUP BY CARD_NUMBER ',
'            HAVING COUNT(*) > 1',
'        )',
'    ) OR',
'    :P460_ACTION != ''UNMERGE_CARD''',
')',
'GROUP BY MS.CARD_NUMBER',
'ORDER BY MS.CARD_NUMBER DESC'))
,p_attribute_07=>'P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_da_action_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sql ',
'',
'SELECT DISTINCT ',
'    ''Card-''|| MS.CARD_NUMBER || '' ('' || ',
'    LISTAGG(L.B_NUMMER || '' - '' || L.LAND, ''; '') ',
'    WITHIN GROUP (ORDER BY L.B_NUMMER) || '')'' as d,',
'    MS.CARD_NUMBER as r',
'FROM T_MS_SUCHE_SPLIT MS',
'JOIN t_land L ON (L.LANDID = MS.LANDID)',
'WHERE MS.SUCHEID = :P460_SEARCH_SELECTION ',
'AND MS.MEILENSTEIN = :P460_MILESTONE_SELECTION',
'AND (',
'    (:P460_ACTION = ''UNMERGE_CARD'' AND',
'        MS.CARD_NUMBER IN (',
'            SELECT CARD_NUMBER ',
'            FROM T_MS_SUCHE_SPLIT ',
'            WHERE SUCHEID = :P460_SEARCH_SELECTION ',
'            AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'            GROUP BY CARD_NUMBER ',
'            HAVING COUNT(*) > 1',
'        )',
'    ) OR',
'    :P460_ACTION != ''UNMERGE_CARD''',
')',
'GROUP BY MS.CARD_NUMBER',
'ORDER BY MS.CARD_NUMBER DESC'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964314442172509406)
,p_event_id=>wwv_flow_imp.id(964315475258509406)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_CARD_SHUTTLE,P460_SELECTED_COUNTRIES_FROM_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964313957172509405)
,p_event_id=>wwv_flow_imp.id(964315475258509406)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_CARD_SHUTTLE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964313491247509405)
,p_event_id=>wwv_flow_imp.id(964315475258509406)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964313024750509405)
,p_name=>'Handle Apply Action'
,p_event_sequence=>190
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(964352257500509503)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964312574640509404)
,p_event_id=>wwv_flow_imp.id(964313024750509405)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Sind Sie sicher, dass Sie die ausgew\00E4hlten Karten l\00F6schen m\00F6chten?')
,p_attribute_02=>unistr('Karten l\00F6schen ? ')
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-question'
,p_attribute_05=>'.delete_confirm'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P460_ACTION'
,p_client_condition_expression=>'DELETE_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964312049606509404)
,p_event_id=>wwv_flow_imp.id(964313024750509405)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Sind Sie sicher, dass Sie die ausgew\00E4hlten L\00E4nder aus der Karte l\00F6schen m\00F6chten?')
,p_attribute_02=>unistr('ausgew\00E4hlten L\00E4nder aus der Karte l\00F6schen ?')
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-question'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P460_ACTION'
,p_client_condition_expression=>'DELETE_COUNTRIES'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964311534575509404)
,p_event_id=>wwv_flow_imp.id(964313024750509405)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Sind Sie sicher, dass Sie die ausgew\00E4hlten Karten zusammenf\00FChren m\00F6chten?')
,p_attribute_02=>unistr('Karten zusammenf\00FChren ?')
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-question'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P460_ACTION'
,p_client_condition_expression=>'MERGE_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964311057710509403)
,p_event_id=>wwv_flow_imp.id(964313024750509405)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Sind Sie sicher, dass Sie die ausgew\00E4hlte Karte aufteilen m\00F6chten?')
,p_attribute_02=>unistr('ausgew\00E4hlte Karte aufteilen ?')
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-question'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P460_ACTION'
,p_client_condition_expression=>'UNMERGE_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964310577504509403)
,p_event_id=>wwv_flow_imp.id(964313024750509405)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Sind Sie sicher, dass Sie die ausgew\00E4hlten L\00E4nder in Karten aufteilen m\00F6chten?')
,p_attribute_02=>unistr('ausgew\00E4hlten L\00E4nder in Karten ?')
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-question'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P460_ACTION'
,p_client_condition_expression=>'UNMERGE_COUNTRIES'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964310030873509403)
,p_event_id=>wwv_flow_imp.id(964313024750509405)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'processCardAction();'
,p_da_action_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'l_first_card NUMBER;',
'l_new_card NUMBER;',
'l_counter NUMBER := 0;',
'l_remaining_countries NUMBER;',
'BEGIN',
'    CASE :P460_ACTION',
'    WHEN ''DELETE_CARD'' THEN',
'    DELETE FROM t_ms_suche_split',
'    WHERE CARD_NUMBER IN (',
'        SELECT column_value',
'        FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
'    )',
'    AND SUCHEID = :P460_SEARCH_SELECTION',
'    AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'',
'',
'    WHEN ''DELETE_COUNTRIES'' THEN',
'        -- First check if this would delete all countries from the card',
'        SELECT COUNT(*)',
'        INTO l_remaining_countries',
'        FROM t_ms_suche_split',
'        WHERE card_number IN (',
'            SELECT column_value ',
'            FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
'        )',
'        AND SUCHEID = :P460_SEARCH_SELECTION',
'        AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'        AND landid NOT IN (',
'            SELECT column_value',
'            FROM table(apex_string.split_numbers(:P460_SELECTED_COUNTRIES_FROM_CARD, '':''))',
'        );',
'',
'        IF l_remaining_countries > 0 THEN',
'            -- Safe to delete as it won''t remove all countries',
'            DELETE FROM t_ms_suche_split',
'            WHERE card_number IN (',
'                SELECT column_value',
'                FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
'            )',
'            AND landid IN (',
'                SELECT column_value',
'                FROM table(apex_string.split_numbers(:P460_SELECTED_COUNTRIES_FROM_CARD, '':''))',
'            )',
'            AND SUCHEID = :P460_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'        ELSE',
'            -- Would delete all countries - show error',
'            apex_error.add_error(',
'                p_message => ''Cannot delete all countries from a card. Use Delete Card action instead.'',',
'                p_display_location => apex_error.c_inline_in_notification',
'            );',
'            RETURN;',
'        END IF;',
'',
'        ',
'',
'WHEN ''MERGE_CARD'' THEN',
'-- Get first selected card number',
'SELECT MIN(column_value)',
'INTO l_first_card',
'FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''));',
'',
'-- Update other cards to first card number',
'UPDATE t_ms_suche_split',
'SET CARD_NUMBER = l_first_card,',
'    LETZTE_AENDERUNG_DATUM = SYSDATE,',
'    LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'WHERE CARD_NUMBER IN (',
'    SELECT column_value',
'    FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
')',
'AND CARD_NUMBER != l_first_card',
'AND SUCHEID = :P460_SEARCH_SELECTION',
'AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'',
'WHEN ''UNMERGE_CARD'' THEN',
'-- Get next available card number',
'SELECT NVL(MAX(CARD_NUMBER), 0) + 1',
'INTO l_new_card',
'FROM t_ms_suche_split;',
'',
'-- Update each landid to new card number',
'FOR r IN (',
'    SELECT DISTINCT ms.LANDID',
'    FROM t_ms_suche_split ms',
'    WHERE ms.CARD_NUMBER IN (',
'        SELECT column_value',
'        FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
'    )',
'    AND ms.SUCHEID = :P460_SEARCH_SELECTION',
'    AND ms.MEILENSTEIN = :P460_MILESTONE_SELECTION',
') LOOP',
'    IF l_counter > 0 THEN',
'        UPDATE t_ms_suche_split',
'        SET CARD_NUMBER = l_new_card + l_counter,',
'            LETZTE_AENDERUNG_DATUM = SYSDATE,',
'            LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'        WHERE LANDID = r.LANDID',
'        AND SUCHEID = :P460_SEARCH_SELECTION',
'        AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'    END IF;',
'    l_counter := l_counter + 1;',
'END LOOP;',
'END CASE;',
'',
'-- Show success message',
'apex_application.g_print_success_message := ',
'CASE :P460_ACTION',
'WHEN ''DELETE_CARD'' THEN ''Selected cards deleted successfully''',
'WHEN ''DELETE_COUNTRIES'' THEN ''Selected Countries from card deleted successfully''',
'WHEN ''MERGE_CARD'' THEN ''Cards merged successfully''',
'WHEN ''UNMERGE_CARD'' THEN ''Cards unmerged successfully''',
'END;',
'END;',
'',
'',
'',
'',
'',
'P460_ACTION,P460_CARD_SHUTTLE,P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION',
'',
'',
'P460_ACTION,P460_CARD_SHUTTLE'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964309059456509402)
,p_event_id=>wwv_flow_imp.id(964313024750509405)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'refreshcard();'
,p_server_condition_type=>'NEVER'
,p_da_action_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'l_first_card NUMBER;',
'l_new_card NUMBER;',
'l_counter NUMBER := 0;',
'l_remaining_countries NUMBER;',
'BEGIN',
'    CASE :P460_ACTION',
'    WHEN ''DELETE_CARD'' THEN',
'    DELETE FROM t_ms_suche_split',
'    WHERE CARD_NUMBER IN (',
'        SELECT column_value',
'        FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
'    )',
'    AND SUCHEID = :P460_SEARCH_SELECTION',
'    AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'',
'',
'    WHEN ''DELETE_COUNTRIES'' THEN',
'        -- First check if this would delete all countries from the card',
'        SELECT COUNT(*)',
'        INTO l_remaining_countries',
'        FROM t_ms_suche_split',
'        WHERE card_number IN (',
'            SELECT column_value ',
'            FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
'        )',
'        AND SUCHEID = :P460_SEARCH_SELECTION',
'        AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'        AND landid NOT IN (',
'            SELECT column_value',
'            FROM table(apex_string.split_numbers(:P460_SELECTED_COUNTRIES_FROM_CARD, '':''))',
'        );',
'',
'        IF l_remaining_countries > 0 THEN',
'            -- Safe to delete as it won''t remove all countries',
'            DELETE FROM t_ms_suche_split',
'            WHERE card_number IN (',
'                SELECT column_value',
'                FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
'            )',
'            AND landid IN (',
'                SELECT column_value',
'                FROM table(apex_string.split_numbers(:P460_SELECTED_COUNTRIES_FROM_CARD, '':''))',
'            )',
'            AND SUCHEID = :P460_SEARCH_SELECTION',
'            AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'        ELSE',
'            -- Would delete all countries - show error',
'            apex_error.add_error(',
'                p_message => ''Cannot delete all countries from a card. Use Delete Card action instead.'',',
'                p_display_location => apex_error.c_inline_in_notification',
'            );',
'            RETURN;',
'        END IF;',
'',
'        ',
'',
'WHEN ''MERGE_CARD'' THEN',
'-- Get first selected card number',
'SELECT MIN(column_value)',
'INTO l_first_card',
'FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''));',
'',
'-- Update other cards to first card number',
'UPDATE t_ms_suche_split',
'SET CARD_NUMBER = l_first_card,',
'    LETZTE_AENDERUNG_DATUM = SYSDATE,',
'    LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'WHERE CARD_NUMBER IN (',
'    SELECT column_value',
'    FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
')',
'AND CARD_NUMBER != l_first_card',
'AND SUCHEID = :P460_SEARCH_SELECTION',
'AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'',
'WHEN ''UNMERGE_CARD'' THEN',
'-- Get next available card number',
'SELECT NVL(MAX(CARD_NUMBER), 0) + 1',
'INTO l_new_card',
'FROM t_ms_suche_split;',
'',
'-- Update each landid to new card number',
'FOR r IN (',
'    SELECT DISTINCT ms.LANDID',
'    FROM t_ms_suche_split ms',
'    WHERE ms.CARD_NUMBER IN (',
'        SELECT column_value',
'        FROM table(apex_string.split_numbers(:P460_CARD_SHUTTLE, '':''))',
'    )',
'    AND ms.SUCHEID = :P460_SEARCH_SELECTION',
'    AND ms.MEILENSTEIN = :P460_MILESTONE_SELECTION',
') LOOP',
'    IF l_counter > 0 THEN',
'        UPDATE t_ms_suche_split',
'        SET CARD_NUMBER = l_new_card + l_counter,',
'            LETZTE_AENDERUNG_DATUM = SYSDATE,',
'            LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'        WHERE LANDID = r.LANDID',
'        AND SUCHEID = :P460_SEARCH_SELECTION',
'        AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'    END IF;',
'    l_counter := l_counter + 1;',
'END LOOP;',
'END CASE;',
'',
'-- Show success message',
'apex_application.g_print_success_message := ',
'CASE :P460_ACTION',
'WHEN ''DELETE_CARD'' THEN ''Selected cards deleted successfully''',
'WHEN ''DELETE_COUNTRIES'' THEN ''Selected Countries from card deleted successfully''',
'WHEN ''MERGE_CARD'' THEN ''Cards merged successfully''',
'WHEN ''UNMERGE_CARD'' THEN ''Cards unmerged successfully''',
'END;',
'END;',
'',
'',
'',
'',
'',
'P460_ACTION,P460_CARD_SHUTTLE,P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION',
'',
'',
'P460_ACTION,P460_CARD_SHUTTLE'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964309585691509402)
,p_event_id=>wwv_flow_imp.id(964313024750509405)
,p_event_result=>'TRUE'
,p_action_sequence=>120
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_CARD_SHUTTLE,P460_ACTION,P460_JUMP_TO_CARD,P460_FILTER_LAND,P460_FILTER_LAENDERGRUPPE'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964308690236509401)
,p_name=>'When Filter button press'
,p_event_sequence=>200
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(964347284027509488)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964308156048509401)
,p_event_id=>wwv_flow_imp.id(964308690236509401)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'click_to_showResult();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964307665980509401)
,p_event_id=>wwv_flow_imp.id(964308690236509401)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'refreshcard();'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964307147541509401)
,p_event_id=>wwv_flow_imp.id(964308690236509401)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_ACTION'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH card_stats AS (',
'    SELECT ',
'        COUNT(DISTINCT card_number) as total_cards,',
'        COUNT(CASE WHEN card_count > 1 THEN 1 END) as merged_cards',
'    FROM (',
'        SELECT card_number, COUNT(*) as card_count',
'        FROM T_MS_SUCHE_SPLIT',
'        WHERE SUCHEID = :P460_SEARCH_SELECTION',
'        AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'        GROUP BY card_number',
'    )',
')',
'SELECT d, r',
'FROM (',
'    -- Delete Card: Show always if any cards exist',
'    SELECT ''Delete Card'' as d, ''DELETE_CARD'' as r ',
'    FROM card_stats',
'    WHERE total_cards > 0',
'    ',
'    UNION ALL',
'    ',
'    -- Delete Countries: Show when any merged cards exist',
'    SELECT ''Delete Countries from Card'' as d, ''DELETE_COUNTRIES'' as r',
'    FROM card_stats',
'    WHERE merged_cards > 0',
'    ',
'    UNION ALL',
'    ',
'    -- Unmerge Countries: Show when any merged cards exist',
'    SELECT ''Unmerge Countries from Card'' as d, ''UNMERGE_COUNTRIES'' as r',
'    FROM card_stats',
'    WHERE merged_cards > 0',
'    ',
'    UNION ALL',
'    ',
'    -- Merge Cards: Show only when more than one card exists',
'    SELECT ''Merge Cards'' as d, ''MERGE_CARD'' as r',
'    FROM card_stats',
'    WHERE total_cards > 1',
'    ',
'    UNION ALL',
'    ',
'    -- Unmerge Card: Show only when merged cards exist',
'    SELECT ''Unmerge Card'' as d, ''UNMERGE_CARD'' as r',
'    FROM card_stats',
'    WHERE merged_cards > 0',
')',
'ORDER BY r;'))
,p_attribute_07=>'P460_MILESTONE_SELECTION,P460_SEARCH_SELECTION'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964306711404509401)
,p_event_id=>wwv_flow_imp.id(964308690236509401)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_FILTER_LAND,P460_CARD_SHUTTLE,P460_ACTION,P460_FILTER_LAENDERGRUPPE,P460_JUMP_TO_CARD'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964306296077509401)
,p_name=>'Show / Hide'
,p_event_sequence=>210
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P460_CARD_SHUTTLE'
,p_condition_element=>'P460_CARD_SHUTTLE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964305733693509400)
,p_event_id=>wwv_flow_imp.id(964306296077509401)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_SELECTED_COUNTRIES_FROM_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964305248061509400)
,p_event_id=>wwv_flow_imp.id(964306296077509401)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_SELECTED_COUNTRIES_FROM_CARD'
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>'$v("P460_ACTION") === "DELETE_COUNTRIES" || $v("P460_ACTION") === "UNMERGE_COUNTRIES"'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964304764877509399)
,p_event_id=>wwv_flow_imp.id(964306296077509401)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_SELECTED_COUNTRIES_FROM_CARD'
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$v("P460_ACTION") !== "DELETE_COUNTRIES" && $v("P460_ACTION") !== "UNMERGE_COUNTRIES"',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964304316592509399)
,p_name=>'Scroll to Selected Card'
,p_event_sequence=>220
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P460_JUMP_TO_CARD'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$v(''P460_JUMP_TO_CARD'') !== null'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964303868044509398)
,p_event_id=>wwv_flow_imp.id(964304316592509399)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
'try {',
'    const selectedCardNum = apex.item(''P460_JUMP_TO_CARD'').getValue();',
'    if (selectedCardNum) {',
'        // Find the card container',
'        const cardElement = document.querySelector(`.cards-region .card-container[data-cardnum="${selectedCardNum}"]`);',
'        ',
'        if (cardElement) {',
'            // Calculate position to scroll to (position the card 100px from the top)',
'            const cardRect = cardElement.getBoundingClientRect();',
'            const cardTop = cardElement.getBoundingClientRect().top + window.pageYOffset;',
'            const offset = 100;',
'            ',
'            // Smooth scroll',
'            window.scrollTo({',
'                top: cardTop - offset,',
'                behavior: ''smooth''',
'            });',
'            ',
'            // Apply highlighting',
'            // cardElement.style.backgroundColor = ''#FFFFC0'';',
'            cardElement.style.boxShadow = ''0 0 10px 3px rgba(187, 10, 49, 0.6)'';',
'            cardElement.style.border = ''2px solid #bb0a31'';',
'            cardElement.style.transition = ''all 0.3s ease'';',
'            ',
'            // Add a pulse animation',
'            const pulseAnimation = cardElement.animate([',
'                { boxShadow: ''0 0 10px 3px rgba(187, 10, 49, 0.6)'' },',
'                { boxShadow: ''0 0 15px 5px rgba(187, 10, 49, 0.8)'' },',
'                { boxShadow: ''0 0 10px 3px rgba(187, 10, 49, 0.6)'' }',
'            ], {',
'                duration: 1200,',
'                iterations: 2',
'            });',
'            ',
'            // Add a subtle bounce effect',
'            cardElement.animate([',
'                { transform: ''translateY(0)'' },',
'                { transform: ''translateY(-8px)'' },',
'                { transform: ''translateY(0)'' }',
'            ], {',
'                duration: 800,',
'                easing: ''ease-in-out''',
'            });',
'            ',
'            // Reset styling after animation',
'            setTimeout(() => {',
'                cardElement.style.backgroundColor = '''';',
'                cardElement.style.boxShadow = ''0 2px 4px rgba(0,0,0,0.1)'';',
'                cardElement.style.border = ''1px solid #e0e0e0'';',
'            }, 2500);',
'        }',
'    }',
'} catch (error) {',
'    console.error(''Error scrolling to card:'', error);',
'}'))
,p_da_action_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// try {',
'//     const selectedCardNum = apex.item(''P460_JUMP_TO_CARD'').getValue();',
'//     if (selectedCardNum) {',
'//         // Find the card container',
'//         const cardElement = document.querySelector(`.cards-region .card-container[data-cardnum="${selectedCardNum}"]`);',
'        ',
'//         if (cardElement) {',
'//             // Calculate position to scroll to (position the card 100px from the top)',
'//             const cardRect = cardElement.getBoundingClientRect();',
'//             const cardTop = cardElement.getBoundingClientRect().top + window.pageYOffset;',
'//             const offset = 100;',
'            ',
'//             // Smooth scroll',
'//             window.scrollTo({',
'//                 top: cardTop - offset,',
'//                 behavior: ''smooth''',
'//             });',
'            ',
'//             // Apply highlighting',
'//             // cardElement.style.backgroundColor = ''#FFFFC0'';',
'//             cardElement.style.boxShadow = ''0 0 10px 3px rgba(187, 10, 49, 0.6)'';',
'//             cardElement.style.border = ''2px solid #bb0a31'';',
'//             cardElement.style.transition = ''all 0.3s ease'';',
'            ',
'//             // Reset styling after animation',
'//             setTimeout(() => {',
'//                 cardElement.style.backgroundColor = '''';',
'//                 cardElement.style.boxShadow = ''0 2px 4px rgba(0,0,0,0.1)'';',
'//                 cardElement.style.border = ''1px solid #e0e0e0'';',
'//             }, 2500);',
'//         }',
'//     }',
'// } catch (error) {',
'//     console.error(''Error scrolling to card:'', error);',
'// }'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964303430818509398)
,p_name=>'Show Hide Next Items'
,p_event_sequence=>230
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P460_SEARCH_SELECTION'
,p_condition_element=>'P460_SEARCH_SELECTION'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964302959634509398)
,p_event_id=>wwv_flow_imp.id(964303430818509398)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_MILESTONE_SELECTION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964302467060509397)
,p_event_id=>wwv_flow_imp.id(964303430818509398)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_MILESTONE_SELECTION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964302017959509397)
,p_name=>'Change'
,p_event_sequence=>240
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P460_CARD_SHUTTLE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964301560041509397)
,p_event_id=>wwv_flow_imp.id(964302017959509397)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("P460_CARD_SHUTTLE")) {',
'    apex.item("APPLY_ACTION_BUTTON").enable();',
'} else {',
'    apex.item("APPLY_ACTION_BUTTON").disable();',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964301211190509397)
,p_name=>'Enable / Disable Filter button'
,p_event_sequence=>270
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P460_FILTER_LAND'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964300645750509397)
,p_event_id=>wwv_flow_imp.id(964301211190509397)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("P460_FILTER_LAND")) {',
'    apex.item("B501317057147707225").enable();',
'} else {',
'    apex.item("B501317057147707225").disable();',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964300156543509396)
,p_event_id=>wwv_flow_imp.id(964301211190509397)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9764228157320764934)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964299751325509396)
,p_name=>'Toggle Checkboxes Based on Action'
,p_event_sequence=>280
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P460_ACTION,P460_HAS_MERGED_CARDS'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$v(''P460_ACTION'') === ''DELETE_CARD'' && $v(''P460_HAS_MERGED_CARDS'') === ''Y'''
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_da_event_comment=>'$v(''P460_ACTION'') === ''DELETE_CARD'''
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964299289556509396)
,p_event_id=>wwv_flow_imp.id(964299751325509396)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_DELETE_SPECIFIC_COUNTRIES'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964298808187509396)
,p_event_id=>wwv_flow_imp.id(964299751325509396)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_DELETE_SPECIFIC_COUNTRIES'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964298372471509396)
,p_name=>'Toggle Checkboxes Based on Action_1'
,p_event_sequence=>290
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P460_ACTION,P460_HAS_MERGED_CARDS'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$v(''P460_ACTION'') === ''UNMERGE_CARD'' && $v(''P460_HAS_MERGED_CARDS'') === ''Y'''
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964297834533509395)
,p_event_id=>wwv_flow_imp.id(964298372471509396)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_SPLIT_SPECIFIC_COUNTRIES'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964297320835509395)
,p_event_id=>wwv_flow_imp.id(964298372471509396)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_SPLIT_SPECIFIC_COUNTRIES'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964296994855509395)
,p_name=>'New'
,p_event_sequence=>300
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P460_DELETE_SPECIFIC_COUNTRIES,P460_SPLIT_SPECIFIC_COUNTRIES'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$v(''P460_DELETE_SPECIFIC_COUNTRIES'') === ''Y'' || $v(''P460_SPLIT_SPECIFIC_COUNTRIES'') === ''Y'''
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964296501848509394)
,p_event_id=>wwv_flow_imp.id(964296994855509395)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_SELECTED_COUNTRIES_FROM_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964296000555509394)
,p_event_id=>wwv_flow_imp.id(964296994855509395)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_SELECTED_COUNTRIES_FROM_CARD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964295600577509394)
,p_name=>'Change 5'
,p_event_sequence=>310
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P460_CARD_SHUTTLE'
,p_condition_element=>'P460_CARD_SHUTTLE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964295090635509394)
,p_event_id=>wwv_flow_imp.id(964295600577509394)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_SELECTED_COUNTRIES_FROM_CARD'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964294613967509394)
,p_event_id=>wwv_flow_imp.id(964295600577509394)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_SELECTED_COUNTRIES_FROM_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964294109864509394)
,p_event_id=>wwv_flow_imp.id(964295600577509394)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_SELECTED_COUNTRIES_FROM_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964293558347509394)
,p_event_id=>wwv_flow_imp.id(964295600577509394)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("P460_CARD_SHUTTLE")) {',
'    apex.item("APPLY_ACTION_BUTTON").enable();',
'} else {',
'    apex.item("APPLY_ACTION_BUTTON").disable();',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964293129968509393)
,p_name=>'New_1'
,p_event_sequence=>320
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P460_CARD_COUNT'
,p_condition_element=>'P460_CARD_COUNT'
,p_triggering_condition_type=>'GREATER_THAN_OR_EQUAL'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964292679477509393)
,p_event_id=>wwv_flow_imp.id(964293129968509393)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_JUMP_TO_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964292124000509393)
,p_event_id=>wwv_flow_imp.id(964293129968509393)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P460_JUMP_TO_CARD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964291814663509393)
,p_name=>'Toggle Jump To Card Visibility'
,p_event_sequence=>330
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(9764227952700764932)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964291260698509393)
,p_event_id=>wwv_flow_imp.id(964291814663509393)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Check if there are any cards in the region',
'var cardContainers = $(".cards-regions .card-container");',
'if (cardContainers.length > 0) {',
'    // Show the "Jump to Card" item if cards exist',
'    apex.item("P460_JUMP_TO_CARD_CONTAINER").enable();',
'} else {',
'    // Hide the "Jump to Card" item if no cards exist',
'    apex.item("P460_JUMP_TO_CARD_CONTAINER").disable();',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964290857085509393)
,p_name=>'New_2'
,p_event_sequence=>340
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P460_CARD_SHUTTLE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964290412868509392)
,p_event_id=>wwv_flow_imp.id(964290857085509393)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  l_count NUMBER;',
'BEGIN',
'  SELECT COUNT(*) INTO l_count',
'  FROM (',
'    SELECT 1 FROM t_ms_suche_split ',
'    WHERE card_number IN (',
'      SELECT column_value ',
'      FROM apex_string.split(:P460_CARD_SHUTTLE,'':'')',
'    ) ',
'    AND SUCHEID = :P460_SEARCH_SELECTION',
'    AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'    GROUP BY card_number ',
'    HAVING COUNT(*) > 1',
'  );',
'  ',
'  IF l_count > 0 THEN',
'    :P460_HAS_MERGED_CARDS := ''Y'';',
'  ELSE',
'    :P460_HAS_MERGED_CARDS := ''N'';',
'  END IF;',
'END;'))
,p_attribute_02=>'P460_CARD_SHUTTLE,P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION'
,p_attribute_03=>'P460_HAS_MERGED_CARDS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964289977552509392)
,p_name=>'Save FilterandView Settings'
,p_event_sequence=>350
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(964339159241509477)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964289439968509392)
,p_event_id=>wwv_flow_imp.id(964289977552509392)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P460_MODAL_URL := APEX_PAGE.get_url(',
'    p_page => 462,',
'    p_clear_cache => 462,',
'    p_items => ''P462_DATA,P462_FILTER_VIEW_PAGE'',',
'    p_values => ''\'' || :P460_FILTER_VIEW_PROFILE|| ''\,460'' ',
');',
'',
''))
,p_attribute_02=>'P460_FILTER_VIEW_PROFILE,G_BENUTZERID'
,p_attribute_03=>'P460_MODAL_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964288921281509392)
,p_event_id=>wwv_flow_imp.id(964289977552509392)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.navigation.redirect($v(''P460_MODAL_URL''));',
'//window.location = $v(''P460_MODAL_URL'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964288595191509392)
,p_name=>'Manage FilterandView Settings'
,p_event_sequence=>360
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(964338735598509477)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964288043435509391)
,p_event_id=>wwv_flow_imp.id(964288595191509392)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P460_MODAL_URL := APEX_PAGE.get_url(',
'    p_page => 463,',
'    p_clear_cache => 463,',
'    p_items => ''P463_FILTER_VIEW_PAGE'',',
'    p_values => ''460''',
');',
'',
'UPDATE T_FILTER_VIEW_PROFILE ',
'SET NEW = 0 ',
'WHERE BENUTZERID = :G_BENUTZERID AND PAGE = 460;',
'',
':P460_FILTER_PROFILE_NEW := '''';'))
,p_attribute_02=>'P460_FILTER_PROFILE_NEW'
,p_attribute_03=>'P460_MODAL_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964287517729509391)
,p_event_id=>wwv_flow_imp.id(964288595191509392)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.navigation.redirect($v(''P460_MODAL_URL''));',
'//window.location = $v(''P460_MODAL_URL'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964287120161509391)
,p_name=>'Pass Data to Filter Profile'
,p_event_sequence=>370
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION,P460_FILTER_LAENDERGRUPPE,P460_FILTER_LAND'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964286657106509391)
,p_event_id=>wwv_flow_imp.id(964287120161509391)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var obj = new Object();',
'obj.search_selection = $v(''P460_SEARCH_SELECTION'');',
'obj.milestone_selection = $v(''P460_MILESTONE_SELECTION'');',
'obj.filter_laendergruppe = $v(''P460_FILTER_LAENDERGRUPPE'');',
'obj.filter_land = $v(''P460_FILTER_LAND'');',
'obj.card_countries = getAllCardCountries();',
'obj.card_numbers = getAllCardNumbers();',
'$s(''P460_FILTER_VIEW_PROFILE'', JSON.stringify(obj));',
'',
'apex.server.process(''DUMMY_PROCESS'', {',
'  pageItems: ''#P460_FILTER_VIEW_PROFILE''',
'}, {',
'  dataType: "text"',
'});',
'',
'',
'',
'',
'// Update permalink when state changes',
'setTimeout(updatePermalink, 500);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964286291190509391)
,p_name=>'Dialog Closed Page 463'
,p_event_sequence=>380
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId && this.data.dialogPageId == 463'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964285785054509391)
,p_event_id=>wwv_flow_imp.id(964286291190509391)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.submit(''REFRESH'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964285343619509390)
,p_name=>'Dialog Closed Page 462'
,p_event_sequence=>390
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'body'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964284820903509390)
,p_event_id=>wwv_flow_imp.id(964285343619509390)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (this.data.successMessage) {',
'    apex.message.showPageSuccess(this.data.successMessage.text);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964284423159509390)
,p_name=>'Dialog Closed Page 463, 462'
,p_event_sequence=>400
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'body'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964283921380509390)
,p_event_id=>wwv_flow_imp.id(964284423159509390)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Handle return from profile management',
'if (this.data && this.data.dialogPageId && ',
'    (this.data.dialogPageId == 463 || this.data.dialogPageId == 462)) {',
'    ',
'    // Refresh regions that might need updating after profile changes',
'    apex.region("FilterSuche").refresh();',
'    ',
'    // Check if we need to refresh the profile display',
'    if ($v("P460_START_PROFILE") === null || $v("P460_START_PROFILE") === "") {',
'        var profileDisplay = document.getElementById("selectedfilter");',
'        if (profileDisplay) {',
'            var span = profileDisplay.querySelector("span");',
'            if (span) {',
'                span.textContent = "None";',
'            }',
'        }',
'    }',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964283574827509390)
,p_name=>'copy permalink'
,p_event_sequence=>410
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(964339554362509478)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964283105011509390)
,p_event_id=>wwv_flow_imp.id(964283574827509390)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// navigator.clipboard.writeText($v("P460_PERMALINK"));',
'// alert(''Der Permalink wurde in die Zwischenablage kopiert:\n\n'' + $v("P460_PERMALINK"));',
'',
'copyCurrentPermalink();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964282625640509389)
,p_name=>'Click Custom Maximize Button'
,p_event_sequence=>420
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(964334820940509474)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964282207106509389)
,p_event_id=>wwv_flow_imp.id(964282625640509389)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''span.js-maximizeButtonContainer button'').click()'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964281810646509389)
,p_name=>'New_3'
,p_event_sequence=>430
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964281274879509389)
,p_event_id=>wwv_flow_imp.id(964281810646509389)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(964280868116509389)
,p_name=>'Set Suchparameter PRI Postprozess Items'
,p_event_sequence=>440
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P460_MILESTONE_SELECTION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(964280326853509388)
,p_event_id=>wwv_flow_imp.id(964280868116509389)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_search_id NUMBER := :P460_SEARCH_SELECTION;',
'    l_milestone_id NUMBER := :P460_MILESTONE_SELECTION;',
'BEGIN',
'    -- Clear all fields first',
'    :P460_SUCHE_ID := NULL;',
'    :P460_SEARCH_NAME := NULL;',
'    :P460_SEARCH_SOP := NULL;',
'    :P460_SEARCH_EOP := NULL;',
'    :P460_SEARCH_TYPE := NULL;',
'    :P460_KPB_NUMBERS := NULL;',
'    ',
'    -- Get search name (doesn''t depend on milestone)',
'    IF l_search_id IS NOT NULL THEN',
'    :P460_SUCHE_ID := l_search_id;',
'        BEGIN',
'            SELECT tsj.bezeichnung',
'            INTO :P460_SEARCH_NAME',
'            FROM t_suche_json tsj',
'            WHERE tsj.sucheid = l_search_id',
'            AND (tsj.benutzerid = :G_BENUTZERID ',
'                 OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                            WHERE brr.benutzerid = :G_BENUTZERID ',
'                            AND brr.rolleid = 1001));',
'        EXCEPTION',
'            WHEN NO_DATA_FOUND THEN',
'                :P460_SEARCH_NAME := NULL;',
'        END;',
'    END IF;',
'',
'    -- Get milestone-specific data',
'    IF l_search_id IS NOT NULL AND l_milestone_id IS NOT NULL THEN',
'        BEGIN',
'            SELECT',
'                TO_CHAR(TO_DATE(jt.datum_sop), ''DD.MM.YYYY''),',
'                TO_CHAR(TO_DATE(jt.datum_eop), ''DD.MM.YYYY''),',
'                CASE jt.suchtyp',
'                    WHEN ''0'' THEN ''Neue Typen''',
'                    WHEN ''10'' THEN ''Bestehender Typ''',
'                    ELSE ''Nicht angegeben''',
'                END,',
'                jt.kpb_values',
'            INTO :P460_SEARCH_SOP, :P460_SEARCH_EOP, :P460_SEARCH_TYPE, :P460_KPB_NUMBERS',
'            FROM t_suche_json tsj,',
'            JSON_TABLE(tsj.suchdaten, ''$[*]'' COLUMNS (',
'                meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'                datum_sop VARCHAR2(20) PATH ''$.DATUM_SOP'',',
'                datum_eop VARCHAR2(20) PATH ''$.DATUM_EOP'',',
'                suchtyp VARCHAR2(20) PATH ''$.SUCHTYP'',',
'                kpb_values  VARCHAR2(4000) PATH ''$.KPB''',
'            )) jt',
'            WHERE tsj.sucheid = l_search_id',
'            AND jt.meilenstein = l_milestone_id',
'            AND (tsj.benutzerid = :G_BENUTZERID ',
'                 OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                            WHERE brr.benutzerid = :G_BENUTZERID ',
'                            AND brr.rolleid = 1001));',
'        EXCEPTION',
'            WHEN NO_DATA_FOUND THEN',
'                :P460_SEARCH_SOP := NULL;',
'                :P460_SEARCH_EOP := NULL;',
'                :P460_SEARCH_TYPE := NULL;',
'                :P460_KPB_NUMBERS := NULL;',
'        END;',
'    END IF;',
'END;'))
,p_attribute_02=>'P460_SEARCH_SELECTION,P460_MILESTONE_SELECTION'
,p_attribute_03=>'P460_SEARCH_NAME,P460_SEARCH_SOP,P460_SEARCH_EOP,P460_SEARCH_TYPE,P460_KPB_NUMBERS,P460_SUCHE_ID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964327970663509427)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Custom XLSX Export - All Countries Result'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_context apex_exec.t_context;',
'    l_print_config    apex_data_export.t_print_config;',
'    l_export apex_data_export.t_export;',
'    l_name VARCHAR2(255);',
'    lTitle varchar2(250);',
'BEGIN',
'    -- Get user name',
'    SELECT b.nachname || '' '' || b.vorname',
'    INTO l_name',
'    FROM t_benutzer b',
'    WHERE benutzerid = :G_BENUTZERID;',
'    ',
'    -- Set title',
unistr('    lTitle := ''Aller L\00E4nder - Vorschriften'';'),
'    ',
'    -- Create query context',
'    l_context := apex_exec.open_query_context(',
'    p_location => apex_exec.c_location_local_db,',
'    p_sql_query => q''[',
'            WITH search_countries AS (',
'                SELECT ',
'                    sucheid,',
'                    to_number(COLUMN_VALUE) as landid',
'                FROM t_suche_json,',
'                TABLE(apex_string.split(',
'                    json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                    '':''',
'                ))',
'                WHERE ',
'                    sucheid = v(''P460_SEARCH_SELECTION'') ',
'                    AND BENUTZERID = v(''G_BENUTZERID'')',
'            )',
'            SELECT DISTINCT',
'                ms.landnummer||'' - ''||ms.landbezeichnung AS Landbezeichnung,',
'                ms.themabezeichnung AS Themabezeichnung,',
'                ms.vorschriftnummer as Vorschriftennummer,',
'                nvl(tv.vorschrift_nummer, '''') AS Alternative_Vorschriftennummer',
'            FROM search_countries sc',
'            LEFT OUTER JOIN T_MS_SUCHERGEBNISS ms ON (',
'                ms.sucheid = sc.sucheid ',
'                AND ms.landid = sc.landid',
'                AND ms.meilenstein = v(''P460_MILESTONE_SELECTION'')',
'                AND sc.landid NOT IN (',
'                    SELECT column_value ',
'                    FROM table(apex_string.split_numbers(v(''P460_FILTER_LAND''), '':''))',
'                )',
'            )',
'            LEFT OUTER JOIN t_vorschrift tv ON (tv.vorschriftid = ms.alternative_vorschriftid)',
'            WHERE ms.VORSCHRIFTID IS NOT NULL ',
'            GROUP BY ',
'                ms.vorschriftnummer,',
'                ms.VORSCHRIFTID,',
'                ms.landnummer,',
'                ms.landbezeichnung,',
'                ms.themabezeichnung,',
'                tv.vorschrift_nummer,',
'                sc.sucheid',
'            ORDER BY ',
'                ms.landnummer||'' - ''||ms.landbezeichnung,',
'                ms.themabezeichnung,',
'                ms.vorschriftnummer',
'        ]''',
'    );',
'        ',
'    -- Configure print settings',
'    l_print_config := apex_data_export.get_print_config(',
'        p_page_header => lTitle,',
'        p_header_font_family => ''Audi Type'',',
'        p_header_font_size => 10,',
'        p_body_font_family => ''Audi Type'',',
'        p_body_font_size => 10,',
'        p_border_width => 0.5,',
'        p_page_footer_font_family => ''Audi Type'',',
'        p_page_footer_font_size => 10,',
'        p_header_bg_color => ''#D0D0D0''',
'    );',
'',
'',
'',
'',
'        ',
'    -- Create export',
'    l_export := apex_data_export.export(',
'        p_context => l_context,',
'        p_print_config => l_print_config,',
'        p_format => apex_data_export.c_format_xlsx,',
unistr('        p_file_name => ''Aller L\00E4nder - Vorschriften'' || ''-'' || l_name || ''-'' || TO_CHAR(SYSDATE, ''DD.MM.YYYY HH24:MI:SS'') || ''.xlsx'''),
'    );',
'    ',
'    -- Close context and download',
'    apex_exec.close(l_context);',
'    apex_data_export.download(p_export => l_export);',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_exec.close(l_context);',
'        RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(964331204381509440)
,p_internal_uid=>2707884345235878808
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_context apex_exec.t_context;',
'    l_print_config    apex_data_export.t_print_config;',
'    l_export apex_data_export.t_export;',
'    l_name VARCHAR2(255);',
'    lTitle varchar2(250);',
'BEGIN',
'    -- Get user name',
'    SELECT b.nachname || '' '' || b.vorname',
'    INTO l_name',
'    FROM t_benutzer b',
'    WHERE benutzerid = :G_BENUTZERID;',
'    ',
'    -- Set title',
unistr('    lTitle := ''Aller L\00E4nder - Vorschriften'';'),
'    ',
'    -- Create query context',
'    l_context := apex_exec.open_query_context(',
'        p_location => apex_exec.c_location_local_db,',
'        p_sql_query => q''[',
'            WITH search_countries AS (',
'                SELECT ',
'                    sucheid,',
'                    to_number(COLUMN_VALUE) as landid',
'                FROM t_suche_json,',
'                TABLE(apex_string.split(',
'                    json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                    '':''',
'                ))',
'                WHERE ',
'                    sucheid = v(''P460_SEARCH_SELECTION'') ',
'                    AND BENUTZERID = v(''G_BENUTZERID'')',
'            )',
'            SELECT DISTINCT',
'                -- sc.sucheid,',
'                -- ms.VORSCHRIFTID,',
'                ',
'                ms.landnummer||'' - ''||ms.landbezeichnung AS Landbezeichnung,',
'                ms.vorschriftnummer as Vorschriftennummer',
'                ',
'            FROM search_countries sc',
'            LEFT JOIN T_MS_SUCHERGEBNISS ms ON (',
'                ms.sucheid = sc.sucheid ',
'                AND ms.landid = sc.landid',
'                AND ms.meilenstein =  v(''P460_MILESTONE_SELECTION'')',
'                AND sc.landid NOT IN (',
'                    SELECT column_value ',
'                    FROM table(apex_string.split_numbers(v(''P460_FILTER_LAND''), '':''))',
'                )',
'            )',
'            WHERE VORSCHRIFTID IS NOT NULL ',
'            GROUP BY ',
'                ms.vorschriftnummer,',
'                ms.VORSCHRIFTID,',
'                ms.landnummer,',
'                ms.landbezeichnung,',
'                sc.sucheid',
'            ORDER BY ',
'                Landbezeichnung,',
'                Vorschriftennummer',
'        ]''',
'    );',
'    ',
'    -- Configure print settings',
'    l_print_config := apex_data_export.get_print_config(',
'        p_page_header => lTitle,',
'        p_header_font_family => ''Audi Type'',',
'        p_header_font_size => 10,',
'        p_body_font_family => ''Audi Type'',',
'        p_body_font_size => 10,',
'        p_border_width => 0.5,',
'        p_page_footer_font_family => ''Audi Type'',',
'        p_page_footer_font_size => 10,',
'        p_header_bg_color => ''#D0D0D0''',
'    );',
'',
'',
'',
'',
'        ',
'    -- Create export',
'    l_export := apex_data_export.export(',
'        p_context => l_context,',
'        p_print_config => l_print_config,',
'        p_format => apex_data_export.c_format_xlsx,',
unistr('        p_file_name => ''Aller L\00E4nder - Vorschriften'' || ''-'' || l_name || ''-'' || TO_CHAR(SYSDATE, ''DD.MM.YYYY HH24:MI:SS'') || ''.xlsx'''),
'    );',
'    ',
'    -- Close context and download',
'    apex_exec.close(l_context);',
'    apex_data_export.download(p_export => l_export);',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_exec.close(l_context);',
'        RAISE;',
'END;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964324801914509419)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Fill Items in Page Load '
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    SELECT',
'           JSON_VALUE(DATA, ''$.search_selection''),',
'           JSON_VALUE(DATA, ''$.milestone_selection''),',
'           JSON_VALUE(DATA, ''$.filter_laendergruppe''),',
'           JSON_VALUE(DATA, ''$.filter_land''),',
'           JSON_VALUE(DATA, ''$.card_countries''),',
'           JSON_VALUE(DATA, ''$.card_numbers''),',
'           name',
'    INTO :P460_SEARCH_SELECTION,',
'         :P460_MILESTONE_SELECTION,',
'         :P460_FILTER_LAENDERGRUPPE,',
'         :P460_FILTER_LAND,',
'         :P460_SAVED_CARD_COUNTRIES,',
'         :P460_SAVED_CARD_NUMBERS,',
'         :P460_START_PROFILE',
'    FROM T_FILTER_VIEW_PROFILE',
'    WHERE START_PROFILE = 1 ',
'    AND (BENUTZERID = :G_BENUTZERID ',
'         OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                    WHERE brr.benutzerid = :G_BENUTZERID ',
'                    AND brr.rolleid = 1001))',
'    AND PAGE = 460;',
'',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        :P460_SEARCH_SELECTION := null;',
'        :P460_MILESTONE_SELECTION := null;',
'        :P460_FILTER_LAENDERGRUPPE := null;',
'        :P460_FILTER_LAND := null;',
'        :P460_START_PROFILE := null;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2707887513984878816
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964323930560509418)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Filter Profile Settings'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'BEGIN',
'    IF :P460_FILTER_VIEW_PROFILE_ID IS NOT NULL THEN',
'        SELECT ',
'           JSON_VALUE(DATA, ''$.search_selection''),',
'           JSON_VALUE(DATA, ''$.milestone_selection''),',
'           JSON_VALUE(DATA, ''$.filter_laendergruppe''),',
'           JSON_VALUE(DATA, ''$.filter_land''),',
'           JSON_VALUE(DATA, ''$.card_countries''),',
'           JSON_VALUE(DATA, ''$.card_numbers''),',
'           NAME',
'        INTO ',
'           :P460_SEARCH_SELECTION,',
'           :P460_MILESTONE_SELECTION,',
'           :P460_FILTER_LAENDERGRUPPE,',
'           :P460_FILTER_LAND,',
'           :P460_SAVED_CARD_COUNTRIES,',
'           :P460_SAVED_CARD_NUMBERS,',
'           :P460_START_PROFILE',
'        FROM T_FILTER_VIEW_PROFILE',
'        WHERE FILTER_VIEW_PROFILEID = :P460_FILTER_VIEW_PROFILE_ID',
'        AND BENUTZERID = :G_BENUTZERID',
'        AND PAGE = ''460'';',
'        ',
'        :P460_REFRESH_CARDS := ''Y'';',
'        -- Clear the profile ID after loading it',
'        -- :P460_FILTER_VIEW_PROFILE_ID := NULL;',
'    END IF;',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        NULL;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P460_FILTER_VIEW_PROFILE_ID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>2707888385338878817
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964323163752509418)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Verify Profile Exists'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_profile_exists NUMBER;',
'BEGIN',
'    -- Check if the current profile still exists',
'    SELECT COUNT(*) ',
'    INTO l_profile_exists',
'    FROM T_FILTER_VIEW_PROFILE',
'    WHERE BENUTZERID = :G_BENUTZERID',
'    AND PAGE = 460',
'    AND NAME = :P460_START_PROFILE;',
'    ',
'    -- If profile doesn''t exist, clear the name',
'    IF l_profile_exists = 0 AND :P460_START_PROFILE IS NOT NULL THEN',
'        :P460_START_PROFILE := NULL;',
'        :P460_FILTER_VIEW_PROFILE_ID := NULL;',
'        ',
'        -- Add message that profile was deleted',
'        apex_application.g_print_success_message := ',
'            ''The previously selected filter profile no longer exists.'';',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2707889152146878817
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964322813075509418)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Handle Permalink Parameters'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- If we have URL parameters, load them',
'    IF :P460_SEARCH_SELECTION IS NOT NULL AND :P460_MILESTONE_SELECTION IS NOT NULL THEN',
'        -- Set items from URL parameters',
'        -- These will already be set by APEX URL processing',
'        ',
'        -- If we have filter land data, trigger the filter',
'        IF :P460_FILTER_LAND IS NOT NULL THEN',
'            -- The filtering will be handled by existing dynamic actions',
'            NULL;',
'        END IF;',
'        ',
'        -- If we have a specific profile, load it',
'        IF :P460_START_PROFILE IS NOT NULL THEN',
'            -- Load the profile data',
'            BEGIN',
'                SELECT',
'                    JSON_VALUE(DATA, ''$.search_selection''),',
'                    JSON_VALUE(DATA, ''$.milestone_selection''),',
'                    JSON_VALUE(DATA, ''$.filter_laendergruppe''),',
'                    JSON_VALUE(DATA, ''$.filter_land''),',
'                    JSON_VALUE(DATA, ''$.card_countries''),',
'                    JSON_VALUE(DATA, ''$.card_numbers'')',
'                INTO :P460_SEARCH_SELECTION,',
'                     :P460_MILESTONE_SELECTION,',
'                     :P460_FILTER_LAENDERGRUPPE,',
'                     :P460_FILTER_LAND,',
'                     :P460_SAVED_CARD_COUNTRIES,',
'                     :P460_SAVED_CARD_NUMBERS',
'                FROM T_FILTER_VIEW_PROFILE',
'                WHERE NAME = :P460_START_PROFILE',
'                AND (BENUTZERID = :G_BENUTZERID ',
'                     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                                WHERE brr.benutzerid = :G_BENUTZERID ',
'                                AND brr.rolleid = 1001))',
'                AND PAGE = 460;',
'                ',
'                :P460_REFRESH_CARDS := ''Y'';',
'            EXCEPTION',
'                WHEN NO_DATA_FOUND THEN',
'                    -- Profile doesn''t exist, continue with URL parameters',
'                    NULL;',
'            END;',
'        END IF;',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2707889502823878817
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964322361802509417)
,p_process_sequence=>50
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Search Header Details'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_search_id    NUMBER := :P460_SEARCH_SELECTION;',
'    l_milestone_id NUMBER := :P460_MILESTONE_SELECTION;',
'BEGIN',
'    -- First, get the main search name, which doesn''t depend on the milestone',
'    IF l_search_id IS NOT NULL THEN',
'        SELECT',
'            tsj.bezeichnung',
'        INTO',
'            :P460_SEARCH_NAME',
'        FROM',
'            t_suche_json tsj',
'        WHERE',
'            tsj.sucheid = l_search_id;',
'    ELSE',
'        :P460_SEARCH_NAME := NULL;',
'    END IF;',
'',
'    -- Then, get the details for the SPECIFIC milestone the user selected',
'    IF l_search_id IS NOT NULL AND l_milestone_id IS NOT NULL THEN',
'        SELECT',
'            jt.sop,',
'            jt.eop,',
'            CASE',
'                WHEN jt.suchtyp = ''0'' THEN ''Neue Typen''',
'                WHEN jt.suchtyp = ''10'' THEN ''Bestehender Typ''',
'                ELSE jt.suchtyp',
'            END',
'        INTO',
'            :P460_SEARCH_SOP,',
'            :P460_SEARCH_EOP,',
'            :P460_SEARCH_TYPE',
'        FROM',
'            t_suche_json tsj,',
'            JSON_TABLE(tsj.suchdaten, ''$[*]''',
'                COLUMNS (',
'                    meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'                    sop         VARCHAR2(20) PATH ''$.DATUM_SOP'',',
'                    eop         VARCHAR2(20) PATH ''$.DATUM_EOP'',',
'                    suchtyp     VARCHAR2(20) PATH ''$.SUCHTYP''',
'                )',
'            ) jt',
'        WHERE',
'            tsj.sucheid = l_search_id',
'            AND jt.meilenstein = l_milestone_id; ',
'',
'    ELSE',
'        -- Clear milestone-specific fields if no milestone is selected',
'        :P460_SEARCH_SOP := NULL;',
'        :P460_SEARCH_EOP := NULL;',
'        :P460_SEARCH_TYPE := NULL;',
'    END IF;',
'',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        -- This handles cases where a milestone might not have data. Clear the fields.',
'        :P460_SEARCH_SOP := NULL;',
'        :P460_SEARCH_EOP := NULL;',
'        :P460_SEARCH_TYPE := NULL;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2707889954096878818
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964321930394509417)
,p_process_sequence=>60
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Search Header Details_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_search_id NUMBER := :P460_SEARCH_SELECTION;',
'BEGIN',
'    IF l_search_id IS NOT NULL THEN',
'        SELECT',
'            tsj.bezeichnung, -- Get the search name directly from the table column',
'            jt.sop,',
'            jt.eop,',
'            CASE',
'                WHEN jt.suchtyp = ''0'' THEN ''Neue Typen''',
'                WHEN jt.suchtyp = ''10'' THEN ''Bestehender Typ''',
'                ELSE jt.suchtyp',
'            END',
'        INTO',
'            :P460_SEARCH_NAME,',
'            :P460_SEARCH_SOP,',
'            :P460_SEARCH_EOP,',
'            :P460_SEARCH_TYPE',
'        FROM',
'            t_suche_json tsj,',
'            JSON_TABLE(tsj.suchdaten, ''$[*]''',
'                COLUMNS (',
'                    meilenstein NUMBER PATH ''$.MEILENSTEIN'',',
'                    -- Removed the "name" column from here as it''s not in the JSON',
'                    sop VARCHAR2(20) PATH ''$.DATUM_SOP'',',
'                    eop VARCHAR2(20) PATH ''$.DATUM_EOP'',',
'                    suchtyp VARCHAR2(20) PATH ''$.SUCHTYP''',
'                    -- KPB column is also removed as requested',
'                )',
'            ) jt',
'        WHERE',
'            tsj.sucheid = l_search_id',
'            AND jt.meilenstein = 1; -- Fetches details from the first milestone',
'    ELSE',
'        -- Clear fields if no search is selected',
'        :P460_SEARCH_NAME := NULL;',
'        :P460_SEARCH_SOP := NULL;',
'        :P460_SEARCH_EOP := NULL;',
'        :P460_SEARCH_TYPE := NULL;',
'    END IF;',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        -- Fallback to get at least the name if JSON is empty or has no milestone 1',
'        BEGIN',
'            SELECT tsj.bezeichnung INTO :P460_SEARCH_NAME FROM t_suche_json tsj WHERE tsj.sucheid = l_search_id;',
'        EXCEPTION',
'            WHEN NO_DATA_FOUND THEN',
'                :P460_SEARCH_NAME := NULL;',
'        END;',
'        :P460_SEARCH_SOP := NULL;',
'        :P460_SEARCH_EOP := NULL;',
'        :P460_SEARCH_TYPE := NULL;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2707890385504878818
,p_process_comment=>'Mile stone 1'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964327559175509426)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadLaenderShuttle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected            VARCHAR2(2000) := apex_application.g_x01;  -- List of selected items',
'    lLaendergruppe       VARCHAR2(2000) := apex_application.g_x02;  -- List of country groups',
'    lStartdatumTyp       NUMBER := NULL;  -- Type of start date',
'    lSuche               VARCHAR2(2000) := apex_application.g_x03;  -- Selected Search',
'    lMilestoneSelection  VARCHAR2(2000) := apex_application.g_x04;   -- Selected milestone',
'BEGIN',
'    -- Open the JSON array to start constructing the response',
'    apex_json.open_array;',
'',
'    -- Loop through the selected countries that match the conditions',
'    FOR l IN (',
'        SELECT ',
'            b_nummer || '' - '' || CASE ',
'                WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'                ELSE land_eng',
'            END AS d,  -- Display value',
'            landid      -- Return value (land ID)',
'        FROM ',
'            t_land',
'        WHERE ',
'            -- Exclude selected countries based on lSelected',
'            landid NOT IN (SELECT column_value FROM table(apex_string.split_numbers(lSelected, '':'')))',
'            ',
'            -- Filter by Laendergruppe (country group), if specified',
'            AND (',
'                lLaendergruppe IS NULL ',
'                OR landid IN (',
'                    SELECT landid ',
'                    FROM t_land_ref_laendergruppe ',
'                    WHERE laendergruppeid IN (',
'                        SELECT column_value ',
'                        FROM table(apex_string.split_numbers(lLaendergruppe, '':''))',
'                    )',
'                )',
'            )',
'            ',
'            -- Ensure the country is part of the selected search and milestone',
'            AND EXISTS (',
'                SELECT 1',
'                FROM t_suche_json tsj,',
'                     json_table(tsj.suchdaten, ''$[*]'' COLUMNS (',
'                         laender VARCHAR2(4000) PATH ''$.LAENDER'',',
'                         meilenstein VARCHAR2(4000) PATH ''$.MEILENSTEIN''',
'                     )) jt',
'                WHERE tsj.sucheid = lSuche',
'                -- AND tsj.BENUTZERID = :G_BENUTZERID',
'',
'                AND (tsj.BENUTZERID = :G_BENUTZERID ',
'                     OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                                WHERE brr.benutzerid = :G_BENUTZERID ',
'                                AND brr.rolleid = 1001))',
'',
'                AND landid IN (',
'                    SELECT TO_NUMBER(COLUMN_VALUE)',
'                    FROM TABLE(apex_string.split(jt.laender, '':''))',
'                )',
'            --   AND LANDID NOT IN (SELECT LANDID FROM T_MS_SUCHE_SPLIT WHERE BENUTZERID=:G_BENUTZERID AND SUCHEID	=lSuche AND MEILENSTEIN =lMilestoneSelection )',
'                AND LANDID NOT IN (',
'                    SELECT LANDID FROM T_MS_SUCHE_SPLIT ',
'                    WHERE (BENUTZERID = :G_BENUTZERID ',
'                           OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                                      WHERE brr.benutzerid = :G_BENUTZERID ',
'                                      AND brr.rolleid = 1001))',
'                    AND SUCHEID = lSuche ',
'                    AND MEILENSTEIN = lMilestoneSelection',
')',
'                AND (',
'                    lMilestoneSelection IS NULL',
'                    OR jt.meilenstein = lMilestoneSelection',
'                )',
'            )',
'            ',
'            -- filtering by startdatum_typ',
'            AND (',
'                lStartdatumTyp IS NULL',
'                OR startdatum_typ = lStartdatumTyp',
'            )',
'        ',
'        -- Order results by binary sort of the country number',
'        ORDER BY ',
'            NLSSORT(b_nummer, ''NLS_SORT=BINARY_AI'')',
'    ) LOOP',
'        -- Write each country to the JSON response',
'        apex_json.open_object;',
'        apex_json.write(''d'', l.d);  -- Display value',
'        apex_json.write(''r'', l.landid);  -- Return value (land ID)',
'        apex_json.close_object;',
'    END LOOP;',
'',
'    -- Close the JSON array',
'    apex_json.close_array;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2707884756723878809
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected      VARCHAR2(2000) := apex_application.g_x01;  -- List of selected items',
'    lLaendergruppe VARCHAR2(2000) := apex_application.g_x02;  -- List of country groups',
'    lStartdatumTyp NUMBER := NULL;  -- Type of start date',
'    lSuche         NUMBER := apex_application.g_x03;  -- Search number',
'',
'BEGIN',
'    -- Open the JSON array to start constructing the response',
'    apex_json.open_array;',
'',
'    -- Loop through the selected countries that match the conditions',
'    FOR l IN (',
'        SELECT ',
'            b_nummer || '' - '' || CASE ',
'                WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN land',
'                ELSE land_eng',
'            END AS d,  -- Display value',
'            landid      -- Return value (land ID)',
'        FROM ',
'            t_land',
'        WHERE ',
'            -- Exclude selected countries based on lSelected',
'            landid NOT IN (SELECT column_value FROM table(apex_string.split_numbers(lSelected, '':'')))',
'            ',
'            -- Filter by Laendergruppe (country group), if specified',
'            AND (',
'                lLaendergruppe IS NULL ',
'                OR landid IN (',
'                    SELECT landid ',
'                    FROM t_land_ref_laendergruppe ',
'                    WHERE laendergruppeid IN (',
'                        SELECT column_value ',
'                        FROM table(apex_string.split_numbers(lLaendergruppe, '':''))',
'                    )',
'                )',
'            )',
'            ',
'            -- Ensure the country is part of the selected search (suche)',
'            AND landid IN (',
'                SELECT ',
'                    TO_NUMBER(COLUMN_VALUE) AS landid',
'                FROM ',
'                    t_suche_json,',
'                    TABLE(apex_string.split(',
'                        json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                        '':''',
'                    ))',
'                WHERE ',
'                    BENUTZERID = :G_BENUTZERID  -- User ID',
'                    AND sucheid = :P460_SEARCH_SELECTION  -- Selected search ID',
'            )',
'',
'            -- filtering by startdatum_typ',
'            AND (',
'                lStartdatumTyp IS NULL',
'                OR startdatum_typ = lStartdatumTyp',
'            )',
'        ',
'        -- Order results by binary sort of the country number',
'        ORDER BY ',
'            NLSSORT(b_nummer, ''NLS_SORT=BINARY_AI'')',
'    ) LOOP',
'        -- Write each country to the JSON response',
'        apex_json.open_object;',
'        apex_json.write(''d'', l.d);  -- Display value',
'        apex_json.write(''r'', l.landid);  -- Return value (land ID)',
'        apex_json.close_object;',
'    END LOOP;',
'',
'    -- Close the JSON array',
'    apex_json.close_array;',
'',
'END;',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964326800998509425)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'INSERT_CODE_AJAX'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected            VARCHAR2(2000) := apex_application.g_x01;  -- List of selected items',
'    lLaendergruppe       VARCHAR2(2000) := apex_application.g_x02;  -- List of country groups',
'    lStartdatumTyp       NUMBER := NULL;  -- Type of start date',
'    lSuche               VARCHAR2(2000) := apex_application.g_x03;  -- Selected Search',
'    lMilestoneSelection  VARCHAR2(2000) := apex_application.g_x04;   -- Selected milestone',
'    L_CARD NUMBER;',
'    l_selected_count NUMBER;',
'    l_existing_card NUMBER := NULL;',
'BEGIN    ',
'    -- Open the JSON array to start constructing the response',
'    apex_json.open_array;',
'',
'    -- Count selected countries',
'    SELECT COUNT(column_value) INTO l_selected_count ',
'    FROM TABLE(apex_string.split_numbers(lSelected, '':''));',
'    ',
'    IF l_selected_count = 0 THEN',
'        apex_error.add_error(',
unistr('            p_message => ''Bitte w\00E4hlen Sie mindestens ein Land aus.'','),
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'        RETURN;',
'    END IF;',
'',
'    -- Check if ANY of the selected countries already exist in ANY card',
'    BEGIN',
'        SELECT DISTINCT card_number INTO l_existing_card',
'        FROM t_ms_suche_split ',
'        WHERE sucheid = lSuche ',
'        AND meilenstein = lMilestoneSelection',
'        AND (BENUTZERID = :G_BENUTZERID ',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001))',
'        AND landid IN (',
'            SELECT column_value ',
'            FROM TABLE(apex_string.split_numbers(lSelected, '':''))',
'        )',
'        AND ROWNUM = 1;',
'        ',
'        -- If we found any country in existing card, show error',
'        apex_error.add_error(',
unistr('            p_message => ''Ausgew\00E4hlte L\00E4nder sind bereits in Karte '' || l_existing_card || '' enthalten.'','),
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'        RETURN;',
'        ',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            NULL; -- Good, no countries exist in any card',
'    END;',
'',
'    -- Get next card number',
'    SELECT NVL(MAX(card_number) + 1, 1) ',
'    INTO L_CARD ',
'    FROM t_ms_suche_split ',
'    WHERE (BENUTZERID = :G_BENUTZERID ',
'           OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                      WHERE brr.benutzerid = :G_BENUTZERID ',
'                      AND brr.rolleid = 1001));',
'',
'    -- Insert data',
'    FOR i IN (',
'        WITH search_countries AS (',
'            SELECT ',
'                sucheid,',
'                to_number(COLUMN_VALUE) AS landid',
'            FROM t_suche_json,',
'            TABLE(apex_string.split(',
'                json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                '':''',
'            ))',
'            WHERE (BENUTZERID = :G_BENUTZERID ',
'                   OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                              WHERE brr.benutzerid = :G_BENUTZERID ',
'                              AND brr.rolleid = 1001))',
'            AND sucheid = lSuche ',
'        )',
'        SELECT DISTINCT',
'            ms.sucheid AS sucheid,',
'            lMilestoneSelection AS meilenstein,',
'            sc.landid AS landid',
'        FROM search_countries sc',
'        LEFT JOIN T_MS_SUCHERGEBNISS ms ON (',
'            ms.sucheid = sc.sucheid ',
'            AND ms.landid = sc.landid',
'            AND sc.landid IN (',
'                SELECT column_value ',
'                FROM TABLE(apex_string.split_numbers(lSelected, '':''))',
'            )',
'        )',
'        WHERE ms.VORSCHRIFTID IS NOT NULL',
'    ) LOOP',
'        INSERT INTO t_ms_suche_split (',
'            sucheid,',
'            meilenstein,',
'            card_number,',
'            landid,',
'            BENUTZERID,',
'            letzte_aenderung_datum,',
'            letzte_aenderung_benutzerid',
'        )',
'        VALUES (',
'            i.sucheid,',
'            i.meilenstein,',
'            L_CARD,',
'            i.landid,',
'            :G_BENUTZERID,',
'            SYSDATE,',
'            :G_BENUTZERID',
'        );',
'    END LOOP;',
'',
'    -- Success message',
'    apex_application.g_print_success_message := ',
'        ''Karte '' || L_CARD || '' erfolgreich erstellt.'';',
'',
'    -- Close the JSON array',
'    apex_json.close_array;',
'            ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_error.add_error(',
'            p_message => ''Fehler beim Erstellen der Karte: '' || SQLERRM,',
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'        RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2707885514900878810
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected            VARCHAR2(2000) := apex_application.g_x01;  -- List of selected items',
'    lLaendergruppe       VARCHAR2(2000) := apex_application.g_x02;  -- List of country groups',
'    lStartdatumTyp       NUMBER := NULL;  -- Type of start date',
'    lSuche               VARCHAR2(2000) := apex_application.g_x03;  -- Selected Search',
'    lMilestoneSelection  VARCHAR2(2000) := apex_application.g_x04;   -- Selected milestone',
'     L_CARD NUMBER;',
'    l_count NUMBER;',
'    l_selected_count NUMBER;',
'    l_landid_exists BOOLEAN := FALSE;',
'    l_card_number number;',
'    begin',
'    -- Open the JSON array to start constructing the response',
'    apex_json.open_array;',
'  ',
'BEGIN    ',
'',
'    SELECT COUNT(column_value) INTO l_selected_count ',
'    FROM TABLE(apex_string.split_numbers(lSelected, '':''));',
'    ',
'    IF l_selected_count = 0 THEN',
'        apex_error.add_error(',
'            p_message => ''Please select at least one country.'',',
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'      --  RETURN;',
'   -- END IF;',
'else',
'    -- Check if these lands already exist in a card',
'    begin',
' SELECT distinct card_number INTO l_card_number ',
'        FROM t_ms_suche_split ',
'        WHERE sucheid = lSuche ',
'        AND meilenstein = lMilestoneSelection ',
'        AND landid IN (',
'            SELECT column_value ',
'            FROM TABLE(apex_string.split_numbers(lSelected, '':''))',
'        );',
'   exception when no_data_found then l_card_number :=0;',
'   end;',
'  --deleting existing countries for selected card',
'   if  l_card_number>0 then ',
'   delete from t_ms_suche_split where card_number =l_card_number and  BENUTZERID = :G_BENUTZERID;',
'   end if;',
'',
'    BEGIN',
'        SELECT COUNT(*) INTO l_count ',
'        FROM t_ms_suche_split ',
'        WHERE sucheid = lSuche ',
'        AND meilenstein = lMilestoneSelection ',
'        AND landid IN (',
'            SELECT column_value ',
'            FROM TABLE(apex_string.split_numbers(lSelected, '':''))',
'        );',
'    EXCEPTION ',
'        WHEN NO_DATA_FOUND THEN ',
'            l_count := 0;',
'    END;',
'',
'    -- Only proceed if countries aren''t already in a card',
'    IF l_count = 0 THEN ',
'        -- Get next card number',
'        SELECT NVL(MAX(card_number) + 1, 1) ',
'        INTO L_CARD ',
'        FROM t_ms_suche_split ',
'        WHERE BENUTZERID = :G_BENUTZERID;',
'',
'        -- Insert data',
'        FOR i IN (',
'            WITH search_countries AS (',
'                SELECT ',
'                    sucheid,',
'                    to_number(COLUMN_VALUE) AS landid',
'                FROM t_suche_json,',
'                TABLE(apex_string.split(',
'                    json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                    '':''',
'                ))',
'                WHERE BENUTZERID = :G_BENUTZERID',
'                AND sucheid = lSuche ',
'            )',
'            SELECT DISTINCT',
'                ms.sucheid AS sucheid,',
'                lMilestoneSelection AS meilenstein,',
'                sc.landid AS landid',
'            FROM search_countries sc',
'            LEFT JOIN T_MS_SUCHERGEBNISS ms ON (',
'                ms.sucheid = sc.sucheid ',
'                AND ms.landid = sc.landid',
'                AND sc.landid IN (',
'                    SELECT column_value ',
'                    FROM TABLE(apex_string.split_numbers(lSelected, '':''))',
'                )',
'            )',
'            WHERE VORSCHRIFTID IS NOT NULL',
'        ) LOOP',
'           -- l_landid_exists := TRUE;',
'            ',
'            INSERT INTO t_ms_suche_split (',
'                sucheid,',
'                meilenstein,',
'                card_number,',
'                landid,',
'                BENUTZERID,',
'                letzte_aenderung_datum,',
'                letzte_aenderung_benutzerid',
'            )',
'            VALUES (',
'                i.sucheid,',
'                i.meilenstein,',
'                L_CARD,',
'                i.landid,',
'                :G_BENUTZERID,',
'                SYSDATE,',
'                :G_BENUTZERID',
'            );',
'        END LOOP;',
'',
'        -- Check if any records were actually inserted',
'      /*  IF NOT l_landid_exists THEN',
'  '))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964321169130509416)
,p_process_sequence=>30
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'INSERT_CODE_AJAX_Backup - 29.09.2025'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected            VARCHAR2(2000) := apex_application.g_x01;  -- List of selected items',
'    lLaendergruppe       VARCHAR2(2000) := apex_application.g_x02;  -- List of country groups',
'    lStartdatumTyp       NUMBER := NULL;  -- Type of start date',
'    lSuche               VARCHAR2(2000) := apex_application.g_x03;  -- Selected Search',
'    lMilestoneSelection  VARCHAR2(2000) := apex_application.g_x04;   -- Selected milestone',
'     L_CARD NUMBER;',
'    l_count NUMBER;',
'    l_selected_count NUMBER;',
'    l_landid_exists BOOLEAN := FALSE;',
'    l_card_number number;',
'    begin',
'    -- Open the JSON array to start constructing the response',
'    apex_json.open_array;',
'  ',
'BEGIN    ',
'',
'    SELECT COUNT(column_value) INTO l_selected_count ',
'    FROM TABLE(apex_string.split_numbers(lSelected, '':''));',
'    ',
'    IF l_selected_count = 0 THEN',
'        apex_error.add_error(',
unistr('            p_message => ''Bitte w\00E4hlen Sie mindestens ein Land aus.'','),
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'      --  RETURN;',
'   -- END IF;',
'else',
'    -- Check if these lands already exist in a card',
'    begin',
' SELECT distinct card_number INTO l_card_number ',
'        FROM t_ms_suche_split ',
'        WHERE sucheid = lSuche ',
'        AND meilenstein = lMilestoneSelection ',
'        AND landid IN (',
'            SELECT column_value ',
'            FROM TABLE(apex_string.split_numbers(lSelected, '':''))',
'        );',
'   exception when no_data_found then l_card_number :=0;',
'   end;',
'  --deleting existing countries for selected card',
'   if  l_card_number>0 then ',
'   delete from t_ms_suche_split where card_number = l_card_number ',
'   and (BENUTZERID = :G_BENUTZERID ',
'        OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                   WHERE brr.benutzerid = :G_BENUTZERID ',
'                   AND brr.rolleid = 1001));',
'   end if;',
'',
'    BEGIN',
'        SELECT COUNT(*) INTO l_count ',
'        FROM t_ms_suche_split ',
'        WHERE sucheid = lSuche ',
'        AND meilenstein = lMilestoneSelection ',
'        AND landid IN (',
'            SELECT column_value ',
'            FROM TABLE(apex_string.split_numbers(lSelected, '':''))',
'        );',
'    EXCEPTION ',
'        WHEN NO_DATA_FOUND THEN ',
'            l_count := 0;',
'    END;',
'',
'    -- Only proceed if countries aren''t already in a card',
'    IF l_count = 0 THEN ',
'        -- Get next card number',
'        SELECT NVL(MAX(card_number) + 1, 1) ',
'        INTO L_CARD ',
'        FROM t_ms_suche_split ',
'        WHERE (BENUTZERID = :G_BENUTZERID ',
'               OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                          WHERE brr.benutzerid = :G_BENUTZERID ',
'                          AND brr.rolleid = 1001));',
'',
'        -- Insert data',
'        FOR i IN (',
'            WITH search_countries AS (',
'                SELECT ',
'                    sucheid,',
'                    to_number(COLUMN_VALUE) AS landid',
'                FROM t_suche_json,',
'                TABLE(apex_string.split(',
'                    json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                    '':''',
'                ))',
'                WHERE (BENUTZERID = :G_BENUTZERID ',
'                       OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                                  WHERE brr.benutzerid = :G_BENUTZERID ',
'                                  AND brr.rolleid = 1001))',
'                AND sucheid = lSuche ',
'            )',
'            SELECT DISTINCT',
'                ms.sucheid AS sucheid,',
'                lMilestoneSelection AS meilenstein,',
'                sc.landid AS landid',
'            FROM search_countries sc',
'            LEFT JOIN T_MS_SUCHERGEBNISS ms ON (',
'                ms.sucheid = sc.sucheid ',
'                AND ms.landid = sc.landid',
'                AND sc.landid IN (',
'                    SELECT column_value ',
'                    FROM TABLE(apex_string.split_numbers(lSelected, '':''))',
'                )',
'            )',
'            WHERE VORSCHRIFTID IS NOT NULL',
'        ) LOOP',
'           -- l_landid_exists := TRUE;',
'            ',
'            INSERT INTO t_ms_suche_split (',
'                sucheid,',
'                meilenstein,',
'                card_number,',
'                landid,',
'                BENUTZERID,',
'                letzte_aenderung_datum,',
'                letzte_aenderung_benutzerid',
'            )',
'            VALUES (',
'                i.sucheid,',
'                i.meilenstein,',
'                L_CARD,',
'                i.landid,',
'                :G_BENUTZERID,',
'                SYSDATE,',
'                :G_BENUTZERID',
'            );',
'        END LOOP;',
'',
'        -- Check if any records were actually inserted',
'      /*  IF NOT l_landid_exists THEN',
'            apex_error.add_error(',
'                p_message => ''No valid regulations found for selected countries.'',',
'                p_display_location => apex_error.c_inline_in_notification',
'            );',
'            RETURN;',
'        END IF;',
'*/',
'        -- Success message',
'        apex_application.g_print_success_message := ',
'            ''Karte '' || L_CARD || '' erfolgreich erstellt.'';',
'            ',
'    ELSE',
'        apex_error.add_error(',
unistr('            p_message => ''Ausgew\00E4hlte L\00E4nder sind bereits in einer Karte enthalten.'','),
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'    end if;',
'end if;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_error.add_error(',
'            p_message => ''Fehler beim Erstellen der Karte: '' || SQLERRM,',
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'        RAISE;',
' end; ',
'    -- Close the JSON array',
'   apex_json.close_array;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2707891146768878819
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSelected            VARCHAR2(2000) := apex_application.g_x01;  -- List of selected items',
'    lLaendergruppe       VARCHAR2(2000) := apex_application.g_x02;  -- List of country groups',
'    lStartdatumTyp       NUMBER := NULL;  -- Type of start date',
'    lSuche               VARCHAR2(2000) := apex_application.g_x03;  -- Selected Search',
'    lMilestoneSelection  VARCHAR2(2000) := apex_application.g_x04;   -- Selected milestone',
'     L_CARD NUMBER;',
'    l_count NUMBER;',
'    l_selected_count NUMBER;',
'    l_landid_exists BOOLEAN := FALSE;',
'    l_card_number number;',
'    begin',
'    -- Open the JSON array to start constructing the response',
'    apex_json.open_array;',
'  ',
'BEGIN    ',
'',
'    SELECT COUNT(column_value) INTO l_selected_count ',
'    FROM TABLE(apex_string.split_numbers(lSelected, '':''));',
'    ',
'    IF l_selected_count = 0 THEN',
'        apex_error.add_error(',
'            p_message => ''Please select at least one country.'',',
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'      --  RETURN;',
'   -- END IF;',
'else',
'    -- Check if these lands already exist in a card',
'    begin',
' SELECT distinct card_number INTO l_card_number ',
'        FROM t_ms_suche_split ',
'        WHERE sucheid = lSuche ',
'        AND meilenstein = lMilestoneSelection ',
'        AND landid IN (',
'            SELECT column_value ',
'            FROM TABLE(apex_string.split_numbers(lSelected, '':''))',
'        );',
'   exception when no_data_found then l_card_number :=0;',
'   end;',
'  --deleting existing countries for selected card',
'   if  l_card_number>0 then ',
'   delete from t_ms_suche_split where card_number =l_card_number and  BENUTZERID = :G_BENUTZERID;',
'   end if;',
'',
'    BEGIN',
'        SELECT COUNT(*) INTO l_count ',
'        FROM t_ms_suche_split ',
'        WHERE sucheid = lSuche ',
'        AND meilenstein = lMilestoneSelection ',
'        AND landid IN (',
'            SELECT column_value ',
'            FROM TABLE(apex_string.split_numbers(lSelected, '':''))',
'        );',
'    EXCEPTION ',
'        WHEN NO_DATA_FOUND THEN ',
'            l_count := 0;',
'    END;',
'',
'    -- Only proceed if countries aren''t already in a card',
'    IF l_count = 0 THEN ',
'        -- Get next card number',
'        SELECT NVL(MAX(card_number) + 1, 1) ',
'        INTO L_CARD ',
'        FROM t_ms_suche_split ',
'        WHERE BENUTZERID = :G_BENUTZERID;',
'',
'        -- Insert data',
'        FOR i IN (',
'            WITH search_countries AS (',
'                SELECT ',
'                    sucheid,',
'                    to_number(COLUMN_VALUE) AS landid',
'                FROM t_suche_json,',
'                TABLE(apex_string.split(',
'                    json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                    '':''',
'                ))',
'                WHERE BENUTZERID = :G_BENUTZERID',
'                AND sucheid = lSuche ',
'            )',
'            SELECT DISTINCT',
'                ms.sucheid AS sucheid,',
'                lMilestoneSelection AS meilenstein,',
'                sc.landid AS landid',
'            FROM search_countries sc',
'            LEFT JOIN T_MS_SUCHERGEBNISS ms ON (',
'                ms.sucheid = sc.sucheid ',
'                AND ms.landid = sc.landid',
'                AND sc.landid IN (',
'                    SELECT column_value ',
'                    FROM TABLE(apex_string.split_numbers(lSelected, '':''))',
'                )',
'            )',
'            WHERE VORSCHRIFTID IS NOT NULL',
'        ) LOOP',
'           -- l_landid_exists := TRUE;',
'            ',
'            INSERT INTO t_ms_suche_split (',
'                sucheid,',
'                meilenstein,',
'                card_number,',
'                landid,',
'                BENUTZERID,',
'                letzte_aenderung_datum,',
'                letzte_aenderung_benutzerid',
'            )',
'            VALUES (',
'                i.sucheid,',
'                i.meilenstein,',
'                L_CARD,',
'                i.landid,',
'                :G_BENUTZERID,',
'                SYSDATE,',
'                :G_BENUTZERID',
'            );',
'        END LOOP;',
'',
'        -- Check if any records were actually inserted',
'      /*  IF NOT l_landid_exists THEN',
'  '))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964326337908509424)
,p_process_sequence=>40
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'HANDLE_CARD_ACTION'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   l_first_card        NUMBER;',
'   l_new_card         NUMBER;',
'   l_counter          NUMBER := 0;',
'   l_remaining_countries NUMBER;',
'   l_total_rows       NUMBER;',
'   l_action           VARCHAR2(50) := apex_application.g_x01;',
'   l_card_numbers     VARCHAR2(4000) := apex_application.g_x02;',
'   l_country_ids      VARCHAR2(4000) := apex_application.g_x03;',
'   l_is_pri_user      NUMBER := 0;',
'BEGIN',
'   dbms_output.put_line(''=== Startkarte Aktion ==='');',
'   dbms_output.put_line(''Aktion: '' || l_action);',
'   dbms_output.put_line(''Karten-Nummern: '' || l_card_numbers);',
unistr('   dbms_output.put_line(''L\00E4nder-IDs: '' || l_country_ids);'),
'   ',
'   -- Check if user is PRI USER',
'   SELECT COUNT(*)',
'   INTO l_is_pri_user',
'   FROM t_benutzer_ref_rolle brr ',
'   WHERE brr.benutzerid = :G_BENUTZERID ',
'   AND brr.rolleid = 1001;',
'   ',
'   CASE l_action',
'       WHEN ''DELETE_CARD'' THEN',
'           IF l_is_pri_user > 0 THEN',
'               -- PRI users can delete any cards',
'               DELETE FROM t_ms_suche_split',
'               WHERE CARD_NUMBER IN (',
'                   SELECT column_value',
'                   FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'               )',
'               AND SUCHEID = :P460_SEARCH_SELECTION',
'               AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'           ELSE',
'               -- Regular users can only delete their own cards',
'               DELETE FROM t_ms_suche_split',
'               WHERE CARD_NUMBER IN (',
'                   SELECT column_value',
'                   FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'               )',
'               AND SUCHEID = :P460_SEARCH_SELECTION',
'               AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'               AND BENUTZERID = :G_BENUTZERID;',
'           END IF;',
'',
'           apex_json.open_object;',
'           apex_json.write(''status'', ''success'');',
unistr('           apex_json.write(''message'', ''Ausgew\00E4hlte Karten erfolgreich gel\00F6scht'');'),
'           apex_json.close_object;',
'',
'       WHEN ''DELETE_COUNTRIES'' THEN',
'           IF l_is_pri_user > 0 THEN',
'               -- PRI users',
'               SELECT COUNT(*)',
'               INTO l_remaining_countries',
'               FROM t_ms_suche_split',
'               WHERE card_number IN (',
'                   SELECT column_value ',
'                   FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'               )',
'               AND SUCHEID = :P460_SEARCH_SELECTION',
'               AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'               AND landid NOT IN (',
'                   SELECT column_value',
'                   FROM table(apex_string.split_numbers(l_country_ids, '':''))',
'               );',
'           ELSE',
'               -- Regular users',
'               SELECT COUNT(*)',
'               INTO l_remaining_countries',
'               FROM t_ms_suche_split',
'               WHERE card_number IN (',
'                   SELECT column_value ',
'                   FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'               )',
'               AND SUCHEID = :P460_SEARCH_SELECTION',
'               AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'               AND BENUTZERID = :G_BENUTZERID',
'               AND landid NOT IN (',
'                   SELECT column_value',
'                   FROM table(apex_string.split_numbers(l_country_ids, '':''))',
'               );',
'           END IF;',
'',
unistr('           dbms_output.put_line(''Verbleibende L\00E4nder: '' || l_remaining_countries);'),
'',
'           IF l_remaining_countries > 0 THEN',
'               IF l_is_pri_user > 0 THEN',
'                   -- PRI users',
'                   DELETE FROM t_ms_suche_split',
'                   WHERE card_number IN (',
'                       SELECT column_value',
'                       FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'                   )',
'                   AND landid IN (',
'                       SELECT column_value',
'                       FROM table(apex_string.split_numbers(l_country_ids, '':''))',
'                   )',
'                   AND SUCHEID = :P460_SEARCH_SELECTION',
'                   AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'               ELSE',
'                   -- Regular users',
'                   DELETE FROM t_ms_suche_split',
'                   WHERE card_number IN (',
'                       SELECT column_value',
'                       FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'                   )',
'                   AND landid IN (',
'                       SELECT column_value',
'                       FROM table(apex_string.split_numbers(l_country_ids, '':''))',
'                   )',
'                   AND SUCHEID = :P460_SEARCH_SELECTION',
'                   AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'                   AND BENUTZERID = :G_BENUTZERID;',
'               END IF;',
'',
unistr('               dbms_output.put_line(''L\00E4nder gel\00F6scht: '' || SQL%ROWCOUNT);'),
'',
'               apex_json.open_object;',
'               apex_json.write(''status'', ''success'');',
unistr('               apex_json.write(''message'', ''Ausgew\00E4hlte L\00E4nder erfolgreich gel\00F6scht'');'),
'               apex_json.close_object;',
'           ELSE',
'               apex_json.open_object;',
'               apex_json.write(''status'', ''error'');',
unistr('               apex_json.write(''message'', ''Es k\00F6nnen nicht alle L\00E4nder von einer Karte gel\00F6scht werden. Verwenden Sie stattdessen Karte l\00F6schen.'');'),
'               apex_json.close_object;',
'           END IF;',
'',
'       WHEN ''MERGE_CARD'' THEN',
'           IF l_is_pri_user > 0 THEN',
'               -- PRI users',
'               SELECT COUNT(*) INTO l_total_rows',
'               FROM t_ms_suche_split',
'               WHERE CARD_NUMBER IN (',
'                   SELECT column_value',
'                   FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'               )',
'               AND SUCHEID = :P460_SEARCH_SELECTION',
'               AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'           ELSE',
'               -- Regular users',
'               SELECT COUNT(*) INTO l_total_rows',
'               FROM t_ms_suche_split',
'               WHERE CARD_NUMBER IN (',
'                   SELECT column_value',
'                   FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'               )',
'               AND SUCHEID = :P460_SEARCH_SELECTION',
'               AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'               AND BENUTZERID = :G_BENUTZERID;',
'           END IF;',
'           ',
unistr('           dbms_output.put_line(''Zeilen vor der Zusammenf\00FChrung: '' || l_total_rows);'),
'           ',
'           SELECT MIN(column_value)',
'           INTO l_first_card',
'           FROM table(apex_string.split_numbers(l_card_numbers, '':''));',
'           ',
'           dbms_output.put_line(''Ziel-Kartennummer: '' || l_first_card);',
'           ',
'           IF l_is_pri_user > 0 THEN',
'               -- PRI users',
'               UPDATE t_ms_suche_split',
'               SET CARD_NUMBER = l_first_card',
'               WHERE CARD_NUMBER IN (',
'                   SELECT column_value',
'                   FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'               )',
'               AND SUCHEID = :P460_SEARCH_SELECTION',
'               AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'           ELSE',
'               -- Regular users',
'               UPDATE t_ms_suche_split',
'               SET CARD_NUMBER = l_first_card',
'               WHERE CARD_NUMBER IN (',
'                   SELECT column_value',
'                   FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'               )',
'               AND SUCHEID = :P460_SEARCH_SELECTION',
'               AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'               AND BENUTZERID = :G_BENUTZERID;',
'           END IF;',
'           ',
unistr('           dbms_output.put_line(''Bei der Zusammenf\00FChrung aktualisierte Zeilen: '' || SQL%ROWCOUNT);'),
'',
'           apex_json.open_object;',
'           apex_json.write(''status'', ''success'');',
unistr('           apex_json.write(''message'', ''Karten erfolgreich zusammengef\00FChrt'');'),
'           apex_json.close_object;',
'',
'       WHEN ''UNMERGE_CARD'' THEN',
'           SELECT NVL(MAX(CARD_NUMBER), 0) + 1',
'           INTO l_new_card',
'           FROM t_ms_suche_split;',
'           ',
'           dbms_output.put_line(''Beginn der Aufhebung der Sperrung mit neuer Kartennummer: '' || l_new_card);',
'           ',
'           IF l_is_pri_user > 0 THEN',
'               -- PRI users',
'               FOR r IN (',
'                   SELECT DISTINCT landid,',
'                          ROW_NUMBER() OVER (ORDER BY landid) - 1 as rn',
'                   FROM t_ms_suche_split ',
'                   WHERE CARD_NUMBER IN (',
'                       SELECT column_value',
'                       FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'                   )',
'                   AND SUCHEID = :P460_SEARCH_SELECTION',
'                   AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'               ) LOOP',
'                   IF r.rn > 0 THEN',
'                       UPDATE t_ms_suche_split',
'                       SET CARD_NUMBER = l_new_card + r.rn - 1',
'                       WHERE LANDID = r.landid',
'                       AND SUCHEID = :P460_SEARCH_SELECTION',
'                       AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'                       ',
'                       dbms_output.put_line(''Updated landid '' || r.landid || '' to card '' || (l_new_card + r.rn - 1));',
'                   END IF;',
'               END LOOP;',
'           ELSE',
'               -- Regular users',
'               FOR r IN (',
'                   SELECT DISTINCT landid,',
'                          ROW_NUMBER() OVER (ORDER BY landid) - 1 as rn',
'                   FROM t_ms_suche_split ',
'                   WHERE CARD_NUMBER IN (',
'                       SELECT column_value',
'                       FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'                   )',
'                   AND SUCHEID = :P460_SEARCH_SELECTION',
'                   AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'                   AND BENUTZERID = :G_BENUTZERID',
'               ) LOOP',
'                   IF r.rn > 0 THEN',
'                       UPDATE t_ms_suche_split',
'                       SET CARD_NUMBER = l_new_card + r.rn - 1',
'                       WHERE LANDID = r.landid',
'                       AND SUCHEID = :P460_SEARCH_SELECTION',
'                       AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'                       AND BENUTZERID = :G_BENUTZERID;',
'                       ',
'                       dbms_output.put_line(''Updated landid '' || r.landid || '' to card '' || (l_new_card + r.rn - 1));',
'                   END IF;',
'               END LOOP;',
'           END IF;',
'',
'           apex_json.open_object;',
'           apex_json.write(''status'', ''success'');',
'           apex_json.write(''message'', ''Karten erfolgreich entwertet'');',
'           apex_json.close_object;',
'',
'       WHEN ''UNMERGE_COUNTRIES'' THEN',
'           SELECT NVL(MAX(CARD_NUMBER), 0) + 1',
'           INTO l_new_card',
'           FROM t_ms_suche_split;',
'           ',
'           dbms_output.put_line(''Starting selective unmerge with new card number: '' || l_new_card);',
'           ',
'           IF l_country_ids IS NULL THEN',
'               apex_json.open_object;',
'               apex_json.write(''status'', ''error'');',
unistr('               apex_json.write(''message'', ''Bitte w\00E4hlen Sie die L\00E4nder aus, deren Zusammenf\00FChrung Sie aufheben m\00F6chten'');'),
'               apex_json.close_object;',
'               RETURN;',
'           END IF;',
'           ',
'           l_counter := 0;',
'           IF l_is_pri_user > 0 THEN',
'               -- PRI users',
'               FOR r IN (',
'                   SELECT landid,',
'                          ROW_NUMBER() OVER (ORDER BY landid) as rn',
'                   FROM t_ms_suche_split ',
'                   WHERE card_number IN (',
'                       SELECT column_value',
'                       FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'                   )',
'                   AND landid IN (',
'                       SELECT column_value',
'                       FROM table(apex_string.split_numbers(l_country_ids, '':''))',
'                   )',
'                   AND SUCHEID = :P460_SEARCH_SELECTION',
'                   AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'               ) LOOP',
'                   UPDATE t_ms_suche_split',
'                   SET CARD_NUMBER = l_new_card + l_counter,',
'                       LETZTE_AENDERUNG_DATUM = SYSDATE,',
'                       LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'                   WHERE LANDID = r.landid',
'                   AND SUCHEID = :P460_SEARCH_SELECTION',
'                   AND MEILENSTEIN = :P460_MILESTONE_SELECTION;',
'                   ',
'                   dbms_output.put_line(''Created new card '' || (l_new_card + l_counter) || '' for country '' || r.landid);',
'                   l_counter := l_counter + 1;',
'               END LOOP;',
'           ELSE',
'               -- Regular users',
'               FOR r IN (',
'                   SELECT landid,',
'                          ROW_NUMBER() OVER (ORDER BY landid) as rn',
'                   FROM t_ms_suche_split ',
'                   WHERE card_number IN (',
'                       SELECT column_value',
'                       FROM table(apex_string.split_numbers(l_card_numbers, '':''))',
'                   )',
'                   AND landid IN (',
'                       SELECT column_value',
'                       FROM table(apex_string.split_numbers(l_country_ids, '':''))',
'                   )',
'                   AND SUCHEID = :P460_SEARCH_SELECTION',
'                   AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'                   AND BENUTZERID = :G_BENUTZERID',
'               ) LOOP',
'                   UPDATE t_ms_suche_split',
'                   SET CARD_NUMBER = l_new_card + l_counter,',
'                       LETZTE_AENDERUNG_DATUM = SYSDATE,',
'                       LETZTE_AENDERUNG_BENUTZERID = :G_BENUTZERID',
'                   WHERE LANDID = r.landid',
'                   AND SUCHEID = :P460_SEARCH_SELECTION',
'                   AND MEILENSTEIN = :P460_MILESTONE_SELECTION',
'                   AND BENUTZERID = :G_BENUTZERID;',
'                   ',
'                   dbms_output.put_line(''Created new card '' || (l_new_card + l_counter) || '' for country '' || r.landid);',
'                   l_counter := l_counter + 1;',
'               END LOOP;',
'           END IF;',
'',
'           IF l_counter > 0 THEN',
'               apex_json.open_object;',
'               apex_json.write(''status'', ''success'');',
unistr('               apex_json.write(''message'', l_counter || '' Aufteilung der L\00E4nder auf neue Karten'');'),
'               apex_json.close_object;',
'           ELSE',
'               apex_json.open_object;',
'               apex_json.write(''status'', ''error'');',
unistr('               apex_json.write(''message'', ''Es wurden keine L\00E4nder zur Aufteilung ausgew\00E4hlt'');'),
'               apex_json.close_object;',
'           END IF;',
'   END CASE;',
'   ',
'   COMMIT;',
'   dbms_output.put_line(''=== Action Completed Successfully ==='');',
'   ',
'EXCEPTION',
'   WHEN OTHERS THEN',
'       dbms_output.put_line(''Ein Fehler ist aufgetreten: '' || SQLERRM);',
'       apex_json.open_object;',
'       apex_json.write(''status'', ''error'');',
'       apex_json.write(''message'', ''Error: '' || SQLERRM);',
'       apex_json.close_object;',
'       ROLLBACK;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2707885977990878811
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964327143411509425)
,p_process_sequence=>50
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DOWNLOAD_CARD_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_query         CLOB;',
'    l_excel         BLOB;',
'    l_filename      VARCHAR2(4000);',
'    l_name          VARCHAR2(4000);',
'    lTitle          VARCHAR2(4000);',
'    l_landids       VARCHAR2(4000) := apex_application.g_x01;',
'    l_count         NUMBER;',
'BEGIN',
'    -- Get user name',
'    SELECT b.nachname || ''_'' || b.vorname',
'      INTO l_name',
'      FROM t_benutzer b',
'     WHERE benutzerid = :G_BENUTZERID;',
'',
'    -- Count the number of selected countries',
'    SELECT COUNT(*)',
'      INTO l_count',
'      FROM t_land l',
'     WHERE l.LANDID IN (',
'           SELECT TO_NUMBER(COLUMN_VALUE)',
'             FROM TABLE(apex_string.split(l_landids, '':''))',
'     );',
'',
'    -- Determine title based on the number of countries selected',
'    IF l_count > 15 THEN',
'        -- More than 15 countries: use a general title',
unistr('        lTitle := ''L\00E4nder Vorschriften'';'),
'    ELSIF l_count >= 5 THEN',
'        -- Between 5 and 15 countries: use only B_NUMMER',
'        SELECT LISTAGG(l.B_NUMMER, ''; '') WITHIN GROUP (ORDER BY l.B_NUMMER)',
'          INTO lTitle',
'          FROM t_land l',
'         WHERE l.LANDID IN (',
'               SELECT TO_NUMBER(COLUMN_VALUE)',
'                 FROM TABLE(apex_string.split(l_landids, '':''))',
'         );',
'    ELSE',
'        -- Fewer than 5 countries: use B_NUMMER and the country name',
'        SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '') WITHIN GROUP (ORDER BY l.B_NUMMER)',
'          INTO lTitle',
'          FROM t_land l',
'         WHERE l.LANDID IN (',
'               SELECT TO_NUMBER(COLUMN_VALUE)',
'                 FROM TABLE(apex_string.split(l_landids, '':''))',
'         );',
'    END IF;',
'',
'    -- Get SQL query with EXCEL format',
'    l_query := PCK_RI_FILTERED_SUCHE.country_vorschrift_card_detail(',
'                 p_search_id => :P460_SEARCH_SELECTION,',
'                 p_milestone => :P460_MILESTONE_SELECTION,',
'                 p_landid    => l_landids,',
'                 p_format    => ''EXCEL''',
'               );',
'',
'    -- Generate Excel using emano_report',
'    l_excel := emano_report.fMakeExcelsingleSheet_land(',
'                   aSheetName => ''3MS Gefilterte Ergebnisse'',',
'                   aTitleName => lTitle || '' - Vorschriften'',',
'                   aQuery     => l_query',
'               );',
'',
'    -- Set filename',
'    l_filename := lTitle || '' - Vorschriften'' || ''-'' || l_name || ''-'' ||',
'                  TO_CHAR(SYSDATE, ''DD.MM.YYYY HH24:MI:SS'') || ''.xlsx'';',
'',
'    -- Download file',
'    sys.htp.init;',
'    sys.owa_util.mime_header(''application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'', FALSE);',
'    sys.htp.p(''Content-Length: '' || DBMS_LOB.GETLENGTH(l_excel));',
'    sys.htp.p(''Content-Disposition: attachment; filename="'' || l_filename || ''"'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(l_excel);',
'',
'    apex_application.stop_apex_engine;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        htp.p(''Error: '' || SQLERRM);',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2707885172487878810
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_query         CLOB;',
'    l_excel         BLOB;',
'    l_filename      VARCHAR2(4000);',
'    l_name          VARCHAR2(4000);',
'    lTitle          VARCHAR2(4000);',
'    l_landids       VARCHAR2(4000) := apex_application.g_x01;',
'BEGIN',
'    -- Get user name',
'    SELECT b.nachname || ''_'' || b.vorname',
'    INTO l_name',
'    FROM t_benutzer b',
'    WHERE benutzerid = :G_BENUTZERID;',
'    ',
'    -- Get title with all countries',
'    SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '') WITHIN GROUP (ORDER BY l.B_NUMMER)',
'    INTO lTitle',
'    FROM t_land l',
'    WHERE l.LANDID IN (',
'        SELECT TO_NUMBER(COLUMN_VALUE)',
'        FROM TABLE(apex_string.split(l_landids, '':''))',
'    );',
'    ',
'    -- Get SQL query with EXCEL format',
'    l_query := country_vorschrift_card_detail(',
'        p_search_id => :P460_SEARCH_SELECTION,',
'        p_milestone => :P460_MILESTONE_SELECTION,',
'        p_landid => l_landids,',
'        p_format => ''EXCEL''',
'    );',
'    ',
'    -- Generate Excel using emano_report',
'    l_excel := emano_report.fMakeExcelsingleSheet_land(',
'        aSheetName => ''3MS Filtered Results'',',
'        aTitleName => lTitle || '' - Vorschriften'',',
'        aQuery => l_query',
'    );',
'    ',
'    -- Set filename',
'    -- l_filename := ''Regulations_'' || l_name || ''_'' || ',
'    --               TO_CHAR(SYSDATE, ''YYYYMMDD_HH24MISS'') || ''.xlsx'';',
'    l_filename := lTitle || '' - Vorschriften'' || ''-'' || l_name || ''-'' || ',
'              TO_CHAR(SYSDATE, ''DD.MM.YYYY HH24:MI:SS'') || ''.xlsx'';',
'',
'    ',
'    -- Download',
'    sys.htp.init;',
'    sys.owa_util.mime_header(''application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'', FALSE);',
'    sys.htp.p(''Content-Length: '' || DBMS_LOB.GETLENGTH(l_excel));',
'    sys.htp.p(''Content-Disposition: attachment; filename="'' || l_filename || ''"'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(l_excel);',
'    ',
'    apex_application.stop_apex_engine;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        htp.p(''Error: '' || SQLERRM);',
'END;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964325986424509422)
,p_process_sequence=>60
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadData'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE    ',
'    lSearchID NUMBER;',
'    lMilestone NUMBER;',
'    lLaender VARCHAR2(4000);',
'    cChunkSize CONSTANT NUMBER := 8000;',
'    lChunk VARCHAR2(8000 CHAR);',
'    lDaten CLOB;',
'    lOffset PLS_INTEGER := 1;',
'BEGIN',
'    -- Get parameters ',
'    BEGIN',
'        lSearchID := TO_NUMBER(apex_application.g_x01);',
'        lMilestone := TO_NUMBER(apex_application.g_x02);',
'        lLaender := apex_application.g_x03;',
'    EXCEPTION',
'        WHEN OTHERS THEN',
'            HTP.PRN(''<tr><td colspan="3" style="text-align:center; padding:20px; color:#bb0a31;">Invalid parameters.</td></tr>'');',
'            RETURN;',
'    END;',
'    ',
'    -- Basic validation',
'    IF lSearchID IS NULL OR lMilestone IS NULL OR lLaender IS NULL THEN',
'        HTP.PRN(''<tr><td colspan="3" style="text-align:center; padding:20px; color:#bb0a31;">Missing parameters.</td></tr>'');',
'        RETURN;',
'    END IF;',
'    ',
'    -- Get regulation data',
'    BEGIN',
'        lDaten := PCK_RI_FILTERED_SUCHE.country_vorschrift_card_detail(',
'            p_search_id => lSearchID,',
'            p_milestone => lMilestone,',
'            p_landid => lLaender,',
'            p_format => ''DISPLAY''',
'        );',
'    EXCEPTION',
'        WHEN OTHERS THEN',
'            HTP.PRN(''<tr><td colspan="3" style="text-align:center; padding:20px; color:#bb0a31;">Package function error: '' || SUBSTR(SQLERRM, 1, 100) || ''</td></tr>'');',
'            RETURN;',
'    END;',
'    ',
'    -- Check if data exists',
'    IF lDaten IS NULL OR DBMS_LOB.GETLENGTH(lDaten) = 0 THEN',
'        HTP.PRN(''<tr><td colspan="3" style="text-align:center; padding:20px; color:#666;">No regulations found.</td></tr>'');',
'        RETURN;',
'    END IF;',
'    ',
'    -- Output data in small chunks',
'    BEGIN',
'        LOOP',
'            lChunk := DBMS_LOB.SUBSTR(lDaten, cChunkSize, lOffset);',
'            EXIT WHEN lChunk IS NULL OR LENGTH(lChunk) = 0;',
'            ',
'            HTP.PRN(lChunk);',
'            lOffset := lOffset + cChunkSize;',
'            ',
'            -- Safety check',
'            IF lOffset > DBMS_LOB.GETLENGTH(lDaten) + cChunkSize THEN',
'                EXIT;',
'            END IF;',
'        END LOOP;',
'    EXCEPTION',
'        WHEN OTHERS THEN',
'            HTP.PRN(''<tr><td colspan="3" style="text-align:center; padding:20px; color:#bb0a31;">Output error.</td></tr>'');',
'    END;',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        HTP.PRN(''<tr><td colspan="3" style="text-align:center; padding:20px; color:#bb0a31;">System error.</td></tr>'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2707886329474878813
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare    ',
'    lSearchID number := apex_application.g_x01;  -- List of selected items',
'    lMilestone number := apex_application.g_x02;  -- List of country groups',
'    lLaender varchar2(2000) := apex_application.g_x03;  -- Selected Search',
'    cChunkSize constant number := 32000;',
'    lChunk   varchar2(cChunkSize char);    ',
'',
'    lDaten clob;',
'    lOffset  pls_integer := 1;',
'begin',
'',
'    debug(''ajax1'');',
'',
'    lDaten := country_vorschrift_card_detail(',
'           p_search_id => lSearchID,',
'           p_milestone => lMilestone,',
'           P_LANDID => lLaender,',
'           p_format => ''DISPLAY''',
'       );',
'',
'    debug(''ajax2'');       ',
'',
'--  OWA_UTIL.MIME_HEADER(''application/json'');  ',
'  loop    ',
'    lChunk := dbms_lob.substr(lDaten, cChunkSize, lOffset);    ',
'    exit when lChunk is null;    ',
'    htp.prn(lChunk); -- PRN = don''t terminate each call with newline   ',
'    lOffset := lOffset + cChunkSize;  ',
'  end loop;',
'',
'',
'    debug(''ajax3'');    ',
'',
'    --debug(''ajax'',dbms_lob.getlength(lDaten));',
'',
'end;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964321536412509416)
,p_process_sequence=>70
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'loadData_Backup- 24.08.2025'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lSearchID NUMBER := apex_application.g_x01;',
'    lMilestone NUMBER := apex_application.g_x02;',
'    lLaender VARCHAR2(2000) := apex_application.g_x03;',
'    cChunkSize CONSTANT NUMBER := 32000;',
'    lChunk VARCHAR2(cChunkSize CHAR);',
'    lDaten CLOB;',
'    lOffset PLS_INTEGER := 1;',
'BEGIN',
'    -- Get regulation data with chunks',
'    lDaten := PCK_RI_FILTERED_SUCHE.country_vorschrift_card_detail(',
'        p_search_id => lSearchID,',
'        p_milestone => lMilestone,',
'        P_LANDID => lLaender,',
'        p_format => ''DISPLAY''',
'    );',
'',
'    -- Output data in chunks',
'    LOOP',
'        lChunk := DBMS_LOB.SUBSTR(lDaten, cChunkSize, lOffset);',
'        EXIT WHEN lChunk IS NULL;',
'        HTP.PRN(lChunk);',
'        lOffset := lOffset + cChunkSize;',
'    END LOOP;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        apex_error.add_error(',
'            p_message => ''Error loading data: '' || SQLERRM,',
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2707890779486878819
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare    ',
'    lSearchID number := apex_application.g_x01;  -- List of selected items',
'    lMilestone number := apex_application.g_x02;  -- List of country groups',
'    lLaender varchar2(2000) := apex_application.g_x03;  -- Selected Search',
'    cChunkSize constant number := 32000;',
'    lChunk   varchar2(cChunkSize char);    ',
'',
'    lDaten clob;',
'    lOffset  pls_integer := 1;',
'begin',
'',
'    debug(''ajax1'');',
'',
'    lDaten := country_vorschrift_card_detail(',
'           p_search_id => lSearchID,',
'           p_milestone => lMilestone,',
'           P_LANDID => lLaender,',
'           p_format => ''DISPLAY''',
'       );',
'',
'    debug(''ajax2'');       ',
'',
'--  OWA_UTIL.MIME_HEADER(''application/json'');  ',
'  loop    ',
'    lChunk := dbms_lob.substr(lDaten, cChunkSize, lOffset);    ',
'    exit when lChunk is null;    ',
'    htp.prn(lChunk); -- PRN = don''t terminate each call with newline   ',
'    lOffset := lOffset + cChunkSize;  ',
'  end loop;',
'',
'',
'    debug(''ajax3'');    ',
'',
'    --debug(''ajax'',dbms_lob.getlength(lDaten));',
'',
'end;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964325550730509421)
,p_process_sequence=>80
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_CARD_CONTENT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_landids VARCHAR2(4000) := apex_application.g_x02;',
'    l_search_id NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_milestone NUMBER := TO_NUMBER(apex_application.g_x04);',
'    l_country_list CLOB;',
'    --semicolon format',
'    l_country_list_semicolon CLOB;  ',
'    l_status VARCHAR2(20) := ''not-started'';',
'    l_status_icon VARCHAR2(100);',
'    l_status_title VARCHAR2(100);',
'    l_html CLOB;',
'    l_custom_title VARCHAR2(200);',
'    l_row_count NUMBER := 0;',
'',
'BEGIN',
'    -- Get country list with newlines',
'    SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, CHR(10)) ',
'           WITHIN GROUP (ORDER BY l.B_NUMMER)',
'    INTO l_country_list',
'    FROM t_land l',
'    WHERE l.LANDID IN (',
'        SELECT TO_NUMBER(COLUMN_VALUE)',
'        FROM TABLE(apex_string.split(l_landids, '':''))',
'    );',
'    ',
'    -- get country list with semicolons for the resetTitle function',
'    SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '') ',
'           WITHIN GROUP (ORDER BY l.B_NUMMER)',
'    INTO l_country_list_semicolon',
'    FROM t_land l',
'    WHERE l.LANDID IN (',
'        SELECT TO_NUMBER(COLUMN_VALUE)',
'        FROM TABLE(apex_string.split(l_landids, '':''))',
'    );',
'',
'    -- Get custom title if exists - FIXED FOR ORA-01422',
'    BEGIN',
'        SELECT MAX(custom_card_title)',
'        INTO l_custom_title',
'        FROM t_ms_suche_split',
'        WHERE card_number = l_card_number',
'        AND (BENUTZERID = :G_BENUTZERID ',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001))',
'        AND custom_card_title IS NOT NULL;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_custom_title := NULL;',
'    END;',
'    ',
'    -- Get status if exists - FIXED FOR ORA-01422',
'    BEGIN',
'        SELECT MAX(status)',
'        INTO l_status',
'        FROM t_ms_card_status cs',
'        WHERE cs.card_number = l_card_number',
'        AND cs.sucheid = l_search_id',
'        AND cs.meilenstein = l_milestone',
'        AND (cs.benutzerid = :G_BENUTZERID ',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001));',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_status := ''not-started'';',
'    END;',
'    ',
'    -- Ensure status has a valid value',
'    IF l_status IS NULL OR l_status NOT IN (''not-started'', ''in-progress'', ''completed'') THEN',
'        l_status := ''not-started'';',
'    END IF;',
'    ',
'    -- Get number of GROUPED rows for this card (matching the LISTAGG logic)',
'    BEGIN',
'        WITH search_countries AS (',
'            SELECT ',
'                sucheid,',
'                to_number(COLUMN_VALUE) as landid',
'            FROM t_suche_json,',
'            TABLE(apex_string.split(',
'                json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                '':''',
'            ))',
'            WHERE sucheid = l_search_id',
'        )',
'        SELECT COUNT(DISTINCT ',
'            CASE ',
'                WHEN NVL(tp_main.ANZEIGE_MIT_DOKUMENTENDATUM, 0) = 20 ',
'                     AND tv_main.DOKUMENTENDATUM IS NOT NULL ',
'                THEN COALESCE(tv_main.vorschrift_nummer, ms.vorschriftnummer) || ''_'' || ',
'                     TO_CHAR(tv_main.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'                ELSE COALESCE(tv_main.vorschrift_nummer, ms.vorschriftnummer) ',
'            END || ''|'' || ms.themabezeichnung',
'        )',
'        INTO l_row_count',
'        FROM search_countries sc',
'        LEFT OUTER JOIN T_MS_SUCHERGEBNISS ms ON (',
'            ms.sucheid = sc.sucheid ',
'            AND ms.landid = sc.landid',
'            AND sc.landid IN (',
'                SELECT TO_NUMBER(COLUMN_VALUE)',
'                FROM TABLE(apex_string.split(l_landids, '':''))',
'            )',
'        )',
'        LEFT OUTER JOIN t_vorschrift tv_main ON (tv_main.vorschriftid = ms.vorschriftid)',
'        LEFT OUTER JOIN t_publisher tp_main ON (tv_main.publisherid = tp_main.publisherid)',
'        LEFT OUTER JOIN T_MS_PARAMETER mp ON (mp.MS_PARAMETERID = ms.MS_PARAMETERID)',
'        WHERE ms.vorschriftnummer IS NOT NULL',
'        AND ms.MEILENSTEIN = l_milestone',
'        -- AND mp.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1;',
'        AND (mp.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1 OR ms.MANUELLER_EINTRAG = 10);',
'    EXCEPTION',
'        WHEN OTHERS THEN',
'            l_row_count := 0;',
'    END;',
'',
'    -- Set status icon and title - FIXED WITH ELSE CLAUSE',
'    CASE l_status',
'        WHEN ''not-started'' THEN',
'            l_status_icon := ''<span class="fa fa-clock-o" style="font-size: 14px;"></span>'';',
'            l_status_title := ''Nicht begonnen'';',
'        WHEN ''in-progress'' THEN',
'            l_status_icon := ''<span class="fa fa-spinner" style="font-size: 14px;"></span>'';',
'            l_status_title := ''In Bearbeitung'';',
'        WHEN ''completed'' THEN',
'            l_status_icon := ''<span class="fa fa-check-circle" style="font-size: 14px;"></span>'';',
'            l_status_title := ''Bearbeitung des Marktes abgeschlossen'';',
'        ELSE',
'            -- Default case for any unexpected status value',
'            l_status_icon := ''<span class="fa fa-clock-o" style="font-size: 14px;"></span>'';',
'            l_status_title := ''Nicht begonnen'';',
'            l_status := ''not-started'';',
'    END CASE;',
'    ',
'    -- Build card HTML with improved layout structure',
'    l_html := ',
'    ''<div class="header-container">'' ||',
'    ',
'    -- Title section with editing controls',
'    ''<div class="title-section">'' ||',
'    ''<div class="title-container" id="title-container-'' || l_card_number || ''">'' ||',
'    ',
'    -- Edit icon',
'    ''<span class="edit-icon" onclick="makeEditable('' || l_card_number || '')" title="Title bearbeiten">'' ||',
'    ''<span class="fa fa-edit" style="font-size: 14px; color: #666;"></span>'' ||',
'    ''</span>'' ||',
'    ',
'    -- Reset icon (only visible when custom title exists)',
'    CASE WHEN l_custom_title IS NOT NULL THEN',
'        ''<span class="reset-icon" onclick="resetTitle('' || l_card_number || '', '''''' || ',
'        REPLACE(l_country_list_semicolon, '''''''', '''''''''''') || '''''');" '' ||',
unistr('        ''title="Titel l\00F6schen">'' ||'),
'        ''<span class="fa fa-trash" style="font-size: 14px; color: #666;"></span>'' ||',
'        ''</span>''',
'    ELSE ',
'        ''<span class="reset-icon" style="display:none;" onclick="resetTitle('' || l_card_number || '', '''''' || ',
'        REPLACE(l_country_list_semicolon, '''''''', '''''''''''') || '''''');" '' ||',
unistr('        ''title="Titel l\00F6schen">'' ||'),
'        ''<span class="fa fa-trash" style="font-size: 14px; color: #666;"></span>'' ||',
'        ''</span>''',
'    END ||',
'    ',
'    -- Custom title indicator (if exists)',
'    CASE WHEN l_custom_title IS NOT NULL THEN',
'        ''<div class="custom-title-indicator">'' ||',
'        l_custom_title ||',
'        ''</div>''',
'    ELSE '''' END ||',
'    ',
'    -- Country list with data attributes (using newline format for display)',
'    ''<span class="country-name" id="card-title-'' || l_card_number || ''" '' ||',
'    ''data-custom-title="'' || NVL(l_custom_title, '''') || ''">'' || ',
'    l_country_list || ',
'    ''</span>'' ||',
'    ''</div>'' ||',
'    ''</div>'' ||',
'    ',
'    -- Action buttons section (separate from title section)',
'    ''<div class="action-buttons">'' ||',
'    -- Status Indicator',
'    ''<span class="status-indicator '' || l_status || ''" '' || ',
'    ''title="'' || l_status_title || ''" '' || ',
'    ''data-card="'' || l_card_number || ''" '' || ',
'    ''onclick="cycleStatus('' || l_card_number || '')">'' ||',
'    l_status_icon ||',
'    ''</span>'' ||',
'',
'    -- View button',
'    ''<span class="view-full-button" onclick="openDetailView('''''' || REGEXP_REPLACE(l_landids, '':'', '';'') || '''''', '''''' || l_card_number || '''''')" '' ||',
unistr('    ''title="Detailansicht \00F6ffnen" style="cursor: pointer; margin: 0 8px; color: #bb0a31;">'' ||'),
'    ''<span class="fa fa-expand" style="font-size: 14px;"></span>'' ||',
'    ''</span>'' ||',
'    ',
'    -- Download button',
'    ''<span class="download-icon" onclick="downloadCardData('''''' || l_landids || '''''')" '' ||',
'    ''title="Daten herunterladen">'' ||',
'    ''<span class="fa fa-download-alt" style="font-size: 14px;"></span>'' ||',
'    ''</span>'' ||',
'    ''</div>'' ||',
'    ',
'    ''</div>'' ||',
'    ',
'    ''<div class="t-Report t-Report--altRowsDefault t-Report--rowHighlight">'' ||',
'    ''<div class="t-Report-wrap">'' ||',
'    ',
'    -- Only include the toggle header and button when there are more than 5 rows',
'    CASE WHEN l_row_count > 5 THEN',
'        -- Toggle header with expand button for cards with more than 5 rows',
'        ''<div class="toggle-header" style="display: flex; justify-content: space-between; align-items: center; padding: 8px 12px; background-color: #f5f5f5; border-bottom: 1px solid #e0e0e0;">'' ||',
'        ''<div class="toggle-count" style="display: inline-block;">'' || l_row_count || '' Vorschriften insgesamt</div>'' ||',
'        ''<div class="toggle-button" style="cursor: pointer; color: #bb0a31; display: inline-flex; align-items: center;">'' ||',
'        ''<span class="fa fa-expand" style="font-size: 14px; margin-right: 4px;"></span>'' ||',
'        ''<span class="toggle-text">Expand</span>'' ||',
'        ''</div>'' ||',
'        ''</div>''',
'    ELSE',
'        -- Simple header without expand button for cards with 5 or fewer rows',
'        ''<div style="padding: 8px 12px; background-color: #f5f5f5; border-bottom: 1px solid #e0e0e0;">'' ||',
'        ''<div class="toggle-count" style="display: inline-block;">'' || l_row_count || '' Vorschriften insgesamt</div>'' ||',
'        ''</div>''',
'    END ||',
'    ',
'    ''<div class="t-Report-tableWrap" style="width: 100%; overflow-x: hidden;">'' ||',
'    ''<table class="t-Report-report" style="width: 100%; table-layout: fixed;">'' ||',
'    ''<thead><tr>'' ||',
'    ''<th class="t-Report-colHead" align="left" style="width: 40%; padding: 12px 8px; height: 40px; text-align: center;">'' ||',
'    ''<span class="u-Report-sortHeading">Themabezeichnung</span>'' ||',
'    ''</th>'' ||',
'    ''<th class="t-Report-colHead" align="center" style="width: 30%; padding: 12px 8px; height: 40px; text-align: center;">'' ||',
'    ''<span class="u-Report-sortHeading">Vorschriftennummer</span>'' ||',
'    ''</th>'' ||',
'    ''<th class="t-Report-colHead" align="center" style="width: 30%; padding: 12px 8px; height: 40px; text-align: center;">'' ||',
'    ''<span class="u-Report-sortHeading">Alternative Vorschriftennummer</span>'' ||',
'    ''</th></tr></thead>'' ||',
'    ''<tbody>'' ||',
'    ''<div class="loaddata" searchid="'' || l_search_id || ''" milestone="'' || l_milestone || ''" landid="'' || l_landids || ''">'' ||',
'    ''</div>'' ||',
'    ''</tbody>'' ||',
'    ''</table></div></div></div>'';',
'    ',
'    -- Return HTML',
'    HTP.p(l_html);',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        HTP.p(''Error generating card content: '' || SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2707886765168878814
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
' l_html := ',
'    ''<div class="header-container">'' ||',
'    ''<div class="title-container">'' ||',
'    ''<span class="edit-icon" onclick="makeEditable('' || l_card_number || '')" title="Title bearbeiten">'' ||',
'    ''<span class="fa fa-edit" style="font-size: 14px; color: #666;"></span>'' ||',
'    ''</span>'' ||',
'    -- Add reset icon (only visible when custom title exists)',
'    CASE WHEN l_custom_title IS NOT NULL THEN',
'        ''<span class="reset-icon" onclick="resetTitle('' || l_card_number || '', '''''' || ',
'        REPLACE(l_country_list, '''''''', '''''''''''' ) || '''''');" '' ||',
unistr('        ''title="Zur\00FCcksetzen auf Standardtitel">'' ||'),
'        ''<span class="fa fa-undo" style="font-size: 14px; color: #666;"></span>'' ||',
'        ''</span>''',
'    ELSE '''' END ||',
'    ''<span class="country-name" id="card-title-'' || l_card_number || ''">'' || ',
'    nvl(l_custom_title, l_country_list) || ',
'    ''</span>'' ||',
'    ''</div>'' ||',
'    -- Status Indicator',
'    ''<span class="status-indicator '' || l_status || ''" '' || ',
'    ''title="'' || l_status_title || ''" '' || ',
'    ''data-card="'' || l_card_number || ''" '' || ',
'    ''onclick="cycleStatus('' || l_card_number || '')">'' ||',
'    l_status_icon ||',
'    ''</span>'' ||',
'    -- View button',
'    ''<span class="view-full-button" onclick="openDetailView('''''' || l_landids || '''''', '''''' || l_card_number || '''''')" '' ||',
unistr('    ''title="Detailansicht \00F6ffnen" style="cursor: pointer; margin: 0 8px; color: #bb0a31;">'' ||'),
'    ''<span class="fa fa-expand" style="font-size: 14px;"></span>'' ||',
'    ''</span>'' ||',
'    -- Download button',
'    ''<span class="download-icon" onclick="downloadCardData('''''' || l_landids || '''''')" '' ||',
'    ''title="Daten herunterladen">'' ||',
'    ''<span class="fa fa-download-alt" style="font-size: 14px;"></span>'' ||',
'    ''</span>'' ||',
'    ''</div>'' ||',
'    ''<div class="t-Report t-Report--altRowsDefault t-Report--rowHighlight">'' ||',
'    ''<div class="t-Report-wrap">'' ||',
'    -- Add the toggle row above the table headers with the Expand button',
'    ''<div class="toggle-header" style="display: flex; justify-content: space-between; align-items: center; padding: 8px 12px; background-color: #f5f5f5; border-bottom: 1px solid #e0e0e0;">'' ||',
'    ''<div class="toggle-count" style="display: inline-block;">'' || l_row_count || '' Vorschriften insgesamt</div>'' ||',
'    ''<div class="toggle-button" style="cursor: pointer; color: #bb0a31; display: inline-flex; align-items: center;">'' ||',
'    ''<span class="fa fa-expand" style="font-size: 14px; margin-right: 4px;"></span>'' ||',
'    ''<span class="toggle-text">Expand</span>'' ||',
'    ''</div>'' ||',
'    ''</div>'' ||',
'    ''<div class="t-Report-tableWrap">'' ||',
'    ''<table class="t-Report-report" style="width: 100%; table-layout: fixed;">'' ||',
'    ''<thead><tr>'' ||',
'    ''<th class="t-Report-colHead" align="left" style="width: 60%; padding: 12px 8px; height: 40px; text-align: center;">'' ||',
'    ''<span class="u-Report-sortHeading">Themabezeichnung</span>'' ||',
'    ''</th>'' ||',
'    ''<th class="t-Report-colHead" align="center" style="width: 40%; padding: 12px 8px; height: 40px; text-align: center;">'' ||',
'    ''<span class="u-Report-sortHeading">Vorschriftennummer</span>'' ||',
'    ''</th></tr></thead>'' ||',
'    ''<tbody>'' ||',
'    ''<div class="loaddata" searchid="'' || l_search_id || ''" milestone="'' || l_milestone || ''" landid="'' || l_landids || ''">'' ||',
'    ''</div>'' ||',
'    ''</tbody>'' ||',
'    ''</table></div></div></div>'';',
'    ',
'    -- Return HTML',
'    HTP.p(l_html);'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(952959514029997289)
,p_process_sequence=>90
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_CARD_CONTENT_29.101.2025, 09:07am'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_landids VARCHAR2(4000) := apex_application.g_x02;',
'    l_search_id NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_milestone NUMBER := TO_NUMBER(apex_application.g_x04);',
'    l_country_list CLOB;',
'    --semicolon format',
'    l_country_list_semicolon CLOB;  ',
'    l_status VARCHAR2(20) := ''not-started'';',
'    l_status_icon VARCHAR2(100);',
'    l_status_title VARCHAR2(100);',
'    l_html CLOB;',
'    l_custom_title VARCHAR2(200);',
'    l_row_count NUMBER := 0;',
'',
'',
'',
'',
'',
'BEGIN',
'    -- Get country list with newlines',
'    SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, CHR(10)) ',
'           WITHIN GROUP (ORDER BY l.B_NUMMER)',
'    INTO l_country_list',
'    FROM t_land l',
'    WHERE l.LANDID IN (',
'        SELECT TO_NUMBER(COLUMN_VALUE)',
'        FROM TABLE(apex_string.split(l_landids, '':''))',
'    );',
'    ',
'    -- get country list with semicolons for the resetTitle function',
'    SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '') ',
'           WITHIN GROUP (ORDER BY l.B_NUMMER)',
'    INTO l_country_list_semicolon',
'    FROM t_land l',
'    WHERE l.LANDID IN (',
'        SELECT TO_NUMBER(COLUMN_VALUE)',
'        FROM TABLE(apex_string.split(l_landids, '':''))',
'    );',
'',
'    -- Get custom title if exists - MODIFIED FOR PRI USERS',
'    BEGIN',
'        SELECT custom_card_title ',
'        INTO l_custom_title',
'        FROM t_ms_suche_split',
'        WHERE card_number = l_card_number',
'        AND (BENUTZERID = :G_BENUTZERID ',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001))',
'        AND ROWNUM = 1',
'        AND custom_card_title IS NOT NULL;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_custom_title := NULL;',
'    END;',
'    ',
'    -- Get status if exists - MODIFIED FOR PRI USERS',
'    BEGIN',
'        SELECT status',
'        INTO l_status',
'        FROM t_ms_card_status cs',
'        WHERE cs.card_number = l_card_number',
'        AND cs.sucheid = l_search_id',
'        AND cs.meilenstein = l_milestone',
'        AND (cs.benutzerid = :G_BENUTZERID ',
'             OR EXISTS (SELECT 1 FROM t_benutzer_ref_rolle brr ',
'                        WHERE brr.benutzerid = :G_BENUTZERID ',
'                        AND brr.rolleid = 1001));',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_status := ''not-started'';',
'    END;',
'    ',
'    -- Get number of rows for this card',
'    /*',
'    ',
'    BEGIN',
'        SELECT COUNT(*)',
'        INTO l_row_count',
'        FROM T_MS_SUCHERGEBNISS ms',
'        WHERE ms.landid IN (',
'            SELECT TO_NUMBER(COLUMN_VALUE)',
'            FROM TABLE(apex_string.split(l_landids, '':''))',
'        )',
'        AND ms.sucheid = l_search_id',
'        AND ms.meilenstein = l_milestone;',
'    EXCEPTION',
'        WHEN OTHERS THEN',
'            l_row_count := 0;',
'    END;',
'',
'    */',
'    ',
'',
'    -- Get number of GROUPED rows for this card (matching the LISTAGG logic)',
'    BEGIN',
'        WITH search_countries AS (',
'            SELECT ',
'                sucheid,',
'                to_number(COLUMN_VALUE) as landid',
'            FROM t_suche_json,',
'            TABLE(apex_string.split(',
'                json_value(suchdaten FORMAT JSON, ''$[0].LAENDER''),',
'                '':''',
'            ))',
'            WHERE sucheid = l_search_id',
'        )',
'        SELECT COUNT(DISTINCT ',
'            CASE ',
'                WHEN NVL(tp_main.ANZEIGE_MIT_DOKUMENTENDATUM, 0) = 20 ',
'                     AND tv_main.DOKUMENTENDATUM IS NOT NULL ',
'                THEN COALESCE(tv_main.vorschrift_nummer, ms.vorschriftnummer) || ''_'' || ',
'                     TO_CHAR(tv_main.DOKUMENTENDATUM, ''DD.MM.YYYY'')',
'                ELSE COALESCE(tv_main.vorschrift_nummer, ms.vorschriftnummer) ',
'            END || ''|'' || ms.themabezeichnung  -- Use pipe to make unique combination',
'        )',
'        INTO l_row_count',
'        FROM search_countries sc',
'        LEFT OUTER JOIN T_MS_SUCHERGEBNISS ms ON (',
'            ms.sucheid = sc.sucheid ',
'            AND ms.landid = sc.landid',
'            AND sc.landid IN (',
'                SELECT TO_NUMBER(COLUMN_VALUE)',
'                FROM TABLE(apex_string.split(l_landids, '':''))',
'            )',
'        )',
'        LEFT OUTER JOIN t_vorschrift tv_main ON (tv_main.vorschriftid = ms.vorschriftid)',
'        LEFT OUTER JOIN t_publisher tp_main ON (tv_main.publisherid = tp_main.publisherid)',
'        LEFT OUTER JOIN T_MS_PARAMETER mp ON (mp.MS_PARAMETERID = ms.MS_PARAMETERID)',
'        WHERE ms.vorschriftnummer IS NOT NULL',
'        AND ms.MEILENSTEIN = l_milestone',
'        AND mp.AUSGABE_DER_VORSCHRIFT_BEI_REPORT_BAUREIHE = 1;',
'    EXCEPTION',
'        WHEN OTHERS THEN',
'            l_row_count := 0;',
'    END;',
'',
'',
'',
'    -- Set status icon and title',
'    CASE l_status',
'        WHEN ''not-started'' THEN',
'            l_status_icon := ''<span class="fa fa-clock-o" style="font-size: 14px;"></span>'';',
'            l_status_title := ''Nicht begonnen'';',
'        WHEN ''in-progress'' THEN',
'            l_status_icon := ''<span class="fa fa-spinner" style="font-size: 14px;"></span>'';',
'            l_status_title := ''In Bearbeitung'';',
'        WHEN ''completed'' THEN',
'            l_status_icon := ''<span class="fa fa-check-circle" style="font-size: 14px;"></span>'';',
'            l_status_title := ''Bearbeitung des Marktes abgeschlossen'';',
'    END CASE;',
'    ',
'    -- Build card HTML with improved layout structure',
'    l_html := ',
'    ''<div class="header-container">'' ||',
'    ',
'    -- Title section with editing controls',
'    ''<div class="title-section">'' ||',
'    ''<div class="title-container" id="title-container-'' || l_card_number || ''">'' ||',
'    ',
'    -- Edit icon',
'    ''<span class="edit-icon" onclick="makeEditable('' || l_card_number || '')" title="Title bearbeiten">'' ||',
'    ''<span class="fa fa-edit" style="font-size: 14px; color: #666;"></span>'' ||',
'    ''</span>'' ||',
'    ',
'    -- Reset icon (only visible when custom title exists)',
'    CASE WHEN l_custom_title IS NOT NULL THEN',
'        ''<span class="reset-icon" onclick="resetTitle('' || l_card_number || '', '''''' || ',
'        REPLACE(l_country_list_semicolon, '''''''', '''''''''''') || '''''');" '' ||  -- Using semicolon format',
unistr('        ''title="Titel l\00F6schen">'' ||'),
'        ''<span class="fa fa-trash" style="font-size: 14px; color: #666;"></span>'' ||',
'        ''</span>''',
'    ELSE ',
'        ''<span class="reset-icon" style="display:none;" onclick="resetTitle('' || l_card_number || '', '''''' || ',
'        REPLACE(l_country_list_semicolon, '''''''', '''''''''''') || '''''');" '' ||  -- Using semicolon format',
unistr('        ''title="Titel l\00F6schen">'' ||'),
'        ''<span class="fa fa-trash" style="font-size: 14px; color: #666;"></span>'' ||',
'        ''</span>''',
'    END ||',
'    ',
'    -- Custom title indicator (if exists)',
'    CASE WHEN l_custom_title IS NOT NULL THEN',
'        ''<div class="custom-title-indicator">'' ||',
'        l_custom_title ||',
'        ''</div>''',
'    ELSE '''' END ||',
'    ',
'    -- Country list with data attributes (using newline format for display)',
'    ''<span class="country-name" id="card-title-'' || l_card_number || ''" '' ||',
'    ''data-custom-title="'' || NVL(l_custom_title, '''') || ''">'' || ',
'    l_country_list || ',
'    ''</span>'' ||',
'    ''</div>'' ||',
'    ''</div>'' ||',
'    ',
'    -- Action buttons section (separate from title section)',
'    ''<div class="action-buttons">'' ||',
'    -- Status Indicator',
'    ''<span class="status-indicator '' || l_status || ''" '' || ',
'    ''title="'' || l_status_title || ''" '' || ',
'    ''data-card="'' || l_card_number || ''" '' || ',
'    ''onclick="cycleStatus('' || l_card_number || '')">'' ||',
'    l_status_icon ||',
'    ''</span>'' ||',
'',
'    -- View button',
'    ''<span class="view-full-button" onclick="openDetailView('''''' || REGEXP_REPLACE(l_landids, '':'', '';'') || '''''', '''''' || l_card_number || '''''')" '' ||',
unistr('    ''title="Detailansicht \00F6ffnen" style="cursor: pointer; margin: 0 8px; color: #bb0a31;">'' ||'),
'    ''<span class="fa fa-expand" style="font-size: 14px;"></span>'' ||',
'    ''</span>'' ||',
'    ',
'    -- Download button',
'    ''<span class="download-icon" onclick="downloadCardData('''''' || l_landids || '''''')" '' ||',
'    ''title="Daten herunterladen">'' ||',
'    ''<span class="fa fa-download-alt" style="font-size: 14px;"></span>'' ||',
'    ''</span>'' ||',
'    ''</div>'' ||',
'    ',
'    ''</div>'' ||',
'    ',
'    ''<div class="t-Report t-Report--altRowsDefault t-Report--rowHighlight">'' ||',
'    ''<div class="t-Report-wrap">'' ||',
'    ',
'    -- Only include the toggle header and button when there are more than 5 rows',
'    CASE WHEN l_row_count > 5 THEN',
'        -- Toggle header with expand button for cards with more than 5 rows',
'        ''<div class="toggle-header" style="display: flex; justify-content: space-between; align-items: center; padding: 8px 12px; background-color: #f5f5f5; border-bottom: 1px solid #e0e0e0;">'' ||',
'        ''<div class="toggle-count" style="display: inline-block;">'' || l_row_count || '' Vorschriften insgesamt</div>'' ||',
'        ''<div class="toggle-button" style="cursor: pointer; color: #bb0a31; display: inline-flex; align-items: center;">'' ||',
'        ''<span class="fa fa-expand" style="font-size: 14px; margin-right: 4px;"></span>'' ||',
'        ''<span class="toggle-text">Expand</span>'' ||',
'        ''</div>'' ||',
'        ''</div>''',
'    ELSE',
'        -- Simple header without expand button for cards with 5 or fewer rows',
'        ''<div style="padding: 8px 12px; background-color: #f5f5f5; border-bottom: 1px solid #e0e0e0;">'' ||',
'        ''<div class="toggle-count" style="display: inline-block;">'' || l_row_count || '' Vorschriften insgesamt</div>'' ||',
'        ''</div>''',
'    END ||',
'    ',
'    ''<div class="t-Report-tableWrap" style="width: 100%; overflow-x: hidden;">'' ||',
'    ''<table class="t-Report-report" style="width: 100%; table-layout: fixed;">'' ||',
'    ''<thead><tr>'' ||',
'    ''<th class="t-Report-colHead" align="left" style="width: 40%; padding: 12px 8px; height: 40px; text-align: center;">'' ||',
'    ''<span class="u-Report-sortHeading">Themabezeichnung</span>'' ||',
'    ''</th>'' ||',
'    ''<th class="t-Report-colHead" align="center" style="width: 30%; padding: 12px 8px; height: 40px; text-align: center;">'' ||',
'    ''<span class="u-Report-sortHeading">Vorschriftennummer</span>'' ||',
'    ''</th>'' ||',
'    ''<th class="t-Report-colHead" align="center" style="width: 30%; padding: 12px 8px; height: 40px; text-align: center;">'' ||',
'    ''<span class="u-Report-sortHeading">Alternative Vorschriftennummer</span>'' ||',
'    ''</th></tr></thead>'' ||',
'    ''<tbody>'' ||',
'    ''<div class="loaddata" searchid="'' || l_search_id || ''" milestone="'' || l_milestone || ''" landid="'' || l_landids || ''">'' ||',
'    ''</div>'' ||',
'    ''</tbody>'' ||',
'    ''</table></div></div></div>'';',
'',
'',
'',
'',
'',
'',
'    ',
'    -- Return HTML',
'    HTP.p(l_html);',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        HTP.p(''Error generating card content: '' || SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>2719252801869390946
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
' l_html := ',
'    ''<div class="header-container">'' ||',
'    ''<div class="title-container">'' ||',
'    ''<span class="edit-icon" onclick="makeEditable('' || l_card_number || '')" title="Title bearbeiten">'' ||',
'    ''<span class="fa fa-edit" style="font-size: 14px; color: #666;"></span>'' ||',
'    ''</span>'' ||',
'    -- Add reset icon (only visible when custom title exists)',
'    CASE WHEN l_custom_title IS NOT NULL THEN',
'        ''<span class="reset-icon" onclick="resetTitle('' || l_card_number || '', '''''' || ',
'        REPLACE(l_country_list, '''''''', '''''''''''' ) || '''''');" '' ||',
unistr('        ''title="Zur\00FCcksetzen auf Standardtitel">'' ||'),
'        ''<span class="fa fa-undo" style="font-size: 14px; color: #666;"></span>'' ||',
'        ''</span>''',
'    ELSE '''' END ||',
'    ''<span class="country-name" id="card-title-'' || l_card_number || ''">'' || ',
'    nvl(l_custom_title, l_country_list) || ',
'    ''</span>'' ||',
'    ''</div>'' ||',
'    -- Status Indicator',
'    ''<span class="status-indicator '' || l_status || ''" '' || ',
'    ''title="'' || l_status_title || ''" '' || ',
'    ''data-card="'' || l_card_number || ''" '' || ',
'    ''onclick="cycleStatus('' || l_card_number || '')">'' ||',
'    l_status_icon ||',
'    ''</span>'' ||',
'    -- View button',
'    ''<span class="view-full-button" onclick="openDetailView('''''' || l_landids || '''''', '''''' || l_card_number || '''''')" '' ||',
unistr('    ''title="Detailansicht \00F6ffnen" style="cursor: pointer; margin: 0 8px; color: #bb0a31;">'' ||'),
'    ''<span class="fa fa-expand" style="font-size: 14px;"></span>'' ||',
'    ''</span>'' ||',
'    -- Download button',
'    ''<span class="download-icon" onclick="downloadCardData('''''' || l_landids || '''''')" '' ||',
'    ''title="Daten herunterladen">'' ||',
'    ''<span class="fa fa-download-alt" style="font-size: 14px;"></span>'' ||',
'    ''</span>'' ||',
'    ''</div>'' ||',
'    ''<div class="t-Report t-Report--altRowsDefault t-Report--rowHighlight">'' ||',
'    ''<div class="t-Report-wrap">'' ||',
'    -- Add the toggle row above the table headers with the Expand button',
'    ''<div class="toggle-header" style="display: flex; justify-content: space-between; align-items: center; padding: 8px 12px; background-color: #f5f5f5; border-bottom: 1px solid #e0e0e0;">'' ||',
'    ''<div class="toggle-count" style="display: inline-block;">'' || l_row_count || '' Vorschriften insgesamt</div>'' ||',
'    ''<div class="toggle-button" style="cursor: pointer; color: #bb0a31; display: inline-flex; align-items: center;">'' ||',
'    ''<span class="fa fa-expand" style="font-size: 14px; margin-right: 4px;"></span>'' ||',
'    ''<span class="toggle-text">Expand</span>'' ||',
'    ''</div>'' ||',
'    ''</div>'' ||',
'    ''<div class="t-Report-tableWrap">'' ||',
'    ''<table class="t-Report-report" style="width: 100%; table-layout: fixed;">'' ||',
'    ''<thead><tr>'' ||',
'    ''<th class="t-Report-colHead" align="left" style="width: 60%; padding: 12px 8px; height: 40px; text-align: center;">'' ||',
'    ''<span class="u-Report-sortHeading">Themabezeichnung</span>'' ||',
'    ''</th>'' ||',
'    ''<th class="t-Report-colHead" align="center" style="width: 40%; padding: 12px 8px; height: 40px; text-align: center;">'' ||',
'    ''<span class="u-Report-sortHeading">Vorschriftennummer</span>'' ||',
'    ''</th></tr></thead>'' ||',
'    ''<tbody>'' ||',
'    ''<div class="loaddata" searchid="'' || l_search_id || ''" milestone="'' || l_milestone || ''" landid="'' || l_landids || ''">'' ||',
'    ''</div>'' ||',
'    ''</tbody>'' ||',
'    ''</table></div></div></div>'';',
'    ',
'    -- Return HTML',
'    HTP.p(l_html);'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964325208323509420)
,p_process_sequence=>100
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_CARD_TITLE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_title VARCHAR2(200) := apex_application.g_x02;',
'    l_action VARCHAR2(20) := apex_application.g_x03;',
'    l_country_list CLOB;',
'    l_landids VARCHAR2(4000);',
'BEGIN',
'    -- Get the landids for this card to construct the original title',
'    BEGIN',
'        SELECT LISTAGG(landid, '':'') WITHIN GROUP (ORDER BY landid)',
'        INTO l_landids',
'        FROM t_ms_suche_split',
'        WHERE card_number = l_card_number',
'        AND ROWNUM = 1;',
'    ',
'        -- Get the original country list',
'        SELECT LISTAGG(l.B_NUMMER || '' - '' || l.LAND, ''; '') ',
'               WITHIN GROUP (ORDER BY l.B_NUMMER)',
'        INTO l_country_list',
'        FROM t_land l',
'        WHERE l.LANDID IN (',
'            SELECT TO_NUMBER(COLUMN_VALUE)',
'            FROM TABLE(apex_string.split(l_landids, '':''))',
'        );',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_country_list := '''';',
'    END;',
'    ',
'    -- Update title based on action',
'    IF l_action = ''RESET'' OR l_title IS NULL OR l_title = '''' THEN',
'        -- Reset to default - set to NULL',
'        UPDATE t_ms_suche_split',
'        SET custom_card_title = NULL',
'        WHERE card_number = l_card_number',
'        AND benutzerid = :G_BENUTZERID;',
'    ELSE',
'        -- Set to custom title',
'        UPDATE t_ms_suche_split',
'        SET custom_card_title = l_title',
'        WHERE card_number = l_card_number',
'        AND benutzerid = :G_BENUTZERID;',
'    END IF;',
'    ',
'    COMMIT;',
'    ',
'    -- JSON response',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
'    apex_json.write(''message'', ''Title updated successfully'');',
'    apex_json.write(''original_title'', l_country_list);',
'    apex_json.close_object;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Return error as JSON',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;     ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2707887107575878815
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_title VARCHAR2(200) := apex_application.g_x02;',
'BEGIN',
'    -- Update title',
'    UPDATE t_ms_suche_split',
'    SET custom_card_title = l_title',
'    WHERE card_number = l_card_number',
'    AND benutzerid = :G_BENUTZERID;',
'    ',
'    ',
'    -- JSON response',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
'    apex_json.write(''message'', ''Title updated successfully'');',
'    apex_json.close_object;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Return error as JSON',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;',
'        -- -- Roll back transaction',
'        -- ROLLBACK;',
'',
'        ',
'END;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964328376551509427)
,p_process_sequence=>110
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UPDATE_CARD_STATUS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_status VARCHAR2(20) := apex_application.g_x02;',
'    l_search_id NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_milestone NUMBER := TO_NUMBER(apex_application.g_x04);',
'BEGIN',
'    -- Update or insert status in the profile table',
'    MERGE INTO t_ms_card_status cs',
'    USING (SELECT :G_BENUTZERID as benutzerid, l_card_number as card_number, ',
'             l_search_id as sucheid, l_milestone as meilenstein FROM dual) src',
'    ON (cs.benutzerid = src.benutzerid AND cs.card_number = src.card_number ',
'        AND cs.sucheid = src.sucheid AND cs.meilenstein = src.meilenstein)',
'    WHEN MATCHED THEN',
'        UPDATE SET status = l_status, letzte_aenderung_datum = SYSDATE',
'    WHEN NOT MATCHED THEN',
'        INSERT (benutzerid, card_number, sucheid, meilenstein, status, erstelldatum, letzte_aenderung_datum)',
'        VALUES (src.benutzerid, src.card_number, src.sucheid, src.meilenstein, ',
'                l_status, SYSDATE, SYSDATE);',
'                ',
'    -- Set local page variables to ensure proper UI update',
'    :P460_JUST_UPDATED_CARD := l_card_number;',
'    :P460_JUST_UPDATED_STATUS := l_status;',
'                ',
'    -- Return success response',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
'    apex_json.write(''message'', ''Status updated successfully'');',
'    apex_json.close_object;',
'                ',
'    COMMIT;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Return error response',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;',
'        ',
'        ROLLBACK;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2707883939347878808
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_status VARCHAR2(20) := apex_application.g_x02;',
'    l_search_id NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_milestone NUMBER := TO_NUMBER(apex_application.g_x04);',
'BEGIN',
'    -- Update or insert status in the profile table',
'    MERGE INTO t_ms_card_status cs',
'    USING (SELECT :G_BENUTZERID as benutzerid, l_card_number as card_number, ',
'                 l_search_id as sucheid, l_milestone as meilenstein FROM dual) src',
'    ON (cs.benutzerid = src.benutzerid AND cs.card_number = src.card_number ',
'        AND cs.sucheid = src.sucheid AND cs.meilenstein = src.meilenstein)',
'    WHEN MATCHED THEN',
'        UPDATE SET status = l_status, letzte_aenderung_datum = SYSDATE',
'    WHEN NOT MATCHED THEN',
'        INSERT (benutzerid, card_number, sucheid, meilenstein, status, erstelldatum, letzte_aenderung_datum)',
'        VALUES (src.benutzerid, src.card_number, src.sucheid, src.meilenstein, ',
'                l_status, SYSDATE, SYSDATE);',
'                ',
'    -- Return success response',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
'    apex_json.write(''message'', ''Status updated successfully'');',
'    apex_json.close_object;',
'                ',
'    COMMIT;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Return error response',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;',
'        ',
'        ROLLBACK;',
'END;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964324375431509419)
,p_process_sequence=>120
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RESTORE_SAVED_CARDS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_countries VARCHAR2(4000) := apex_application.g_x01;',
'    l_card_numbers VARCHAR2(4000) := apex_application.g_x02;',
'    l_search_id NUMBER;',
'    l_milestone NUMBER;',
'    ',
'    -- Arrays to hold split strings',
'    l_country_array apex_t_varchar2;',
'    l_card_array apex_t_varchar2;',
'    ',
'    -- Variables for assigning countries to cards',
'    l_country_per_card NUMBER;',
'    l_country_index NUMBER := 1;',
'BEGIN',
'    -- Validate inputs',
'    IF l_card_countries IS NULL OR l_card_numbers IS NULL THEN',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', ''Missing required card data'');',
'        apex_json.close_object;',
'        RETURN;',
'    END IF;',
'',
'    -- Convert string parameters to numbers with error handling',
'    BEGIN',
'        l_search_id := TO_NUMBER(apex_application.g_x03);',
'        l_milestone := TO_NUMBER(apex_application.g_x04);',
'    EXCEPTION ',
'        WHEN VALUE_ERROR THEN',
'            apex_json.open_object;',
'            apex_json.write(''status'', ''error'');',
'            apex_json.write(''message'', ''Invalid search ID or milestone value'');',
'            apex_json.close_object;',
'            RETURN;',
'    END;',
'    ',
'    -- Log start',
'    DEBUG(''RESTORE_CARDS Start'', ''Countries: '' || l_card_countries);',
'    DEBUG(''RESTORE_CARDS Parameters'', ''Card Numbers: '' || l_card_numbers || '', Search: '' || l_search_id || '', Milestone: '' || l_milestone);',
'    ',
'    -- Delete existing cards',
'    DELETE FROM t_ms_suche_split ',
'    WHERE sucheid = l_search_id ',
'    AND meilenstein = l_milestone',
'    AND benutzerid = :G_BENUTZERID;',
'    ',
'    DEBUG(''RESTORE_CARDS'', ''Deleted existing cards: '' || SQL%ROWCOUNT);',
'    ',
'    -- Split strings into arrays',
'    l_country_array := apex_string.split(l_card_countries, '':'');',
'    l_card_array := apex_string.split(l_card_numbers, '':'');',
'    ',
'    -- Validate array data',
'    IF l_country_array.count = 0 OR l_card_array.count = 0 THEN',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', ''No valid countries or card numbers found in input'');',
'        apex_json.close_object;',
'        RETURN;',
'    END IF;',
'    ',
'    -- Calculate how many countries should go to each card (evenly distributed)',
'    l_country_per_card := CEIL(l_country_array.count / l_card_array.count);',
'    DEBUG(''RESTORE_CARDS'', ''Countries per card: '' || l_country_per_card);',
'    ',
'    -- Process each card',
'    FOR i IN 1..l_card_array.count LOOP',
'        DEBUG(''RESTORE_CARDS Process'', ''Processing card: '' || l_card_array(i) || '', row: '' || i);',
'        ',
'        -- Get countries for this card (evenly distributed)',
'        FOR j IN 1..l_country_per_card LOOP',
'            IF l_country_index <= l_country_array.count THEN',
'                -- Insert this country for this card',
'                DEBUG(''RESTORE_CARDS Country'', ''Adding landid: '' || l_country_array(l_country_index) || '' to card: '' || l_card_array(i));',
'                ',
'                BEGIN',
'                    INSERT INTO t_ms_suche_split (',
'                        sucheid, ',
'                        meilenstein, ',
'                        card_number, ',
'                        landid, ',
'                        benutzerid, ',
'                        letzte_aenderung_datum, ',
'                        letzte_aenderung_benutzerid',
'                    ) VALUES (',
'                        l_search_id, ',
'                        l_milestone, ',
'                        TO_NUMBER(l_card_array(i)), ',
'                        TO_NUMBER(l_country_array(l_country_index)), ',
'                        :G_BENUTZERID, ',
'                        SYSDATE, ',
'                        :G_BENUTZERID',
'                    );',
'                    ',
'                    DEBUG(''RESTORE_CARDS Insert'', ''Success for landid: '' || l_country_array(l_country_index) || '', card: '' || l_card_array(i));',
'                EXCEPTION',
'                    WHEN OTHERS THEN',
'                        DEBUG(''RESTORE_CARDS Error'', ''Error on insert: '' || SQLERRM);',
'                END;',
'                ',
'                -- Move to next country',
'                l_country_index := l_country_index + 1;',
'            END IF;',
'        END LOOP;',
'    END LOOP;',
'    ',
'    COMMIT;',
'    DEBUG(''RESTORE_CARDS End'', ''Completed successfully'');',
'    ',
'    -- Return success JSON response',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
'    apex_json.write(''message'', ''Cards restored successfully'');',
'    apex_json.write(''cards_count'', l_card_array.count);',
'    apex_json.write(''countries_count'', l_country_array.count);',
'    apex_json.close_object;',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Log error',
'        DEBUG(''RESTORE_CARDS Fatal'', ''Error: '' || SQLERRM);',
'        ',
'        -- Rollback',
'        ROLLBACK;',
'        ',
'        -- Return error JSON',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', ''Error: '' || SQLERRM);',
'        apex_json.write(''error_backtrace'', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);',
'        apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2707887940467878816
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_countries VARCHAR2(4000) := apex_application.g_x01;',
'    l_card_numbers VARCHAR2(4000) := apex_application.g_x02;',
'    l_search_id NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_milestone NUMBER := TO_NUMBER(apex_application.g_x04);',
'    l_card_number NUMBER;',
'BEGIN',
'    -- Loop through card numbers',
'    FOR i IN (',
'        SELECT ',
'            column_value AS card_num,',
'            ROWNUM AS rn',
'        FROM TABLE(apex_string.split(l_card_numbers, '':''))',
'    ) LOOP',
'        l_card_number := TO_NUMBER(i.card_num);',
'        ',
'        -- For each country in this card',
'        FOR c IN (',
'            SELECT ',
'                column_value AS landid,',
'                i.rn AS card_index',
'            FROM TABLE(apex_string.split(l_card_countries, '':''))',
'            WHERE MOD(ROWNUM, LENGTH(l_card_numbers) - LENGTH(REPLACE(l_card_numbers, '':'', '''')) + 1) = ',
'                  MOD(i.rn - 1, LENGTH(l_card_numbers) - LENGTH(REPLACE(l_card_numbers, '':'', '''')) + 1)',
'        ) LOOP',
'            -- Insert record for this card and country',
'            INSERT INTO t_ms_suche_split (',
'                sucheid,',
'                meilenstein,',
'                card_number,',
'                landid,',
'                BENUTZERID,',
'                letzte_aenderung_datum,',
'                letzte_aenderung_benutzerid',
'            ) VALUES (',
'                l_search_id,',
'                l_milestone,',
'                l_card_number,',
'                TO_NUMBER(c.landid),',
'                :G_BENUTZERID,',
'                SYSDATE,',
'                :G_BENUTZERID',
'            );',
'        END LOOP;',
'    END LOOP;',
'    ',
'    COMMIT;',
'    ',
'    -- Return success response',
'    apex_json.open_object;',
'    apex_json.write(''status'', ''success'');',
'    apex_json.write(''message'', ''Cards restored successfully'');',
'    apex_json.close_object;',
'    ',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Return error response',
'        apex_json.open_object;',
'        apex_json.write(''status'', ''error'');',
'        apex_json.write(''message'', SQLERRM);',
'        apex_json.close_object;',
'        ROLLBACK;',
'END;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(964323531327509418)
,p_process_sequence=>130
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_CURRENT_CARD_STATUS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_card_number NUMBER := TO_NUMBER(apex_application.g_x01);',
'    l_search_id NUMBER := TO_NUMBER(apex_application.g_x02);',
'    l_milestone NUMBER := TO_NUMBER(apex_application.g_x03);',
'    l_status VARCHAR2(20) := ''not-started'';',
'BEGIN',
'    -- Get status from database',
'    BEGIN',
'        SELECT status INTO l_status',
'        FROM t_ms_card_status',
'        WHERE benutzerid = :G_BENUTZERID',
'        AND card_number = l_card_number',
'        AND sucheid = l_search_id',
'        AND meilenstein = l_milestone;',
'        ',
'        -- Debug for troubleshooting',
'        apex_debug.info(''Status found for card %s: %s'', l_card_number, l_status);',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            l_status := ''not-started'';',
'            apex_debug.info(''No status found for card %s, using default: %s'', l_card_number, l_status);',
'    END;',
'    ',
'    -- Return as JSON',
'    apex_json.open_object;',
'    apex_json.write(''status'', l_status);',
'    apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2707888784571878817
);
wwv_flow_imp.component_end;
end;
/
