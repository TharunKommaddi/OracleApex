prompt --application/user_interfaces
begin
--   Manifest
--     USER INTERFACES: 120
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_user_interface(
 p_id=>wwv_flow_imp.id(3672212315899388115)
,p_theme_id=>42
,p_home_url=>'f?p=&APP_ID.:202:&SESSION.'
,p_login_url=>'f?p=&APP_ID.:LOGIN_DESKTOP:&SESSION.'
,p_theme_style_by_user_pref=>false
,p_built_with_love=>false
,p_global_page_id=>0
,p_navigation_list_id=>wwv_flow_imp.id(3414107444680820531)
,p_navigation_list_position=>'SIDE'
,p_navigation_list_template_id=>wwv_flow_imp.id(3414142062615820564)
,p_nav_list_template_options=>'#DEFAULT#'
,p_javascript_file_urls=>'#APP_IMAGES#regindex.js'
,p_include_legacy_javascript=>'18'
,p_include_jquery_migrate=>true
,p_nav_bar_type=>'LIST'
,p_nav_bar_list_id=>wwv_flow_imp.id(3414149819795820577)
,p_nav_bar_list_template_id=>wwv_flow_imp.id(2666542910922482649)
,p_nav_bar_template_options=>'#DEFAULT#'
);
wwv_flow_imp.component_end;
end;
/
