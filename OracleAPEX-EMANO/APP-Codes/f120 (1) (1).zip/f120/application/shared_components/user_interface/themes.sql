prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 120
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(3414145786015820574)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_version_identifier=>'1.2'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_current_theme_style_id=>wwv_flow_imp.id(3414154667717873899)
,p_default_page_template=>wwv_flow_imp.id(3414112865087820538)
,p_default_dialog_template=>wwv_flow_imp.id(3414111602455820538)
,p_error_template=>wwv_flow_imp.id(3414109515918820536)
,p_printer_friendly_template=>wwv_flow_imp.id(3414112865087820538)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(3414109515918820536)
,p_default_button_template=>wwv_flow_imp.id(3414144722843820567)
,p_default_region_template=>wwv_flow_imp.id(3414123643808820547)
,p_default_chart_template=>wwv_flow_imp.id(3414123643808820547)
,p_default_form_template=>wwv_flow_imp.id(3414123643808820547)
,p_default_reportr_template=>wwv_flow_imp.id(3414123643808820547)
,p_default_tabform_template=>wwv_flow_imp.id(3414123643808820547)
,p_default_wizard_template=>wwv_flow_imp.id(3414123643808820547)
,p_default_menur_template=>wwv_flow_imp.id(3414126953447820548)
,p_default_listr_template=>wwv_flow_imp.id(3414123643808820547)
,p_default_irr_template=>wwv_flow_imp.id(3414123142457820547)
,p_default_report_template=>wwv_flow_imp.id(3414132514175820554)
,p_default_label_template=>wwv_flow_imp.id(3414144209519820566)
,p_default_menu_template=>wwv_flow_imp.id(3414145144550820567)
,p_default_calendar_template=>wwv_flow_imp.id(3414145281370820568)
,p_default_list_template=>wwv_flow_imp.id(3414139656742820562)
,p_default_nav_list_template=>wwv_flow_imp.id(3414143135747820565)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(3414143135747820565)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(3414142062615820564)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(3414115701564820543)
,p_default_dialogr_template=>wwv_flow_imp.id(3414115547641820543)
,p_default_option_label=>wwv_flow_imp.id(3414144209519820566)
,p_default_required_label=>wwv_flow_imp.id(3414144407257820566)
,p_default_navbar_list_template=>wwv_flow_imp.id(2666542910922482649)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#IMAGE_PREFIX#themes/theme_42/1.2/')
,p_files_version=>101
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_IMAGES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
