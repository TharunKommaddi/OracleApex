prompt --application/shared_components/user_interface/lovs/lov_rev_notwendig
begin
--   Manifest
--     LOV_REV_NOTWENDIG
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(646432047862271176)
,p_lov_name=>'LOV_REV_NOTWENDIG'
,p_lov_query=>'.'||wwv_flow_imp.id(646432047862271176)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(646431807625271143)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Nicht bewertet'
,p_lov_return_value=>'10'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(646431425586271140)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Ja'
,p_lov_return_value=>'20'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(646430995736271140)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Nein'
,p_lov_return_value=>'30'
);
wwv_flow_imp.component_end;
end;
/
