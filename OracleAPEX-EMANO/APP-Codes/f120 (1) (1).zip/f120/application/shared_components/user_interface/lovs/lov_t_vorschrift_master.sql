prompt --application/shared_components/user_interface/lovs/lov_t_vorschrift_master
begin
--   Manifest
--     LOV_T_VORSCHRIFT.MASTER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(1019194795775238322)
,p_lov_name=>'LOV_T_VORSCHRIFT.MASTER'
,p_lov_query=>'.'||wwv_flow_imp.id(1019194795775238322)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1019194360830238312)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('Master in GETEX + automatische \00DCbernahme')
,p_lov_return_value=>'30'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1019194010477238294)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Master in GETEX'
,p_lov_return_value=>'20'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1019193541500238294)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Master in RegIndex'
,p_lov_return_value=>'10'
);
wwv_flow_imp.component_end;
end;
/
