prompt --application/shared_components/user_interface/lovs/lov_cocoa
begin
--   Manifest
--     LOV_COCOA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(983775321622566064)
,p_lov_name=>'LOV_COCOA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH cte1 AS (',
'    SELECT ',
'        t.JIRA_ISSUE_KEY,',
'        x.*',
'    FROM t_x_cocoa_import t,',
'    JSON_TABLE(',
'        t.DATA_CLOB, ''$.fields''',
'        COLUMNS (',
'            full_description VARCHAR2(4000) PATH ''$.description'',',
'            summary VARCHAR2(4000) PATH ''$.summary'',',
'            issue_type_desc VARCHAR2(500) PATH ''$.issuetype.description'',',
'            cluster_value VARCHAR2(500) PATH ''$.customfield_53150[0].value''',
'        )',
'    ) x',
'    WHERE t.JIRA_GET_STATUS = 20',
'), ',
'cte2 AS (',
'    SELECT ',
'        JIRA_ISSUE_KEY,',
'        summary,',
'        issue_type_desc,',
'        cluster_value,',
'        CASE ',
'            WHEN full_description LIKE ''%[%|%]%'' THEN',
'                substr(',
'                    substr(full_description, instr(full_description,''['')+1, ',
'                           instr(full_description,'']'')-(instr(full_description,''['')+1)),',
'                    instr(',
'                        substr(full_description, instr(full_description,''['')+1, ',
'                               instr(full_description,'']'')-(instr(full_description,''['')+1)),',
'                        ''|''',
'                    )+1',
'                )',
'            ELSE NULL',
'        END as extracted_url',
'    FROM cte1',
'), ',
'cte3 AS (',
'    SELECT ',
'        jira_issue_key,',
'        summary,',
'        issue_type_desc,',
'        cluster_value,',
'        CASE ',
'            WHEN extracted_url IS NOT NULL AND INSTR(extracted_url, ''/revision/'') > 0 THEN',
'                substr(extracted_url, 0, instr(extracted_url,''/revision/''))',
'            ELSE NULL',
'        END as getex_link_jira',
'    FROM cte2',
'),',
'cte4 AS (',
'    SELECT ',
'        t3.jira_issue_key,',
'        t3.summary,',
'        t3.issue_type_desc,',
'        t3.cluster_value,',
'        t3.getex_link_jira,',
'        CASE WHEN tv.url_getex_vorschrift IS NOT NULL THEN 1 ELSE NULL END as is_linked',
'    FROM cte3 t3',
'    LEFT JOIN t_vorschrift tv ON (',
'        tv.url_getex_vorschrift = t3.getex_link_jira ',
'        AND tv.vorschriftid = :P25_VORSCHRIFTID',
'    )',
')',
'SELECT ',
'    c4.jira_issue_key as d,',
'    c4.summary as d2,',
'    NVL(c4.issue_type_desc, ''No Issue Type'') as d3,',
'    NVL(c4.cluster_value, ''No Cluster'') as d4,',
'    c4.jira_issue_key as r',
'FROM cte4 c4',
'WHERE ',
'    :P582_AUSWAHL = ''all'' ',
'    OR (:P582_AUSWAHL = ''filtered'' AND c4.is_linked = 1)',
'ORDER BY ',
'    c4.is_linked DESC NULLS LAST,',
'    c4.jira_issue_key;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(983773264422555422)
,p_query_column_name=>'R'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(983774088279555422)
,p_query_column_name=>'D'
,p_heading=>'Ticketnummer'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(983773701213555422)
,p_query_column_name=>'D2'
,p_heading=>'Summary'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(967153284176653443)
,p_query_column_name=>'D3'
,p_heading=>'Issue Type'
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(967152901431653443)
,p_query_column_name=>'D4'
,p_heading=>'Cluster'
,p_display_sequence=>50
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
