prompt --application/shared_components/user_interface/lovs/lov_arbeitskreis
begin
--   Manifest
--     LOV_ARBEITSKREIS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(864452481913721779)
,p_lov_name=>'LOV_ARBEITSKREIS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
' SELECT ',
'    ET_B_AKID, ',
'    kurz, ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN Bezeichnung',
'        ELSE name_eng',
'    END AS name',
'FROM T_ET_B_AK ',
'WHERE ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN Bezeichnung',
'        ELSE name_eng',
'    END NOT IN ',
'    (',
'        CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''Administratoren'' ELSE ''Administrators'' END,',
'        CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN ''Redaktionsteam'' ELSE ''Editorial Team'' END',
'    );',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'T_ET_B_AK'
,p_return_column_name=>'ET_B_AKID'
,p_display_column_name=>'NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'KURZ'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(943352986642305955)
,p_query_column_name=>'ET_B_AKID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(943352565418305955)
,p_query_column_name=>'KURZ'
,p_heading=>'Kurz'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(943352219103305955)
,p_query_column_name=>'NAME'
,p_heading=>'Name'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
