prompt --application/shared_components/user_interface/lovs/lov_vorschrift_status
begin
--   Manifest
--     LOV_VORSCHRIFT_STATUS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(2490458092659806028)
,p_lov_name=>'LOV_VORSCHRIFT_STATUS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select Status as d,',
'       Vorschrift_statusid as r',
'  from T_vorschrift_status',
' order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
