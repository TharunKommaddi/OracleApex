prompt --application/shared_components/user_interface/lovs/lov_vorschrift_beziehung_art
begin
--   Manifest
--     LOV_VORSCHRIFT_BEZIEHUNG_ART
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(2655378917409322525)
,p_lov_name=>'LOV_VORSCHRIFT_BEZIEHUNG_ART'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select BEZIEHUNG_ART as d,',
'       BEZIEHUNG_ARTID as r',
'  from T_BEZIEHUNG_ART',
'  where beziehung_artid != 30',
' order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
