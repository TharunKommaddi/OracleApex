prompt --application/shared_components/user_interface/lovs/lov_notation
begin
--   Manifest
--     LOV_NOTATION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(936366540557201430)
,p_lov_name=>'LOV_NOTATION'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cte_la as (',
'    select ',
'        normid,',
'        nvl(listagg(trim(la.b_nummer), '', '') within group (order by la.b_nummer),null) as laender_nummer,',
'        nvl(listagg(trim(CASE WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN la.LAND ELSE la.LAND_ENG END), '', '') within group (order by la.LAND),null) as laender_name',
'    from t_norm_ref_land nrl',
'    left outer join t_land la on nrl.landid = la.landid',
'    group by normid',
')',
'select ',
'    n.normid, ',
'    n.bezeichnung "BEZEICHNUNG",',
'    cte_la.laender_nummer "B_NUMMER",',
'    cte_la.laender_name "LAND"',
'from "#OWNER#"."T_NORM" n',
'left outer join cte_la on cte_la.normid = n.normid',
'where n.normid not in (1016)',
'order by n.BEZEICHNUNG asc;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_owner=>'CARMAH2_ADMIN'
,p_return_column_name=>'NORMID'
,p_display_column_name=>'BEZEICHNUNG'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(936366067740197467)
,p_query_column_name=>'NORMID'
,p_display_sequence=>1
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(936365644569197465)
,p_query_column_name=>'BEZEICHNUNG'
,p_heading=>'Bezeichnung'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(936327321434581637)
,p_query_column_name=>'B_NUMMER'
,p_heading=>'B Nummer'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(936329956086598934)
,p_query_column_name=>'LAND'
,p_heading=>'Land'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
