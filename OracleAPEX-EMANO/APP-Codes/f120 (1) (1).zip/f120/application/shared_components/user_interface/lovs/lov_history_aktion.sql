prompt --application/shared_components/user_interface/lovs/lov_history_aktion
begin
--   Manifest
--     LOV_HISTORY_AKTION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(958145941627486314)
,p_lov_name=>'LOV_HISTORY_AKTION'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    display_value,',
'    actual_value',
'FROM (',
'    SELECT',
'        emano_util.fLang(''fa-database-x'', ''fa-database-x'') AS display_value,',
'        0 AS actual_value,',
'        1 AS sort_order',
'    FROM dual',
'',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''fa-database-new'', ''fa-database-new'') AS display_value,',
'        10 AS actual_value,',
'        2 AS sort_order',
'    FROM dual',
'    ',
'    UNION ALL',
'',
'    SELECT ',
'        emano_util.fLang(''fa-database-edit'', ''fa-database-edit'') AS display_value,',
'        20 AS actual_value,',
'        3 AS sort_order',
'    FROM dual',
')',
'ORDER BY sort_order;',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_query_owner=>'CARMAH2_ADMIN'
,p_return_column_name=>'ACTUAL_VALUE'
,p_display_column_name=>'DISPLAY_VALUE'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
