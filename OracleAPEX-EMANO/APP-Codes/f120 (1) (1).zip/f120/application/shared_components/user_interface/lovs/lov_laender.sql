prompt --application/shared_components/user_interface/lovs/lov_laender
begin
--   Manifest
--     LOV_LAENDER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(301033789677752359)
,p_lov_name=>'LOV_LAENDER'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH cte1 AS (',
'    SELECT ',
'        l.b_nummer || '' - '' || ',
'        emano_util.fLang(land,land_eng) || '' ('' || count(irl.importeurid) || '')'' AS d, ',
'        l.b_nummer, ',
'        CASE ',
'            WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN l.land',
'            ELSE l.land_eng ',
'        END AS LandName, ',
'        l.landid',
'    FROM ',
'        t_land l',
'        JOIN t_importeur_ref_land irl ON (l.landid = irl.landid)',
'        JOIN t_importeur i ON (irl.importeurid = i.importeurid AND i.is_deleted = 0)',
'    WHERE ',
'        l.status_datenstand = 10',
'    GROUP BY ',
'        l.landid, l.b_nummer, ',
'        land, land_eng',
')',
'',
'SELECT cte1.*, flagge',
'FROM cte1',
'JOIN t_land l ON (l.landid = cte1.landid)',
'ORDER BY NLSSORT(cte1.B_NUMMER, ''NLS_SORT=BINARY_AI'') ASC',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'T_LAND'
,p_return_column_name=>'LANDID'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
