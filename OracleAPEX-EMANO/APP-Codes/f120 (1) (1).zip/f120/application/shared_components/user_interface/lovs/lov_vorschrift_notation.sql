prompt --application/shared_components/user_interface/lovs/lov_vorschrift_notation
begin
--   Manifest
--     LOV_VORSCHRIFT_NOTATION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(697941437682634362)
,p_lov_name=>'LOV_VORSCHRIFT_NOTATION'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung, normid, beispiel',
'from t_norm n',
'order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'NORMID'
,p_display_column_name=>'BEZEICHNUNG'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(697940944471630933)
,p_query_column_name=>'NORMID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(697940602847630932)
,p_query_column_name=>'BEZEICHNUNG'
,p_heading=>'Bezeichnung'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(697940140592630932)
,p_query_column_name=>'BEISPIEL'
,p_heading=>'Beispiel'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
