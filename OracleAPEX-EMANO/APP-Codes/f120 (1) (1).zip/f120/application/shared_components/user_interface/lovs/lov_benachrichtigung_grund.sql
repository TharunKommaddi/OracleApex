prompt --application/shared_components/user_interface/lovs/lov_benachrichtigung_grund
begin
--   Manifest
--     LOV_BENACHRICHTIGUNG_GRUND
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(619924812765862105)
,p_lov_name=>'LOV_BENACHRICHTIGUNG_GRUND'
,p_lov_query=>'.'||wwv_flow_imp.id(619924812765862105)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(619924533126862070)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'SW-Relevanz'
,p_lov_return_value=>'10'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(619924073184862068)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Norm ohne Validierung'
,p_lov_return_value=>'20'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(619923703542862068)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'automatisierte In-Kraft-Setzung'
,p_lov_return_value=>'30'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(619923299276862068)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'manuell'
,p_lov_return_value=>'40'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(476179572071734410)
,p_lov_disp_sequence=>14
,p_lov_disp_value=>unistr('automatisiertes L\00F6schen in 4 Wochen')
,p_lov_return_value=>'50'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(476179246063715214)
,p_lov_disp_sequence=>24
,p_lov_disp_value=>'Fremdarbeitskreisvergabe'
,p_lov_return_value=>'60'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(476179006153701078)
,p_lov_disp_sequence=>34
,p_lov_disp_value=>unistr('Vorschrift\00E4nderung')
,p_lov_return_value=>'70'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(476178673284679664)
,p_lov_disp_sequence=>44
,p_lov_disp_value=>unistr('MfV G\00FCltigkeitsdatum in der Vergangenheit')
,p_lov_return_value=>'80'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(378791733096071160)
,p_lov_disp_sequence=>54
,p_lov_disp_value=>unistr('Vorschrift gel\00F6scht')
,p_lov_return_value=>'90'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(358514533778986136)
,p_lov_disp_sequence=>64
,p_lov_disp_value=>'Einsatzdatum fehlt'
,p_lov_return_value=>'100'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(993833115761655101)
,p_lov_disp_sequence=>74
,p_lov_disp_value=>'Status gewechselt'
,p_lov_return_value=>'110'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(993832701504645460)
,p_lov_disp_sequence=>84
,p_lov_disp_value=>unistr('Themen Differenz zum Vorg\00E4nger/ Nachfolger')
,p_lov_return_value=>'120'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(868349901395020010)
,p_lov_disp_sequence=>94
,p_lov_disp_value=>unistr('Benutzer zur Arbeitsgruppe hinzugef\00FCgt')
,p_lov_return_value=>'130'
);
wwv_flow_imp.component_end;
end;
/
