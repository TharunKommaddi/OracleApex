prompt --application/shared_components/user_interface/lovs/lov_vorgaenger_nachfolger
begin
--   Manifest
--     LOV_VORGAENGER_NACHFOLGER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(694202809530357733)
,p_lov_name=>'LOV_VORGAENGER_NACHFOLGER'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH cte_vorschriften_info AS (',
'    SELECT',
'        v.vorschriftid,',
'        v.vorschrift_nummer AS Vorschriftennummer,',
'        --v.vorschrift_bezeichnung  AS Titel,',
'        v.dokumentendatum AS Dokumentendatum,',
'       -- vrv.datum_in_kraft AS Inkraftsetzungsdatum',
'        to_char(vre.einsatzdatum, ''DD.MM.YYYY'') AS Inkraftsetzungsdatum',
'    FROM',
'        t_vorschrift v',
'    LEFT OUTER JOIN',
'        --t_vorschrift_ref_vorschrift vrv ON v.vorschriftid = vrv.VORGAENGER_VORSCHRIFTID --v.vorschriftid = vrv.VORSCHRIFT_REF_VORSCHRIFTID',
'        t_vorschrift_ref_einsatzdatum_typ vre ON (vre.vorschriftid = v.vorschriftid ',
'                                             and vre.einsatzdatum_typid = 1000 )',
')',
'',
'SELECT',
'    c.vorschriftid,',
'    c.Vorschriftennummer,',
'    --c.Titel,',
'    c.Dokumentendatum,',
'    c.Inkraftsetzungsdatum',
'FROM',
'    cte_vorschriften_info c',
'ORDER BY 1;',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'VORSCHRIFTID'
,p_display_column_name=>'VORSCHRIFTENNUMMER'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(694156395925798606)
,p_query_column_name=>'VORSCHRIFTENNUMMER'
,p_heading=>'Vorschriftennummer'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(694155980956798606)
,p_query_column_name=>'VORSCHRIFTID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(694157192393798607)
,p_query_column_name=>'DOKUMENTENDATUM'
,p_heading=>'Dokumentendatum'
,p_display_sequence=>20
,p_data_type=>'DATE'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(694156761965798606)
,p_query_column_name=>'INKRAFTSETZUNGSDATUM'
,p_heading=>'Inkraftsetzungsdatum'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
