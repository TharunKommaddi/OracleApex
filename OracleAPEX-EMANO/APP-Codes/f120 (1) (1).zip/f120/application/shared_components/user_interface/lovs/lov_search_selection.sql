prompt --application/shared_components/user_interface/lovs/lov_search_selection
begin
--   Manifest
--     LOV_SEARCH_SELECTION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(983436421153177291)
,p_lov_name=>'LOV_SEARCH_SELECTION'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH pri_user_check AS (',
'    SELECT 1 AS is_pri_user',
'    FROM t_benutzer_ref_rolle',
'    WHERE benutzerid = :G_BENUTZERID',
'      AND rolleid = 1001 -- Role ID for PRI User',
'      AND ROWNUM = 1',
')',
'SELECT',
'    tsj.sucheid AS sucheid,                        -- First column: Search ID',
'    tsj.bezeichnung AS d,                          -- Second column: Search Name',
'    tsj.sucheid AS r,                              -- Return value',
'    b.nachname || '', '' || b.vorname AS benutzer,',
'    TO_CHAR(tsj.zeitpunkt, ''DD.MM.YYYY HH24:MI'') AS zeitpunkt',
'FROM',
'    t_suche_json tsj',
'JOIN',
'    t_benutzer b ON tsj.benutzerid = b.benutzerid',
'WHERE',
'    tsj.manuelle_speicherung > 0  -- Greater than 0 (includes both 1 and 10)',
'    AND (',
'        (SELECT NVL(is_pri_user, 0) FROM pri_user_check) = 1',
'        OR',
'        tsj.benutzerid = :G_BENUTZERID',
'    )',
'ORDER BY',
'    tsj.zeitpunkt DESC'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_owner=>'CARMAH2_ADMIN'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(983429806141134543)
,p_query_column_name=>'R'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(983415493415070997)
,p_query_column_name=>'D'
,p_heading=>'Name der Suche'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(947580214049404919)
,p_query_column_name=>'SUCHEID'
,p_heading=>'Sucheid'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(983428953804134542)
,p_query_column_name=>'BENUTZER'
,p_heading=>'Benutzer'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(983428534845134541)
,p_query_column_name=>'ZEITPUNKT'
,p_heading=>'Zeitpunkt'
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
