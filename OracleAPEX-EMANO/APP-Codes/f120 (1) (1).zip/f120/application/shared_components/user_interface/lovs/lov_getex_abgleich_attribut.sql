prompt --application/shared_components/user_interface/lovs/lov_getex_abgleich_attribut
begin
--   Manifest
--     LOV_GETEX_ABGLEICH_ATTRIBUT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(739407984509553661)
,p_lov_name=>'LOV_GETEX_ABGLEICH_ATTRIBUT'
,p_lov_query=>'.'||wwv_flow_imp.id(739407984509553661)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(739407644639553650)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'identisch'
,p_lov_return_value=>'0'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(739407262335553648)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'abweichend'
,p_lov_return_value=>'1'
);
wwv_flow_imp.component_end;
end;
/
