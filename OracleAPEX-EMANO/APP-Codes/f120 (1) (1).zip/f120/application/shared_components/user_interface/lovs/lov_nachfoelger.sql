prompt --application/shared_components/user_interface/lovs/lov_nachfoelger
begin
--   Manifest
--     LOV_NACHFOELGER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(694187650551187352)
,p_lov_name=>'LOV_NACHFOELGER'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH cte_vorschriften_info AS (',
'    SELECT',
'        v.vorschriftid,',
'        v.vorschrift_nummer AS Vorschriftennummer,',
'        --v.vorschrift_bezeichnung  AS Titel,',
'        v.dokumentendatum AS Dokumentendatum,',
'        vrv.datum_in_kraft AS Inkraftsetzungsdatum',
'    FROM',
'        t_vorschrift v',
'    JOIN',
'        t_vorschrift_ref_vorschrift vrv ON v.vorschriftid = vrv.NACHFOLGER_VORSCHRIFTID --v.vorschriftid = vrv.VORSCHRIFT_REF_VORSCHRIFTID',
')',
'',
'SELECT',
'    c.vorschriftid,',
'    c.Vorschriftennummer,',
'    --c.Titel,',
'    c.Dokumentendatum,',
'    c.Inkraftsetzungsdatum',
'FROM',
'    cte_vorschriften_info c',
'ORDER BY 1;',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_owner=>'CARMAH2_ADMIN'
,p_return_column_name=>'VORSCHRIFTID'
,p_display_column_name=>'VORSCHRIFTENNUMMER'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
