prompt --application/shared_components/user_interface/lovs/lov_import_status_getzex
begin
--   Manifest
--     LOV_IMPORT_STATUS_GETZEX
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(799385323802234434)
,p_lov_name=>'LOV_IMPORT_STATUS_GETZEX'
,p_lov_query=>'.'||wwv_flow_imp.id(799385323802234434)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(799385012900234429)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'aktuell'
,p_lov_return_value=>'10'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(799384544933234428)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'nicht aktuell'
,p_lov_return_value=>'20'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(799384144475234427)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'kein Match zu GETEX'
,p_lov_return_value=>'30'
);
wwv_flow_imp.component_end;
end;
/
