prompt --application/shared_components/user_interface/lovs/lov_vorschrift_detail
begin
--   Manifest
--     LOV_VORSCHRIFT_DETAIL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(808793069799008182)
,p_lov_name=>'LOV_VORSCHRIFT_DETAIL'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'T_VORSCHRIFT'
,p_return_column_name=>'VORSCHRIFTID'
,p_display_column_name=>'VORSCHRIFT_NUMMER'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'VORSCHRIFT_NUMMER'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(442732884474877258)
,p_query_column_name=>'VORSCHRIFTID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(442732493252877258)
,p_query_column_name=>'VORSCHRIFT_NUMMER'
,p_heading=>'Vorschrift Nummer'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(1032287447742920698)
,p_query_column_name=>'DOKUMENTENDATUM'
,p_heading=>'Dokumentendatum'
,p_display_sequence=>25
,p_data_type=>'DATE'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(442732114743877258)
,p_query_column_name=>'VORSCHRIFT_BEZEICHNUNG'
,p_heading=>'Vorschrift Bezeichnung'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
