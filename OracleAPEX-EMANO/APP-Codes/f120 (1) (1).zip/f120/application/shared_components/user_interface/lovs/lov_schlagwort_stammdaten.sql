prompt --application/shared_components/user_interface/lovs/lov_schlagwort_stammdaten
begin
--   Manifest
--     LOV_SCHLAGWORT_STAMMDATEN
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(757927504411982072)
,p_lov_name=>'LOV_SCHLAGWORT_STAMMDATEN'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT stext as Schlagwort, SCHLAGWORTID as R, spath as Pfad ',
'FROM (',
'  SELECT stext, SCHLAGWORTID, sys_connect_by_path(stext, ''/'') spath',
'  FROM T_SCHLAGWORT',
'  --WHERE SCHLAGWORTID NOT IN (SELECT DISTINCT PARENTID FROM T_SCHLAGWORT WHERE PARENTID IS NOT NULL)',
'  CONNECT BY PRIOR SCHLAGWORTID = parentid',
'  START WITH parentid IS NULL',
');',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_owner=>'CARMAH2_ADMIN'
,p_return_column_name=>'R'
,p_display_column_name=>'SCHLAGWORT'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(757926349867982053)
,p_query_column_name=>'R'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(757926830996982053)
,p_query_column_name=>'SCHLAGWORT'
,p_heading=>'Schlagwort'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(757927144179982054)
,p_query_column_name=>'PFAD'
,p_heading=>'Pfad'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
