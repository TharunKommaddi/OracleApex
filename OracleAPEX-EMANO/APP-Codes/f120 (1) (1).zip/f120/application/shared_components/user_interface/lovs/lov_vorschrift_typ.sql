prompt --application/shared_components/user_interface/lovs/lov_vorschrift_typ
begin
--   Manifest
--     LOV_VORSCHRIFT_TYP
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(2656545044559578040)
,p_lov_name=>'LOV_VORSCHRIFT_TYP'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN bezeichnung ',
'        ELSE name_eng',
'    END AS d,',
'    vorschrift_typid AS r',
'FROM t_vorschrift_typ',
'ORDER BY 2;',
''))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
