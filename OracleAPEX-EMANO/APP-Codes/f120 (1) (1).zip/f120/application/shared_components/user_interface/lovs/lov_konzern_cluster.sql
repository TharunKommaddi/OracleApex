prompt --application/shared_components/user_interface/lovs/lov_konzern_cluster
begin
--   Manifest
--     LOV_KONZERN_CLUSTER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(646262310283071234)
,p_lov_name=>'LOV_KONZERN_CLUSTER'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'T_KONZERN_CLUSTER'
,p_return_column_name=>'KONZERN_CLUSTERID'
,p_display_column_name=>'BEZEICHNUNG'
,p_default_sort_column_name=>'BEZEICHNUNG'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
