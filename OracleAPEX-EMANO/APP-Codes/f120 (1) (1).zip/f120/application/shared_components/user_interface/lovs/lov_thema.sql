prompt --application/shared_components/user_interface/lovs/lov_thema
begin
--   Manifest
--     LOV_THEMA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(2642113052556035666)
,p_lov_name=>'LOV_THEMA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    NUMMER || '' - '' || ',
'    CASE ',
'        WHEN :FSP_LANGUAGE_PREFERENCE = ''de'' THEN BEZEICHNUNG',
'        ELSE name_eng',
'    END as d,',
'    THEMAID as r',
'FROM V_THEMA_BAUM vtb',
'-- It excludes topics linked to et_b_akid = 1036 in t_thema_ref_et_b_ak, ensuring results are relevant to users without access to these excluded topics.',
'-- WHERE vtb.themaid not in (select themaid from t_thema_ref_et_b_ak where et_b_akid =1036 )',
'ORDER BY vtb.thema_sortorder;'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
