prompt --application/shared_components/logic/application_processes/gethelppicture
begin
--   Manifest
--     APPLICATION PROCESS: getHelpPicture
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(210720375001259889)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'getHelpPicture'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lBlob blob;',
'    lMime varchar2(250);',
'    lFilename varchar2(250);',
'begin',
'    -- Aufruf des JR PrintServers',
'                                          ',
'    select bild_blob, mime_type, filename into lblob,lMime,lFilename from t_hilfe_bild where HILFE_BILDID = :G_HILFE_BILDID;',
'    ',
'    lFilename := ''ET-Freigabe'';',
'    ',
'    sys.htp.init;',
'    sys.owa_util.mime_header( lMime, FALSE );',
'    sys.htp.p(''Content-length: '' || dbms_lob.getlength(lBlob));',
'    /*sys.htp.p(''Content-Disposition: attachment; filename="'' || lFilename || ''"'' );*/',
'    sys.htp.p(''Cache-Control: public, max-age=31536000'');',
'    /*sys.htp.p(''Pragma: no-cache'');          ',
'    sys.htp.p(''Expires: 0''); */',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file( lBlob );',
'',
' ',
'',
'    apex_application.stop_apex_engine; ',
'  ',
'  ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
