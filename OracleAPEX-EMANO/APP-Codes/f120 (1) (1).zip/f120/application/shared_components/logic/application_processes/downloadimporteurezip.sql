prompt --application/shared_components/logic/application_processes/downloadimporteurezip
begin
--   Manifest
--     APPLICATION PROCESS: downloadImporteureZip
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(1039479922185547532)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'downloadImporteureZip'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lBlob blob;',
'    lFilename varchar2(250);',
'    lName varchar2(250);',
'begin',
'',
'    -- Retrieve the user''s name',
'    select b.nachname || ''_'' || b.Vorname',
'    into lName',
'    from T_Benutzer b',
'    where BENUTZERID = :G_BENUTZERID;',
'',
'',
'    lBlob := pck_ri_importeur.fZipExports;',
'    lFilename := ''RegIndex_Importeure'';',
'    ',
'    sys.htp.init;',
'    sys.owa_util.mime_header( ''application/zip'', FALSE );',
'',
'',
'    sys.htp.p(''Content-Disposition: attachment; filename="'' || lFilename || ''-'' || lName || ''-'' || to_char(sysdate, ''YYYY-MM-DD HH24:MI:SS'') || ''.zip"'');',
'',
'',
'    sys.htp.p(''Content-length: '' || dbms_lob.getlength(lBlob));',
'    sys.htp.p(''Cache-Control: public, max-age=31536000'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file( lBlob );',
'',
' ',
'',
'    apex_application.stop_apex_engine; ',
'  ',
'  ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
