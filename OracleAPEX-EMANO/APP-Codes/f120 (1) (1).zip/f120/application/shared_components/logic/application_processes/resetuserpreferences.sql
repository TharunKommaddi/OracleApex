prompt --application/shared_components/logic/application_processes/resetuserpreferences
begin
--   Manifest
--     APPLICATION PROCESS: resetUserPreferences
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(1079531077690780454)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'resetUserPreferences'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lClearCacheSettings varchar2(256);',
'begin',
'    emano_util.pResetPageIGIR(:APP_PAGE_ID, :APP_ID);',
'',
unistr('    apex_util.clear_app_cache(); -- Zur\00FCcksetzen Page-Items auf Sessionbaais Applikationsweit'),
unistr('    apex_util.clear_page_cache;  -- Zur\00FCcksetzen der Einstellungen f\00FCr die akutelle Seite'),
'    apex_util.clear_page_cache(200);',
unistr('    apex_util.clear_user_cache(); -- Zur\00FCcksetzen der Benutzereinstellungen f\00FCr die aktuelle Seite'),
'    --apex_util.remove_preference(''PERSISTENT_ITEM_P200_FILTER_BLAND''); -- Entfernen einer bestimmen Benutzereinstellung',
'    ',
'    ',
'    lClearCacheSettings := ''''',
unistr('                    --|| ''200'' -- Einstellungen der Seite 200 zur\00FCcksetzen    '),
unistr('                    --|| '', APP'' -- Setzt alle Page-Items auf Sessiondbasis f\00FCr die aktuelle Applikation zur\00FCck'),
unistr('                    --|| '', SESSION'' -- Setzt alle Page-Items auf Sessiondbasis f\00FCr alle Applikationen des Workspaces'),
unistr('                    || '', RIR'' -- Interactrive Report zu primary Report zur\00FCcksetzen f\00FCr die akutelle Seite'),
unistr('                    --|| '', CIR'' -- Interactrive Report zu primary Report (mit benutzereingestellen Spalten) zur\00FCcksetzen f\00FCr die akutelle Seite'),
unistr('                    || '', RP'' -- Pagination f\00FCr die aktuelle Seite zur\00FCcksetzen '),
'                    ;',
'    apex_util.redirect_url(apex_page.get_url(p_application => :APP_ID,',
'                                             p_page => :APP_PAGE_ID,',
'                                             p_session => :APP_SESSION,',
'                                             p_clear_cache => lClearCacheSettings',
'                                            ),',
'                           TRUE);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
