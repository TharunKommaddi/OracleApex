prompt --application/shared_components/logic/application_processes/downloadcsv
begin
--   Manifest
--     APPLICATION PROCESS: downloadCSV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(2678576452863347555)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'downloadCSV'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lBlob blob;',
'    lFilename varchar2(250);',
'    lSQL clob;',
'begin',
'    -- Aufruf des JR PrintServers',
'   debug (''Export Type'',:G_CSV_EXPORTTYPE);',
'   debug('':G_CSV_DELTAMODE'',:G_CSV_DELTAMODE);',
'    lSQL := pck_ri_suche.fGetCSVSQL2(:P450_SUCHEID, :G_CSV_INDEX, :G_CSV_EXPORTTYPE, :G_CSV_DELTAMODE,:P450_SUCHE_TEMPIDS);                  ',
'    lBlob := emano_report.fWrapperCSV(lSQL);',
'    select to_char(Sysdate, ''YYYY-MM-DD_HH24-MI-SS'')||''_RegIndex_''||case :G_CSV_EXPORTTYPE when  ''1'' then ''Export_Baureihen'' when ''2'' then ''Export_Themengebiete'' when ''3'' then ''Export_Vorschriften'' end ||''.csv'' into  lFilename',
'    from dual;',
'    ',
'    sys.htp.init;',
'    sys.owa_util.mime_header( ''text/csv'', FALSE );',
'    sys.htp.p(''Content-length: '' || dbms_lob.getlength(lBlob));',
'    sys.htp.p(''Content-Disposition: attachment; filename="'' || lFilename || ''"'' );       ',
'    sys.htp.p(''Cache-Control: public, max-age=31536000''); ',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file( lBlob );',
'',
' ',
'',
'    apex_application.stop_apex_engine; ',
'  ',
'  ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
