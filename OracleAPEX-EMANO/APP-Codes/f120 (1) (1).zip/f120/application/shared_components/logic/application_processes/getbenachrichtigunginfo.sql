prompt --application/shared_components/logic/application_processes/getbenachrichtigunginfo
begin
--   Manifest
--     APPLICATION PROCESS: getBenachrichtigungInfo
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(647957266487957085)
,p_process_sequence=>1
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'getBenachrichtigungInfo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    anzahl number;',
'begin',
'   SELECT ',
'( SELECT count(distinct b.benachrichtigungid) ',
'    --b.benachrichtigungid bid, b.BENACHRICHTIGUNG_TEXT btext, b.STATUS bstatus, ak.et_b_AKID bakid --, u.benutzerid, u.Nachname',
'    FROM T_BENACHRICHTIGUNG b',
'    JOIN t_et_b_ak ak on ( b.ArbeitskreisID = ak.et_b_AKID)',
'    JOIN t_et_b_ak_ref_benutzer arb ON (arb.et_b_akid = ak.et_b_akid)',
'    JOIN t_benutzer u on (u.benutzerid = arb.benutzerid)',
'   WHERE u.benutzerid = :G_BENUTZERID  ',
'     and (b.letzte_aenderung_datum is null OR ((b.erstellung_datum = b.letzte_aenderung_datum) and b.status = 10))',
'  )',
'  +',
'  (  SELECT count(distinct b.benachrichtigungid) count1',
'       FROM T_BENACHRICHTIGUNG b',
'       JOIN t_et_b_ak ak on ( b.ArbeitskreisID = ak.et_b_AKID)',
'      WHERE  ( ak.bezeichnung = ''Administratoren'' ',
'        and :G_BENUTZERID in (select benutzerid from T_BENUTZER_REF_ROLLE  where ROLLEID in (1003)))',
'        and (b.letzte_aenderung_datum is null OR ( (b.erstellung_datum = b.letzte_aenderung_datum ) and b.status = 10))',
'   ) into anzahl ',
'   FROM dual;',
'   ',
'   :G_BENACHRICHTIGUNG_INFO := '''';',
'    /*if (anzahl is not null and anzahl = 1 ) then',
'           :G_BENACHRICHTIGUNG_INFO  :=''  Es gibt '' || anzahl || '' neue Benachrichtigung.'';',
'    elsif(anzahl is not null and anzahl >= 2 ) then',
'           :G_BENACHRICHTIGUNG_INFO  :=''  Es gibt '' || anzahl || '' neue Benachrichtigungen.'';',
'    end if;*/',
'    ',
'    ',
'    if (anzahl is not null and anzahl > 0 and PCK_RI.fIsUserInRolle(:G_BENUTZERID, ''1003:1000'') > 0 ) then',
'        :G_BENACHRICHTIGUNG_INFO := ''<a href="'' || apex_page.get_url(p_page => 610) || ''"><span class="fa fa-bell-o" aria-hidden="true" style="margin-top:7px">'' || anzahl || ''</span></a>'';',
'    end if;',
'    ',
'    ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('Neue Benachrichtigungen k\00F6nnen nicht ermittelt werden. ')
,p_process_when_type=>'USER_IS_NOT_PUBLIC_USER'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
