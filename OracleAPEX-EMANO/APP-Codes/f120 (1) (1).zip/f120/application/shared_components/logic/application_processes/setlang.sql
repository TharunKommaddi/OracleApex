prompt --application/shared_components/logic/application_processes/setlang
begin
--   Manifest
--     APPLICATION PROCESS: setLang
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(959612688960730895)
,p_process_sequence=>1
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'setLang'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    debug(''setlang'',:FSP_LANGUAGE_PREFERENCE);',
'    update t_benutzer set userlang = :FSP_LANGUAGE_PREFERENCE where benutzerid = :G_BENUTZERID;',
'    owa_util.redirect_url(apex_page.get_url);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'LANG'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
