prompt --application/shared_components/logic/application_processes/downloadgetexjson
begin
--   Manifest
--     APPLICATION PROCESS: downloadGetexJson
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(1098434632240521488)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'downloadGetexJson'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' lBlob blob;',
'    lClob clob :='''';',
'    lFilename varchar2(250);',
'    lName varchar2(250);',
'    tgt_blob BLOB;',
'    amount INTEGER := DBMS_LOB.lobmaxsize;',
'        dest_offset INTEGER := 1;',
'        src_offset INTEGER  := 1;',
'        blob_csid INTEGER := nls_charset_id(''UTF8'');',
'        lang_context INTEGER := DBMS_LOB.default_lang_ctx;',
'        warning INTEGER := 0;',
'begin',
'    -- Retrieve the user''s name',
'    debug(''getex_Json Download'');',
'    select b.nachname || ''_'' || b.Vorname',
'    into lName    from T_Benutzer b    where BENUTZERID = :G_BENUTZERID;',
'',
'    select  daten into lClob ',
'    from T_x_getex_import where GETEX_SCHLUESSEL = :G_GETEX_KEY;',
' ',
'   -- lBlob := EMANO_REPORT.fClobToBlob(UNISTR(''\FEFF'') || lClob);',
'       DBMS_LOB.CreateTemporary(tgt_blob, true);',
'        DBMS_LOB.ConvertToBlob(tgt_blob, lClob, amount, dest_offset, src_offset, blob_csid, lang_context, warning);',
'        lBlob := tgt_blob;',
'    lFilename := ''Getex'';',
'    ',
'    sys.htp.init;',
'    sys.owa_util.mime_header( ''text/csv'', FALSE );',
'    sys.htp.p(''Content-Disposition: attachment; filename="'' || lFilename || ''-'' || lName || ''-'' || to_char(sysdate, ''YYYY-MM-DD HH24:MI:SS'') || ''.json"'');',
'    sys.htp.p(''Content-length: '' || dbms_lob.getlength(lBlob));',
'    sys.htp.p(''Cache-Control: public, max-age=31536000'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file( lBlob );',
'    ',
'    apex_application.stop_apex_engine; ',
'  ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'download process fehlgeschlagen.'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
