prompt --application/shared_components/logic/application_processes/initlang
begin
--   Manifest
--     APPLICATION PROCESS: initLang
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(959613499105750052)
,p_process_sequence=>1
,p_process_point=>'ON_NEW_INSTANCE'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'initLang'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lLang varchar2(30);',
'',
'begin',
'  ',
'',
'    select userlang into lLang from t_benutzer where benutzerid = :G_BENUTZERID;',
'    -- if (lLang != ''de'') then',
'       :FSP_LANGUAGE_PREFERENCE := lLang;',
'   -- end if;',
'    owa_util.redirect_url(''f?p=''||:APP_ID||'':''||:APP_PAGE_ID||'':''||:APP_SESSION); ',
'exception',
'    when no_data_found then',
'        -- Gastbenutzer',
'        :FSP_LANGUAGE_PREFERENCE := ''de'';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
