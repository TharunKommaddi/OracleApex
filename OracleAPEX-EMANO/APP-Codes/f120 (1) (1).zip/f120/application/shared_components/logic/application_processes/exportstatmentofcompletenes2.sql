prompt --application/shared_components/logic/application_processes/exportstatmentofcompletenes2
begin
--   Manifest
--     APPLICATION PROCESS: exportStatmentOfCompletenes2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(660235334250015157)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'exportStatmentOfCompletenes2'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lBlob blob;',
'    lQuery clob;',
'    lSheetName varchar2(500);',
'    lTitleName varchar2(500);',
'    lName varchar2(500);',
'    lLand varchar2(500);',
'    lLandBNr varchar2(50);',
'    lFilename varchar2(250);',
'begin',
'    -- Retrieve the user''s name',
'    select b.nachname || ''_'' || b.Vorname',
'    into lName',
'    from T_Benutzer b',
'    where BENUTZERID = :G_BENUTZERID;',
'',
'    -- Retrieve country information',
'    select b_nummer, land',
'    into lLandBNr, lLand',
'    from t_land',
'    where LANDID = :P430_LAND;',
'    ',
'    -- Prepare the query array for the combined report',
'      ',
'    lQuery := PCK_RI_EXPORT.fGetSQLExportCombined; -- Used the new combined function',
'    ',
'    -- Prepare the title for the Excel sheet',
'    ',
'    lTitleName := ''Country: '' || lLand || '' ('' || lLandBNr || '') Combined Report'';',
'    ',
'    -- Prepare the sheet name',
' ',
'    lSheetName := ''Combined Report'';',
'    ',
'    -- Generate the Excel file with the combined report',
'    lBlob := emano_report.fMakeExcelsingleSheet(lSheetName, lTitleName, lQuery);',
'    ',
'    -- Set the filename for the Excel file',
'    lFilename := ''Excel-Export-Statement_of_Completeness-'' || lLandBNr || ''-'' || lLand || ''-'' || lName || ''-'' || to_char(sysdate, ''YYYY-MM-DD-HH24-MI-SS'') || ''.xlsx'';',
'       ',
'    -- Initiate the HTTP response for file download',
'    sys.htp.init;',
'    sys.owa_util.mime_header(''application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'', false);   ',
'    sys.htp.p(''Content-length: '' || dbms_lob.getlength(lBlob));',
'    sys.htp.p(''Content-Disposition: attachment; filename="'' || lFilename || ''"'');',
'    sys.htp.p(''Cache-Control: no-cache, no-store, must-revalidate'');',
'    sys.htp.p(''Pragma: no-cache'');',
'    sys.htp.p(''Expires: 0'');',
'    sys.owa_util.http_header_close;',
'    ',
'    -- Download the file',
'    sys.wpg_docload.download_file(lBlob);',
'    ',
'    -- Stop further APEX processing',
'    apex_application.stop_apex_engine;',
'        ',
'/*exception',
'    when others then',
'        htp.p(dbms_utility.format_error_backtrace);*/',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
