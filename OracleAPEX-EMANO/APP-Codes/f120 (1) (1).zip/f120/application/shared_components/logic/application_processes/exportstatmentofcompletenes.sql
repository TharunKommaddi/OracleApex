prompt --application/shared_components/logic/application_processes/exportstatmentofcompletenes
begin
--   Manifest
--     APPLICATION PROCESS: exportStatmentOfCompletenes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(668162431573293462)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'exportStatmentOfCompletenes'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lSQLCode clob;',
'    lBlob blob;',
'    lFilename varchar2(250);',
'    lName varchar2(500);',
'    lLand varchar2(500);',
'    lLandBNr varchar2(50);',
'    lCurFut varchar2(50);',
'begin',
'    select b.nachname || ''_'' || b.Vorname',
'    into lName',
'    from T_Benutzer b',
'    where BENUTZERID = :G_BENUTZERID;',
'    ',
'    select b_nummer, land',
'    into lLandBNr, lLand',
'    from t_land',
'    where LANDID = :P430_LAND;',
'    ',
'    lCurFut := case when :P430_CURRENT_FUTURE = 10 then ''Current'' else ''Future'' end;',
'     ',
'    lSQLCode := PCK_RI_EXPORT.fGetSQLExport;',
'    ',
'    emano_report.pInit(lSQLCode);',
'    emano_report.pExecute;',
'        ',
'    -- Excel-Export',
'    lBlob := emano_report.fMakeExcel(''Country: '' || lLand || '' ('' || lLandBNr || '')  '' || lCurFut );',
'    lFilename := ''Excel-Export-Statement_of_Completenes-'' || lLandBNr || ''-'' || lLand || ''-'' || lCurFut || ''-'' || lName || ''-'' || to_char(sysdate, ''YYYY-MM-DD-HH24-MI-SS'') || ''-VERTRAULICH.xlsx'';',
'       ',
'    sys.htp.init;',
'    sys.owa_util.mime_header(''application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'', false);',
'       ',
'    ',
'    sys.htp.p(''Content-length: '' || dbms_lob.getlength(lBlob));',
'    sys.htp.p(''Content-Disposition: attachment; filename = "'' || lFilename || ''"'');',
'    sys.htp.p(''Cache-Control: no-cache, no-store, must-revalidate'');',
'    sys.htp.p(''Pragma: no-cache'');',
'    sys.htp.p(''Expires: 0'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(lBlob);',
'    ',
'    apex_application.stop_apex_engine;',
'        ',
'    ',
'    exception',
'      when others then',
'          htp.p(dbms_utility.format_error_backtrace);',
'          --raise;',
'        --htp.p(lSQLCode);',
'        ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
