prompt --application/shared_components/logic/application_processes/pgethilfetooltip
begin
--   Manifest
--     APPLICATION PROCESS: pGetHilfeTooltip
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(1455991714963141807)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'pGetHilfeTooltip'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lHelpID number := apex_application.g_x01;',
'    lTooltipText varchar2(250); ',
'    lLink varchar2(2000);',
'begin',
'    lLink := apex_page.get_url(p_page => 170, p_items => ''P170_HILFEID'', p_values => lHelpID);',
'    -- select tooltip into lTooltipText from t_hilfe where hilfeid = lHelpID;',
'',
'    begin',
'    if (lHelpID is not null ) then ',
'        select tooltip into lTooltipText from t_hilfe where hilfeid = lHelpID;',
'     else ',
'        lTooltipText := ''No tooltip available'';',
'     end if;',
'     ',
'    exception',
'        when no_data_found then',
'            lTooltipText := ''No tooltip available'';',
'    end;',
'',
'',
'    apex_json.open_object;',
'    apex_json.write(''link'',lLink);',
'    apex_json.write(''tooltip'',lTooltipText);',
'    apex_json.close_all;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
