prompt --application/shared_components/logic/application_processes/logusersession
begin
--   Manifest
--     APPLICATION PROCESS: LogUserSession
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(1092655436615458439)
,p_process_sequence=>1
,p_process_point=>'ON_NEW_INSTANCE'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LogUserSession'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_abteilung VARCHAR2(20);',
'BEGIN',
'    -- Get transformed department for current user',
'    SELECT PCK_RI.fTRANSFORM_ABTEILUNG(ABTEILUNG)',
'    INTO v_abteilung',
'    FROM T_BENUTZER',
'    WHERE BENUTZERID = :G_BENUTZERID;',
'',
'    -- Log session',
'    INSERT INTO T_SESSION_PROTOKOLL (',
'        ABTEILUNG,',
'        SESSION_ID,',
'        BENUTZERID',
'    ) VALUES (',
'        v_abteilung,',
'        V(''APP_SESSION''),',
'        :G_BENUTZERID',
'    );',
'    -- COMMIT;',
'EXCEPTION',
'    WHEN DUP_VAL_ON_INDEX THEN',
'        NULL; -- Ignore if already logged',
'    WHEN OTHERS THEN',
'        apex_error.add_error(',
'            p_message => ''Error logging session: '' || SQLERRM,',
'            p_display_location => apex_error.c_on_error_page',
'        );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
