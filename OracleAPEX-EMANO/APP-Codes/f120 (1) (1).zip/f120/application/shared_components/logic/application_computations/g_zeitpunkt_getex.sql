prompt --application/shared_components/logic/application_computations/g_zeitpunkt_getex
begin
--   Manifest
--     APPLICATION COMPUTATION: G_ZEITPUNKT_GETEX
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(650405895644086376)
,p_computation_sequence=>10
,p_computation_item=>'G_ZEITPUNKT_GETEX'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'QUERY'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'select to_char(max(zeitpunkt_upload),''dd.mm.yyyy hh24:mi'') from t_x_getex_import'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
