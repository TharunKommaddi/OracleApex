prompt --application/shared_components/logic/application_computations/g_environment
begin
--   Manifest
--     APPLICATION COMPUTATION: G_ENVIRONMENT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(2666550162775565601)
,p_computation_sequence=>10
,p_computation_item=>'G_ENVIRONMENT'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    lVersion varchar2(250);',
'    lGlobalName varchar2(250);',
'    lUmgebung varchar2(250);',
'begin',
'    select version  into lVersion from apex_applications where application_id = :APP_ID;',
'    select global_name into lGlobalName from global_name;',
'    lUmgebung := case substr(lGlobalName,1,1)',
'        when ''E'' then '' (Entwicklungsumgebung)''',
'        when ''T'' then '' (Testumgebung)''',
'        else ''''',
'    end;',
'    return ''Version: '' || lVersion || lUmgebung;',
'exception',
'    when others then return ''xyz'';',
'end;'))
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
