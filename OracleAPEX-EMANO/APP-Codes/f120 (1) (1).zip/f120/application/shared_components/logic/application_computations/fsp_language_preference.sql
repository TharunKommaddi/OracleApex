prompt --application/shared_components/logic/application_computations/fsp_language_preference
begin
--   Manifest
--     APPLICATION COMPUTATION: FSP_LANGUAGE_PREFERENCE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(701462705703605417)
,p_computation_sequence=>10
,p_computation_item=>'FSP_LANGUAGE_PREFERENCE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'de'
,p_compute_when=>':FSP_LANGUAGE_PREFERENCE is null'
,p_compute_when_text=>'PLSQL'
,p_compute_when_type=>'EXPRESSION'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
