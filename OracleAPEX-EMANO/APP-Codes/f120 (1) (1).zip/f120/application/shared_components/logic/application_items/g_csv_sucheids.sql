prompt --application/shared_components/logic/application_items/g_csv_sucheids
begin
--   Manifest
--     APPLICATION ITEM: G_CSV_SUCHEIDS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(2678576745811351671)
,p_name=>'G_CSV_SUCHEIDS'
,p_protection_level=>'N'
,p_escape_on_http_output=>'N'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
