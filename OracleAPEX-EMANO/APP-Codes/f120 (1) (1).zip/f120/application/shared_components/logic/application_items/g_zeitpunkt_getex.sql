prompt --application/shared_components/logic/application_items/g_zeitpunkt_getex
begin
--   Manifest
--     APPLICATION ITEM: G_ZEITPUNKT_GETEX
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(650406442971089427)
,p_name=>'G_ZEITPUNKT_GETEX'
,p_protection_level=>'I'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
