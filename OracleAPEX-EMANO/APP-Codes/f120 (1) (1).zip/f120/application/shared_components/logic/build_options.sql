prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 120
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(858110749738284382)
,p_build_option_name=>unistr('Funktion nur f\00FCr Liveumgebung')
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
