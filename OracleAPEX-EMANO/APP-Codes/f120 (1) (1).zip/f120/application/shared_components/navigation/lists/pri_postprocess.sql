prompt --application/shared_components/navigation/lists/pri_postprocess
begin
--   Manifest
--     LIST: PRI+ postprocess
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(964128428368451140)
,p_name=>'PRI+ postprocess'
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(964128281113451139)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Aktion w\00E4hlen')
,p_list_item_link_target=>'f?p=&APP_ID.:464:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(964127897031451138)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Pr\00FCfen & Best\00E4tigen')
,p_list_item_link_target=>'f?p=&APP_ID.:468:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(964127477863451137)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Ergebnis'
,p_list_item_link_target=>'f?p=&APP_ID.:469:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
