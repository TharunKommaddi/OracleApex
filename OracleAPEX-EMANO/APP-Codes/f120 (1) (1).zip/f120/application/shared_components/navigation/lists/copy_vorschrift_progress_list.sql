prompt --application/shared_components/navigation/lists/copy_vorschrift_progress_list
begin
--   Manifest
--     LIST: Copy Vorschrift Progress List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(712760182011977984)
,p_name=>'Copy Vorschrift Progress List'
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(712759181019977962)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Kerndaten'
,p_list_item_link_target=>'f?p=&APP_ID.:540:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(631778651198544690)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Einsatzdatum'
,p_list_item_link_target=>'f?p=&APP_ID.:544:&APP_SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(702083336490168255)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Verkn\00FCpfungen')
,p_list_item_link_target=>'f?p=&APP_ID.:541:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(702082922880168254)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'MfVs'
,p_list_item_link_target=>'f?p=&APP_ID.:542:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(702082526340168254)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Verlinkte Normen'
,p_list_item_link_target=>'f?p=&APP_ID.:543:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(702082129590168253)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('L\00E4nder und Themen')
,p_list_item_link_target=>'f?p=&APP_ID.:545:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
