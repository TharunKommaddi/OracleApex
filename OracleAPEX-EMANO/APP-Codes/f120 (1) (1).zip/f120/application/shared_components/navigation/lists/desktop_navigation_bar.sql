prompt --application/shared_components/navigation/lists/desktop_navigation_bar
begin
--   Manifest
--     LIST: Desktop Navigation Bar
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(3414149819795820577)
,p_name=>'Desktop Navigation Bar'
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1096808685455135668)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>'&G_ENVIRONMENT.'
,p_list_item_link_target=>'javascript:var x =window.open(''https://volkswagengroup.sharepoint.com/sites/ET-BInfoHilfe/SitePages/Release-Notes-Regulation-Index.aspx'',''_blank'')'
,p_list_item_icon=>'fa-external-link'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(12759903846324713)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Benutzereinstellungen zur\00FCcksetzen')
,p_list_item_link_target=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.:APPLICATION_PROCESS=resetUserPreferences:&DEBUG.::::'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(863832034454753492)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Support'
,p_list_item_link_target=>'mailto:regindex-support@audi.de'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3414150006665820578)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Log Out'
,p_list_item_link_target=>'&LOGOUT_URL.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(959519852746386511)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Deutsch / German'
,p_list_item_link_target=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.:LANG:&DEBUG.::FSP_LANGUAGE_PREFERENCE:de:'
,p_list_item_current_type=>'EXPRESSION'
,p_list_item_current_for_pages=>'nvl(:FSP_LANGUAGE_PREFERENCE,''de'') = ''de'''
,p_list_item_current_language=>'PLSQL'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(959519602558380066)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Englisch / English'
,p_list_item_link_target=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.:LANG:&DEBUG.::FSP_LANGUAGE_PREFERENCE:en:'
,p_list_item_current_type=>'EXPRESSION'
,p_list_item_current_for_pages=>'nvl(:FSP_LANGUAGE_PREFERENCE,''de'') = ''en'''
,p_list_item_current_language=>'PLSQL'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(650405166768083929)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Letzte Aktualisierung der GETEX2-Daten: &G_ZEITPUNKT_GETEX.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
