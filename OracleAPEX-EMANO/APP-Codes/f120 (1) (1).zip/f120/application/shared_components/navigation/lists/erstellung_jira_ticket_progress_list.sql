prompt --application/shared_components/navigation/lists/erstellung_jira_ticket_progress_list
begin
--   Manifest
--     LIST: Erstellung Jira Ticket Progress List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(637561291400734979)
,p_name=>'Erstellung Jira Ticket Progress List'
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1094110598257267939)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>unistr('MfV-Vorg\00E4nger')
,p_list_item_link_target=>'f?p=&APP_ID.:581:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1016546875286197445)
,p_list_item_display_sequence=>6
,p_list_item_link_text=>'COCOA-Ticket'
,p_list_item_link_target=>'f?p=&APP_ID.:582:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(637560268289734966)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'MfV Teil'
,p_list_item_link_target=>'f?p=&APP_ID.:570:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(637555577823734938)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Arbeitskreise'
,p_list_item_link_target=>'f?p=&APP_ID.:571:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(637550214667734936)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Vorschriften'
,p_list_item_link_target=>'f?p=&APP_ID.:572:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(637539029286734930)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Zusammenfassung'
,p_list_item_link_target=>'f?p=&APP_ID.:574:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(983821747506080147)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Link Jira Ticket '
,p_list_item_link_target=>'f?p=&APP_ID.:576:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
