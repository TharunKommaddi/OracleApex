prompt --application/shared_components/navigation/lists/desktop_navigation_menu
begin
--   Manifest
--     LIST: Desktop Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(3414107444680820531)
,p_name=>'Desktop Navigation Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(917284848047928146)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>'Arbeitskreis'
,p_list_item_link_target=>'f?p=&APP_ID.:380:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 380,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'380,385'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(852020596540651578)
,p_list_item_display_sequence=>230
,p_list_item_link_text=>'VKO/VEX Register'
,p_list_item_link_target=>'f?p=&APP_ID.:520:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(917284848047928146)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'520'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2641545243547267152)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Vorschriften'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'20,25'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(861101339035113312)
,p_list_item_display_sequence=>220
,p_list_item_link_text=>'Langversion'
,p_list_item_link_target=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(2641545243547267152)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(683260841166116558)
,p_list_item_display_sequence=>260
,p_list_item_link_text=>'Benachrichtigungen'
,p_list_item_link_target=>'f?p=&APP_ID.:610:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 610,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641545243547267152)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'610,615'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(799212907437903097)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Fachbereichreport'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(885738975337484697)
,p_list_item_display_sequence=>240
,p_list_item_link_text=>'CoP Vorschriften Report'
,p_list_item_link_target=>'f?p=&APP_ID.:390:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(799212907437903097)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'390'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(602625761784642613)
,p_list_item_display_sequence=>290
,p_list_item_link_text=>'Funktionen FuKa (System42)'
,p_list_item_link_target=>'f?p=&APP_ID.:440:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(799212907437903097)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'440'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(658382005935079167)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'ET-B Reports'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  v_val BOOLEAN;',
'  v_num_val NUMBER;',
'  v_num_val2 NUMBER := 0;',
'BEGIN',
'  FOR i IN (',
'    SELECT 430 AS page FROM dual',
'    UNION ALL',
'    SELECT 800 AS page FROM dual ',
'    UNION ALL',
'    SELECT 810 AS page FROM dual ',
'    UNION ALL',
'    SELECT 820 AS page FROM dual ',
'    UNION ALL',
'    SELECT 1000 AS page FROM dual ',
'    UNION ALL',
'    SELECT 60 AS page FROM dual',
'    UNION ALL',
'    SELECT 26 AS page FROM dual ',
'  ) LOOP',
'    v_val := PCK_RI.fIsAuthorized(pageId => i.page, accessMode => 100);',
'    IF v_val IS NULL THEN',
'      v_num_val := 0;',
'    ELSIF v_val = TRUE THEN',
'      v_num_val := 1;',
'    ELSE',
'      v_num_val := 0;',
'    END IF;',
'    v_num_val2 := v_num_val2 + v_num_val;',
'  END LOOP;',
'  ',
'  IF v_num_val2 > 0 THEN',
'    RETURN TRUE;',
'  ELSE',
'    RETURN FALSE;',
'  END IF;',
'END;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(658381662299076050)
,p_list_item_display_sequence=>26
,p_list_item_link_text=>'Statement of Completeness'
,p_list_item_link_target=>'f?p=&APP_ID.:430:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 430,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(658382005935079167)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(984990617300187550)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Tableau-Tabelle'
,p_list_item_link_target=>'f?p=&APP_ID.:1000:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 1000,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(658382005935079167)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(571947634668201857)
,p_list_item_display_sequence=>300
,p_list_item_link_text=>unistr('Report Datum au\00DFer Kraft')
,p_list_item_link_target=>'f?p=&APP_ID.:800:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 800,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(658382005935079167)
,p_security_scheme=>wwv_flow_imp.id(2652734704667593954)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(571947266357198762)
,p_list_item_display_sequence=>310
,p_list_item_link_text=>'Report Vernetzung Demands'
,p_list_item_link_target=>'f?p=&APP_ID.:810:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 810,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(658382005935079167)
,p_security_scheme=>wwv_flow_imp.id(2652734704667593954)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(571946792473195204)
,p_list_item_display_sequence=>320
,p_list_item_link_text=>'Report Vernetzung equal'
,p_list_item_link_target=>'f?p=&APP_ID.:820:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 820,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(658382005935079167)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(363376150429671148)
,p_list_item_display_sequence=>400
,p_list_item_link_text=>'SRA Gruppen Abgleich'
,p_list_item_link_target=>'f?p=&APP_ID.:60:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 60,',
'                      accessMode => 200))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(658382005935079167)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1022668719988122718)
,p_list_item_display_sequence=>420
,p_list_item_link_text=>unistr('Grundbef\00FCllung Items')
,p_list_item_link_target=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'pck_ri.fIsAuthorized(pageId => 26, accessMode => 100)'
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(658382005935079167)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(930977902559185624)
,p_list_item_display_sequence=>430
,p_list_item_link_text=>unistr('Qualit\00E4tscheck')
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 27,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(658382005935079167)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'27'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(929202992136974881)
,p_list_item_display_sequence=>440
,p_list_item_link_text=>unistr('Analyse letzt g\00FCltige Fassung')
,p_list_item_link_target=>'f?p=&APP_ID.:2000:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 2000,',
'                      accessMode => 200))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(658382005935079167)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(904465038135429188)
,p_list_item_display_sequence=>450
,p_list_item_link_text=>'Free VKO Report'
,p_list_item_link_target=>'f?p=&APP_ID.:2020:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'(PCK_RI.fIsAuthorized(pageId => 2020, accessMode => 100))'
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(658382005935079167)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(708959231521443366)
,p_list_item_display_sequence=>460
,p_list_item_link_text=>'GETEX2 Blacklist'
,p_list_item_link_target=>'f?p=&APP_ID.:2100:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 2100,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(658382005935079167)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Stammdaten'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2663060438130110349)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('L\00E4nder')
,p_list_item_link_target=>'f?p=&APP_ID.:130:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 130,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'130,135'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2641376079671049538)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('L\00E4ndergruppen')
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 10,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10,15'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2641724353492572804)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Themen'
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 30,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'30,35'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2642952643812609135)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Benutzerverwaltung'
,p_list_item_link_target=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 50,',
'                      accessMode => 100))',
'         '))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'50,55'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2643468481944719072)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'MfVs / Jira-Tickets'
,p_list_item_link_target=>'f?p=&APP_ID.:70:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 70,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'70,75'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(833743948968157806)
,p_list_item_display_sequence=>85
,p_list_item_link_text=>'MFV Fehlerhandling'
,p_list_item_link_target=>'f?p=&APP_ID.:1010:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 1010,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1098432665695464096)
,p_list_item_display_sequence=>86
,p_list_item_link_text=>'GETEX Fehlerhandling'
,p_list_item_link_target=>'f?p=&APP_ID.:2300:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'(PCK_RI.fIsAuthorized(pageId => 2300, accessMode => 100))'
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2300'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1062607465817138907)
,p_list_item_display_sequence=>530
,p_list_item_link_text=>'Publisher Stammdaten'
,p_list_item_link_target=>'f?p=&APP_ID.:260:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 260,',
'                      accessMode => 200))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(1098432665695464096)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'260, 265'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1037118931368613569)
,p_list_item_display_sequence=>550
,p_list_item_link_text=>'NORM Prefix'
,p_list_item_link_target=>'f?p=&APP_ID.:270:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'( pck_ri.fIsUserInRolle(listRolleId => ''1003'') > 0)'
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(1098432665695464096)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'270, 275'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(997487240178974055)
,p_list_item_display_sequence=>600
,p_list_item_link_text=>'GETEX Monitor'
,p_list_item_link_target=>'f?p=&APP_ID.:2400:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(1098432665695464096)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2400'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(949494569490872321)
,p_list_item_display_sequence=>610
,p_list_item_link_text=>'Demands-Ketten'
,p_list_item_link_target=>'f?p=&APP_ID.:287:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(1098432665695464096)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2644236629530842855)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'MfV-Vorschriften-Zuordnungen'
,p_list_item_link_target=>'f?p=&APP_ID.:80:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'NEVER'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'80,85'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2653111686195749481)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Webseiten'
,p_list_item_link_target=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 110,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'110,115'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(904064947393841157)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'MfV Importkontrolle'
,p_list_item_link_target=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'NEVER'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_security_scheme=>wwv_flow_imp.id(2660026449262803947)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2662243054139647391)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Normierte Eingabe'
,p_list_item_link_target=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'NEVER'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'120,125'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2677410576081604082)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'KSU'
,p_list_item_link_target=>'f?p=&APP_ID.:150:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 150,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'150,155'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2684487065503686852)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Hilfe'
,p_list_item_link_target=>'f?p=&APP_ID.:160:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 160,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'160,165'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(925650194047411635)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>'Antriebsart'
,p_list_item_link_target=>'f?p=&APP_ID.:370:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 370,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_security_scheme=>wwv_flow_imp.id(2660026449262803947)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(864462321513810444)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>'Funktionen'
,p_list_item_link_target=>'f?p=&APP_ID.:341:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 341,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'340,341'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(863784023462403799)
,p_list_item_display_sequence=>210
,p_list_item_link_text=>'Konzern Cluster'
,p_list_item_link_target=>'f?p=&APP_ID.:510:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 510,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'510,515'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(643885231532781647)
,p_list_item_display_sequence=>270
,p_list_item_link_text=>'Keywords'
,p_list_item_link_target=>'f?p=&APP_ID.:251:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 251,',
'                      accessMode => 200))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'250,251'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(615514995425153653)
,p_list_item_display_sequence=>280
,p_list_item_link_text=>'Regulierungsverantwortliche'
,p_list_item_link_target=>'f?p=&APP_ID.:410:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'410,415,420,423,425'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(374244174022172136)
,p_list_item_display_sequence=>370
,p_list_item_link_text=>'Konzern Jira Ticket'
,p_list_item_link_target=>'f?p=&APP_ID.:590:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 590,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'590,595'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(373068603489521465)
,p_list_item_display_sequence=>380
,p_list_item_link_text=>'Stammdaten Suche'
,p_list_item_link_target=>'f?p=&APP_ID.:701:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 701,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(462419286062339172)
,p_list_item_display_sequence=>330
,p_list_item_link_text=>'MS Bilder'
,p_list_item_link_target=>'f?p=&APP_ID.:730:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(373068603489521465)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'730,735'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(373068102405512899)
,p_list_item_display_sequence=>390
,p_list_item_link_text=>'Texte'
,p_list_item_link_target=>'f?p=&APP_ID.:710:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(373068603489521465)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(658869255857856747)
,p_list_item_display_sequence=>480
,p_list_item_link_text=>unistr('Sub L\00E4nder')
,p_list_item_link_target=>'f?p=&APP_ID.:230:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 230,',
'                      accessMode => 300))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'230'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1047625936557171417)
,p_list_item_display_sequence=>540
,p_list_item_link_text=>unistr('\00DCbergangsbestimmung')
,p_list_item_link_target=>'f?p=&APP_ID.:481:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'( pck_ri.fIsUserInRolle(listRolleId => ''1200:1003'') > 0)'
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1025476995801102411)
,p_list_item_display_sequence=>590
,p_list_item_link_text=>'LRSA'
,p_list_item_link_target=>'f?p=&APP_ID.:280:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 280,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(910486469380829168)
,p_list_item_display_sequence=>630
,p_list_item_link_text=>'Nicht-Relevant Regeln'
,p_list_item_link_target=>'f?p=&APP_ID.:53:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(2641513990780422187)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'53'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2653119729010775838)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Cockpit'
,p_list_item_link_target=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2663864640197750405)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Suche'
,p_list_item_link_target=>'f?p=&APP_ID.:320:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1003906171264896358)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'GANTT-Chart'
,p_list_item_link_target=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 400,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'400'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(991826904659187203)
,p_list_item_display_sequence=>175
,p_list_item_link_text=>'FZG-Projekt MS Suche'
,p_list_item_link_target=>'f?p=&APP_ID.:450:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 450,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'450'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1081257995654783616)
,p_list_item_display_sequence=>348
,p_list_item_link_text=>'Post-process Hub'
,p_list_item_link_target=>'f?p=&APP_ID.:482:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'( pck_ri.fIsUserInRolle(listRolleId => ''1080'') > 0)'
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(402761603101426715)
,p_list_item_display_sequence=>350
,p_list_item_link_text=>'Importeure'
,p_list_item_link_target=>'f?p=&APP_ID.:920:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId =>920,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'920, 900, 910, 930, 940, 950'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(301113818170757823)
,p_list_item_display_sequence=>360
,p_list_item_link_text=>'Matrixansicht'
,p_list_item_link_target=>'f?p=&APP_ID.:960:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(402761603101426715)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1095196784825160884)
,p_list_item_display_sequence=>490
,p_list_item_link_text=>'Report Cluster'
,p_list_item_link_target=>'f?p=&APP_ID.:980:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(PCK_RI.fIsAuthorized(pageId => 980,',
'                      accessMode => 100))'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(402761603101426715)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(940197000533814110)
,p_list_item_display_sequence=>620
,p_list_item_link_text=>'Konsolidierte-Fassung'
,p_list_item_link_target=>'f?p=&APP_ID.:290:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'290'
);
wwv_flow_imp.component_end;
end;
/
