prompt --application/shared_components/navigation/lists/copy_fuka_assistant
begin
--   Manifest
--     LIST: Copy FUKA Assistant
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(988451613722471139)
,p_name=>'Copy FUKA Assistant'
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(988450151161471099)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Auswahl der Quellvorschrift '
,p_list_item_link_target=>'f?p=&APP_ID.:470:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(988445899505471080)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Auswahl der Funktionen (FuKa)'
,p_list_item_link_target=>'f?p=&APP_ID.:472:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(988440922824471076)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Zuweisung der Funktionen'
,p_list_item_link_target=>'f?p=&APP_ID.:474:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
