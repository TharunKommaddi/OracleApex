prompt --application/shared_components/navigation/lists/suche_kpb_wählen_progress_list
begin
--   Manifest
--     LIST: Suche KPB wählen Progress List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(902112785903569023)
,p_name=>unistr('Suche KPB w\00E4hlen Progress List')
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(902111757939569021)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('KPB w\00E4hlen')
,p_list_item_link_target=>'f?p=&APP_ID.:366:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(902107048640569013)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Motor Getriebe Varianten w\00E4hlen')
,p_list_item_link_target=>'f?p=&APP_ID.:367:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
