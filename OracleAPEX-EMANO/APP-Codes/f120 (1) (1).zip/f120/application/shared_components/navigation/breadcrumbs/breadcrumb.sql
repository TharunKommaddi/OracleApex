prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(3414151185686820583)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1008632162141899904)
,p_short_name=>unistr('Testseite, bitte l\00F6schen')
,p_link=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>2
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(952363816230253885)
,p_short_name=>'Demands Cockpit'
,p_link=>'f?p=&APP_ID.:287:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>287
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(940196122814814066)
,p_short_name=>'Konsolidierte-Fassung'
,p_link=>'f?p=&APP_ID.:290:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>290
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(933464551503454697)
,p_short_name=>'Vorschriften_Temporary_Form'
,p_link=>'f?p=&APP_ID.:2005:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>2005
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(930977038967185577)
,p_short_name=>unistr('Qualit\00E4tscheck')
,p_link=>'f?p=&APP_ID.:27:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>27
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(929171187161614576)
,p_short_name=>'ImagePopUp'
,p_link=>'f?p=&APP_ID.:2010:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>2010
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(910485592401829143)
,p_short_name=>'Automatismus Nicht-Relevant - Regeln'
,p_link=>'f?p=&APP_ID.:53:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>53
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(868144428572009771)
,p_short_name=>'GETEX IMPORT LIST'
,p_link=>'f?p=&APP_ID.:640:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>640
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(773104755218966618)
,p_short_name=>'vorschrift'
,p_link=>'f?p=&APP_ID.:7:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(714911556610399065)
,p_short_name=>unistr('Testseite bitte l\00F6schen')
,p_link=>'f?p=&APP_ID.:9:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>9
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(710606885378530656)
,p_short_name=>'MS Parameter Report'
,p_link=>'f?p=&APP_ID.:702:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>702
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(696225235130430011)
,p_short_name=>'Getex Attribut Gruppe Report'
,p_link=>'f?p=&APP_ID.:650:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>650
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(658868451179856718)
,p_short_name=>'Subcountries'
,p_link=>'f?p=&APP_ID.:230:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>230
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3414151617643820585)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.'
,p_page_id=>1
);
wwv_flow_imp.component_end;
end;
/
