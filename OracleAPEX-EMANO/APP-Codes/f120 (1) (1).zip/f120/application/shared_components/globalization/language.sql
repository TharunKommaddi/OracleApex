prompt --application/shared_components/globalization/language
begin
--   Manifest
--     LANGUAGE MAP: 120
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_language_map(
 p_id=>wwv_flow_imp.id(383117873187474432)
,p_translation_flow_id=>121
,p_translation_flow_language_cd=>'en'
,p_direction_right_to_left=>'N'
);
wwv_flow_imp.component_end;
end;
/
