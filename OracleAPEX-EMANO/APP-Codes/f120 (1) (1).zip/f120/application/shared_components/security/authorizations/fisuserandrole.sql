prompt --application/shared_components/security/authorizations/fisuserandrole
begin
--   Manifest
--     SECURITY SCHEME: fIsUserAndRole
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(2650729409691767117)
,p_name=>'fIsUserAndRole'
,p_scheme_type=>'NATIVE_EXISTS'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'from t_benutzer b',
'join t_benutzer_ref_rolle brr on brr.benutzerid = b.benutzerid',
'join t_rolle r on r.rolleid = brr.rolleid',
'where b.status = 10 ',
'and b.benutzerid = :G_BENUTZERID',
'and r.rolle in (''Admin'', ''VKO'', ''ZVEX'', ''VEX'')'))
,p_error_message=>'Sie sind nicht autorisiert, diese Seite zu verwenden.'
,p_version_scn=>1
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
