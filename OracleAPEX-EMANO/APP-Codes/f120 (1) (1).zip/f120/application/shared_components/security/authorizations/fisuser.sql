prompt --application/shared_components/security/authorizations/fisuser
begin
--   Manifest
--     SECURITY SCHEME: fIsUser
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(2645659840847340007)
,p_name=>'fIsUser'
,p_scheme_type=>'NATIVE_EXISTS'
,p_attribute_01=>'select 1 from t_benutzer where benutzerid = :G_BENUTZERID'
,p_error_message=>'Sie sind nicht autorisiert, diese Anwendung zu verwenden.'
,p_version_scn=>1
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
