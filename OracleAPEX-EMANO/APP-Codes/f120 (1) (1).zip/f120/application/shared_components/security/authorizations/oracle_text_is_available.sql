prompt --application/shared_components/security/authorizations/oracle_text_is_available
begin
--   Manifest
--     SECURITY SCHEME: Oracle Text is available
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(769823299513670358)
,p_name=>'Oracle Text is available'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>'return pck_ri_vorschrift_oracle_text_pkg.text_is_available;'
,p_error_message=>'Oracle Text is not available in this workspace.'
,p_version_scn=>1
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
