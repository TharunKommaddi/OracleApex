prompt --application/shared_components/security/authentications/sso
begin
--   Manifest
--     AUTHENTICATION: SSO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>138082333993231172
,p_default_application_id=>118
,p_default_id_offset=>3672212315899388235
,p_default_owner=>'VORSCHRIFTEN_ADMIN'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(2666536060574351887)
,p_name=>'SSO'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_01=>'custom_page_sentry'
,p_attribute_05=>'N'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
